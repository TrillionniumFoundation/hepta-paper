use hepta_legacy_compatibility::qualify_production_node_profile_v1;
use serde_json::Value;
use sha2::{Digest, Sha256};
use std::{
    io::Write,
    process::{Command, Stdio},
    thread,
};
pub fn oracle(script: &str, requests: &Value, sources: &[(&str, &[u8])]) -> Value {
    let root = std::path::Path::new(env!("CARGO_MANIFEST_DIR")).join("../../..");
    let mut child = Command::new("node")
        .arg(root.join(script))
        .stdin(Stdio::piped())
        .stdout(Stdio::piped())
        .stderr(Stdio::piped())
        .spawn()
        .expect("required pinned Node oracle");
    // Read output concurrently with writing: larger differential corpora cannot deadlock pipes.
    let mut input = child.stdin.take().expect("stdin");
    let bytes = serde_json::to_vec(requests).expect("request bytes");
    let writer = thread::spawn(move || input.write_all(&bytes).expect("write oracle request"));
    let output = child.wait_with_output().expect("oracle process");
    writer.join().expect("input writer");
    assert!(
        output.status.success(),
        "oracle failure: {}",
        String::from_utf8_lossy(&output.stderr)
    );
    let value: Value = serde_json::from_slice(&output.stdout).expect("oracle JSON");
    qualify_production_node_profile_v1(&value["profile"])
        .expect("exact Node/ICU/CLDR/source profile");
    for (path, bytes) in sources {
        assert_eq!(
            value["sources"][path],
            hex::encode(Sha256::digest(bytes)),
            "actual source binding {path}"
        );
    }
    value
}
