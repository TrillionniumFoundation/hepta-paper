"""Shared guard helpers for plan-only LLM decision consumption."""

import re


EXTERNAL_OPERATION_NAMES = frozenset(
    {"delete", "email", "publish", "sendmail", "submit", "upload", "withdraw"}
)
OPERATION_RE = re.compile(r"^[a-z][a-z0-9_.-]*$")
OPERATION_SEGMENT_RE = re.compile(r"[._-]+")
OPERATION_LIKE_TOKEN_RE = re.compile(r"[a-z][a-z0-9_.-]*")
OPERATION_FIELD_NAMES = {
    "action",
    "external_operation",
    "operation",
    "operation_id",
    "requested_operation",
    "runtime_operation",
    "selected_action",
    "selected_operation",
}
FORBIDDEN_ALLOWED_COMMAND_TOKENS = {
    "curl",
    "email",
    "ftp",
    "portal",
    "scp",
    "sendmail",
    "ssh",
    "submit",
    "upload",
}
FORBIDDEN_ALLOWED_COMMAND_FLAGS = {
    "--apply",
    "--apply-status",
    "--execute",
    "--send-approved",
}

SHELL_CONTROL_TOKENS = ["\n", "\r", ";", "|", "&&", "||", "`", "$("]

FORBIDDEN_DECISION_CONSUMPTION_FLAGS = [
    "human_authorized",
    "recorder_write_path_authorized",
    "decision_consumption_authorized",
    "workflow_execution_authorized",
    "model_call_authorized",
    "external_action_authorized",
    "external_action_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_authorized",
    "package_mutation_performed",
    "archive_mutation_authorized",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "secret_material_read_authorized",
    "secret_material_read_performed",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_merge_performed",
    "crontab_mutation_authorized",
    "crontab_mutation_performed",
    "commit_authorized",
    "commit_performed",
    "approval_execution_authorized",
    "applies_decision",
    "apply_decision",
    "closes_human_boundary",
    "human_decision_closed",
]


def canonical_field_name(name):
    """Return a snake_case-ish field name for boundary alias checks."""
    text = str(name or "").strip()
    text = re.sub(r"([a-z0-9])([A-Z])", r"\1_\2", text)
    return re.sub(r"[.\-]+", "_", text).lower()


def operation_segments(operation):
    return [
        segment
        for segment in OPERATION_SEGMENT_RE.split(str(operation or "").strip().lower())
        if segment
    ]


def external_operation_verbs(operation):
    operation = str(operation or "").strip().lower()
    if not OPERATION_RE.fullmatch(operation):
        return set()
    return set(operation_segments(operation)) & set(EXTERNAL_OPERATION_NAMES)


def is_external_operation(operation):
    return bool(external_operation_verbs(operation))


def _operation_field_name(key):
    key = canonical_field_name(key)
    return key in OPERATION_FIELD_NAMES or key.endswith("_operation")


def _external_operation_field_issue(decision_output):
    for key, value in (decision_output or {}).items():
        if not _operation_field_name(key) or not isinstance(value, str):
            continue
        if is_external_operation(value):
            return f"external_action_operation {key}={value} must not be consumed by plan-only decision routing"
    return ""


def decision_output_external_operation_issue(decision_output):
    """Return an issue when decision output carries a structured external operation."""
    return _external_operation_field_issue(decision_output)


def _command_external_operation_issue(command):
    lowered = str(command or "").strip().lower()
    for token in OPERATION_LIKE_TOKEN_RE.findall(lowered):
        if token in FORBIDDEN_ALLOWED_COMMAND_TOKENS or is_external_operation(token):
            return "allowed_command contains external-action token"
    return ""


def _command_forbidden_flag_issue(command):
    lowered = str(command or "").strip().lower()
    for flag in re.findall(r"(?<![a-z0-9_.-])--[a-z0-9][a-z0-9_.-]*", lowered):
        if flag in FORBIDDEN_ALLOWED_COMMAND_FLAGS:
            return f"allowed_command contains approval/execution boundary flag {flag}"
    return ""


def decision_output_requires_human(decision_output):
    """Return True when an LLM decision explicitly stops at a human boundary."""
    decision_output = dict(decision_output or {})
    human_fields = {"requires_human", "requires_human_confirmation", "human_review_required"}
    return any(
        bool(value)
        for key, value in decision_output.items()
        if canonical_field_name(key) in human_fields
    )


def decision_output_forbidden_consumption_issue(decision_output):
    """Return a plan-only boundary issue for mutation/external authorizations."""
    decision_output = dict(decision_output or {})
    forbidden = set(FORBIDDEN_DECISION_CONSUMPTION_FLAGS)
    for key, value in decision_output.items():
        if canonical_field_name(key) in forbidden and value:
            return f"{key} must be false for plan-only decision consumption"
    operation_issue = _external_operation_field_issue(decision_output)
    if operation_issue:
        return operation_issue
    return ""


def command_safety_issue(command):
    """Return a blocking issue for shell/external command text, or empty string."""
    command = str(command or "").strip()
    if not command:
        return ""
    lowered = command.lower()
    if any(token in command for token in SHELL_CONTROL_TOKENS):
        return "allowed_command contains shell control syntax"
    flag_issue = _command_forbidden_flag_issue(lowered)
    if flag_issue:
        return flag_issue
    external_issue = _command_external_operation_issue(lowered)
    if external_issue:
        return external_issue
    return ""


def allowed_command_matches_expected(allowed_command, expected_command):
    """Validate that optional LLM command text matches an existing local command."""
    command = str(allowed_command or "").strip()
    if not command:
        return True, ""
    issue = command_safety_issue(command)
    if issue:
        return False, issue
    expected = str(expected_command or "").strip()
    if command == expected:
        return True, ""
    return False, "allowed_command does not match the selected local candidate command"


def allowed_command_safe_for_paperctl_goal(allowed_command, selected_task):
    """Validate a proposed command as a local `paperctl run --goal` route."""
    command = str(allowed_command or "").strip()
    if not command:
        return True, ""
    issue = command_safety_issue(command)
    if issue:
        return False, issue
    lowered = command.lower()
    tokens = set(re.findall(r"[a-z0-9_./-]+", lowered))
    selected = str(selected_task or "").strip().lower()
    has_paperctl = any(token.endswith("paperctl") for token in tokens)
    has_run = "run" in tokens
    has_goal = bool(selected and (f"--goal {selected}" in lowered or f"--goal={selected}" in lowered))
    if has_paperctl and has_run and has_goal:
        return True, ""
    return False, "allowed_command is not a paperctl run --goal proposal for the selected task"


def decision_plan_consumption_issue(
    decision_plan,
    expected_state="PLAN_ONLY_CONSUMABLE",
    required_selection_fields=None,
):
    """Return why a plan-only decision may not be consumed by a route selector."""
    decision_plan = dict(decision_plan or {})
    if not decision_plan.get("consume_allowed"):
        return "decision plan is not marked consumable"
    state = decision_plan.get("consumption_state") or ""
    if expected_state and state != expected_state:
        return f"decision plan state is not {expected_state}: {state or '<missing>'}"
    fields = list(required_selection_fields or [])
    if fields and not any(decision_plan.get(field) for field in fields):
        return "decision plan is missing explicit LLM selection fields"
    return ""
