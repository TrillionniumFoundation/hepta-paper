"""Paper production lifecycle core.

This module is deliberately paper-specific.  It sits above local proof,
referee, gate, package, preflight, release, and external-submission surfaces
and chooses one fail-closed production state for each paper.
"""

import collections
import datetime as dt


COMMAND = "paper-production-core-audit"
SCHEMA_ID = "paper_factory.paper_production.core_audit.v1"
REPAIR_LOOP_COMMAND = "paper-production-repair-loop"
REPAIR_LOOP_SCHEMA_ID = "paper_factory.paper_production.repair_loop.v1"

SOURCE_MISSING = "SOURCE_MISSING"
CONTRACT_MISSING = "CONTRACT_MISSING"
PROOF_BLOCKED = "PROOF_BLOCKED"
REPAIR_REQUESTED = "REPAIR_REQUESTED"
GATE_BLOCKED = "GATE_BLOCKED"
PACKAGE_BLOCKED = "PACKAGE_BLOCKED"
PREFLIGHT_BLOCKED = "PREFLIGHT_BLOCKED"
WARNING_REVIEW_BLOCKED = "WARNING_REVIEW_BLOCKED"
LOCAL_RELEASE_BLOCKED = "LOCAL_RELEASE_BLOCKED"
EXTERNAL_AUTH_REQUIRED = "EXTERNAL_AUTH_REQUIRED"
PRODUCTION_READY_LOCAL_ONLY = "PRODUCTION_READY_LOCAL_ONLY"

PASS_STATE = PRODUCTION_READY_LOCAL_ONLY
ATTENTION_STATES = {EXTERNAL_AUTH_REQUIRED}
FAIL_STATES = {
    SOURCE_MISSING,
    CONTRACT_MISSING,
    PROOF_BLOCKED,
    REPAIR_REQUESTED,
    GATE_BLOCKED,
    PACKAGE_BLOCKED,
    PREFLIGHT_BLOCKED,
    WARNING_REVIEW_BLOCKED,
    LOCAL_RELEASE_BLOCKED,
}

PAPER_CONTRACT_CHAIN = [
    "PaperRegistryRecord",
    "SourceWorkspace",
    "ClaimInventory",
    "ClaimClassification",
    "EvidenceProvenance",
    "ProofOrQualityContract",
    "ProofReadinessReport",
    "RefereeRepairQueue",
    "GateRun",
    "ArtifactPackage",
    "SubmissionPreflight",
    "HandoffIndex",
    "LocalArchive",
    "ReleaseVerification",
    "ManualVenueAuthorization",
    "ExternalSubmissionReceipt",
]

PAPER_PROFILES = [
    "theorem_or_proof_paper",
    "empirical_or_experiment_paper",
    "systems_or_artifact_paper",
    "survey_or_position_paper",
    "external_data_or_human_subjects_paper",
]

REPAIR_LOOP_TERMINAL_STATES = {
    EXTERNAL_AUTH_REQUIRED,
    PRODUCTION_READY_LOCAL_ONLY,
}

REPAIR_LOOP_STATE_ACTIONS = [
    (SOURCE_MISSING, "BLOCKED_SOURCE_MISSING", "restore or declare source before repair automation can run"),
    (CONTRACT_MISSING, "BLOCKED_CONTRACT_MISSING", "declare paper profile and proof/quality contract before referee repair automation can run"),
    (PROOF_BLOCKED, "SYNC_PROOF_BLOCKERS", "sync proof-readiness blockers into referee repair requests"),
    (REPAIR_REQUESTED, "RUN_REFEREE_REPAIR", "run referee repair runner/orchestrator for open proof-readiness requests"),
    (GATE_BLOCKED, "RUN_GATE", "run or repair local gate after proof/referee blockers clear"),
    (PACKAGE_BLOCKED, "RUN_PACKAGE_REBUILD", "create/verify local packages after upstream paper state clears"),
    (PREFLIGHT_BLOCKED, "RUN_SUBMISSION_PREFLIGHT", "run submission preflight after package verification clears"),
    (WARNING_REVIEW_BLOCKED, "RUN_WARNING_REVIEW", "resolve or explicitly explain submission-preflight warnings before release"),
    (LOCAL_RELEASE_BLOCKED, "RUN_RELEASE_VERIFY", "freeze or verify local release after preflight clears"),
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _as_int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _status_for_state(state):
    if state in FAIL_STATES:
        return "FAIL"
    if state in ATTENTION_STATES:
        return "ATTENTION"
    return "PASS"


def _stage(name, status, detail="", blocking=True, ref=None):
    return {
        "name": name,
        "status": status,
        "blocking": bool(blocking),
        "detail": detail,
        "ref": ref or {},
    }


def _missing_or_status(value):
    return value or "MISSING"


def _package_status(snapshot):
    package = snapshot.get("package") or {}
    return _missing_or_status(package.get("status") or ("PASS" if package.get("present") else ""))


def _preflight_status(snapshot):
    preflight = snapshot.get("submission_preflight") or {}
    return _missing_or_status(preflight.get("status") or ("PASS" if preflight.get("present") else ""))


def _release_status(snapshot):
    release = snapshot.get("release_verify") or {}
    status = _missing_or_status(release.get("status") or ("PASS" if release.get("present") else ""))
    semantics = release.get("current_package_verify_semantics_pass")
    if status == "PASS" and semantics is False:
        return "FAIL"
    return status


def _warning_review_status(snapshot):
    warning_review = snapshot.get("warning_review") or {}
    preflight = snapshot.get("submission_preflight") or {}
    warning_count = _as_int(
        warning_review.get("warning_count", preflight.get("warning_count"))
    )
    unresolved_count = _as_int(warning_review.get("unresolved_count"))
    status = _missing_or_status(warning_review.get("status"))
    if warning_count <= 0 and status == "MISSING":
        return "PASS", {
            "warning_count": 0,
            "unresolved_count": 0,
            "status": "NOT_REQUIRED",
            "present": False,
        }
    if status == "PASS" and unresolved_count == 0:
        return "PASS", dict(warning_review)
    return "FAIL", dict(warning_review)


def evaluate_paper(snapshot):
    """Evaluate one paper snapshot into a single production state."""
    snapshot = dict(snapshot or {})
    proof = dict(snapshot.get("proof_readiness") or {})
    gate = dict(snapshot.get("latest_gate") or {})
    repair = dict(snapshot.get("repair_queue") or {})

    slug = snapshot.get("slug") or ""
    source_ready = bool(snapshot.get("source_ready"))
    contract_declared = bool(proof.get("contract_declared"))
    proof_blockers = _as_int(proof.get("blocker_count"))
    proof_blocking = bool(proof.get("workflow_readiness_blocking")) or proof_blockers > 0
    repair_requested = _as_int(repair.get("open_proof_blocker_count")) > 0
    gate_status = _missing_or_status(gate.get("status"))
    package_status = _package_status(snapshot)
    preflight_status = _preflight_status(snapshot)
    warning_review_status, warning_review_snapshot = _warning_review_status(snapshot)
    release_status = _release_status(snapshot)
    external_authorized = bool(snapshot.get("manual_venue_authorization", {}).get("external_action_authorized"))

    stages = []
    upstream_blocked = False

    def add_stage(name, status, detail="", blocking=True, ref=None):
        nonlocal upstream_blocked
        effective_status = status
        effective_blocking = blocking
        effective_detail = detail
        if upstream_blocked and status == "FAIL":
            effective_status = "SKIP"
            effective_blocking = False
            effective_detail = f"blocked_by_upstream:{detail}"
        stages.append(_stage(name, effective_status, effective_detail, blocking=effective_blocking, ref=ref))
        if effective_blocking and effective_status == "FAIL":
            upstream_blocked = True

    add_stage(
        "SourceWorkspace",
        "PASS" if source_ready else "FAIL",
        snapshot.get("main_tex") or "missing main tex",
    )
    add_stage(
        "ProofOrQualityContract",
        "PASS" if contract_declared else "FAIL",
        proof.get("proof_state") or "missing declared proof/quality contract",
        ref={"proof_readiness_hash": proof.get("proof_readiness_hash") or ""},
    )
    add_stage(
        "ProofReadinessReport",
        "FAIL" if proof_blocking else ("PASS" if contract_declared else "SKIP"),
        ",".join(proof.get("failed_report_ids") or []) or proof.get("proof_state") or "",
        ref={"blocker_count": proof_blockers},
    )
    add_stage(
        "RefereeRepairQueue",
        "ATTENTION" if repair_requested else ("PASS" if not proof_blocking else "FAIL"),
        f"open_proof_blockers={repair.get('open_proof_blocker_count', 0)}",
        blocking=proof_blocking and not repair_requested,
        ref=repair,
    )
    add_stage("GateRun", "PASS" if gate_status == "PASS" else "FAIL", gate_status, ref=gate)
    add_stage("ArtifactPackage", "PASS" if package_status == "PASS" else "FAIL", package_status, ref=snapshot.get("package") or {})
    add_stage(
        "SubmissionPreflight",
        "PASS" if preflight_status == "PASS" else "FAIL",
        preflight_status,
        ref=snapshot.get("submission_preflight") or {},
    )
    add_stage(
        "WarningReview",
        "PASS" if warning_review_status == "PASS" else "FAIL",
        warning_review_status,
        ref=warning_review_snapshot,
    )
    add_stage(
        "ReleaseVerification",
        "PASS" if release_status == "PASS" else "FAIL",
        release_status,
        ref=snapshot.get("release_verify") or {},
    )
    add_stage(
        "ManualVenueAuthorization",
        "PASS" if external_authorized else "ATTENTION",
        "external_action_authorized" if external_authorized else "external_action_not_authorized",
        blocking=False,
        ref=snapshot.get("manual_venue_authorization") or {},
    )

    if not source_ready:
        state = SOURCE_MISSING
        next_action = "restore or declare the source workspace and main tex"
    elif not contract_declared:
        state = CONTRACT_MISSING
        next_action = "declare the paper-specific proof/quality contract"
    elif proof_blocking and repair_requested:
        state = REPAIR_REQUESTED
        next_action = "dispatch or complete the open proof-readiness repair requests"
    elif proof_blocking:
        state = PROOF_BLOCKED
        next_action = "sync proof blockers into the referee repair queue"
    elif gate_status != "PASS":
        state = GATE_BLOCKED
        next_action = "run or repair the paper gate"
    elif package_status != "PASS":
        state = PACKAGE_BLOCKED
        next_action = "create and verify a local package after upstream gates pass"
    elif preflight_status != "PASS":
        state = PREFLIGHT_BLOCKED
        next_action = "run or repair submission preflight"
    elif warning_review_status != "PASS":
        state = WARNING_REVIEW_BLOCKED
        next_action = "run or repair warning review before local release"
    elif release_status != "PASS":
        state = LOCAL_RELEASE_BLOCKED
        next_action = "freeze and verify the local release archive"
    elif not external_authorized:
        state = EXTERNAL_AUTH_REQUIRED
        next_action = "request explicit human venue/external submission authorization"
    else:
        state = PRODUCTION_READY_LOCAL_ONLY
        next_action = "ready for authorized external submission handoff"

    status = _status_for_state(state)
    blockers = [
        item
        for item in stages
        if item.get("blocking") and item.get("status") == "FAIL"
    ]
    return {
        "slug": slug,
        "status": status,
        "production_state": state,
        "next_action": next_action,
        "source_ready": source_ready,
        "proof_blocked": proof_blocking,
        "proof_blocker_count": proof_blockers,
        "repair_requested": repair_requested,
        "open_proof_blocker_count": _as_int(repair.get("open_proof_blocker_count")),
        "stage_checks": stages,
        "blocking_stage_count": len(blockers),
        "blocking_stages": blockers,
        "inputs": snapshot,
    }


def summarize(evaluations):
    evaluations = [dict(item or {}) for item in evaluations]
    state_counts = collections.Counter(item.get("production_state") or "" for item in evaluations)
    status_counts = collections.Counter(item.get("status") or "" for item in evaluations)
    fail_count = status_counts.get("FAIL", 0)
    attention_count = status_counts.get("ATTENTION", 0)
    return {
        "status": "FAIL" if fail_count else ("ATTENTION" if attention_count else "PASS"),
        "paper_count": len(evaluations),
        "pass_count": status_counts.get("PASS", 0),
        "fail_count": fail_count,
        "attention_count": attention_count,
        "state_counts": dict(sorted(state_counts.items())),
        "source_missing_count": state_counts.get(SOURCE_MISSING, 0),
        "contract_missing_count": state_counts.get(CONTRACT_MISSING, 0),
        "proof_blocked_count": sum(1 for item in evaluations if item.get("proof_blocked")),
        "repair_requested_count": state_counts.get(REPAIR_REQUESTED, 0),
        "gate_blocked_count": state_counts.get(GATE_BLOCKED, 0),
        "package_blocked_count": state_counts.get(PACKAGE_BLOCKED, 0),
        "preflight_blocked_count": state_counts.get(PREFLIGHT_BLOCKED, 0),
        "warning_review_blocked_count": state_counts.get(WARNING_REVIEW_BLOCKED, 0),
        "local_release_blocked_count": state_counts.get(LOCAL_RELEASE_BLOCKED, 0),
        "external_auth_required_count": state_counts.get(EXTERNAL_AUTH_REQUIRED, 0),
        "production_ready_local_only_count": state_counts.get(PRODUCTION_READY_LOCAL_ONLY, 0),
        "proof_blocker_count": sum(_as_int(item.get("proof_blocker_count")) for item in evaluations),
        "open_proof_blocker_count": sum(_as_int(item.get("open_proof_blocker_count")) for item in evaluations),
    }


def audit_report(paper_snapshots, label="", created_at=None, skipped=None):
    evaluations = [evaluate_paper(item) for item in paper_snapshots]
    summary = summarize(evaluations)
    return {
        "created_at": created_at or _created_at(),
        "command": COMMAND,
        "status": summary["status"],
        "label": label or "",
        "report_schema": {
            "schema_id": SCHEMA_ID,
            "stable_top_level_fields": [
                "created_at",
                "command",
                "status",
                "label",
                "report_schema",
                "paper_contract_chain",
                "paper_profiles",
                "summary",
                "papers",
                "skipped",
                "boundary",
            ],
            "stable_summary_fields": [
                "paper_count",
                "pass_count",
                "fail_count",
                "attention_count",
                "state_counts",
                "contract_missing_count",
                "proof_blocked_count",
                "repair_requested_count",
                "external_auth_required_count",
            ],
            "deprecated_fields": [],
            "notes": [
                "A paper has exactly one highest-priority production_state.",
                "Missing proof/quality contract is production-blocking even when lower proof-readiness reports are migration ATTENTION.",
                "External submission is never implied by local package, preflight, archive, or release verification.",
            ],
        },
        "paper_contract_chain": list(PAPER_CONTRACT_CHAIN),
        "paper_profiles": list(PAPER_PROFILES),
        "summary": summary,
        "papers": evaluations,
        "skipped": list(skipped or []),
        "boundary": {
            "source_mutation_performed": False,
            "package_mutation_performed": False,
            "archive_mutation_performed": False,
            "provider_model_call_performed": False,
            "external_action_performed": False,
            "secret_material_read_performed": False,
            "commit_performed": False,
        },
    }


def repair_loop_frontier(audit_report):
    """Return the next repair-loop action for a production-core audit report."""
    report = dict(audit_report or {})
    summary = dict(report.get("summary") or {})
    papers = [dict(item or {}) for item in report.get("papers") or []]
    state_counts = dict(summary.get("state_counts") or {})
    if not papers:
        return {
            "action": "NO_TARGETS",
            "terminal": True,
            "state": "",
            "paper_count": 0,
            "slugs": [],
            "reason": "no selected papers",
        }
    failing = int(summary.get("fail_count") or 0)
    if failing == 0:
        terminal_states = sorted({
            item.get("production_state") or ""
            for item in papers
            if item.get("production_state") in REPAIR_LOOP_TERMINAL_STATES
        })
        return {
            "action": "LOCAL_PRODUCTION_COMPLETE",
            "terminal": True,
            "state": ",".join(terminal_states),
            "paper_count": len(papers),
            "slugs": [item.get("slug") or "" for item in papers],
            "reason": "local production core has no failing states",
        }
    for state, action, reason in REPAIR_LOOP_STATE_ACTIONS:
        count = int(state_counts.get(state) or 0)
        if count <= 0:
            continue
        slugs = [
            item.get("slug") or ""
            for item in papers
            if item.get("production_state") == state
        ]
        return {
            "action": action,
            "terminal": action.startswith("BLOCKED_"),
            "state": state,
            "paper_count": count,
            "slugs": slugs,
            "reason": reason,
        }
    return {
        "action": "BLOCKED_UNKNOWN_STATE",
        "terminal": True,
        "state": "",
        "paper_count": failing,
        "slugs": [item.get("slug") or "" for item in papers if item.get("status") == "FAIL"],
        "reason": "production audit failed with no recognized repair-loop frontier",
    }


def repair_loop_frontier_slug_shard(frontier, worker_limit=0):
    """Select the current frontier slug batch for a repair-loop iteration."""
    frontier = dict(frontier or {})
    action = frontier.get("action") or ""
    slugs = [slug for slug in (frontier.get("slugs") or []) if slug]
    limit = max(0, _as_int(worker_limit))
    selected = list(slugs)
    deferred = []
    if action == "RUN_REFEREE_REPAIR" and limit > 0:
        selected = slugs[:limit]
        deferred = slugs[len(selected):]
    return {
        "worker_limit": limit,
        "worker_limit_applied": action == "RUN_REFEREE_REPAIR" and limit > 0,
        "frontier_slugs": slugs,
        "selected_slugs": selected,
        "deferred_slugs": deferred,
    }


def resolve_artifact_label(requested_label="", latest_label="", requested_package_count=0, requested_present_count=None):
    """Resolve the package/release label used by a core audit."""
    requested_label = requested_label or ""
    latest_label = latest_label or ""
    requested_package_count = _as_int(requested_package_count)
    if requested_present_count is None:
        requested_present_count = requested_package_count
    requested_present_count = _as_int(requested_present_count)
    if requested_label and requested_present_count > 0:
        return {
            "artifact_label": requested_label,
            "artifact_label_source": "requested_label",
            "fallback_from_label": "",
            "requested_package_count": requested_package_count,
            "requested_present_count": requested_present_count,
        }
    if latest_label and latest_label != requested_label:
        return {
            "artifact_label": latest_label,
            "artifact_label_source": "latest_package_label",
            "fallback_from_label": requested_label,
            "requested_package_count": requested_package_count,
            "requested_present_count": requested_present_count,
        }
    return {
        "artifact_label": requested_label or latest_label,
        "artifact_label_source": "requested_label" if requested_label else ("latest_package_label" if latest_label else ""),
        "fallback_from_label": "",
        "requested_package_count": requested_package_count,
        "requested_present_count": requested_present_count,
    }
