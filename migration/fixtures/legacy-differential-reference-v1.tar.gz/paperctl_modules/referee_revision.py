"""Pure referee-revision decision helpers for paperctl."""

from paperctl_modules.llm_consumption import (
    command_safety_issue,
    decision_output_forbidden_consumption_issue,
    decision_output_requires_human,
)


def _forbidden_consumption_state(issue):
    if str(issue or "").startswith("external_action_"):
        return "EXTERNAL_ACTION_FORBIDDEN"
    return "FORBIDDEN_DECISION_BOUNDARY"


def _decision_ref_issue_text(decision_ref):
    issues = []
    for issue in (decision_ref or {}).get("validation_issues") or []:
        if isinstance(issue, dict):
            issues.append(str(issue.get("issue") or issue.get("message") or issue))
        else:
            issues.append(str(issue))
    return "; ".join(issue for issue in issues if issue)


def _request_id(item):
    request = item.get("request") or {}
    try:
        return int(request.get("request_id") or 0)
    except Exception:
        return 0


def _candidate_request_ids(items):
    return [_request_id(item) for item in items if _request_id(item)]


def _candidate_modes(items):
    modes = []
    for item in items:
        mode = item.get("repair_mode") or ""
        if mode and mode not in modes:
            modes.append(mode)
    return modes


def _matches_request(item, decision_output):
    request = item.get("request") or {}
    selected_request_id = (
        decision_output.get("selected_request_id")
        or decision_output.get("request_id")
        or decision_output.get("target_request_id")
        or ""
    )
    if selected_request_id:
        try:
            if int(selected_request_id) != int(request.get("request_id") or 0):
                return False
        except Exception:
            return False
    selected_request_key = (
        decision_output.get("selected_request_key")
        or decision_output.get("request_key")
        or ""
    )
    if selected_request_key and selected_request_key != (request.get("request_key") or ""):
        return False
    selected_slug = decision_output.get("selected_slug") or decision_output.get("slug") or ""
    if selected_slug and selected_slug != (request.get("slug") or ""):
        return False
    selected_mode = (
        decision_output.get("selected_repair_mode")
        or decision_output.get("repair_mode")
        or decision_output.get("selected_route")
        or decision_output.get("route")
        or decision_output.get("selected_task")
        or decision_output.get("task")
        or ""
    )
    if selected_mode and selected_mode != (item.get("repair_mode") or ""):
        return False
    allowed_command = decision_output.get("allowed_command") or ""
    if allowed_command and allowed_command != (item.get("next_command_after_repair") or ""):
        return False
    next_action = decision_output.get("next_action") or decision_output.get("selected_action") or ""
    if next_action and next_action not in [
        item.get("repair_mode") or "",
        item.get("next_command_after_repair") or "",
        request.get("request_key") or "",
    ]:
        return False
    return bool(selected_request_id or selected_request_key or selected_slug or selected_mode or allowed_command or next_action)


def _matching_request_route(items, decision_output):
    for item in items:
        if _matches_request(item, decision_output):
            return item
    return {}


def referee_revision_request_decision_plan(blocked_requests, decision_output=None, decision_ref=None):
    """Return a plan-only view of referee-revision blocked-request route consumption."""
    blocked_requests = [dict(item) for item in blocked_requests or []]
    decision_output = dict(decision_output or {})
    decision_ref = dict(decision_ref or {})
    deterministic_item = blocked_requests[0] if blocked_requests else {}
    deterministic_request = deterministic_item.get("request") or {}
    deterministic_request_id = _request_id(deterministic_item)
    deterministic_repair_mode = deterministic_item.get("repair_mode") or ""
    deterministic_command = deterministic_item.get("next_command_after_repair") or ""
    candidate_request_ids = _candidate_request_ids(blocked_requests)
    candidate_repair_modes = _candidate_modes(blocked_requests)
    if not blocked_requests:
        return {
            "consume_allowed": False,
            "consumption_state": "NO_BLOCKED_REQUEST_ROUTE_REQUIRED",
            "reason": "blocked repair plan has no blocked requests",
            "deterministic_request_id": 0,
            "deterministic_request_key": "",
            "deterministic_repair_mode": "",
            "deterministic_command": "",
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": 0,
            "candidate_request_ids": [],
            "candidate_repair_modes": [],
            "decision_report_ref": decision_ref,
        }
    if not decision_ref:
        return {
            "consume_allowed": False,
            "consumption_state": "NO_LLM_DECISION_REPORT",
            "reason": "missing referee_revision_request_route LLM decision report",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": {},
        }
    decision_ref_issue = _decision_ref_issue_text(decision_ref)
    if decision_ref_issue:
        return {
            "consume_allowed": False,
            "consumption_state": "INVALID_LLM_DECISION_REPORT",
            "reason": f"referee_revision_request_route decision report is not valid: {decision_ref_issue}",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": decision_ref,
        }
    if decision_output.get("decision_point_id") != "referee_revision_request_route":
        return {
            "consume_allowed": False,
            "consumption_state": "INVALID_DECISION_POINT",
            "reason": "decision output is not for referee_revision_request_route",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": decision_ref,
        }
    forbidden_issue = decision_output_forbidden_consumption_issue(decision_output)
    if forbidden_issue:
        return {
            "consume_allowed": False,
            "consumption_state": _forbidden_consumption_state(forbidden_issue),
            "reason": forbidden_issue,
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": decision_ref,
        }
    allowed_command_issue = command_safety_issue(decision_output.get("allowed_command") or "")
    if allowed_command_issue:
        return {
            "consume_allowed": False,
            "consumption_state": "ALLOWED_COMMAND_NOT_SAFE_REQUEST_ROUTE",
            "reason": allowed_command_issue,
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": decision_ref,
        }
    if decision_output_requires_human(decision_output):
        return {
            "consume_allowed": False,
            "consumption_state": "HUMAN_REVIEW_REQUIRED",
            "reason": "decision output requires human review before request route consumption",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": decision_ref,
        }
    matched = _matching_request_route(blocked_requests, decision_output)
    if not matched:
        return {
            "consume_allowed": False,
            "consumption_state": "NO_SELECTABLE_REQUEST_ROUTE",
            "reason": "decision output does not identify a blocked request repair route",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_repair_mode": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "decision_report_ref": decision_ref,
        }
    request = matched.get("request") or {}
    llm_request_id = _request_id(matched)
    llm_repair_mode = matched.get("repair_mode") or ""
    llm_command = matched.get("next_command_after_repair") or ""
    return {
        "consume_allowed": True,
        "consumption_state": "PLAN_ONLY_CONSUMABLE",
        "reason": "decision output identifies a blocked request repair route",
        "deterministic_request_id": deterministic_request_id,
        "deterministic_request_key": deterministic_request.get("request_key") or "",
        "deterministic_repair_mode": deterministic_repair_mode,
        "deterministic_command": deterministic_command,
        "llm_request_id": llm_request_id,
        "llm_request_key": request.get("request_key") or "",
        "llm_repair_mode": llm_repair_mode,
        "llm_command": llm_command,
        "would_change_route": (
            llm_request_id != deterministic_request_id
            or llm_repair_mode != deterministic_repair_mode
            or llm_command != deterministic_command
        ),
        "candidate_count": len(blocked_requests),
        "candidate_request_ids": candidate_request_ids,
        "candidate_repair_modes": candidate_repair_modes,
        "decision_report_ref": decision_ref,
    }


def referee_revision_request_consuming_selection(blocked_requests, decision_plan=None):
    """Select one blocked-request repair route from a validated LLM plan."""
    blocked_requests = [dict(item) for item in blocked_requests or []]
    decision_plan = dict(decision_plan or {})
    deterministic_item = blocked_requests[0] if blocked_requests else {}
    deterministic_request = deterministic_item.get("request") or {}
    deterministic_request_id = _request_id(deterministic_item)
    deterministic_repair_mode = deterministic_item.get("repair_mode") or ""
    deterministic_command = deterministic_item.get("next_command_after_repair") or ""
    candidate_request_ids = _candidate_request_ids(blocked_requests)
    candidate_repair_modes = _candidate_modes(blocked_requests)

    def selected_payload(decision_consumed, selection_state, item, fallback_reason, would_change_route=False):
        request = item.get("request") or {}
        return {
            "decision_consumed": bool(decision_consumed),
            "selection_state": selection_state,
            "plan_state": decision_plan.get("consumption_state") or "",
            "selected_request_id": _request_id(item),
            "selected_request_key": request.get("request_key") or "",
            "selected_slug": request.get("slug") or "",
            "selected_repair_mode": item.get("repair_mode") or "",
            "selected_command": item.get("next_command_after_repair") or "",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_slug": deterministic_request.get("slug") or "",
            "deterministic_repair_mode": deterministic_repair_mode,
            "deterministic_command": deterministic_command,
            "would_change_route": bool(would_change_route),
            "candidate_count": len(blocked_requests),
            "candidate_request_ids": candidate_request_ids,
            "candidate_repair_modes": candidate_repair_modes,
            "fallback_reason": fallback_reason,
            "decision_report_ref": decision_plan.get("decision_report_ref") or {},
        }

    if decision_plan.get("consume_allowed"):
        selected_request_id = int(decision_plan.get("llm_request_id") or 0)
        selected_request_key = decision_plan.get("llm_request_key") or ""
        selected_repair_mode = decision_plan.get("llm_repair_mode") or ""
        selected_command = decision_plan.get("llm_command") or ""
        matched = {}
        for item in blocked_requests:
            request = item.get("request") or {}
            if selected_request_id and _request_id(item) != selected_request_id:
                continue
            if selected_request_key and selected_request_key != (request.get("request_key") or ""):
                continue
            if selected_repair_mode and selected_repair_mode != (item.get("repair_mode") or ""):
                continue
            if selected_command and selected_command != (item.get("next_command_after_repair") or ""):
                continue
            matched = item
            break
        if matched:
            return selected_payload(
                True,
                "CONSUMED_LLM_REFEREE_REVISION_REQUEST_ROUTE",
                matched,
                "",
                decision_plan.get("would_change_route"),
            )

    if not blocked_requests:
        return selected_payload(
            False,
            "NO_BLOCKED_REQUEST_ROUTE_REQUIRED",
            {},
            decision_plan.get("reason") or "blocked repair plan has no blocked requests",
        )

    return selected_payload(
        False,
        "DETERMINISTIC_FALLBACK_NO_LLM_REFEREE_REVISION_REQUEST_CONSUMPTION",
        deterministic_item,
        decision_plan.get("reason") or "missing consumable referee_revision_request_route LLM decision report",
    )


def _item_patch_id(item):
    try:
        return int(item.get("patch_id") or 0)
    except Exception:
        return 0


def _candidate_resync_keys(items):
    keys = []
    for item in items:
        request = item.get("request") or {}
        request_id = _request_id(item)
        patch_id = _item_patch_id(item)
        key = f"{request_id}:{patch_id}:{item.get('classification') or ''}:{request.get('request_key') or ''}"
        keys.append(key)
    return keys


def _candidate_resync_classifications(items):
    classifications = []
    for item in items:
        classification = item.get("classification") or ""
        if classification and classification not in classifications:
            classifications.append(classification)
    return classifications


def _matches_resync_item(item, decision_output):
    request = item.get("request") or {}
    selected_request_id = (
        decision_output.get("selected_request_id")
        or decision_output.get("request_id")
        or decision_output.get("target_request_id")
        or ""
    )
    if selected_request_id:
        try:
            if int(selected_request_id) != int(request.get("request_id") or 0):
                return False
        except Exception:
            return False
    selected_patch_id = (
        decision_output.get("selected_patch_id")
        or decision_output.get("patch_id")
        or decision_output.get("target_patch_id")
        or ""
    )
    if selected_patch_id:
        try:
            if int(selected_patch_id) != _item_patch_id(item):
                return False
        except Exception:
            return False
    selected_key = decision_output.get("selected_request_key") or decision_output.get("request_key") or ""
    if selected_key and selected_key != (request.get("request_key") or ""):
        return False
    selected_classification = (
        decision_output.get("selected_classification")
        or decision_output.get("classification")
        or decision_output.get("selected_route")
        or decision_output.get("route")
        or decision_output.get("selected_task")
        or decision_output.get("task")
        or ""
    )
    if selected_classification and selected_classification != (item.get("classification") or ""):
        return False
    allowed_command = decision_output.get("allowed_command") or ""
    if allowed_command and allowed_command not in [
        item.get("next_command") or "",
        item.get("patch_hygiene_command") or "",
    ]:
        return False
    next_action = decision_output.get("next_action") or decision_output.get("selected_action") or ""
    if next_action and next_action not in [
        item.get("classification") or "",
        item.get("recommended_action") or "",
        item.get("next_command") or "",
        item.get("patch_hygiene_command") or "",
        request.get("request_key") or "",
    ]:
        return False
    return bool(selected_request_id or selected_patch_id or selected_key or selected_classification or allowed_command or next_action)


def _matching_resync_item(items, decision_output):
    for item in items:
        if _matches_resync_item(item, decision_output):
            return item
    return {}


def evidence_resync_decision_plan(items, decision_output=None, decision_ref=None):
    """Return a plan-only view of evidence resync-route consumption."""
    items = [dict(item) for item in items or []]
    decision_output = dict(decision_output or {})
    decision_ref = dict(decision_ref or {})
    deterministic_item = items[0] if items else {}
    deterministic_request = deterministic_item.get("request") or {}
    deterministic_request_id = _request_id(deterministic_item)
    deterministic_patch_id = _item_patch_id(deterministic_item)
    deterministic_classification = deterministic_item.get("classification") or ""
    deterministic_command = deterministic_item.get("next_command") or ""
    candidate_keys = _candidate_resync_keys(items)
    candidate_classifications = _candidate_resync_classifications(items)
    if not items:
        return {
            "consume_allowed": False,
            "consumption_state": "NO_RESYNC_ACTION_REQUIRED",
            "reason": "evidence resync report has no selected items",
            "deterministic_request_id": 0,
            "deterministic_request_key": "",
            "deterministic_patch_id": 0,
            "deterministic_classification": "",
            "deterministic_command": "",
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": 0,
            "candidate_keys": [],
            "candidate_classifications": [],
            "decision_report_ref": decision_ref,
        }
    if not decision_ref:
        return {
            "consume_allowed": False,
            "consumption_state": "NO_LLM_DECISION_REPORT",
            "reason": "missing evidence_resync_route LLM decision report",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": {},
        }
    decision_ref_issue = _decision_ref_issue_text(decision_ref)
    if decision_ref_issue:
        return {
            "consume_allowed": False,
            "consumption_state": "INVALID_LLM_DECISION_REPORT",
            "reason": f"evidence_resync_route decision report is not valid: {decision_ref_issue}",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": decision_ref,
        }
    if decision_output.get("decision_point_id") != "evidence_resync_route":
        return {
            "consume_allowed": False,
            "consumption_state": "INVALID_DECISION_POINT",
            "reason": "decision output is not for evidence_resync_route",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": decision_ref,
        }
    forbidden_issue = decision_output_forbidden_consumption_issue(decision_output)
    if forbidden_issue:
        return {
            "consume_allowed": False,
            "consumption_state": _forbidden_consumption_state(forbidden_issue),
            "reason": forbidden_issue,
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": decision_ref,
        }
    allowed_command_issue = command_safety_issue(decision_output.get("allowed_command") or "")
    if allowed_command_issue:
        return {
            "consume_allowed": False,
            "consumption_state": "ALLOWED_COMMAND_NOT_SAFE_EVIDENCE_RESYNC_ROUTE",
            "reason": allowed_command_issue,
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": decision_ref,
        }
    if decision_output_requires_human(decision_output):
        return {
            "consume_allowed": False,
            "consumption_state": "HUMAN_REVIEW_REQUIRED",
            "reason": "decision output requires human review before evidence resync route consumption",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": decision_ref,
        }
    matched = _matching_resync_item(items, decision_output)
    if not matched:
        return {
            "consume_allowed": False,
            "consumption_state": "NO_SELECTABLE_RESYNC_ROUTE",
            "reason": "decision output does not identify an evidence resync item",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "llm_request_id": 0,
            "llm_request_key": "",
            "llm_patch_id": 0,
            "llm_classification": "",
            "llm_command": "",
            "would_change_route": False,
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "decision_report_ref": decision_ref,
        }
    request = matched.get("request") or {}
    llm_request_id = _request_id(matched)
    llm_patch_id = _item_patch_id(matched)
    llm_classification = matched.get("classification") or ""
    llm_command = decision_output.get("allowed_command") or matched.get("next_command") or ""
    return {
        "consume_allowed": True,
        "consumption_state": "PLAN_ONLY_CONSUMABLE",
        "reason": "decision output identifies an evidence resync item",
        "deterministic_request_id": deterministic_request_id,
        "deterministic_request_key": deterministic_request.get("request_key") or "",
        "deterministic_patch_id": deterministic_patch_id,
        "deterministic_classification": deterministic_classification,
        "deterministic_command": deterministic_command,
        "llm_request_id": llm_request_id,
        "llm_request_key": request.get("request_key") or "",
        "llm_patch_id": llm_patch_id,
        "llm_classification": llm_classification,
        "llm_command": llm_command,
        "would_change_route": (
            llm_request_id != deterministic_request_id
            or llm_patch_id != deterministic_patch_id
            or llm_classification != deterministic_classification
            or llm_command != deterministic_command
        ),
        "candidate_count": len(items),
        "candidate_keys": candidate_keys,
        "candidate_classifications": candidate_classifications,
        "decision_report_ref": decision_ref,
    }


def evidence_resync_consuming_selection(items, decision_plan=None):
    """Select one evidence-resync route from a validated LLM plan."""
    items = [dict(item) for item in items or []]
    decision_plan = dict(decision_plan or {})
    deterministic_item = items[0] if items else {}
    deterministic_request = deterministic_item.get("request") or {}
    deterministic_request_id = _request_id(deterministic_item)
    deterministic_patch_id = _item_patch_id(deterministic_item)
    deterministic_classification = deterministic_item.get("classification") or ""
    deterministic_command = deterministic_item.get("next_command") or ""
    candidate_keys = _candidate_resync_keys(items)
    candidate_classifications = _candidate_resync_classifications(items)

    def selected_payload(decision_consumed, selection_state, item, fallback_reason, would_change_route=False):
        request = item.get("request") or {}
        return {
            "decision_consumed": bool(decision_consumed),
            "selection_state": selection_state,
            "plan_state": decision_plan.get("consumption_state") or "",
            "selected_request_id": _request_id(item),
            "selected_request_key": request.get("request_key") or "",
            "selected_slug": request.get("slug") or "",
            "selected_patch_id": _item_patch_id(item),
            "selected_classification": item.get("classification") or "",
            "selected_command": item.get("next_command") or "",
            "selected_patch_hygiene_command": item.get("patch_hygiene_command") or "",
            "deterministic_request_id": deterministic_request_id,
            "deterministic_request_key": deterministic_request.get("request_key") or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_classification": deterministic_classification,
            "deterministic_command": deterministic_command,
            "would_change_route": bool(would_change_route),
            "candidate_count": len(items),
            "candidate_keys": candidate_keys,
            "candidate_classifications": candidate_classifications,
            "fallback_reason": fallback_reason,
            "decision_report_ref": decision_plan.get("decision_report_ref") or {},
        }

    if decision_plan.get("consume_allowed"):
        selected_request_id = int(decision_plan.get("llm_request_id") or 0)
        selected_request_key = decision_plan.get("llm_request_key") or ""
        selected_patch_id = int(decision_plan.get("llm_patch_id") or 0)
        selected_classification = decision_plan.get("llm_classification") or ""
        selected_command = decision_plan.get("llm_command") or ""
        matched = {}
        for item in items:
            request = item.get("request") or {}
            if selected_request_id and _request_id(item) != selected_request_id:
                continue
            if selected_request_key and selected_request_key != (request.get("request_key") or ""):
                continue
            if selected_patch_id and _item_patch_id(item) != selected_patch_id:
                continue
            if selected_classification and selected_classification != (item.get("classification") or ""):
                continue
            if selected_command and selected_command not in [
                item.get("next_command") or "",
                item.get("patch_hygiene_command") or "",
            ]:
                continue
            matched = item
            break
        if matched:
            selected = selected_payload(
                True,
                "CONSUMED_LLM_EVIDENCE_RESYNC_ROUTE",
                matched,
                "",
                decision_plan.get("would_change_route"),
            )
            if selected_command:
                selected["selected_command"] = selected_command
            return selected

    if not items:
        return selected_payload(
            False,
            "NO_RESYNC_ACTION_REQUIRED",
            {},
            decision_plan.get("reason") or "evidence resync report has no selected items",
        )

    return selected_payload(
        False,
        "DETERMINISTIC_FALLBACK_NO_LLM_EVIDENCE_RESYNC_CONSUMPTION",
        deterministic_item,
        decision_plan.get("reason") or "missing consumable evidence_resync_route LLM decision report",
    )


def _ready_merge_candidate_command(item):
    patch_id = _item_patch_id(item)
    if not patch_id:
        return ""
    return f"./bin/paperctl merge-queue --patch-id {patch_id} --json"


def _is_ready_merge_candidate(item):
    return bool(
        item.get("patch_exists")
        and item.get("sha256_ok")
        and (item.get("git_apply_check") or {}).get("returncode") == 0
    )


def _candidate_ready_merge_patch_ids(items):
    return [_item_patch_id(item) for item in items if _item_patch_id(item)]


def _candidate_ready_merge_slugs(items):
    slugs = []
    for item in items:
        slug = item.get("slug") or ""
        if slug and slug not in slugs:
            slugs.append(slug)
    return slugs


def _matches_ready_merge_candidate(item, decision_output):
    selected_patch_id = (
        decision_output.get("selected_patch_id")
        or decision_output.get("patch_id")
        or decision_output.get("target_patch_id")
        or ""
    )
    if selected_patch_id:
        try:
            if int(selected_patch_id) != _item_patch_id(item):
                return False
        except Exception:
            return False
    selected_slug = decision_output.get("selected_slug") or decision_output.get("slug") or ""
    if selected_slug and selected_slug != (item.get("slug") or ""):
        return False
    selected_batch_id = (
        decision_output.get("selected_batch_id")
        or decision_output.get("batch_id")
        or decision_output.get("target_batch_id")
        or ""
    )
    if selected_batch_id and selected_batch_id != (item.get("batch_id") or ""):
        return False
    selected_route = (
        decision_output.get("selected_ready_merge_route")
        or decision_output.get("selected_route")
        or decision_output.get("route")
        or decision_output.get("selected_task")
        or decision_output.get("task")
        or ""
    )
    if selected_route and selected_route not in [
        "ready_merge",
        "ready_merge_boundary",
        "merge_plan",
        "merge_queue_plan",
        _ready_merge_candidate_command(item),
    ]:
        return False
    allowed_command = decision_output.get("allowed_command") or ""
    if allowed_command and allowed_command != _ready_merge_candidate_command(item):
        return False
    next_action = decision_output.get("next_action") or decision_output.get("selected_action") or ""
    if next_action and next_action not in [
        "ready_merge",
        "ready_merge_boundary",
        "merge_plan",
        "merge_queue_plan",
        _ready_merge_candidate_command(item),
        item.get("slug") or "",
        item.get("batch_id") or "",
        str(_item_patch_id(item)),
    ]:
        return False
    return bool(selected_patch_id or selected_slug or selected_batch_id or selected_route or allowed_command or next_action)


def _matching_ready_merge_candidate(items, decision_output):
    for item in items:
        if _matches_ready_merge_candidate(item, decision_output):
            return item
    return {}


def ready_merge_boundary_decision_plan(patches, decision_output=None, decision_ref=None, ready_merge_state="", status=""):
    """Return a plan-only view of ready-merge-boundary consumption."""
    patches = [dict(item) for item in patches or []]
    decision_output = dict(decision_output or {})
    decision_ref = dict(decision_ref or {})
    ready_candidates = [item for item in patches if _is_ready_merge_candidate(item)]
    deterministic_item = ready_candidates[0] if ready_candidates else {}
    deterministic_patch_id = _item_patch_id(deterministic_item)
    deterministic_command = _ready_merge_candidate_command(deterministic_item)
    ready_patch_ids = _candidate_ready_merge_patch_ids(ready_candidates)
    inspected_patch_ids = _candidate_ready_merge_patch_ids(patches)
    candidate_slugs = _candidate_ready_merge_slugs(ready_candidates)

    def base(state, reason, **overrides):
        data = {
            "consume_allowed": False,
            "consumption_state": state,
            "reason": reason,
            "ready_merge_state": ready_merge_state or "",
            "ready_merge_status": status or "",
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_slug": deterministic_item.get("slug") or "",
            "deterministic_batch_id": deterministic_item.get("batch_id") or "",
            "deterministic_command": deterministic_command,
            "llm_patch_id": 0,
            "llm_slug": "",
            "llm_batch_id": "",
            "llm_command": "",
            "llm_patch_ready": False,
            "would_change_route": False,
            "candidate_count": len(ready_candidates),
            "inspected_patch_count": len(patches),
            "candidate_patch_ids": ready_patch_ids,
            "inspected_patch_ids": inspected_patch_ids,
            "candidate_slugs": candidate_slugs,
            "decision_report_ref": decision_ref,
        }
        data.update(overrides)
        return data

    if not ready_candidates:
        reason = "ready-merge-set report has no ready checked patch candidates"
        if patches:
            reason = "ready-merge-set patches exist but none pass ready merge checks"
        return base("NO_READY_MERGE_CANDIDATE", reason)
    if not decision_ref:
        return base(
            "NO_LLM_DECISION_REPORT",
            "missing ready_merge_boundary LLM decision report",
            decision_report_ref={},
        )
    decision_ref_issue = _decision_ref_issue_text(decision_ref)
    if decision_ref_issue:
        return base(
            "INVALID_LLM_DECISION_REPORT",
            f"ready_merge_boundary decision report is not valid: {decision_ref_issue}",
        )
    if decision_output.get("decision_point_id") != "ready_merge_boundary":
        return base(
            "INVALID_DECISION_POINT",
            "decision output is not for ready_merge_boundary",
        )
    forbidden_issue = decision_output_forbidden_consumption_issue(decision_output)
    if forbidden_issue:
        return base(
            _forbidden_consumption_state(forbidden_issue),
            forbidden_issue,
        )
    allowed_command_issue = command_safety_issue(decision_output.get("allowed_command") or "")
    if allowed_command_issue:
        return base(
            "ALLOWED_COMMAND_NOT_SAFE_READY_MERGE_BOUNDARY",
            allowed_command_issue,
        )
    if decision_output_requires_human(decision_output):
        return base(
            "HUMAN_REVIEW_REQUIRED",
            "decision output requires human review before ready merge boundary consumption",
        )
    matched = _matching_ready_merge_candidate(patches, decision_output)
    if not matched:
        return base(
            "NO_SELECTABLE_READY_MERGE_CANDIDATE",
            "decision output does not identify a ready merge candidate",
        )
    llm_patch_id = _item_patch_id(matched)
    llm_command = _ready_merge_candidate_command(matched)
    if not _is_ready_merge_candidate(matched):
        return base(
            "SELECTED_PATCH_NOT_READY",
            "decision output identifies a patch that failed ready merge checks",
            llm_patch_id=llm_patch_id,
            llm_slug=matched.get("slug") or "",
            llm_batch_id=matched.get("batch_id") or "",
            llm_command=llm_command,
            llm_patch_ready=False,
        )
    return base(
        "PLAN_ONLY_CONSUMABLE",
        "decision output identifies a ready merge candidate",
        consume_allowed=True,
        llm_patch_id=llm_patch_id,
        llm_slug=matched.get("slug") or "",
        llm_batch_id=matched.get("batch_id") or "",
        llm_command=llm_command,
        llm_patch_ready=True,
        would_change_route=(
            llm_patch_id != deterministic_patch_id
            or (matched.get("slug") or "") != (deterministic_item.get("slug") or "")
            or (matched.get("batch_id") or "") != (deterministic_item.get("batch_id") or "")
            or llm_command != deterministic_command
        ),
    )


def ready_merge_boundary_consuming_selection(patches, decision_plan=None):
    """Select one ready-merge candidate from a validated LLM plan."""
    patches = [dict(item) for item in patches or []]
    decision_plan = dict(decision_plan or {})
    ready_candidates = [item for item in patches if _is_ready_merge_candidate(item)]
    deterministic_item = ready_candidates[0] if ready_candidates else {}
    deterministic_patch_id = _item_patch_id(deterministic_item)
    deterministic_command = _ready_merge_candidate_command(deterministic_item)
    candidate_patch_ids = _candidate_ready_merge_patch_ids(ready_candidates)
    inspected_patch_ids = _candidate_ready_merge_patch_ids(patches)
    candidate_slugs = _candidate_ready_merge_slugs(ready_candidates)

    def selected_payload(decision_consumed, selection_state, item, fallback_reason, would_change_route=False):
        return {
            "decision_consumed": bool(decision_consumed),
            "selection_state": selection_state,
            "plan_state": decision_plan.get("consumption_state") or "",
            "selected_patch_id": _item_patch_id(item),
            "selected_slug": item.get("slug") or "",
            "selected_batch_id": item.get("batch_id") or "",
            "selected_command": _ready_merge_candidate_command(item),
            "deterministic_patch_id": deterministic_patch_id,
            "deterministic_slug": deterministic_item.get("slug") or "",
            "deterministic_batch_id": deterministic_item.get("batch_id") or "",
            "deterministic_command": deterministic_command,
            "would_change_route": bool(would_change_route),
            "candidate_count": len(ready_candidates),
            "inspected_patch_count": len(patches),
            "candidate_patch_ids": candidate_patch_ids,
            "inspected_patch_ids": inspected_patch_ids,
            "candidate_slugs": candidate_slugs,
            "fallback_reason": fallback_reason,
            "decision_report_ref": decision_plan.get("decision_report_ref") or {},
        }

    if decision_plan.get("consume_allowed"):
        selected_patch_id = int(decision_plan.get("llm_patch_id") or 0)
        selected_slug = decision_plan.get("llm_slug") or ""
        selected_batch_id = decision_plan.get("llm_batch_id") or ""
        selected_command = decision_plan.get("llm_command") or ""
        for item in ready_candidates:
            if selected_patch_id and _item_patch_id(item) != selected_patch_id:
                continue
            if selected_slug and selected_slug != (item.get("slug") or ""):
                continue
            if selected_batch_id and selected_batch_id != (item.get("batch_id") or ""):
                continue
            if selected_command and selected_command != _ready_merge_candidate_command(item):
                continue
            return selected_payload(
                True,
                "CONSUMED_LLM_READY_MERGE_BOUNDARY",
                item,
                "",
                decision_plan.get("would_change_route"),
            )

    if not ready_candidates:
        return selected_payload(
            False,
            "NO_READY_MERGE_CANDIDATE",
            {},
            decision_plan.get("reason") or "ready-merge-set report has no ready checked patch candidates",
        )

    return selected_payload(
        False,
        "DETERMINISTIC_FALLBACK_NO_LLM_READY_MERGE_CONSUMPTION",
        deterministic_item,
        decision_plan.get("reason") or "missing consumable ready_merge_boundary LLM decision report",
    )


def _route_id(item):
    return item.get("route_id") or item.get("route") or item.get("task") or ""


def _candidate_route_ids(items):
    route_ids = []
    for item in items:
        route_id = _route_id(item)
        if route_id and route_id not in route_ids:
            route_ids.append(route_id)
    return route_ids


def _candidate_route_slugs(items):
    slugs = []
    for item in items:
        for slug in item.get("slugs") or []:
            if slug and slug not in slugs:
                slugs.append(slug)
        slug = item.get("slug") or ""
        if slug and slug not in slugs:
            slugs.append(slug)
    return slugs


def _matches_post_apply_final_gate_route(item, decision_output):
    selected_route = (
        decision_output.get("selected_final_gate_route")
        or decision_output.get("selected_route")
        or decision_output.get("route")
        or decision_output.get("selected_task")
        or decision_output.get("task")
        or decision_output.get("next_action")
        or decision_output.get("selected_action")
        or ""
    )
    route_id = _route_id(item)
    route_kind = item.get("route_kind") or ""
    if selected_route and selected_route not in [route_id, route_kind, item.get("next_command") or ""]:
        return False
    selected_slug = decision_output.get("selected_slug") or decision_output.get("slug") or ""
    slugs = list(item.get("slugs") or [])
    if selected_slug and selected_slug not in slugs and selected_slug != (item.get("slug") or ""):
        return False
    allowed_command = decision_output.get("allowed_command") or ""
    if allowed_command and allowed_command != (item.get("next_command") or ""):
        return False
    return bool(selected_route or selected_slug or allowed_command)


def _matching_post_apply_final_gate_route(items, decision_output):
    for item in items:
        if _matches_post_apply_final_gate_route(item, decision_output):
            return item
    return {}


def post_apply_final_gate_decision_plan(routes, decision_output=None, decision_ref=None):
    """Return a plan-only view of post-apply-final-gate route consumption."""
    routes = [dict(item) for item in routes or []]
    decision_output = dict(decision_output or {})
    decision_ref = dict(decision_ref or {})
    deterministic_item = routes[0] if routes else {}
    deterministic_route = _route_id(deterministic_item)
    deterministic_command = deterministic_item.get("next_command") or ""
    candidate_route_ids = _candidate_route_ids(routes)
    candidate_slugs = _candidate_route_slugs(routes)

    def base(state, reason, **overrides):
        data = {
            "consume_allowed": False,
            "consumption_state": state,
            "reason": reason,
            "deterministic_route": deterministic_route,
            "deterministic_route_kind": deterministic_item.get("route_kind") or "",
            "deterministic_command": deterministic_command,
            "deterministic_slugs": list(deterministic_item.get("slugs") or []),
            "llm_route": "",
            "llm_route_kind": "",
            "llm_command": "",
            "llm_slugs": [],
            "would_change_route": False,
            "candidate_count": len(routes),
            "candidate_route_ids": candidate_route_ids,
            "candidate_slugs": candidate_slugs,
            "decision_report_ref": decision_ref,
        }
        data.update(overrides)
        return data

    if not routes:
        return base(
            "NO_POST_APPLY_FINAL_GATE_ACTION_REQUIRED",
            "no post-apply final gate route candidates",
        )
    if not decision_ref:
        return base(
            "NO_LLM_DECISION_REPORT",
            "missing post_apply_final_gate_route LLM decision report",
            decision_report_ref={},
        )
    decision_ref_issue = _decision_ref_issue_text(decision_ref)
    if decision_ref_issue:
        return base(
            "INVALID_LLM_DECISION_REPORT",
            f"post_apply_final_gate_route decision report is not valid: {decision_ref_issue}",
        )
    if decision_output.get("decision_point_id") != "post_apply_final_gate_route":
        return base(
            "INVALID_DECISION_POINT",
            "decision output is not for post_apply_final_gate_route",
        )
    forbidden_issue = decision_output_forbidden_consumption_issue(decision_output)
    if forbidden_issue:
        return base(
            _forbidden_consumption_state(forbidden_issue),
            forbidden_issue,
        )
    allowed_command_issue = command_safety_issue(decision_output.get("allowed_command") or "")
    if allowed_command_issue:
        return base(
            "ALLOWED_COMMAND_NOT_SAFE_POST_APPLY_FINAL_GATE_ROUTE",
            allowed_command_issue,
        )
    if decision_output_requires_human(decision_output):
        return base(
            "HUMAN_REVIEW_REQUIRED",
            "decision output requires human review before final-gate route consumption",
        )
    matched = _matching_post_apply_final_gate_route(routes, decision_output)
    if not matched:
        return base(
            "NO_SELECTABLE_POST_APPLY_FINAL_GATE_ROUTE",
            "decision output does not identify a post-apply final gate route",
        )
    llm_route = _route_id(matched)
    llm_command = matched.get("next_command") or ""
    llm_slugs = list(matched.get("slugs") or [])
    return base(
        "PLAN_ONLY_CONSUMABLE",
        "decision output identifies a post-apply final gate route",
        consume_allowed=True,
        llm_route=llm_route,
        llm_route_kind=matched.get("route_kind") or "",
        llm_command=llm_command,
        llm_slugs=llm_slugs,
        would_change_route=(
            llm_route != deterministic_route
            or llm_command != deterministic_command
            or llm_slugs != list(deterministic_item.get("slugs") or [])
        ),
    )


def post_apply_final_gate_consuming_selection(routes, decision_plan=None):
    """Select one post-apply final-gate route from a validated LLM plan."""
    routes = [dict(item) for item in routes or []]
    decision_plan = dict(decision_plan or {})
    deterministic_item = routes[0] if routes else {}
    deterministic_route = _route_id(deterministic_item)
    deterministic_command = deterministic_item.get("next_command") or ""
    deterministic_slugs = list(deterministic_item.get("slugs") or [])
    candidate_route_ids = _candidate_route_ids(routes)
    candidate_slugs = _candidate_route_slugs(routes)

    def selected_payload(decision_consumed, selection_state, item, fallback_reason, would_change_route=False):
        return {
            "decision_consumed": bool(decision_consumed),
            "selection_state": selection_state,
            "plan_state": decision_plan.get("consumption_state") or "",
            "selected_route": _route_id(item),
            "selected_route_kind": item.get("route_kind") or "",
            "selected_slugs": list(item.get("slugs") or []),
            "selected_command": item.get("next_command") or "",
            "deterministic_route": deterministic_route,
            "deterministic_route_kind": deterministic_item.get("route_kind") or "",
            "deterministic_slugs": deterministic_slugs,
            "deterministic_command": deterministic_command,
            "would_change_route": bool(would_change_route),
            "candidate_count": len(routes),
            "candidate_route_ids": candidate_route_ids,
            "candidate_slugs": candidate_slugs,
            "fallback_reason": fallback_reason,
            "decision_report_ref": decision_plan.get("decision_report_ref") or {},
        }

    if decision_plan.get("consume_allowed"):
        selected_route = decision_plan.get("llm_route") or ""
        selected_route_kind = decision_plan.get("llm_route_kind") or ""
        selected_command = decision_plan.get("llm_command") or ""
        selected_slugs = list(decision_plan.get("llm_slugs") or [])
        for item in routes:
            if selected_route and _route_id(item) != selected_route:
                continue
            if selected_route_kind and (item.get("route_kind") or "") != selected_route_kind:
                continue
            if selected_command and (item.get("next_command") or "") != selected_command:
                continue
            if selected_slugs and list(item.get("slugs") or []) != selected_slugs:
                continue
            return selected_payload(
                True,
                "CONSUMED_LLM_POST_APPLY_FINAL_GATE_ROUTE",
                item,
                "",
                decision_plan.get("would_change_route"),
            )

    if not routes:
        return selected_payload(
            False,
            "NO_POST_APPLY_FINAL_GATE_ACTION_REQUIRED",
            {},
            decision_plan.get("reason") or "no post-apply final gate route candidates",
        )

    return selected_payload(
        False,
        "DETERMINISTIC_FALLBACK_NO_LLM_POST_APPLY_FINAL_GATE_CONSUMPTION",
        deterministic_item,
        decision_plan.get("reason") or "missing consumable post_apply_final_gate_route LLM decision report",
    )
