"""Artifact maturity queue for the paper production workflow.

This report turns report-only authoring surfaces into an explicit production
artifact/evidence maturity ledger. It never creates artifacts or performs
external actions.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json


COMMAND = "paper-production-artifact-maturity-queue"
SCHEMA_ID = "paper_factory.paper_production.artifact_maturity_queue.v1"

PASS = "PASS"
FAIL = "FAIL"

READY_STATE = "ARTIFACT_MATURITY_QUEUE_READY"
TARGET_SCOPE_STATE = "BLOCKED_ARTIFACT_MATURITY_TARGET_SCOPE"
SURFACE_STATE = "BLOCKED_ARTIFACT_MATURITY_REQUIRED_SURFACE_MISSING"
ARTIFACT_STATE = "BLOCKED_ARTIFACT_MATURITY_REQUIRED_ARTIFACTS_MISSING"
ACTION_LEAK_STATE = "BLOCKED_ARTIFACT_MATURITY_ACTION_LEAK"
SOURCE_GATE_STATE = "BLOCKED_ARTIFACT_MATURITY_SOURCE_EVIDENCE_GATE"

MATURITY_RANK = {
    "surface_missing": 0,
    "queued": 1,
    "authoring_surface_ready": 2,
    "artifact_present": 3,
    "validated_evidence": 4,
    "settled": 5,
}

REQUIRED_REPORT_KEYS = [
    "paper_production_target_scope_audit",
    "paper_production_runner_execution_contract_authoring_surface_matrix",
    "paper_production_runner_execution_contract_artifact_queue",
    "paper_production_runner_execution_contract_matrix",
    "paper_production_external_lifecycle_predispatch_authoring_surface_matrix",
    "paper_production_submission_action_manifest_prerequisite_surface_matrix",
    "paper_production_submission_evidence_intake_quarantine_workflow_matrix",
    "paper_production_submission_evidence_real_intake_acceptance_gate",
    "paper_production_referee_repair_source_authoring_surface_matrix",
    "paper_production_referee_repair_source_artifact_intake_queue",
    "paper_production_post_action_reconciliation_matrix",
    "paper_production_final_settlement_gate",
    "paper_production_external_lifecycle_readiness_matrix",
]

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "artifact_maturity_queue_state",
    "external_action_authorized",
    "external_action_performed",
    "report_schema",
    "summary",
    "artifact_maturity_queue",
    "upstream_refs",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "target_scope_status",
    "target_scope_state",
    "target_paper_count",
    "target_slug_set_hash",
    "artifact_maturity_queue_ready",
    "queue_record_count",
    "required_queue_record_count",
    "surface_ready_record_count",
    "report_only_ready_record_count",
    "artifact_present_record_count",
    "validated_evidence_record_count",
    "missing_required_artifact_record_count",
    "runner_execution_contract_status",
    "runner_execution_contract_state",
    "runner_execution_contract_ready",
    "runner_execution_contract_current",
    "runner_execution_contract_ready_count",
    "runner_execution_contract_failed_check_count",
    "runner_execution_contract_source_evidence_current",
    "runner_execution_contract_first_gap",
    "total_expected_artifact_count",
    "total_artifact_present_count",
    "total_validated_evidence_count",
    "first_blocking_artifact_stage",
    "action_manifest_source_evidence_gate_required",
    "action_manifest_source_evidence_gate_ready",
    "action_manifest_source_evidence_gate_status",
    "action_manifest_source_evidence_gate_issue_count",
    "source_artifact_intake_expected_count",
    "source_artifact_intake_valid_count",
    "source_artifact_intake_missing_count",
    "typed_evidence_contract_ready",
    "forbidden_action_count",
    "failed_check_count",
    "artifact_maturity_queue_hash",
]


def _created_at() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _summary(report: dict | None) -> dict:
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _as_int(value) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _status(report: dict | None, ref: dict | None = None) -> str:
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or "MISSING"
    )


def _stable_hash(kind: str, payload) -> str:
    encoded = json.dumps(
        {"kind": kind, "payload": payload},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _add_check(checks: list[dict], name: str, ok: bool, detail: str) -> None:
    checks.append(
        {
            "name": name,
            "status": PASS if ok else FAIL,
            "detail": str(detail),
            "blocking": True,
        }
    )


def _target_scope(report: dict | None) -> tuple[bool, str, str, int, str]:
    report = report or {}
    summary = _summary(report)
    status = _status(report)
    state = report.get("target_scope_state") or ""
    count = _as_int(summary.get("target_paper_count"))
    target_hash = str(summary.get("target_slug_set_hash") or "")
    ready = status == PASS and state == "TARGET_SCOPE_RESOLVED" and count > 0 and len(target_hash) == 64
    return ready, status, state, count, target_hash


def _report_present(report: dict | None, ref: dict | None = None) -> bool:
    return bool((ref or {}).get("path") or _status(report, ref) in {PASS, FAIL, "ATTENTION"})


def _forbidden_action(reports: dict) -> int:
    count = 0
    for report in reports.values():
        if not isinstance(report, dict):
            continue
        summary = _summary(report)
        if (
            report.get("external_action_authorized") is True
            or report.get("external_action_performed") is True
            or summary.get("external_action_authorized") is True
            or summary.get("external_action_performed") is True
            or summary.get("external_action_observed") is True
        ):
            count += 1
    return count


def _source_evidence_gate_from_external_lifecycle(summary: dict) -> dict:
    gate_keys = {
        "action_manifest_source_evidence_gate_required",
        "action_manifest_source_evidence_gate_ready",
        "action_manifest_source_evidence_gate_status",
        "action_manifest_source_evidence_gate_issue_count",
    }
    gate_summary_present = any(key in summary for key in gate_keys)
    external_ready = bool(summary.get("external_lifecycle_matrix_ready"))
    stale_ready_report = bool(external_ready and not gate_summary_present)
    required = bool(
        summary.get("action_manifest_source_evidence_gate_required")
        or stale_ready_report
    )
    status = str(summary.get("action_manifest_source_evidence_gate_status") or "")
    issue_count = _as_int(summary.get("action_manifest_source_evidence_gate_issue_count"))
    if stale_ready_report:
        status = "MISSING"
        issue_count = max(issue_count, 1)
    ready = bool(
        not required
        or (
            summary.get("action_manifest_source_evidence_gate_ready") is True
            and status in {PASS, "NOT_REQUIRED"}
        )
    )
    return {
        "required": required,
        "ready": ready,
        "status": status or ("NOT_REQUIRED" if not required else "MISSING"),
        "issue_count": issue_count,
        "source_artifact_intake_expected_count": _as_int(
            summary.get("source_artifact_intake_expected_count")
        ),
        "source_artifact_intake_valid_count": _as_int(
            summary.get("source_artifact_intake_valid_count")
        ),
        "source_artifact_intake_missing_count": _as_int(
            summary.get("source_artifact_intake_missing_count")
        ),
        "typed_evidence_contract_ready": bool(
            summary.get("typed_evidence_contract_ready")
        ),
    }


def _runner_execution_contract_current(report: dict | None) -> dict:
    report = report or {}
    summary = _summary(report)
    status = _status(report)
    state = str(report.get("runner_execution_contract_state") or "")
    ready_count = _as_int(summary.get("production_execution_contract_ready_count"))
    failed_count = _as_int(summary.get("failed_check_count"))
    source_required = bool(summary.get("action_manifest_source_evidence_gate_required"))
    source_status = str(summary.get("action_manifest_source_evidence_gate_status") or "")
    source_expected = _as_int(summary.get("source_artifact_intake_expected_count"))
    source_valid = _as_int(summary.get("source_artifact_intake_valid_count"))
    source_missing = _as_int(summary.get("source_artifact_intake_missing_count"))
    source_current = bool(
        not source_required
        or (
            summary.get("action_manifest_source_evidence_gate_ready") is True
            and source_status in {PASS, "NOT_REQUIRED"}
            and source_expected > 0
            and source_valid == source_expected
            and source_missing == 0
            and summary.get("typed_evidence_contract_ready") is True
        )
    )
    ready = bool(
        status == PASS
        and state == "RUNNER_EXECUTION_CONTRACT_READY"
        and summary.get("production_runner_ready") is True
        and ready_count > 0
        and failed_count == 0
    )
    current = bool(ready and source_current)
    return {
        "status": status,
        "state": state,
        "ready": ready,
        "current": current,
        "ready_count": ready_count,
        "failed_check_count": failed_count,
        "source_evidence_current": source_current,
        "first_gap": str(summary.get("first_contract_gap") or ""),
    }


def _maturity(expected: int, surface_ready: int, artifact_present: int, validated: int, settled: bool = False) -> str:
    if expected <= 0:
        return "queued"
    if settled and validated >= expected:
        return "settled"
    if validated >= expected:
        return "validated_evidence"
    if artifact_present > 0:
        return "artifact_present"
    if surface_ready >= expected:
        return "authoring_surface_ready"
    return "surface_missing"


def _row(
    *,
    stage: str,
    artifact_kind: str,
    expected: int,
    surface_ready: int = 0,
    artifact_present: int = 0,
    validated: int = 0,
    required: bool = True,
    source_command: str = "",
    next_command: str = "",
    blocker: str = "",
    settled: bool = False,
) -> dict:
    expected = max(_as_int(expected), 0)
    surface_ready = max(_as_int(surface_ready), 0)
    artifact_present = max(_as_int(artifact_present), 0)
    validated = max(_as_int(validated), 0)
    maturity = _maturity(expected, surface_ready, artifact_present, validated, settled=settled)
    evidence_complete = bool(expected > 0 and validated >= expected)
    report_only_ready = bool(
        expected > 0
        and surface_ready >= expected
        and artifact_present < expected
        and validated < expected
    )
    missing_required = bool(required and not evidence_complete)
    if not blocker and missing_required:
        blocker = f"{stage}_artifact_or_evidence_missing"
    payload = {
        "stage": stage,
        "artifact_kind": artifact_kind,
        "expected": expected,
        "surface_ready": surface_ready,
        "artifact_present": artifact_present,
        "validated": validated,
        "maturity": maturity,
    }
    return {
        "stage": stage,
        "artifact_kind": artifact_kind,
        "required_for_production": bool(required),
        "source_command": source_command,
        "next_command": next_command,
        "expected_artifact_count": expected,
        "surface_ready_count": surface_ready,
        "artifact_present_count": artifact_present,
        "validated_evidence_count": validated,
        "maturity_level": maturity,
        "maturity_rank": MATURITY_RANK[maturity],
        "report_only_ready_without_artifact": report_only_ready,
        "evidence_complete": evidence_complete,
        "missing_required_artifact": missing_required,
        "first_blocker": blocker,
        "queue_item_hash": _stable_hash("paper_production_artifact_maturity_queue_row", payload),
    }


def build_artifact_maturity_queue(
    reports: dict | None = None,
    upstream_refs: dict | None = None,
    label: str = "",
    created_at: str | None = None,
) -> dict:
    reports = dict(reports or {})
    upstream_refs = dict(upstream_refs or {})
    target_ready, target_status, target_state, target_count, target_hash = _target_scope(
        reports.get("paper_production_target_scope_audit")
    )

    runner_authoring = _summary(
        reports.get("paper_production_runner_execution_contract_authoring_surface_matrix")
    )
    runner_artifacts = _summary(
        reports.get("paper_production_runner_execution_contract_artifact_queue")
    )
    runner_execution_contract = _runner_execution_contract_current(
        reports.get("paper_production_runner_execution_contract_matrix")
    )
    predispatch = _summary(
        reports.get("paper_production_external_lifecycle_predispatch_authoring_surface_matrix")
    )
    action_prereq = _summary(
        reports.get("paper_production_submission_action_manifest_prerequisite_surface_matrix")
    )
    evidence_workflow = _summary(
        reports.get("paper_production_submission_evidence_intake_quarantine_workflow_matrix")
    )
    real_intake = _summary(
        reports.get("paper_production_submission_evidence_real_intake_acceptance_gate")
    )
    source_authoring = _summary(
        reports.get("paper_production_referee_repair_source_authoring_surface_matrix")
    )
    source_artifact_intake = _summary(
        reports.get("paper_production_referee_repair_source_artifact_intake_queue")
    )
    post_action = _summary(
        reports.get("paper_production_post_action_reconciliation_matrix")
    )
    final_settlement = _summary(
        reports.get("paper_production_final_settlement_gate")
    )
    external_lifecycle = _summary(
        reports.get("paper_production_external_lifecycle_readiness_matrix")
    )
    source_evidence_gate = _source_evidence_gate_from_external_lifecycle(
        external_lifecycle
    )
    source_gate_required = bool(source_evidence_gate.get("required"))
    source_gate_ready = bool(source_evidence_gate.get("ready"))

    scoped_count = target_count or _as_int(external_lifecycle.get("target_paper_count")) or 1
    source_record_count = _as_int(source_authoring.get("source_authoring_surface_record_count"))
    prereq_record_count = _as_int(action_prereq.get("prerequisite_record_count")) or scoped_count
    post_paper_count = _as_int(post_action.get("paper_count")) or scoped_count

    rows = [
        _row(
            stage="runner_execution_contracts",
            artifact_kind="runner_contract_file_or_live_adapter_contract",
            expected=(
                _as_int(runner_artifacts.get("expected_contract_count"))
                or _as_int(runner_authoring.get("authoring_surface_record_count"))
            ),
            surface_ready=_as_int(runner_authoring.get("authoring_surface_ready_count")),
            artifact_present=_as_int(runner_artifacts.get("contract_artifact_present_count")),
            validated=(
                runner_execution_contract["ready_count"]
                if runner_execution_contract["current"]
                else 0
            ),
            source_command="paper-production-runner-execution-contract-authoring-surface-matrix",
            next_command="paper-production-runner-execution-contract-artifact-queue",
            blocker=(
                ""
                if runner_execution_contract["current"]
                else "runner_execution_contract_matrix_not_current"
            ),
        ),
        _row(
            stage="referee_repair_source_packets",
            artifact_kind="real_source_packet",
            expected=source_record_count,
            surface_ready=_as_int(source_authoring.get("source_packet_authoring_ready_count")),
            artifact_present=_as_int(source_artifact_intake.get("source_packet_present_count")),
            validated=_as_int(source_artifact_intake.get("source_packet_valid_count")),
            source_command="paper-production-referee-repair-source-authoring-surface-matrix",
            next_command="paper-production-referee-repair-source-artifact-intake-queue",
        ),
        _row(
            stage="referee_repair_operator_intake_packets",
            artifact_kind="operator_real_source_intake_packet",
            expected=source_record_count,
            surface_ready=_as_int(source_authoring.get("operator_intake_authoring_ready_count")),
            artifact_present=_as_int(source_artifact_intake.get("operator_intake_packet_present_count")),
            validated=_as_int(source_artifact_intake.get("operator_intake_packet_valid_count")),
            source_command="paper-production-referee-repair-source-authoring-surface-matrix",
            next_command="paper-production-referee-repair-source-artifact-intake-queue",
        ),
        _row(
            stage="referee_repair_redrive_receipts",
            artifact_kind="redrive_execution_receipt",
            expected=source_record_count,
            surface_ready=_as_int(source_authoring.get("redrive_receipt_quarantine_ready_count")),
            artifact_present=_as_int(source_artifact_intake.get("redrive_receipt_present_count")),
            validated=_as_int(source_artifact_intake.get("redrive_receipt_valid_count")),
            source_command="paper-production-referee-repair-source-authoring-surface-matrix",
            next_command="paper-production-referee-repair-source-artifact-intake-queue",
        ),
        _row(
            stage="action_manifest_source_evidence_gate",
            artifact_kind="hash_bound_action_manifest_source_evidence_gate",
            expected=1 if source_gate_required else 0,
            surface_ready=1 if source_gate_required else 0,
            artifact_present=1
            if source_gate_required
            and _as_int(source_evidence_gate.get("source_artifact_intake_expected_count")) > 0
            else 0,
            validated=1 if source_gate_required and source_gate_ready else 0,
            required=source_gate_required,
            source_command="paper-production-external-lifecycle-readiness-matrix",
            next_command="paper-production-submission-action-manifest",
            blocker=(
                "action_manifest_source_evidence_gate_not_ready"
                if source_gate_required and not source_gate_ready
                else ""
            ),
        ),
        _row(
            stage="reviewed_operator_venue_input_files",
            artifact_kind="real_reviewed_approval_and_fresh_evidence_input_files",
            expected=_as_int(real_intake.get("operator_input_file_expected_count")),
            surface_ready=_as_int(real_intake.get("operator_packet_expected_file_count"))
            if real_intake.get("operator_packet_ready")
            else 0,
            artifact_present=_as_int(real_intake.get("operator_input_file_nonempty_count")),
            validated=_as_int(real_intake.get("operator_input_file_nonempty_count"))
            if real_intake.get("operator_input_files_ready")
            else 0,
            source_command="paper-production-submission-evidence-real-intake-acceptance-gate",
            next_command="paper-production-remaining-input-autopilot",
        ),
        _row(
            stage="approval_and_fresh_evidence_hashes",
            artifact_kind="approval_hash_and_fresh_evidence_hash",
            expected=2 * prereq_record_count,
            surface_ready=(
                _as_int(action_prereq.get("approval_template_ready_count"))
                + _as_int(action_prereq.get("fresh_evidence_template_ready_count"))
            ),
            artifact_present=(
                _as_int(evidence_workflow.get("approval_hash_present_count"))
                + _as_int(evidence_workflow.get("fresh_evidence_hash_present_count"))
            ),
            validated=(
                _as_int(real_intake.get("approval_hash_present_count"))
                + _as_int(real_intake.get("fresh_evidence_hash_present_count"))
            ),
            source_command="paper-production-submission-evidence-intake-quarantine-workflow-matrix",
            next_command="paper-production-submission-action-manifest-prerequisite-surface-matrix",
        ),
        _row(
            stage="submission_action_manifest",
            artifact_kind="valid_submission_action_manifest",
            expected=prereq_record_count,
            surface_ready=_as_int(action_prereq.get("prerequisite_surface_ready_count")),
            artifact_present=_as_int(action_prereq.get("action_manifest_valid_count")),
            validated=_as_int(external_lifecycle.get("valid_manifest_count")),
            source_command="paper-production-submission-action-manifest-prerequisite-surface-matrix",
            next_command="paper-production-submission-action-manifest",
        ),
        _row(
            stage="submission_replay_guard",
            artifact_kind="dispatch_allowed_replay_guard",
            expected=scoped_count,
            surface_ready=scoped_count if predispatch.get("replay_guard_authoring_ready") else 0,
            artifact_present=_as_int(predispatch.get("dispatch_allowed_count")),
            validated=_as_int(external_lifecycle.get("dispatch_allowed_count")),
            source_command="paper-production-external-lifecycle-predispatch-authoring-surface-matrix",
            next_command="paper-production-submission-replay-guard",
        ),
        _row(
            stage="dispatch_authorization",
            artifact_kind="valid_dispatch_authorization",
            expected=scoped_count,
            surface_ready=scoped_count if predispatch.get("dispatch_authorization_authoring_ready") else 0,
            artifact_present=_as_int(predispatch.get("valid_dispatch_authorization_count")),
            validated=_as_int(external_lifecycle.get("valid_dispatch_authorization_count")),
            source_command="paper-production-external-lifecycle-predispatch-authoring-surface-matrix",
            next_command="paper-production-submission-dispatch-authorization",
        ),
        _row(
            stage="handoff_outbox",
            artifact_kind="external_executor_handoff_outbox_entry",
            expected=scoped_count,
            surface_ready=scoped_count if predispatch.get("handoff_outbox_authoring_ready") else 0,
            artifact_present=_as_int(predispatch.get("outbox_entry_count")),
            validated=_as_int(external_lifecycle.get("outbox_entry_count")),
            source_command="paper-production-external-lifecycle-predispatch-authoring-surface-matrix",
            next_command="paper-production-external-executor-handoff-outbox",
        ),
        _row(
            stage="executor_response",
            artifact_kind="valid_executor_response",
            expected=post_paper_count,
            surface_ready=post_paper_count if reports.get("paper_production_post_action_reconciliation_matrix") else 0,
            artifact_present=_as_int(post_action.get("valid_executor_response_count")),
            validated=_as_int(external_lifecycle.get("valid_executor_response_count")),
            source_command="paper-production-post-action-reconciliation-matrix",
            next_command="paper-production-executor-response-intake",
        ),
        _row(
            stage="submission_receipt",
            artifact_kind="valid_external_submission_receipt",
            expected=post_paper_count,
            surface_ready=post_paper_count if reports.get("paper_production_post_action_reconciliation_matrix") else 0,
            artifact_present=_as_int(post_action.get("valid_receipt_count")),
            validated=_as_int(external_lifecycle.get("valid_receipt_count")),
            source_command="paper-production-post-action-reconciliation-matrix",
            next_command="paper-production-external-submission-receipt",
        ),
        _row(
            stage="venue_state_proof",
            artifact_kind="valid_venue_state_proof",
            expected=post_paper_count,
            surface_ready=post_paper_count if reports.get("paper_production_post_action_reconciliation_matrix") else 0,
            artifact_present=_as_int(post_action.get("valid_state_proof_count")),
            validated=_as_int(external_lifecycle.get("valid_state_proof_count")),
            source_command="paper-production-post-action-reconciliation-matrix",
            next_command="paper-production-venue-state-proof",
        ),
        _row(
            stage="submission_audit_archive",
            artifact_kind="complete_submission_audit_archive",
            expected=post_paper_count,
            surface_ready=post_paper_count if reports.get("paper_production_post_action_reconciliation_matrix") else 0,
            artifact_present=_as_int(post_action.get("complete_archive_count")),
            validated=_as_int(external_lifecycle.get("complete_archive_count")),
            source_command="paper-production-post-action-reconciliation-matrix",
            next_command="paper-production-submission-audit-archive",
        ),
        _row(
            stage="executor_dispatch_cycle",
            artifact_kind="complete_executor_dispatch_cycle_audit",
            expected=post_paper_count,
            surface_ready=post_paper_count if reports.get("paper_production_post_action_reconciliation_matrix") else 0,
            artifact_present=_as_int(post_action.get("complete_cycle_count")),
            validated=_as_int(external_lifecycle.get("complete_cycle_count")),
            source_command="paper-production-post-action-reconciliation-matrix",
            next_command="paper-production-executor-dispatch-cycle-audit",
        ),
        _row(
            stage="post_action_reconciliation",
            artifact_kind="post_action_reconciliation_record",
            expected=post_paper_count,
            surface_ready=post_paper_count if reports.get("paper_production_post_action_reconciliation_matrix") else 0,
            artifact_present=_as_int(post_action.get("reconciliation_count")),
            validated=_as_int(external_lifecycle.get("reconciliation_count")),
            source_command="paper-production-post-action-reconciliation-matrix",
            next_command="paper-production-final-settlement-gate",
        ),
        _row(
            stage="final_settlement",
            artifact_kind="final_settlement_record",
            expected=_as_int(final_settlement.get("paper_count")) or post_paper_count,
            surface_ready=_as_int(final_settlement.get("paper_count")) or post_paper_count,
            artifact_present=_as_int(final_settlement.get("final_settlement_count")),
            validated=_as_int(final_settlement.get("final_settlement_count")),
            source_command="paper-production-final-settlement-gate",
            next_command="paper-production-local-closeout-capstone",
            settled=bool(final_settlement.get("final_settlement_ready")),
        ),
    ]

    required_rows = [row for row in rows if row.get("required_for_production")]
    missing_required = [row for row in required_rows if row.get("missing_required_artifact")]
    report_only_rows = [row for row in rows if row.get("report_only_ready_without_artifact")]
    artifact_rows = [row for row in rows if row.get("artifact_present_count", 0) >= row.get("expected_artifact_count", 0) and row.get("expected_artifact_count", 0) > 0]
    validated_rows = [row for row in rows if row.get("evidence_complete")]
    missing_reports = [
        key
        for key in REQUIRED_REPORT_KEYS
        if not _report_present(reports.get(key), upstream_refs.get(key))
    ]
    forbidden_count = _forbidden_action(reports)
    queue_ready = bool(target_ready and not missing_reports and not missing_required and forbidden_count == 0)
    checks: list[dict] = []
    _add_check(
        checks,
        "target_scope_resolved",
        target_ready,
        f"status={target_status} state={target_state or '-'} papers={target_count}",
    )
    _add_check(
        checks,
        "required_maturity_source_reports_present",
        not missing_reports,
        ",".join(missing_reports) or "-",
    )
    _add_check(
        checks,
        "required_artifacts_and_evidence_mature",
        not missing_required,
        f"missing={len(missing_required)} first={(missing_required[0].get('stage') if missing_required else '-')}",
    )
    _add_check(
        checks,
        "action_manifest_source_evidence_gate_ready",
        not source_gate_required or source_gate_ready,
        (
            f"required={source_gate_required} ready={source_gate_ready} "
            f"status={source_evidence_gate.get('status')}"
        ),
    )
    _add_check(
        checks,
        "runner_execution_contract_current",
        runner_execution_contract["current"],
        (
            f"status={runner_execution_contract['status']} "
            f"state={runner_execution_contract['state'] or '-'} "
            f"ready={runner_execution_contract['ready']} "
            f"source_current={runner_execution_contract['source_evidence_current']} "
            f"ready_count={runner_execution_contract['ready_count']} "
            f"failed={runner_execution_contract['failed_check_count']}"
        ),
    )
    _add_check(
        checks,
        "no_external_action_or_artifact_leak",
        forbidden_count == 0,
        f"forbidden={forbidden_count}",
    )
    failed = [check for check in checks if check.get("status") != PASS]
    if forbidden_count:
        state = ACTION_LEAK_STATE
    elif not target_ready:
        state = TARGET_SCOPE_STATE
    elif missing_reports:
        state = SURFACE_STATE
    elif source_gate_required and not source_gate_ready:
        state = SOURCE_GATE_STATE
    elif missing_required:
        state = ARTIFACT_STATE
    else:
        state = READY_STATE
    queue_hash = _stable_hash(
        "paper_production_artifact_maturity_queue",
        [
            {
                "stage": row.get("stage"),
                "maturity": row.get("maturity_level"),
                "expected": row.get("expected_artifact_count"),
                "present": row.get("artifact_present_count"),
                "validated": row.get("validated_evidence_count"),
            }
            for row in rows
        ],
    )
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": PASS if queue_ready and not failed else FAIL,
        "label": label or (reports.get("paper_production_target_scope_audit") or {}).get("label") or "",
        "created_at": created_at or _created_at(),
        "artifact_maturity_queue_state": state,
        "external_action_authorized": False,
        "external_action_performed": False,
        "summary": {
            "target_scope_status": target_status,
            "target_scope_state": target_state,
            "target_paper_count": target_count,
            "target_slug_set_hash": target_hash,
            "artifact_maturity_queue_ready": queue_ready,
            "queue_record_count": len(rows),
            "required_queue_record_count": len(required_rows),
            "surface_ready_record_count": sum(
                1
                for row in rows
                if row.get("surface_ready_count", 0) >= row.get("expected_artifact_count", 0)
                and row.get("expected_artifact_count", 0) > 0
            ),
            "report_only_ready_record_count": len(report_only_rows),
            "artifact_present_record_count": len(artifact_rows),
            "validated_evidence_record_count": len(validated_rows),
            "missing_required_artifact_record_count": len(missing_required),
            "runner_execution_contract_status": runner_execution_contract["status"],
            "runner_execution_contract_state": runner_execution_contract["state"],
            "runner_execution_contract_ready": runner_execution_contract["ready"],
            "runner_execution_contract_current": runner_execution_contract["current"],
            "runner_execution_contract_ready_count": runner_execution_contract["ready_count"],
            "runner_execution_contract_failed_check_count": runner_execution_contract[
                "failed_check_count"
            ],
            "runner_execution_contract_source_evidence_current": runner_execution_contract[
                "source_evidence_current"
            ],
            "runner_execution_contract_first_gap": runner_execution_contract["first_gap"],
            "total_expected_artifact_count": sum(row.get("expected_artifact_count", 0) for row in required_rows),
            "total_artifact_present_count": sum(row.get("artifact_present_count", 0) for row in required_rows),
            "total_validated_evidence_count": sum(row.get("validated_evidence_count", 0) for row in required_rows),
            "first_blocking_artifact_stage": missing_required[0].get("stage") if missing_required else "",
            "action_manifest_source_evidence_gate_required": source_gate_required,
            "action_manifest_source_evidence_gate_ready": source_gate_ready,
            "action_manifest_source_evidence_gate_status": (
                source_evidence_gate.get("status") or ""
            ),
            "action_manifest_source_evidence_gate_issue_count": _as_int(
                source_evidence_gate.get("issue_count")
            ),
            "source_artifact_intake_expected_count": _as_int(
                source_evidence_gate.get("source_artifact_intake_expected_count")
            ),
            "source_artifact_intake_valid_count": _as_int(
                source_evidence_gate.get("source_artifact_intake_valid_count")
            ),
            "source_artifact_intake_missing_count": _as_int(
                source_evidence_gate.get("source_artifact_intake_missing_count")
            ),
            "typed_evidence_contract_ready": bool(
                source_evidence_gate.get("typed_evidence_contract_ready")
            ),
            "forbidden_action_count": forbidden_count,
            "failed_check_count": len(failed),
            "artifact_maturity_queue_hash": queue_hash,
        },
        "artifact_maturity_queue": rows,
        "upstream_refs": upstream_refs,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This queue distinguishes authoring-surface readiness from real artifact/evidence maturity.",
            "PASS requires every required production artifact/evidence stage to be mature; report-only authoring surfaces alone are not sufficient.",
            "This command never creates approval/fresh evidence, source packets, contracts, action manifests, outbox entries, receipts, archives, reconciliation records, settlement, uploads, emails, portal submissions, or external actions.",
        ],
    }


def markdown(report: dict) -> str:
    summary = report.get("summary") or {}
    lines = [
        "# paper_factory Artifact Maturity Queue",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('artifact_maturity_queue_state', '')}",
        f"- Ready: {summary.get('artifact_maturity_queue_ready')}",
        f"- Missing required stages: {summary.get('missing_required_artifact_record_count', 0)}",
        f"- First blocker: {summary.get('first_blocking_artifact_stage') or '-'}",
        "",
        "## Queue",
        "",
        "| stage | kind | expected | surface | present | validated | maturity | report-only |",
        "| --- | --- | ---: | ---: | ---: | ---: | --- | ---: |",
    ]
    for row in report.get("artifact_maturity_queue") or []:
        lines.append(
            f"| {row.get('stage', '')} | {row.get('artifact_kind', '')} | "
            f"{row.get('expected_artifact_count', 0)} | "
            f"{row.get('surface_ready_count', 0)} | "
            f"{row.get('artifact_present_count', 0)} | "
            f"{row.get('validated_evidence_count', 0)} | "
            f"{row.get('maturity_level', '')} | "
            f"{row.get('report_only_ready_without_artifact', False)} |"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
