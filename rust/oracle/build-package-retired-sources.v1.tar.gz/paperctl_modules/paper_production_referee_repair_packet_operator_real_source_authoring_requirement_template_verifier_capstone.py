"""Operator real-source authoring requirement template verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-authoring-"
    "requirement-template-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_authoring_requirement_template_verifier_capstone.v1"
)
SOURCE_REFERENCE_INTAKE_ENVELOPE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_source_material_reference_intake_envelope.v1"
)
RECEIPT_AUTH_REQUEST_ENVELOPE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_redrive_receipt_authoring_authorization_request_envelope.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_authoring_requirement_template_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_authoring_requirement_template_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count",
    "operator_real_source_authoring_requirement_template_record_count",
    "hash_bound_operator_real_source_authoring_requirement_template_count",
    "operator_real_source_authoring_requirement_template_lint_ready_count",
    "upstream_evidence_lint_hash_receipt_auth_ready_count",
    "upstream_evidence_lint_hash_receipt_auth_blocked_count",
    "operator_field_authoring_requirement_count",
    "operator_field_authoring_requirement_template_verified_count",
    "operator_field_authoring_evidence_present_count",
    "operator_field_authoring_requirement_missing_count",
    "source_material_reference_intake_envelope_template_record_count",
    "source_material_reference_intake_envelope_template_verified_count",
    "source_material_reference_intake_envelope_present_count",
    "source_material_reference_intake_envelope_missing_count",
    "source_material_reference_intake_envelope_valid_count",
    "source_material_reference_intake_envelope_invalid_count",
    "source_material_reference_sha256_declared_count",
    "source_material_reference_sha256_verified_count",
    "source_material_reference_hash_binding_ready_count",
    "source_material_reference_hash_binding_unbound_count",
    "receipt_authorization_envelope_template_record_count",
    "receipt_authorization_envelope_template_verified_count",
    "receipt_authorization_envelope_present_count",
    "receipt_authorization_envelope_missing_count",
    "receipt_authorization_envelope_valid_count",
    "receipt_authorization_envelope_invalid_count",
    "receipt_authorization_envelope_ready_count",
    "receipt_authorization_envelope_quarantined_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_authoring_requirement_template_record_count",
    "request_operator_real_source_authoring_requirement_template_ready_count",
    "request_operator_real_source_authoring_requirement_template_blocked_count",
    "proof_status_operator_real_source_authoring_requirement_required_count",
    "proof_status_operator_real_source_authoring_requirement_ready_count",
    "evidence_manifest_operator_real_source_authoring_requirement_required_count",
    "evidence_manifest_operator_real_source_authoring_requirement_ready_count",
    "appendix_supplement_operator_real_source_authoring_requirement_required_count",
    "appendix_supplement_operator_real_source_authoring_requirement_ready_count",
    "claim_downgrade_operator_real_source_authoring_requirement_required_count",
    "claim_downgrade_operator_real_source_authoring_requirement_ready_count",
    "referee_rejudge_operator_real_source_authoring_requirement_required_count",
    "referee_rejudge_operator_real_source_authoring_requirement_ready_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_authoring_requirement_template_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def expected_source_material_reference_intake_envelope_path(record):
    intake_path = (record or {}).get("expected_operator_real_source_intake_path") or ""
    packet_path = (record or {}).get("expected_packet_path") or ""
    if intake_path.endswith(".operator-real-source-intake.json"):
        return (
            intake_path[: -len(".operator-real-source-intake.json")]
            + ".source-material-reference-intake.json"
        )
    if packet_path.endswith(".json"):
        return packet_path[:-5] + ".source-material-reference-intake.json"
    return packet_path + ".source-material-reference-intake.json" if packet_path else ""


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _field_authoring_requirement_records(record, payload_sha):
    records = []
    for field in record.get("operator_evidence_packet_field_lint_records") or []:
        field = dict(field or {})
        required = bool(field.get("required"))
        template_verified = bool(
            field.get("template_spec_verified")
            and field.get("name")
            and field.get("operator_evidence_packet_field_lint_payload_sha256")
            or field.get("template_spec_verified")
        )
        evidence_present = bool(field.get("operator_evidence_packet_field_lint_ready"))
        payload = {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_field_authoring_requirement.v1"
            ),
            "operator_real_source_authoring_requirement_template_payload_sha256": payload_sha,
            "field": field.get("name") or "",
            "required": required,
        }
        field_sha = _sha(payload)
        records.append(
            {
                "operator_field_authoring_requirement_id": (
                    f"operator-real-source-field-authoring-req-{field_sha[:16]}"
                ),
                "operator_field_authoring_requirement_payload_sha256": field_sha,
                "name": field.get("name") or "",
                "required": required,
                "template_spec_verified": template_verified,
                "operator_field_authoring_evidence_present": evidence_present,
                "operator_field_authoring_requirement_missing": bool(
                    required and not evidence_present
                ),
                "detail": field.get("detail"),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_reference_envelope_template(record, payload_sha):
    path = expected_source_material_reference_intake_envelope_path(record)
    source_audit = dict(record.get("source_material_reference_file_audit") or {})
    required_fields = [
        "schema_id",
        "request_id",
        "slug",
        "packet_type",
        "expected_packet_path",
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256",
        "source_material_reference",
        "request_specific_source_sha256",
        "explicit_source_material_reference_intake",
    ]
    template_verified = bool(
        path
        and record.get("request_id") is not None
        and record.get("slug")
        and record.get("packet_type")
        and record.get("expected_packet_path")
        and record.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256"
        )
    )
    present = bool(record.get("source_material_reference_file_present"))
    sha_declared = bool(record.get("source_material_reference_sha256_declared"))
    sha_verified = bool(record.get("source_material_reference_sha256_verified"))
    hash_binding = bool(record.get("source_material_reference_hash_binding_ready"))
    valid = bool(present and sha_declared and sha_verified and hash_binding)
    return {
        "schema_id": SOURCE_REFERENCE_INTAKE_ENVELOPE_SCHEMA_ID,
        "source_material_reference_intake_envelope_template_id": (
            f"referee-repair-source-reference-intake-template-{payload_sha[:16]}"
        ),
        "expected_source_material_reference_intake_envelope_path": path,
        "required_template_fields": required_fields,
        "required_template_field_count": len(required_fields),
        "source_material_reference_intake_envelope_template_verified": template_verified,
        "source_material_reference_intake_envelope_present": present,
        "source_material_reference_intake_envelope_missing": not present,
        "source_material_reference_intake_envelope_valid": valid,
        "source_material_reference_intake_envelope_invalid": not valid,
        "source_material_reference": source_audit.get("source_material_reference") or "",
        "source_material_reference_sha256_declared": sha_declared,
        "source_material_reference_sha256_verified": sha_verified,
        "source_material_reference_hash_binding_ready": hash_binding,
        "source_material_reference_hash_binding_unbound": not hash_binding,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_authorization_envelope_template(record, payload_sha):
    envelope = dict(record.get("redrive_receipt_authorization_request_envelope") or {})
    expected_path = (
        envelope.get("expected_redrive_receipt_authorization_request_envelope_path")
        or ""
    )
    required_fields = [
        "schema_id",
        "request_id",
        "slug",
        "packet_type",
        "expected_redrive_execution_receipt_path",
        "operator_real_source_intake_acceptance_preflight_payload_sha256",
        "explicit_redrive_receipt_authorization_request",
        "redrive_receipt_authoring_authorization_performed",
    ]
    template_verified = bool(
        expected_path
        and record.get("request_id") is not None
        and record.get("slug")
        and record.get("packet_type")
        and record.get("expected_redrive_execution_receipt_path")
        and record.get("operator_real_source_intake_acceptance_preflight_payload_sha256")
    )
    present = bool(record.get("redrive_receipt_authorization_request_envelope_present"))
    valid = bool(record.get("redrive_receipt_authorization_request_envelope_valid"))
    ready = bool(record.get("redrive_receipt_authorization_request_envelope_ready"))
    performed = bool(record.get("redrive_receipt_authorization_performed"))
    return {
        "schema_id": RECEIPT_AUTH_REQUEST_ENVELOPE_SCHEMA_ID,
        "receipt_authorization_envelope_template_id": (
            f"referee-repair-receipt-auth-envelope-template-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_envelope_path": expected_path,
        "required_template_fields": required_fields,
        "required_template_field_count": len(required_fields),
        "receipt_authorization_envelope_template_verified": template_verified,
        "receipt_authorization_envelope_present": present,
        "receipt_authorization_envelope_missing": not present,
        "receipt_authorization_envelope_valid": valid,
        "receipt_authorization_envelope_invalid": not valid,
        "receipt_authorization_envelope_ready": ready,
        "receipt_authorization_envelope_quarantined": not ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
    }


def _template_record(upstream_record):
    upstream_record = dict(upstream_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_authoring_requirement_template_record.v1"
        ),
        "request_id": upstream_record.get("request_id"),
        "slug": upstream_record.get("slug") or "",
        "packet_type": upstream_record.get("packet_type") or "",
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256": (
            upstream_record.get(
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    hash_bound = bool(
        payload_sha
        and upstream_record.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and upstream_record.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready"
        )
        and upstream_record.get("request_id") is not None
        and upstream_record.get("slug")
        and upstream_record.get("packet_type")
        and upstream_record.get("expected_packet_path")
        and upstream_record.get("expected_redrive_execution_receipt_path")
    )
    field_records = _field_authoring_requirement_records(upstream_record, payload_sha)
    field_required = sum(1 for item in field_records if item.get("required"))
    field_template_verified = sum(
        1
        for item in field_records
        if item.get("required") and item.get("template_spec_verified")
    )
    field_present = sum(
        1
        for item in field_records
        if item.get("required") and item.get("operator_field_authoring_evidence_present")
    )
    source_template = _source_reference_envelope_template(upstream_record, payload_sha)
    receipt_template = _receipt_authorization_envelope_template(
        upstream_record, payload_sha
    )
    expected_file_creation = bool(
        upstream_record.get("expected_packet_file_creation_performed")
    )
    receipt_creation = bool(upstream_record.get("redrive_receipt_creation_performed"))
    evidence_release = bool(upstream_record.get("evidence_release_performed"))
    promoted = bool(upstream_record.get("repair_evidence_promoted"))
    closure = bool(upstream_record.get("request_closure_performed"))
    auth_performed = bool(receipt_template.get("receipt_authorization_performed"))
    consumable = bool(
        upstream_record.get("consumable_as_repair_evidence")
        or upstream_record.get("consumable_as_release_evidence")
        or upstream_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or auth_performed
        or evidence_release
        or promoted
        or closure
    )
    ready = bool(
        hash_bound
        and lint_ready
        and upstream_record.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready"
        )
        and field_present == field_required
        and source_template.get("source_material_reference_intake_envelope_valid")
        and receipt_template.get("receipt_authorization_envelope_ready")
        and not consumable
    )
    issues = []
    if field_present != field_required:
        issues.append("operator_field_authoring_requirements_unsatisfied")
    if not source_template.get("source_material_reference_intake_envelope_present"):
        issues.append("source_material_reference_intake_envelope_missing")
    if (
        source_template.get("source_material_reference_intake_envelope_present")
        and not source_template.get("source_material_reference_intake_envelope_valid")
    ):
        issues.append("source_material_reference_intake_envelope_invalid")
    if not source_template.get("source_material_reference_hash_binding_ready"):
        issues.append("source_material_reference_hash_unbound")
    if not receipt_template.get("receipt_authorization_envelope_present"):
        issues.append("receipt_authorization_envelope_missing")
    if (
        receipt_template.get("receipt_authorization_envelope_present")
        and not receipt_template.get("receipt_authorization_envelope_valid")
    ):
        issues.append("receipt_authorization_envelope_invalid")
    if not receipt_template.get("receipt_authorization_envelope_ready"):
        issues.append("receipt_authorization_envelope_quarantined")
    if consumable:
        issues.append("operator_real_source_authoring_template_action_or_evidence_leak")
    return {
        "request_id": upstream_record.get("request_id"),
        "slug": upstream_record.get("slug") or "",
        "packet_type": upstream_record.get("packet_type") or "",
        "operator_real_source_authoring_requirement_template_id": (
            f"referee-repair-operator-real-source-authoring-template-{upstream_record.get('request_id')}-{upstream_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_authoring_requirement_template_payload_sha256": payload_sha,
        "operator_real_source_authoring_requirement_template_hash_bound": hash_bound,
        "operator_real_source_authoring_requirement_template_lint_ready": lint_ready,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256": (
            upstream_record.get(
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256"
            )
            or ""
        ),
        "expected_packet_path": upstream_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            upstream_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "expected_operator_real_source_intake_path": (
            upstream_record.get("expected_operator_real_source_intake_path") or ""
        ),
        "required_packet_schema_id": upstream_record.get("required_packet_schema_id")
        or "",
        "operator_field_authoring_requirement_records": field_records,
        "operator_field_authoring_requirement_count": field_required,
        "operator_field_authoring_requirement_template_verified_count": field_template_verified,
        "operator_field_authoring_evidence_present_count": field_present,
        "operator_field_authoring_requirement_missing_count": field_required
        - field_present,
        "source_material_reference_intake_envelope_template": source_template,
        "source_material_reference_intake_envelope_template_verified": source_template[
            "source_material_reference_intake_envelope_template_verified"
        ],
        "source_material_reference_intake_envelope_present": source_template[
            "source_material_reference_intake_envelope_present"
        ],
        "source_material_reference_intake_envelope_valid": source_template[
            "source_material_reference_intake_envelope_valid"
        ],
        "source_material_reference_sha256_declared": source_template[
            "source_material_reference_sha256_declared"
        ],
        "source_material_reference_sha256_verified": source_template[
            "source_material_reference_sha256_verified"
        ],
        "source_material_reference_hash_binding_ready": source_template[
            "source_material_reference_hash_binding_ready"
        ],
        "receipt_authorization_envelope_template": receipt_template,
        "receipt_authorization_envelope_template_verified": receipt_template[
            "receipt_authorization_envelope_template_verified"
        ],
        "receipt_authorization_envelope_present": receipt_template[
            "receipt_authorization_envelope_present"
        ],
        "receipt_authorization_envelope_valid": receipt_template[
            "receipt_authorization_envelope_valid"
        ],
        "receipt_authorization_envelope_ready": receipt_template[
            "receipt_authorization_envelope_ready"
        ],
        "receipt_authorization_envelope_quarantined": receipt_template[
            "receipt_authorization_envelope_quarantined"
        ],
        "receipt_authorization_performed": auth_performed,
        "operator_real_source_authoring_requirement_template_ready": ready,
        "operator_real_source_authoring_requirement_template_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "operator real-source authoring templates are ready for downstream human input; do not create source, receipt, or closure here"
            if ready
            else "complete operator field authoring requirements, source-material reference intake envelope, and receipt authorization envelope template inputs"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, template_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in template_records
        if not item.get("operator_real_source_authoring_requirement_template_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_authoring_requirement_template_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_authoring_requirement_template_payload_sha256s": [
            item.get("operator_real_source_authoring_requirement_template_payload_sha256")
            for item in template_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(template_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_authoring_requirement_template_id": (
            f"referee-repair-request-operator-real-source-authoring-template-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_authoring_requirement_template_payload_sha256": payload_sha,
        "request_operator_real_source_authoring_requirement_template_hash_bound": bool(
            payload_sha
            and all(
                item.get("operator_real_source_authoring_requirement_template_hash_bound")
                for item in template_records
            )
        ),
        "request_operator_real_source_authoring_requirement_template_lint_ready": bool(
            payload_sha
            and all(
                item.get("operator_real_source_authoring_requirement_template_lint_ready")
                for item in template_records
            )
        ),
        "operator_real_source_authoring_requirement_template_record_count": len(
            template_records
        ),
        "operator_real_source_authoring_requirement_template_ready_count": sum(
            1
            for item in template_records
            if item.get("operator_real_source_authoring_requirement_template_ready")
        ),
        "request_operator_real_source_authoring_requirement_template_ready": ready,
        "request_operator_real_source_authoring_requirement_template_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_authoring_requirement_template_records": template_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_authoring_requirement_template_verifier_capstone(
    operator_real_source_evidence_lint_hash_receipt_auth_quarantine_report,
    operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_evidence_lint_hash_receipt_auth_quarantine_report or {}
    )
    upstream_ref = dict(
        operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ref or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready"
            )
            for record in upstream_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        template_records = [
            _template_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, template_records))
    template_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_authoring_requirement_template_records"
        )
        or []
    ]
    record_count = len(template_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_operator_real_source_authoring_requirement_template_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in template_records
        if item.get("operator_real_source_authoring_requirement_template_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in template_records
        if item.get("operator_real_source_authoring_requirement_template_lint_ready")
    )
    upstream_ready_count = sum(
        1
        for item in upstream_records
        if item.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready"
        )
    )
    field_required_count = sum(
        _int(item.get("operator_field_authoring_requirement_count"))
        for item in template_records
    )
    field_template_verified_count = sum(
        _int(item.get("operator_field_authoring_requirement_template_verified_count"))
        for item in template_records
    )
    field_present_count = sum(
        _int(item.get("operator_field_authoring_evidence_present_count"))
        for item in template_records
    )
    source_template_count = record_count
    source_template_verified_count = sum(
        1
        for item in template_records
        if item.get("source_material_reference_intake_envelope_template_verified")
    )
    source_envelope_present_count = sum(
        1
        for item in template_records
        if item.get("source_material_reference_intake_envelope_present")
    )
    source_envelope_valid_count = sum(
        1
        for item in template_records
        if item.get("source_material_reference_intake_envelope_valid")
    )
    source_sha_declared_count = sum(
        1
        for item in template_records
        if item.get("source_material_reference_sha256_declared")
    )
    source_sha_verified_count = sum(
        1
        for item in template_records
        if item.get("source_material_reference_sha256_verified")
    )
    source_hash_binding_count = sum(
        1
        for item in template_records
        if item.get("source_material_reference_hash_binding_ready")
    )
    receipt_template_count = record_count
    receipt_template_verified_count = sum(
        1
        for item in template_records
        if item.get("receipt_authorization_envelope_template_verified")
    )
    receipt_present_count = sum(
        1 for item in template_records if item.get("receipt_authorization_envelope_present")
    )
    receipt_valid_count = sum(
        1 for item in template_records if item.get("receipt_authorization_envelope_valid")
    )
    receipt_ready_count = sum(
        1 for item in template_records if item.get("receipt_authorization_envelope_ready")
    )
    receipt_performed_count = sum(
        1 for item in template_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1
        for item in template_records
        if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in template_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in template_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in template_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in template_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in template_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and field_present_count == field_required_count
        and source_template_verified_count == source_template_count
        and source_envelope_valid_count == source_template_count
        and source_hash_binding_count == source_template_count
        and receipt_template_verified_count == receipt_template_count
        and receipt_ready_count == receipt_template_count
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_records)}",
    )
    _add_check(
        checks,
        "all_operator_real_source_authoring_requirement_templates_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_authoring_requirement_templates_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_field_authoring_requirements_satisfied",
        field_present_count == field_required_count,
        f"field_present={field_present_count} required={field_required_count}",
    )
    _add_check(
        checks,
        "all_source_material_reference_intake_envelope_templates_verified",
        source_template_verified_count == source_template_count,
        f"template_verified={source_template_verified_count} records={source_template_count}",
    )
    _add_check(
        checks,
        "all_source_material_reference_intake_envelopes_present_and_valid",
        source_envelope_present_count == source_template_count
        and source_envelope_valid_count == source_template_count,
        f"present={source_envelope_present_count} valid={source_envelope_valid_count} records={source_template_count}",
    )
    _add_check(
        checks,
        "all_source_material_reference_hash_bindings_ready",
        source_hash_binding_count == source_template_count,
        f"hash_binding={source_hash_binding_count} records={source_template_count}",
    )
    _add_check(
        checks,
        "all_receipt_authorization_envelope_templates_verified",
        receipt_template_verified_count == receipt_template_count,
        f"template_verified={receipt_template_verified_count} records={receipt_template_count}",
    )
    _add_check(
        checks,
        "all_receipt_authorization_envelopes_present_valid_and_quarantined",
        receipt_present_count == receipt_template_count
        and receipt_valid_count == receipt_template_count
        and receipt_ready_count == receipt_template_count
        and receipt_performed_count == 0,
        f"present={receipt_present_count} valid={receipt_valid_count} ready={receipt_ready_count} performed={receipt_performed_count} records={receipt_template_count}",
    )
    _add_check(
        checks,
        "all_request_operator_real_source_authoring_requirement_templates_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "operator_real_source_authoring_requirement_templates_are_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_TEMPLATE_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_TEMPLATE_UPSTREAM_LINT"
    elif field_present_count != field_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_FIELD_REQUIREMENT_MISSING"
    elif source_template_verified_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_SOURCE_REFERENCE_TEMPLATE"
    elif source_envelope_present_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_SOURCE_REFERENCE_ENVELOPE_MISSING"
    elif source_envelope_valid_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_SOURCE_REFERENCE_ENVELOPE_INVALID"
    elif source_hash_binding_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_SOURCE_HASH_BINDING"
    elif receipt_template_verified_count != receipt_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_RECEIPT_AUTH_TEMPLATE"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_TEMPLATE_ACTION_LEAK"
    elif receipt_present_count != receipt_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_RECEIPT_AUTH_ENVELOPE_MISSING"
    elif receipt_valid_count != receipt_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_RECEIPT_AUTH_ENVELOPE_INVALID"
    elif receipt_ready_count != receipt_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_RECEIPT_AUTH_ENVELOPE_QUARANTINE"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_TEMPLATE_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_TEMPLATE_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORING_REQUIREMENT_TEMPLATE_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_authoring_requirement_template_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count"
                )
            ),
            "operator_real_source_authoring_requirement_template_record_count": record_count,
            "hash_bound_operator_real_source_authoring_requirement_template_count": hash_bound_count,
            "operator_real_source_authoring_requirement_template_lint_ready_count": lint_ready_count,
            "upstream_evidence_lint_hash_receipt_auth_ready_count": upstream_ready_count,
            "upstream_evidence_lint_hash_receipt_auth_blocked_count": record_count
            - upstream_ready_count,
            "operator_field_authoring_requirement_count": field_required_count,
            "operator_field_authoring_requirement_template_verified_count": field_template_verified_count,
            "operator_field_authoring_evidence_present_count": field_present_count,
            "operator_field_authoring_requirement_missing_count": field_required_count
            - field_present_count,
            "source_material_reference_intake_envelope_template_record_count": source_template_count,
            "source_material_reference_intake_envelope_template_verified_count": source_template_verified_count,
            "source_material_reference_intake_envelope_present_count": source_envelope_present_count,
            "source_material_reference_intake_envelope_missing_count": source_template_count
            - source_envelope_present_count,
            "source_material_reference_intake_envelope_valid_count": source_envelope_valid_count,
            "source_material_reference_intake_envelope_invalid_count": source_template_count
            - source_envelope_valid_count,
            "source_material_reference_sha256_declared_count": source_sha_declared_count,
            "source_material_reference_sha256_verified_count": source_sha_verified_count,
            "source_material_reference_hash_binding_ready_count": source_hash_binding_count,
            "source_material_reference_hash_binding_unbound_count": source_template_count
            - source_hash_binding_count,
            "receipt_authorization_envelope_template_record_count": receipt_template_count,
            "receipt_authorization_envelope_template_verified_count": receipt_template_verified_count,
            "receipt_authorization_envelope_present_count": receipt_present_count,
            "receipt_authorization_envelope_missing_count": receipt_template_count
            - receipt_present_count,
            "receipt_authorization_envelope_valid_count": receipt_valid_count,
            "receipt_authorization_envelope_invalid_count": receipt_template_count
            - receipt_valid_count,
            "receipt_authorization_envelope_ready_count": receipt_ready_count,
            "receipt_authorization_envelope_quarantined_count": receipt_template_count
            - receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_authoring_requirement_template_record_count": request_count,
            "request_operator_real_source_authoring_requirement_template_ready_count": request_ready_count,
            "request_operator_real_source_authoring_requirement_template_blocked_count": request_blocked_count,
            "proof_status_operator_real_source_authoring_requirement_required_count": _count(
                template_records, "proof_status"
            ),
            "proof_status_operator_real_source_authoring_requirement_ready_count": _count(
                template_records,
                "proof_status",
                "operator_real_source_authoring_requirement_template_ready",
            ),
            "evidence_manifest_operator_real_source_authoring_requirement_required_count": _count(
                template_records, "evidence_manifest"
            ),
            "evidence_manifest_operator_real_source_authoring_requirement_ready_count": _count(
                template_records,
                "evidence_manifest",
                "operator_real_source_authoring_requirement_template_ready",
            ),
            "appendix_supplement_operator_real_source_authoring_requirement_required_count": _count(
                template_records, "appendix_supplement"
            ),
            "appendix_supplement_operator_real_source_authoring_requirement_ready_count": _count(
                template_records,
                "appendix_supplement",
                "operator_real_source_authoring_requirement_template_ready",
            ),
            "claim_downgrade_operator_real_source_authoring_requirement_required_count": _count(
                template_records, "claim_downgrade"
            ),
            "claim_downgrade_operator_real_source_authoring_requirement_ready_count": _count(
                template_records,
                "claim_downgrade",
                "operator_real_source_authoring_requirement_template_ready",
            ),
            "referee_rejudge_operator_real_source_authoring_requirement_required_count": _count(
                template_records, "referee_rejudge"
            ),
            "referee_rejudge_operator_real_source_authoring_requirement_ready_count": _count(
                template_records,
                "referee_rejudge",
                "operator_real_source_authoring_requirement_template_ready",
            ),
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_authoring_requirement_template_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_authoring_requirement_template_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies operator field authoring requirement templates, source-material reference intake envelope templates, and receipt authorization envelope templates.",
            "Authoring requirement templates, source-material reference intake envelope templates, and receipt authorization envelope templates are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready authoring requirement template verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Operator Real-Source Authoring Requirement Template Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_authoring_requirement_template_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
