"""Operator real-source evidence lint/hash/receipt-auth quarantine capstone."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-evidence-"
    "lint-hash-receipt-auth-quarantine-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_capstone.v1"
)
RECEIPT_AUTH_REQUEST_ENVELOPE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_redrive_receipt_authoring_authorization_request_envelope.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_state",
    "report_schema",
    "summary",
    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_intake_acceptance_preflight_record_count",
    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count",
    "hash_bound_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_count",
    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready_count",
    "upstream_acceptance_preflight_ready_count",
    "upstream_acceptance_preflight_blocked_count",
    "operator_real_source_intake_checklist_record_count",
    "operator_real_source_intake_checklist_matched_count",
    "operator_real_source_intake_checklist_missing_count",
    "operator_evidence_packet_field_lint_required_count",
    "operator_evidence_packet_field_lint_ready_count",
    "operator_evidence_packet_field_lint_missing_count",
    "source_material_reference_file_required_count",
    "source_material_reference_file_present_count",
    "source_material_reference_file_missing_count",
    "source_material_reference_sha256_declared_count",
    "source_material_reference_sha256_verified_count",
    "source_material_reference_sha256_mismatch_count",
    "source_material_reference_hash_binding_ready_count",
    "source_material_reference_hash_binding_unbound_count",
    "redrive_receipt_authorization_request_envelope_required_count",
    "redrive_receipt_authorization_request_envelope_present_count",
    "redrive_receipt_authorization_request_envelope_missing_count",
    "redrive_receipt_authorization_request_envelope_valid_count",
    "redrive_receipt_authorization_request_envelope_invalid_count",
    "redrive_receipt_authorization_request_envelope_ready_count",
    "redrive_receipt_authorization_request_envelope_quarantined_count",
    "redrive_receipt_authorization_performed_count",
    "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count",
    "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready_count",
    "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_blocked_count",
    "proof_status_operator_real_source_evidence_lint_hash_receipt_auth_required_count",
    "proof_status_operator_real_source_evidence_lint_hash_receipt_auth_ready_count",
    "evidence_manifest_operator_real_source_evidence_lint_hash_receipt_auth_required_count",
    "evidence_manifest_operator_real_source_evidence_lint_hash_receipt_auth_ready_count",
    "appendix_supplement_operator_real_source_evidence_lint_hash_receipt_auth_required_count",
    "appendix_supplement_operator_real_source_evidence_lint_hash_receipt_auth_ready_count",
    "claim_downgrade_operator_real_source_evidence_lint_hash_receipt_auth_required_count",
    "claim_downgrade_operator_real_source_evidence_lint_hash_receipt_auth_ready_count",
    "referee_rejudge_operator_real_source_evidence_lint_hash_receipt_auth_required_count",
    "referee_rejudge_operator_real_source_evidence_lint_hash_receipt_auth_ready_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _first_text(*values):
    for value in values:
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def expected_receipt_authorization_request_envelope_path(acceptance_record):
    receipt_path = (acceptance_record or {}).get("expected_redrive_execution_receipt_path") or ""
    if receipt_path.endswith(".redrive-receipt.json"):
        return receipt_path[: -len(".redrive-receipt.json")] + ".redrive-receipt-authorization-request.json"
    if receipt_path.endswith(".json"):
        return receipt_path[:-5] + ".authorization-request.json"
    return receipt_path + ".authorization-request.json" if receipt_path else ""


def _acceptance_request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get("operator_real_source_intake_acceptance_preflight_records")
        or []
        if isinstance(item, dict)
    ]


def _acceptance_packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get("operator_real_source_intake_acceptance_preflight_records")
        or []
        if isinstance(item, dict)
    ]


def _checklist_packet_records(report):
    records = []
    for request_record in (report or {}).get("operator_real_source_intake_checklist_verifier_records") or []:
        if not isinstance(request_record, dict):
            continue
        for packet_record in request_record.get("operator_real_source_intake_checklist_records") or []:
            if isinstance(packet_record, dict):
                records.append(dict(packet_record))
    return records


def _record_key(record):
    return (
        str((record or {}).get("request_id")),
        (record or {}).get("slug") or "",
        (record or {}).get("packet_type") or "",
    )


def _field_lint_records(acceptance_record, payload_sha):
    records = []
    packet_valid = bool(acceptance_record.get("operator_real_source_intake_packet_valid"))
    for field in acceptance_record.get("operator_intake_field_acceptance_records") or []:
        field = dict(field or {})
        required = bool(field.get("required"))
        acceptance_ready = bool(field.get("operator_intake_field_acceptance_ready"))
        ready = bool(required and packet_valid and acceptance_ready)
        payload = {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_evidence_field_lint_record.v1"
            ),
            "operator_real_source_evidence_lint_hash_receipt_auth_payload_sha256": payload_sha,
            "field": field.get("name") or "",
            "required": required,
        }
        field_sha = _sha(payload)
        records.append(
            {
                "operator_evidence_packet_field_lint_id": (
                    f"operator-real-source-evidence-field-lint-{field_sha[:16]}"
                ),
                "operator_evidence_packet_field_lint_payload_sha256": field_sha,
                "name": field.get("name") or "",
                "required": required,
                "template_spec_verified": bool(field.get("template_spec_verified")),
                "operator_packet_valid": packet_valid,
                "field_acceptance_ready": acceptance_ready,
                "operator_evidence_packet_field_lint_ready": ready,
                "operator_evidence_packet_field_lint_missing": bool(required and not ready),
                "detail": field.get("detail"),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_material_audit(acceptance_record, checklist_record, source_inventory):
    checklist_record = dict(checklist_record or {})
    source_inventory = source_inventory or {}
    source_reference = _first_text(
        checklist_record.get("source_material_evidence_reference"),
        checklist_record.get("real_source_material_evidence_path"),
        checklist_record.get("source_material_evidence_path"),
        acceptance_record.get("source_material_evidence_reference"),
        acceptance_record.get("real_source_material_evidence_path"),
    )
    declared_sha = _first_text(
        checklist_record.get("declared_source_sha256"),
        checklist_record.get("request_specific_source_sha256"),
        checklist_record.get("source_sha256"),
        acceptance_record.get("declared_source_sha256"),
    )
    inventory = dict(source_inventory.get(source_reference) or {}) if source_reference else {}
    file_present = bool(
        source_reference
        and (
            inventory.get("present")
            or checklist_record.get("source_material_reference_file_present")
            or acceptance_record.get("source_material_reference_file_present")
        )
    )
    observed_sha = _first_text(
        inventory.get("sha256"),
        checklist_record.get("observed_source_sha256"),
        acceptance_record.get("observed_source_sha256"),
    )
    sha_declared = bool(len(declared_sha) >= 32 or checklist_record.get("source_sha256_declared") or acceptance_record.get("source_sha256_declared"))
    sha_verified = bool(
        file_present
        and sha_declared
        and (
            inventory.get("sha256_match")
            or checklist_record.get("source_material_reference_sha256_verified")
            or acceptance_record.get("source_material_reference_sha256_verified")
            or (declared_sha and observed_sha and declared_sha == observed_sha)
        )
    )
    hash_bound = bool(
        file_present
        and sha_verified
        and acceptance_record.get("source_material_reference_hash_binding_ready")
    )
    return {
        "source_material_reference_file_audit": {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_source_material_reference_file_sha256_audit.v1"
            ),
            "source_material_reference": source_reference,
            "source_material_reference_file_present": file_present,
            "source_material_reference_file_missing": not file_present,
            "source_material_reference_sha256_declared": sha_declared,
            "declared_source_sha256": declared_sha,
            "observed_source_sha256": observed_sha,
            "source_material_reference_sha256_verified": sha_verified,
            "source_material_reference_sha256_mismatch": bool(
                file_present and sha_declared and not sha_verified
            ),
            "source_material_reference_hash_binding_ready": hash_bound,
            "source_material_reference_hash_binding_unbound": not hash_bound,
            "consumable_as_repair_evidence": False,
            "consumable_as_release_evidence": False,
            "consumable_as_request_closure": False,
        },
        "source_material_reference_file_present": file_present,
        "source_material_reference_sha256_declared": sha_declared,
        "source_material_reference_sha256_verified": sha_verified,
        "source_material_reference_sha256_mismatch": bool(
            file_present and sha_declared and not sha_verified
        ),
        "source_material_reference_hash_binding_ready": hash_bound,
        "source_material_reference_hash_binding_unbound": not hash_bound,
    }


def _receipt_auth_envelope_record(
    acceptance_record, payload_sha, receipt_auth_inventory
):
    receipt_auth_inventory = receipt_auth_inventory or {}
    expected_path = expected_receipt_authorization_request_envelope_path(acceptance_record)
    inventory = dict(receipt_auth_inventory.get(expected_path) or {})
    envelope_data = dict(
        inventory.get("json")
        or acceptance_record.get("redrive_receipt_authorization_request_envelope")
        or {}
    )
    present = bool(
        inventory.get("present")
        or acceptance_record.get("redrive_receipt_authorization_request_envelope_present")
    )
    json_ok = bool(not present or inventory.get("json_ok", True))
    schema_match = bool(
        present
        and json_ok
        and envelope_data.get("schema_id") == RECEIPT_AUTH_REQUEST_ENVELOPE_SCHEMA_ID
    )
    binding_match = bool(
        present
        and json_ok
        and str(envelope_data.get("request_id")) == str(acceptance_record.get("request_id"))
        and (envelope_data.get("slug") or "") == (acceptance_record.get("slug") or "")
        and (envelope_data.get("packet_type") or "") == (acceptance_record.get("packet_type") or "")
        and (envelope_data.get("expected_redrive_execution_receipt_path") or "")
        == (acceptance_record.get("expected_redrive_execution_receipt_path") or "")
        and (
            envelope_data.get("operator_real_source_intake_acceptance_preflight_payload_sha256")
            or ""
        )
        == (
            acceptance_record.get("operator_real_source_intake_acceptance_preflight_payload_sha256")
            or ""
        )
    )
    explicit = bool(
        present
        and json_ok
        and (
            envelope_data.get("explicit_redrive_receipt_authorization_request")
            or envelope_data.get("explicit_receipt_authorization_request")
        )
    )
    performed = bool(
        acceptance_record.get("redrive_receipt_authoring_authorization_performed")
        or inventory.get("authorization_performed")
        or envelope_data.get("redrive_receipt_authoring_authorization_performed")
        or envelope_data.get("authorization_performed")
    )
    valid = bool(present and json_ok and schema_match and binding_match and explicit)
    ready = bool(
        valid
        and acceptance_record.get("redrive_receipt_authoring_authorization_ready")
        and not performed
    )
    return {
        "schema_id": RECEIPT_AUTH_REQUEST_ENVELOPE_SCHEMA_ID,
        "redrive_receipt_authorization_request_envelope_id": (
            f"referee-repair-redrive-receipt-auth-request-{payload_sha[:16]}"
        ),
        "expected_redrive_receipt_authorization_request_envelope_path": expected_path,
        "redrive_receipt_authorization_request_envelope_present": present,
        "redrive_receipt_authorization_request_envelope_missing": not present,
        "redrive_receipt_authorization_request_envelope_json_ok": json_ok,
        "redrive_receipt_authorization_request_envelope_schema_match": schema_match,
        "redrive_receipt_authorization_request_envelope_binding_match": binding_match,
        "redrive_receipt_authorization_request_envelope_explicit": explicit,
        "redrive_receipt_authorization_request_envelope_valid": valid,
        "redrive_receipt_authorization_request_envelope_ready": ready,
        "redrive_receipt_authorization_request_envelope_quarantined": not ready,
        "redrive_receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
    }


def _evidence_record(
    acceptance_record,
    checklist_record,
    source_inventory,
    receipt_auth_inventory,
):
    acceptance_record = dict(acceptance_record or {})
    checklist_record = dict(checklist_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record.v1"
        ),
        "request_id": acceptance_record.get("request_id"),
        "slug": acceptance_record.get("slug") or "",
        "packet_type": acceptance_record.get("packet_type") or "",
        "operator_real_source_intake_acceptance_preflight_payload_sha256": (
            acceptance_record.get("operator_real_source_intake_acceptance_preflight_payload_sha256")
            or ""
        ),
    }
    payload_sha = _sha(payload)
    hash_bound = bool(
        payload_sha
        and acceptance_record.get("operator_real_source_intake_acceptance_preflight_hash_bound")
    )
    lint_ready = bool(
        hash_bound
        and acceptance_record.get("operator_real_source_intake_acceptance_preflight_lint_ready")
        and acceptance_record.get("request_id") is not None
        and acceptance_record.get("slug")
        and acceptance_record.get("packet_type")
    )
    field_records = _field_lint_records(acceptance_record, payload_sha)
    field_required = sum(1 for item in field_records if item.get("required"))
    field_ready = sum(
        1
        for item in field_records
        if item.get("required") and item.get("operator_evidence_packet_field_lint_ready")
    )
    source_audit = _source_material_audit(
        acceptance_record, checklist_record, source_inventory
    )
    receipt_envelope = _receipt_auth_envelope_record(
        acceptance_record, payload_sha, receipt_auth_inventory
    )
    expected_file_creation = bool(
        acceptance_record.get("expected_packet_file_creation_performed")
    )
    receipt_creation = bool(acceptance_record.get("redrive_receipt_creation_performed"))
    evidence_release = bool(acceptance_record.get("evidence_release_performed"))
    promoted = bool(acceptance_record.get("repair_evidence_promoted"))
    closure = bool(acceptance_record.get("request_closure_performed"))
    auth_performed = bool(
        receipt_envelope.get("redrive_receipt_authorization_performed")
    )
    consumable = bool(
        acceptance_record.get("consumable_as_repair_evidence")
        or acceptance_record.get("consumable_as_release_evidence")
        or acceptance_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or auth_performed
        or evidence_release
        or promoted
        or closure
    )
    ready = bool(
        hash_bound
        and lint_ready
        and checklist_record
        and field_ready == field_required
        and source_audit["source_material_reference_file_present"]
        and source_audit["source_material_reference_sha256_verified"]
        and source_audit["source_material_reference_hash_binding_ready"]
        and receipt_envelope["redrive_receipt_authorization_request_envelope_ready"]
        and not consumable
    )
    issues = []
    if not checklist_record:
        issues.append("operator_real_source_intake_checklist_record_missing")
    if field_ready != field_required:
        issues.append("operator_evidence_packet_field_lint_incomplete")
    if not source_audit["source_material_reference_file_present"]:
        issues.append("source_material_reference_file_missing")
    if not source_audit["source_material_reference_sha256_verified"]:
        issues.append("source_material_reference_sha256_unverified")
    if not source_audit["source_material_reference_hash_binding_ready"]:
        issues.append("source_material_reference_hash_unbound")
    if not receipt_envelope["redrive_receipt_authorization_request_envelope_present"]:
        issues.append("redrive_receipt_authorization_request_envelope_missing")
    if (
        receipt_envelope["redrive_receipt_authorization_request_envelope_present"]
        and not receipt_envelope["redrive_receipt_authorization_request_envelope_valid"]
    ):
        issues.append("redrive_receipt_authorization_request_envelope_invalid")
    if not receipt_envelope["redrive_receipt_authorization_request_envelope_ready"]:
        issues.append("redrive_receipt_authorization_request_envelope_quarantined")
    if consumable:
        issues.append("operator_real_source_evidence_lint_hash_auth_action_or_evidence_leak")
    return {
        "request_id": acceptance_record.get("request_id"),
        "slug": acceptance_record.get("slug") or "",
        "packet_type": acceptance_record.get("packet_type") or "",
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_id": (
            f"referee-repair-operator-real-source-evidence-lint-hash-auth-{acceptance_record.get('request_id')}-{acceptance_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256": payload_sha,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_hash_bound": hash_bound,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready": lint_ready,
        "operator_real_source_intake_acceptance_preflight_payload_sha256": (
            acceptance_record.get("operator_real_source_intake_acceptance_preflight_payload_sha256")
            or ""
        ),
        "operator_real_source_intake_checklist_payload_sha256": (
            checklist_record.get("operator_real_source_intake_checklist_payload_sha256")
            or ""
        ),
        "operator_real_source_intake_checklist_record_present": bool(checklist_record),
        "expected_packet_path": acceptance_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            acceptance_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "expected_operator_real_source_intake_path": (
            acceptance_record.get("expected_operator_real_source_intake_path") or ""
        ),
        "required_packet_schema_id": acceptance_record.get("required_packet_schema_id") or "",
        "operator_evidence_packet_field_lint_records": field_records,
        "operator_evidence_packet_field_lint_required_count": field_required,
        "operator_evidence_packet_field_lint_ready_count": field_ready,
        "operator_evidence_packet_field_lint_missing_count": field_required - field_ready,
        **source_audit,
        "redrive_receipt_authorization_request_envelope": receipt_envelope,
        "redrive_receipt_authorization_request_envelope_present": receipt_envelope[
            "redrive_receipt_authorization_request_envelope_present"
        ],
        "redrive_receipt_authorization_request_envelope_valid": receipt_envelope[
            "redrive_receipt_authorization_request_envelope_valid"
        ],
        "redrive_receipt_authorization_request_envelope_ready": receipt_envelope[
            "redrive_receipt_authorization_request_envelope_ready"
        ],
        "redrive_receipt_authorization_request_envelope_quarantined": receipt_envelope[
            "redrive_receipt_authorization_request_envelope_quarantined"
        ],
        "redrive_receipt_authorization_performed": auth_performed,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready": ready,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "operator source evidence lint/hash/auth quarantine is ready for downstream human source authoring review; do not create receipts or close here"
            if ready
            else "complete field-level operator evidence lint, source-material file sha256 audit, and redrive receipt authorization request envelope"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, evidence_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in evidence_records
        if not item.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256s": [
            item.get(
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256"
            )
            for item in evidence_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(evidence_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_id": (
            f"referee-repair-request-operator-real-source-evidence-lint-hash-auth-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_payload_sha256": payload_sha,
        "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_hash_bound"
                )
                for item in evidence_records
            )
        ),
        "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready"
                )
                for item in evidence_records
            )
        ),
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count": len(evidence_records),
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready_count": sum(
            1
            for item in evidence_records
            if item.get(
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready"
            )
        ),
        "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready": ready,
        "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_records": evidence_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_capstone(
    operator_real_source_intake_acceptance_preflight_report,
    operator_real_source_intake_checklist_verifier_report=None,
    operator_real_source_intake_acceptance_preflight_ref=None,
    operator_real_source_intake_checklist_verifier_ref=None,
    source_material_reference_inventory=None,
    redrive_receipt_authorization_request_envelope_inventory=None,
    label="",
    created_at="",
):
    acceptance_report = dict(
        operator_real_source_intake_acceptance_preflight_report or {}
    )
    checklist_report = dict(operator_real_source_intake_checklist_verifier_report or {})
    acceptance_ref = dict(operator_real_source_intake_acceptance_preflight_ref or {})
    checklist_ref = dict(operator_real_source_intake_checklist_verifier_ref or {})
    acceptance_summary = _summary(acceptance_report)
    checklist_summary = _summary(checklist_report)
    acceptance_request_records = _acceptance_request_records(acceptance_report)
    acceptance_records = [
        record
        for request_record in acceptance_request_records
        for record in _acceptance_packet_records(request_record)
    ]
    checklist_records = _checklist_packet_records(checklist_report)
    checklist_by_key = {_record_key(record): record for record in checklist_records}
    acceptance_report_valid = bool(
        acceptance_ref.get("path")
        and acceptance_ref.get("sha256_match")
        and acceptance_report
        and _status(acceptance_report, acceptance_ref) in {"PASS", "FAIL"}
    )
    checklist_report_valid = bool(
        checklist_ref.get("path")
        and checklist_ref.get("sha256_match")
        and checklist_report
        and _status(checklist_report, checklist_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        acceptance_report_valid
        and checklist_report_valid
        and _int(
            acceptance_summary.get(
                "request_operator_real_source_intake_acceptance_preflight_record_count"
            )
        )
        == len(acceptance_request_records)
        and all(
            request.get("request_operator_real_source_intake_acceptance_preflight_lint_ready")
            for request in acceptance_request_records
        )
        and all(
            record.get("operator_real_source_intake_acceptance_preflight_lint_ready")
            for record in acceptance_records
        )
    )
    request_records = []
    for request_record in sorted(
        acceptance_request_records, key=lambda item: str(item.get("request_id"))
    ):
        evidence_records = []
        for acceptance_record in _acceptance_packet_records(request_record):
            checklist_record = checklist_by_key.get(_record_key(acceptance_record), {})
            evidence_records.append(
                _evidence_record(
                    acceptance_record,
                    checklist_record,
                    source_material_reference_inventory,
                    redrive_receipt_authorization_request_envelope_inventory,
                )
            )
        request_records.append(_request_record(request_record, evidence_records))
    evidence_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_records"
        )
        or []
    ]
    record_count = len(evidence_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in evidence_records
        if item.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in evidence_records
        if item.get(
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in acceptance_records
        if item.get("operator_real_source_intake_acceptance_preflight_ready")
    )
    checklist_matched_count = sum(
        1
        for item in evidence_records
        if item.get("operator_real_source_intake_checklist_record_present")
    )
    field_required_count = sum(
        _int(item.get("operator_evidence_packet_field_lint_required_count"))
        for item in evidence_records
    )
    field_ready_count = sum(
        _int(item.get("operator_evidence_packet_field_lint_ready_count"))
        for item in evidence_records
    )
    source_file_present_count = sum(
        1
        for item in evidence_records
        if item.get("source_material_reference_file_present")
    )
    source_sha_declared_count = sum(
        1
        for item in evidence_records
        if item.get("source_material_reference_sha256_declared")
    )
    source_sha_verified_count = sum(
        1
        for item in evidence_records
        if item.get("source_material_reference_sha256_verified")
    )
    source_sha_mismatch_count = sum(
        1
        for item in evidence_records
        if item.get("source_material_reference_sha256_mismatch")
    )
    source_hash_binding_count = sum(
        1
        for item in evidence_records
        if item.get("source_material_reference_hash_binding_ready")
    )
    auth_envelope_present_count = sum(
        1
        for item in evidence_records
        if item.get("redrive_receipt_authorization_request_envelope_present")
    )
    auth_envelope_valid_count = sum(
        1
        for item in evidence_records
        if item.get("redrive_receipt_authorization_request_envelope_valid")
    )
    auth_envelope_ready_count = sum(
        1
        for item in evidence_records
        if item.get("redrive_receipt_authorization_request_envelope_ready")
    )
    auth_performed_count = sum(
        1
        for item in evidence_records
        if item.get("redrive_receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1
        for item in evidence_records
        if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1
        for item in evidence_records
        if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in evidence_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in evidence_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in evidence_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in evidence_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("redrive_receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and checklist_matched_count == record_count
        and field_ready_count == field_required_count
        and source_file_present_count == record_count
        and source_sha_verified_count == record_count
        and source_hash_binding_count == record_count
        and auth_envelope_ready_count == record_count
        and auth_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "operator_real_source_intake_acceptance_preflight_available",
        acceptance_report_valid,
        acceptance_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "operator_real_source_intake_checklist_verifier_available",
        checklist_report_valid,
        checklist_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "operator_real_source_intake_acceptance_preflight_lint_ready",
        upstream_lint_ready,
        f"requests={len(acceptance_request_records)} records={len(acceptance_records)}",
    )
    _add_check(
        checks,
        "all_operator_real_source_evidence_lint_hash_auth_records_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_evidence_lint_hash_auth_records_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_checklist_records_matched",
        checklist_matched_count == record_count,
        f"matched={checklist_matched_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_evidence_packet_fields_linted",
        field_ready_count == field_required_count,
        f"field_lint_ready={field_ready_count} required={field_required_count}",
    )
    _add_check(
        checks,
        "all_source_material_reference_files_present",
        source_file_present_count == record_count,
        f"source_files={source_file_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_material_reference_sha256s_verified",
        source_sha_verified_count == record_count,
        f"sha_verified={source_sha_verified_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_material_reference_hash_bindings_ready",
        source_hash_binding_count == record_count,
        f"hash_binding={source_hash_binding_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipt_authorization_request_envelopes_present_valid_and_quarantined",
        auth_envelope_ready_count == record_count and auth_performed_count == 0,
        f"present={auth_envelope_present_count} valid={auth_envelope_valid_count} ready={auth_envelope_ready_count} performed={auth_performed_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_operator_real_source_evidence_lint_hash_auth_quarantines_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "operator_real_source_evidence_lint_hash_auth_records_are_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and auth_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"auth_performed={auth_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not acceptance_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_UPSTREAM_MISSING"
    elif not checklist_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_CHECKLIST_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_UPSTREAM_LINT"
    elif checklist_matched_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_CHECKLIST_RECORD_MISSING"
    elif field_ready_count != field_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_FIELD_LINT_MISSING"
    elif source_file_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_SOURCE_REFERENCE_FILE_MISSING"
    elif source_sha_verified_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_SOURCE_SHA256_AUDIT"
    elif source_hash_binding_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_SOURCE_HASH_BINDING"
    elif expected_file_creation_count or receipt_creation_count or auth_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_ACTION_LEAK"
    elif auth_envelope_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_RECEIPT_AUTH_REQUEST_ENVELOPE_MISSING"
    elif auth_envelope_valid_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_RECEIPT_AUTH_REQUEST_ENVELOPE_INVALID"
    elif auth_envelope_ready_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_RECEIPT_AUTH_REQUEST_ENVELOPE_QUARANTINE"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_EVIDENCE_LINT_HASH_RECEIPT_AUTH_QUARANTINE_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_state": state,
        "summary": {
            "open_request_count": _int(acceptance_summary.get("open_request_count")),
            "operator_real_source_intake_acceptance_preflight_record_count": _int(
                acceptance_summary.get(
                    "operator_real_source_intake_acceptance_preflight_record_count"
                )
            ),
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count": record_count,
            "hash_bound_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_count": hash_bound_count,
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_lint_ready_count": lint_ready_count,
            "upstream_acceptance_preflight_ready_count": upstream_ready_count,
            "upstream_acceptance_preflight_blocked_count": record_count
            - upstream_ready_count,
            "operator_real_source_intake_checklist_record_count": _int(
                checklist_summary.get("operator_real_source_intake_checklist_record_count")
            ),
            "operator_real_source_intake_checklist_matched_count": checklist_matched_count,
            "operator_real_source_intake_checklist_missing_count": record_count
            - checklist_matched_count,
            "operator_evidence_packet_field_lint_required_count": field_required_count,
            "operator_evidence_packet_field_lint_ready_count": field_ready_count,
            "operator_evidence_packet_field_lint_missing_count": field_required_count
            - field_ready_count,
            "source_material_reference_file_required_count": record_count,
            "source_material_reference_file_present_count": source_file_present_count,
            "source_material_reference_file_missing_count": record_count
            - source_file_present_count,
            "source_material_reference_sha256_declared_count": source_sha_declared_count,
            "source_material_reference_sha256_verified_count": source_sha_verified_count,
            "source_material_reference_sha256_mismatch_count": source_sha_mismatch_count,
            "source_material_reference_hash_binding_ready_count": source_hash_binding_count,
            "source_material_reference_hash_binding_unbound_count": record_count
            - source_hash_binding_count,
            "redrive_receipt_authorization_request_envelope_required_count": record_count,
            "redrive_receipt_authorization_request_envelope_present_count": auth_envelope_present_count,
            "redrive_receipt_authorization_request_envelope_missing_count": record_count
            - auth_envelope_present_count,
            "redrive_receipt_authorization_request_envelope_valid_count": auth_envelope_valid_count,
            "redrive_receipt_authorization_request_envelope_invalid_count": record_count
            - auth_envelope_valid_count,
            "redrive_receipt_authorization_request_envelope_ready_count": auth_envelope_ready_count,
            "redrive_receipt_authorization_request_envelope_quarantined_count": record_count
            - auth_envelope_ready_count,
            "redrive_receipt_authorization_performed_count": auth_performed_count,
            "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_record_count": request_count,
            "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready_count": request_ready_count,
            "request_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_blocked_count": request_blocked_count,
            "proof_status_operator_real_source_evidence_lint_hash_receipt_auth_required_count": _count(
                evidence_records, "proof_status"
            ),
            "proof_status_operator_real_source_evidence_lint_hash_receipt_auth_ready_count": _count(
                evidence_records,
                "proof_status",
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready",
            ),
            "evidence_manifest_operator_real_source_evidence_lint_hash_receipt_auth_required_count": _count(
                evidence_records, "evidence_manifest"
            ),
            "evidence_manifest_operator_real_source_evidence_lint_hash_receipt_auth_ready_count": _count(
                evidence_records,
                "evidence_manifest",
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready",
            ),
            "appendix_supplement_operator_real_source_evidence_lint_hash_receipt_auth_required_count": _count(
                evidence_records, "appendix_supplement"
            ),
            "appendix_supplement_operator_real_source_evidence_lint_hash_receipt_auth_ready_count": _count(
                evidence_records,
                "appendix_supplement",
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready",
            ),
            "claim_downgrade_operator_real_source_evidence_lint_hash_receipt_auth_required_count": _count(
                evidence_records, "claim_downgrade"
            ),
            "claim_downgrade_operator_real_source_evidence_lint_hash_receipt_auth_ready_count": _count(
                evidence_records,
                "claim_downgrade",
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready",
            ),
            "referee_rejudge_operator_real_source_evidence_lint_hash_receipt_auth_required_count": _count(
                evidence_records, "referee_rejudge"
            ),
            "referee_rejudge_operator_real_source_evidence_lint_hash_receipt_auth_ready_count": _count(
                evidence_records,
                "referee_rejudge",
                "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready",
            ),
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_evidence_lint_hash_receipt_auth_quarantine_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies field-level operator evidence lint, source-material reference file sha256 audit, and redrive receipt authorization request-envelope quarantine.",
            "Lint records, source-material file audits, and authorization request-envelope quarantine records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready lint/hash/auth quarantine still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Operator Real-Source Evidence Lint/Hash/Receipt-Auth Quarantine",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_evidence_lint_hash_receipt_auth_quarantine_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
