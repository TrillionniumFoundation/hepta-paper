"""Human-authored value path/source reference/receipt marker verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-authored-"
    "value-path-source-reference-receipt-marker-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_capstone.v1"
)
HUMAN_AUTHORED_VALUE_EXPECTED_PATH_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_human_authored_value_expected_path_json_schema_verifier.v1"
)
SOURCE_REFERENCE_MATERIAL_PATH_SHA_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_source_reference_material_path_sha_quarantine.v1"
)
RECEIPT_MARKER_PACKET_TEMPLATE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_receipt_approval_operator_marker_packet_template_verifier.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_record_count",
    "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_record_count",
    "hash_bound_operator_real_source_human_authored_value_path_source_reference_receipt_marker_count",
    "operator_real_source_human_authored_value_path_source_reference_receipt_marker_lint_ready_count",
    "upstream_human_authored_value_source_reference_receipt_approval_ready_count",
    "upstream_human_authored_value_source_reference_receipt_approval_blocked_count",
    "human_authored_value_expected_path_json_schema_required_count",
    "human_authored_value_expected_path_declared_count",
    "human_authored_value_expected_path_json_count",
    "human_authored_value_packet_present_count",
    "human_authored_value_packet_missing_count",
    "human_authored_value_packet_json_ok_count",
    "human_authored_value_packet_schema_match_count",
    "human_authored_value_packet_hash_bound_count",
    "human_authored_value_expected_path_json_schema_ready_count",
    "source_reference_material_path_required_count",
    "source_reference_material_path_declared_count",
    "source_reference_material_path_json_count",
    "source_reference_material_path_present_count",
    "source_reference_material_path_missing_count",
    "source_reference_material_sha_declared_count",
    "source_reference_material_sha_verified_count",
    "source_reference_material_hash_binding_ready_count",
    "source_reference_material_hash_binding_unbound_count",
    "source_reference_material_path_sha_ready_count",
    "receipt_approval_marker_packet_template_required_count",
    "receipt_approval_marker_packet_path_declared_count",
    "receipt_approval_marker_packet_path_json_count",
    "receipt_approval_marker_packet_present_count",
    "receipt_approval_marker_packet_missing_count",
    "receipt_approval_marker_packet_schema_valid_count",
    "receipt_approval_operator_identity_marker_present_count",
    "receipt_approval_authorization_marker_present_count",
    "receipt_approval_marker_packet_template_verified_count",
    "receipt_approval_marker_packet_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_record_count",
    "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready_count",
    "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _value_lint_records(packet_record):
    return [
        dict(item or {})
        for item in (packet_record or {}).get(
            "human_authored_value_packet_schema_lint_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _json_path(path):
    return bool(path and str(path).endswith(".json"))


def _human_authored_value_expected_path_records(packet_record, payload_sha):
    records = []
    for item in _value_lint_records(packet_record):
        required = bool(item.get("required"))
        expected_path = item.get("expected_human_authored_value_packet_path") or ""
        path_declared = bool(expected_path)
        path_json = _json_path(expected_path)
        present = bool(item.get("human_authored_value_packet_present"))
        json_ok = bool(
            present
            and (
                item.get("human_authored_value_packet_json_ok")
                if "human_authored_value_packet_json_ok" in item
                else item.get("human_authored_value_packet_schema_match")
            )
        )
        schema_match = bool(present and item.get("human_authored_value_packet_schema_match"))
        hash_bound = bool(item.get("human_authored_value_packet_hash_bound"))
        ready = bool(
            required
            and item.get("human_authored_value_packet_schema_lint_template_verified")
            and path_declared
            and path_json
            and present
            and json_ok
            and schema_match
            and hash_bound
        )
        payload = {
            "schema_id": HUMAN_AUTHORED_VALUE_EXPECTED_PATH_SCHEMA_ID,
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_payload_sha256": payload_sha,
            "field": item.get("field") or "",
            "expected_human_authored_value_packet_path": expected_path,
            "source_human_authored_value_packet_schema_lint_payload_sha256": (
                item.get("human_authored_value_packet_schema_lint_payload_sha256") or ""
            ),
        }
        verifier_sha = _sha(payload)
        records.append(
            {
                "schema_id": HUMAN_AUTHORED_VALUE_EXPECTED_PATH_SCHEMA_ID,
                "human_authored_value_expected_path_json_schema_verifier_id": (
                    f"referee-repair-human-authored-value-path-schema-{verifier_sha[:16]}"
                ),
                "human_authored_value_expected_path_json_schema_payload_sha256": verifier_sha,
                "field": item.get("field") or "",
                "required": required,
                "expected_human_authored_value_packet_path": expected_path,
                "expected_human_authored_value_packet_path_declared": path_declared,
                "expected_human_authored_value_packet_path_is_json": path_json,
                "required_schema_id": item.get("required_schema_id") or "",
                "human_authored_value_packet_present": present,
                "human_authored_value_packet_missing": bool(required and not present),
                "human_authored_value_packet_json_ok": json_ok,
                "human_authored_value_packet_schema_match": schema_match,
                "human_authored_value_packet_hash_bound": hash_bound,
                "human_authored_value_expected_path_json_schema_ready": ready,
                "source_human_authored_value_packet_schema_lint_payload_sha256": (
                    item.get("human_authored_value_packet_schema_lint_payload_sha256") or ""
                ),
                "source_authored_value_provenance_manifest_payload_sha256": (
                    item.get("source_authored_value_provenance_manifest_payload_sha256") or ""
                ),
                "source_field_authoring_requirement_payload_sha256": (
                    item.get("source_field_authoring_requirement_payload_sha256") or ""
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_reference_material_path_sha_quarantine(packet_record, payload_sha):
    source = dict(packet_record.get("source_material_intake_reference_sha_verifier") or {})
    expected_path = source.get("expected_source_material_reference_intake_envelope_path") or ""
    path_declared = bool(expected_path)
    path_json = _json_path(expected_path)
    present = bool(source.get("source_material_intake_reference_present"))
    schema_valid = bool(source.get("source_material_intake_reference_schema_valid"))
    sha_declared = bool(source.get("source_material_intake_reference_sha_declared"))
    sha_verified = bool(source.get("source_material_intake_reference_sha_verified"))
    hash_ready = bool(source.get("source_material_intake_reference_hash_binding_ready"))
    ready = bool(
        path_declared
        and path_json
        and present
        and schema_valid
        and sha_declared
        and sha_verified
        and hash_ready
    )
    return {
        "schema_id": SOURCE_REFERENCE_MATERIAL_PATH_SHA_SCHEMA_ID,
        "source_reference_material_path_sha_quarantine_id": (
            f"referee-repair-source-reference-material-path-sha-{payload_sha[:16]}"
        ),
        "expected_source_material_reference_intake_envelope_path": expected_path,
        "expected_source_material_reference_path_declared": path_declared,
        "expected_source_material_reference_path_is_json": path_json,
        "expected_human_source_material_intake_packet_spec_path": (
            source.get("expected_human_source_material_intake_packet_spec_path") or ""
        ),
        "source_reference_material_path_present": present,
        "source_reference_material_path_missing": not present,
        "source_reference_material_schema_valid": schema_valid,
        "source_reference_material_sha_declared": sha_declared,
        "source_reference_material_sha_verified": sha_verified,
        "source_reference_material_hash_binding_ready": hash_ready,
        "source_reference_material_hash_binding_unbound": not hash_ready,
        "source_reference_material_path_sha_ready": ready,
        "source_material_intake_reference_sha_verifier_id": (
            source.get("source_material_intake_reference_sha_verifier_id") or ""
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_marker_packet_template(packet_record, payload_sha):
    receipt = dict(packet_record.get("receipt_approval_operator_marker_quarantine") or {})
    expected_path = (
        receipt.get("expected_receipt_authorization_human_approval_intake_path") or ""
    )
    path_declared = bool(expected_path)
    path_json = _json_path(expected_path)
    present = bool(receipt.get("receipt_authorization_human_approval_intake_present"))
    schema_valid = bool(receipt.get("receipt_authorization_human_approval_intake_valid"))
    identity_required = bool(receipt.get("operator_identity_marker_required", True))
    auth_required = bool(receipt.get("explicit_authorization_marker_required", True))
    identity_present = bool(receipt.get("operator_identity_marker_present"))
    auth_present = bool(receipt.get("explicit_authorization_marker_present"))
    marker_ready = bool(receipt.get("receipt_approval_operator_authorization_marker_ready"))
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(path_declared and path_json and identity_required and auth_required)
    ready = bool(
        template_verified
        and present
        and schema_valid
        and identity_present
        and auth_present
        and marker_ready
        and not performed
    )
    return {
        "schema_id": RECEIPT_MARKER_PACKET_TEMPLATE_SCHEMA_ID,
        "receipt_approval_operator_marker_packet_template_verifier_id": (
            f"referee-repair-receipt-approval-marker-template-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_human_approval_intake_path": expected_path,
        "expected_receipt_approval_marker_packet_path_declared": path_declared,
        "expected_receipt_approval_marker_packet_path_is_json": path_json,
        "receipt_approval_marker_packet_present": present,
        "receipt_approval_marker_packet_missing": not present,
        "receipt_approval_marker_packet_schema_valid": schema_valid,
        "operator_identity_marker_required": identity_required,
        "operator_identity_marker_present": identity_present,
        "explicit_authorization_marker_required": auth_required,
        "explicit_authorization_marker_present": auth_present,
        "receipt_approval_marker_packet_template_verified": template_verified,
        "receipt_approval_marker_packet_ready": ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "receipt_approval_operator_marker_quarantine_id": (
            receipt.get("receipt_approval_operator_marker_quarantine_id") or ""
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    value_records = _human_authored_value_expected_path_records(packet_record, payload_sha)
    source_quarantine = _source_reference_material_path_sha_quarantine(
        packet_record, payload_sha
    )
    receipt_template = _receipt_marker_packet_template(packet_record, payload_sha)
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready"
        )
        and packet_record.get("request_id") is not None
        and packet_record.get("slug")
        and packet_record.get("packet_type")
        and packet_record.get("expected_packet_path")
        and packet_record.get("expected_redrive_execution_receipt_path")
        and value_records
        and source_quarantine.get("expected_source_material_reference_path_declared")
        and receipt_template.get("expected_receipt_approval_marker_packet_path_declared")
    )
    value_required_count = sum(1 for item in value_records if item.get("required"))
    value_path_declared_count = sum(
        1
        for item in value_records
        if item.get("required")
        and item.get("expected_human_authored_value_packet_path_declared")
    )
    value_path_json_count = sum(
        1
        for item in value_records
        if item.get("required")
        and item.get("expected_human_authored_value_packet_path_is_json")
    )
    value_present_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_present")
    )
    value_json_ok_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_json_ok")
    )
    value_schema_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_schema_match")
    )
    value_hash_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_hash_bound")
    )
    value_ready_count = sum(
        1
        for item in value_records
        if item.get("required")
        and item.get("human_authored_value_expected_path_json_schema_ready")
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_template.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_ready"
        )
        and value_required_count
        and value_ready_count == value_required_count
        and source_quarantine.get("source_reference_material_path_sha_ready")
        and receipt_template.get("receipt_approval_marker_packet_ready")
        and not consumable
    )
    issues = []
    if value_path_declared_count != value_required_count:
        issues.append("human_authored_value_expected_path_missing")
    if value_path_json_count != value_required_count:
        issues.append("human_authored_value_expected_path_not_json")
    if value_present_count != value_required_count:
        issues.append("human_authored_value_packet_missing")
    if value_json_ok_count != value_required_count:
        issues.append("human_authored_value_packet_json_invalid")
    if value_schema_count != value_required_count:
        issues.append("human_authored_value_packet_schema_mismatch")
    if value_hash_count != value_required_count:
        issues.append("human_authored_value_packet_hash_unbound")
    if not source_quarantine.get("source_reference_material_path_present"):
        issues.append("source_reference_material_path_missing")
    if not source_quarantine.get("source_reference_material_sha_verified"):
        issues.append("source_reference_material_sha_unverified")
    if not source_quarantine.get("source_reference_material_hash_binding_ready"):
        issues.append("source_reference_material_hash_unbound")
    if not receipt_template.get("receipt_approval_marker_packet_present"):
        issues.append("receipt_approval_marker_packet_missing")
    if not receipt_template.get("receipt_approval_marker_packet_schema_valid"):
        issues.append("receipt_approval_marker_packet_schema_invalid")
    if not receipt_template.get("operator_identity_marker_present"):
        issues.append("receipt_approval_operator_identity_marker_missing")
    if not receipt_template.get("explicit_authorization_marker_present"):
        issues.append("receipt_approval_authorization_marker_missing")
    if not receipt_template.get("receipt_approval_marker_packet_ready"):
        issues.append("receipt_approval_marker_packet_quarantined")
    if consumable:
        issues.append("human_authored_value_path_source_reference_receipt_marker_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_id": (
            f"referee-repair-human-authored-value-path-source-receipt-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_payload_sha256": payload_sha,
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_hash_bound": hash_bound,
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_lint_ready": lint_ready,
        "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256"
            )
            or ""
        ),
        "expected_packet_path": packet_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            packet_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "human_authored_value_expected_path_json_schema_verifier_records": value_records,
        "human_authored_value_expected_path_json_schema_required_count": value_required_count,
        "human_authored_value_expected_path_declared_count": value_path_declared_count,
        "human_authored_value_expected_path_json_count": value_path_json_count,
        "human_authored_value_packet_present_count": value_present_count,
        "human_authored_value_packet_missing_count": value_required_count
        - value_present_count,
        "human_authored_value_packet_json_ok_count": value_json_ok_count,
        "human_authored_value_packet_schema_match_count": value_schema_count,
        "human_authored_value_packet_hash_bound_count": value_hash_count,
        "human_authored_value_expected_path_json_schema_ready_count": value_ready_count,
        "source_reference_material_path_sha_quarantine": source_quarantine,
        "source_reference_material_path_sha_ready": source_quarantine[
            "source_reference_material_path_sha_ready"
        ],
        "receipt_approval_operator_identity_authorization_marker_packet_template_verifier": receipt_template,
        "receipt_approval_marker_packet_ready": receipt_template[
            "receipt_approval_marker_packet_ready"
        ],
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready": ready,
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "human-authored values, source reference material path sha binding, and receipt marker packets are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide human-authored value packets, source reference material path sha binding, and receipt approval identity/authorization marker packets"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_payload_sha256s": [
            item.get(
                "operator_real_source_human_authored_value_path_source_reference_receipt_marker_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_id": (
            f"referee-repair-request-human-authored-value-path-source-receipt-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_payload_sha256": payload_sha,
        "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_authored_value_path_source_reference_receipt_marker_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_authored_value_path_source_reference_receipt_marker_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready"
            )
        ),
        "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready": ready,
        "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_capstone(
    operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_report,
    operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_authored_value_source_reference_receipt_approval_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "human_authored_value_expected_path_json_schema_verifier_records"
        )
        or []
    ]
    source_records = [
        record.get("source_reference_material_path_sha_quarantine") or {}
        for record in verifier_records
    ]
    receipt_records = [
        record.get(
            "receipt_approval_operator_identity_authorization_marker_packet_template_verifier"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_ready"
        )
    )
    value_required_count = sum(1 for item in value_records if item.get("required"))
    value_path_declared_count = sum(
        1
        for item in value_records
        if item.get("required")
        and item.get("expected_human_authored_value_packet_path_declared")
    )
    value_path_json_count = sum(
        1
        for item in value_records
        if item.get("required")
        and item.get("expected_human_authored_value_packet_path_is_json")
    )
    value_present_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_present")
    )
    value_json_ok_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_json_ok")
    )
    value_schema_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_schema_match")
    )
    value_hash_count = sum(
        1
        for item in value_records
        if item.get("required") and item.get("human_authored_value_packet_hash_bound")
    )
    value_ready_count = sum(
        1
        for item in value_records
        if item.get("required")
        and item.get("human_authored_value_expected_path_json_schema_ready")
    )
    source_required_count = record_count
    source_path_declared_count = sum(
        1
        for item in source_records
        if item.get("expected_source_material_reference_path_declared")
    )
    source_path_json_count = sum(
        1 for item in source_records if item.get("expected_source_material_reference_path_is_json")
    )
    source_present_count = sum(
        1 for item in source_records if item.get("source_reference_material_path_present")
    )
    source_sha_declared_count = sum(
        1 for item in source_records if item.get("source_reference_material_sha_declared")
    )
    source_sha_verified_count = sum(
        1 for item in source_records if item.get("source_reference_material_sha_verified")
    )
    source_hash_ready_count = sum(
        1
        for item in source_records
        if item.get("source_reference_material_hash_binding_ready")
    )
    source_ready_count = sum(
        1 for item in source_records if item.get("source_reference_material_path_sha_ready")
    )
    receipt_required_count = record_count
    receipt_path_declared_count = sum(
        1
        for item in receipt_records
        if item.get("expected_receipt_approval_marker_packet_path_declared")
    )
    receipt_path_json_count = sum(
        1
        for item in receipt_records
        if item.get("expected_receipt_approval_marker_packet_path_is_json")
    )
    receipt_present_count = sum(
        1 for item in receipt_records if item.get("receipt_approval_marker_packet_present")
    )
    receipt_schema_valid_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_approval_marker_packet_schema_valid")
    )
    receipt_identity_count = sum(
        1 for item in receipt_records if item.get("operator_identity_marker_present")
    )
    receipt_auth_count = sum(
        1 for item in receipt_records if item.get("explicit_authorization_marker_present")
    )
    receipt_template_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_approval_marker_packet_template_verified")
    )
    receipt_ready_count = sum(
        1 for item in receipt_records if item.get("receipt_approval_marker_packet_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1
        for item in verifier_records
        if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and value_ready_count == value_required_count
        and source_ready_count == source_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "human_authored_value_source_reference_receipt_approval_verifier_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "human_authored_value_source_reference_receipt_approval_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_human_authored_value_expected_paths_json_packets_schema_and_hash_ready",
        value_path_declared_count == value_required_count
        and value_path_json_count == value_required_count
        and value_present_count == value_required_count
        and value_json_ok_count == value_required_count
        and value_schema_count == value_required_count
        and value_hash_count == value_required_count,
        (
            f"path_declared={value_path_declared_count} path_json={value_path_json_count} "
            f"present={value_present_count} json_ok={value_json_ok_count} "
            f"schema={value_schema_count} hash={value_hash_count} required={value_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_source_reference_material_paths_present_sha_verified_and_hash_bound",
        source_path_declared_count == source_required_count
        and source_path_json_count == source_required_count
        and source_present_count == source_required_count
        and source_sha_verified_count == source_required_count
        and source_hash_ready_count == source_required_count,
        (
            f"path_declared={source_path_declared_count} path_json={source_path_json_count} "
            f"present={source_present_count} sha_verified={source_sha_verified_count} "
            f"hash_bound={source_hash_ready_count} records={source_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_approval_marker_packets_present_valid_and_authorized",
        receipt_path_declared_count == receipt_required_count
        and receipt_path_json_count == receipt_required_count
        and receipt_present_count == receipt_required_count
        and receipt_schema_valid_count == receipt_required_count
        and receipt_identity_count == receipt_required_count
        and receipt_auth_count == receipt_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0,
        (
            f"path_declared={receipt_path_declared_count} path_json={receipt_path_json_count} "
            f"present={receipt_present_count} valid={receipt_schema_valid_count} "
            f"identity={receipt_identity_count} auth={receipt_auth_count} "
            f"ready={receipt_ready_count} performed={receipt_performed_count} "
            f"records={receipt_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_human_authored_value_path_source_reference_receipt_marker_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "human_authored_value_path_source_reference_receipt_marker_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PATH_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PATH_UPSTREAM_LINT"
    elif value_path_declared_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_EXPECTED_PATH_MISSING"
    elif value_path_json_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_EXPECTED_PATH_NOT_JSON"
    elif value_present_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_EXPECTED_PACKET_MISSING"
    elif value_json_ok_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PACKET_JSON"
    elif value_schema_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PACKET_SCHEMA"
    elif value_hash_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PACKET_HASH_BINDING"
    elif source_path_declared_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_REFERENCE_PATH_MISSING"
    elif source_present_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_REFERENCE_MATERIAL_PATH_MISSING"
    elif source_sha_verified_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_REFERENCE_MATERIAL_SHA"
    elif source_hash_ready_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_REFERENCE_MATERIAL_HASH_BINDING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PATH_SOURCE_RECEIPT_MARKER_ACTION_LEAK"
    elif receipt_path_declared_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_MARKER_PACKET_PATH_MISSING"
    elif receipt_present_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_MARKER_PACKET_MISSING"
    elif receipt_schema_valid_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_MARKER_PACKET_SCHEMA"
    elif receipt_identity_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_OPERATOR_IDENTITY_MARKER_MISSING"
    elif receipt_auth_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_AUTHORIZATION_MARKER_MISSING"
    elif receipt_ready_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_MARKER_PACKET_QUARANTINE"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PATH_SOURCE_RECEIPT_MARKER_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PATH_SOURCE_RECEIPT_MARKER_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PATH_SOURCE_REFERENCE_RECEIPT_MARKER_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_record_count"
                )
            ),
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_authored_value_path_source_reference_receipt_marker_count": hash_bound_count,
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_lint_ready_count": lint_ready_count,
            "upstream_human_authored_value_source_reference_receipt_approval_ready_count": upstream_ready_count,
            "upstream_human_authored_value_source_reference_receipt_approval_blocked_count": record_count
            - upstream_ready_count,
            "human_authored_value_expected_path_json_schema_required_count": value_required_count,
            "human_authored_value_expected_path_declared_count": value_path_declared_count,
            "human_authored_value_expected_path_json_count": value_path_json_count,
            "human_authored_value_packet_present_count": value_present_count,
            "human_authored_value_packet_missing_count": value_required_count
            - value_present_count,
            "human_authored_value_packet_json_ok_count": value_json_ok_count,
            "human_authored_value_packet_schema_match_count": value_schema_count,
            "human_authored_value_packet_hash_bound_count": value_hash_count,
            "human_authored_value_expected_path_json_schema_ready_count": value_ready_count,
            "source_reference_material_path_required_count": source_required_count,
            "source_reference_material_path_declared_count": source_path_declared_count,
            "source_reference_material_path_json_count": source_path_json_count,
            "source_reference_material_path_present_count": source_present_count,
            "source_reference_material_path_missing_count": source_required_count
            - source_present_count,
            "source_reference_material_sha_declared_count": source_sha_declared_count,
            "source_reference_material_sha_verified_count": source_sha_verified_count,
            "source_reference_material_hash_binding_ready_count": source_hash_ready_count,
            "source_reference_material_hash_binding_unbound_count": source_required_count
            - source_hash_ready_count,
            "source_reference_material_path_sha_ready_count": source_ready_count,
            "receipt_approval_marker_packet_template_required_count": receipt_required_count,
            "receipt_approval_marker_packet_path_declared_count": receipt_path_declared_count,
            "receipt_approval_marker_packet_path_json_count": receipt_path_json_count,
            "receipt_approval_marker_packet_present_count": receipt_present_count,
            "receipt_approval_marker_packet_missing_count": receipt_required_count
            - receipt_present_count,
            "receipt_approval_marker_packet_schema_valid_count": receipt_schema_valid_count,
            "receipt_approval_operator_identity_marker_present_count": receipt_identity_count,
            "receipt_approval_authorization_marker_present_count": receipt_auth_count,
            "receipt_approval_marker_packet_template_verified_count": receipt_template_count,
            "receipt_approval_marker_packet_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_record_count": request_count,
            "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_ready_count": request_ready_count,
            "request_operator_real_source_human_authored_value_path_source_reference_receipt_marker_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies human-authored value packet expected paths, JSON/schema/hash binding, source-reference material path sha binding, and receipt approval identity/authorization marker packet templates.",
            "Human-authored value path verifiers, source reference material path quarantines, and receipt marker packet template verifiers are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Authored Value Path Source Reference Receipt Marker Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_authored_value_path_source_reference_receipt_marker_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
