"""Human-authored value/source reference/receipt approval verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-authored-"
    "value-source-reference-receipt-approval-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_capstone.v1"
)
HUMAN_AUTHORED_VALUE_SCHEMA_LINT_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_human_authored_value_packet_schema_lint.v1"
)
SOURCE_MATERIAL_REFERENCE_SHA_VERIFIER_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_source_material_intake_reference_sha_verifier.v1"
)
RECEIPT_APPROVAL_OPERATOR_MARKER_QUARANTINE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_receipt_approval_operator_marker_quarantine.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_intake_provenance_auth_quarantine_record_count",
    "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_record_count",
    "hash_bound_operator_real_source_human_authored_value_source_reference_receipt_approval_count",
    "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready_count",
    "upstream_human_intake_provenance_auth_ready_count",
    "upstream_human_intake_provenance_auth_blocked_count",
    "human_authored_value_packet_schema_lint_required_count",
    "human_authored_value_packet_schema_lint_template_verified_count",
    "human_authored_value_packet_present_count",
    "human_authored_value_packet_missing_count",
    "human_authored_value_packet_schema_match_count",
    "human_authored_value_packet_schema_lint_ready_count",
    "human_authored_value_packet_hash_bound_count",
    "source_material_intake_reference_required_count",
    "source_material_intake_reference_present_count",
    "source_material_intake_reference_missing_count",
    "source_material_intake_reference_sha_declared_count",
    "source_material_intake_reference_sha_verified_count",
    "source_material_intake_reference_hash_binding_ready_count",
    "source_material_intake_reference_hash_binding_unbound_count",
    "receipt_approval_operator_identity_marker_required_count",
    "receipt_approval_operator_identity_marker_present_count",
    "receipt_approval_authorization_marker_required_count",
    "receipt_approval_authorization_marker_present_count",
    "receipt_approval_operator_authorization_marker_ready_count",
    "receipt_approval_operator_authorization_marker_quarantined_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_authored_value_source_reference_receipt_approval_record_count",
    "request_operator_real_source_human_authored_value_source_reference_receipt_approval_ready_count",
    "request_operator_real_source_human_authored_value_source_reference_receipt_approval_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_intake_provenance_auth_quarantine_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_intake_provenance_auth_quarantine_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _provenance_records(packet_record):
    return [
        dict(item or {})
        for item in (packet_record or {}).get(
            "authored_value_provenance_manifest_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _human_authored_value_schema_lint_records(packet_record, payload_sha):
    records = []
    for item in _provenance_records(packet_record):
        required = bool(item.get("required"))
        present = bool(item.get("authored_value_provenance_manifest_present"))
        hash_bound = bool(item.get("authored_value_provenance_manifest_hash_bound"))
        schema_match = bool(present and hash_bound)
        lint_ready = bool(
            required
            and item.get("authored_value_provenance_manifest_template_verified")
            and present
            and schema_match
            and hash_bound
        )
        payload = {
            "schema_id": HUMAN_AUTHORED_VALUE_SCHEMA_LINT_SCHEMA_ID,
            "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256": payload_sha,
            "field": item.get("field") or "",
            "authored_value_provenance_manifest_payload_sha256": (
                item.get("authored_value_provenance_manifest_payload_sha256") or ""
            ),
        }
        lint_sha = _sha(payload)
        records.append(
            {
                "human_authored_value_packet_schema_lint_id": (
                    f"referee-repair-human-authored-value-schema-lint-{lint_sha[:16]}"
                ),
                "human_authored_value_packet_schema_lint_payload_sha256": lint_sha,
                "field": item.get("field") or "",
                "required": required,
                "expected_human_authored_value_packet_path": (
                    item.get("expected_authored_value_provenance_manifest_path") or ""
                ),
                "required_schema_id": (
                    "paper_factory.paper_production."
                    "referee_repair_operator_authored_value_provenance_manifest.v1"
                ),
                "human_authored_value_packet_schema_lint_template_verified": bool(
                    item.get("authored_value_provenance_manifest_template_verified")
                ),
                "human_authored_value_packet_present": present,
                "human_authored_value_packet_missing": bool(required and not present),
                "human_authored_value_packet_schema_match": schema_match,
                "human_authored_value_packet_hash_bound": hash_bound,
                "human_authored_value_packet_schema_lint_ready": lint_ready,
                "source_authored_value_provenance_manifest_payload_sha256": (
                    item.get("authored_value_provenance_manifest_payload_sha256") or ""
                ),
                "source_field_authoring_requirement_payload_sha256": (
                    item.get("source_field_authoring_requirement_payload_sha256") or ""
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_reference_sha_verifier(packet_record, payload_sha):
    spec = dict(packet_record.get("human_source_material_intake_packet_spec") or {})
    expected_path = spec.get("source_material_reference_intake_envelope_path") or ""
    human_spec_path = (
        spec.get("expected_human_source_material_intake_packet_spec_path") or ""
    )
    present = bool(packet_record.get("human_source_material_intake_packet_spec_present"))
    valid = bool(packet_record.get("human_source_material_intake_packet_spec_valid"))
    sha_declared = bool(spec.get("source_material_reference_sha256_declared"))
    sha_verified = bool(spec.get("source_material_reference_sha256_verified"))
    hash_ready = bool(packet_record.get("source_material_reference_hash_binding_ready"))
    reference_ready = bool(present and valid and sha_declared and sha_verified and hash_ready)
    return {
        "schema_id": SOURCE_MATERIAL_REFERENCE_SHA_VERIFIER_SCHEMA_ID,
        "source_material_intake_reference_sha_verifier_id": (
            f"referee-repair-source-reference-sha-verifier-{payload_sha[:16]}"
        ),
        "expected_source_material_reference_intake_envelope_path": expected_path,
        "expected_human_source_material_intake_packet_spec_path": human_spec_path,
        "source_material_intake_reference_present": present,
        "source_material_intake_reference_missing": not present,
        "source_material_intake_reference_schema_valid": valid,
        "source_material_intake_reference_sha_declared": sha_declared,
        "source_material_intake_reference_sha_verified": sha_verified,
        "source_material_intake_reference_hash_binding_ready": hash_ready,
        "source_material_intake_reference_hash_binding_unbound": not hash_ready,
        "source_material_intake_reference_ready": reference_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_operator_marker_quarantine(packet_record, payload_sha):
    approval = dict(
        packet_record.get("receipt_authorization_human_approval_intake") or {}
    )
    present = bool(packet_record.get("receipt_authorization_human_approval_intake_present"))
    valid = bool(packet_record.get("receipt_authorization_human_approval_intake_valid"))
    approval_ready = bool(
        packet_record.get("receipt_authorization_human_approval_intake_ready")
    )
    identity_marker = bool(
        valid
        and (
            approval.get("operator_identity_marker_present")
            or approval.get("operator_identity_hash_bound")
        )
    )
    authorization_marker = bool(
        valid
        and (
            approval.get("explicit_human_receipt_authorization_approval")
            or approval.get("authorization_marker_present")
        )
    )
    performed = bool(packet_record.get("receipt_authorization_performed"))
    marker_ready = bool(
        present
        and valid
        and approval_ready
        and identity_marker
        and authorization_marker
        and not performed
    )
    return {
        "schema_id": RECEIPT_APPROVAL_OPERATOR_MARKER_QUARANTINE_SCHEMA_ID,
        "receipt_approval_operator_marker_quarantine_id": (
            f"referee-repair-receipt-approval-operator-marker-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_human_approval_intake_path": (
            approval.get("expected_receipt_authorization_human_approval_intake_path")
            or ""
        ),
        "receipt_authorization_human_approval_intake_present": present,
        "receipt_authorization_human_approval_intake_valid": valid,
        "receipt_authorization_human_approval_intake_ready": approval_ready,
        "operator_identity_marker_required": True,
        "operator_identity_marker_present": identity_marker,
        "explicit_authorization_marker_required": True,
        "explicit_authorization_marker_present": authorization_marker,
        "receipt_approval_operator_authorization_marker_ready": marker_ready,
        "receipt_approval_operator_authorization_marker_quarantined": not marker_ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_intake_provenance_auth_quarantine_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_intake_provenance_auth_quarantine_lint_ready"
        )
        and packet_record.get("request_id") is not None
        and packet_record.get("slug")
        and packet_record.get("packet_type")
        and packet_record.get("expected_packet_path")
        and packet_record.get("expected_redrive_execution_receipt_path")
    )
    value_lints = _human_authored_value_schema_lint_records(packet_record, payload_sha)
    source_verifier = _source_reference_sha_verifier(packet_record, payload_sha)
    receipt_marker = _receipt_operator_marker_quarantine(packet_record, payload_sha)
    required_values = sum(1 for item in value_lints if item.get("required"))
    present_values = sum(
        1
        for item in value_lints
        if item.get("required") and item.get("human_authored_value_packet_present")
    )
    schema_match_values = sum(
        1
        for item in value_lints
        if item.get("required") and item.get("human_authored_value_packet_schema_match")
    )
    hash_bound_values = sum(
        1
        for item in value_lints
        if item.get("required") and item.get("human_authored_value_packet_hash_bound")
    )
    lint_ready_values = sum(
        1
        for item in value_lints
        if item.get("required") and item.get("human_authored_value_packet_schema_lint_ready")
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_marker.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_intake_provenance_auth_quarantine_ready"
        )
        and required_values
        and lint_ready_values == required_values
        and source_verifier.get("source_material_intake_reference_ready")
        and receipt_marker.get("receipt_approval_operator_authorization_marker_ready")
        and not consumable
    )
    issues = []
    if present_values != required_values:
        issues.append("human_authored_value_packet_missing")
    if schema_match_values != required_values:
        issues.append("human_authored_value_packet_schema_lint_failed")
    if hash_bound_values != required_values:
        issues.append("human_authored_value_packet_hash_unbound")
    if not source_verifier.get("source_material_intake_reference_present"):
        issues.append("source_material_intake_reference_missing")
    if not source_verifier.get("source_material_intake_reference_sha_verified"):
        issues.append("source_material_intake_reference_sha_unverified")
    if not source_verifier.get("source_material_intake_reference_hash_binding_ready"):
        issues.append("source_material_intake_reference_hash_unbound")
    if not receipt_marker.get("operator_identity_marker_present"):
        issues.append("receipt_approval_operator_identity_marker_missing")
    if not receipt_marker.get("explicit_authorization_marker_present"):
        issues.append("receipt_approval_authorization_marker_missing")
    if not receipt_marker.get("receipt_approval_operator_authorization_marker_ready"):
        issues.append("receipt_approval_operator_authorization_marker_quarantined")
    if consumable:
        issues.append("human_authored_value_source_reference_receipt_approval_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_id": (
            f"referee-repair-human-authored-value-source-receipt-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256": payload_sha,
        "operator_real_source_human_authored_value_source_reference_receipt_approval_hash_bound": hash_bound,
        "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready": lint_ready,
        "operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256"
            )
            or ""
        ),
        "expected_packet_path": packet_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            packet_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "human_authored_value_packet_schema_lint_records": value_lints,
        "human_authored_value_packet_schema_lint_required_count": required_values,
        "human_authored_value_packet_present_count": present_values,
        "human_authored_value_packet_missing_count": required_values - present_values,
        "human_authored_value_packet_schema_match_count": schema_match_values,
        "human_authored_value_packet_hash_bound_count": hash_bound_values,
        "human_authored_value_packet_schema_lint_ready_count": lint_ready_values,
        "source_material_intake_reference_sha_verifier": source_verifier,
        "source_material_intake_reference_ready": source_verifier[
            "source_material_intake_reference_ready"
        ],
        "receipt_approval_operator_marker_quarantine": receipt_marker,
        "receipt_approval_operator_authorization_marker_ready": receipt_marker[
            "receipt_approval_operator_authorization_marker_ready"
        ],
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_authored_value_source_reference_receipt_approval_ready": ready,
        "operator_real_source_human_authored_value_source_reference_receipt_approval_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "human-authored values, source reference sha, and receipt approval markers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide human-authored value packets, source-material reference sha binding, and receipt approval operator/authorization markers"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_authored_value_source_reference_receipt_approval_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256s": [
            item.get(
                "operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_authored_value_source_reference_receipt_approval_id": (
            f"referee-repair-request-human-authored-value-source-receipt-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_authored_value_source_reference_receipt_approval_payload_sha256": payload_sha,
        "request_operator_real_source_human_authored_value_source_reference_receipt_approval_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_authored_value_source_reference_receipt_approval_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_authored_value_source_reference_receipt_approval_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_authored_value_source_reference_receipt_approval_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_authored_value_source_reference_receipt_approval_ready"
            )
        ),
        "request_operator_real_source_human_authored_value_source_reference_receipt_approval_ready": ready,
        "request_operator_real_source_human_authored_value_source_reference_receipt_approval_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_authored_value_source_reference_receipt_approval_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_capstone(
    operator_real_source_human_intake_provenance_auth_quarantine_report,
    operator_real_source_human_intake_provenance_auth_quarantine_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_intake_provenance_auth_quarantine_report or {}
    )
    upstream_ref = dict(
        operator_real_source_human_intake_provenance_auth_quarantine_ref or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_intake_provenance_auth_quarantine_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_intake_provenance_auth_quarantine_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_intake_provenance_auth_quarantine_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_records"
        )
        or []
    ]
    value_lint_records = [
        item
        for record in verifier_records
        for item in record.get("human_authored_value_packet_schema_lint_records") or []
    ]
    source_records = [
        record.get("source_material_intake_reference_sha_verifier") or {}
        for record in verifier_records
    ]
    receipt_marker_records = [
        record.get("receipt_approval_operator_marker_quarantine") or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_authored_value_source_reference_receipt_approval_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get("operator_real_source_human_intake_provenance_auth_quarantine_ready")
    )
    value_required_count = sum(1 for item in value_lint_records if item.get("required"))
    value_template_verified_count = sum(
        1
        for item in value_lint_records
        if item.get("required")
        and item.get("human_authored_value_packet_schema_lint_template_verified")
    )
    value_present_count = sum(
        1
        for item in value_lint_records
        if item.get("required") and item.get("human_authored_value_packet_present")
    )
    value_schema_match_count = sum(
        1
        for item in value_lint_records
        if item.get("required") and item.get("human_authored_value_packet_schema_match")
    )
    value_lint_ready_count = sum(
        1
        for item in value_lint_records
        if item.get("required")
        and item.get("human_authored_value_packet_schema_lint_ready")
    )
    value_hash_bound_count = sum(
        1
        for item in value_lint_records
        if item.get("required") and item.get("human_authored_value_packet_hash_bound")
    )
    source_required_count = record_count
    source_present_count = sum(
        1
        for item in source_records
        if item.get("source_material_intake_reference_present")
    )
    source_sha_declared_count = sum(
        1
        for item in source_records
        if item.get("source_material_intake_reference_sha_declared")
    )
    source_sha_verified_count = sum(
        1
        for item in source_records
        if item.get("source_material_intake_reference_sha_verified")
    )
    source_hash_ready_count = sum(
        1
        for item in source_records
        if item.get("source_material_intake_reference_hash_binding_ready")
    )
    receipt_required_count = record_count
    identity_marker_count = sum(
        1 for item in receipt_marker_records if item.get("operator_identity_marker_present")
    )
    authorization_marker_count = sum(
        1
        for item in receipt_marker_records
        if item.get("explicit_authorization_marker_present")
    )
    receipt_marker_ready_count = sum(
        1
        for item in receipt_marker_records
        if item.get("receipt_approval_operator_authorization_marker_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_marker_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1
        for item in verifier_records
        if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and value_lint_ready_count == value_required_count
        and source_present_count == source_required_count
        and source_sha_verified_count == source_required_count
        and source_hash_ready_count == source_required_count
        and identity_marker_count == receipt_required_count
        and authorization_marker_count == receipt_required_count
        and receipt_marker_ready_count == receipt_required_count
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "operator_real_source_human_intake_provenance_auth_quarantine_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "operator_real_source_human_intake_provenance_auth_quarantine_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_human_authored_value_packets_present_schema_matched_and_hash_bound",
        value_present_count == value_required_count
        and value_schema_match_count == value_required_count
        and value_hash_bound_count == value_required_count,
        (
            f"present={value_present_count} schema_match={value_schema_match_count} "
            f"hash_bound={value_hash_bound_count} required={value_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_source_material_intake_references_present_sha_verified_and_hash_bound",
        source_present_count == source_required_count
        and source_sha_verified_count == source_required_count
        and source_hash_ready_count == source_required_count,
        (
            f"present={source_present_count} sha_verified={source_sha_verified_count} "
            f"hash_bound={source_hash_ready_count} records={source_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_approval_operator_identity_and_authorization_markers_ready",
        identity_marker_count == receipt_required_count
        and authorization_marker_count == receipt_required_count
        and receipt_marker_ready_count == receipt_required_count
        and receipt_performed_count == 0,
        (
            f"identity={identity_marker_count} auth_marker={authorization_marker_count} "
            f"ready={receipt_marker_ready_count} performed={receipt_performed_count} "
            f"records={receipt_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_human_authored_value_source_reference_receipt_approval_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "human_authored_value_source_reference_receipt_approval_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_UPSTREAM_LINT"
    elif value_present_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_PACKET_MISSING"
    elif value_schema_match_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_SCHEMA_LINT"
    elif value_hash_bound_count != value_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_HASH_BINDING"
    elif source_present_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_MATERIAL_INTAKE_REFERENCE_MISSING"
    elif source_sha_verified_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_MATERIAL_INTAKE_REFERENCE_SHA"
    elif source_hash_ready_count != source_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_MATERIAL_INTAKE_REFERENCE_HASH_BINDING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_SOURCE_RECEIPT_ACTION_LEAK"
    elif identity_marker_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_OPERATOR_IDENTITY_MARKER_MISSING"
    elif authorization_marker_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_AUTHORIZATION_MARKER_MISSING"
    elif receipt_marker_ready_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_APPROVAL_OPERATOR_MARKER_QUARANTINE"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_SOURCE_RECEIPT_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_SOURCE_RECEIPT_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_AUTHORED_VALUE_SOURCE_REFERENCE_RECEIPT_APPROVAL_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_intake_provenance_auth_quarantine_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_intake_provenance_auth_quarantine_record_count"
                )
            ),
            "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_authored_value_source_reference_receipt_approval_count": hash_bound_count,
            "operator_real_source_human_authored_value_source_reference_receipt_approval_lint_ready_count": lint_ready_count,
            "upstream_human_intake_provenance_auth_ready_count": upstream_ready_count,
            "upstream_human_intake_provenance_auth_blocked_count": record_count
            - upstream_ready_count,
            "human_authored_value_packet_schema_lint_required_count": value_required_count,
            "human_authored_value_packet_schema_lint_template_verified_count": value_template_verified_count,
            "human_authored_value_packet_present_count": value_present_count,
            "human_authored_value_packet_missing_count": value_required_count
            - value_present_count,
            "human_authored_value_packet_schema_match_count": value_schema_match_count,
            "human_authored_value_packet_schema_lint_ready_count": value_lint_ready_count,
            "human_authored_value_packet_hash_bound_count": value_hash_bound_count,
            "source_material_intake_reference_required_count": source_required_count,
            "source_material_intake_reference_present_count": source_present_count,
            "source_material_intake_reference_missing_count": source_required_count
            - source_present_count,
            "source_material_intake_reference_sha_declared_count": source_sha_declared_count,
            "source_material_intake_reference_sha_verified_count": source_sha_verified_count,
            "source_material_intake_reference_hash_binding_ready_count": source_hash_ready_count,
            "source_material_intake_reference_hash_binding_unbound_count": source_required_count
            - source_hash_ready_count,
            "receipt_approval_operator_identity_marker_required_count": receipt_required_count,
            "receipt_approval_operator_identity_marker_present_count": identity_marker_count,
            "receipt_approval_authorization_marker_required_count": receipt_required_count,
            "receipt_approval_authorization_marker_present_count": authorization_marker_count,
            "receipt_approval_operator_authorization_marker_ready_count": receipt_marker_ready_count,
            "receipt_approval_operator_authorization_marker_quarantined_count": receipt_required_count
            - receipt_marker_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_authored_value_source_reference_receipt_approval_record_count": request_count,
            "request_operator_real_source_human_authored_value_source_reference_receipt_approval_ready_count": request_ready_count,
            "request_operator_real_source_human_authored_value_source_reference_receipt_approval_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies human-authored value packet schema lint, source-material intake reference sha binding, and receipt approval operator identity/authorization markers.",
            "Human-authored value schema lints, source reference sha verifiers, and receipt approval marker quarantines are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Authored Value Source Reference Receipt Approval Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_authored_value_source_reference_receipt_approval_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
