"""Human-input artifact source-path/value/checksum/signature verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-path-value-provenance-checksum-signature-identity-verifier-"
    "capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_capstone.v1"
)
ARTIFACT_SOURCE_VALUE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_human_input_artifact_source_path_value_provenance_lint_matrix.v1"
)
REQUIRED_VALUE_CHECKSUM_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_required_value_checksum_binding_quarantine.v1"
)
SOURCE_HANDOFF_TEMPLATE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_handoff_evidence_intake_packet_template_spec_verifier.v1"
)
RECEIPT_SIGNATURE_IDENTITY_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_receipt_signature_marker_identity_binding_quarantine.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_record_count",
    "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_count",
    "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_lint_ready_count",
    "upstream_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_ready_count",
    "upstream_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_blocked_count",
    "human_input_artifact_source_path_value_provenance_required_field_count",
    "human_input_artifact_source_path_value_provenance_template_verified_count",
    "human_input_artifact_source_path_value_provenance_field_present_count",
    "human_input_artifact_source_path_declared_count",
    "human_input_artifact_value_provenance_present_count",
    "human_input_artifact_source_path_value_provenance_ready_count",
    "required_value_checksum_binding_required_count",
    "required_value_checksum_binding_template_verified_count",
    "required_value_checksum_binding_value_present_count",
    "required_value_checksum_verified_count",
    "required_value_checksum_binding_present_count",
    "required_value_checksum_binding_ready_count",
    "source_handoff_evidence_intake_template_required_count",
    "source_handoff_evidence_intake_path_declared_count",
    "source_handoff_evidence_intake_template_verified_count",
    "source_handoff_evidence_intake_packet_present_count",
    "source_handoff_evidence_intake_packet_schema_valid_count",
    "source_handoff_operator_identity_present_count",
    "source_handoff_source_material_path_declared_count",
    "source_handoff_source_file_sha_verified_count",
    "source_handoff_evidence_intake_packet_template_ready_count",
    "receipt_signature_marker_identity_binding_required_count",
    "receipt_signature_payload_present_count",
    "receipt_signature_operator_identity_present_count",
    "receipt_signature_explicit_authorization_marker_present_count",
    "receipt_signature_authorization_marker_schema_valid_count",
    "receipt_signature_explicit_authorization_identity_binding_present_count",
    "receipt_signature_marker_identity_binding_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_record_count",
    "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready_count",
    "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _artifact_source_path_value_matrix(packet_record, payload_sha):
    source = dict(packet_record.get("human_input_artifact_completeness_matrix") or {})
    source_fields = [
        dict(item or {})
        for item in source.get("human_input_artifact_completeness_field_records") or []
        if isinstance(item, dict)
    ]
    field_records = []
    for item in source_fields:
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_manifest_path = item.get("expected_human_input_artifact_manifest_path") or source.get("expected_human_input_artifact_manifest_path") or ""
        expected_source_path = item.get("expected_human_input_artifact_source_path") or _sidecar(
            expected_manifest_path,
            f".{field}.source-path.json" if field else ".source-path.json",
        )
        template_verified = bool(
            item.get("human_input_artifact_completeness_field_template_verified")
            and expected_manifest_path
            and expected_source_path
            and str(expected_source_path).endswith(".json")
        )
        field_present = bool(item.get("human_input_artifact_completeness_field_present"))
        source_path_declared = bool(item.get("human_input_artifact_source_path_declared"))
        value_provenance_present = bool(
            item.get("human_input_artifact_value_provenance_present")
        )
        ready = bool(
            required
            and template_verified
            and field_present
            and source_path_declared
            and value_provenance_present
        )
        field_payload = {
            "schema_id": ARTIFACT_SOURCE_VALUE_SCHEMA_ID,
            "field": field,
            "expected_human_input_artifact_manifest_path": expected_manifest_path,
            "expected_human_input_artifact_source_path": expected_source_path,
            "parent_payload_sha256": payload_sha,
        }
        field_sha = _sha(field_payload)
        field_records.append(
            {
                "schema_id": ARTIFACT_SOURCE_VALUE_SCHEMA_ID,
                "human_input_artifact_source_path_value_provenance_lint_id": (
                    f"referee-repair-artifact-source-value-{field_sha[:16]}"
                ),
                "human_input_artifact_source_path_value_provenance_payload_sha256": field_sha,
                "field": field,
                "required": required,
                "expected_human_input_artifact_manifest_path": expected_manifest_path,
                "expected_human_input_artifact_source_path": expected_source_path,
                "human_input_artifact_source_path_value_provenance_template_verified": template_verified,
                "human_input_artifact_field_present": field_present,
                "human_input_artifact_source_path_declared": source_path_declared,
                "human_input_artifact_value_provenance_present": value_provenance_present,
                "human_input_artifact_source_path_value_provenance_ready": ready,
                "source_human_input_artifact_completeness_field_ready": bool(
                    item.get("human_input_artifact_completeness_field_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    required_count = sum(1 for item in field_records if item.get("required"))
    template_count = sum(
        1
        for item in field_records
        if item.get("required")
        and item.get("human_input_artifact_source_path_value_provenance_template_verified")
    )
    field_present_count = sum(
        1
        for item in field_records
        if item.get("required") and item.get("human_input_artifact_field_present")
    )
    source_path_count = sum(
        1
        for item in field_records
        if item.get("required") and item.get("human_input_artifact_source_path_declared")
    )
    value_provenance_count = sum(
        1
        for item in field_records
        if item.get("required")
        and item.get("human_input_artifact_value_provenance_present")
    )
    ready_count = sum(
        1
        for item in field_records
        if item.get("required")
        and item.get("human_input_artifact_source_path_value_provenance_ready")
    )
    ready = bool(
        required_count
        and template_count == required_count
        and field_present_count == required_count
        and source_path_count == required_count
        and value_provenance_count == required_count
        and ready_count == required_count
        and source.get("human_input_artifact_completeness_matrix_ready")
    )
    return {
        "schema_id": ARTIFACT_SOURCE_VALUE_SCHEMA_ID,
        "human_input_artifact_source_path_value_provenance_lint_matrix_id": (
            f"referee-repair-artifact-source-path-value-matrix-{payload_sha[:16]}"
        ),
        "expected_human_input_artifact_manifest_path": source.get("expected_human_input_artifact_manifest_path") or "",
        "human_input_artifact_source_path_value_provenance_required_field_count": required_count,
        "human_input_artifact_source_path_value_provenance_template_verified_count": template_count,
        "human_input_artifact_source_path_value_provenance_field_present_count": field_present_count,
        "human_input_artifact_source_path_declared_count": source_path_count,
        "human_input_artifact_value_provenance_present_count": value_provenance_count,
        "human_input_artifact_source_path_value_provenance_ready_count": ready_count,
        "human_input_artifact_source_path_value_provenance_field_records": field_records,
        "human_input_artifact_source_path_value_provenance_matrix_ready": ready,
        "source_human_input_artifact_completeness_matrix_ready": bool(
            source.get("human_input_artifact_completeness_matrix_ready")
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _required_value_checksum_binding_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get("authored_value_payload_required_value_lint_records") or []:
        if not isinstance(item, dict):
            continue
        required = bool(item.get("required"))
        expected_path = item.get("expected_human_authored_value_packet_path") or ""
        expected_binding_path = item.get("expected_required_value_checksum_binding_path") or _sidecar(
            expected_path,
            ".required-value-checksum-binding.json",
        )
        required_value_present = bool(
            item.get("authored_value_payload_required_value_present")
        )
        checksum_verified = bool(
            item.get("authored_value_payload_required_value_checksum_verified")
        )
        binding_present = bool(
            item.get("authored_value_required_value_checksum_binding_present")
            or item.get("authored_value_payload_required_value_checksum_binding_present")
            or item.get("required_value_checksum_binding_present")
        )
        template_verified = bool(
            item.get("authored_value_payload_required_value_template_verified")
            and expected_path
            and expected_binding_path
            and str(expected_binding_path).endswith(".json")
        )
        lint_ready = bool(item.get("authored_value_payload_required_value_lint_ready"))
        ready = bool(
            required
            and template_verified
            and lint_ready
            and required_value_present
            and checksum_verified
            and binding_present
        )
        payload = {
            "schema_id": REQUIRED_VALUE_CHECKSUM_SCHEMA_ID,
            "field": item.get("field") or "",
            "expected_human_authored_value_packet_path": expected_path,
            "expected_required_value_checksum_binding_path": expected_binding_path,
            "parent_payload_sha256": payload_sha,
        }
        value_sha = _sha(payload)
        records.append(
            {
                "schema_id": REQUIRED_VALUE_CHECKSUM_SCHEMA_ID,
                "required_value_checksum_binding_quarantine_id": (
                    f"referee-repair-required-value-checksum-binding-{value_sha[:16]}"
                ),
                "required_value_checksum_binding_payload_sha256": value_sha,
                "field": item.get("field") or "",
                "required": required,
                "expected_human_authored_value_packet_path": expected_path,
                "expected_required_value_checksum_binding_path": expected_binding_path,
                "required_value_checksum_binding_template_verified": template_verified,
                "required_value_present": required_value_present,
                "required_value_checksum_verified": checksum_verified,
                "required_value_checksum_binding_present": binding_present,
                "required_value_checksum_binding_ready": ready,
                "source_authored_value_payload_required_value_lint_payload_sha256": (
                    item.get("authored_value_payload_required_value_lint_payload_sha256")
                    or ""
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_handoff_template(packet_record, payload_sha):
    source = dict(packet_record.get("source_handoff_evidence_intake_quarantine") or {})
    expected_path = source.get("expected_source_handoff_evidence_intake_packet_path") or ""
    path_declared = bool(expected_path)
    path_json = str(expected_path).endswith(".json")
    template_verified = bool(
        source.get("source_handoff_evidence_intake_template_verified")
        and path_declared
        and path_json
    )
    present = bool(source.get("source_handoff_evidence_intake_packet_present"))
    schema_valid = bool(source.get("source_handoff_evidence_intake_packet_schema_valid"))
    identity = bool(source.get("source_handoff_operator_identity_present"))
    source_path = bool(source.get("source_handoff_source_material_path_declared"))
    sha_verified = bool(source.get("source_handoff_source_file_sha_verified"))
    upstream_ready = bool(source.get("source_handoff_upstream_provenance_ready"))
    ready = bool(
        template_verified
        and present
        and schema_valid
        and identity
        and source_path
        and sha_verified
        and source.get("source_handoff_evidence_intake_ready")
    )
    return {
        "schema_id": SOURCE_HANDOFF_TEMPLATE_SCHEMA_ID,
        "source_handoff_evidence_intake_packet_template_spec_verifier_id": (
            f"referee-repair-source-handoff-template-spec-{payload_sha[:16]}"
        ),
        "expected_source_handoff_evidence_intake_packet_path": expected_path,
        "source_handoff_evidence_intake_path_declared": path_declared,
        "source_handoff_evidence_intake_path_is_json": path_json,
        "source_handoff_evidence_intake_template_verified": template_verified,
        "source_handoff_evidence_intake_packet_present": present,
        "source_handoff_evidence_intake_packet_missing": not present,
        "source_handoff_evidence_intake_packet_schema_valid": schema_valid,
        "source_handoff_operator_identity_present": identity,
        "source_handoff_source_material_path_declared": source_path,
        "source_handoff_source_file_sha_verified": sha_verified,
        "source_handoff_upstream_provenance_ready": upstream_ready,
        "source_handoff_evidence_intake_packet_template_ready": ready,
        "source_handoff_evidence_intake_quarantine_id": (
            source.get("source_handoff_evidence_intake_quarantine_id") or ""
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_signature_identity_binding(packet_record, payload_sha):
    receipt = dict(
        packet_record.get("receipt_signature_authorization_payload_marker_schema_verifier")
        or {}
    )
    expected_path = (
        receipt.get("expected_receipt_signature_authorization_marker_schema_path")
        or ""
    )
    template_verified = bool(
        receipt.get("receipt_signature_authorization_marker_schema_template_verified")
        and expected_path
        and str(expected_path).endswith(".json")
    )
    payload_present = bool(receipt.get("receipt_signature_payload_present"))
    identity = bool(receipt.get("receipt_signature_operator_identity_present"))
    authorization = bool(
        receipt.get("receipt_signature_explicit_authorization_marker_present")
    )
    schema_valid = bool(
        receipt.get("receipt_signature_authorization_marker_schema_valid")
    )
    identity_binding = bool(
        receipt.get("receipt_signature_explicit_authorization_identity_binding_present")
        or receipt.get("receipt_signature_marker_identity_binding_present")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    ready = bool(
        template_verified
        and payload_present
        and identity
        and authorization
        and schema_valid
        and identity_binding
        and receipt.get("receipt_signature_authorization_marker_schema_ready")
        and not performed
    )
    return {
        "schema_id": RECEIPT_SIGNATURE_IDENTITY_SCHEMA_ID,
        "receipt_signature_marker_payload_explicit_authorization_identity_binding_quarantine_id": (
            f"referee-repair-receipt-signature-identity-binding-{payload_sha[:16]}"
        ),
        "expected_receipt_signature_authorization_marker_schema_path": expected_path,
        "receipt_signature_marker_identity_binding_template_verified": template_verified,
        "receipt_signature_payload_present": payload_present,
        "receipt_signature_operator_identity_present": identity,
        "receipt_signature_explicit_authorization_marker_present": authorization,
        "receipt_signature_authorization_marker_schema_valid": schema_valid,
        "receipt_signature_explicit_authorization_identity_binding_present": identity_binding,
        "receipt_signature_marker_identity_binding_ready": ready,
        "receipt_authorization_performed": performed,
        "receipt_signature_authorization_payload_marker_schema_verifier_id": (
            receipt.get("receipt_signature_authorization_payload_marker_schema_verifier_id")
            or ""
        ),
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    artifact_matrix = _artifact_source_path_value_matrix(packet_record, payload_sha)
    checksum_records = _required_value_checksum_binding_records(packet_record, payload_sha)
    source_template = _source_handoff_template(packet_record, payload_sha)
    receipt_binding = _receipt_signature_identity_binding(packet_record, payload_sha)
    checksum_required = sum(1 for item in checksum_records if item.get("required"))
    checksum_ready_count = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("required_value_checksum_binding_ready")
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_binding.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_lint_ready"
        )
        and artifact_matrix.get(
            "human_input_artifact_source_path_value_provenance_required_field_count"
        )
        and checksum_required
        and source_template.get("source_handoff_evidence_intake_template_verified")
        and receipt_binding.get("receipt_signature_marker_identity_binding_template_verified")
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_ready"
        )
        and artifact_matrix.get(
            "human_input_artifact_source_path_value_provenance_matrix_ready"
        )
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_template.get(
            "source_handoff_evidence_intake_packet_template_ready"
        )
        and receipt_binding.get("receipt_signature_marker_identity_binding_ready")
        and not consumable
    )
    blockers = []
    if not artifact_matrix.get(
        "human_input_artifact_source_path_value_provenance_matrix_ready"
    ):
        blockers.append("human_input_artifact_source_path_value_provenance_missing")
    if checksum_ready_count != checksum_required:
        blockers.append("required_value_checksum_binding_not_ready")
    if not source_template.get("source_handoff_evidence_intake_packet_template_ready"):
        blockers.append("source_handoff_evidence_intake_packet_template_not_ready")
    if not receipt_binding.get("receipt_signature_marker_identity_binding_ready"):
        blockers.append("receipt_signature_marker_identity_binding_not_ready")
    if consumable:
        blockers.append("human_input_artifact_source_value_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_id": (
            f"referee-repair-human-input-artifact-source-value-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_payload_sha256"
            )
            or ""
        ),
        "expected_packet_path": packet_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            packet_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "human_input_artifact_source_path_value_provenance_lint_matrix": artifact_matrix,
        "required_value_checksum_binding_quarantine_records": checksum_records,
        "required_value_checksum_binding_required_count": checksum_required,
        "required_value_checksum_binding_ready_count": checksum_ready_count,
        "source_handoff_evidence_intake_packet_template_spec_verifier": source_template,
        "receipt_signature_marker_payload_explicit_authorization_identity_binding_quarantine": receipt_binding,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready": ready,
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "human-input artifact source paths, value provenance, required-value checksum bindings, source handoff evidence intake, and receipt signature identity bindings are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide human-input artifact source paths and value provenance, required-value checksum bindings, source handoff evidence intake packets, and receipt signature explicit authorization identity bindings"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_id": (
            f"referee-repair-request-human-input-artifact-source-value-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready": ready,
        "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_capstone(
    operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_report,
    operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_records"
        )
        or []
    ]
    artifact_matrices = [
        record.get("human_input_artifact_source_path_value_provenance_lint_matrix")
        or {}
        for record in verifier_records
    ]
    artifact_field_records = [
        item
        for matrix in artifact_matrices
        for item in matrix.get(
            "human_input_artifact_source_path_value_provenance_field_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get("required_value_checksum_binding_quarantine_records")
        or []
    ]
    source_records = [
        record.get("source_handoff_evidence_intake_packet_template_spec_verifier") or {}
        for record in verifier_records
    ]
    receipt_records = [
        record.get(
            "receipt_signature_marker_payload_explicit_authorization_identity_binding_quarantine"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get(
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_ready"
        )
    )
    artifact_required_count = sum(
        1 for item in artifact_field_records if item.get("required")
    )
    artifact_template_count = sum(
        1
        for item in artifact_field_records
        if item.get("required")
        and item.get(
            "human_input_artifact_source_path_value_provenance_template_verified"
        )
    )
    artifact_field_present_count = sum(
        1
        for item in artifact_field_records
        if item.get("required") and item.get("human_input_artifact_field_present")
    )
    artifact_source_path_count = sum(
        1
        for item in artifact_field_records
        if item.get("required") and item.get("human_input_artifact_source_path_declared")
    )
    artifact_value_provenance_count = sum(
        1
        for item in artifact_field_records
        if item.get("required")
        and item.get("human_input_artifact_value_provenance_present")
    )
    artifact_ready_count = sum(
        1
        for item in artifact_field_records
        if item.get("required")
        and item.get("human_input_artifact_source_path_value_provenance_ready")
    )
    checksum_required_count = sum(1 for item in checksum_records if item.get("required"))
    checksum_template_count = sum(
        1
        for item in checksum_records
        if item.get("required")
        and item.get("required_value_checksum_binding_template_verified")
    )
    checksum_value_present_count = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("required_value_present")
    )
    checksum_verified_count = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("required_value_checksum_verified")
    )
    checksum_binding_present_count = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("required_value_checksum_binding_present")
    )
    checksum_ready_count = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("required_value_checksum_binding_ready")
    )
    source_required_count = record_count
    source_path_declared_count = sum(
        1 for item in source_records if item.get("source_handoff_evidence_intake_path_declared")
    )
    source_template_count = sum(
        1 for item in source_records if item.get("source_handoff_evidence_intake_template_verified")
    )
    source_present_count = sum(
        1 for item in source_records if item.get("source_handoff_evidence_intake_packet_present")
    )
    source_schema_count = sum(
        1 for item in source_records if item.get("source_handoff_evidence_intake_packet_schema_valid")
    )
    source_identity_count = sum(
        1 for item in source_records if item.get("source_handoff_operator_identity_present")
    )
    source_material_path_count = sum(
        1 for item in source_records if item.get("source_handoff_source_material_path_declared")
    )
    source_sha_count = sum(
        1 for item in source_records if item.get("source_handoff_source_file_sha_verified")
    )
    source_ready_count = sum(
        1
        for item in source_records
        if item.get("source_handoff_evidence_intake_packet_template_ready")
    )
    receipt_required_count = record_count
    receipt_payload_count = sum(
        1 for item in receipt_records if item.get("receipt_signature_payload_present")
    )
    receipt_identity_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_operator_identity_present")
    )
    receipt_authorization_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_explicit_authorization_marker_present")
    )
    receipt_schema_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_authorization_marker_schema_valid")
    )
    receipt_identity_binding_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_explicit_authorization_identity_binding_present")
    )
    receipt_ready_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_marker_identity_binding_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1
        for item in verifier_records
        if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and artifact_ready_count == artifact_required_count
        and checksum_ready_count == checksum_required_count
        and source_ready_count == source_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_human_input_artifact_source_paths_and_value_provenance_present",
        artifact_field_present_count == artifact_required_count
        and artifact_source_path_count == artifact_required_count
        and artifact_value_provenance_count == artifact_required_count
        and artifact_ready_count == artifact_required_count,
        (
            f"fields={artifact_field_present_count}/{artifact_required_count} "
            f"source_paths={artifact_source_path_count} "
            f"value_provenance={artifact_value_provenance_count} "
            f"ready={artifact_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_required_value_checksum_bindings_present",
        checksum_value_present_count == checksum_required_count
        and checksum_verified_count == checksum_required_count
        and checksum_binding_present_count == checksum_required_count
        and checksum_ready_count == checksum_required_count,
        (
            f"values={checksum_value_present_count}/{checksum_required_count} "
            f"checksums={checksum_verified_count} bindings={checksum_binding_present_count} "
            f"ready={checksum_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_source_handoff_evidence_intake_packets_template_and_identity_bound",
        source_present_count == source_required_count
        and source_schema_count == source_required_count
        and source_identity_count == source_required_count
        and source_material_path_count == source_required_count
        and source_sha_count == source_required_count
        and source_ready_count == source_required_count,
        (
            f"path={source_path_declared_count}/{source_required_count} "
            f"present={source_present_count} schema={source_schema_count} "
            f"identity={source_identity_count} source_path={source_material_path_count} "
            f"sha={source_sha_count} ready={source_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_signature_marker_identity_bindings_present",
        receipt_payload_count == receipt_required_count
        and receipt_identity_count == receipt_required_count
        and receipt_authorization_count == receipt_required_count
        and receipt_schema_count == receipt_required_count
        and receipt_identity_binding_count == receipt_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0,
        (
            f"payload={receipt_payload_count}/{receipt_required_count} "
            f"identity={receipt_identity_count} authorization={receipt_authorization_count} "
            f"schema={receipt_schema_count} identity_binding={receipt_identity_binding_count} "
            f"ready={receipt_ready_count} performed={receipt_performed_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_UPSTREAM_LINT"
    elif (
        artifact_field_present_count != artifact_required_count
        or artifact_source_path_count != artifact_required_count
        or artifact_value_provenance_count != artifact_required_count
        or artifact_ready_count != artifact_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_PATH_VALUE_PROVENANCE_MISSING"
    elif (
        checksum_value_present_count != checksum_required_count
        or checksum_verified_count != checksum_required_count
        or checksum_binding_present_count != checksum_required_count
        or checksum_ready_count != checksum_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_REQUIRED_VALUE_CHECKSUM_BINDING_MISSING"
    elif (
        source_present_count != source_required_count
        or source_schema_count != source_required_count
        or source_identity_count != source_required_count
        or source_material_path_count != source_required_count
        or source_sha_count != source_required_count
        or source_ready_count != source_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_HANDOFF_EVIDENCE_INTAKE_PACKET_MISSING"
    elif (
        receipt_payload_count != receipt_required_count
        or receipt_identity_count != receipt_required_count
        or receipt_authorization_count != receipt_required_count
        or receipt_schema_count != receipt_required_count
        or receipt_identity_binding_count != receipt_required_count
        or receipt_ready_count != receipt_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_SIGNATURE_MARKER_IDENTITY_BINDING_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_PATH_VALUE_PROVENANCE_CHECKSUM_SIGNATURE_IDENTITY_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_lint_ready_count": lint_ready_count,
            "upstream_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_ready_count": upstream_ready_count,
            "upstream_human_input_artifact_completeness_value_lint_handoff_intake_signature_marker_blocked_count": record_count
            - upstream_ready_count,
            "human_input_artifact_source_path_value_provenance_required_field_count": artifact_required_count,
            "human_input_artifact_source_path_value_provenance_template_verified_count": artifact_template_count,
            "human_input_artifact_source_path_value_provenance_field_present_count": artifact_field_present_count,
            "human_input_artifact_source_path_declared_count": artifact_source_path_count,
            "human_input_artifact_value_provenance_present_count": artifact_value_provenance_count,
            "human_input_artifact_source_path_value_provenance_ready_count": artifact_ready_count,
            "required_value_checksum_binding_required_count": checksum_required_count,
            "required_value_checksum_binding_template_verified_count": checksum_template_count,
            "required_value_checksum_binding_value_present_count": checksum_value_present_count,
            "required_value_checksum_verified_count": checksum_verified_count,
            "required_value_checksum_binding_present_count": checksum_binding_present_count,
            "required_value_checksum_binding_ready_count": checksum_ready_count,
            "source_handoff_evidence_intake_template_required_count": source_required_count,
            "source_handoff_evidence_intake_path_declared_count": source_path_declared_count,
            "source_handoff_evidence_intake_template_verified_count": source_template_count,
            "source_handoff_evidence_intake_packet_present_count": source_present_count,
            "source_handoff_evidence_intake_packet_schema_valid_count": source_schema_count,
            "source_handoff_operator_identity_present_count": source_identity_count,
            "source_handoff_source_material_path_declared_count": source_material_path_count,
            "source_handoff_source_file_sha_verified_count": source_sha_count,
            "source_handoff_evidence_intake_packet_template_ready_count": source_ready_count,
            "receipt_signature_marker_identity_binding_required_count": receipt_required_count,
            "receipt_signature_payload_present_count": receipt_payload_count,
            "receipt_signature_operator_identity_present_count": receipt_identity_count,
            "receipt_signature_explicit_authorization_marker_present_count": receipt_authorization_count,
            "receipt_signature_authorization_marker_schema_valid_count": receipt_schema_count,
            "receipt_signature_explicit_authorization_identity_binding_present_count": receipt_identity_binding_count,
            "receipt_signature_marker_identity_binding_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies human-input artifact source paths, value provenance, required-value checksum bindings, source handoff evidence intake packet templates, and receipt signature explicit authorization identity bindings.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Path Value Provenance Checksum Signature Identity Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_path_value_provenance_checksum_signature_identity_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
