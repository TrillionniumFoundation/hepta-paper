"""Human-input artifact source/value payload checkpoint/clock verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-checkpoint-clock-signature-chain-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_checkpoint_clock_signature_chain_verifier_capstone.v1"
)

UPSTREAM = "inclusion_root_freshness_signature_sequence"
UPSTREAM_LONG = (
    "operator_real_source_human_input_artifact_source_value_payload_"
    "inclusion_root_freshness_signature_sequence"
)
THIS = "checkpoint_clock_signature_chain"
THIS_LONG = (
    "operator_real_source_human_input_artifact_source_value_payload_"
    "checkpoint_clock_signature_chain"
)

STATE_KEY = (
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_"
    "checkpoint_clock_signature_chain_verifier_state"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    STATE_KEY,
    "report_schema",
    "summary",
    f"{THIS_LONG}_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    f"{UPSTREAM_LONG}_verifier_record_count",
    f"{THIS_LONG}_verifier_record_count",
    f"hash_bound_{THIS_LONG}_count",
    f"{THIS_LONG}_lint_ready_count",
    "upstream_payload_inclusion_root_freshness_signature_sequence_ready_count",
    "upstream_payload_inclusion_root_freshness_signature_sequence_blocked_count",
    "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_required_count",
    "source_inclusion_log_checkpoint_signature_present_count",
    "source_inclusion_log_checkpoint_signature_valid_count",
    "source_root_consistency_operator_public_key_present_count",
    "source_root_consistency_operator_public_key_valid_count",
    "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready_count",
    "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_required_count",
    "value_timestamp_signer_certificate_chain_subject_present_count",
    "value_timestamp_signer_certificate_chain_subject_valid_count",
    "value_root_freshness_clock_evidence_present_count",
    "value_root_freshness_clock_evidence_valid_count",
    "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready_count",
    "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_required_count",
    "checksum_merkle_inclusion_proof_log_checkpoint_present_count",
    "checksum_merkle_inclusion_proof_log_checkpoint_valid_count",
    "checksum_revocation_authority_signature_freshness_present_count",
    "checksum_revocation_authority_signature_freshness_valid_count",
    "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready_count",
    "source_checkpoint_public_key_certificate_session_monotonicity_ledger_required_count",
    "source_checkpoint_public_key_certificate_present_count",
    "source_checkpoint_public_key_certificate_valid_count",
    "source_session_monotonicity_ledger_present_count",
    "source_session_monotonicity_ledger_valid_count",
    "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready_count",
    "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_required_count",
    "receipt_revocation_authority_freshness_certificate_present_count",
    "receipt_revocation_authority_freshness_certificate_valid_count",
    "receipt_timestamp_signer_signature_chain_present_count",
    "receipt_timestamp_signer_signature_chain_valid_count",
    "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready_count",
    "receipt_authorization_performed_count",
    f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_record_count",
    f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_ready_count",
    f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    f"{THIS_LONG}_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(f"{UPSTREAM_LONG}_verifier_records") or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(f"{UPSTREAM_LONG}_records") or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _sum(records, key):
    return sum(1 for item in records if item.get(key))


def _field_marker_records(
    packet_record,
    payload_sha,
    source_key,
    id_prefix,
    parent_expected_key,
    expected_key,
    sidecar_suffix,
    upstream_ready_key,
    upstream_presence_keys,
    present_key_a,
    valid_key_a,
    present_key_b,
    valid_key_b,
    ready_key,
):
    records = []
    for item in packet_record.get(source_key) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_parent_path = item.get(parent_expected_key) or ""
        expected_path = item.get(expected_key) or _sidecar(
            expected_parent_path, sidecar_suffix
        )
        upstream_ready = bool(item.get(upstream_ready_key))
        marker_a = bool(item.get(present_key_a))
        marker_a_valid = bool(item.get(valid_key_a))
        marker_b = bool(item.get(present_key_b))
        marker_b_valid = bool(item.get(valid_key_b))
        template_verified = bool(
            expected_parent_path
            and expected_path
            and str(expected_parent_path).endswith(".json")
            and str(expected_path).endswith(".json")
        )
        upstream_presence_ready = all(bool(item.get(key)) for key in upstream_presence_keys)
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and upstream_presence_ready
            and marker_a
            and marker_a_valid
            and marker_b
            and marker_b_valid
        )
        record_sha = _sha(
            {
                "field": field,
                parent_expected_key: expected_parent_path,
                expected_key: expected_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                f"{ready_key}_id": f"{id_prefix}-{field}-{record_sha[:16]}",
                "field": field,
                "required": required,
                parent_expected_key: expected_parent_path,
                expected_key: expected_path,
                f"{ready_key}_template_verified": template_verified,
                upstream_ready_key: upstream_ready,
                present_key_a: marker_a,
                valid_key_a: marker_a_valid,
                present_key_b: marker_b,
                valid_key_b: marker_b_valid,
                ready_key: ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _singleton_marker_record(
    packet_record,
    payload_sha,
    source_key,
    id_value,
    parent_expected_key,
    expected_key,
    sidecar_suffix,
    upstream_ready_key,
    upstream_presence_keys,
    present_key_a,
    valid_key_a,
    present_key_b,
    valid_key_b,
    ready_key,
    performed_keys=None,
):
    item = dict(packet_record.get(source_key) or {})
    expected_parent_path = item.get(parent_expected_key) or ""
    expected_path = item.get(expected_key) or _sidecar(expected_parent_path, sidecar_suffix)
    upstream_ready = bool(item.get(upstream_ready_key))
    marker_a = bool(item.get(present_key_a))
    marker_a_valid = bool(item.get(valid_key_a))
    marker_b = bool(item.get(present_key_b))
    marker_b_valid = bool(item.get(valid_key_b))
    performed = any(bool(item.get(key) or packet_record.get(key)) for key in (performed_keys or []))
    template_verified = bool(
        expected_parent_path
        and expected_path
        and str(expected_parent_path).endswith(".json")
        and str(expected_path).endswith(".json")
    )
    upstream_presence_ready = all(bool(item.get(key)) for key in upstream_presence_keys)
    ready = bool(
        template_verified
        and upstream_ready
        and upstream_presence_ready
        and marker_a
        and marker_a_valid
        and marker_b
        and marker_b_valid
        and not performed
    )
    return {
        f"{ready_key}_id": f"{id_value}-{payload_sha[:16]}",
        "required": True,
        parent_expected_key: expected_parent_path,
        expected_key: expected_path,
        f"{ready_key}_template_verified": template_verified,
        upstream_ready_key: upstream_ready,
        present_key_a: marker_a,
        valid_key_a: marker_a_valid,
        present_key_b: marker_b,
        valid_key_b: marker_b_valid,
        ready_key: ready,
        "receipt_authorization_performed": performed,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload_sha = _sha(
        {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_human_input_artifact_source_value_payload_checkpoint_clock_signature_chain_record.v1"
            ),
            "request_id": packet_record.get("request_id"),
            "slug": packet_record.get("slug") or "",
            "packet_type": packet_record.get("packet_type") or "",
            "parent_payload_sha256": packet_record.get(f"{UPSTREAM_LONG}_payload_sha256")
            or "",
        }
    )
    source_records = _field_marker_records(
        packet_record,
        payload_sha,
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_records",
        "referee-repair-source-inclusion-checkpoint-key",
        "expected_source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_path",
        "expected_source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_path",
        ".checkpoint-signature-root-consistency-operator-public-key.json",
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready",
        [
            "source_signed_root_transparency_inclusion_log_checkpoint_present",
            "source_signed_root_transparency_root_consistency_present",
        ],
        "source_inclusion_log_checkpoint_signature_present",
        "source_inclusion_log_checkpoint_signature_valid",
        "source_root_consistency_operator_public_key_present",
        "source_root_consistency_operator_public_key_valid",
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready",
    )
    value_records = _field_marker_records(
        packet_record,
        payload_sha,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_records",
        "referee-repair-value-timestamp-clock-evidence",
        "expected_value_timestamp_signer_certificate_chain_root_freshness_authority_path",
        "expected_value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_path",
        ".timestamp-signer-subject-root-freshness-clock-evidence.json",
        "value_timestamp_signer_certificate_chain_root_freshness_authority_ready",
        [
            "value_timestamp_signer_certificate_chain_present",
            "value_root_freshness_authority_present",
        ],
        "value_timestamp_signer_certificate_chain_subject_present",
        "value_timestamp_signer_certificate_chain_subject_valid",
        "value_root_freshness_clock_evidence_present",
        "value_root_freshness_clock_evidence_valid",
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready",
    )
    checksum_records = _field_marker_records(
        packet_record,
        payload_sha,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_records",
        "referee-repair-checksum-merkle-log-signature",
        "expected_checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_path",
        "expected_checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_path",
        ".log-checkpoint-revocation-authority-signature-freshness.json",
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready",
        [
            "checksum_transparency_inclusion_merkle_proof_present",
            "checksum_revocation_authority_signature_present",
        ],
        "checksum_merkle_inclusion_proof_log_checkpoint_present",
        "checksum_merkle_inclusion_proof_log_checkpoint_valid",
        "checksum_revocation_authority_signature_freshness_present",
        "checksum_revocation_authority_signature_freshness_valid",
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready",
    )
    source_ledger = _singleton_marker_record(
        packet_record,
        payload_sha,
        "source_checkpoint_signature_public_key_session_sequence_monotonicity",
        "referee-repair-source-checkpoint-ledger",
        "expected_source_checkpoint_signature_public_key_session_sequence_monotonicity_path",
        "expected_source_checkpoint_public_key_certificate_session_monotonicity_ledger_path",
        ".checkpoint-public-key-certificate-session-monotonicity-ledger.json",
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready",
        [
            "source_checkpoint_signature_public_key_present",
            "source_session_sequence_monotonicity_present",
        ],
        "source_checkpoint_public_key_certificate_present",
        "source_checkpoint_public_key_certificate_valid",
        "source_session_monotonicity_ledger_present",
        "source_session_monotonicity_ledger_valid",
        "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready",
    )
    receipt_signature_chain = _singleton_marker_record(
        packet_record,
        payload_sha,
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer",
        "referee-repair-receipt-signature-chain",
        "expected_receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_path",
        "expected_receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_path",
        ".revocation-authority-freshness-certificate-timestamp-signer-signature-chain.json",
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready",
        [
            "receipt_certificate_chain_revocation_authority_freshness_present",
            "receipt_certificate_chain_revocation_timestamp_signer_present",
        ],
        "receipt_revocation_authority_freshness_certificate_present",
        "receipt_revocation_authority_freshness_certificate_valid",
        "receipt_timestamp_signer_signature_chain_present",
        "receipt_timestamp_signer_signature_chain_valid",
        "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready",
        performed_keys=["receipt_authorization_performed"],
    )
    source_required = _required_count(source_records)
    value_required = _required_count(value_records)
    checksum_required = _required_count(checksum_records)
    source_ready = _count(
        source_records,
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready",
    )
    value_ready = _count(
        value_records,
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready",
    )
    checksum_ready = _count(
        checksum_records,
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_signature_chain.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(payload_sha and packet_record.get(f"{UPSTREAM_LONG}_hash_bound"))
    lint_ready = bool(
        hash_bound
        and packet_record.get(f"{UPSTREAM_LONG}_lint_ready")
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(f"{UPSTREAM_LONG}_ready")
        and source_ready == source_required
        and value_ready == value_required
        and checksum_ready == checksum_required
        and source_ledger.get(
            "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready"
        )
        and receipt_signature_chain.get(
            "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_missing")
    if value_ready != value_required:
        blockers.append("value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_missing")
    if not source_ledger.get(
        "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready"
    ):
        blockers.append("source_checkpoint_public_key_certificate_session_monotonicity_ledger_missing")
    if not receipt_signature_chain.get(
        "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready"
    ):
        blockers.append("receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_missing")
    if consumable:
        blockers.append("payload_checkpoint_clock_signature_chain_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        f"{THIS_LONG}_verifier_id": (
            f"referee-repair-human-input-source-value-payload-checkpoint-clock-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        f"{THIS_LONG}_payload_sha256": payload_sha,
        f"{THIS_LONG}_hash_bound": hash_bound,
        f"{THIS_LONG}_lint_ready": lint_ready,
        f"{UPSTREAM_LONG}_payload_sha256": packet_record.get(f"{UPSTREAM_LONG}_payload_sha256")
        or "",
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_records": source_records,
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_required_count": source_required,
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready_count": source_ready,
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_records": value_records,
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_required_count": value_required,
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready_count": value_ready,
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_records": checksum_records,
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_required_count": checksum_required,
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready_count": checksum_ready,
        "source_checkpoint_public_key_certificate_session_monotonicity_ledger": source_ledger,
        "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain": receipt_signature_chain,
        "receipt_authorization_performed": receipt_performed,
        f"{THIS_LONG}_ready": ready,
        f"{THIS_LONG}_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "checkpoint/clock/signature-chain verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source checkpoint signature/operator public-key, value certificate subject/clock evidence, checksum Merkle log checkpoint/signature freshness, source public-key certificate/session monotonicity ledger, and receipt freshness certificate/signature-chain markers"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [item for item in verifier_records if not item.get(f"{THIS_LONG}_ready")]
    payload_sha = _sha(
        {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_checkpoint_clock_signature_chain_record.v1"
            ),
            "request_id": request_id,
            "slug": slug,
            "payload_sha256s": [item.get(f"{THIS_LONG}_payload_sha256") for item in verifier_records],
        }
    )
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_id": (
            f"referee-repair-request-human-input-source-value-payload-checkpoint-clock-{request_id}-{payload_sha[:16]}"
        ),
        f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_payload_sha256": payload_sha,
        f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_hash_bound": bool(
            payload_sha and all(item.get(f"{THIS_LONG}_hash_bound") for item in verifier_records)
        ),
        f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_lint_ready": bool(
            payload_sha and all(item.get(f"{THIS_LONG}_lint_ready") for item in verifier_records)
        ),
        f"{THIS_LONG}_record_count": len(verifier_records),
        f"{THIS_LONG}_ready_count": sum(1 for item in verifier_records if item.get(f"{THIS_LONG}_ready")),
        f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_ready": ready,
        f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        f"{THIS_LONG}_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_checkpoint_clock_signature_chain_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                f"request_operator_real_source_human_input_artifact_source_value_payload_{UPSTREAM}_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                f"request_operator_real_source_human_input_artifact_source_value_payload_{UPSTREAM}_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(record.get(f"{UPSTREAM_LONG}_lint_ready") for record in upstream_packet_records)
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(f"{THIS_LONG}_records") or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_records"
        )
        or []
    ]
    source_ledger_records = [
        record.get("source_checkpoint_public_key_certificate_session_monotonicity_ledger")
        or {}
        for record in verifier_records
    ]
    receipt_records = [
        record.get(
            "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = _sum(verifier_records, f"{THIS_LONG}_hash_bound")
    lint_ready_count = _sum(verifier_records, f"{THIS_LONG}_lint_ready")
    upstream_ready_count = _sum(upstream_packet_records, f"{UPSTREAM_LONG}_ready")
    source_required = _required_count(source_records)
    source_signature_count = _count(source_records, "source_inclusion_log_checkpoint_signature_present")
    source_signature_valid_count = _count(source_records, "source_inclusion_log_checkpoint_signature_valid")
    source_key_count = _count(source_records, "source_root_consistency_operator_public_key_present")
    source_key_valid_count = _count(source_records, "source_root_consistency_operator_public_key_valid")
    source_ready_count = _count(
        source_records,
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready",
    )
    value_required = _required_count(value_records)
    value_subject_count = _count(value_records, "value_timestamp_signer_certificate_chain_subject_present")
    value_subject_valid_count = _count(value_records, "value_timestamp_signer_certificate_chain_subject_valid")
    value_clock_count = _count(value_records, "value_root_freshness_clock_evidence_present")
    value_clock_valid_count = _count(value_records, "value_root_freshness_clock_evidence_valid")
    value_ready_count = _count(
        value_records,
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready",
    )
    checksum_required = _required_count(checksum_records)
    checksum_log_count = _count(checksum_records, "checksum_merkle_inclusion_proof_log_checkpoint_present")
    checksum_log_valid_count = _count(checksum_records, "checksum_merkle_inclusion_proof_log_checkpoint_valid")
    checksum_freshness_count = _count(checksum_records, "checksum_revocation_authority_signature_freshness_present")
    checksum_freshness_valid_count = _count(checksum_records, "checksum_revocation_authority_signature_freshness_valid")
    checksum_ready_count = _count(
        checksum_records,
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready",
    )
    source_ledger_required = record_count
    source_cert_count = _sum(source_ledger_records, "source_checkpoint_public_key_certificate_present")
    source_cert_valid_count = _sum(source_ledger_records, "source_checkpoint_public_key_certificate_valid")
    source_ledger_count = _sum(source_ledger_records, "source_session_monotonicity_ledger_present")
    source_ledger_valid_count = _sum(source_ledger_records, "source_session_monotonicity_ledger_valid")
    source_ledger_ready_count = _sum(
        source_ledger_records,
        "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready",
    )
    receipt_required = record_count
    receipt_cert_count = _sum(receipt_records, "receipt_revocation_authority_freshness_certificate_present")
    receipt_cert_valid_count = _sum(receipt_records, "receipt_revocation_authority_freshness_certificate_valid")
    receipt_chain_count = _sum(receipt_records, "receipt_timestamp_signer_signature_chain_present")
    receipt_chain_valid_count = _sum(receipt_records, "receipt_timestamp_signer_signature_chain_valid")
    receipt_ready_count = _sum(
        receipt_records,
        "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready",
    )
    receipt_performed_count = _sum(receipt_records, "receipt_authorization_performed")
    expected_file_creation_count = _sum(verifier_records, "expected_packet_file_creation_performed")
    receipt_creation_count = _sum(verifier_records, "redrive_receipt_creation_performed")
    evidence_release_count = _sum(verifier_records, "evidence_release_performed")
    promoted_count = _sum(verifier_records, "repair_evidence_promoted")
    closure_count = _sum(verifier_records, "request_closure_performed")
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_ledger_ready_count == source_ledger_required
        and receipt_ready_count == receipt_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_inclusion_root_freshness_signature_sequence_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_inclusion_root_freshness_signature_sequence_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} checkpoint_signatures={source_signature_count} public_keys={source_key_count}",
    )
    _add_check(
        checks,
        "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} subjects={value_subject_count} clock_evidence={value_clock_count}",
    )
    _add_check(
        checks,
        "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} log_checkpoints={checksum_log_count} freshness={checksum_freshness_count}",
    )
    _add_check(
        checks,
        "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready",
        source_ledger_required > 0 and source_ledger_ready_count == source_ledger_required,
        f"ready={source_ledger_ready_count}/{source_ledger_required} certs={source_cert_count} ledgers={source_ledger_count}",
    )
    _add_check(
        checks,
        "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready",
        receipt_required > 0 and receipt_ready_count == receipt_required,
        f"ready={receipt_ready_count}/{receipt_required} certs={receipt_cert_count} chains={receipt_chain_count}",
    )
    _add_check(
        checks,
        "all_request_payload_checkpoint_clock_signature_chain_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_checkpoint_clock_signature_chain_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_CHECKPOINT_CLOCK_SIGNATURE_CHAIN_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_CHECKPOINT_CLOCK_SIGNATURE_CHAIN_UPSTREAM_LINT"
    elif (
        source_signature_count != source_required
        or source_signature_valid_count != source_required
        or source_key_count != source_required
        or source_key_valid_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_INCLUSION_LOG_CHECKPOINT_SIGNATURE_ROOT_CONSISTENCY_OPERATOR_PUBLIC_KEY_MISSING"
    elif (
        value_subject_count != value_required
        or value_subject_valid_count != value_required
        or value_clock_count != value_required
        or value_clock_valid_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_TIMESTAMP_SIGNER_CERTIFICATE_CHAIN_SUBJECT_ROOT_FRESHNESS_CLOCK_EVIDENCE_MISSING"
    elif (
        checksum_log_count != checksum_required
        or checksum_log_valid_count != checksum_required
        or checksum_freshness_count != checksum_required
        or checksum_freshness_valid_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_MERKLE_INCLUSION_PROOF_LOG_CHECKPOINT_REVOCATION_AUTHORITY_SIGNATURE_FRESHNESS_MISSING"
    elif (
        source_cert_count != source_ledger_required
        or source_cert_valid_count != source_ledger_required
        or source_ledger_count != source_ledger_required
        or source_ledger_valid_count != source_ledger_required
        or source_ledger_ready_count != source_ledger_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_CHECKPOINT_PUBLIC_KEY_CERTIFICATE_SESSION_MONOTONICITY_LEDGER_MISSING"
    elif (
        receipt_cert_count != receipt_required
        or receipt_cert_valid_count != receipt_required
        or receipt_chain_count != receipt_required
        or receipt_chain_valid_count != receipt_required
        or receipt_ready_count != receipt_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_REVOCATION_AUTHORITY_FRESHNESS_CERTIFICATE_TIMESTAMP_SIGNER_SIGNATURE_CHAIN_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_CHECKPOINT_CLOCK_SIGNATURE_CHAIN_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_CHECKPOINT_CLOCK_SIGNATURE_CHAIN_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_CHECKPOINT_CLOCK_SIGNATURE_CHAIN_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_CHECKPOINT_CLOCK_SIGNATURE_CHAIN_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        STATE_KEY: state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            f"{UPSTREAM_LONG}_verifier_record_count": _int(
                upstream_summary.get(f"{UPSTREAM_LONG}_verifier_record_count")
            ),
            f"{THIS_LONG}_verifier_record_count": record_count,
            f"hash_bound_{THIS_LONG}_count": hash_bound_count,
            f"{THIS_LONG}_lint_ready_count": lint_ready_count,
            "upstream_payload_inclusion_root_freshness_signature_sequence_ready_count": upstream_ready_count,
            "upstream_payload_inclusion_root_freshness_signature_sequence_blocked_count": record_count - upstream_ready_count,
            "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_required_count": source_required,
            "source_inclusion_log_checkpoint_signature_present_count": source_signature_count,
            "source_inclusion_log_checkpoint_signature_valid_count": source_signature_valid_count,
            "source_root_consistency_operator_public_key_present_count": source_key_count,
            "source_root_consistency_operator_public_key_valid_count": source_key_valid_count,
            "source_inclusion_log_checkpoint_signature_root_consistency_operator_public_key_ready_count": source_ready_count,
            "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_required_count": value_required,
            "value_timestamp_signer_certificate_chain_subject_present_count": value_subject_count,
            "value_timestamp_signer_certificate_chain_subject_valid_count": value_subject_valid_count,
            "value_root_freshness_clock_evidence_present_count": value_clock_count,
            "value_root_freshness_clock_evidence_valid_count": value_clock_valid_count,
            "value_timestamp_signer_certificate_chain_subject_root_freshness_clock_evidence_ready_count": value_ready_count,
            "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_required_count": checksum_required,
            "checksum_merkle_inclusion_proof_log_checkpoint_present_count": checksum_log_count,
            "checksum_merkle_inclusion_proof_log_checkpoint_valid_count": checksum_log_valid_count,
            "checksum_revocation_authority_signature_freshness_present_count": checksum_freshness_count,
            "checksum_revocation_authority_signature_freshness_valid_count": checksum_freshness_valid_count,
            "checksum_merkle_inclusion_proof_log_checkpoint_revocation_authority_signature_freshness_ready_count": checksum_ready_count,
            "source_checkpoint_public_key_certificate_session_monotonicity_ledger_required_count": source_ledger_required,
            "source_checkpoint_public_key_certificate_present_count": source_cert_count,
            "source_checkpoint_public_key_certificate_valid_count": source_cert_valid_count,
            "source_session_monotonicity_ledger_present_count": source_ledger_count,
            "source_session_monotonicity_ledger_valid_count": source_ledger_valid_count,
            "source_checkpoint_public_key_certificate_session_monotonicity_ledger_ready_count": source_ledger_ready_count,
            "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_required_count": receipt_required,
            "receipt_revocation_authority_freshness_certificate_present_count": receipt_cert_count,
            "receipt_revocation_authority_freshness_certificate_valid_count": receipt_cert_valid_count,
            "receipt_timestamp_signer_signature_chain_present_count": receipt_chain_count,
            "receipt_timestamp_signer_signature_chain_valid_count": receipt_chain_valid_count,
            "receipt_revocation_authority_freshness_certificate_timestamp_signer_signature_chain_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_record_count": request_count,
            f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_ready_count": request_ready_count,
            f"request_operator_real_source_human_input_artifact_source_value_payload_{THIS}_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            f"{THIS_LONG}_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        f"{THIS_LONG}_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source inclusion-log checkpoint signatures and root-consistency operator public keys, value timestamp-signer certificate-chain subject/root-freshness clock evidence, checksum Merkle-inclusion proof log checkpoints and revocation-authority signature freshness, source checkpoint public-key certificate/session monotonicity ledgers, and receipt revocation-authority freshness certificates plus timestamp-signer signature chains.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Checkpoint Clock Signature Chain Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get(STATE_KEY, '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
