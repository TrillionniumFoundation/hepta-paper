"""Human-input artifact source/value payload digest chain verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-digest-chain-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_capstone.v1"
)
SOURCE_CONTENT_PROVENANCE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_content_payload_hash_materialization_provenance_marker.v1"
)
VALUE_PUBLIC_IDENTITY_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_value_operator_signature_public_identity_hash_binding_verifier.v1"
)
CHECKSUM_EXPECTED_DIGEST_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_checksum_sha_match_expected_digest_source_packet_identity_verifier.v1"
)
SOURCE_HANDOFF_ATTESTATION_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_handoff_payload_marker_operator_signature_source_file_hash_attestation.v1"
)
RECEIPT_DIGEST_CHAIN_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_receipt_authorization_binding_operator_signature_payload_digest_chain.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_digest_chain_count",
    "operator_real_source_human_input_artifact_source_value_payload_digest_chain_lint_ready_count",
    "upstream_payload_hash_signature_binding_ready_count",
    "upstream_payload_hash_signature_binding_blocked_count",
    "source_content_materialization_provenance_required_count",
    "source_path_packet_content_payload_hash_present_count",
    "source_path_packet_content_payload_hash_sha_match_count",
    "source_content_materialization_provenance_marker_present_count",
    "source_content_materialization_provenance_marker_schema_valid_count",
    "source_content_materialization_provenance_marker_hash_bound_count",
    "source_content_materialization_provenance_ready_count",
    "value_operator_signature_public_identity_required_count",
    "value_identity_operator_signature_present_count",
    "value_operator_signature_public_identity_present_count",
    "value_operator_signature_public_identity_hash_bound_count",
    "value_operator_signature_hash_binding_verified_count",
    "value_operator_signature_public_identity_ready_count",
    "checksum_expected_digest_source_identity_required_count",
    "checksum_explicit_payload_hash_sha_match_count",
    "checksum_expected_digest_present_count",
    "checksum_expected_digest_sha_match_count",
    "checksum_source_packet_identity_present_count",
    "checksum_source_packet_identity_hash_bound_count",
    "checksum_expected_digest_source_identity_ready_count",
    "source_handoff_operator_signature_attestation_required_count",
    "source_handoff_identity_sha_payload_marker_payload_hash_sha_match_count",
    "source_handoff_payload_marker_operator_signature_present_count",
    "source_handoff_payload_marker_operator_signature_bound_count",
    "source_handoff_source_file_hash_attestation_present_count",
    "source_handoff_source_file_hash_attestation_sha_match_count",
    "source_handoff_operator_signature_attestation_ready_count",
    "receipt_authorization_digest_chain_required_count",
    "receipt_identity_marker_operator_signature_payload_hash_sha_match_count",
    "receipt_authorization_binding_operator_signature_present_count",
    "receipt_authorization_binding_operator_signature_bound_count",
    "receipt_payload_digest_chain_present_count",
    "receipt_payload_digest_chain_sha_match_count",
    "receipt_payload_digest_chain_authorization_bound_count",
    "receipt_authorization_digest_chain_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _source_content_provenance_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_path_packet_content_payload_hash_schema_validator_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_hash_path = item.get("expected_source_path_packet_content_payload_hash_path") or ""
        expected_marker_path = (
            item.get("expected_source_content_materialization_provenance_marker_path")
            or _sidecar(expected_hash_path, ".materialization-provenance.json")
        )
        payload_hash_present = bool(item.get("source_path_packet_content_payload_hash_present"))
        payload_hash_sha = bool(item.get("source_path_packet_content_payload_hash_sha_match"))
        marker_present = bool(
            item.get("source_content_materialization_provenance_marker_present")
        )
        marker_schema = bool(
            item.get("source_content_materialization_provenance_marker_schema_valid")
        )
        marker_hash = bool(
            item.get("source_content_materialization_provenance_marker_hash_bound")
        )
        template_verified = bool(
            expected_hash_path
            and expected_marker_path
            and str(expected_hash_path).endswith(".json")
            and str(expected_marker_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("source_path_content_payload_hash_schema_ready")
            and payload_hash_present
            and payload_hash_sha
            and marker_present
            and marker_schema
            and marker_hash
        )
        payload = {
            "schema_id": SOURCE_CONTENT_PROVENANCE_SCHEMA_ID,
            "field": field,
            "expected_source_path_packet_content_payload_hash_path": expected_hash_path,
            "expected_source_content_materialization_provenance_marker_path": expected_marker_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": SOURCE_CONTENT_PROVENANCE_SCHEMA_ID,
                "source_content_payload_hash_materialization_provenance_marker_id": (
                    f"referee-repair-source-content-provenance-{record_sha[:16]}"
                ),
                "source_content_payload_hash_materialization_provenance_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_path_packet_content_payload_hash_path": expected_hash_path,
                "expected_source_content_materialization_provenance_marker_path": expected_marker_path,
                "source_content_materialization_provenance_template_verified": template_verified,
                "source_path_packet_content_payload_hash_present": payload_hash_present,
                "source_path_packet_content_payload_hash_sha_match": payload_hash_sha,
                "source_content_materialization_provenance_marker_present": marker_present,
                "source_content_materialization_provenance_marker_schema_valid": marker_schema,
                "source_content_materialization_provenance_marker_hash_bound": marker_hash,
                "source_content_materialization_provenance_ready": ready,
                "upstream_source_path_content_payload_hash_schema_ready": bool(
                    item.get("source_path_content_payload_hash_schema_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_public_identity_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get("value_identity_signature_source_binding_marker_records") or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_signature_path = item.get("expected_value_identity_operator_signature_path") or ""
        expected_identity_path = (
            item.get("expected_value_operator_signature_public_identity_path")
            or _sidecar(expected_signature_path, ".public-identity.json")
        )
        signature_present = bool(item.get("value_identity_operator_signature_present"))
        public_identity = bool(item.get("value_operator_signature_public_identity_present"))
        public_identity_hash = bool(
            item.get("value_operator_signature_public_identity_hash_bound")
        )
        hash_binding = bool(item.get("value_operator_signature_hash_binding_verified"))
        template_verified = bool(
            expected_signature_path
            and expected_identity_path
            and str(expected_signature_path).endswith(".json")
            and str(expected_identity_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("value_identity_signature_source_binding_ready")
            and signature_present
            and public_identity
            and public_identity_hash
            and hash_binding
        )
        payload = {
            "schema_id": VALUE_PUBLIC_IDENTITY_SCHEMA_ID,
            "field": field,
            "expected_value_identity_operator_signature_path": expected_signature_path,
            "expected_value_operator_signature_public_identity_path": expected_identity_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": VALUE_PUBLIC_IDENTITY_SCHEMA_ID,
                "value_operator_signature_public_identity_hash_binding_verifier_id": (
                    f"referee-repair-value-public-identity-{record_sha[:16]}"
                ),
                "value_operator_signature_public_identity_hash_binding_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_identity_operator_signature_path": expected_signature_path,
                "expected_value_operator_signature_public_identity_path": expected_identity_path,
                "value_operator_signature_public_identity_template_verified": template_verified,
                "value_identity_operator_signature_present": signature_present,
                "value_operator_signature_public_identity_present": public_identity,
                "value_operator_signature_public_identity_hash_bound": public_identity_hash,
                "value_operator_signature_hash_binding_verified": hash_binding,
                "value_operator_signature_public_identity_ready": ready,
                "upstream_value_identity_signature_source_binding_ready": bool(
                    item.get("value_identity_signature_source_binding_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_expected_digest_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get("checksum_payload_hash_sha_match_verifier_records") or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_sha_match_path = (
            item.get("expected_checksum_explicit_payload_hash_sha_match_path") or ""
        )
        expected_digest_path = (
            item.get("expected_checksum_expected_digest_source_packet_identity_path")
            or _sidecar(expected_sha_match_path, ".expected-digest-source-identity.json")
        )
        sha_match = bool(item.get("checksum_explicit_payload_hash_sha_match"))
        digest_present = bool(item.get("checksum_expected_digest_present"))
        digest_sha = bool(item.get("checksum_expected_digest_sha_match"))
        source_identity = bool(item.get("checksum_source_packet_identity_present"))
        source_identity_hash = bool(item.get("checksum_source_packet_identity_hash_bound"))
        template_verified = bool(
            expected_sha_match_path
            and expected_digest_path
            and str(expected_sha_match_path).endswith(".json")
            and str(expected_digest_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("checksum_payload_hash_sha_match_ready")
            and sha_match
            and digest_present
            and digest_sha
            and source_identity
            and source_identity_hash
        )
        payload = {
            "schema_id": CHECKSUM_EXPECTED_DIGEST_SCHEMA_ID,
            "field": field,
            "expected_checksum_explicit_payload_hash_sha_match_path": expected_sha_match_path,
            "expected_checksum_expected_digest_source_packet_identity_path": expected_digest_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": CHECKSUM_EXPECTED_DIGEST_SCHEMA_ID,
                "checksum_sha_match_expected_digest_source_packet_identity_verifier_id": (
                    f"referee-repair-checksum-expected-digest-{record_sha[:16]}"
                ),
                "checksum_sha_match_expected_digest_source_packet_identity_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_explicit_payload_hash_sha_match_path": expected_sha_match_path,
                "expected_checksum_expected_digest_source_packet_identity_path": expected_digest_path,
                "checksum_expected_digest_source_identity_template_verified": template_verified,
                "checksum_explicit_payload_hash_sha_match": sha_match,
                "checksum_expected_digest_present": digest_present,
                "checksum_expected_digest_sha_match": digest_sha,
                "checksum_source_packet_identity_present": source_identity,
                "checksum_source_packet_identity_hash_bound": source_identity_hash,
                "checksum_expected_digest_source_identity_ready": ready,
                "upstream_checksum_payload_hash_sha_match_ready": bool(
                    item.get("checksum_payload_hash_sha_match_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_handoff_attestation(packet_record, payload_sha):
    source = dict(
        packet_record.get("source_handoff_identity_sha_payload_marker_schema_hash_quarantine")
        or {}
    )
    expected_marker_path = source.get("expected_source_handoff_identity_sha_payload_marker_path") or ""
    expected_attestation_path = (
        source.get("expected_source_handoff_payload_marker_source_file_hash_attestation_path")
        or _sidecar(expected_marker_path, ".operator-signature-source-file-attestation.json")
    )
    marker_sha = bool(
        source.get("source_handoff_identity_sha_payload_marker_payload_hash_sha_match")
    )
    operator_signature = bool(
        source.get("source_handoff_payload_marker_operator_signature_present")
    )
    operator_signature_bound = bool(
        source.get("source_handoff_payload_marker_operator_signature_bound")
    )
    attestation = bool(
        source.get("source_handoff_source_file_hash_attestation_present")
    )
    attestation_sha = bool(
        source.get("source_handoff_source_file_hash_attestation_sha_match")
    )
    template_verified = bool(
        expected_marker_path
        and expected_attestation_path
        and str(expected_marker_path).endswith(".json")
        and str(expected_attestation_path).endswith(".json")
    )
    ready = bool(
        source.get("source_handoff_payload_marker_schema_hash_ready")
        and template_verified
        and marker_sha
        and operator_signature
        and operator_signature_bound
        and attestation
        and attestation_sha
    )
    return {
        "schema_id": SOURCE_HANDOFF_ATTESTATION_SCHEMA_ID,
        "source_handoff_payload_marker_operator_signature_source_file_hash_attestation_id": (
            f"referee-repair-source-handoff-attestation-{payload_sha[:16]}"
        ),
        "expected_source_handoff_identity_sha_payload_marker_path": expected_marker_path,
        "expected_source_handoff_payload_marker_source_file_hash_attestation_path": expected_attestation_path,
        "source_handoff_operator_signature_attestation_template_verified": template_verified,
        "source_handoff_identity_sha_payload_marker_payload_hash_sha_match": marker_sha,
        "source_handoff_payload_marker_operator_signature_present": operator_signature,
        "source_handoff_payload_marker_operator_signature_bound": operator_signature_bound,
        "source_handoff_source_file_hash_attestation_present": attestation,
        "source_handoff_source_file_hash_attestation_sha_match": attestation_sha,
        "source_handoff_operator_signature_attestation_ready": ready,
        "upstream_source_handoff_payload_marker_schema_hash_ready": bool(
            source.get("source_handoff_payload_marker_schema_hash_ready")
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_digest_chain(packet_record, payload_sha):
    receipt = dict(
        packet_record.get(
            "receipt_identity_marker_operator_signature_payload_hash_authorization_binding"
        )
        or {}
    )
    expected_hash_path = (
        receipt.get("expected_receipt_identity_marker_operator_signature_payload_hash_path")
        or ""
    )
    expected_chain_path = (
        receipt.get("expected_receipt_authorization_payload_digest_chain_path")
        or _sidecar(expected_hash_path, ".authorization-digest-chain.json")
    )
    signature_sha = bool(
        receipt.get("receipt_identity_marker_operator_signature_payload_hash_sha_match")
    )
    operator_signature = bool(
        receipt.get("receipt_authorization_binding_operator_signature_present")
    )
    operator_signature_bound = bool(
        receipt.get("receipt_authorization_binding_operator_signature_bound")
    )
    digest_chain = bool(receipt.get("receipt_payload_digest_chain_present"))
    digest_chain_sha = bool(receipt.get("receipt_payload_digest_chain_sha_match"))
    digest_chain_auth = bool(
        receipt.get("receipt_payload_digest_chain_authorization_bound")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_hash_path
        and expected_chain_path
        and str(expected_hash_path).endswith(".json")
        and str(expected_chain_path).endswith(".json")
    )
    ready = bool(
        receipt.get("receipt_operator_signature_payload_hash_authorization_ready")
        and template_verified
        and signature_sha
        and operator_signature
        and operator_signature_bound
        and digest_chain
        and digest_chain_sha
        and digest_chain_auth
        and not performed
    )
    return {
        "schema_id": RECEIPT_DIGEST_CHAIN_SCHEMA_ID,
        "receipt_authorization_binding_operator_signature_payload_digest_chain_id": (
            f"referee-repair-receipt-digest-chain-{payload_sha[:16]}"
        ),
        "expected_receipt_identity_marker_operator_signature_payload_hash_path": expected_hash_path,
        "expected_receipt_authorization_payload_digest_chain_path": expected_chain_path,
        "receipt_authorization_digest_chain_template_verified": template_verified,
        "receipt_identity_marker_operator_signature_payload_hash_sha_match": signature_sha,
        "receipt_authorization_binding_operator_signature_present": operator_signature,
        "receipt_authorization_binding_operator_signature_bound": operator_signature_bound,
        "receipt_payload_digest_chain_present": digest_chain,
        "receipt_payload_digest_chain_sha_match": digest_chain_sha,
        "receipt_payload_digest_chain_authorization_bound": digest_chain_auth,
        "receipt_authorization_digest_chain_ready": ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_digest_chain_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_records = _source_content_provenance_records(packet_record, payload_sha)
    value_records = _value_public_identity_records(packet_record, payload_sha)
    checksum_records = _checksum_expected_digest_records(packet_record, payload_sha)
    source_attestation = _source_handoff_attestation(packet_record, payload_sha)
    receipt_chain = _receipt_digest_chain(packet_record, payload_sha)
    source_required = _required_count(source_records)
    source_ready = _count(source_records, "source_content_materialization_provenance_ready")
    value_required = _required_count(value_records)
    value_ready = _count(value_records, "value_operator_signature_public_identity_ready")
    checksum_required = _required_count(checksum_records)
    checksum_ready = _count(
        checksum_records, "checksum_expected_digest_source_identity_ready"
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_chain.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_attestation.get("source_handoff_operator_signature_attestation_ready")
        and receipt_chain.get("receipt_authorization_digest_chain_ready")
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_content_materialization_provenance_marker_missing")
    if value_ready != value_required:
        blockers.append("value_operator_signature_public_identity_hash_binding_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_expected_digest_source_packet_identity_missing")
    if not source_attestation.get("source_handoff_operator_signature_attestation_ready"):
        blockers.append("source_handoff_operator_signature_source_file_hash_attestation_missing")
    if not receipt_chain.get("receipt_authorization_digest_chain_ready"):
        blockers.append("receipt_authorization_operator_signature_payload_digest_chain_missing")
    if consumable:
        blockers.append("human_input_artifact_source_value_payload_digest_chain_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_id": (
            f"referee-repair-human-input-source-value-payload-digest-chain-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256"
            )
            or ""
        ),
        "source_content_payload_hash_materialization_provenance_records": source_records,
        "source_content_materialization_provenance_required_count": source_required,
        "source_content_materialization_provenance_ready_count": source_ready,
        "value_operator_signature_public_identity_hash_binding_records": value_records,
        "value_operator_signature_public_identity_required_count": value_required,
        "value_operator_signature_public_identity_ready_count": value_ready,
        "checksum_sha_match_expected_digest_source_packet_identity_records": checksum_records,
        "checksum_expected_digest_source_identity_required_count": checksum_required,
        "checksum_expected_digest_source_identity_ready_count": checksum_ready,
        "source_handoff_payload_marker_operator_signature_source_file_hash_attestation": source_attestation,
        "receipt_authorization_binding_operator_signature_payload_digest_chain": receipt_chain,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "payload materialization provenance, value public identity hash bindings, checksum source identities, source hash attestations, and receipt digest chains are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source content materialization provenance markers, value operator signature public identity/hash bindings, checksum expected digest/source packet identities, source handoff signature/hash attestations, and receipt authorization payload digest chains"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_digest_chain_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_id": (
            f"referee-repair-request-human-input-source-value-payload-digest-chain-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_digest_chain_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_digest_chain_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_content_payload_hash_materialization_provenance_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "value_operator_signature_public_identity_hash_binding_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_sha_match_expected_digest_source_packet_identity_records"
        )
        or []
    ]
    source_attestation_records = [
        record.get(
            "source_handoff_payload_marker_operator_signature_source_file_hash_attestation"
        )
        or {}
        for record in verifier_records
    ]
    receipt_chain_records = [
        record.get("receipt_authorization_binding_operator_signature_payload_digest_chain")
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready"
        )
    )
    source_required = _required_count(source_records)
    source_hash_count = _count(source_records, "source_path_packet_content_payload_hash_present")
    source_sha_count = _count(source_records, "source_path_packet_content_payload_hash_sha_match")
    source_marker_count = _count(
        source_records, "source_content_materialization_provenance_marker_present"
    )
    source_marker_schema_count = _count(
        source_records, "source_content_materialization_provenance_marker_schema_valid"
    )
    source_marker_hash_count = _count(
        source_records, "source_content_materialization_provenance_marker_hash_bound"
    )
    source_ready_count = _count(
        source_records, "source_content_materialization_provenance_ready"
    )
    value_required = _required_count(value_records)
    value_signature_count = _count(value_records, "value_identity_operator_signature_present")
    value_public_identity_count = _count(
        value_records, "value_operator_signature_public_identity_present"
    )
    value_public_hash_count = _count(
        value_records, "value_operator_signature_public_identity_hash_bound"
    )
    value_hash_binding_count = _count(
        value_records, "value_operator_signature_hash_binding_verified"
    )
    value_ready_count = _count(
        value_records, "value_operator_signature_public_identity_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_sha_count = _count(checksum_records, "checksum_explicit_payload_hash_sha_match")
    checksum_digest_count = _count(checksum_records, "checksum_expected_digest_present")
    checksum_digest_sha_count = _count(
        checksum_records, "checksum_expected_digest_sha_match"
    )
    checksum_source_identity_count = _count(
        checksum_records, "checksum_source_packet_identity_present"
    )
    checksum_source_identity_hash_count = _count(
        checksum_records, "checksum_source_packet_identity_hash_bound"
    )
    checksum_ready_count = _count(
        checksum_records, "checksum_expected_digest_source_identity_ready"
    )
    source_attestation_required = record_count
    source_attestation_marker_sha_count = sum(
        1
        for item in source_attestation_records
        if item.get("source_handoff_identity_sha_payload_marker_payload_hash_sha_match")
    )
    source_attestation_signature_count = sum(
        1
        for item in source_attestation_records
        if item.get("source_handoff_payload_marker_operator_signature_present")
    )
    source_attestation_signature_bound_count = sum(
        1
        for item in source_attestation_records
        if item.get("source_handoff_payload_marker_operator_signature_bound")
    )
    source_attestation_count = sum(
        1
        for item in source_attestation_records
        if item.get("source_handoff_source_file_hash_attestation_present")
    )
    source_attestation_sha_count = sum(
        1
        for item in source_attestation_records
        if item.get("source_handoff_source_file_hash_attestation_sha_match")
    )
    source_attestation_ready_count = sum(
        1
        for item in source_attestation_records
        if item.get("source_handoff_operator_signature_attestation_ready")
    )
    receipt_required = record_count
    receipt_signature_sha_count = sum(
        1
        for item in receipt_chain_records
        if item.get("receipt_identity_marker_operator_signature_payload_hash_sha_match")
    )
    receipt_operator_signature_count = sum(
        1
        for item in receipt_chain_records
        if item.get("receipt_authorization_binding_operator_signature_present")
    )
    receipt_operator_signature_bound_count = sum(
        1
        for item in receipt_chain_records
        if item.get("receipt_authorization_binding_operator_signature_bound")
    )
    receipt_digest_chain_count = sum(
        1 for item in receipt_chain_records if item.get("receipt_payload_digest_chain_present")
    )
    receipt_digest_chain_sha_count = sum(
        1
        for item in receipt_chain_records
        if item.get("receipt_payload_digest_chain_sha_match")
    )
    receipt_digest_chain_auth_count = sum(
        1
        for item in receipt_chain_records
        if item.get("receipt_payload_digest_chain_authorization_bound")
    )
    receipt_ready_count = sum(
        1
        for item in receipt_chain_records
        if item.get("receipt_authorization_digest_chain_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_chain_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1 for item in verifier_records if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1 for item in verifier_records + request_records if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1 for item in verifier_records + request_records if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1 for item in verifier_records + request_records if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_ready_count == source_required
        and value_ready_count == value_required
        and checksum_ready_count == checksum_required
        and source_attestation_ready_count == source_attestation_required
        and receipt_ready_count == receipt_required
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "payload_hash_signature_binding_verifier_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "payload_hash_signature_binding_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_source_content_materialization_provenance_markers_verified",
        source_hash_count == source_required
        and source_sha_count == source_required
        and source_marker_count == source_required
        and source_marker_schema_count == source_required
        and source_marker_hash_count == source_required
        and source_ready_count == source_required,
        (
            f"payload_hash={source_hash_count}/{source_required} "
            f"sha_match={source_sha_count} marker={source_marker_count} "
            f"marker_schema={source_marker_schema_count} "
            f"marker_hash={source_marker_hash_count} ready={source_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_value_operator_signature_public_identity_hash_bindings_verified",
        value_signature_count == value_required
        and value_public_identity_count == value_required
        and value_public_hash_count == value_required
        and value_hash_binding_count == value_required
        and value_ready_count == value_required,
        (
            f"signature={value_signature_count}/{value_required} "
            f"public_identity={value_public_identity_count} "
            f"public_hash={value_public_hash_count} "
            f"hash_binding={value_hash_binding_count} ready={value_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_checksum_expected_digest_source_identities_verified",
        checksum_sha_count == checksum_required
        and checksum_digest_count == checksum_required
        and checksum_digest_sha_count == checksum_required
        and checksum_source_identity_count == checksum_required
        and checksum_source_identity_hash_count == checksum_required
        and checksum_ready_count == checksum_required,
        (
            f"sha_match={checksum_sha_count}/{checksum_required} "
            f"expected_digest={checksum_digest_count} digest_sha={checksum_digest_sha_count} "
            f"source_identity={checksum_source_identity_count} "
            f"source_identity_hash={checksum_source_identity_hash_count} "
            f"ready={checksum_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_source_handoff_operator_signature_source_file_hash_attestations_verified",
        source_attestation_marker_sha_count == source_attestation_required
        and source_attestation_signature_count == source_attestation_required
        and source_attestation_signature_bound_count == source_attestation_required
        and source_attestation_count == source_attestation_required
        and source_attestation_sha_count == source_attestation_required
        and source_attestation_ready_count == source_attestation_required,
        (
            f"marker_sha={source_attestation_marker_sha_count}/{source_attestation_required} "
            f"signature={source_attestation_signature_count} "
            f"signature_bound={source_attestation_signature_bound_count} "
            f"attestation={source_attestation_count} "
            f"attestation_sha={source_attestation_sha_count} "
            f"ready={source_attestation_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_authorization_operator_signature_payload_digest_chains_verified",
        receipt_signature_sha_count == receipt_required
        and receipt_operator_signature_count == receipt_required
        and receipt_operator_signature_bound_count == receipt_required
        and receipt_digest_chain_count == receipt_required
        and receipt_digest_chain_sha_count == receipt_required
        and receipt_digest_chain_auth_count == receipt_required
        and receipt_ready_count == receipt_required
        and receipt_performed_count == 0,
        (
            f"signature_sha={receipt_signature_sha_count}/{receipt_required} "
            f"operator_signature={receipt_operator_signature_count} "
            f"signature_bound={receipt_operator_signature_bound_count} "
            f"digest_chain={receipt_digest_chain_count} "
            f"digest_sha={receipt_digest_chain_sha_count} "
            f"authorization_bound={receipt_digest_chain_auth_count} "
            f"ready={receipt_ready_count} performed={receipt_performed_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_payload_digest_chain_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_digest_chain_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_DIGEST_CHAIN_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_DIGEST_CHAIN_UPSTREAM_LINT"
    elif (
        source_hash_count != source_required
        or source_sha_count != source_required
        or source_marker_count != source_required
        or source_marker_schema_count != source_required
        or source_marker_hash_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_CONTENT_MATERIALIZATION_PROVENANCE_MARKER_MISSING"
    elif (
        value_signature_count != value_required
        or value_public_identity_count != value_required
        or value_public_hash_count != value_required
        or value_hash_binding_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_OPERATOR_SIGNATURE_PUBLIC_IDENTITY_HASH_BINDING_MISSING"
    elif (
        checksum_sha_count != checksum_required
        or checksum_digest_count != checksum_required
        or checksum_digest_sha_count != checksum_required
        or checksum_source_identity_count != checksum_required
        or checksum_source_identity_hash_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_EXPECTED_DIGEST_SOURCE_PACKET_IDENTITY_MISSING"
    elif (
        source_attestation_marker_sha_count != source_attestation_required
        or source_attestation_signature_count != source_attestation_required
        or source_attestation_signature_bound_count != source_attestation_required
        or source_attestation_count != source_attestation_required
        or source_attestation_sha_count != source_attestation_required
        or source_attestation_ready_count != source_attestation_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_HANDOFF_OPERATOR_SIGNATURE_SOURCE_FILE_HASH_ATTESTATION_MISSING"
    elif (
        receipt_signature_sha_count != receipt_required
        or receipt_operator_signature_count != receipt_required
        or receipt_operator_signature_bound_count != receipt_required
        or receipt_digest_chain_count != receipt_required
        or receipt_digest_chain_sha_count != receipt_required
        or receipt_digest_chain_auth_count != receipt_required
        or receipt_ready_count != receipt_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTHORIZATION_OPERATOR_SIGNATURE_PAYLOAD_DIGEST_CHAIN_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_DIGEST_CHAIN_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_DIGEST_CHAIN_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_DIGEST_CHAIN_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_DIGEST_CHAIN_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_digest_chain_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_lint_ready_count": lint_ready_count,
            "upstream_payload_hash_signature_binding_ready_count": upstream_ready_count,
            "upstream_payload_hash_signature_binding_blocked_count": record_count - upstream_ready_count,
            "source_content_materialization_provenance_required_count": source_required,
            "source_path_packet_content_payload_hash_present_count": source_hash_count,
            "source_path_packet_content_payload_hash_sha_match_count": source_sha_count,
            "source_content_materialization_provenance_marker_present_count": source_marker_count,
            "source_content_materialization_provenance_marker_schema_valid_count": source_marker_schema_count,
            "source_content_materialization_provenance_marker_hash_bound_count": source_marker_hash_count,
            "source_content_materialization_provenance_ready_count": source_ready_count,
            "value_operator_signature_public_identity_required_count": value_required,
            "value_identity_operator_signature_present_count": value_signature_count,
            "value_operator_signature_public_identity_present_count": value_public_identity_count,
            "value_operator_signature_public_identity_hash_bound_count": value_public_hash_count,
            "value_operator_signature_hash_binding_verified_count": value_hash_binding_count,
            "value_operator_signature_public_identity_ready_count": value_ready_count,
            "checksum_expected_digest_source_identity_required_count": checksum_required,
            "checksum_explicit_payload_hash_sha_match_count": checksum_sha_count,
            "checksum_expected_digest_present_count": checksum_digest_count,
            "checksum_expected_digest_sha_match_count": checksum_digest_sha_count,
            "checksum_source_packet_identity_present_count": checksum_source_identity_count,
            "checksum_source_packet_identity_hash_bound_count": checksum_source_identity_hash_count,
            "checksum_expected_digest_source_identity_ready_count": checksum_ready_count,
            "source_handoff_operator_signature_attestation_required_count": source_attestation_required,
            "source_handoff_identity_sha_payload_marker_payload_hash_sha_match_count": source_attestation_marker_sha_count,
            "source_handoff_payload_marker_operator_signature_present_count": source_attestation_signature_count,
            "source_handoff_payload_marker_operator_signature_bound_count": source_attestation_signature_bound_count,
            "source_handoff_source_file_hash_attestation_present_count": source_attestation_count,
            "source_handoff_source_file_hash_attestation_sha_match_count": source_attestation_sha_count,
            "source_handoff_operator_signature_attestation_ready_count": source_attestation_ready_count,
            "receipt_authorization_digest_chain_required_count": receipt_required,
            "receipt_identity_marker_operator_signature_payload_hash_sha_match_count": receipt_signature_sha_count,
            "receipt_authorization_binding_operator_signature_present_count": receipt_operator_signature_count,
            "receipt_authorization_binding_operator_signature_bound_count": receipt_operator_signature_bound_count,
            "receipt_payload_digest_chain_present_count": receipt_digest_chain_count,
            "receipt_payload_digest_chain_sha_match_count": receipt_digest_chain_sha_count,
            "receipt_payload_digest_chain_authorization_bound_count": receipt_digest_chain_auth_count,
            "receipt_authorization_digest_chain_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_digest_chain_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source content materialization provenance markers, value operator signature public identity/hash bindings, checksum expected digest/source packet identities, source handoff signature/hash attestations, and receipt authorization payload digest chains.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Digest Chain Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_digest_chain_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
