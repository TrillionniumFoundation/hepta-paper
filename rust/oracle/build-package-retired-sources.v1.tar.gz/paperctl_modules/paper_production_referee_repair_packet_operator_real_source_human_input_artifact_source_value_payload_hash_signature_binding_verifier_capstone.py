"""Human-input artifact source/value payload hash/signature binding verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-hash-signature-binding-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_capstone.v1"
)
SOURCE_PATH_CONTENT_HASH_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_path_packet_content_payload_hash_schema_validator.v1"
)
VALUE_SIGNATURE_BINDING_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_value_identity_signature_source_binding_marker.v1"
)
CHECKSUM_SHA_MATCH_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_checksum_payload_hash_sha_match_verifier.v1"
)
SOURCE_HANDOFF_MARKER_HASH_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_handoff_identity_sha_payload_marker_schema_hash_quarantine.v1"
)
RECEIPT_SIGNATURE_HASH_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_receipt_identity_marker_operator_signature_payload_hash_authorization_binding.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_count",
    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready_count",
    "upstream_payload_marker_ready_count",
    "upstream_payload_marker_blocked_count",
    "source_path_content_payload_hash_schema_required_count",
    "source_path_packet_content_present_count",
    "source_path_packet_content_schema_valid_count",
    "source_path_packet_content_payload_hash_present_count",
    "source_path_packet_content_payload_hash_bound_count",
    "source_path_packet_content_payload_hash_sha_match_count",
    "source_path_content_payload_hash_schema_ready_count",
    "value_identity_signature_source_binding_required_count",
    "value_identity_authorization_marker_present_count",
    "value_identity_operator_identity_present_count",
    "value_identity_source_identity_present_count",
    "value_identity_operator_signature_present_count",
    "value_identity_operator_signature_bound_count",
    "value_identity_source_binding_marker_present_count",
    "value_identity_source_binding_marker_schema_valid_count",
    "value_identity_signature_source_binding_ready_count",
    "checksum_payload_hash_sha_match_required_count",
    "checksum_explicit_payload_hash_present_count",
    "checksum_explicit_payload_hash_bound_count",
    "checksum_explicit_payload_hash_sha_match_count",
    "checksum_payload_hash_sha_match_ready_count",
    "source_handoff_payload_marker_schema_hash_required_count",
    "source_handoff_identity_sha_payload_marker_present_count",
    "source_handoff_identity_sha_payload_marker_schema_valid_count",
    "source_handoff_identity_sha_payload_marker_hash_bound_count",
    "source_handoff_identity_sha_payload_marker_payload_hash_present_count",
    "source_handoff_identity_sha_payload_marker_payload_hash_sha_match_count",
    "source_handoff_payload_marker_schema_hash_ready_count",
    "receipt_operator_signature_payload_hash_authorization_required_count",
    "receipt_signature_operator_signature_present_count",
    "receipt_signature_operator_signature_identity_bound_count",
    "receipt_identity_marker_operator_signature_payload_hash_present_count",
    "receipt_identity_marker_operator_signature_payload_hash_bound_count",
    "receipt_identity_marker_operator_signature_payload_hash_sha_match_count",
    "receipt_identity_marker_authorization_binding_verified_count",
    "receipt_operator_signature_payload_hash_authorization_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _source_path_content_hash_records(packet_record, payload_sha):
    matrix = packet_record.get("source_path_packet_json_schema_content_verifier_matrix") or {}
    records = []
    for item in matrix.get("source_path_packet_json_schema_content_verifier_records") or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_content_path = (
            item.get("expected_human_input_artifact_source_path_packet_content_path")
            or ""
        )
        expected_payload_hash_path = (
            item.get("expected_source_path_packet_content_payload_hash_path")
            or _sidecar(expected_content_path, ".payload-hash.json")
        )
        content_present = bool(item.get("source_path_packet_content_present"))
        content_schema = bool(item.get("source_path_packet_content_schema_valid"))
        payload_hash_present = bool(
            item.get("source_path_packet_content_payload_hash_present")
        )
        payload_hash_bound = bool(
            item.get("source_path_packet_content_payload_hash_bound")
        )
        payload_hash_sha_match = bool(
            item.get("source_path_packet_content_payload_hash_sha_match")
        )
        template_verified = bool(
            expected_content_path
            and expected_payload_hash_path
            and str(expected_content_path).endswith(".json")
            and str(expected_payload_hash_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("source_path_packet_json_schema_content_ready")
            and content_present
            and content_schema
            and payload_hash_present
            and payload_hash_bound
            and payload_hash_sha_match
        )
        payload = {
            "schema_id": SOURCE_PATH_CONTENT_HASH_SCHEMA_ID,
            "field": field,
            "expected_human_input_artifact_source_path_packet_content_path": expected_content_path,
            "expected_source_path_packet_content_payload_hash_path": expected_payload_hash_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": SOURCE_PATH_CONTENT_HASH_SCHEMA_ID,
                "source_path_packet_content_payload_hash_schema_validator_id": (
                    f"referee-repair-source-path-content-hash-schema-{record_sha[:16]}"
                ),
                "source_path_packet_content_payload_hash_schema_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_human_input_artifact_source_path_packet_content_path": expected_content_path,
                "expected_source_path_packet_content_payload_hash_path": expected_payload_hash_path,
                "source_path_packet_content_payload_hash_schema_template_verified": template_verified,
                "source_path_packet_content_present": content_present,
                "source_path_packet_content_schema_valid": content_schema,
                "source_path_packet_content_payload_hash_present": payload_hash_present,
                "source_path_packet_content_payload_hash_bound": payload_hash_bound,
                "source_path_packet_content_payload_hash_sha_match": payload_hash_sha_match,
                "source_path_content_payload_hash_schema_ready": ready,
                "upstream_source_path_packet_json_schema_content_ready": bool(
                    item.get("source_path_packet_json_schema_content_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_signature_binding_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get("value_provenance_identity_authorization_marker_records") or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_marker_path = (
            item.get("expected_value_provenance_identity_authorization_marker_path")
            or ""
        )
        expected_signature_path = (
            item.get("expected_value_identity_operator_signature_path")
            or _sidecar(expected_marker_path, ".operator-signature.json")
        )
        expected_source_binding_path = (
            item.get("expected_value_identity_source_binding_marker_path")
            or _sidecar(expected_marker_path, ".source-identity-binding.json")
        )
        marker_present = bool(item.get("value_identity_authorization_marker_present"))
        marker_schema = bool(item.get("value_identity_authorization_marker_schema_valid"))
        operator_identity = bool(item.get("value_identity_operator_identity_present"))
        source_identity = bool(item.get("value_identity_source_identity_present"))
        operator_signature = bool(item.get("value_identity_operator_signature_present"))
        operator_signature_bound = bool(
            item.get("value_identity_operator_signature_bound")
        )
        source_binding_marker = bool(
            item.get("value_identity_source_binding_marker_present")
        )
        source_binding_schema = bool(
            item.get("value_identity_source_binding_marker_schema_valid")
        )
        template_verified = bool(
            expected_marker_path
            and expected_signature_path
            and expected_source_binding_path
            and str(expected_signature_path).endswith(".json")
            and str(expected_source_binding_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("value_identity_authorization_marker_ready")
            and marker_present
            and marker_schema
            and operator_identity
            and source_identity
            and operator_signature
            and operator_signature_bound
            and source_binding_marker
            and source_binding_schema
        )
        payload = {
            "schema_id": VALUE_SIGNATURE_BINDING_SCHEMA_ID,
            "field": field,
            "expected_value_provenance_identity_authorization_marker_path": expected_marker_path,
            "expected_value_identity_operator_signature_path": expected_signature_path,
            "expected_value_identity_source_binding_marker_path": expected_source_binding_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": VALUE_SIGNATURE_BINDING_SCHEMA_ID,
                "value_identity_signature_source_binding_marker_id": (
                    f"referee-repair-value-signature-source-binding-{record_sha[:16]}"
                ),
                "value_identity_signature_source_binding_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_provenance_identity_authorization_marker_path": expected_marker_path,
                "expected_value_identity_operator_signature_path": expected_signature_path,
                "expected_value_identity_source_binding_marker_path": expected_source_binding_path,
                "value_identity_signature_source_binding_template_verified": template_verified,
                "value_identity_authorization_marker_present": marker_present,
                "value_identity_authorization_marker_schema_valid": marker_schema,
                "value_identity_operator_identity_present": operator_identity,
                "value_identity_source_identity_present": source_identity,
                "value_identity_operator_signature_present": operator_signature,
                "value_identity_operator_signature_bound": operator_signature_bound,
                "value_identity_source_binding_marker_present": source_binding_marker,
                "value_identity_source_binding_marker_schema_valid": source_binding_schema,
                "value_identity_signature_source_binding_ready": ready,
                "upstream_value_identity_authorization_marker_ready": bool(
                    item.get("value_identity_authorization_marker_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_sha_match_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get("checksum_explicit_binding_payload_hash_verifier_records") or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_payload_hash_path = (
            item.get("expected_checksum_explicit_binding_payload_hash_path") or ""
        )
        expected_sha_match_path = (
            item.get("expected_checksum_explicit_payload_hash_sha_match_path")
            or _sidecar(expected_payload_hash_path, ".sha-match.json")
        )
        payload_hash_present = bool(item.get("checksum_explicit_payload_hash_present"))
        payload_hash_bound = bool(item.get("checksum_explicit_payload_hash_bound"))
        payload_hash_sha_match = bool(
            item.get("checksum_explicit_payload_hash_sha_match")
        )
        template_verified = bool(
            expected_payload_hash_path
            and expected_sha_match_path
            and str(expected_payload_hash_path).endswith(".json")
            and str(expected_sha_match_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("checksum_explicit_payload_hash_ready")
            and payload_hash_present
            and payload_hash_bound
            and payload_hash_sha_match
        )
        payload = {
            "schema_id": CHECKSUM_SHA_MATCH_SCHEMA_ID,
            "field": field,
            "expected_checksum_explicit_binding_payload_hash_path": expected_payload_hash_path,
            "expected_checksum_explicit_payload_hash_sha_match_path": expected_sha_match_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": CHECKSUM_SHA_MATCH_SCHEMA_ID,
                "checksum_payload_hash_sha_match_verifier_id": (
                    f"referee-repair-checksum-payload-hash-sha-match-{record_sha[:16]}"
                ),
                "checksum_payload_hash_sha_match_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_explicit_binding_payload_hash_path": expected_payload_hash_path,
                "expected_checksum_explicit_payload_hash_sha_match_path": expected_sha_match_path,
                "checksum_payload_hash_sha_match_template_verified": template_verified,
                "checksum_explicit_payload_hash_present": payload_hash_present,
                "checksum_explicit_payload_hash_bound": payload_hash_bound,
                "checksum_explicit_payload_hash_sha_match": payload_hash_sha_match,
                "checksum_payload_hash_sha_match_ready": ready,
                "upstream_checksum_explicit_payload_hash_ready": bool(
                    item.get("checksum_explicit_payload_hash_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_handoff_marker_schema_hash(packet_record, payload_sha):
    source = dict(
        packet_record.get("source_handoff_identity_sha_payload_marker_quarantine") or {}
    )
    expected_marker_path = (
        source.get("expected_source_handoff_identity_sha_payload_marker_path") or ""
    )
    expected_payload_hash_path = (
        source.get("expected_source_handoff_identity_sha_payload_marker_payload_hash_path")
        or _sidecar(expected_marker_path, ".payload-hash.json")
    )
    marker_present = bool(source.get("source_handoff_identity_sha_payload_marker_present"))
    marker_schema = bool(
        source.get("source_handoff_identity_sha_payload_marker_schema_valid")
    )
    marker_hash_bound = bool(
        source.get("source_handoff_identity_sha_payload_marker_hash_bound")
    )
    payload_hash_present = bool(
        source.get("source_handoff_identity_sha_payload_marker_payload_hash_present")
    )
    payload_hash_sha_match = bool(
        source.get("source_handoff_identity_sha_payload_marker_payload_hash_sha_match")
    )
    template_verified = bool(
        expected_marker_path
        and expected_payload_hash_path
        and str(expected_marker_path).endswith(".json")
        and str(expected_payload_hash_path).endswith(".json")
    )
    ready = bool(
        source.get("source_handoff_identity_sha_payload_marker_ready")
        and template_verified
        and marker_present
        and marker_schema
        and marker_hash_bound
        and payload_hash_present
        and payload_hash_sha_match
    )
    return {
        "schema_id": SOURCE_HANDOFF_MARKER_HASH_SCHEMA_ID,
        "source_handoff_identity_sha_payload_marker_schema_hash_quarantine_id": (
            f"referee-repair-source-handoff-marker-schema-hash-{payload_sha[:16]}"
        ),
        "expected_source_handoff_identity_sha_payload_marker_path": expected_marker_path,
        "expected_source_handoff_identity_sha_payload_marker_payload_hash_path": expected_payload_hash_path,
        "source_handoff_identity_sha_payload_marker_schema_hash_template_verified": template_verified,
        "source_handoff_identity_sha_payload_marker_present": marker_present,
        "source_handoff_identity_sha_payload_marker_schema_valid": marker_schema,
        "source_handoff_identity_sha_payload_marker_hash_bound": marker_hash_bound,
        "source_handoff_identity_sha_payload_marker_payload_hash_present": payload_hash_present,
        "source_handoff_identity_sha_payload_marker_payload_hash_sha_match": payload_hash_sha_match,
        "source_handoff_payload_marker_schema_hash_ready": ready,
        "upstream_source_handoff_identity_sha_payload_marker_ready": bool(
            source.get("source_handoff_identity_sha_payload_marker_ready")
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_signature_hash_binding(packet_record, payload_sha):
    receipt = dict(
        packet_record.get("receipt_identity_marker_payload_schema_operator_signature_verifier")
        or {}
    )
    expected_signature_path = (
        receipt.get("expected_receipt_identity_marker_operator_signature_path") or ""
    )
    expected_hash_path = (
        receipt.get("expected_receipt_identity_marker_operator_signature_payload_hash_path")
        or _sidecar(expected_signature_path, ".payload-hash.json")
    )
    operator_signature = bool(receipt.get("receipt_signature_operator_signature_present"))
    signature_bound = bool(
        receipt.get("receipt_signature_operator_signature_identity_bound")
    )
    payload_hash_present = bool(
        receipt.get("receipt_identity_marker_operator_signature_payload_hash_present")
    )
    payload_hash_bound = bool(
        receipt.get("receipt_identity_marker_operator_signature_payload_hash_bound")
    )
    payload_hash_sha_match = bool(
        receipt.get("receipt_identity_marker_operator_signature_payload_hash_sha_match")
    )
    authorization_binding_verified = bool(
        receipt.get("receipt_identity_marker_authorization_binding_verified")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_signature_path
        and expected_hash_path
        and str(expected_signature_path).endswith(".json")
        and str(expected_hash_path).endswith(".json")
    )
    ready = bool(
        receipt.get("receipt_identity_marker_payload_signature_ready")
        and template_verified
        and operator_signature
        and signature_bound
        and payload_hash_present
        and payload_hash_bound
        and payload_hash_sha_match
        and authorization_binding_verified
        and not performed
    )
    return {
        "schema_id": RECEIPT_SIGNATURE_HASH_SCHEMA_ID,
        "receipt_identity_marker_operator_signature_payload_hash_authorization_binding_id": (
            f"referee-repair-receipt-signature-hash-binding-{payload_sha[:16]}"
        ),
        "expected_receipt_identity_marker_operator_signature_path": expected_signature_path,
        "expected_receipt_identity_marker_operator_signature_payload_hash_path": expected_hash_path,
        "receipt_identity_marker_operator_signature_payload_hash_authorization_template_verified": template_verified,
        "receipt_signature_operator_signature_present": operator_signature,
        "receipt_signature_operator_signature_identity_bound": signature_bound,
        "receipt_identity_marker_operator_signature_payload_hash_present": payload_hash_present,
        "receipt_identity_marker_operator_signature_payload_hash_bound": payload_hash_bound,
        "receipt_identity_marker_operator_signature_payload_hash_sha_match": payload_hash_sha_match,
        "receipt_identity_marker_authorization_binding_verified": authorization_binding_verified,
        "receipt_operator_signature_payload_hash_authorization_ready": ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_path_records = _source_path_content_hash_records(packet_record, payload_sha)
    value_records = _value_signature_binding_records(packet_record, payload_sha)
    checksum_records = _checksum_sha_match_records(packet_record, payload_sha)
    source_marker = _source_handoff_marker_schema_hash(packet_record, payload_sha)
    receipt_signature = _receipt_signature_hash_binding(packet_record, payload_sha)
    source_required = sum(1 for item in source_path_records if item.get("required"))
    source_ready = sum(
        1
        for item in source_path_records
        if item.get("required") and item.get("source_path_content_payload_hash_schema_ready")
    )
    value_required = sum(1 for item in value_records if item.get("required"))
    value_ready = sum(
        1
        for item in value_records
        if item.get("required") and item.get("value_identity_signature_source_binding_ready")
    )
    checksum_required = sum(1 for item in checksum_records if item.get("required"))
    checksum_ready = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("checksum_payload_hash_sha_match_ready")
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_signature.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_marker.get("source_handoff_payload_marker_schema_hash_ready")
        and receipt_signature.get("receipt_operator_signature_payload_hash_authorization_ready")
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_path_packet_content_payload_hash_schema_missing")
    if value_ready != value_required:
        blockers.append("value_identity_operator_signature_source_binding_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_payload_hash_sha_match_missing")
    if not source_marker.get("source_handoff_payload_marker_schema_hash_ready"):
        blockers.append("source_handoff_payload_marker_schema_hash_quarantine_missing")
    if not receipt_signature.get("receipt_operator_signature_payload_hash_authorization_ready"):
        blockers.append("receipt_operator_signature_payload_hash_authorization_missing")
    if consumable:
        blockers.append("human_input_artifact_source_value_payload_hash_signature_binding_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_id": (
            f"referee-repair-human-input-source-value-payload-hash-signature-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256"
            )
            or ""
        ),
        "source_path_packet_content_payload_hash_schema_validator_records": source_path_records,
        "source_path_content_payload_hash_schema_required_count": source_required,
        "source_path_content_payload_hash_schema_ready_count": source_ready,
        "value_identity_signature_source_binding_marker_records": value_records,
        "value_identity_signature_source_binding_required_count": value_required,
        "value_identity_signature_source_binding_ready_count": value_ready,
        "checksum_payload_hash_sha_match_verifier_records": checksum_records,
        "checksum_payload_hash_sha_match_required_count": checksum_required,
        "checksum_payload_hash_sha_match_ready_count": checksum_ready,
        "source_handoff_identity_sha_payload_marker_schema_hash_quarantine": source_marker,
        "receipt_identity_marker_operator_signature_payload_hash_authorization_binding": receipt_signature,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "payload hashes, signature bindings, sha matches, and source/receipt authorization bindings are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source-path content payload hashes, value operator signatures/source bindings, checksum sha matches, source handoff payload-marker hash/schema quarantine, and receipt operator-signature payload hash authorization bindings"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_id": (
            f"referee-repair-request-human-input-source-value-payload-hash-signature-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_marker_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_marker_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_marker_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_marker_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_marker_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_records"
        )
        or []
    ]
    source_path_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_path_packet_content_payload_hash_schema_validator_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get("value_identity_signature_source_binding_marker_records")
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get("checksum_payload_hash_sha_match_verifier_records") or []
    ]
    source_marker_records = [
        record.get("source_handoff_identity_sha_payload_marker_schema_hash_quarantine")
        or {}
        for record in verifier_records
    ]
    receipt_records = [
        record.get(
            "receipt_identity_marker_operator_signature_payload_hash_authorization_binding"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_ready"
        )
    )
    source_required = _required_count(source_path_records)
    source_content_count = _count(source_path_records, "source_path_packet_content_present")
    source_schema_count = _count(source_path_records, "source_path_packet_content_schema_valid")
    source_hash_count = _count(
        source_path_records, "source_path_packet_content_payload_hash_present"
    )
    source_hash_bound_count = _count(
        source_path_records, "source_path_packet_content_payload_hash_bound"
    )
    source_sha_match_count = _count(
        source_path_records, "source_path_packet_content_payload_hash_sha_match"
    )
    source_ready_count = _count(
        source_path_records, "source_path_content_payload_hash_schema_ready"
    )
    value_required = _required_count(value_records)
    value_marker_count = _count(value_records, "value_identity_authorization_marker_present")
    value_operator_count = _count(value_records, "value_identity_operator_identity_present")
    value_source_count = _count(value_records, "value_identity_source_identity_present")
    value_signature_count = _count(value_records, "value_identity_operator_signature_present")
    value_signature_bound_count = _count(
        value_records, "value_identity_operator_signature_bound"
    )
    value_binding_count = _count(value_records, "value_identity_source_binding_marker_present")
    value_binding_schema_count = _count(
        value_records, "value_identity_source_binding_marker_schema_valid"
    )
    value_ready_count = _count(value_records, "value_identity_signature_source_binding_ready")
    checksum_required = _required_count(checksum_records)
    checksum_hash_count = _count(checksum_records, "checksum_explicit_payload_hash_present")
    checksum_hash_bound_count = _count(
        checksum_records, "checksum_explicit_payload_hash_bound"
    )
    checksum_sha_count = _count(checksum_records, "checksum_explicit_payload_hash_sha_match")
    checksum_ready_count = _count(checksum_records, "checksum_payload_hash_sha_match_ready")
    source_marker_required = record_count
    source_marker_count = sum(
        1
        for item in source_marker_records
        if item.get("source_handoff_identity_sha_payload_marker_present")
    )
    source_marker_schema_count = sum(
        1
        for item in source_marker_records
        if item.get("source_handoff_identity_sha_payload_marker_schema_valid")
    )
    source_marker_hash_bound_count = sum(
        1
        for item in source_marker_records
        if item.get("source_handoff_identity_sha_payload_marker_hash_bound")
    )
    source_marker_payload_hash_count = sum(
        1
        for item in source_marker_records
        if item.get("source_handoff_identity_sha_payload_marker_payload_hash_present")
    )
    source_marker_sha_count = sum(
        1
        for item in source_marker_records
        if item.get("source_handoff_identity_sha_payload_marker_payload_hash_sha_match")
    )
    source_marker_ready_count = sum(
        1
        for item in source_marker_records
        if item.get("source_handoff_payload_marker_schema_hash_ready")
    )
    receipt_required = record_count
    receipt_signature_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_operator_signature_present")
    )
    receipt_signature_bound_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_signature_operator_signature_identity_bound")
    )
    receipt_hash_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_identity_marker_operator_signature_payload_hash_present")
    )
    receipt_hash_bound_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_identity_marker_operator_signature_payload_hash_bound")
    )
    receipt_sha_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_identity_marker_operator_signature_payload_hash_sha_match")
    )
    receipt_authorization_binding_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_identity_marker_authorization_binding_verified")
    )
    receipt_ready_count = sum(
        1
        for item in receipt_records
        if item.get("receipt_operator_signature_payload_hash_authorization_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1 for item in verifier_records if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1 for item in verifier_records + request_records if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1 for item in verifier_records + request_records if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1 for item in verifier_records + request_records if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_ready_count == source_required
        and value_ready_count == value_required
        and checksum_ready_count == checksum_required
        and source_marker_ready_count == source_marker_required
        and receipt_ready_count == receipt_required
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "source_value_payload_marker_verifier_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_value_payload_marker_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_source_path_content_payload_hash_schema_validated",
        source_content_count == source_required
        and source_schema_count == source_required
        and source_hash_count == source_required
        and source_hash_bound_count == source_required
        and source_sha_match_count == source_required
        and source_ready_count == source_required,
        (
            f"content={source_content_count}/{source_required} "
            f"schema={source_schema_count} hash={source_hash_count} "
            f"hash_bound={source_hash_bound_count} sha_match={source_sha_match_count} "
            f"ready={source_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_value_identity_operator_signatures_and_source_bindings_verified",
        value_marker_count == value_required
        and value_operator_count == value_required
        and value_source_count == value_required
        and value_signature_count == value_required
        and value_signature_bound_count == value_required
        and value_binding_count == value_required
        and value_binding_schema_count == value_required
        and value_ready_count == value_required,
        (
            f"marker={value_marker_count}/{value_required} "
            f"operator={value_operator_count} source={value_source_count} "
            f"signature={value_signature_count} signature_bound={value_signature_bound_count} "
            f"source_binding={value_binding_count} binding_schema={value_binding_schema_count} "
            f"ready={value_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_checksum_payload_hash_sha_matches_verified",
        checksum_hash_count == checksum_required
        and checksum_hash_bound_count == checksum_required
        and checksum_sha_count == checksum_required
        and checksum_ready_count == checksum_required,
        (
            f"hash={checksum_hash_count}/{checksum_required} "
            f"hash_bound={checksum_hash_bound_count} sha_match={checksum_sha_count} "
            f"ready={checksum_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_source_handoff_payload_marker_schema_hash_quarantines_verified",
        source_marker_count == source_marker_required
        and source_marker_schema_count == source_marker_required
        and source_marker_hash_bound_count == source_marker_required
        and source_marker_payload_hash_count == source_marker_required
        and source_marker_sha_count == source_marker_required
        and source_marker_ready_count == source_marker_required,
        (
            f"marker={source_marker_count}/{source_marker_required} "
            f"schema={source_marker_schema_count} marker_hash={source_marker_hash_bound_count} "
            f"payload_hash={source_marker_payload_hash_count} sha_match={source_marker_sha_count} "
            f"ready={source_marker_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_operator_signature_payload_hash_authorization_bindings_verified",
        receipt_signature_count == receipt_required
        and receipt_signature_bound_count == receipt_required
        and receipt_hash_count == receipt_required
        and receipt_hash_bound_count == receipt_required
        and receipt_sha_count == receipt_required
        and receipt_authorization_binding_count == receipt_required
        and receipt_ready_count == receipt_required
        and receipt_performed_count == 0,
        (
            f"signature={receipt_signature_count}/{receipt_required} "
            f"signature_bound={receipt_signature_bound_count} hash={receipt_hash_count} "
            f"hash_bound={receipt_hash_bound_count} sha_match={receipt_sha_count} "
            f"authorization_binding={receipt_authorization_binding_count} "
            f"ready={receipt_ready_count} performed={receipt_performed_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_payload_hash_signature_binding_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_hash_signature_binding_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_HASH_SIGNATURE_BINDING_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_HASH_SIGNATURE_BINDING_UPSTREAM_LINT"
    elif (
        source_content_count != source_required
        or source_schema_count != source_required
        or source_hash_count != source_required
        or source_hash_bound_count != source_required
        or source_sha_match_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_PATH_PACKET_CONTENT_PAYLOAD_HASH_SCHEMA_MISSING"
    elif (
        value_marker_count != value_required
        or value_operator_count != value_required
        or value_source_count != value_required
        or value_signature_count != value_required
        or value_signature_bound_count != value_required
        or value_binding_count != value_required
        or value_binding_schema_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_IDENTITY_OPERATOR_SIGNATURE_SOURCE_BINDING_MISSING"
    elif (
        checksum_hash_count != checksum_required
        or checksum_hash_bound_count != checksum_required
        or checksum_sha_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_PAYLOAD_HASH_SHA_MATCH_MISSING"
    elif (
        source_marker_count != source_marker_required
        or source_marker_schema_count != source_marker_required
        or source_marker_hash_bound_count != source_marker_required
        or source_marker_payload_hash_count != source_marker_required
        or source_marker_sha_count != source_marker_required
        or source_marker_ready_count != source_marker_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_HANDOFF_PAYLOAD_MARKER_SCHEMA_HASH_QUARANTINE_MISSING"
    elif (
        receipt_signature_count != receipt_required
        or receipt_signature_bound_count != receipt_required
        or receipt_hash_count != receipt_required
        or receipt_hash_bound_count != receipt_required
        or receipt_sha_count != receipt_required
        or receipt_authorization_binding_count != receipt_required
        or receipt_ready_count != receipt_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_IDENTITY_OPERATOR_SIGNATURE_PAYLOAD_HASH_AUTHORIZATION_BINDING_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_HASH_SIGNATURE_BINDING_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_HASH_SIGNATURE_BINDING_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_HASH_SIGNATURE_BINDING_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_HASH_SIGNATURE_BINDING_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_lint_ready_count": lint_ready_count,
            "upstream_payload_marker_ready_count": upstream_ready_count,
            "upstream_payload_marker_blocked_count": record_count - upstream_ready_count,
            "source_path_content_payload_hash_schema_required_count": source_required,
            "source_path_packet_content_present_count": source_content_count,
            "source_path_packet_content_schema_valid_count": source_schema_count,
            "source_path_packet_content_payload_hash_present_count": source_hash_count,
            "source_path_packet_content_payload_hash_bound_count": source_hash_bound_count,
            "source_path_packet_content_payload_hash_sha_match_count": source_sha_match_count,
            "source_path_content_payload_hash_schema_ready_count": source_ready_count,
            "value_identity_signature_source_binding_required_count": value_required,
            "value_identity_authorization_marker_present_count": value_marker_count,
            "value_identity_operator_identity_present_count": value_operator_count,
            "value_identity_source_identity_present_count": value_source_count,
            "value_identity_operator_signature_present_count": value_signature_count,
            "value_identity_operator_signature_bound_count": value_signature_bound_count,
            "value_identity_source_binding_marker_present_count": value_binding_count,
            "value_identity_source_binding_marker_schema_valid_count": value_binding_schema_count,
            "value_identity_signature_source_binding_ready_count": value_ready_count,
            "checksum_payload_hash_sha_match_required_count": checksum_required,
            "checksum_explicit_payload_hash_present_count": checksum_hash_count,
            "checksum_explicit_payload_hash_bound_count": checksum_hash_bound_count,
            "checksum_explicit_payload_hash_sha_match_count": checksum_sha_count,
            "checksum_payload_hash_sha_match_ready_count": checksum_ready_count,
            "source_handoff_payload_marker_schema_hash_required_count": source_marker_required,
            "source_handoff_identity_sha_payload_marker_present_count": source_marker_count,
            "source_handoff_identity_sha_payload_marker_schema_valid_count": source_marker_schema_count,
            "source_handoff_identity_sha_payload_marker_hash_bound_count": source_marker_hash_bound_count,
            "source_handoff_identity_sha_payload_marker_payload_hash_present_count": source_marker_payload_hash_count,
            "source_handoff_identity_sha_payload_marker_payload_hash_sha_match_count": source_marker_sha_count,
            "source_handoff_payload_marker_schema_hash_ready_count": source_marker_ready_count,
            "receipt_operator_signature_payload_hash_authorization_required_count": receipt_required,
            "receipt_signature_operator_signature_present_count": receipt_signature_count,
            "receipt_signature_operator_signature_identity_bound_count": receipt_signature_bound_count,
            "receipt_identity_marker_operator_signature_payload_hash_present_count": receipt_hash_count,
            "receipt_identity_marker_operator_signature_payload_hash_bound_count": receipt_hash_bound_count,
            "receipt_identity_marker_operator_signature_payload_hash_sha_match_count": receipt_sha_count,
            "receipt_identity_marker_authorization_binding_verified_count": receipt_authorization_binding_count,
            "receipt_operator_signature_payload_hash_authorization_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source-path content payload hashes/schema, value identity operator signatures/source bindings, checksum payload hash sha matches, source handoff payload-marker schema/hash quarantine, and receipt operator-signature payload hash authorization bindings.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Hash Signature Binding Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_hash_signature_binding_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
