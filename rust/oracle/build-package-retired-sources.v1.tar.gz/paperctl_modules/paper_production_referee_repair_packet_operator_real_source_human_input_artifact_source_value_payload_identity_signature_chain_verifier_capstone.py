"""Human-input artifact source/value payload identity-signature chain verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-identity-signature-chain-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_count",
    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready_count",
    "upstream_payload_certificate_chain_materialization_ready_count",
    "upstream_payload_certificate_chain_materialization_blocked_count",
    "source_provenance_validator_operator_identity_signature_required_count",
    "source_content_provenance_marker_payload_schema_validated_count",
    "source_content_provenance_marker_payload_hash_sha_match_count",
    "source_content_provenance_marker_payload_validator_hash_bound_count",
    "source_provenance_validator_operator_identity_present_count",
    "source_provenance_validator_operator_identity_hash_bound_count",
    "source_provenance_validator_signature_marker_present_count",
    "source_provenance_validator_signature_marker_valid_count",
    "source_provenance_validator_operator_identity_signature_ready_count",
    "value_certificate_chain_issuer_root_identity_required_count",
    "value_public_identity_operator_signature_certificate_chain_present_count",
    "value_public_identity_operator_signature_certificate_chain_hash_bound_count",
    "value_public_identity_operator_signature_certificate_chain_verified_count",
    "value_certificate_chain_issuer_identity_present_count",
    "value_certificate_chain_issuer_identity_hash_bound_count",
    "value_certificate_chain_root_identity_present_count",
    "value_certificate_chain_root_identity_hash_bound_count",
    "value_certificate_chain_issuer_root_identity_hash_verified_count",
    "value_certificate_chain_issuer_root_identity_ready_count",
    "checksum_materialization_expected_source_digest_chain_comparison_required_count",
    "checksum_expected_digest_source_identity_materialization_hash_present_count",
    "checksum_expected_digest_source_identity_materialization_hash_sha_match_count",
    "checksum_expected_digest_source_identity_materialization_hash_bound_count",
    "checksum_materialization_expected_digest_chain_present_count",
    "checksum_materialization_source_digest_chain_present_count",
    "checksum_materialization_expected_source_digest_chain_match_count",
    "checksum_materialization_digest_chain_comparison_hash_bound_count",
    "checksum_materialization_expected_source_digest_chain_comparison_ready_count",
    "source_attestation_certificate_issuer_quarantine_signature_required_count",
    "source_handoff_source_file_attestation_certificate_present_count",
    "source_handoff_source_file_attestation_certificate_hash_bound_count",
    "source_handoff_source_file_attestation_hash_quarantine_present_count",
    "source_handoff_source_file_attestation_hash_quarantine_sha_match_count",
    "source_attestation_certificate_issuer_identity_present_count",
    "source_attestation_certificate_issuer_identity_hash_bound_count",
    "source_attestation_quarantine_signature_present_count",
    "source_attestation_quarantine_signature_valid_count",
    "source_attestation_certificate_issuer_quarantine_signature_ready_count",
    "receipt_signature_marker_public_identity_certificate_authorization_chain_required_count",
    "receipt_authorization_digest_chain_operator_public_identity_present_count",
    "receipt_authorization_digest_chain_signature_verification_marker_present_count",
    "receipt_authorization_digest_chain_signature_verification_marker_valid_count",
    "receipt_signature_marker_public_identity_certificate_present_count",
    "receipt_signature_marker_public_identity_certificate_hash_bound_count",
    "receipt_authorization_chain_present_count",
    "receipt_authorization_chain_hash_bound_count",
    "receipt_signature_marker_public_identity_authorization_chain_verified_count",
    "receipt_signature_marker_public_identity_certificate_authorization_chain_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _source_identity_signature_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_content_provenance_marker_payload_schema_hash_validator_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_validator_path = (
            item.get("expected_source_content_provenance_marker_payload_schema_hash_validator_path")
            or ""
        )
        expected_signature_path = (
            item.get("expected_source_provenance_validator_operator_identity_signature_marker_path")
            or _sidecar(expected_validator_path, ".operator-identity-signature-marker.json")
        )
        schema_validated = bool(
            item.get("source_content_provenance_marker_payload_schema_validated")
        )
        payload_hash = bool(
            item.get("source_content_provenance_marker_payload_hash_sha_match")
        )
        validator_hash = bool(
            item.get("source_content_provenance_marker_payload_validator_hash_bound")
        )
        operator_identity = bool(
            item.get("source_provenance_validator_operator_identity_present")
        )
        operator_identity_hash = bool(
            item.get("source_provenance_validator_operator_identity_hash_bound")
        )
        signature_marker = bool(
            item.get("source_provenance_validator_signature_marker_present")
        )
        signature_valid = bool(
            item.get("source_provenance_validator_signature_marker_valid")
        )
        template_verified = bool(
            expected_validator_path
            and expected_signature_path
            and str(expected_validator_path).endswith(".json")
            and str(expected_signature_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("source_content_provenance_marker_payload_schema_hash_ready")
            and schema_validated
            and payload_hash
            and validator_hash
            and operator_identity
            and operator_identity_hash
            and signature_marker
            and signature_valid
        )
        payload = {
            "field": field,
            "expected_source_content_provenance_marker_payload_schema_hash_validator_path": expected_validator_path,
            "expected_source_provenance_validator_operator_identity_signature_marker_path": expected_signature_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "source_provenance_validator_operator_identity_signature_marker_id": (
                    f"referee-repair-source-validator-signature-{record_sha[:16]}"
                ),
                "source_provenance_validator_operator_identity_signature_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_content_provenance_marker_payload_schema_hash_validator_path": expected_validator_path,
                "expected_source_provenance_validator_operator_identity_signature_marker_path": expected_signature_path,
                "source_provenance_validator_operator_identity_signature_template_verified": template_verified,
                "source_content_provenance_marker_payload_schema_validated": schema_validated,
                "source_content_provenance_marker_payload_hash_sha_match": payload_hash,
                "source_content_provenance_marker_payload_validator_hash_bound": validator_hash,
                "source_provenance_validator_operator_identity_present": operator_identity,
                "source_provenance_validator_operator_identity_hash_bound": operator_identity_hash,
                "source_provenance_validator_signature_marker_present": signature_marker,
                "source_provenance_validator_signature_marker_valid": signature_valid,
                "source_provenance_validator_operator_identity_signature_ready": ready,
                "upstream_source_content_provenance_marker_payload_schema_hash_ready": bool(
                    item.get("source_content_provenance_marker_payload_schema_hash_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_issuer_root_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_public_identity_operator_signature_certificate_chain_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_certificate_path = (
            item.get("expected_value_public_identity_operator_signature_certificate_chain_path")
            or ""
        )
        expected_issuer_root_path = (
            item.get("expected_value_certificate_chain_issuer_root_identity_hash_path")
            or _sidecar(expected_certificate_path, ".issuer-root-identity-hash.json")
        )
        certificate = bool(
            item.get("value_public_identity_operator_signature_certificate_chain_present")
        )
        certificate_hash = bool(
            item.get("value_public_identity_operator_signature_certificate_chain_hash_bound")
        )
        certificate_verified = bool(
            item.get("value_public_identity_operator_signature_certificate_chain_verified")
        )
        issuer = bool(item.get("value_certificate_chain_issuer_identity_present"))
        issuer_hash = bool(item.get("value_certificate_chain_issuer_identity_hash_bound"))
        root = bool(item.get("value_certificate_chain_root_identity_present"))
        root_hash = bool(item.get("value_certificate_chain_root_identity_hash_bound"))
        issuer_root_verified = bool(
            item.get("value_certificate_chain_issuer_root_identity_hash_verified")
        )
        template_verified = bool(
            expected_certificate_path
            and expected_issuer_root_path
            and str(expected_certificate_path).endswith(".json")
            and str(expected_issuer_root_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("value_public_identity_operator_signature_certificate_chain_ready")
            and certificate
            and certificate_hash
            and certificate_verified
            and issuer
            and issuer_hash
            and root
            and root_hash
            and issuer_root_verified
        )
        payload = {
            "field": field,
            "expected_value_public_identity_operator_signature_certificate_chain_path": expected_certificate_path,
            "expected_value_certificate_chain_issuer_root_identity_hash_path": expected_issuer_root_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "value_certificate_chain_issuer_root_identity_hash_verifier_id": (
                    f"referee-repair-value-issuer-root-{record_sha[:16]}"
                ),
                "value_certificate_chain_issuer_root_identity_hash_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_public_identity_operator_signature_certificate_chain_path": expected_certificate_path,
                "expected_value_certificate_chain_issuer_root_identity_hash_path": expected_issuer_root_path,
                "value_certificate_chain_issuer_root_identity_hash_template_verified": template_verified,
                "value_public_identity_operator_signature_certificate_chain_present": certificate,
                "value_public_identity_operator_signature_certificate_chain_hash_bound": certificate_hash,
                "value_public_identity_operator_signature_certificate_chain_verified": certificate_verified,
                "value_certificate_chain_issuer_identity_present": issuer,
                "value_certificate_chain_issuer_identity_hash_bound": issuer_hash,
                "value_certificate_chain_root_identity_present": root,
                "value_certificate_chain_root_identity_hash_bound": root_hash,
                "value_certificate_chain_issuer_root_identity_hash_verified": issuer_root_verified,
                "value_certificate_chain_issuer_root_identity_ready": ready,
                "upstream_value_public_identity_operator_signature_certificate_chain_ready": bool(
                    item.get("value_public_identity_operator_signature_certificate_chain_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_digest_chain_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_expected_digest_source_identity_materialization_hash_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_materialization_path = (
            item.get("expected_checksum_expected_digest_source_identity_materialization_hash_path")
            or ""
        )
        expected_comparison_path = (
            item.get("expected_checksum_materialization_expected_source_digest_chain_comparison_path")
            or _sidecar(expected_materialization_path, ".expected-source-digest-chain-comparison.json")
        )
        materialization = bool(
            item.get("checksum_expected_digest_source_identity_materialization_hash_present")
        )
        materialization_sha = bool(
            item.get("checksum_expected_digest_source_identity_materialization_hash_sha_match")
        )
        materialization_hash = bool(
            item.get("checksum_expected_digest_source_identity_materialization_hash_bound")
        )
        expected_chain = bool(
            item.get("checksum_materialization_expected_digest_chain_present")
        )
        source_chain = bool(item.get("checksum_materialization_source_digest_chain_present"))
        chain_match = bool(
            item.get("checksum_materialization_expected_source_digest_chain_match")
        )
        comparison_hash = bool(
            item.get("checksum_materialization_digest_chain_comparison_hash_bound")
        )
        template_verified = bool(
            expected_materialization_path
            and expected_comparison_path
            and str(expected_materialization_path).endswith(".json")
            and str(expected_comparison_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("checksum_expected_digest_source_identity_materialization_hash_ready")
            and materialization
            and materialization_sha
            and materialization_hash
            and expected_chain
            and source_chain
            and chain_match
            and comparison_hash
        )
        payload = {
            "field": field,
            "expected_checksum_expected_digest_source_identity_materialization_hash_path": expected_materialization_path,
            "expected_checksum_materialization_expected_source_digest_chain_comparison_path": expected_comparison_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "checksum_materialization_expected_source_digest_chain_comparison_verifier_id": (
                    f"referee-repair-checksum-digest-chain-{record_sha[:16]}"
                ),
                "checksum_materialization_expected_source_digest_chain_comparison_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_expected_digest_source_identity_materialization_hash_path": expected_materialization_path,
                "expected_checksum_materialization_expected_source_digest_chain_comparison_path": expected_comparison_path,
                "checksum_materialization_expected_source_digest_chain_comparison_template_verified": template_verified,
                "checksum_expected_digest_source_identity_materialization_hash_present": materialization,
                "checksum_expected_digest_source_identity_materialization_hash_sha_match": materialization_sha,
                "checksum_expected_digest_source_identity_materialization_hash_bound": materialization_hash,
                "checksum_materialization_expected_digest_chain_present": expected_chain,
                "checksum_materialization_source_digest_chain_present": source_chain,
                "checksum_materialization_expected_source_digest_chain_match": chain_match,
                "checksum_materialization_digest_chain_comparison_hash_bound": comparison_hash,
                "checksum_materialization_expected_source_digest_chain_comparison_ready": ready,
                "upstream_checksum_expected_digest_source_identity_materialization_hash_ready": bool(
                    item.get("checksum_expected_digest_source_identity_materialization_hash_ready")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_certificate_signature(record, payload_sha):
    source = dict(
        record.get("source_handoff_source_file_attestation_certificate_hash_quarantine")
        or {}
    )
    expected_quarantine_path = (
        source.get("expected_source_handoff_source_file_attestation_certificate_hash_quarantine_path")
        or ""
    )
    expected_signature_path = (
        source.get("expected_source_attestation_certificate_issuer_quarantine_signature_path")
        or _sidecar(expected_quarantine_path, ".issuer-identity-quarantine-signature.json")
    )
    certificate = bool(
        source.get("source_handoff_source_file_attestation_certificate_present")
    )
    certificate_hash = bool(
        source.get("source_handoff_source_file_attestation_certificate_hash_bound")
    )
    quarantine = bool(
        source.get("source_handoff_source_file_attestation_hash_quarantine_present")
    )
    quarantine_sha = bool(
        source.get("source_handoff_source_file_attestation_hash_quarantine_sha_match")
    )
    issuer = bool(source.get("source_attestation_certificate_issuer_identity_present"))
    issuer_hash = bool(
        source.get("source_attestation_certificate_issuer_identity_hash_bound")
    )
    signature = bool(source.get("source_attestation_quarantine_signature_present"))
    signature_valid = bool(source.get("source_attestation_quarantine_signature_valid"))
    template_verified = bool(
        expected_quarantine_path
        and expected_signature_path
        and str(expected_quarantine_path).endswith(".json")
        and str(expected_signature_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and source.get("source_handoff_source_file_attestation_certificate_hash_quarantine_ready")
        and certificate
        and certificate_hash
        and quarantine
        and quarantine_sha
        and issuer
        and issuer_hash
        and signature
        and signature_valid
    )
    return {
        "source_attestation_certificate_issuer_quarantine_signature_verifier_id": (
            f"referee-repair-source-certificate-signature-{payload_sha[:16]}"
        ),
        "expected_source_handoff_source_file_attestation_certificate_hash_quarantine_path": expected_quarantine_path,
        "expected_source_attestation_certificate_issuer_quarantine_signature_path": expected_signature_path,
        "source_attestation_certificate_issuer_quarantine_signature_template_verified": template_verified,
        "source_handoff_source_file_attestation_certificate_present": certificate,
        "source_handoff_source_file_attestation_certificate_hash_bound": certificate_hash,
        "source_handoff_source_file_attestation_hash_quarantine_present": quarantine,
        "source_handoff_source_file_attestation_hash_quarantine_sha_match": quarantine_sha,
        "source_attestation_certificate_issuer_identity_present": issuer,
        "source_attestation_certificate_issuer_identity_hash_bound": issuer_hash,
        "source_attestation_quarantine_signature_present": signature,
        "source_attestation_quarantine_signature_valid": signature_valid,
        "source_attestation_certificate_issuer_quarantine_signature_ready": ready,
        "upstream_source_handoff_source_file_attestation_certificate_hash_quarantine_ready": bool(
            source.get("source_handoff_source_file_attestation_certificate_hash_quarantine_ready")
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_certificate_authorization(record, payload_sha):
    receipt = dict(
        record.get("receipt_authorization_digest_chain_operator_identity_signature_verification")
        or {}
    )
    expected_verification_path = (
        receipt.get("expected_receipt_authorization_digest_chain_operator_identity_signature_verification_path")
        or ""
    )
    expected_authorization_path = (
        receipt.get("expected_receipt_signature_marker_public_identity_certificate_authorization_chain_path")
        or _sidecar(expected_verification_path, ".public-identity-certificate-authorization-chain.json")
    )
    public_identity = bool(
        receipt.get("receipt_authorization_digest_chain_operator_public_identity_present")
    )
    marker = bool(
        receipt.get("receipt_authorization_digest_chain_signature_verification_marker_present")
    )
    marker_valid = bool(
        receipt.get("receipt_authorization_digest_chain_signature_verification_marker_valid")
    )
    certificate = bool(
        receipt.get("receipt_signature_marker_public_identity_certificate_present")
    )
    certificate_hash = bool(
        receipt.get("receipt_signature_marker_public_identity_certificate_hash_bound")
    )
    authorization_chain = bool(receipt.get("receipt_authorization_chain_present"))
    authorization_hash = bool(receipt.get("receipt_authorization_chain_hash_bound"))
    chain_verified = bool(
        receipt.get("receipt_signature_marker_public_identity_authorization_chain_verified")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_verification_path
        and expected_authorization_path
        and str(expected_verification_path).endswith(".json")
        and str(expected_authorization_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and receipt.get(
            "receipt_authorization_digest_chain_operator_identity_signature_verification_ready"
        )
        and public_identity
        and marker
        and marker_valid
        and certificate
        and certificate_hash
        and authorization_chain
        and authorization_hash
        and chain_verified
        and not performed
    )
    return {
        "receipt_signature_marker_public_identity_certificate_authorization_chain_verifier_id": (
            f"referee-repair-receipt-certificate-auth-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_digest_chain_operator_identity_signature_verification_path": expected_verification_path,
        "expected_receipt_signature_marker_public_identity_certificate_authorization_chain_path": expected_authorization_path,
        "receipt_signature_marker_public_identity_certificate_authorization_chain_template_verified": template_verified,
        "receipt_authorization_digest_chain_operator_public_identity_present": public_identity,
        "receipt_authorization_digest_chain_signature_verification_marker_present": marker,
        "receipt_authorization_digest_chain_signature_verification_marker_valid": marker_valid,
        "receipt_signature_marker_public_identity_certificate_present": certificate,
        "receipt_signature_marker_public_identity_certificate_hash_bound": certificate_hash,
        "receipt_authorization_chain_present": authorization_chain,
        "receipt_authorization_chain_hash_bound": authorization_hash,
        "receipt_signature_marker_public_identity_authorization_chain_verified": chain_verified,
        "receipt_signature_marker_public_identity_certificate_authorization_chain_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_authorization_digest_chain_operator_identity_signature_verification_ready": bool(
            receipt.get(
                "receipt_authorization_digest_chain_operator_identity_signature_verification_ready"
            )
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_records = _source_identity_signature_records(packet_record, payload_sha)
    value_records = _value_issuer_root_records(packet_record, payload_sha)
    checksum_records = _checksum_digest_chain_records(packet_record, payload_sha)
    source_signature = _source_certificate_signature(packet_record, payload_sha)
    receipt_authorization = _receipt_certificate_authorization(packet_record, payload_sha)
    source_required = _required_count(source_records)
    source_ready = _count(
        source_records, "source_provenance_validator_operator_identity_signature_ready"
    )
    value_required = _required_count(value_records)
    value_ready = _count(value_records, "value_certificate_chain_issuer_root_identity_ready")
    checksum_required = _required_count(checksum_records)
    checksum_ready = _count(
        checksum_records,
        "checksum_materialization_expected_source_digest_chain_comparison_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_authorization.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_signature.get(
            "source_attestation_certificate_issuer_quarantine_signature_ready"
        )
        and receipt_authorization.get(
            "receipt_signature_marker_public_identity_certificate_authorization_chain_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_provenance_validator_operator_identity_signature_missing")
    if value_ready != value_required:
        blockers.append("value_certificate_chain_issuer_root_identity_hash_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_materialization_expected_source_digest_chain_comparison_missing")
    if not source_signature.get(
        "source_attestation_certificate_issuer_quarantine_signature_ready"
    ):
        blockers.append("source_attestation_certificate_issuer_quarantine_signature_missing")
    if not receipt_authorization.get(
        "receipt_signature_marker_public_identity_certificate_authorization_chain_ready"
    ):
        blockers.append("receipt_signature_marker_public_identity_certificate_authorization_chain_missing")
    if consumable:
        blockers.append("payload_identity_signature_chain_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_id": (
            f"referee-repair-human-input-source-value-payload-identity-signature-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_payload_sha256"
            )
            or ""
        ),
        "source_provenance_validator_operator_identity_signature_marker_records": source_records,
        "source_provenance_validator_operator_identity_signature_required_count": source_required,
        "source_provenance_validator_operator_identity_signature_ready_count": source_ready,
        "value_certificate_chain_issuer_root_identity_hash_records": value_records,
        "value_certificate_chain_issuer_root_identity_required_count": value_required,
        "value_certificate_chain_issuer_root_identity_ready_count": value_ready,
        "checksum_materialization_expected_source_digest_chain_comparison_records": checksum_records,
        "checksum_materialization_expected_source_digest_chain_comparison_required_count": checksum_required,
        "checksum_materialization_expected_source_digest_chain_comparison_ready_count": checksum_ready,
        "source_attestation_certificate_issuer_quarantine_signature": source_signature,
        "receipt_signature_marker_public_identity_certificate_authorization_chain": receipt_authorization,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "identity signature chain verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source validator operator identity signatures, value issuer/root identity hashes, checksum expected/source digest-chain comparisons, source attestation issuer signatures, and receipt public identity authorization chains"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_id": (
            f"referee-repair-request-human-input-source-value-payload-identity-signature-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_provenance_validator_operator_identity_signature_marker_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get("value_certificate_chain_issuer_root_identity_hash_records")
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_materialization_expected_source_digest_chain_comparison_records"
        )
        or []
    ]
    source_signature_records = [
        record.get("source_attestation_certificate_issuer_quarantine_signature") or {}
        for record in verifier_records
    ]
    receipt_authorization_records = [
        record.get("receipt_signature_marker_public_identity_certificate_authorization_chain")
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_ready"
        )
    )
    source_required = _required_count(source_records)
    source_schema_count = _count(
        source_records, "source_content_provenance_marker_payload_schema_validated"
    )
    source_payload_hash_count = _count(
        source_records, "source_content_provenance_marker_payload_hash_sha_match"
    )
    source_validator_hash_count = _count(
        source_records, "source_content_provenance_marker_payload_validator_hash_bound"
    )
    source_identity_count = _count(
        source_records, "source_provenance_validator_operator_identity_present"
    )
    source_identity_hash_count = _count(
        source_records, "source_provenance_validator_operator_identity_hash_bound"
    )
    source_signature_marker_count = _count(
        source_records, "source_provenance_validator_signature_marker_present"
    )
    source_signature_valid_count = _count(
        source_records, "source_provenance_validator_signature_marker_valid"
    )
    source_ready_count = _count(
        source_records, "source_provenance_validator_operator_identity_signature_ready"
    )
    value_required = _required_count(value_records)
    value_certificate_count = _count(
        value_records, "value_public_identity_operator_signature_certificate_chain_present"
    )
    value_certificate_hash_count = _count(
        value_records, "value_public_identity_operator_signature_certificate_chain_hash_bound"
    )
    value_certificate_verified_count = _count(
        value_records, "value_public_identity_operator_signature_certificate_chain_verified"
    )
    value_issuer_count = _count(
        value_records, "value_certificate_chain_issuer_identity_present"
    )
    value_issuer_hash_count = _count(
        value_records, "value_certificate_chain_issuer_identity_hash_bound"
    )
    value_root_count = _count(value_records, "value_certificate_chain_root_identity_present")
    value_root_hash_count = _count(
        value_records, "value_certificate_chain_root_identity_hash_bound"
    )
    value_issuer_root_verified_count = _count(
        value_records, "value_certificate_chain_issuer_root_identity_hash_verified"
    )
    value_ready_count = _count(
        value_records, "value_certificate_chain_issuer_root_identity_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_materialization_count = _count(
        checksum_records,
        "checksum_expected_digest_source_identity_materialization_hash_present",
    )
    checksum_materialization_sha_count = _count(
        checksum_records,
        "checksum_expected_digest_source_identity_materialization_hash_sha_match",
    )
    checksum_materialization_hash_count = _count(
        checksum_records,
        "checksum_expected_digest_source_identity_materialization_hash_bound",
    )
    checksum_expected_chain_count = _count(
        checksum_records, "checksum_materialization_expected_digest_chain_present"
    )
    checksum_source_chain_count = _count(
        checksum_records, "checksum_materialization_source_digest_chain_present"
    )
    checksum_chain_match_count = _count(
        checksum_records, "checksum_materialization_expected_source_digest_chain_match"
    )
    checksum_comparison_hash_count = _count(
        checksum_records, "checksum_materialization_digest_chain_comparison_hash_bound"
    )
    checksum_ready_count = _count(
        checksum_records,
        "checksum_materialization_expected_source_digest_chain_comparison_ready",
    )
    source_signature_required = record_count
    source_certificate_count = sum(
        1
        for item in source_signature_records
        if item.get("source_handoff_source_file_attestation_certificate_present")
    )
    source_certificate_hash_count = sum(
        1
        for item in source_signature_records
        if item.get("source_handoff_source_file_attestation_certificate_hash_bound")
    )
    source_quarantine_count = sum(
        1
        for item in source_signature_records
        if item.get("source_handoff_source_file_attestation_hash_quarantine_present")
    )
    source_quarantine_sha_count = sum(
        1
        for item in source_signature_records
        if item.get("source_handoff_source_file_attestation_hash_quarantine_sha_match")
    )
    source_issuer_count = sum(
        1
        for item in source_signature_records
        if item.get("source_attestation_certificate_issuer_identity_present")
    )
    source_issuer_hash_count = sum(
        1
        for item in source_signature_records
        if item.get("source_attestation_certificate_issuer_identity_hash_bound")
    )
    source_quarantine_signature_count = sum(
        1
        for item in source_signature_records
        if item.get("source_attestation_quarantine_signature_present")
    )
    source_quarantine_signature_valid_count = sum(
        1
        for item in source_signature_records
        if item.get("source_attestation_quarantine_signature_valid")
    )
    source_signature_ready_count = sum(
        1
        for item in source_signature_records
        if item.get("source_attestation_certificate_issuer_quarantine_signature_ready")
    )
    receipt_required = record_count
    receipt_public_identity_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_authorization_digest_chain_operator_public_identity_present")
    )
    receipt_marker_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_authorization_digest_chain_signature_verification_marker_present")
    )
    receipt_marker_valid_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_authorization_digest_chain_signature_verification_marker_valid")
    )
    receipt_certificate_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_signature_marker_public_identity_certificate_present")
    )
    receipt_certificate_hash_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_signature_marker_public_identity_certificate_hash_bound")
    )
    receipt_authorization_chain_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_authorization_chain_present")
    )
    receipt_authorization_chain_hash_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_authorization_chain_hash_bound")
    )
    receipt_chain_verified_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_signature_marker_public_identity_authorization_chain_verified")
    )
    receipt_ready_count = sum(
        1
        for item in receipt_authorization_records
        if item.get(
            "receipt_signature_marker_public_identity_certificate_authorization_chain_ready"
        )
    )
    receipt_performed_count = sum(
        1
        for item in receipt_authorization_records
        if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1 for item in verifier_records if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1 for item in verifier_records if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1 for item in verifier_records if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1 for item in verifier_records if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_signature_ready_count == source_signature_required
        and receipt_ready_count == receipt_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_certificate_chain_materialization_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_certificate_chain_materialization_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_provenance_validator_operator_identity_signatures_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} identity={source_identity_count} signature={source_signature_marker_count}",
    )
    _add_check(
        checks,
        "value_certificate_chain_issuer_root_identity_hashes_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} issuer={value_issuer_count} root={value_root_count}",
    )
    _add_check(
        checks,
        "checksum_materialization_expected_source_digest_chain_comparisons_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} expected_chain={checksum_expected_chain_count} source_chain={checksum_source_chain_count}",
    )
    _add_check(
        checks,
        "source_attestation_certificate_issuer_quarantine_signatures_ready",
        source_signature_required > 0
        and source_signature_ready_count == source_signature_required,
        f"ready={source_signature_ready_count}/{source_signature_required} issuer={source_issuer_count} signature={source_quarantine_signature_count}",
    )
    _add_check(
        checks,
        "receipt_signature_marker_public_identity_certificate_authorization_chains_ready",
        receipt_required > 0 and receipt_ready_count == receipt_required,
        f"ready={receipt_ready_count}/{receipt_required} certificate={receipt_certificate_count} authorization={receipt_authorization_chain_count}",
    )
    _add_check(
        checks,
        "all_request_payload_identity_signature_chain_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_identity_signature_chain_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_IDENTITY_SIGNATURE_CHAIN_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_IDENTITY_SIGNATURE_CHAIN_UPSTREAM_LINT"
    elif (
        source_schema_count != source_required
        or source_payload_hash_count != source_required
        or source_validator_hash_count != source_required
        or source_identity_count != source_required
        or source_identity_hash_count != source_required
        or source_signature_marker_count != source_required
        or source_signature_valid_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_PROVENANCE_VALIDATOR_OPERATOR_IDENTITY_SIGNATURE_MARKER_MISSING"
    elif (
        value_certificate_count != value_required
        or value_certificate_hash_count != value_required
        or value_certificate_verified_count != value_required
        or value_issuer_count != value_required
        or value_issuer_hash_count != value_required
        or value_root_count != value_required
        or value_root_hash_count != value_required
        or value_issuer_root_verified_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_CERTIFICATE_CHAIN_ISSUER_ROOT_IDENTITY_HASH_MISSING"
    elif (
        checksum_materialization_count != checksum_required
        or checksum_materialization_sha_count != checksum_required
        or checksum_materialization_hash_count != checksum_required
        or checksum_expected_chain_count != checksum_required
        or checksum_source_chain_count != checksum_required
        or checksum_chain_match_count != checksum_required
        or checksum_comparison_hash_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_MATERIALIZATION_EXPECTED_SOURCE_DIGEST_CHAIN_COMPARISON_MISSING"
    elif (
        source_certificate_count != source_signature_required
        or source_certificate_hash_count != source_signature_required
        or source_quarantine_count != source_signature_required
        or source_quarantine_sha_count != source_signature_required
        or source_issuer_count != source_signature_required
        or source_issuer_hash_count != source_signature_required
        or source_quarantine_signature_count != source_signature_required
        or source_quarantine_signature_valid_count != source_signature_required
        or source_signature_ready_count != source_signature_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_ATTESTATION_CERTIFICATE_ISSUER_QUARANTINE_SIGNATURE_MISSING"
    elif (
        receipt_public_identity_count != receipt_required
        or receipt_marker_count != receipt_required
        or receipt_marker_valid_count != receipt_required
        or receipt_certificate_count != receipt_required
        or receipt_certificate_hash_count != receipt_required
        or receipt_authorization_chain_count != receipt_required
        or receipt_authorization_chain_hash_count != receipt_required
        or receipt_chain_verified_count != receipt_required
        or receipt_ready_count != receipt_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_SIGNATURE_MARKER_PUBLIC_IDENTITY_CERTIFICATE_AUTHORIZATION_CHAIN_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_IDENTITY_SIGNATURE_CHAIN_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_IDENTITY_SIGNATURE_CHAIN_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_IDENTITY_SIGNATURE_CHAIN_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_IDENTITY_SIGNATURE_CHAIN_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_certificate_chain_materialization_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready_count": lint_ready_count,
            "upstream_payload_certificate_chain_materialization_ready_count": upstream_ready_count,
            "upstream_payload_certificate_chain_materialization_blocked_count": record_count - upstream_ready_count,
            "source_provenance_validator_operator_identity_signature_required_count": source_required,
            "source_content_provenance_marker_payload_schema_validated_count": source_schema_count,
            "source_content_provenance_marker_payload_hash_sha_match_count": source_payload_hash_count,
            "source_content_provenance_marker_payload_validator_hash_bound_count": source_validator_hash_count,
            "source_provenance_validator_operator_identity_present_count": source_identity_count,
            "source_provenance_validator_operator_identity_hash_bound_count": source_identity_hash_count,
            "source_provenance_validator_signature_marker_present_count": source_signature_marker_count,
            "source_provenance_validator_signature_marker_valid_count": source_signature_valid_count,
            "source_provenance_validator_operator_identity_signature_ready_count": source_ready_count,
            "value_certificate_chain_issuer_root_identity_required_count": value_required,
            "value_public_identity_operator_signature_certificate_chain_present_count": value_certificate_count,
            "value_public_identity_operator_signature_certificate_chain_hash_bound_count": value_certificate_hash_count,
            "value_public_identity_operator_signature_certificate_chain_verified_count": value_certificate_verified_count,
            "value_certificate_chain_issuer_identity_present_count": value_issuer_count,
            "value_certificate_chain_issuer_identity_hash_bound_count": value_issuer_hash_count,
            "value_certificate_chain_root_identity_present_count": value_root_count,
            "value_certificate_chain_root_identity_hash_bound_count": value_root_hash_count,
            "value_certificate_chain_issuer_root_identity_hash_verified_count": value_issuer_root_verified_count,
            "value_certificate_chain_issuer_root_identity_ready_count": value_ready_count,
            "checksum_materialization_expected_source_digest_chain_comparison_required_count": checksum_required,
            "checksum_expected_digest_source_identity_materialization_hash_present_count": checksum_materialization_count,
            "checksum_expected_digest_source_identity_materialization_hash_sha_match_count": checksum_materialization_sha_count,
            "checksum_expected_digest_source_identity_materialization_hash_bound_count": checksum_materialization_hash_count,
            "checksum_materialization_expected_digest_chain_present_count": checksum_expected_chain_count,
            "checksum_materialization_source_digest_chain_present_count": checksum_source_chain_count,
            "checksum_materialization_expected_source_digest_chain_match_count": checksum_chain_match_count,
            "checksum_materialization_digest_chain_comparison_hash_bound_count": checksum_comparison_hash_count,
            "checksum_materialization_expected_source_digest_chain_comparison_ready_count": checksum_ready_count,
            "source_attestation_certificate_issuer_quarantine_signature_required_count": source_signature_required,
            "source_handoff_source_file_attestation_certificate_present_count": source_certificate_count,
            "source_handoff_source_file_attestation_certificate_hash_bound_count": source_certificate_hash_count,
            "source_handoff_source_file_attestation_hash_quarantine_present_count": source_quarantine_count,
            "source_handoff_source_file_attestation_hash_quarantine_sha_match_count": source_quarantine_sha_count,
            "source_attestation_certificate_issuer_identity_present_count": source_issuer_count,
            "source_attestation_certificate_issuer_identity_hash_bound_count": source_issuer_hash_count,
            "source_attestation_quarantine_signature_present_count": source_quarantine_signature_count,
            "source_attestation_quarantine_signature_valid_count": source_quarantine_signature_valid_count,
            "source_attestation_certificate_issuer_quarantine_signature_ready_count": source_signature_ready_count,
            "receipt_signature_marker_public_identity_certificate_authorization_chain_required_count": receipt_required,
            "receipt_authorization_digest_chain_operator_public_identity_present_count": receipt_public_identity_count,
            "receipt_authorization_digest_chain_signature_verification_marker_present_count": receipt_marker_count,
            "receipt_authorization_digest_chain_signature_verification_marker_valid_count": receipt_marker_valid_count,
            "receipt_signature_marker_public_identity_certificate_present_count": receipt_certificate_count,
            "receipt_signature_marker_public_identity_certificate_hash_bound_count": receipt_certificate_hash_count,
            "receipt_authorization_chain_present_count": receipt_authorization_chain_count,
            "receipt_authorization_chain_hash_bound_count": receipt_authorization_chain_hash_count,
            "receipt_signature_marker_public_identity_authorization_chain_verified_count": receipt_chain_verified_count,
            "receipt_signature_marker_public_identity_certificate_authorization_chain_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source provenance validator operator identity/signature markers, value certificate-chain issuer/root identity hashes, checksum expected/source digest-chain comparisons, source attestation certificate issuer/quarantine signatures, and receipt public identity certificate/authorization chains.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Identity Signature Chain Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
