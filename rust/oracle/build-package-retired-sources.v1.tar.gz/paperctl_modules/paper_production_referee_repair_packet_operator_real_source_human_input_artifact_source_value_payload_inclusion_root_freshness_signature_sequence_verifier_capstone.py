"""Human-input artifact source/value payload inclusion/root verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-inclusion-root-freshness-signature-sequence-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_count",
    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_lint_ready_count",
    "upstream_payload_signed_root_transparency_freshness_sequence_ready_count",
    "upstream_payload_signed_root_transparency_freshness_sequence_blocked_count",
    "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_required_count",
    "source_signed_root_transparency_inclusion_log_checkpoint_present_count",
    "source_signed_root_transparency_inclusion_log_checkpoint_valid_count",
    "source_signed_root_transparency_root_consistency_present_count",
    "source_signed_root_transparency_root_consistency_valid_count",
    "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready_count",
    "value_timestamp_signer_certificate_chain_root_freshness_authority_required_count",
    "value_timestamp_signer_certificate_chain_present_count",
    "value_timestamp_signer_certificate_chain_valid_count",
    "value_root_freshness_authority_present_count",
    "value_root_freshness_authority_valid_count",
    "value_timestamp_signer_certificate_chain_root_freshness_authority_ready_count",
    "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_required_count",
    "checksum_transparency_inclusion_merkle_proof_present_count",
    "checksum_transparency_inclusion_merkle_proof_valid_count",
    "checksum_revocation_authority_signature_present_count",
    "checksum_revocation_authority_signature_valid_count",
    "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready_count",
    "source_checkpoint_signature_public_key_session_sequence_monotonicity_required_count",
    "source_checkpoint_signature_public_key_present_count",
    "source_checkpoint_signature_public_key_valid_count",
    "source_session_sequence_monotonicity_present_count",
    "source_session_sequence_monotonicity_valid_count",
    "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready_count",
    "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_required_count",
    "receipt_certificate_chain_revocation_authority_freshness_present_count",
    "receipt_certificate_chain_revocation_authority_freshness_valid_count",
    "receipt_certificate_chain_revocation_timestamp_signer_present_count",
    "receipt_certificate_chain_revocation_timestamp_signer_valid_count",
    "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _sum(records, key):
    return sum(1 for item in records if item.get(key))


def _source_inclusion_root_consistency_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_certificate_chain_root_proof_signed_root_operator_transparency_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_parent_path = (
            item.get(
                "expected_source_certificate_chain_root_proof_signed_root_operator_transparency_path"
            )
            or ""
        )
        expected_path = (
            item.get(
                "expected_source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_path"
            )
            or _sidecar(
                expected_parent_path,
                ".inclusion-log-checkpoint-root-consistency.json",
            )
        )
        upstream_ready = bool(
            item.get(
                "source_certificate_chain_root_proof_signed_root_operator_transparency_ready"
            )
        )
        inclusion = bool(
            item.get("source_signed_root_transparency_inclusion_log_checkpoint_present")
        )
        inclusion_valid = bool(
            item.get("source_signed_root_transparency_inclusion_log_checkpoint_valid")
        )
        consistency = bool(
            item.get("source_signed_root_transparency_root_consistency_present")
        )
        consistency_valid = bool(
            item.get("source_signed_root_transparency_root_consistency_valid")
        )
        template_verified = bool(
            expected_parent_path
            and expected_path
            and str(expected_parent_path).endswith(".json")
            and str(expected_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("source_certificate_chain_signed_root_present")
            and item.get("source_certificate_chain_signed_root_valid")
            and item.get("source_certificate_chain_operator_transparency_present")
            and item.get("source_certificate_chain_operator_transparency_valid")
            and inclusion
            and inclusion_valid
            and consistency
            and consistency_valid
        )
        record_sha = _sha(
            {
                "field": field,
                "expected_source_certificate_chain_root_proof_signed_root_operator_transparency_path": expected_parent_path,
                "expected_source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_path": expected_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_id": (
                    f"referee-repair-source-signed-root-inclusion-root-{field}-{record_sha[:16]}"
                ),
                "field": field,
                "required": required,
                "expected_source_certificate_chain_root_proof_signed_root_operator_transparency_path": expected_parent_path,
                "expected_source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_path": expected_path,
                "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_template_verified": template_verified,
                "source_certificate_chain_signed_root_present": bool(
                    item.get("source_certificate_chain_signed_root_present")
                ),
                "source_certificate_chain_operator_transparency_present": bool(
                    item.get("source_certificate_chain_operator_transparency_present")
                ),
                "source_signed_root_transparency_inclusion_log_checkpoint_present": inclusion,
                "source_signed_root_transparency_inclusion_log_checkpoint_valid": inclusion_valid,
                "source_signed_root_transparency_root_consistency_present": consistency,
                "source_signed_root_transparency_root_consistency_valid": consistency_valid,
                "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready": ready,
                "upstream_source_certificate_chain_root_proof_signed_root_operator_transparency_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_root_freshness_authority_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_authority_clock_skew_timestamp_signer_root_freshness_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_parent_path = (
            item.get("expected_value_authority_clock_skew_timestamp_signer_root_freshness_path")
            or ""
        )
        expected_path = (
            item.get(
                "expected_value_timestamp_signer_certificate_chain_root_freshness_authority_path"
            )
            or _sidecar(
                expected_parent_path,
                ".timestamp-signer-certificate-chain-root-freshness-authority.json",
            )
        )
        upstream_ready = bool(
            item.get("value_authority_clock_skew_timestamp_signer_root_freshness_ready")
        )
        chain = bool(item.get("value_timestamp_signer_certificate_chain_present"))
        chain_valid = bool(item.get("value_timestamp_signer_certificate_chain_valid"))
        authority = bool(item.get("value_root_freshness_authority_present"))
        authority_valid = bool(item.get("value_root_freshness_authority_valid"))
        template_verified = bool(
            expected_parent_path
            and expected_path
            and str(expected_parent_path).endswith(".json")
            and str(expected_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("value_authority_clock_skew_timestamp_signer_present")
            and item.get("value_authority_clock_skew_timestamp_signer_valid")
            and item.get("value_authority_root_freshness_present")
            and item.get("value_authority_root_freshness_valid")
            and chain
            and chain_valid
            and authority
            and authority_valid
        )
        record_sha = _sha(
            {
                "field": field,
                "expected_value_authority_clock_skew_timestamp_signer_root_freshness_path": expected_parent_path,
                "expected_value_timestamp_signer_certificate_chain_root_freshness_authority_path": expected_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                "value_timestamp_signer_certificate_chain_root_freshness_authority_id": (
                    f"referee-repair-value-timestamp-root-authority-{field}-{record_sha[:16]}"
                ),
                "field": field,
                "required": required,
                "expected_value_authority_clock_skew_timestamp_signer_root_freshness_path": expected_parent_path,
                "expected_value_timestamp_signer_certificate_chain_root_freshness_authority_path": expected_path,
                "value_timestamp_signer_certificate_chain_root_freshness_authority_template_verified": template_verified,
                "value_authority_clock_skew_timestamp_signer_present": bool(
                    item.get("value_authority_clock_skew_timestamp_signer_present")
                ),
                "value_authority_root_freshness_present": bool(
                    item.get("value_authority_root_freshness_present")
                ),
                "value_timestamp_signer_certificate_chain_present": chain,
                "value_timestamp_signer_certificate_chain_valid": chain_valid,
                "value_root_freshness_authority_present": authority,
                "value_root_freshness_authority_valid": authority_valid,
                "value_timestamp_signer_certificate_chain_root_freshness_authority_ready": ready,
                "upstream_value_authority_clock_skew_timestamp_signer_root_freshness_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_signature_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_operator_certificate_transparency_inclusion_revocation_authority_freshness_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_parent_path = (
            item.get(
                "expected_checksum_operator_certificate_transparency_inclusion_revocation_authority_freshness_path"
            )
            or ""
        )
        expected_path = (
            item.get(
                "expected_checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_path"
            )
            or _sidecar(
                expected_parent_path,
                ".merkle-proof-revocation-authority-signature.json",
            )
        )
        upstream_ready = bool(
            item.get(
                "checksum_operator_certificate_transparency_inclusion_revocation_authority_freshness_ready"
            )
        )
        proof = bool(item.get("checksum_transparency_inclusion_merkle_proof_present"))
        proof_valid = bool(item.get("checksum_transparency_inclusion_merkle_proof_valid"))
        signature = bool(item.get("checksum_revocation_authority_signature_present"))
        signature_valid = bool(item.get("checksum_revocation_authority_signature_valid"))
        template_verified = bool(
            expected_parent_path
            and expected_path
            and str(expected_parent_path).endswith(".json")
            and str(expected_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("checksum_operator_certificate_transparency_inclusion_present")
            and item.get("checksum_operator_certificate_transparency_inclusion_valid")
            and item.get(
                "checksum_operator_certificate_revocation_authority_freshness_present"
            )
            and item.get(
                "checksum_operator_certificate_revocation_authority_freshness_valid"
            )
            and proof
            and proof_valid
            and signature
            and signature_valid
        )
        record_sha = _sha(
            {
                "field": field,
                "expected_checksum_operator_certificate_transparency_inclusion_revocation_authority_freshness_path": expected_parent_path,
                "expected_checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_path": expected_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_id": (
                    f"referee-repair-checksum-inclusion-signature-{field}-{record_sha[:16]}"
                ),
                "field": field,
                "required": required,
                "expected_checksum_operator_certificate_transparency_inclusion_revocation_authority_freshness_path": expected_parent_path,
                "expected_checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_path": expected_path,
                "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_template_verified": template_verified,
                "checksum_operator_certificate_transparency_inclusion_present": bool(
                    item.get("checksum_operator_certificate_transparency_inclusion_present")
                ),
                "checksum_operator_certificate_revocation_authority_freshness_present": bool(
                    item.get(
                        "checksum_operator_certificate_revocation_authority_freshness_present"
                    )
                ),
                "checksum_transparency_inclusion_merkle_proof_present": proof,
                "checksum_transparency_inclusion_merkle_proof_valid": proof_valid,
                "checksum_revocation_authority_signature_present": signature,
                "checksum_revocation_authority_signature_valid": signature_valid,
                "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready": ready,
                "upstream_checksum_operator_certificate_transparency_inclusion_revocation_authority_freshness_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_checkpoint_monotonicity_record(packet_record, payload_sha):
    source = dict(
        packet_record.get("source_audit_proof_append_only_checkpoint_signature_sequence")
        or {}
    )
    expected_parent_path = (
        source.get("expected_source_audit_proof_append_only_checkpoint_signature_sequence_path")
        or ""
    )
    expected_path = (
        source.get(
            "expected_source_checkpoint_signature_public_key_session_sequence_monotonicity_path"
        )
        or _sidecar(
            expected_parent_path,
            ".checkpoint-signature-public-key-session-sequence-monotonicity.json",
        )
    )
    upstream_ready = bool(
        source.get("source_audit_proof_append_only_checkpoint_signature_sequence_ready")
    )
    public_key = bool(source.get("source_checkpoint_signature_public_key_present"))
    public_key_valid = bool(source.get("source_checkpoint_signature_public_key_valid"))
    monotonicity = bool(source.get("source_session_sequence_monotonicity_present"))
    monotonicity_valid = bool(source.get("source_session_sequence_monotonicity_valid"))
    template_verified = bool(
        expected_parent_path
        and expected_path
        and str(expected_parent_path).endswith(".json")
        and str(expected_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and source.get("source_audit_proof_append_only_checkpoint_signature_present")
        and source.get("source_audit_proof_append_only_checkpoint_signature_valid")
        and source.get("source_audit_proof_append_only_checkpoint_sequence_present")
        and source.get("source_audit_proof_append_only_checkpoint_sequence_valid")
        and public_key
        and public_key_valid
        and monotonicity
        and monotonicity_valid
    )
    return {
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_id": (
            f"referee-repair-source-checkpoint-monotonicity-{payload_sha[:16]}"
        ),
        "required": True,
        "expected_source_audit_proof_append_only_checkpoint_signature_sequence_path": expected_parent_path,
        "expected_source_checkpoint_signature_public_key_session_sequence_monotonicity_path": expected_path,
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_template_verified": template_verified,
        "source_audit_proof_append_only_checkpoint_signature_present": bool(
            source.get("source_audit_proof_append_only_checkpoint_signature_present")
        ),
        "source_audit_proof_append_only_checkpoint_sequence_present": bool(
            source.get("source_audit_proof_append_only_checkpoint_sequence_present")
        ),
        "source_checkpoint_signature_public_key_present": public_key,
        "source_checkpoint_signature_public_key_valid": public_key_valid,
        "source_session_sequence_monotonicity_present": monotonicity,
        "source_session_sequence_monotonicity_valid": monotonicity_valid,
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready": ready,
        "upstream_source_audit_proof_append_only_checkpoint_signature_sequence_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_timestamp_signer_record(packet_record, payload_sha):
    receipt = dict(
        packet_record.get("receipt_freshness_timestamp_signature_certificate_chain_revocation")
        or {}
    )
    expected_parent_path = (
        receipt.get("expected_receipt_freshness_timestamp_signature_certificate_chain_revocation_path")
        or ""
    )
    expected_path = (
        receipt.get(
            "expected_receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_path"
        )
        or _sidecar(
            expected_parent_path,
            ".revocation-authority-freshness-timestamp-signer.json",
        )
    )
    performed = bool(
        receipt.get("receipt_authorization_performed")
        or packet_record.get("receipt_authorization_performed")
    )
    upstream_ready = bool(
        receipt.get("receipt_freshness_timestamp_signature_certificate_chain_revocation_ready")
    )
    authority = bool(
        receipt.get("receipt_certificate_chain_revocation_authority_freshness_present")
    )
    authority_valid = bool(
        receipt.get("receipt_certificate_chain_revocation_authority_freshness_valid")
    )
    signer = bool(receipt.get("receipt_certificate_chain_revocation_timestamp_signer_present"))
    signer_valid = bool(
        receipt.get("receipt_certificate_chain_revocation_timestamp_signer_valid")
    )
    template_verified = bool(
        expected_parent_path
        and expected_path
        and str(expected_parent_path).endswith(".json")
        and str(expected_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and receipt.get("receipt_freshness_timestamp_signature_certificate_chain_present")
        and receipt.get("receipt_freshness_timestamp_signature_certificate_chain_valid")
        and receipt.get("receipt_freshness_timestamp_signature_certificate_revocation_checked")
        and receipt.get("receipt_freshness_timestamp_signature_certificate_not_revoked")
        and authority
        and authority_valid
        and signer
        and signer_valid
        and not performed
    )
    return {
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_id": (
            f"referee-repair-receipt-revocation-authority-signer-{payload_sha[:16]}"
        ),
        "required": True,
        "expected_receipt_freshness_timestamp_signature_certificate_chain_revocation_path": expected_parent_path,
        "expected_receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_path": expected_path,
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_template_verified": template_verified,
        "receipt_freshness_timestamp_signature_certificate_chain_present": bool(
            receipt.get("receipt_freshness_timestamp_signature_certificate_chain_present")
        ),
        "receipt_freshness_timestamp_signature_certificate_revocation_checked": bool(
            receipt.get("receipt_freshness_timestamp_signature_certificate_revocation_checked")
        ),
        "receipt_certificate_chain_revocation_authority_freshness_present": authority,
        "receipt_certificate_chain_revocation_authority_freshness_valid": authority_valid,
        "receipt_certificate_chain_revocation_timestamp_signer_present": signer,
        "receipt_certificate_chain_revocation_timestamp_signer_valid": signer_valid,
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_freshness_timestamp_signature_certificate_chain_revocation_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload_sha = _sha(
        {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_record.v1"
            ),
            "request_id": packet_record.get("request_id"),
            "slug": packet_record.get("slug") or "",
            "packet_type": packet_record.get("packet_type") or "",
            "parent_payload_sha256": packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_payload_sha256"
            )
            or "",
        }
    )
    source_records = _source_inclusion_root_consistency_records(packet_record, payload_sha)
    value_records = _value_root_freshness_authority_records(packet_record, payload_sha)
    checksum_records = _checksum_signature_records(packet_record, payload_sha)
    source_monotonicity = _source_checkpoint_monotonicity_record(packet_record, payload_sha)
    receipt_signer = _receipt_timestamp_signer_record(packet_record, payload_sha)
    source_required = _required_count(source_records)
    value_required = _required_count(value_records)
    checksum_required = _required_count(checksum_records)
    source_ready = _count(
        source_records,
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready",
    )
    value_ready = _count(
        value_records,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_ready",
    )
    checksum_ready = _count(
        checksum_records,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_signer.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_ready"
        )
        and source_ready == source_required
        and value_ready == value_required
        and checksum_ready == checksum_required
        and source_monotonicity.get(
            "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready"
        )
        and receipt_signer.get(
            "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_missing")
    if value_ready != value_required:
        blockers.append("value_timestamp_signer_certificate_chain_root_freshness_authority_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_missing")
    if not source_monotonicity.get(
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready"
    ):
        blockers.append("source_checkpoint_signature_public_key_session_sequence_monotonicity_missing")
    if not receipt_signer.get(
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready"
    ):
        blockers.append("receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_missing")
    if consumable:
        blockers.append("payload_inclusion_root_freshness_signature_sequence_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_id": (
            f"referee-repair-human-input-source-value-payload-inclusion-seq-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_payload_sha256"
            )
            or ""
        ),
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_records": source_records,
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_required_count": source_required,
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready_count": source_ready,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_records": value_records,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_required_count": value_required,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_ready_count": value_ready,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_records": checksum_records,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_required_count": checksum_required,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready_count": checksum_ready,
        "source_checkpoint_signature_public_key_session_sequence_monotonicity": source_monotonicity,
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer": receipt_signer,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "inclusion/root freshness/signature/sequence verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source signed-root transparency inclusion/root consistency, value timestamp signer certificate-chain/root freshness authority, checksum Merkle proof/revocation-authority signature, source checkpoint public-key/sequence monotonicity, and receipt revocation-authority freshness/timestamp signer markers"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready"
        )
    ]
    payload_sha = _sha(
        {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_record.v1"
            ),
            "request_id": request_id,
            "slug": slug,
            "payload_sha256s": [
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_payload_sha256"
                )
                for item in verifier_records
            ],
        }
    )
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_id": (
            f"referee-repair-request-human-input-source-value-payload-inclusion-seq-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "value_timestamp_signer_certificate_chain_root_freshness_authority_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_records"
        )
        or []
    ]
    source_sequence_records = [
        record.get("source_checkpoint_signature_public_key_session_sequence_monotonicity")
        or {}
        for record in verifier_records
    ]
    receipt_records = [
        record.get(
            "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_hash_bound",
    )
    lint_ready_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_lint_ready",
    )
    upstream_ready_count = _sum(
        upstream_packet_records,
        "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_ready",
    )
    source_required = _required_count(source_records)
    source_inclusion_count = _count(
        source_records, "source_signed_root_transparency_inclusion_log_checkpoint_present"
    )
    source_inclusion_valid_count = _count(
        source_records, "source_signed_root_transparency_inclusion_log_checkpoint_valid"
    )
    source_consistency_count = _count(
        source_records, "source_signed_root_transparency_root_consistency_present"
    )
    source_consistency_valid_count = _count(
        source_records, "source_signed_root_transparency_root_consistency_valid"
    )
    source_ready_count = _count(
        source_records,
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready",
    )
    value_required = _required_count(value_records)
    value_chain_count = _count(
        value_records, "value_timestamp_signer_certificate_chain_present"
    )
    value_chain_valid_count = _count(
        value_records, "value_timestamp_signer_certificate_chain_valid"
    )
    value_authority_count = _count(
        value_records, "value_root_freshness_authority_present"
    )
    value_authority_valid_count = _count(
        value_records, "value_root_freshness_authority_valid"
    )
    value_ready_count = _count(
        value_records,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_ready",
    )
    checksum_required = _required_count(checksum_records)
    checksum_proof_count = _count(
        checksum_records, "checksum_transparency_inclusion_merkle_proof_present"
    )
    checksum_proof_valid_count = _count(
        checksum_records, "checksum_transparency_inclusion_merkle_proof_valid"
    )
    checksum_signature_count = _count(
        checksum_records, "checksum_revocation_authority_signature_present"
    )
    checksum_signature_valid_count = _count(
        checksum_records, "checksum_revocation_authority_signature_valid"
    )
    checksum_ready_count = _count(
        checksum_records,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready",
    )
    source_sequence_required = record_count
    source_public_key_count = _sum(
        source_sequence_records, "source_checkpoint_signature_public_key_present"
    )
    source_public_key_valid_count = _sum(
        source_sequence_records, "source_checkpoint_signature_public_key_valid"
    )
    source_monotonicity_count = _sum(
        source_sequence_records, "source_session_sequence_monotonicity_present"
    )
    source_monotonicity_valid_count = _sum(
        source_sequence_records, "source_session_sequence_monotonicity_valid"
    )
    source_sequence_ready_count = _sum(
        source_sequence_records,
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready",
    )
    receipt_required = record_count
    receipt_authority_count = _sum(
        receipt_records,
        "receipt_certificate_chain_revocation_authority_freshness_present",
    )
    receipt_authority_valid_count = _sum(
        receipt_records,
        "receipt_certificate_chain_revocation_authority_freshness_valid",
    )
    receipt_signer_count = _sum(
        receipt_records,
        "receipt_certificate_chain_revocation_timestamp_signer_present",
    )
    receipt_signer_valid_count = _sum(
        receipt_records,
        "receipt_certificate_chain_revocation_timestamp_signer_valid",
    )
    receipt_ready_count = _sum(
        receipt_records,
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready",
    )
    receipt_performed_count = _sum(receipt_records, "receipt_authorization_performed")
    expected_file_creation_count = _sum(
        verifier_records, "expected_packet_file_creation_performed"
    )
    receipt_creation_count = _sum(verifier_records, "redrive_receipt_creation_performed")
    evidence_release_count = _sum(verifier_records, "evidence_release_performed")
    promoted_count = _sum(verifier_records, "repair_evidence_promoted")
    closure_count = _sum(verifier_records, "request_closure_performed")
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_sequence_ready_count == source_sequence_required
        and receipt_ready_count == receipt_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_signed_root_transparency_freshness_sequence_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_signed_root_transparency_freshness_sequence_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} inclusions={source_inclusion_count} root_consistency={source_consistency_count}",
    )
    _add_check(
        checks,
        "value_timestamp_signer_certificate_chain_root_freshness_authority_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} chains={value_chain_count} authorities={value_authority_count}",
    )
    _add_check(
        checks,
        "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} proofs={checksum_proof_count} signatures={checksum_signature_count}",
    )
    _add_check(
        checks,
        "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready",
        source_sequence_required > 0 and source_sequence_ready_count == source_sequence_required,
        f"ready={source_sequence_ready_count}/{source_sequence_required} public_keys={source_public_key_count} monotonicity={source_monotonicity_count}",
    )
    _add_check(
        checks,
        "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready",
        receipt_required > 0 and receipt_ready_count == receipt_required,
        f"ready={receipt_ready_count}/{receipt_required} authorities={receipt_authority_count} timestamp_signers={receipt_signer_count}",
    )
    _add_check(
        checks,
        "all_request_payload_inclusion_root_freshness_signature_sequence_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_inclusion_root_freshness_signature_sequence_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_INCLUSION_ROOT_FRESHNESS_SIGNATURE_SEQUENCE_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_INCLUSION_ROOT_FRESHNESS_SIGNATURE_SEQUENCE_UPSTREAM_LINT"
    elif (
        source_inclusion_count != source_required
        or source_inclusion_valid_count != source_required
        or source_consistency_count != source_required
        or source_consistency_valid_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_SIGNED_ROOT_TRANSPARENCY_INCLUSION_LOG_CHECKPOINT_ROOT_CONSISTENCY_MISSING"
    elif (
        value_chain_count != value_required
        or value_chain_valid_count != value_required
        or value_authority_count != value_required
        or value_authority_valid_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_TIMESTAMP_SIGNER_CERTIFICATE_CHAIN_ROOT_FRESHNESS_AUTHORITY_MISSING"
    elif (
        checksum_proof_count != checksum_required
        or checksum_proof_valid_count != checksum_required
        or checksum_signature_count != checksum_required
        or checksum_signature_valid_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_TRANSPARENCY_INCLUSION_MERKLE_PROOF_REVOCATION_AUTHORITY_SIGNATURE_MISSING"
    elif (
        source_public_key_count != source_sequence_required
        or source_public_key_valid_count != source_sequence_required
        or source_monotonicity_count != source_sequence_required
        or source_monotonicity_valid_count != source_sequence_required
        or source_sequence_ready_count != source_sequence_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_CHECKPOINT_SIGNATURE_PUBLIC_KEY_SESSION_SEQUENCE_MONOTONICITY_MISSING"
    elif (
        receipt_authority_count != receipt_required
        or receipt_authority_valid_count != receipt_required
        or receipt_signer_count != receipt_required
        or receipt_signer_valid_count != receipt_required
        or receipt_ready_count != receipt_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_CERTIFICATE_CHAIN_REVOCATION_AUTHORITY_FRESHNESS_TIMESTAMP_SIGNER_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_INCLUSION_ROOT_FRESHNESS_SIGNATURE_SEQUENCE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_INCLUSION_ROOT_FRESHNESS_SIGNATURE_SEQUENCE_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_INCLUSION_ROOT_FRESHNESS_SIGNATURE_SEQUENCE_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_INCLUSION_ROOT_FRESHNESS_SIGNATURE_SEQUENCE_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_signed_root_transparency_freshness_sequence_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_lint_ready_count": lint_ready_count,
            "upstream_payload_signed_root_transparency_freshness_sequence_ready_count": upstream_ready_count,
            "upstream_payload_signed_root_transparency_freshness_sequence_blocked_count": record_count - upstream_ready_count,
            "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_required_count": source_required,
            "source_signed_root_transparency_inclusion_log_checkpoint_present_count": source_inclusion_count,
            "source_signed_root_transparency_inclusion_log_checkpoint_valid_count": source_inclusion_valid_count,
            "source_signed_root_transparency_root_consistency_present_count": source_consistency_count,
            "source_signed_root_transparency_root_consistency_valid_count": source_consistency_valid_count,
            "source_signed_root_transparency_inclusion_log_checkpoint_root_consistency_ready_count": source_ready_count,
            "value_timestamp_signer_certificate_chain_root_freshness_authority_required_count": value_required,
            "value_timestamp_signer_certificate_chain_present_count": value_chain_count,
            "value_timestamp_signer_certificate_chain_valid_count": value_chain_valid_count,
            "value_root_freshness_authority_present_count": value_authority_count,
            "value_root_freshness_authority_valid_count": value_authority_valid_count,
            "value_timestamp_signer_certificate_chain_root_freshness_authority_ready_count": value_ready_count,
            "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_required_count": checksum_required,
            "checksum_transparency_inclusion_merkle_proof_present_count": checksum_proof_count,
            "checksum_transparency_inclusion_merkle_proof_valid_count": checksum_proof_valid_count,
            "checksum_revocation_authority_signature_present_count": checksum_signature_count,
            "checksum_revocation_authority_signature_valid_count": checksum_signature_valid_count,
            "checksum_transparency_inclusion_merkle_proof_revocation_authority_signature_ready_count": checksum_ready_count,
            "source_checkpoint_signature_public_key_session_sequence_monotonicity_required_count": source_sequence_required,
            "source_checkpoint_signature_public_key_present_count": source_public_key_count,
            "source_checkpoint_signature_public_key_valid_count": source_public_key_valid_count,
            "source_session_sequence_monotonicity_present_count": source_monotonicity_count,
            "source_session_sequence_monotonicity_valid_count": source_monotonicity_valid_count,
            "source_checkpoint_signature_public_key_session_sequence_monotonicity_ready_count": source_sequence_ready_count,
            "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_required_count": receipt_required,
            "receipt_certificate_chain_revocation_authority_freshness_present_count": receipt_authority_count,
            "receipt_certificate_chain_revocation_authority_freshness_valid_count": receipt_authority_valid_count,
            "receipt_certificate_chain_revocation_timestamp_signer_present_count": receipt_signer_count,
            "receipt_certificate_chain_revocation_timestamp_signer_valid_count": receipt_signer_valid_count,
            "receipt_certificate_chain_revocation_authority_freshness_timestamp_signer_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source signed-root transparency inclusion-log checkpoint/root consistency, value timestamp-signer certificate-chain/root freshness authority, checksum transparency-inclusion Merkle proof/revocation-authority signature, source checkpoint-signature public-key/session sequence monotonicity, and receipt certificate-chain revocation-authority freshness/timestamp signer markers.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Inclusion Root Freshness Signature Sequence Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_inclusion_root_freshness_signature_sequence_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
