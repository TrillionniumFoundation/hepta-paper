"""Human-input artifact source/value payload marker verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-marker-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_marker_verifier_capstone.v1"
)
SOURCE_PATH_PACKET_CONTENT_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_path_packet_json_schema_content_verifier.v1"
)
VALUE_IDENTITY_AUTHORIZATION_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_value_provenance_identity_authorization_marker.v1"
)
CHECKSUM_PAYLOAD_HASH_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_checksum_explicit_binding_payload_hash_verifier.v1"
)
SOURCE_HANDOFF_PAYLOAD_MARKER_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_source_handoff_identity_sha_payload_marker_quarantine.v1"
)
RECEIPT_PAYLOAD_SIGNATURE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_receipt_identity_marker_payload_schema_operator_signature.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_marker_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_marker_count",
    "operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready_count",
    "upstream_human_input_artifact_source_value_packet_handoff_receipt_identity_ready_count",
    "upstream_human_input_artifact_source_value_packet_handoff_receipt_identity_blocked_count",
    "source_path_packet_content_required_field_count",
    "source_path_packet_spec_present_count",
    "source_path_packet_spec_json_ok_count",
    "source_path_packet_spec_schema_valid_count",
    "source_path_packet_content_present_count",
    "source_path_packet_content_hash_bound_count",
    "source_path_packet_json_schema_content_ready_count",
    "value_identity_authorization_marker_required_field_count",
    "value_provenance_present_count",
    "value_identity_manifest_present_count",
    "value_identity_operator_identity_present_count",
    "value_identity_source_identity_present_count",
    "value_identity_authorization_marker_present_count",
    "value_identity_authorization_marker_schema_valid_count",
    "value_identity_authorization_marker_ready_count",
    "checksum_explicit_payload_hash_required_count",
    "checksum_explicit_packet_present_count",
    "checksum_explicit_packet_json_ok_count",
    "checksum_explicit_packet_schema_valid_count",
    "checksum_explicit_payload_hash_present_count",
    "checksum_explicit_payload_hash_bound_count",
    "checksum_explicit_payload_hash_ready_count",
    "source_handoff_identity_sha_payload_marker_required_count",
    "source_handoff_evidence_intake_packet_present_count",
    "source_handoff_operator_identity_present_count",
    "source_handoff_source_material_path_declared_count",
    "source_handoff_source_file_sha_verified_count",
    "source_handoff_identity_sha_quarantine_present_count",
    "source_handoff_identity_sha_payload_marker_present_count",
    "source_handoff_identity_sha_payload_marker_schema_valid_count",
    "source_handoff_identity_sha_payload_marker_hash_bound_count",
    "source_handoff_identity_sha_payload_marker_ready_count",
    "receipt_identity_marker_payload_signature_required_count",
    "receipt_signature_payload_present_count",
    "receipt_signature_operator_identity_present_count",
    "receipt_signature_explicit_authorization_marker_present_count",
    "receipt_signature_explicit_authorization_identity_binding_present_count",
    "receipt_signature_explicit_authorization_identity_marker_present_count",
    "receipt_signature_identity_marker_payload_schema_present_count",
    "receipt_signature_operator_signature_present_count",
    "receipt_signature_operator_signature_identity_bound_count",
    "receipt_identity_marker_payload_signature_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_marker_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_marker_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_marker_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _artifact_records(packet_record):
    matrix = (
        packet_record.get(
            "human_input_artifact_source_path_packet_spec_value_provenance_identity_matrix"
        )
        or {}
    )
    return [
        dict(item or {})
        for item in matrix.get(
            "human_input_artifact_source_path_packet_spec_value_provenance_identity_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _source_path_packet_content_matrix(packet_record, payload_sha):
    records = []
    for item in _artifact_records(packet_record):
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_source_path = item.get("expected_human_input_artifact_source_path") or ""
        expected_spec_path = (
            item.get("expected_human_input_artifact_source_path_packet_spec_path") or ""
        )
        expected_content_path = (
            item.get("expected_human_input_artifact_source_path_packet_content_path")
            or _sidecar(expected_spec_path, ".content.json")
        )
        source_path_declared = bool(item.get("human_input_artifact_source_path_declared"))
        spec_present = bool(item.get("human_input_artifact_source_path_packet_spec_present"))
        spec_json_ok = bool(item.get("human_input_artifact_source_path_packet_spec_json_ok"))
        spec_schema = bool(
            item.get("human_input_artifact_source_path_packet_spec_schema_valid")
        )
        content_present = bool(
            item.get("human_input_artifact_source_path_packet_content_present")
        )
        content_hash_bound = bool(
            item.get("human_input_artifact_source_path_packet_content_hash_bound")
        )
        template_verified = bool(
            item.get("human_input_artifact_source_path_packet_spec_template_verified")
            and expected_source_path
            and expected_spec_path
            and expected_content_path
            and str(expected_spec_path).endswith(".json")
            and str(expected_content_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("human_input_artifact_source_path_packet_spec_value_provenance_ready")
            and source_path_declared
            and spec_present
            and spec_json_ok
            and spec_schema
            and content_present
            and content_hash_bound
        )
        payload = {
            "schema_id": SOURCE_PATH_PACKET_CONTENT_SCHEMA_ID,
            "field": field,
            "expected_human_input_artifact_source_path": expected_source_path,
            "expected_human_input_artifact_source_path_packet_spec_path": expected_spec_path,
            "expected_human_input_artifact_source_path_packet_content_path": expected_content_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": SOURCE_PATH_PACKET_CONTENT_SCHEMA_ID,
                "source_path_packet_json_schema_content_verifier_id": (
                    f"referee-repair-source-path-packet-content-{record_sha[:16]}"
                ),
                "source_path_packet_json_schema_content_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_human_input_artifact_source_path": expected_source_path,
                "expected_human_input_artifact_source_path_packet_spec_path": expected_spec_path,
                "expected_human_input_artifact_source_path_packet_content_path": expected_content_path,
                "source_path_packet_content_template_verified": template_verified,
                "human_input_artifact_source_path_declared": source_path_declared,
                "source_path_packet_spec_present": spec_present,
                "source_path_packet_spec_json_ok": spec_json_ok,
                "source_path_packet_spec_schema_valid": spec_schema,
                "source_path_packet_content_present": content_present,
                "source_path_packet_content_hash_bound": content_hash_bound,
                "source_path_packet_json_schema_content_ready": ready,
                "source_human_input_artifact_source_path_packet_spec_value_provenance_ready": bool(
                    item.get(
                        "human_input_artifact_source_path_packet_spec_value_provenance_ready"
                    )
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    required_count = sum(1 for item in records if item.get("required"))
    return {
        "schema_id": SOURCE_PATH_PACKET_CONTENT_SCHEMA_ID,
        "source_path_packet_json_schema_content_verifier_matrix_id": (
            f"referee-repair-source-path-packet-content-matrix-{payload_sha[:16]}"
        ),
        "source_path_packet_content_required_field_count": required_count,
        "source_path_packet_spec_present_count": sum(
            1 for item in records if item.get("required") and item.get("source_path_packet_spec_present")
        ),
        "source_path_packet_spec_json_ok_count": sum(
            1 for item in records if item.get("required") and item.get("source_path_packet_spec_json_ok")
        ),
        "source_path_packet_spec_schema_valid_count": sum(
            1 for item in records if item.get("required") and item.get("source_path_packet_spec_schema_valid")
        ),
        "source_path_packet_content_present_count": sum(
            1 for item in records if item.get("required") and item.get("source_path_packet_content_present")
        ),
        "source_path_packet_content_hash_bound_count": sum(
            1 for item in records if item.get("required") and item.get("source_path_packet_content_hash_bound")
        ),
        "source_path_packet_json_schema_content_ready_count": sum(
            1 for item in records if item.get("required") and item.get("source_path_packet_json_schema_content_ready")
        ),
        "source_path_packet_json_schema_content_verifier_records": records,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _value_identity_authorization_records(packet_record, payload_sha):
    records = []
    for item in _artifact_records(packet_record):
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_manifest_path = (
            item.get("expected_human_input_artifact_value_provenance_source_identity_manifest_path")
            or ""
        )
        expected_marker_path = (
            item.get("expected_value_provenance_identity_authorization_marker_path")
            or _sidecar(expected_manifest_path, ".authorization-marker.json")
        )
        value_provenance = bool(item.get("human_input_artifact_value_provenance_present"))
        identity_manifest = bool(
            item.get("human_input_artifact_value_provenance_source_identity_manifest_present")
        )
        operator_identity = bool(
            item.get("value_provenance_operator_identity_present")
        )
        source_identity = bool(item.get("value_provenance_source_identity_present"))
        authorization_marker = bool(
            item.get("value_provenance_identity_authorization_marker_present")
        )
        marker_schema = bool(
            item.get("value_provenance_identity_authorization_marker_schema_valid")
        )
        template_verified = bool(
            expected_manifest_path
            and expected_marker_path
            and str(expected_marker_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and value_provenance
            and identity_manifest
            and operator_identity
            and source_identity
            and authorization_marker
            and marker_schema
        )
        payload = {
            "schema_id": VALUE_IDENTITY_AUTHORIZATION_SCHEMA_ID,
            "field": field,
            "expected_human_input_artifact_value_provenance_source_identity_manifest_path": expected_manifest_path,
            "expected_value_provenance_identity_authorization_marker_path": expected_marker_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": VALUE_IDENTITY_AUTHORIZATION_SCHEMA_ID,
                "value_provenance_identity_authorization_marker_id": (
                    f"referee-repair-value-identity-auth-marker-{record_sha[:16]}"
                ),
                "value_provenance_identity_authorization_marker_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_human_input_artifact_value_provenance_source_identity_manifest_path": expected_manifest_path,
                "expected_value_provenance_identity_authorization_marker_path": expected_marker_path,
                "value_identity_authorization_marker_template_verified": template_verified,
                "value_provenance_present": value_provenance,
                "value_identity_manifest_present": identity_manifest,
                "value_identity_operator_identity_present": operator_identity,
                "value_identity_source_identity_present": source_identity,
                "value_identity_authorization_marker_present": authorization_marker,
                "value_identity_authorization_marker_schema_valid": marker_schema,
                "value_identity_authorization_marker_ready": ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_payload_hash_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "required_value_checksum_binding_explicit_packet_verifier_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_explicit_path = (
            item.get("expected_required_value_checksum_binding_explicit_packet_path")
            or ""
        )
        expected_hash_path = (
            item.get("expected_checksum_explicit_binding_payload_hash_path")
            or _sidecar(expected_explicit_path, ".payload-hash.json")
        )
        explicit_present = bool(
            item.get("required_value_checksum_binding_explicit_packet_present")
        )
        explicit_json_ok = bool(
            item.get("required_value_checksum_binding_explicit_packet_json_ok")
        )
        explicit_schema = bool(
            item.get("required_value_checksum_binding_explicit_packet_schema_valid")
        )
        payload_hash_present = bool(
            item.get("checksum_explicit_binding_payload_hash_present")
        )
        payload_hash_bound = bool(
            item.get("checksum_explicit_binding_payload_hash_bound")
        )
        template_verified = bool(
            expected_explicit_path
            and expected_hash_path
            and str(expected_explicit_path).endswith(".json")
            and str(expected_hash_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and item.get("required_value_checksum_binding_explicit_packet_ready")
            and explicit_present
            and explicit_json_ok
            and explicit_schema
            and payload_hash_present
            and payload_hash_bound
        )
        payload = {
            "schema_id": CHECKSUM_PAYLOAD_HASH_SCHEMA_ID,
            "field": field,
            "expected_required_value_checksum_binding_explicit_packet_path": expected_explicit_path,
            "expected_checksum_explicit_binding_payload_hash_path": expected_hash_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "schema_id": CHECKSUM_PAYLOAD_HASH_SCHEMA_ID,
                "checksum_explicit_binding_payload_hash_verifier_id": (
                    f"referee-repair-checksum-payload-hash-{record_sha[:16]}"
                ),
                "checksum_explicit_binding_payload_hash_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_required_value_checksum_binding_explicit_packet_path": expected_explicit_path,
                "expected_checksum_explicit_binding_payload_hash_path": expected_hash_path,
                "checksum_explicit_binding_payload_hash_template_verified": template_verified,
                "checksum_explicit_packet_present": explicit_present,
                "checksum_explicit_packet_json_ok": explicit_json_ok,
                "checksum_explicit_packet_schema_valid": explicit_schema,
                "checksum_explicit_payload_hash_present": payload_hash_present,
                "checksum_explicit_payload_hash_bound": payload_hash_bound,
                "checksum_explicit_payload_hash_ready": ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_handoff_payload_marker(packet_record, payload_sha):
    source = dict(
        packet_record.get("source_handoff_evidence_intake_identity_sha_quarantine") or {}
    )
    expected_packet_path = source.get("expected_source_handoff_evidence_intake_packet_path") or ""
    expected_marker_path = (
        source.get("expected_source_handoff_identity_sha_payload_marker_path")
        or _sidecar(expected_packet_path, ".identity-sha-payload-marker.json")
    )
    packet_present = bool(source.get("source_handoff_evidence_intake_packet_present"))
    operator_identity = bool(source.get("source_handoff_operator_identity_present"))
    source_path = bool(source.get("source_handoff_source_material_path_declared"))
    source_sha = bool(source.get("source_handoff_source_file_sha_verified"))
    quarantine_present = bool(source.get("source_handoff_identity_sha_quarantine_present"))
    payload_marker = bool(source.get("source_handoff_identity_sha_payload_marker_present"))
    payload_schema = bool(
        source.get("source_handoff_identity_sha_payload_marker_schema_valid")
    )
    payload_hash = bool(source.get("source_handoff_identity_sha_payload_marker_hash_bound"))
    ready = bool(
        source.get("source_handoff_identity_sha_quarantine_ready")
        and packet_present
        and operator_identity
        and source_path
        and source_sha
        and quarantine_present
        and payload_marker
        and payload_schema
        and payload_hash
    )
    return {
        "schema_id": SOURCE_HANDOFF_PAYLOAD_MARKER_SCHEMA_ID,
        "source_handoff_identity_sha_payload_marker_quarantine_id": (
            f"referee-repair-source-handoff-payload-marker-{payload_sha[:16]}"
        ),
        "expected_source_handoff_evidence_intake_packet_path": expected_packet_path,
        "expected_source_handoff_identity_sha_payload_marker_path": expected_marker_path,
        "source_handoff_evidence_intake_packet_present": packet_present,
        "source_handoff_operator_identity_present": operator_identity,
        "source_handoff_source_material_path_declared": source_path,
        "source_handoff_source_file_sha_verified": source_sha,
        "source_handoff_identity_sha_quarantine_present": quarantine_present,
        "source_handoff_identity_sha_payload_marker_present": payload_marker,
        "source_handoff_identity_sha_payload_marker_schema_valid": payload_schema,
        "source_handoff_identity_sha_payload_marker_hash_bound": payload_hash,
        "source_handoff_identity_sha_payload_marker_ready": ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_payload_signature(packet_record, payload_sha):
    receipt = dict(
        packet_record.get("receipt_signature_explicit_authorization_identity_marker_verifier")
        or {}
    )
    expected_marker_schema_path = (
        receipt.get("expected_receipt_signature_authorization_marker_schema_path") or ""
    )
    expected_signature_path = (
        receipt.get("expected_receipt_identity_marker_operator_signature_path")
        or _sidecar(expected_marker_schema_path, ".operator-signature.json")
    )
    payload_present = bool(receipt.get("receipt_signature_payload_present"))
    operator_identity = bool(receipt.get("receipt_signature_operator_identity_present"))
    authorization = bool(
        receipt.get("receipt_signature_explicit_authorization_marker_present")
    )
    identity_binding = bool(
        receipt.get("receipt_signature_explicit_authorization_identity_binding_present")
    )
    marker_present = bool(
        receipt.get("receipt_signature_explicit_authorization_identity_marker_present")
    )
    marker_schema = bool(
        receipt.get("receipt_signature_explicit_authorization_identity_marker_schema_valid")
    )
    payload_schema = bool(receipt.get("receipt_signature_identity_marker_payload_schema_present"))
    operator_signature = bool(receipt.get("receipt_signature_operator_signature_present"))
    signature_bound = bool(
        receipt.get("receipt_signature_operator_signature_identity_bound")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    ready = bool(
        receipt.get("receipt_signature_explicit_authorization_identity_marker_ready")
        and payload_present
        and operator_identity
        and authorization
        and identity_binding
        and marker_present
        and marker_schema
        and payload_schema
        and operator_signature
        and signature_bound
        and not performed
    )
    return {
        "schema_id": RECEIPT_PAYLOAD_SIGNATURE_SCHEMA_ID,
        "receipt_identity_marker_payload_schema_operator_signature_verifier_id": (
            f"referee-repair-receipt-payload-signature-{payload_sha[:16]}"
        ),
        "expected_receipt_signature_authorization_marker_schema_path": expected_marker_schema_path,
        "expected_receipt_identity_marker_operator_signature_path": expected_signature_path,
        "receipt_signature_payload_present": payload_present,
        "receipt_signature_operator_identity_present": operator_identity,
        "receipt_signature_explicit_authorization_marker_present": authorization,
        "receipt_signature_explicit_authorization_identity_binding_present": identity_binding,
        "receipt_signature_explicit_authorization_identity_marker_present": marker_present,
        "receipt_signature_explicit_authorization_identity_marker_schema_valid": marker_schema,
        "receipt_signature_identity_marker_payload_schema_present": payload_schema,
        "receipt_signature_operator_signature_present": operator_signature,
        "receipt_signature_operator_signature_identity_bound": signature_bound,
        "receipt_identity_marker_payload_signature_ready": ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_marker_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_path_matrix = _source_path_packet_content_matrix(packet_record, payload_sha)
    value_identity_records = _value_identity_authorization_records(
        packet_record, payload_sha
    )
    checksum_records = _checksum_payload_hash_records(packet_record, payload_sha)
    source_marker = _source_handoff_payload_marker(packet_record, payload_sha)
    receipt_signature = _receipt_payload_signature(packet_record, payload_sha)
    source_path_required = source_path_matrix.get(
        "source_path_packet_content_required_field_count"
    )
    source_path_ready = source_path_matrix.get(
        "source_path_packet_json_schema_content_ready_count"
    )
    value_required = sum(1 for item in value_identity_records if item.get("required"))
    value_ready = sum(
        1
        for item in value_identity_records
        if item.get("required") and item.get("value_identity_authorization_marker_ready")
    )
    checksum_required = sum(1 for item in checksum_records if item.get("required"))
    checksum_ready = sum(
        1
        for item in checksum_records
        if item.get("required") and item.get("checksum_explicit_payload_hash_ready")
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_signature.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_lint_ready"
        )
        and source_path_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_ready"
        )
        and source_path_required
        and source_path_ready == source_path_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_marker.get("source_handoff_identity_sha_payload_marker_ready")
        and receipt_signature.get("receipt_identity_marker_payload_signature_ready")
        and not consumable
    )
    blockers = []
    if source_path_ready != source_path_required:
        blockers.append("source_path_packet_json_schema_content_missing")
    if value_ready != value_required:
        blockers.append("value_identity_authorization_marker_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_explicit_binding_payload_hash_missing")
    if not source_marker.get("source_handoff_identity_sha_payload_marker_ready"):
        blockers.append("source_handoff_identity_sha_payload_marker_missing")
    if not receipt_signature.get("receipt_identity_marker_payload_signature_ready"):
        blockers.append("receipt_identity_marker_payload_signature_missing")
    if consumable:
        blockers.append("human_input_artifact_source_value_payload_marker_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_id": (
            f"referee-repair-human-input-source-value-payload-marker-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_marker_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_payload_sha256"
            )
            or ""
        ),
        "expected_packet_path": packet_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            packet_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "source_path_packet_json_schema_content_verifier_matrix": source_path_matrix,
        "value_provenance_identity_authorization_marker_records": value_identity_records,
        "value_identity_authorization_marker_required_count": value_required,
        "value_identity_authorization_marker_ready_count": value_ready,
        "checksum_explicit_binding_payload_hash_verifier_records": checksum_records,
        "checksum_explicit_payload_hash_required_count": checksum_required,
        "checksum_explicit_payload_hash_ready_count": checksum_ready,
        "source_handoff_identity_sha_payload_marker_quarantine": source_marker,
        "receipt_identity_marker_payload_schema_operator_signature_verifier": receipt_signature,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_marker_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_marker_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "source-path packet content, value identity authorization, checksum payload hashes, source handoff payload markers, and receipt marker signatures are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source-path packet JSON/schema/content, value identity authorization markers, checksum explicit payload hashes, source handoff identity/sha payload markers, and receipt marker payload signatures"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get("operator_real_source_human_input_artifact_source_value_payload_marker_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_marker_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256s": [
            item.get("operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256")
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_marker_id": (
            f"referee-repair-request-human-input-source-value-payload-marker-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_marker_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_marker_hash_bound": bool(
            payload_sha
            and all(
                item.get("operator_real_source_human_input_artifact_source_value_payload_marker_hash_bound")
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready": bool(
            payload_sha
            and all(
                item.get("operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready")
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_marker_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_marker_ready_count": sum(
            1
            for item in verifier_records
            if item.get("operator_real_source_human_input_artifact_source_value_payload_marker_ready")
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_marker_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_marker_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_marker_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_marker_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_report,
    operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get("request_operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_lint_ready")
            for request in upstream_request_records
        )
        and all(
            record.get("operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_lint_ready")
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_marker_records"
        )
        or []
    ]
    source_path_records = [
        item
        for record in verifier_records
        for item in (
            record.get("source_path_packet_json_schema_content_verifier_matrix") or {}
        ).get("source_path_packet_json_schema_content_verifier_records")
        or []
    ]
    value_identity_records = [
        item
        for record in verifier_records
        for item in record.get("value_provenance_identity_authorization_marker_records")
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get("checksum_explicit_binding_payload_hash_verifier_records")
        or []
    ]
    source_marker_records = [
        record.get("source_handoff_identity_sha_payload_marker_quarantine") or {}
        for record in verifier_records
    ]
    receipt_signature_records = [
        record.get("receipt_identity_marker_payload_schema_operator_signature_verifier")
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_operator_real_source_human_input_artifact_source_value_payload_marker_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get("operator_real_source_human_input_artifact_source_value_payload_marker_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get("operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready")
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get("operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_ready")
    )
    source_path_required_count = sum(
        1 for item in source_path_records if item.get("required")
    )
    source_path_spec_present_count = sum(
        1 for item in source_path_records if item.get("required") and item.get("source_path_packet_spec_present")
    )
    source_path_spec_json_count = sum(
        1 for item in source_path_records if item.get("required") and item.get("source_path_packet_spec_json_ok")
    )
    source_path_spec_schema_count = sum(
        1 for item in source_path_records if item.get("required") and item.get("source_path_packet_spec_schema_valid")
    )
    source_path_content_count = sum(
        1 for item in source_path_records if item.get("required") and item.get("source_path_packet_content_present")
    )
    source_path_content_hash_count = sum(
        1 for item in source_path_records if item.get("required") and item.get("source_path_packet_content_hash_bound")
    )
    source_path_ready_count = sum(
        1 for item in source_path_records if item.get("required") and item.get("source_path_packet_json_schema_content_ready")
    )
    value_required_count = sum(
        1 for item in value_identity_records if item.get("required")
    )
    value_provenance_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_provenance_present")
    )
    value_manifest_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_identity_manifest_present")
    )
    value_operator_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_identity_operator_identity_present")
    )
    value_source_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_identity_source_identity_present")
    )
    value_marker_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_identity_authorization_marker_present")
    )
    value_marker_schema_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_identity_authorization_marker_schema_valid")
    )
    value_ready_count = sum(
        1 for item in value_identity_records if item.get("required") and item.get("value_identity_authorization_marker_ready")
    )
    checksum_required_count = sum(1 for item in checksum_records if item.get("required"))
    checksum_packet_count = sum(
        1 for item in checksum_records if item.get("required") and item.get("checksum_explicit_packet_present")
    )
    checksum_json_count = sum(
        1 for item in checksum_records if item.get("required") and item.get("checksum_explicit_packet_json_ok")
    )
    checksum_schema_count = sum(
        1 for item in checksum_records if item.get("required") and item.get("checksum_explicit_packet_schema_valid")
    )
    checksum_hash_count = sum(
        1 for item in checksum_records if item.get("required") and item.get("checksum_explicit_payload_hash_present")
    )
    checksum_hash_bound_count = sum(
        1 for item in checksum_records if item.get("required") and item.get("checksum_explicit_payload_hash_bound")
    )
    checksum_ready_count = sum(
        1 for item in checksum_records if item.get("required") and item.get("checksum_explicit_payload_hash_ready")
    )
    source_required_count = record_count
    source_packet_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_evidence_intake_packet_present")
    )
    source_identity_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_operator_identity_present")
    )
    source_path_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_source_material_path_declared")
    )
    source_sha_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_source_file_sha_verified")
    )
    source_quarantine_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_identity_sha_quarantine_present")
    )
    source_marker_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_identity_sha_payload_marker_present")
    )
    source_marker_schema_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_identity_sha_payload_marker_schema_valid")
    )
    source_marker_hash_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_identity_sha_payload_marker_hash_bound")
    )
    source_ready_count = sum(
        1 for item in source_marker_records if item.get("source_handoff_identity_sha_payload_marker_ready")
    )
    receipt_required_count = record_count
    receipt_payload_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_payload_present")
    )
    receipt_identity_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_operator_identity_present")
    )
    receipt_authorization_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_explicit_authorization_marker_present")
    )
    receipt_identity_binding_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_explicit_authorization_identity_binding_present")
    )
    receipt_marker_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_explicit_authorization_identity_marker_present")
    )
    receipt_payload_schema_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_identity_marker_payload_schema_present")
    )
    receipt_operator_signature_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_operator_signature_present")
    )
    receipt_signature_bound_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_signature_operator_signature_identity_bound")
    )
    receipt_ready_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_identity_marker_payload_signature_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_signature_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1 for item in verifier_records if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1 for item in verifier_records + request_records if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1 for item in verifier_records + request_records if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1 for item in verifier_records + request_records if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_path_ready_count == source_path_required_count
        and value_ready_count == value_required_count
        and checksum_ready_count == checksum_required_count
        and source_ready_count == source_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "source_value_packet_handoff_receipt_identity_verifier_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_value_packet_handoff_receipt_identity_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_source_path_packet_json_schema_content_verified",
        source_path_spec_present_count == source_path_required_count
        and source_path_spec_json_count == source_path_required_count
        and source_path_spec_schema_count == source_path_required_count
        and source_path_content_count == source_path_required_count
        and source_path_content_hash_count == source_path_required_count
        and source_path_ready_count == source_path_required_count,
        (
            f"specs={source_path_spec_present_count}/{source_path_required_count} "
            f"json={source_path_spec_json_count} schema={source_path_spec_schema_count} "
            f"content={source_path_content_count} "
            f"content_hash={source_path_content_hash_count} ready={source_path_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_value_identity_authorization_markers_verified",
        value_provenance_count == value_required_count
        and value_manifest_count == value_required_count
        and value_operator_count == value_required_count
        and value_source_count == value_required_count
        and value_marker_count == value_required_count
        and value_marker_schema_count == value_required_count
        and value_ready_count == value_required_count,
        (
            f"value_provenance={value_provenance_count}/{value_required_count} "
            f"manifest={value_manifest_count} operator_identity={value_operator_count} "
            f"source_identity={value_source_count} marker={value_marker_count} "
            f"marker_schema={value_marker_schema_count} ready={value_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_checksum_explicit_binding_payload_hashes_verified",
        checksum_packet_count == checksum_required_count
        and checksum_json_count == checksum_required_count
        and checksum_schema_count == checksum_required_count
        and checksum_hash_count == checksum_required_count
        and checksum_hash_bound_count == checksum_required_count
        and checksum_ready_count == checksum_required_count,
        (
            f"packets={checksum_packet_count}/{checksum_required_count} "
            f"json={checksum_json_count} schema={checksum_schema_count} "
            f"payload_hash={checksum_hash_count} hash_bound={checksum_hash_bound_count} "
            f"ready={checksum_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_source_handoff_identity_sha_payload_markers_verified",
        source_packet_count == source_required_count
        and source_identity_count == source_required_count
        and source_path_count == source_required_count
        and source_sha_count == source_required_count
        and source_quarantine_count == source_required_count
        and source_marker_count == source_required_count
        and source_marker_schema_count == source_required_count
        and source_marker_hash_count == source_required_count
        and source_ready_count == source_required_count,
        (
            f"packets={source_packet_count}/{source_required_count} "
            f"identity={source_identity_count} source_path={source_path_count} "
            f"sha={source_sha_count} quarantine={source_quarantine_count} "
            f"marker={source_marker_count} marker_schema={source_marker_schema_count} "
            f"marker_hash={source_marker_hash_count} ready={source_ready_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_identity_marker_payload_signatures_verified",
        receipt_payload_count == receipt_required_count
        and receipt_identity_count == receipt_required_count
        and receipt_authorization_count == receipt_required_count
        and receipt_identity_binding_count == receipt_required_count
        and receipt_marker_count == receipt_required_count
        and receipt_payload_schema_count == receipt_required_count
        and receipt_operator_signature_count == receipt_required_count
        and receipt_signature_bound_count == receipt_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0,
        (
            f"payload={receipt_payload_count}/{receipt_required_count} "
            f"identity={receipt_identity_count} authorization={receipt_authorization_count} "
            f"identity_binding={receipt_identity_binding_count} marker={receipt_marker_count} "
            f"payload_schema={receipt_payload_schema_count} "
            f"operator_signature={receipt_operator_signature_count} "
            f"signature_bound={receipt_signature_bound_count} ready={receipt_ready_count} "
            f"performed={receipt_performed_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_human_input_artifact_source_value_payload_marker_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "human_input_artifact_source_value_payload_marker_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MARKER_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MARKER_UPSTREAM_LINT"
    elif (
        source_path_spec_present_count != source_path_required_count
        or source_path_spec_json_count != source_path_required_count
        or source_path_spec_schema_count != source_path_required_count
        or source_path_content_count != source_path_required_count
        or source_path_content_hash_count != source_path_required_count
        or source_path_ready_count != source_path_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_PATH_PACKET_JSON_SCHEMA_CONTENT_MISSING"
    elif (
        value_provenance_count != value_required_count
        or value_manifest_count != value_required_count
        or value_operator_count != value_required_count
        or value_source_count != value_required_count
        or value_marker_count != value_required_count
        or value_marker_schema_count != value_required_count
        or value_ready_count != value_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_IDENTITY_AUTHORIZATION_MARKER_MISSING"
    elif (
        checksum_packet_count != checksum_required_count
        or checksum_json_count != checksum_required_count
        or checksum_schema_count != checksum_required_count
        or checksum_hash_count != checksum_required_count
        or checksum_hash_bound_count != checksum_required_count
        or checksum_ready_count != checksum_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_EXPLICIT_BINDING_PAYLOAD_HASH_MISSING"
    elif (
        source_packet_count != source_required_count
        or source_identity_count != source_required_count
        or source_path_count != source_required_count
        or source_sha_count != source_required_count
        or source_quarantine_count != source_required_count
        or source_marker_count != source_required_count
        or source_marker_schema_count != source_required_count
        or source_marker_hash_count != source_required_count
        or source_ready_count != source_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_HANDOFF_IDENTITY_SHA_PAYLOAD_MARKER_MISSING"
    elif (
        receipt_payload_count != receipt_required_count
        or receipt_identity_count != receipt_required_count
        or receipt_authorization_count != receipt_required_count
        or receipt_identity_binding_count != receipt_required_count
        or receipt_marker_count != receipt_required_count
        or receipt_payload_schema_count != receipt_required_count
        or receipt_operator_signature_count != receipt_required_count
        or receipt_signature_bound_count != receipt_required_count
        or receipt_ready_count != receipt_required_count
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_IDENTITY_MARKER_PAYLOAD_SIGNATURE_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MARKER_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MARKER_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MARKER_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MARKER_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_marker_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_packet_handoff_receipt_identity_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_marker_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_marker_lint_ready_count": lint_ready_count,
            "upstream_human_input_artifact_source_value_packet_handoff_receipt_identity_ready_count": upstream_ready_count,
            "upstream_human_input_artifact_source_value_packet_handoff_receipt_identity_blocked_count": record_count - upstream_ready_count,
            "source_path_packet_content_required_field_count": source_path_required_count,
            "source_path_packet_spec_present_count": source_path_spec_present_count,
            "source_path_packet_spec_json_ok_count": source_path_spec_json_count,
            "source_path_packet_spec_schema_valid_count": source_path_spec_schema_count,
            "source_path_packet_content_present_count": source_path_content_count,
            "source_path_packet_content_hash_bound_count": source_path_content_hash_count,
            "source_path_packet_json_schema_content_ready_count": source_path_ready_count,
            "value_identity_authorization_marker_required_field_count": value_required_count,
            "value_provenance_present_count": value_provenance_count,
            "value_identity_manifest_present_count": value_manifest_count,
            "value_identity_operator_identity_present_count": value_operator_count,
            "value_identity_source_identity_present_count": value_source_count,
            "value_identity_authorization_marker_present_count": value_marker_count,
            "value_identity_authorization_marker_schema_valid_count": value_marker_schema_count,
            "value_identity_authorization_marker_ready_count": value_ready_count,
            "checksum_explicit_payload_hash_required_count": checksum_required_count,
            "checksum_explicit_packet_present_count": checksum_packet_count,
            "checksum_explicit_packet_json_ok_count": checksum_json_count,
            "checksum_explicit_packet_schema_valid_count": checksum_schema_count,
            "checksum_explicit_payload_hash_present_count": checksum_hash_count,
            "checksum_explicit_payload_hash_bound_count": checksum_hash_bound_count,
            "checksum_explicit_payload_hash_ready_count": checksum_ready_count,
            "source_handoff_identity_sha_payload_marker_required_count": source_required_count,
            "source_handoff_evidence_intake_packet_present_count": source_packet_count,
            "source_handoff_operator_identity_present_count": source_identity_count,
            "source_handoff_source_material_path_declared_count": source_path_count,
            "source_handoff_source_file_sha_verified_count": source_sha_count,
            "source_handoff_identity_sha_quarantine_present_count": source_quarantine_count,
            "source_handoff_identity_sha_payload_marker_present_count": source_marker_count,
            "source_handoff_identity_sha_payload_marker_schema_valid_count": source_marker_schema_count,
            "source_handoff_identity_sha_payload_marker_hash_bound_count": source_marker_hash_count,
            "source_handoff_identity_sha_payload_marker_ready_count": source_ready_count,
            "receipt_identity_marker_payload_signature_required_count": receipt_required_count,
            "receipt_signature_payload_present_count": receipt_payload_count,
            "receipt_signature_operator_identity_present_count": receipt_identity_count,
            "receipt_signature_explicit_authorization_marker_present_count": receipt_authorization_count,
            "receipt_signature_explicit_authorization_identity_binding_present_count": receipt_identity_binding_count,
            "receipt_signature_explicit_authorization_identity_marker_present_count": receipt_marker_count,
            "receipt_signature_identity_marker_payload_schema_present_count": receipt_payload_schema_count,
            "receipt_signature_operator_signature_present_count": receipt_operator_signature_count,
            "receipt_signature_operator_signature_identity_bound_count": receipt_signature_bound_count,
            "receipt_identity_marker_payload_signature_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_marker_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_marker_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_marker_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_marker_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source-path packet JSON/schema/content, value provenance identity authorization markers, checksum explicit binding payload hashes, source handoff identity/sha payload markers, and receipt identity marker payload signatures.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Marker Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_marker_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
