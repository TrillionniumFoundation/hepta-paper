"""Human-input artifact source/value payload Merkle/freshness ledger verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-merkle-freshness-ledger-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_count",
    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready_count",
    "upstream_payload_transparency_revocation_replay_ready_count",
    "upstream_payload_transparency_revocation_replay_blocked_count",
    "source_transparency_log_merkle_inclusion_checkpoint_hash_required_count",
    "source_transparency_log_merkle_checkpoint_present_count",
    "source_transparency_log_merkle_checkpoint_hash_bound_count",
    "source_transparency_log_merkle_inclusion_proof_hash_match_count",
    "source_transparency_log_checkpoint_root_hash_valid_count",
    "source_transparency_log_merkle_inclusion_checkpoint_hash_ready_count",
    "value_revocation_authority_signer_root_freshness_required_count",
    "value_revocation_authority_signer_present_count",
    "value_revocation_authority_signature_valid_count",
    "value_revocation_root_freshness_present_count",
    "value_revocation_root_freshness_valid_count",
    "value_revocation_authority_signer_root_freshness_ready_count",
    "checksum_attestation_payload_digest_expected_source_cross_binding_required_count",
    "checksum_attestation_payload_digest_expected_source_binding_present_count",
    "checksum_attestation_payload_digest_expected_source_sha_match_count",
    "checksum_attestation_payload_digest_source_packet_identity_match_count",
    "checksum_attestation_payload_digest_cross_binding_hash_bound_count",
    "checksum_attestation_payload_digest_expected_source_cross_binding_ready_count",
    "source_nonce_session_timestamped_anti_replay_ledger_required_count",
    "source_nonce_session_timestamped_anti_replay_ledger_present_count",
    "source_nonce_session_timestamped_anti_replay_ledger_hash_bound_count",
    "source_nonce_session_timestamp_monotonic_count",
    "source_nonce_session_ledger_entry_unique_count",
    "source_nonce_session_timestamped_anti_replay_ledger_ready_count",
    "receipt_authorization_signer_binding_certificate_revocation_root_freshness_required_count",
    "receipt_authorization_signer_certificate_revocation_present_count",
    "receipt_authorization_signer_certificate_not_revoked_count",
    "receipt_authorization_signer_root_freshness_present_count",
    "receipt_authorization_signer_root_freshness_valid_count",
    "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _sum(records, key):
    return sum(1 for item in records if item.get(key))


def _source_merkle_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_validator_public_key_signature_transparency_log_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_log_path = (
            item.get("expected_source_validator_public_key_signature_transparency_log_path")
            or ""
        )
        expected_checkpoint_path = (
            item.get(
                "expected_source_transparency_log_merkle_inclusion_checkpoint_hash_path"
            )
            or _sidecar(expected_log_path, ".merkle-inclusion-checkpoint-hash.json")
        )
        upstream_ready = bool(
            item.get("source_validator_public_key_signature_transparency_log_ready")
        )
        checkpoint = bool(item.get("source_transparency_log_merkle_checkpoint_present"))
        checkpoint_hash = bool(
            item.get("source_transparency_log_merkle_checkpoint_hash_bound")
        )
        inclusion_hash = bool(
            item.get("source_transparency_log_merkle_inclusion_proof_hash_match")
        )
        root_hash = bool(item.get("source_transparency_log_checkpoint_root_hash_valid"))
        template_verified = bool(
            expected_log_path
            and expected_checkpoint_path
            and str(expected_log_path).endswith(".json")
            and str(expected_checkpoint_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("source_validator_public_key_signature_transparency_log_present")
            and item.get(
                "source_validator_public_key_signature_transparency_log_hash_bound"
            )
            and item.get(
                "source_validator_public_key_signature_transparency_inclusion_verified"
            )
            and checkpoint
            and checkpoint_hash
            and inclusion_hash
            and root_hash
        )
        payload = {
            "field": field,
            "expected_source_validator_public_key_signature_transparency_log_path": expected_log_path,
            "expected_source_transparency_log_merkle_inclusion_checkpoint_hash_path": expected_checkpoint_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "source_transparency_log_merkle_inclusion_checkpoint_hash_verifier_id": (
                    f"referee-repair-source-merkle-checkpoint-{record_sha[:16]}"
                ),
                "source_transparency_log_merkle_inclusion_checkpoint_hash_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_validator_public_key_signature_transparency_log_path": expected_log_path,
                "expected_source_transparency_log_merkle_inclusion_checkpoint_hash_path": expected_checkpoint_path,
                "source_transparency_log_merkle_inclusion_checkpoint_hash_template_verified": template_verified,
                "source_validator_public_key_signature_transparency_log_present": bool(
                    item.get("source_validator_public_key_signature_transparency_log_present")
                ),
                "source_validator_public_key_signature_transparency_log_hash_bound": bool(
                    item.get(
                        "source_validator_public_key_signature_transparency_log_hash_bound"
                    )
                ),
                "source_validator_public_key_signature_transparency_inclusion_verified": bool(
                    item.get(
                        "source_validator_public_key_signature_transparency_inclusion_verified"
                    )
                ),
                "source_transparency_log_merkle_checkpoint_present": checkpoint,
                "source_transparency_log_merkle_checkpoint_hash_bound": checkpoint_hash,
                "source_transparency_log_merkle_inclusion_proof_hash_match": inclusion_hash,
                "source_transparency_log_checkpoint_root_hash_valid": root_hash,
                "source_transparency_log_merkle_inclusion_checkpoint_hash_ready": ready,
                "upstream_source_validator_public_key_signature_transparency_log_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_freshness_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_trust_chain_digest_revocation_expiry_window_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_revocation_path = (
            item.get("expected_value_trust_chain_digest_revocation_expiry_window_path")
            or ""
        )
        expected_freshness_path = (
            item.get("expected_value_revocation_authority_signer_root_freshness_path")
            or _sidecar(
                expected_revocation_path,
                ".authority-signer-root-freshness.json",
            )
        )
        upstream_ready = bool(
            item.get("value_trust_chain_digest_revocation_expiry_ready")
        )
        signer = bool(item.get("value_revocation_authority_signer_present"))
        signature = bool(item.get("value_revocation_authority_signature_valid"))
        freshness = bool(item.get("value_revocation_root_freshness_present"))
        freshness_valid = bool(item.get("value_revocation_root_freshness_valid"))
        template_verified = bool(
            expected_revocation_path
            and expected_freshness_path
            and str(expected_revocation_path).endswith(".json")
            and str(expected_freshness_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("value_trust_chain_digest_revocation_status_present")
            and item.get("value_trust_chain_digest_not_revoked")
            and item.get("value_trust_chain_digest_expiry_window_valid")
            and signer
            and signature
            and freshness
            and freshness_valid
        )
        payload = {
            "field": field,
            "expected_value_trust_chain_digest_revocation_expiry_window_path": expected_revocation_path,
            "expected_value_revocation_authority_signer_root_freshness_path": expected_freshness_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "value_revocation_authority_signer_root_freshness_verifier_id": (
                    f"referee-repair-value-authority-freshness-{record_sha[:16]}"
                ),
                "value_revocation_authority_signer_root_freshness_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_trust_chain_digest_revocation_expiry_window_path": expected_revocation_path,
                "expected_value_revocation_authority_signer_root_freshness_path": expected_freshness_path,
                "value_revocation_authority_signer_root_freshness_template_verified": template_verified,
                "value_trust_chain_digest_revocation_status_present": bool(
                    item.get("value_trust_chain_digest_revocation_status_present")
                ),
                "value_trust_chain_digest_not_revoked": bool(
                    item.get("value_trust_chain_digest_not_revoked")
                ),
                "value_trust_chain_digest_expiry_window_valid": bool(
                    item.get("value_trust_chain_digest_expiry_window_valid")
                ),
                "value_revocation_authority_signer_present": signer,
                "value_revocation_authority_signature_valid": signature,
                "value_revocation_root_freshness_present": freshness,
                "value_revocation_root_freshness_valid": freshness_valid,
                "value_revocation_authority_signer_root_freshness_ready": ready,
                "upstream_value_trust_chain_digest_revocation_expiry_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_cross_binding_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_operator_attestation_public_key_trust_payload_digest_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_payload_digest_path = (
            item.get(
                "expected_checksum_operator_attestation_public_key_trust_payload_digest_path"
            )
            or ""
        )
        expected_cross_binding_path = (
            item.get(
                "expected_checksum_attestation_payload_digest_expected_source_cross_binding_path"
            )
            or _sidecar(
                expected_payload_digest_path,
                ".expected-source-cross-binding.json",
            )
        )
        upstream_ready = bool(
            item.get("checksum_operator_attestation_public_key_trust_payload_digest_ready")
        )
        binding = bool(
            item.get("checksum_attestation_payload_digest_expected_source_binding_present")
        )
        sha_match = bool(
            item.get("checksum_attestation_payload_digest_expected_source_sha_match")
        )
        identity = bool(
            item.get(
                "checksum_attestation_payload_digest_source_packet_identity_match"
            )
        )
        hash_bound = bool(
            item.get("checksum_attestation_payload_digest_cross_binding_hash_bound")
        )
        template_verified = bool(
            expected_payload_digest_path
            and expected_cross_binding_path
            and str(expected_payload_digest_path).endswith(".json")
            and str(expected_cross_binding_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("checksum_operator_attestation_public_key_trust_present")
            and item.get("checksum_operator_attestation_payload_digest_present")
            and item.get("checksum_operator_attestation_payload_digest_sha_match")
            and binding
            and sha_match
            and identity
            and hash_bound
        )
        payload = {
            "field": field,
            "expected_checksum_operator_attestation_public_key_trust_payload_digest_path": expected_payload_digest_path,
            "expected_checksum_attestation_payload_digest_expected_source_cross_binding_path": expected_cross_binding_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "checksum_attestation_payload_digest_expected_source_cross_binding_verifier_id": (
                    f"referee-repair-checksum-cross-binding-{record_sha[:16]}"
                ),
                "checksum_attestation_payload_digest_expected_source_cross_binding_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_operator_attestation_public_key_trust_payload_digest_path": expected_payload_digest_path,
                "expected_checksum_attestation_payload_digest_expected_source_cross_binding_path": expected_cross_binding_path,
                "checksum_attestation_payload_digest_expected_source_cross_binding_template_verified": template_verified,
                "checksum_operator_attestation_public_key_trust_present": bool(
                    item.get("checksum_operator_attestation_public_key_trust_present")
                ),
                "checksum_operator_attestation_payload_digest_present": bool(
                    item.get("checksum_operator_attestation_payload_digest_present")
                ),
                "checksum_operator_attestation_payload_digest_sha_match": bool(
                    item.get("checksum_operator_attestation_payload_digest_sha_match")
                ),
                "checksum_attestation_payload_digest_expected_source_binding_present": binding,
                "checksum_attestation_payload_digest_expected_source_sha_match": sha_match,
                "checksum_attestation_payload_digest_source_packet_identity_match": identity,
                "checksum_attestation_payload_digest_cross_binding_hash_bound": hash_bound,
                "checksum_attestation_payload_digest_expected_source_cross_binding_ready": ready,
                "upstream_checksum_operator_attestation_public_key_trust_payload_digest_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_ledger(record, payload_sha):
    source = dict(record.get("source_replay_guard_nonce_session_binding") or {})
    expected_binding_path = (
        source.get("expected_source_replay_guard_nonce_session_binding_path") or ""
    )
    expected_ledger_path = (
        source.get("expected_source_nonce_session_timestamped_anti_replay_ledger_path")
        or _sidecar(expected_binding_path, ".timestamped-anti-replay-ledger.json")
    )
    upstream_ready = bool(source.get("source_replay_guard_nonce_session_binding_ready"))
    ledger = bool(
        source.get("source_nonce_session_timestamped_anti_replay_ledger_present")
    )
    ledger_hash = bool(
        source.get("source_nonce_session_timestamped_anti_replay_ledger_hash_bound")
    )
    timestamp = bool(source.get("source_nonce_session_timestamp_monotonic"))
    unique = bool(source.get("source_nonce_session_ledger_entry_unique"))
    template_verified = bool(
        expected_binding_path
        and expected_ledger_path
        and str(expected_binding_path).endswith(".json")
        and str(expected_ledger_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and source.get("source_replay_guard_nonce_unique")
        and source.get("source_replay_guard_session_binding_valid")
        and ledger
        and ledger_hash
        and timestamp
        and unique
    )
    return {
        "source_nonce_session_timestamped_anti_replay_ledger_verifier_id": (
            f"referee-repair-source-anti-replay-ledger-{payload_sha[:16]}"
        ),
        "expected_source_replay_guard_nonce_session_binding_path": expected_binding_path,
        "expected_source_nonce_session_timestamped_anti_replay_ledger_path": expected_ledger_path,
        "source_nonce_session_timestamped_anti_replay_ledger_template_verified": template_verified,
        "source_replay_guard_nonce_unique": bool(
            source.get("source_replay_guard_nonce_unique")
        ),
        "source_replay_guard_session_binding_valid": bool(
            source.get("source_replay_guard_session_binding_valid")
        ),
        "source_nonce_session_timestamped_anti_replay_ledger_present": ledger,
        "source_nonce_session_timestamped_anti_replay_ledger_hash_bound": ledger_hash,
        "source_nonce_session_timestamp_monotonic": timestamp,
        "source_nonce_session_ledger_entry_unique": unique,
        "source_nonce_session_timestamped_anti_replay_ledger_ready": ready,
        "upstream_source_replay_guard_nonce_session_binding_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_freshness(record, payload_sha):
    receipt = dict(
        record.get("receipt_trust_root_digest_revocation_authorization_signer_binding")
        or {}
    )
    expected_binding_path = (
        receipt.get(
            "expected_receipt_trust_root_digest_revocation_authorization_signer_binding_path"
        )
        or ""
    )
    expected_freshness_path = (
        receipt.get(
            "expected_receipt_authorization_signer_certificate_revocation_root_freshness_path"
        )
        or _sidecar(
            expected_binding_path,
            ".certificate-revocation-root-freshness.json",
        )
    )
    upstream_ready = bool(
        receipt.get("receipt_trust_root_revocation_authorization_signer_binding_ready")
    )
    revocation = bool(
        receipt.get("receipt_authorization_signer_certificate_revocation_present")
    )
    not_revoked = bool(
        receipt.get("receipt_authorization_signer_certificate_not_revoked")
    )
    freshness = bool(
        receipt.get("receipt_authorization_signer_root_freshness_present")
    )
    freshness_valid = bool(
        receipt.get("receipt_authorization_signer_root_freshness_valid")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_binding_path
        and expected_freshness_path
        and str(expected_binding_path).endswith(".json")
        and str(expected_freshness_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and receipt.get("receipt_trust_root_digest_not_revoked")
        and receipt.get("receipt_authorization_signer_binding_valid")
        and revocation
        and not_revoked
        and freshness
        and freshness_valid
        and not performed
    )
    return {
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness_verifier_id": (
            f"referee-repair-receipt-root-freshness-{payload_sha[:16]}"
        ),
        "expected_receipt_trust_root_digest_revocation_authorization_signer_binding_path": expected_binding_path,
        "expected_receipt_authorization_signer_certificate_revocation_root_freshness_path": expected_freshness_path,
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness_template_verified": template_verified,
        "receipt_trust_root_digest_not_revoked": bool(
            receipt.get("receipt_trust_root_digest_not_revoked")
        ),
        "receipt_authorization_signer_binding_valid": bool(
            receipt.get("receipt_authorization_signer_binding_valid")
        ),
        "receipt_authorization_signer_certificate_revocation_present": revocation,
        "receipt_authorization_signer_certificate_not_revoked": not_revoked,
        "receipt_authorization_signer_root_freshness_present": freshness,
        "receipt_authorization_signer_root_freshness_valid": freshness_valid,
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_trust_root_revocation_authorization_signer_binding_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_records = _source_merkle_records(packet_record, payload_sha)
    value_records = _value_freshness_records(packet_record, payload_sha)
    checksum_records = _checksum_cross_binding_records(packet_record, payload_sha)
    source_ledger = _source_ledger(packet_record, payload_sha)
    receipt_freshness = _receipt_freshness(packet_record, payload_sha)
    source_required = _required_count(source_records)
    source_ready = _count(
        source_records, "source_transparency_log_merkle_inclusion_checkpoint_hash_ready"
    )
    value_required = _required_count(value_records)
    value_ready = _count(
        value_records, "value_revocation_authority_signer_root_freshness_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_ready = _count(
        checksum_records,
        "checksum_attestation_payload_digest_expected_source_cross_binding_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_freshness.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_ledger.get("source_nonce_session_timestamped_anti_replay_ledger_ready")
        and receipt_freshness.get(
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_transparency_log_merkle_inclusion_checkpoint_hash_missing")
    if value_ready != value_required:
        blockers.append("value_revocation_authority_signer_root_freshness_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_attestation_payload_digest_expected_source_cross_binding_missing")
    if not source_ledger.get("source_nonce_session_timestamped_anti_replay_ledger_ready"):
        blockers.append("source_nonce_session_timestamped_anti_replay_ledger_missing")
    if not receipt_freshness.get(
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready"
    ):
        blockers.append(
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness_missing"
        )
    if consumable:
        blockers.append("payload_merkle_freshness_ledger_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_id": (
            f"referee-repair-human-input-source-value-payload-merkle-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256"
            )
            or ""
        ),
        "source_transparency_log_merkle_inclusion_checkpoint_hash_records": source_records,
        "source_transparency_log_merkle_inclusion_checkpoint_hash_required_count": source_required,
        "source_transparency_log_merkle_inclusion_checkpoint_hash_ready_count": source_ready,
        "value_revocation_authority_signer_root_freshness_records": value_records,
        "value_revocation_authority_signer_root_freshness_required_count": value_required,
        "value_revocation_authority_signer_root_freshness_ready_count": value_ready,
        "checksum_attestation_payload_digest_expected_source_cross_binding_records": checksum_records,
        "checksum_attestation_payload_digest_expected_source_cross_binding_required_count": checksum_required,
        "checksum_attestation_payload_digest_expected_source_cross_binding_ready_count": checksum_ready,
        "source_nonce_session_timestamped_anti_replay_ledger": source_ledger,
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness": receipt_freshness,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "Merkle/freshness/ledger verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source Merkle inclusion checkpoints, value revocation authority/root freshness, checksum payload digest expected/source cross-bindings, source timestamped anti-replay ledgers, and receipt certificate revocation/root freshness markers"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_id": (
            f"referee-repair-request-human-input-source-value-payload-merkle-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_transparency_log_merkle_inclusion_checkpoint_hash_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get("value_revocation_authority_signer_root_freshness_records")
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_attestation_payload_digest_expected_source_cross_binding_records"
        )
        or []
    ]
    source_ledger_records = [
        record.get("source_nonce_session_timestamped_anti_replay_ledger") or {}
        for record in verifier_records
    ]
    receipt_freshness_records = [
        record.get(
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_hash_bound",
    )
    lint_ready_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready",
    )
    upstream_ready_count = _sum(
        upstream_packet_records,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready",
    )
    source_required = _required_count(source_records)
    source_checkpoint_count = _count(
        source_records, "source_transparency_log_merkle_checkpoint_present"
    )
    source_checkpoint_hash_count = _count(
        source_records, "source_transparency_log_merkle_checkpoint_hash_bound"
    )
    source_inclusion_hash_count = _count(
        source_records, "source_transparency_log_merkle_inclusion_proof_hash_match"
    )
    source_root_hash_count = _count(
        source_records, "source_transparency_log_checkpoint_root_hash_valid"
    )
    source_ready_count = _count(
        source_records, "source_transparency_log_merkle_inclusion_checkpoint_hash_ready"
    )
    value_required = _required_count(value_records)
    value_signer_count = _count(
        value_records, "value_revocation_authority_signer_present"
    )
    value_signature_count = _count(
        value_records, "value_revocation_authority_signature_valid"
    )
    value_freshness_count = _count(
        value_records, "value_revocation_root_freshness_present"
    )
    value_freshness_valid_count = _count(
        value_records, "value_revocation_root_freshness_valid"
    )
    value_ready_count = _count(
        value_records, "value_revocation_authority_signer_root_freshness_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_binding_count = _count(
        checksum_records,
        "checksum_attestation_payload_digest_expected_source_binding_present",
    )
    checksum_sha_count = _count(
        checksum_records, "checksum_attestation_payload_digest_expected_source_sha_match"
    )
    checksum_identity_count = _count(
        checksum_records,
        "checksum_attestation_payload_digest_source_packet_identity_match",
    )
    checksum_hash_count = _count(
        checksum_records, "checksum_attestation_payload_digest_cross_binding_hash_bound"
    )
    checksum_ready_count = _count(
        checksum_records,
        "checksum_attestation_payload_digest_expected_source_cross_binding_ready",
    )
    source_ledger_required = record_count
    source_ledger_count = _sum(
        source_ledger_records,
        "source_nonce_session_timestamped_anti_replay_ledger_present",
    )
    source_ledger_hash_count = _sum(
        source_ledger_records,
        "source_nonce_session_timestamped_anti_replay_ledger_hash_bound",
    )
    source_timestamp_count = _sum(
        source_ledger_records, "source_nonce_session_timestamp_monotonic"
    )
    source_ledger_unique_count = _sum(
        source_ledger_records, "source_nonce_session_ledger_entry_unique"
    )
    source_ledger_ready_count = _sum(
        source_ledger_records,
        "source_nonce_session_timestamped_anti_replay_ledger_ready",
    )
    receipt_freshness_required = record_count
    receipt_revocation_count = _sum(
        receipt_freshness_records,
        "receipt_authorization_signer_certificate_revocation_present",
    )
    receipt_not_revoked_count = _sum(
        receipt_freshness_records,
        "receipt_authorization_signer_certificate_not_revoked",
    )
    receipt_root_freshness_count = _sum(
        receipt_freshness_records,
        "receipt_authorization_signer_root_freshness_present",
    )
    receipt_root_freshness_valid_count = _sum(
        receipt_freshness_records,
        "receipt_authorization_signer_root_freshness_valid",
    )
    receipt_ready_count = _sum(
        receipt_freshness_records,
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready",
    )
    receipt_performed_count = _sum(receipt_freshness_records, "receipt_authorization_performed")
    expected_file_creation_count = _sum(
        verifier_records, "expected_packet_file_creation_performed"
    )
    receipt_creation_count = _sum(verifier_records, "redrive_receipt_creation_performed")
    evidence_release_count = _sum(verifier_records, "evidence_release_performed")
    promoted_count = _sum(verifier_records, "repair_evidence_promoted")
    closure_count = _sum(verifier_records, "request_closure_performed")
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_ledger_ready_count == source_ledger_required
        and receipt_ready_count == receipt_freshness_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_transparency_revocation_replay_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_transparency_revocation_replay_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_transparency_log_merkle_inclusion_checkpoint_hashes_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} checkpoints={source_checkpoint_count} roots={source_root_hash_count}",
    )
    _add_check(
        checks,
        "value_revocation_authority_signer_root_freshness_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} signer={value_signer_count} freshness={value_freshness_count}",
    )
    _add_check(
        checks,
        "checksum_attestation_payload_digest_expected_source_cross_bindings_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} bindings={checksum_binding_count} sha={checksum_sha_count}",
    )
    _add_check(
        checks,
        "source_nonce_session_timestamped_anti_replay_ledgers_ready",
        source_ledger_required > 0 and source_ledger_ready_count == source_ledger_required,
        f"ready={source_ledger_ready_count}/{source_ledger_required} ledgers={source_ledger_count} timestamps={source_timestamp_count}",
    )
    _add_check(
        checks,
        "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready",
        receipt_freshness_required > 0
        and receipt_ready_count == receipt_freshness_required,
        f"ready={receipt_ready_count}/{receipt_freshness_required} revocation={receipt_revocation_count} freshness={receipt_root_freshness_count}",
    )
    _add_check(
        checks,
        "all_request_payload_merkle_freshness_ledger_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_merkle_freshness_ledger_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_MERKLE_FRESHNESS_LEDGER_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_MERKLE_FRESHNESS_LEDGER_UPSTREAM_LINT"
    elif (
        source_checkpoint_count != source_required
        or source_checkpoint_hash_count != source_required
        or source_inclusion_hash_count != source_required
        or source_root_hash_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_TRANSPARENCY_LOG_MERKLE_INCLUSION_CHECKPOINT_HASH_MISSING"
    elif (
        value_signer_count != value_required
        or value_signature_count != value_required
        or value_freshness_count != value_required
        or value_freshness_valid_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_REVOCATION_AUTHORITY_SIGNER_ROOT_FRESHNESS_MISSING"
    elif (
        checksum_binding_count != checksum_required
        or checksum_sha_count != checksum_required
        or checksum_identity_count != checksum_required
        or checksum_hash_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_ATTESTATION_PAYLOAD_DIGEST_EXPECTED_SOURCE_CROSS_BINDING_MISSING"
    elif (
        source_ledger_count != source_ledger_required
        or source_ledger_hash_count != source_ledger_required
        or source_timestamp_count != source_ledger_required
        or source_ledger_unique_count != source_ledger_required
        or source_ledger_ready_count != source_ledger_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_NONCE_SESSION_TIMESTAMPED_ANTI_REPLAY_LEDGER_MISSING"
    elif (
        receipt_revocation_count != receipt_freshness_required
        or receipt_not_revoked_count != receipt_freshness_required
        or receipt_root_freshness_count != receipt_freshness_required
        or receipt_root_freshness_valid_count != receipt_freshness_required
        or receipt_ready_count != receipt_freshness_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTHORIZATION_SIGNER_BINDING_CERTIFICATE_REVOCATION_ROOT_FRESHNESS_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_MERKLE_FRESHNESS_LEDGER_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_MERKLE_FRESHNESS_LEDGER_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_MERKLE_FRESHNESS_LEDGER_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_MERKLE_FRESHNESS_LEDGER_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready_count": lint_ready_count,
            "upstream_payload_transparency_revocation_replay_ready_count": upstream_ready_count,
            "upstream_payload_transparency_revocation_replay_blocked_count": record_count - upstream_ready_count,
            "source_transparency_log_merkle_inclusion_checkpoint_hash_required_count": source_required,
            "source_transparency_log_merkle_checkpoint_present_count": source_checkpoint_count,
            "source_transparency_log_merkle_checkpoint_hash_bound_count": source_checkpoint_hash_count,
            "source_transparency_log_merkle_inclusion_proof_hash_match_count": source_inclusion_hash_count,
            "source_transparency_log_checkpoint_root_hash_valid_count": source_root_hash_count,
            "source_transparency_log_merkle_inclusion_checkpoint_hash_ready_count": source_ready_count,
            "value_revocation_authority_signer_root_freshness_required_count": value_required,
            "value_revocation_authority_signer_present_count": value_signer_count,
            "value_revocation_authority_signature_valid_count": value_signature_count,
            "value_revocation_root_freshness_present_count": value_freshness_count,
            "value_revocation_root_freshness_valid_count": value_freshness_valid_count,
            "value_revocation_authority_signer_root_freshness_ready_count": value_ready_count,
            "checksum_attestation_payload_digest_expected_source_cross_binding_required_count": checksum_required,
            "checksum_attestation_payload_digest_expected_source_binding_present_count": checksum_binding_count,
            "checksum_attestation_payload_digest_expected_source_sha_match_count": checksum_sha_count,
            "checksum_attestation_payload_digest_source_packet_identity_match_count": checksum_identity_count,
            "checksum_attestation_payload_digest_cross_binding_hash_bound_count": checksum_hash_count,
            "checksum_attestation_payload_digest_expected_source_cross_binding_ready_count": checksum_ready_count,
            "source_nonce_session_timestamped_anti_replay_ledger_required_count": source_ledger_required,
            "source_nonce_session_timestamped_anti_replay_ledger_present_count": source_ledger_count,
            "source_nonce_session_timestamped_anti_replay_ledger_hash_bound_count": source_ledger_hash_count,
            "source_nonce_session_timestamp_monotonic_count": source_timestamp_count,
            "source_nonce_session_ledger_entry_unique_count": source_ledger_unique_count,
            "source_nonce_session_timestamped_anti_replay_ledger_ready_count": source_ledger_ready_count,
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness_required_count": receipt_freshness_required,
            "receipt_authorization_signer_certificate_revocation_present_count": receipt_revocation_count,
            "receipt_authorization_signer_certificate_not_revoked_count": receipt_not_revoked_count,
            "receipt_authorization_signer_root_freshness_present_count": receipt_root_freshness_count,
            "receipt_authorization_signer_root_freshness_valid_count": receipt_root_freshness_valid_count,
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source transparency-log Merkle inclusion checkpoints, value revocation authority/root freshness, checksum attestation payload expected/source cross-bindings, source timestamped anti-replay ledgers, and receipt authorization signer certificate revocation/root freshness.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Merkle Freshness Ledger Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
