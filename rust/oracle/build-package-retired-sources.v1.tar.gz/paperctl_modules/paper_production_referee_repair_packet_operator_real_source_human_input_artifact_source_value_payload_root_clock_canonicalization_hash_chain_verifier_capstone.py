"""Human-input artifact source/value payload root/clock/canonicalization verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-root-clock-canonicalization-hash-chain-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_count",
    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_lint_ready_count",
    "upstream_payload_signed_tree_head_expiry_signature_ready_count",
    "upstream_payload_signed_tree_head_expiry_signature_blocked_count",
    "source_signed_tree_head_log_operator_public_key_root_consistency_required_count",
    "source_signed_tree_head_log_operator_public_key_present_count",
    "source_signed_tree_head_log_operator_public_key_hash_bound_count",
    "source_signed_tree_head_log_root_consistency_present_count",
    "source_signed_tree_head_log_root_consistency_valid_count",
    "source_signed_tree_head_log_operator_public_key_root_consistency_ready_count",
    "value_revocation_timestamp_authority_signature_expiry_clock_window_required_count",
    "value_revocation_timestamp_authority_signature_present_count",
    "value_revocation_timestamp_authority_signature_valid_count",
    "value_revocation_expiry_clock_window_present_count",
    "value_revocation_expiry_clock_window_valid_count",
    "value_revocation_timestamp_authority_signature_expiry_clock_window_ready_count",
    "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_required_count",
    "checksum_cross_binding_operator_certificate_present_count",
    "checksum_cross_binding_operator_certificate_valid_count",
    "checksum_cross_binding_operator_public_key_present_count",
    "checksum_cross_binding_operator_public_key_valid_count",
    "checksum_cross_binding_payload_canonicalization_present_count",
    "checksum_cross_binding_payload_canonicalization_valid_count",
    "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready_count",
    "source_append_only_ledger_sequence_gap_session_root_hash_chain_required_count",
    "source_append_only_ledger_sequence_gap_check_present_count",
    "source_append_only_ledger_sequence_gap_check_valid_count",
    "source_session_root_hash_chain_present_count",
    "source_session_root_hash_chain_valid_count",
    "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready_count",
    "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_required_count",
    "receipt_authority_signature_public_key_present_count",
    "receipt_authority_signature_public_key_valid_count",
    "receipt_authority_signature_root_consistency_present_count",
    "receipt_authority_signature_root_consistency_valid_count",
    "receipt_authority_revocation_timestamp_freshness_present_count",
    "receipt_authority_revocation_timestamp_freshness_valid_count",
    "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _sum(records, key):
    return sum(1 for item in records if item.get(key))


def _source_root_consistency_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get("source_transparency_log_signed_tree_head_records") or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_sth_path = item.get("expected_source_transparency_log_signed_tree_head_path") or ""
        expected_root_path = (
            item.get(
                "expected_source_signed_tree_head_log_operator_public_key_root_consistency_path"
            )
            or _sidecar(expected_sth_path, ".operator-public-key-root-consistency.json")
        )
        upstream_ready = bool(item.get("source_transparency_log_signed_tree_head_ready"))
        public_key = bool(
            item.get("source_signed_tree_head_log_operator_public_key_present")
        )
        public_key_hash = bool(
            item.get("source_signed_tree_head_log_operator_public_key_hash_bound")
        )
        root_consistency = bool(
            item.get("source_signed_tree_head_log_root_consistency_present")
        )
        root_valid = bool(item.get("source_signed_tree_head_log_root_consistency_valid"))
        template_verified = bool(
            expected_sth_path
            and expected_root_path
            and str(expected_sth_path).endswith(".json")
            and str(expected_root_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("source_transparency_log_signed_tree_head_present")
            and item.get("source_transparency_log_signed_tree_head_hash_bound")
            and item.get("source_transparency_log_signed_tree_head_signature_valid")
            and item.get("source_transparency_log_signed_tree_head_checkpoint_consistent")
            and public_key
            and public_key_hash
            and root_consistency
            and root_valid
        )
        record_sha = _sha(
            {
                "field": field,
                "expected_source_transparency_log_signed_tree_head_path": expected_sth_path,
                "expected_source_signed_tree_head_log_operator_public_key_root_consistency_path": expected_root_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                "source_signed_tree_head_log_operator_public_key_root_consistency_verifier_id": (
                    f"referee-repair-source-sth-root-consistency-{record_sha[:16]}"
                ),
                "source_signed_tree_head_log_operator_public_key_root_consistency_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_transparency_log_signed_tree_head_path": expected_sth_path,
                "expected_source_signed_tree_head_log_operator_public_key_root_consistency_path": expected_root_path,
                "source_signed_tree_head_log_operator_public_key_root_consistency_template_verified": template_verified,
                "source_transparency_log_signed_tree_head_present": bool(
                    item.get("source_transparency_log_signed_tree_head_present")
                ),
                "source_transparency_log_signed_tree_head_hash_bound": bool(
                    item.get("source_transparency_log_signed_tree_head_hash_bound")
                ),
                "source_transparency_log_signed_tree_head_signature_valid": bool(
                    item.get("source_transparency_log_signed_tree_head_signature_valid")
                ),
                "source_transparency_log_signed_tree_head_checkpoint_consistent": bool(
                    item.get(
                        "source_transparency_log_signed_tree_head_checkpoint_consistent"
                    )
                ),
                "source_signed_tree_head_log_operator_public_key_present": public_key,
                "source_signed_tree_head_log_operator_public_key_hash_bound": public_key_hash,
                "source_signed_tree_head_log_root_consistency_present": root_consistency,
                "source_signed_tree_head_log_root_consistency_valid": root_valid,
                "source_signed_tree_head_log_operator_public_key_root_consistency_ready": ready,
                "upstream_source_transparency_log_signed_tree_head_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_clock_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_revocation_root_freshness_timestamp_expiry_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_window_path = (
            item.get("expected_value_revocation_root_freshness_timestamp_expiry_path")
            or ""
        )
        expected_clock_path = (
            item.get(
                "expected_value_revocation_timestamp_authority_signature_expiry_clock_window_path"
            )
            or _sidecar(expected_window_path, ".authority-signature-clock-window.json")
        )
        upstream_ready = bool(
            item.get("value_revocation_root_freshness_timestamp_expiry_ready")
        )
        authority_signature = bool(
            item.get("value_revocation_timestamp_authority_signature_present")
        )
        authority_signature_valid = bool(
            item.get("value_revocation_timestamp_authority_signature_valid")
        )
        clock_window = bool(item.get("value_revocation_expiry_clock_window_present"))
        clock_window_valid = bool(
            item.get("value_revocation_expiry_clock_window_valid")
        )
        template_verified = bool(
            expected_window_path
            and expected_clock_path
            and str(expected_window_path).endswith(".json")
            and str(expected_clock_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("value_revocation_root_freshness_timestamp_present")
            and item.get("value_revocation_root_freshness_timestamp_valid")
            and item.get("value_revocation_root_freshness_expiry_present")
            and item.get("value_revocation_root_freshness_expiry_valid")
            and authority_signature
            and authority_signature_valid
            and clock_window
            and clock_window_valid
        )
        record_sha = _sha(
            {
                "field": field,
                "expected_value_revocation_root_freshness_timestamp_expiry_path": expected_window_path,
                "expected_value_revocation_timestamp_authority_signature_expiry_clock_window_path": expected_clock_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                "value_revocation_timestamp_authority_signature_expiry_clock_window_verifier_id": (
                    f"referee-repair-value-clock-window-{record_sha[:16]}"
                ),
                "value_revocation_timestamp_authority_signature_expiry_clock_window_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_revocation_root_freshness_timestamp_expiry_path": expected_window_path,
                "expected_value_revocation_timestamp_authority_signature_expiry_clock_window_path": expected_clock_path,
                "value_revocation_timestamp_authority_signature_expiry_clock_window_template_verified": template_verified,
                "value_revocation_root_freshness_timestamp_present": bool(
                    item.get("value_revocation_root_freshness_timestamp_present")
                ),
                "value_revocation_root_freshness_timestamp_valid": bool(
                    item.get("value_revocation_root_freshness_timestamp_valid")
                ),
                "value_revocation_root_freshness_expiry_present": bool(
                    item.get("value_revocation_root_freshness_expiry_present")
                ),
                "value_revocation_root_freshness_expiry_valid": bool(
                    item.get("value_revocation_root_freshness_expiry_valid")
                ),
                "value_revocation_timestamp_authority_signature_present": authority_signature,
                "value_revocation_timestamp_authority_signature_valid": authority_signature_valid,
                "value_revocation_expiry_clock_window_present": clock_window,
                "value_revocation_expiry_clock_window_valid": clock_window_valid,
                "value_revocation_timestamp_authority_signature_expiry_clock_window_ready": ready,
                "upstream_value_revocation_root_freshness_timestamp_expiry_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_canonicalization_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_expected_source_cross_binding_operator_signature_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_signature_path = (
            item.get("expected_checksum_expected_source_cross_binding_operator_signature_path")
            or ""
        )
        expected_canonical_path = (
            item.get(
                "expected_checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_path"
            )
            or _sidecar(
                expected_signature_path,
                ".operator-certificate-public-key-payload-canonicalization.json",
            )
        )
        upstream_ready = bool(
            item.get("checksum_expected_source_cross_binding_operator_signature_ready")
        )
        certificate = bool(
            item.get("checksum_cross_binding_operator_certificate_present")
        )
        certificate_valid = bool(
            item.get("checksum_cross_binding_operator_certificate_valid")
        )
        public_key = bool(item.get("checksum_cross_binding_operator_public_key_present"))
        public_key_valid = bool(
            item.get("checksum_cross_binding_operator_public_key_valid")
        )
        canonical = bool(
            item.get("checksum_cross_binding_payload_canonicalization_present")
        )
        canonical_valid = bool(
            item.get("checksum_cross_binding_payload_canonicalization_valid")
        )
        template_verified = bool(
            expected_signature_path
            and expected_canonical_path
            and str(expected_signature_path).endswith(".json")
            and str(expected_canonical_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("checksum_expected_source_cross_binding_operator_signature_present")
            and item.get("checksum_expected_source_cross_binding_operator_signature_valid")
            and item.get("checksum_expected_source_cross_binding_operator_identity_bound")
            and item.get("checksum_expected_source_cross_binding_operator_signature_hash_bound")
            and certificate
            and certificate_valid
            and public_key
            and public_key_valid
            and canonical
            and canonical_valid
        )
        record_sha = _sha(
            {
                "field": field,
                "expected_checksum_expected_source_cross_binding_operator_signature_path": expected_signature_path,
                "expected_checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_path": expected_canonical_path,
                "parent_payload_sha256": payload_sha,
            }
        )
        records.append(
            {
                "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_verifier_id": (
                    f"referee-repair-checksum-canonicalization-{record_sha[:16]}"
                ),
                "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_expected_source_cross_binding_operator_signature_path": expected_signature_path,
                "expected_checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_path": expected_canonical_path,
                "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_template_verified": template_verified,
                "checksum_expected_source_cross_binding_operator_signature_present": bool(
                    item.get(
                        "checksum_expected_source_cross_binding_operator_signature_present"
                    )
                ),
                "checksum_expected_source_cross_binding_operator_signature_valid": bool(
                    item.get(
                        "checksum_expected_source_cross_binding_operator_signature_valid"
                    )
                ),
                "checksum_expected_source_cross_binding_operator_identity_bound": bool(
                    item.get(
                        "checksum_expected_source_cross_binding_operator_identity_bound"
                    )
                ),
                "checksum_expected_source_cross_binding_operator_signature_hash_bound": bool(
                    item.get(
                        "checksum_expected_source_cross_binding_operator_signature_hash_bound"
                    )
                ),
                "checksum_cross_binding_operator_certificate_present": certificate,
                "checksum_cross_binding_operator_certificate_valid": certificate_valid,
                "checksum_cross_binding_operator_public_key_present": public_key,
                "checksum_cross_binding_operator_public_key_valid": public_key_valid,
                "checksum_cross_binding_payload_canonicalization_present": canonical,
                "checksum_cross_binding_payload_canonicalization_valid": canonical_valid,
                "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready": ready,
                "upstream_checksum_expected_source_cross_binding_operator_signature_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_hash_chain_record(packet_record, payload_sha):
    source = dict(
        packet_record.get("source_anti_replay_ledger_append_only_sequence_session_root")
        or {}
    )
    expected_root_path = (
        source.get("expected_source_anti_replay_ledger_append_only_sequence_session_root_path")
        or ""
    )
    expected_hash_chain_path = (
        source.get(
            "expected_source_append_only_ledger_sequence_gap_session_root_hash_chain_path"
        )
        or _sidecar(expected_root_path, ".sequence-gap-session-root-hash-chain.json")
    )
    upstream_ready = bool(
        source.get("source_anti_replay_ledger_append_only_sequence_session_root_ready")
    )
    sequence_gap = bool(source.get("source_append_only_ledger_sequence_gap_check_present"))
    sequence_gap_valid = bool(
        source.get("source_append_only_ledger_sequence_gap_check_valid")
    )
    hash_chain = bool(source.get("source_session_root_hash_chain_present"))
    hash_chain_valid = bool(source.get("source_session_root_hash_chain_valid"))
    template_verified = bool(
        expected_root_path
        and expected_hash_chain_path
        and str(expected_root_path).endswith(".json")
        and str(expected_hash_chain_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and source.get("source_anti_replay_ledger_append_only_sequence_present")
        and source.get("source_anti_replay_ledger_append_only_sequence_valid")
        and source.get("source_anti_replay_ledger_session_root_present")
        and source.get("source_anti_replay_ledger_session_root_valid")
        and sequence_gap
        and sequence_gap_valid
        and hash_chain
        and hash_chain_valid
    )
    return {
        "source_append_only_ledger_sequence_gap_session_root_hash_chain_verifier_id": (
            f"referee-repair-source-hash-chain-{payload_sha[:16]}"
        ),
        "required": True,
        "expected_source_anti_replay_ledger_append_only_sequence_session_root_path": expected_root_path,
        "expected_source_append_only_ledger_sequence_gap_session_root_hash_chain_path": expected_hash_chain_path,
        "source_append_only_ledger_sequence_gap_session_root_hash_chain_template_verified": template_verified,
        "source_anti_replay_ledger_append_only_sequence_present": bool(
            source.get("source_anti_replay_ledger_append_only_sequence_present")
        ),
        "source_anti_replay_ledger_append_only_sequence_valid": bool(
            source.get("source_anti_replay_ledger_append_only_sequence_valid")
        ),
        "source_anti_replay_ledger_session_root_present": bool(
            source.get("source_anti_replay_ledger_session_root_present")
        ),
        "source_anti_replay_ledger_session_root_valid": bool(
            source.get("source_anti_replay_ledger_session_root_valid")
        ),
        "source_append_only_ledger_sequence_gap_check_present": sequence_gap,
        "source_append_only_ledger_sequence_gap_check_valid": sequence_gap_valid,
        "source_session_root_hash_chain_present": hash_chain,
        "source_session_root_hash_chain_valid": hash_chain_valid,
        "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready": ready,
        "upstream_source_anti_replay_ledger_append_only_sequence_session_root_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_freshness_record(packet_record, payload_sha):
    receipt = dict(
        packet_record.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature"
        )
        or {}
    )
    expected_signature_path = (
        receipt.get(
            "expected_receipt_signer_certificate_revocation_root_freshness_authority_signature_path"
        )
        or ""
    )
    expected_freshness_path = (
        receipt.get(
            "expected_receipt_authority_signature_public_key_root_revocation_timestamp_freshness_path"
        )
        or _sidecar(
            expected_signature_path,
            ".public-key-root-revocation-timestamp-freshness.json",
        )
    )
    upstream_ready = bool(
        receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready"
        )
    )
    public_key = bool(receipt.get("receipt_authority_signature_public_key_present"))
    public_key_valid = bool(
        receipt.get("receipt_authority_signature_public_key_valid")
    )
    root_consistency = bool(
        receipt.get("receipt_authority_signature_root_consistency_present")
    )
    root_consistency_valid = bool(
        receipt.get("receipt_authority_signature_root_consistency_valid")
    )
    timestamp_freshness = bool(
        receipt.get("receipt_authority_revocation_timestamp_freshness_present")
    )
    timestamp_freshness_valid = bool(
        receipt.get("receipt_authority_revocation_timestamp_freshness_valid")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_signature_path
        and expected_freshness_path
        and str(expected_signature_path).endswith(".json")
        and str(expected_freshness_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_present"
        )
        and receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid"
        )
        and receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound"
        )
        and receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound"
        )
        and public_key
        and public_key_valid
        and root_consistency
        and root_consistency_valid
        and timestamp_freshness
        and timestamp_freshness_valid
        and not performed
    )
    return {
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_verifier_id": (
            f"referee-repair-receipt-authority-freshness-{payload_sha[:16]}"
        ),
        "required": True,
        "expected_receipt_signer_certificate_revocation_root_freshness_authority_signature_path": expected_signature_path,
        "expected_receipt_authority_signature_public_key_root_revocation_timestamp_freshness_path": expected_freshness_path,
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_template_verified": template_verified,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_present": bool(
            receipt.get(
                "receipt_signer_certificate_revocation_root_freshness_authority_signature_present"
            )
        ),
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid": bool(
            receipt.get(
                "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid"
            )
        ),
        "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound": bool(
            receipt.get(
                "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound"
            )
        ),
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound": bool(
            receipt.get(
                "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound"
            )
        ),
        "receipt_authority_signature_public_key_present": public_key,
        "receipt_authority_signature_public_key_valid": public_key_valid,
        "receipt_authority_signature_root_consistency_present": root_consistency,
        "receipt_authority_signature_root_consistency_valid": root_consistency_valid,
        "receipt_authority_revocation_timestamp_freshness_present": timestamp_freshness,
        "receipt_authority_revocation_timestamp_freshness_valid": timestamp_freshness_valid,
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_signer_certificate_revocation_root_freshness_authority_signature_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload_sha = _sha(
        {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_record.v1"
            ),
            "request_id": packet_record.get("request_id"),
            "slug": packet_record.get("slug") or "",
            "packet_type": packet_record.get("packet_type") or "",
            "parent_payload_sha256": packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256"
            )
            or "",
        }
    )
    source_records = _source_root_consistency_records(packet_record, payload_sha)
    value_records = _value_clock_records(packet_record, payload_sha)
    checksum_records = _checksum_canonicalization_records(packet_record, payload_sha)
    source_hash_chain = _source_hash_chain_record(packet_record, payload_sha)
    receipt_freshness = _receipt_freshness_record(packet_record, payload_sha)
    source_required = _required_count(source_records)
    value_required = _required_count(value_records)
    checksum_required = _required_count(checksum_records)
    source_ready = _count(
        source_records,
        "source_signed_tree_head_log_operator_public_key_root_consistency_ready",
    )
    value_ready = _count(
        value_records,
        "value_revocation_timestamp_authority_signature_expiry_clock_window_ready",
    )
    checksum_ready = _count(
        checksum_records,
        "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_freshness.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready"
        )
        and source_ready == source_required
        and value_ready == value_required
        and checksum_ready == checksum_required
        and source_hash_chain.get(
            "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready"
        )
        and receipt_freshness.get(
            "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_signed_tree_head_log_operator_public_key_root_consistency_missing")
    if value_ready != value_required:
        blockers.append("value_revocation_timestamp_authority_signature_expiry_clock_window_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_missing")
    if not source_hash_chain.get(
        "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready"
    ):
        blockers.append("source_append_only_ledger_sequence_gap_session_root_hash_chain_missing")
    if not receipt_freshness.get(
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready"
    ):
        blockers.append("receipt_authority_signature_public_key_root_revocation_timestamp_freshness_missing")
    if consumable:
        blockers.append("payload_root_clock_canonicalization_hash_chain_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_id": (
            f"referee-repair-human-input-source-value-payload-root-clock-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256"
            )
            or ""
        ),
        "source_signed_tree_head_log_operator_public_key_root_consistency_records": source_records,
        "source_signed_tree_head_log_operator_public_key_root_consistency_required_count": source_required,
        "source_signed_tree_head_log_operator_public_key_root_consistency_ready_count": source_ready,
        "value_revocation_timestamp_authority_signature_expiry_clock_window_records": value_records,
        "value_revocation_timestamp_authority_signature_expiry_clock_window_required_count": value_required,
        "value_revocation_timestamp_authority_signature_expiry_clock_window_ready_count": value_ready,
        "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_records": checksum_records,
        "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_required_count": checksum_required,
        "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready_count": checksum_ready,
        "source_append_only_ledger_sequence_gap_session_root_hash_chain": source_hash_chain,
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness": receipt_freshness,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "root/clock/canonicalization/hash-chain verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source STH log public-key/root consistency, value timestamp authority signature and expiry clock window, checksum operator certificate/public-key canonicalization, source sequence-gap hash-chain, and receipt authority public-key/root freshness markers"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready"
        )
    ]
    payload_sha = _sha(
        {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_record.v1"
            ),
            "request_id": request_id,
            "slug": slug,
            "payload_sha256s": [
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_payload_sha256"
                )
                for item in verifier_records
            ],
        }
    )
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_id": (
            f"referee-repair-request-human-input-source-value-payload-root-clock-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_signed_tree_head_log_operator_public_key_root_consistency_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "value_revocation_timestamp_authority_signature_expiry_clock_window_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_records"
        )
        or []
    ]
    source_hash_chain_records = [
        record.get("source_append_only_ledger_sequence_gap_session_root_hash_chain")
        or {}
        for record in verifier_records
    ]
    receipt_freshness_records = [
        record.get(
            "receipt_authority_signature_public_key_root_revocation_timestamp_freshness"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_hash_bound",
    )
    lint_ready_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_lint_ready",
    )
    upstream_ready_count = _sum(
        upstream_packet_records,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready",
    )
    source_required = _required_count(source_records)
    source_public_key_count = _count(
        source_records, "source_signed_tree_head_log_operator_public_key_present"
    )
    source_public_key_hash_count = _count(
        source_records, "source_signed_tree_head_log_operator_public_key_hash_bound"
    )
    source_root_consistency_count = _count(
        source_records, "source_signed_tree_head_log_root_consistency_present"
    )
    source_root_valid_count = _count(
        source_records, "source_signed_tree_head_log_root_consistency_valid"
    )
    source_ready_count = _count(
        source_records,
        "source_signed_tree_head_log_operator_public_key_root_consistency_ready",
    )
    value_required = _required_count(value_records)
    value_signature_count = _count(
        value_records, "value_revocation_timestamp_authority_signature_present"
    )
    value_signature_valid_count = _count(
        value_records, "value_revocation_timestamp_authority_signature_valid"
    )
    value_clock_count = _count(
        value_records, "value_revocation_expiry_clock_window_present"
    )
    value_clock_valid_count = _count(
        value_records, "value_revocation_expiry_clock_window_valid"
    )
    value_ready_count = _count(
        value_records,
        "value_revocation_timestamp_authority_signature_expiry_clock_window_ready",
    )
    checksum_required = _required_count(checksum_records)
    checksum_certificate_count = _count(
        checksum_records, "checksum_cross_binding_operator_certificate_present"
    )
    checksum_certificate_valid_count = _count(
        checksum_records, "checksum_cross_binding_operator_certificate_valid"
    )
    checksum_public_key_count = _count(
        checksum_records, "checksum_cross_binding_operator_public_key_present"
    )
    checksum_public_key_valid_count = _count(
        checksum_records, "checksum_cross_binding_operator_public_key_valid"
    )
    checksum_canonical_count = _count(
        checksum_records, "checksum_cross_binding_payload_canonicalization_present"
    )
    checksum_canonical_valid_count = _count(
        checksum_records, "checksum_cross_binding_payload_canonicalization_valid"
    )
    checksum_ready_count = _count(
        checksum_records,
        "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready",
    )
    source_hash_required = record_count
    source_sequence_gap_count = _sum(
        source_hash_chain_records,
        "source_append_only_ledger_sequence_gap_check_present",
    )
    source_sequence_gap_valid_count = _sum(
        source_hash_chain_records,
        "source_append_only_ledger_sequence_gap_check_valid",
    )
    source_hash_chain_count = _sum(
        source_hash_chain_records, "source_session_root_hash_chain_present"
    )
    source_hash_chain_valid_count = _sum(
        source_hash_chain_records, "source_session_root_hash_chain_valid"
    )
    source_hash_ready_count = _sum(
        source_hash_chain_records,
        "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready",
    )
    receipt_required = record_count
    receipt_public_key_count = _sum(
        receipt_freshness_records, "receipt_authority_signature_public_key_present"
    )
    receipt_public_key_valid_count = _sum(
        receipt_freshness_records, "receipt_authority_signature_public_key_valid"
    )
    receipt_root_count = _sum(
        receipt_freshness_records,
        "receipt_authority_signature_root_consistency_present",
    )
    receipt_root_valid_count = _sum(
        receipt_freshness_records,
        "receipt_authority_signature_root_consistency_valid",
    )
    receipt_timestamp_count = _sum(
        receipt_freshness_records,
        "receipt_authority_revocation_timestamp_freshness_present",
    )
    receipt_timestamp_valid_count = _sum(
        receipt_freshness_records,
        "receipt_authority_revocation_timestamp_freshness_valid",
    )
    receipt_ready_count = _sum(
        receipt_freshness_records,
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready",
    )
    receipt_performed_count = _sum(receipt_freshness_records, "receipt_authorization_performed")
    expected_file_creation_count = _sum(
        verifier_records, "expected_packet_file_creation_performed"
    )
    receipt_creation_count = _sum(verifier_records, "redrive_receipt_creation_performed")
    evidence_release_count = _sum(verifier_records, "evidence_release_performed")
    promoted_count = _sum(verifier_records, "repair_evidence_promoted")
    closure_count = _sum(verifier_records, "request_closure_performed")
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_hash_ready_count == source_hash_required
        and receipt_ready_count == receipt_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_signed_tree_head_expiry_signature_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_signed_tree_head_expiry_signature_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_signed_tree_head_log_operator_public_key_root_consistency_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} public_keys={source_public_key_count} root_consistency={source_root_consistency_count}",
    )
    _add_check(
        checks,
        "value_revocation_timestamp_authority_signature_expiry_clock_window_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} signatures={value_signature_count} clock_windows={value_clock_count}",
    )
    _add_check(
        checks,
        "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} certificates={checksum_certificate_count} canonical={checksum_canonical_count}",
    )
    _add_check(
        checks,
        "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready",
        source_hash_required > 0 and source_hash_ready_count == source_hash_required,
        f"ready={source_hash_ready_count}/{source_hash_required} sequence_gap={source_sequence_gap_count} hash_chain={source_hash_chain_count}",
    )
    _add_check(
        checks,
        "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready",
        receipt_required > 0 and receipt_ready_count == receipt_required,
        f"ready={receipt_ready_count}/{receipt_required} public_keys={receipt_public_key_count} timestamp_freshness={receipt_timestamp_count}",
    )
    _add_check(
        checks,
        "all_request_payload_root_clock_canonicalization_hash_chain_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_root_clock_canonicalization_hash_chain_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_ROOT_CLOCK_CANONICALIZATION_HASH_CHAIN_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_ROOT_CLOCK_CANONICALIZATION_HASH_CHAIN_UPSTREAM_LINT"
    elif (
        source_public_key_count != source_required
        or source_public_key_hash_count != source_required
        or source_root_consistency_count != source_required
        or source_root_valid_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_SIGNED_TREE_HEAD_LOG_OPERATOR_PUBLIC_KEY_ROOT_CONSISTENCY_MISSING"
    elif (
        value_signature_count != value_required
        or value_signature_valid_count != value_required
        or value_clock_count != value_required
        or value_clock_valid_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_REVOCATION_TIMESTAMP_AUTHORITY_SIGNATURE_EXPIRY_CLOCK_WINDOW_MISSING"
    elif (
        checksum_certificate_count != checksum_required
        or checksum_certificate_valid_count != checksum_required
        or checksum_public_key_count != checksum_required
        or checksum_public_key_valid_count != checksum_required
        or checksum_canonical_count != checksum_required
        or checksum_canonical_valid_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_CROSS_BINDING_OPERATOR_CERTIFICATE_PUBLIC_KEY_PAYLOAD_CANONICALIZATION_MISSING"
    elif (
        source_sequence_gap_count != source_hash_required
        or source_sequence_gap_valid_count != source_hash_required
        or source_hash_chain_count != source_hash_required
        or source_hash_chain_valid_count != source_hash_required
        or source_hash_ready_count != source_hash_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_APPEND_ONLY_LEDGER_SEQUENCE_GAP_SESSION_ROOT_HASH_CHAIN_MISSING"
    elif (
        receipt_public_key_count != receipt_required
        or receipt_public_key_valid_count != receipt_required
        or receipt_root_count != receipt_required
        or receipt_root_valid_count != receipt_required
        or receipt_timestamp_count != receipt_required
        or receipt_timestamp_valid_count != receipt_required
        or receipt_ready_count != receipt_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTHORITY_SIGNATURE_PUBLIC_KEY_ROOT_REVOCATION_TIMESTAMP_FRESHNESS_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_ROOT_CLOCK_CANONICALIZATION_HASH_CHAIN_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_ROOT_CLOCK_CANONICALIZATION_HASH_CHAIN_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_ROOT_CLOCK_CANONICALIZATION_HASH_CHAIN_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_ROOT_CLOCK_CANONICALIZATION_HASH_CHAIN_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_lint_ready_count": lint_ready_count,
            "upstream_payload_signed_tree_head_expiry_signature_ready_count": upstream_ready_count,
            "upstream_payload_signed_tree_head_expiry_signature_blocked_count": record_count - upstream_ready_count,
            "source_signed_tree_head_log_operator_public_key_root_consistency_required_count": source_required,
            "source_signed_tree_head_log_operator_public_key_present_count": source_public_key_count,
            "source_signed_tree_head_log_operator_public_key_hash_bound_count": source_public_key_hash_count,
            "source_signed_tree_head_log_root_consistency_present_count": source_root_consistency_count,
            "source_signed_tree_head_log_root_consistency_valid_count": source_root_valid_count,
            "source_signed_tree_head_log_operator_public_key_root_consistency_ready_count": source_ready_count,
            "value_revocation_timestamp_authority_signature_expiry_clock_window_required_count": value_required,
            "value_revocation_timestamp_authority_signature_present_count": value_signature_count,
            "value_revocation_timestamp_authority_signature_valid_count": value_signature_valid_count,
            "value_revocation_expiry_clock_window_present_count": value_clock_count,
            "value_revocation_expiry_clock_window_valid_count": value_clock_valid_count,
            "value_revocation_timestamp_authority_signature_expiry_clock_window_ready_count": value_ready_count,
            "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_required_count": checksum_required,
            "checksum_cross_binding_operator_certificate_present_count": checksum_certificate_count,
            "checksum_cross_binding_operator_certificate_valid_count": checksum_certificate_valid_count,
            "checksum_cross_binding_operator_public_key_present_count": checksum_public_key_count,
            "checksum_cross_binding_operator_public_key_valid_count": checksum_public_key_valid_count,
            "checksum_cross_binding_payload_canonicalization_present_count": checksum_canonical_count,
            "checksum_cross_binding_payload_canonicalization_valid_count": checksum_canonical_valid_count,
            "checksum_cross_binding_operator_certificate_public_key_payload_canonicalization_ready_count": checksum_ready_count,
            "source_append_only_ledger_sequence_gap_session_root_hash_chain_required_count": source_hash_required,
            "source_append_only_ledger_sequence_gap_check_present_count": source_sequence_gap_count,
            "source_append_only_ledger_sequence_gap_check_valid_count": source_sequence_gap_valid_count,
            "source_session_root_hash_chain_present_count": source_hash_chain_count,
            "source_session_root_hash_chain_valid_count": source_hash_chain_valid_count,
            "source_append_only_ledger_sequence_gap_session_root_hash_chain_ready_count": source_hash_ready_count,
            "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_required_count": receipt_required,
            "receipt_authority_signature_public_key_present_count": receipt_public_key_count,
            "receipt_authority_signature_public_key_valid_count": receipt_public_key_valid_count,
            "receipt_authority_signature_root_consistency_present_count": receipt_root_count,
            "receipt_authority_signature_root_consistency_valid_count": receipt_root_valid_count,
            "receipt_authority_revocation_timestamp_freshness_present_count": receipt_timestamp_count,
            "receipt_authority_revocation_timestamp_freshness_valid_count": receipt_timestamp_valid_count,
            "receipt_authority_signature_public_key_root_revocation_timestamp_freshness_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source signed-tree-head log operator public-key/root consistency, value revocation timestamp authority signatures and expiry clock windows, checksum operator certificate/public-key payload canonicalization, source append-only sequence-gap/session-root hash chains, and receipt authority public-key/root revocation timestamp freshness.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Root Clock Canonicalization Hash Chain Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_root_clock_canonicalization_hash_chain_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
