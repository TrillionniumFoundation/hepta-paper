"""Human-input artifact source/value payload signed-tree/expiry signature verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-signed-tree-head-expiry-signature-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_count",
    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready_count",
    "upstream_payload_merkle_freshness_ledger_ready_count",
    "upstream_payload_merkle_freshness_ledger_blocked_count",
    "source_transparency_log_signed_tree_head_required_count",
    "source_transparency_log_signed_tree_head_present_count",
    "source_transparency_log_signed_tree_head_hash_bound_count",
    "source_transparency_log_signed_tree_head_signature_valid_count",
    "source_transparency_log_signed_tree_head_checkpoint_consistent_count",
    "source_transparency_log_signed_tree_head_ready_count",
    "value_revocation_root_freshness_timestamp_expiry_required_count",
    "value_revocation_root_freshness_timestamp_present_count",
    "value_revocation_root_freshness_timestamp_valid_count",
    "value_revocation_root_freshness_expiry_present_count",
    "value_revocation_root_freshness_expiry_valid_count",
    "value_revocation_root_freshness_timestamp_expiry_ready_count",
    "checksum_expected_source_cross_binding_operator_signature_required_count",
    "checksum_expected_source_cross_binding_operator_signature_present_count",
    "checksum_expected_source_cross_binding_operator_signature_valid_count",
    "checksum_expected_source_cross_binding_operator_identity_bound_count",
    "checksum_expected_source_cross_binding_operator_signature_hash_bound_count",
    "checksum_expected_source_cross_binding_operator_signature_ready_count",
    "source_anti_replay_ledger_append_only_sequence_session_root_required_count",
    "source_anti_replay_ledger_append_only_sequence_present_count",
    "source_anti_replay_ledger_append_only_sequence_valid_count",
    "source_anti_replay_ledger_session_root_present_count",
    "source_anti_replay_ledger_session_root_valid_count",
    "source_anti_replay_ledger_append_only_sequence_session_root_ready_count",
    "receipt_signer_certificate_revocation_root_freshness_authority_signature_required_count",
    "receipt_signer_certificate_revocation_root_freshness_authority_signature_present_count",
    "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid_count",
    "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound_count",
    "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound_count",
    "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _sum(records, key):
    return sum(1 for item in records if item.get(key))


def _source_signed_tree_head_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_transparency_log_merkle_inclusion_checkpoint_hash_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_checkpoint_path = (
            item.get(
                "expected_source_transparency_log_merkle_inclusion_checkpoint_hash_path"
            )
            or ""
        )
        expected_sth_path = (
            item.get("expected_source_transparency_log_signed_tree_head_path")
            or _sidecar(expected_checkpoint_path, ".signed-tree-head.json")
        )
        upstream_ready = bool(
            item.get("source_transparency_log_merkle_inclusion_checkpoint_hash_ready")
        )
        sth_present = bool(item.get("source_transparency_log_signed_tree_head_present"))
        sth_hash = bool(item.get("source_transparency_log_signed_tree_head_hash_bound"))
        sth_sig = bool(
            item.get("source_transparency_log_signed_tree_head_signature_valid")
        )
        checkpoint_consistent = bool(
            item.get("source_transparency_log_signed_tree_head_checkpoint_consistent")
        )
        template_verified = bool(
            expected_checkpoint_path
            and expected_sth_path
            and str(expected_checkpoint_path).endswith(".json")
            and str(expected_sth_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("source_transparency_log_merkle_checkpoint_present")
            and item.get("source_transparency_log_merkle_checkpoint_hash_bound")
            and item.get("source_transparency_log_checkpoint_root_hash_valid")
            and sth_present
            and sth_hash
            and sth_sig
            and checkpoint_consistent
        )
        payload = {
            "field": field,
            "expected_source_transparency_log_merkle_inclusion_checkpoint_hash_path": expected_checkpoint_path,
            "expected_source_transparency_log_signed_tree_head_path": expected_sth_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "source_transparency_log_signed_tree_head_verifier_id": (
                    f"referee-repair-source-signed-tree-head-{record_sha[:16]}"
                ),
                "source_transparency_log_signed_tree_head_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_transparency_log_merkle_inclusion_checkpoint_hash_path": expected_checkpoint_path,
                "expected_source_transparency_log_signed_tree_head_path": expected_sth_path,
                "source_transparency_log_signed_tree_head_template_verified": template_verified,
                "source_transparency_log_merkle_checkpoint_present": bool(
                    item.get("source_transparency_log_merkle_checkpoint_present")
                ),
                "source_transparency_log_merkle_checkpoint_hash_bound": bool(
                    item.get("source_transparency_log_merkle_checkpoint_hash_bound")
                ),
                "source_transparency_log_checkpoint_root_hash_valid": bool(
                    item.get("source_transparency_log_checkpoint_root_hash_valid")
                ),
                "source_transparency_log_signed_tree_head_present": sth_present,
                "source_transparency_log_signed_tree_head_hash_bound": sth_hash,
                "source_transparency_log_signed_tree_head_signature_valid": sth_sig,
                "source_transparency_log_signed_tree_head_checkpoint_consistent": checkpoint_consistent,
                "source_transparency_log_signed_tree_head_ready": ready,
                "upstream_source_transparency_log_merkle_inclusion_checkpoint_hash_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_timestamp_expiry_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_revocation_authority_signer_root_freshness_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_freshness_path = (
            item.get("expected_value_revocation_authority_signer_root_freshness_path")
            or ""
        )
        expected_window_path = (
            item.get("expected_value_revocation_root_freshness_timestamp_expiry_path")
            or _sidecar(expected_freshness_path, ".timestamp-expiry.json")
        )
        upstream_ready = bool(
            item.get("value_revocation_authority_signer_root_freshness_ready")
        )
        timestamp = bool(
            item.get("value_revocation_root_freshness_timestamp_present")
        )
        timestamp_valid = bool(
            item.get("value_revocation_root_freshness_timestamp_valid")
        )
        expiry = bool(item.get("value_revocation_root_freshness_expiry_present"))
        expiry_valid = bool(item.get("value_revocation_root_freshness_expiry_valid"))
        template_verified = bool(
            expected_freshness_path
            and expected_window_path
            and str(expected_freshness_path).endswith(".json")
            and str(expected_window_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("value_revocation_authority_signer_present")
            and item.get("value_revocation_authority_signature_valid")
            and item.get("value_revocation_root_freshness_valid")
            and timestamp
            and timestamp_valid
            and expiry
            and expiry_valid
        )
        payload = {
            "field": field,
            "expected_value_revocation_authority_signer_root_freshness_path": expected_freshness_path,
            "expected_value_revocation_root_freshness_timestamp_expiry_path": expected_window_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "value_revocation_root_freshness_timestamp_expiry_verifier_id": (
                    f"referee-repair-value-timestamp-expiry-{record_sha[:16]}"
                ),
                "value_revocation_root_freshness_timestamp_expiry_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_revocation_authority_signer_root_freshness_path": expected_freshness_path,
                "expected_value_revocation_root_freshness_timestamp_expiry_path": expected_window_path,
                "value_revocation_root_freshness_timestamp_expiry_template_verified": template_verified,
                "value_revocation_authority_signer_present": bool(
                    item.get("value_revocation_authority_signer_present")
                ),
                "value_revocation_authority_signature_valid": bool(
                    item.get("value_revocation_authority_signature_valid")
                ),
                "value_revocation_root_freshness_valid": bool(
                    item.get("value_revocation_root_freshness_valid")
                ),
                "value_revocation_root_freshness_timestamp_present": timestamp,
                "value_revocation_root_freshness_timestamp_valid": timestamp_valid,
                "value_revocation_root_freshness_expiry_present": expiry,
                "value_revocation_root_freshness_expiry_valid": expiry_valid,
                "value_revocation_root_freshness_timestamp_expiry_ready": ready,
                "upstream_value_revocation_authority_signer_root_freshness_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_operator_signature_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_attestation_payload_digest_expected_source_cross_binding_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_cross_binding_path = (
            item.get(
                "expected_checksum_attestation_payload_digest_expected_source_cross_binding_path"
            )
            or ""
        )
        expected_signature_path = (
            item.get("expected_checksum_expected_source_cross_binding_operator_signature_path")
            or _sidecar(expected_cross_binding_path, ".operator-signature.json")
        )
        upstream_ready = bool(
            item.get("checksum_attestation_payload_digest_expected_source_cross_binding_ready")
        )
        signature = bool(
            item.get("checksum_expected_source_cross_binding_operator_signature_present")
        )
        signature_valid = bool(
            item.get("checksum_expected_source_cross_binding_operator_signature_valid")
        )
        identity = bool(
            item.get(
                "checksum_expected_source_cross_binding_operator_identity_bound"
            )
        )
        signature_hash = bool(
            item.get(
                "checksum_expected_source_cross_binding_operator_signature_hash_bound"
            )
        )
        template_verified = bool(
            expected_cross_binding_path
            and expected_signature_path
            and str(expected_cross_binding_path).endswith(".json")
            and str(expected_signature_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("checksum_attestation_payload_digest_expected_source_binding_present")
            and item.get("checksum_attestation_payload_digest_expected_source_sha_match")
            and item.get("checksum_attestation_payload_digest_source_packet_identity_match")
            and item.get("checksum_attestation_payload_digest_cross_binding_hash_bound")
            and signature
            and signature_valid
            and identity
            and signature_hash
        )
        payload = {
            "field": field,
            "expected_checksum_attestation_payload_digest_expected_source_cross_binding_path": expected_cross_binding_path,
            "expected_checksum_expected_source_cross_binding_operator_signature_path": expected_signature_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "checksum_expected_source_cross_binding_operator_signature_verifier_id": (
                    f"referee-repair-checksum-operator-signature-{record_sha[:16]}"
                ),
                "checksum_expected_source_cross_binding_operator_signature_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_attestation_payload_digest_expected_source_cross_binding_path": expected_cross_binding_path,
                "expected_checksum_expected_source_cross_binding_operator_signature_path": expected_signature_path,
                "checksum_expected_source_cross_binding_operator_signature_template_verified": template_verified,
                "checksum_attestation_payload_digest_expected_source_binding_present": bool(
                    item.get(
                        "checksum_attestation_payload_digest_expected_source_binding_present"
                    )
                ),
                "checksum_attestation_payload_digest_expected_source_sha_match": bool(
                    item.get("checksum_attestation_payload_digest_expected_source_sha_match")
                ),
                "checksum_attestation_payload_digest_source_packet_identity_match": bool(
                    item.get(
                        "checksum_attestation_payload_digest_source_packet_identity_match"
                    )
                ),
                "checksum_attestation_payload_digest_cross_binding_hash_bound": bool(
                    item.get("checksum_attestation_payload_digest_cross_binding_hash_bound")
                ),
                "checksum_expected_source_cross_binding_operator_signature_present": signature,
                "checksum_expected_source_cross_binding_operator_signature_valid": signature_valid,
                "checksum_expected_source_cross_binding_operator_identity_bound": identity,
                "checksum_expected_source_cross_binding_operator_signature_hash_bound": signature_hash,
                "checksum_expected_source_cross_binding_operator_signature_ready": ready,
                "upstream_checksum_attestation_payload_digest_expected_source_cross_binding_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_append_only_session_root(record, payload_sha):
    source = dict(record.get("source_nonce_session_timestamped_anti_replay_ledger") or {})
    expected_ledger_path = (
        source.get("expected_source_nonce_session_timestamped_anti_replay_ledger_path")
        or ""
    )
    expected_root_path = (
        source.get(
            "expected_source_anti_replay_ledger_append_only_sequence_session_root_path"
        )
        or _sidecar(expected_ledger_path, ".append-only-sequence-session-root.json")
    )
    upstream_ready = bool(
        source.get("source_nonce_session_timestamped_anti_replay_ledger_ready")
    )
    sequence = bool(
        source.get("source_anti_replay_ledger_append_only_sequence_present")
    )
    sequence_valid = bool(
        source.get("source_anti_replay_ledger_append_only_sequence_valid")
    )
    session_root = bool(source.get("source_anti_replay_ledger_session_root_present"))
    session_root_valid = bool(
        source.get("source_anti_replay_ledger_session_root_valid")
    )
    template_verified = bool(
        expected_ledger_path
        and expected_root_path
        and str(expected_ledger_path).endswith(".json")
        and str(expected_root_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and source.get("source_nonce_session_timestamped_anti_replay_ledger_present")
        and source.get("source_nonce_session_timestamped_anti_replay_ledger_hash_bound")
        and source.get("source_nonce_session_timestamp_monotonic")
        and source.get("source_nonce_session_ledger_entry_unique")
        and sequence
        and sequence_valid
        and session_root
        and session_root_valid
    )
    return {
        "source_anti_replay_ledger_append_only_sequence_session_root_verifier_id": (
            f"referee-repair-source-ledger-root-{payload_sha[:16]}"
        ),
        "expected_source_nonce_session_timestamped_anti_replay_ledger_path": expected_ledger_path,
        "expected_source_anti_replay_ledger_append_only_sequence_session_root_path": expected_root_path,
        "source_anti_replay_ledger_append_only_sequence_session_root_template_verified": template_verified,
        "source_nonce_session_timestamped_anti_replay_ledger_present": bool(
            source.get("source_nonce_session_timestamped_anti_replay_ledger_present")
        ),
        "source_nonce_session_timestamped_anti_replay_ledger_hash_bound": bool(
            source.get("source_nonce_session_timestamped_anti_replay_ledger_hash_bound")
        ),
        "source_nonce_session_timestamp_monotonic": bool(
            source.get("source_nonce_session_timestamp_monotonic")
        ),
        "source_nonce_session_ledger_entry_unique": bool(
            source.get("source_nonce_session_ledger_entry_unique")
        ),
        "source_anti_replay_ledger_append_only_sequence_present": sequence,
        "source_anti_replay_ledger_append_only_sequence_valid": sequence_valid,
        "source_anti_replay_ledger_session_root_present": session_root,
        "source_anti_replay_ledger_session_root_valid": session_root_valid,
        "source_anti_replay_ledger_append_only_sequence_session_root_ready": ready,
        "upstream_source_nonce_session_timestamped_anti_replay_ledger_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_authority_signature(record, payload_sha):
    receipt = dict(
        record.get(
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness"
        )
        or {}
    )
    expected_freshness_path = (
        receipt.get(
            "expected_receipt_authorization_signer_certificate_revocation_root_freshness_path"
        )
        or ""
    )
    expected_signature_path = (
        receipt.get(
            "expected_receipt_signer_certificate_revocation_root_freshness_authority_signature_path"
        )
        or _sidecar(expected_freshness_path, ".authority-signature.json")
    )
    upstream_ready = bool(
        receipt.get(
            "receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready"
        )
    )
    signature = bool(
        receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_present"
        )
    )
    signature_valid = bool(
        receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid"
        )
    )
    identity = bool(
        receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound"
        )
    )
    signature_hash = bool(
        receipt.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound"
        )
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_freshness_path
        and expected_signature_path
        and str(expected_freshness_path).endswith(".json")
        and str(expected_signature_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and receipt.get("receipt_authorization_signer_certificate_not_revoked")
        and receipt.get("receipt_authorization_signer_root_freshness_valid")
        and signature
        and signature_valid
        and identity
        and signature_hash
        and not performed
    )
    return {
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_verifier_id": (
            f"referee-repair-receipt-authority-signature-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_signer_certificate_revocation_root_freshness_path": expected_freshness_path,
        "expected_receipt_signer_certificate_revocation_root_freshness_authority_signature_path": expected_signature_path,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_template_verified": template_verified,
        "receipt_authorization_signer_certificate_not_revoked": bool(
            receipt.get("receipt_authorization_signer_certificate_not_revoked")
        ),
        "receipt_authorization_signer_root_freshness_valid": bool(
            receipt.get("receipt_authorization_signer_root_freshness_valid")
        ),
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_present": signature,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid": signature_valid,
        "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound": identity,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound": signature_hash,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_authorization_signer_binding_certificate_revocation_root_freshness_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_records = _source_signed_tree_head_records(packet_record, payload_sha)
    value_records = _value_timestamp_expiry_records(packet_record, payload_sha)
    checksum_records = _checksum_operator_signature_records(packet_record, payload_sha)
    source_root = _source_append_only_session_root(packet_record, payload_sha)
    receipt_signature = _receipt_authority_signature(packet_record, payload_sha)
    source_required = _required_count(source_records)
    source_ready = _count(source_records, "source_transparency_log_signed_tree_head_ready")
    value_required = _required_count(value_records)
    value_ready = _count(
        value_records, "value_revocation_root_freshness_timestamp_expiry_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_ready = _count(
        checksum_records, "checksum_expected_source_cross_binding_operator_signature_ready"
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_signature.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_root.get(
            "source_anti_replay_ledger_append_only_sequence_session_root_ready"
        )
        and receipt_signature.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_transparency_log_signed_tree_head_missing")
    if value_ready != value_required:
        blockers.append("value_revocation_root_freshness_timestamp_expiry_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_expected_source_cross_binding_operator_signature_missing")
    if not source_root.get(
        "source_anti_replay_ledger_append_only_sequence_session_root_ready"
    ):
        blockers.append("source_anti_replay_ledger_append_only_sequence_session_root_missing")
    if not receipt_signature.get(
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready"
    ):
        blockers.append(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_missing"
        )
    if consumable:
        blockers.append("payload_signed_tree_head_expiry_signature_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_id": (
            f"referee-repair-human-input-source-value-payload-signed-tree-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_payload_sha256"
            )
            or ""
        ),
        "source_transparency_log_signed_tree_head_records": source_records,
        "source_transparency_log_signed_tree_head_required_count": source_required,
        "source_transparency_log_signed_tree_head_ready_count": source_ready,
        "value_revocation_root_freshness_timestamp_expiry_records": value_records,
        "value_revocation_root_freshness_timestamp_expiry_required_count": value_required,
        "value_revocation_root_freshness_timestamp_expiry_ready_count": value_ready,
        "checksum_expected_source_cross_binding_operator_signature_records": checksum_records,
        "checksum_expected_source_cross_binding_operator_signature_required_count": checksum_required,
        "checksum_expected_source_cross_binding_operator_signature_ready_count": checksum_ready,
        "source_anti_replay_ledger_append_only_sequence_session_root": source_root,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature": receipt_signature,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "signed-tree/expiry/signature verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source signed tree heads, value freshness timestamps/expiry windows, checksum cross-binding operator signatures, source append-only ledger session roots, and receipt revocation root freshness authority signatures"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_id": (
            f"referee-repair-request-human-input-source-value-payload-signed-tree-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get("source_transparency_log_signed_tree_head_records") or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "value_revocation_root_freshness_timestamp_expiry_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_expected_source_cross_binding_operator_signature_records"
        )
        or []
    ]
    source_root_records = [
        record.get("source_anti_replay_ledger_append_only_sequence_session_root") or {}
        for record in verifier_records
    ]
    receipt_signature_records = [
        record.get(
            "receipt_signer_certificate_revocation_root_freshness_authority_signature"
        )
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_hash_bound",
    )
    lint_ready_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready",
    )
    upstream_ready_count = _sum(
        upstream_packet_records,
        "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_ready",
    )
    source_required = _required_count(source_records)
    source_present_count = _count(
        source_records, "source_transparency_log_signed_tree_head_present"
    )
    source_hash_count = _count(
        source_records, "source_transparency_log_signed_tree_head_hash_bound"
    )
    source_signature_count = _count(
        source_records, "source_transparency_log_signed_tree_head_signature_valid"
    )
    source_consistent_count = _count(
        source_records, "source_transparency_log_signed_tree_head_checkpoint_consistent"
    )
    source_ready_count = _count(
        source_records, "source_transparency_log_signed_tree_head_ready"
    )
    value_required = _required_count(value_records)
    value_timestamp_count = _count(
        value_records, "value_revocation_root_freshness_timestamp_present"
    )
    value_timestamp_valid_count = _count(
        value_records, "value_revocation_root_freshness_timestamp_valid"
    )
    value_expiry_count = _count(
        value_records, "value_revocation_root_freshness_expiry_present"
    )
    value_expiry_valid_count = _count(
        value_records, "value_revocation_root_freshness_expiry_valid"
    )
    value_ready_count = _count(
        value_records, "value_revocation_root_freshness_timestamp_expiry_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_signature_count = _count(
        checksum_records,
        "checksum_expected_source_cross_binding_operator_signature_present",
    )
    checksum_signature_valid_count = _count(
        checksum_records,
        "checksum_expected_source_cross_binding_operator_signature_valid",
    )
    checksum_identity_count = _count(
        checksum_records,
        "checksum_expected_source_cross_binding_operator_identity_bound",
    )
    checksum_hash_count = _count(
        checksum_records,
        "checksum_expected_source_cross_binding_operator_signature_hash_bound",
    )
    checksum_ready_count = _count(
        checksum_records,
        "checksum_expected_source_cross_binding_operator_signature_ready",
    )
    source_root_required = record_count
    source_sequence_count = _sum(
        source_root_records,
        "source_anti_replay_ledger_append_only_sequence_present",
    )
    source_sequence_valid_count = _sum(
        source_root_records,
        "source_anti_replay_ledger_append_only_sequence_valid",
    )
    source_session_root_count = _sum(
        source_root_records,
        "source_anti_replay_ledger_session_root_present",
    )
    source_session_root_valid_count = _sum(
        source_root_records,
        "source_anti_replay_ledger_session_root_valid",
    )
    source_root_ready_count = _sum(
        source_root_records,
        "source_anti_replay_ledger_append_only_sequence_session_root_ready",
    )
    receipt_signature_required = record_count
    receipt_signature_count = _sum(
        receipt_signature_records,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_present",
    )
    receipt_signature_valid_count = _sum(
        receipt_signature_records,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid",
    )
    receipt_identity_count = _sum(
        receipt_signature_records,
        "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound",
    )
    receipt_hash_count = _sum(
        receipt_signature_records,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound",
    )
    receipt_ready_count = _sum(
        receipt_signature_records,
        "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready",
    )
    receipt_performed_count = _sum(receipt_signature_records, "receipt_authorization_performed")
    expected_file_creation_count = _sum(
        verifier_records, "expected_packet_file_creation_performed"
    )
    receipt_creation_count = _sum(verifier_records, "redrive_receipt_creation_performed")
    evidence_release_count = _sum(verifier_records, "evidence_release_performed")
    promoted_count = _sum(verifier_records, "repair_evidence_promoted")
    closure_count = _sum(verifier_records, "request_closure_performed")
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_root_ready_count == source_root_required
        and receipt_ready_count == receipt_signature_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_merkle_freshness_ledger_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_merkle_freshness_ledger_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_transparency_log_signed_tree_heads_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} signed_tree_heads={source_present_count} signatures={source_signature_count}",
    )
    _add_check(
        checks,
        "value_revocation_root_freshness_timestamp_expiry_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} timestamps={value_timestamp_count} expiry={value_expiry_count}",
    )
    _add_check(
        checks,
        "checksum_expected_source_cross_binding_operator_signatures_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} signatures={checksum_signature_count} identity={checksum_identity_count}",
    )
    _add_check(
        checks,
        "source_anti_replay_ledger_append_only_sequence_session_roots_ready",
        source_root_required > 0 and source_root_ready_count == source_root_required,
        f"ready={source_root_ready_count}/{source_root_required} sequence={source_sequence_count} session_root={source_session_root_count}",
    )
    _add_check(
        checks,
        "receipt_signer_certificate_revocation_root_freshness_authority_signatures_ready",
        receipt_signature_required > 0
        and receipt_ready_count == receipt_signature_required,
        f"ready={receipt_ready_count}/{receipt_signature_required} signatures={receipt_signature_count} identity={receipt_identity_count}",
    )
    _add_check(
        checks,
        "all_request_payload_signed_tree_head_expiry_signature_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_signed_tree_head_expiry_signature_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_SIGNED_TREE_HEAD_EXPIRY_SIGNATURE_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_SIGNED_TREE_HEAD_EXPIRY_SIGNATURE_UPSTREAM_LINT"
    elif (
        source_present_count != source_required
        or source_hash_count != source_required
        or source_signature_count != source_required
        or source_consistent_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_TRANSPARENCY_LOG_SIGNED_TREE_HEAD_MISSING"
    elif (
        value_timestamp_count != value_required
        or value_timestamp_valid_count != value_required
        or value_expiry_count != value_required
        or value_expiry_valid_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_REVOCATION_ROOT_FRESHNESS_TIMESTAMP_EXPIRY_MISSING"
    elif (
        checksum_signature_count != checksum_required
        or checksum_signature_valid_count != checksum_required
        or checksum_identity_count != checksum_required
        or checksum_hash_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_EXPECTED_SOURCE_CROSS_BINDING_OPERATOR_SIGNATURE_MISSING"
    elif (
        source_sequence_count != source_root_required
        or source_sequence_valid_count != source_root_required
        or source_session_root_count != source_root_required
        or source_session_root_valid_count != source_root_required
        or source_root_ready_count != source_root_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_ANTI_REPLAY_LEDGER_APPEND_ONLY_SEQUENCE_SESSION_ROOT_MISSING"
    elif (
        receipt_signature_count != receipt_signature_required
        or receipt_signature_valid_count != receipt_signature_required
        or receipt_identity_count != receipt_signature_required
        or receipt_hash_count != receipt_signature_required
        or receipt_ready_count != receipt_signature_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_SIGNER_CERTIFICATE_REVOCATION_ROOT_FRESHNESS_AUTHORITY_SIGNATURE_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_SIGNED_TREE_HEAD_EXPIRY_SIGNATURE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_SIGNED_TREE_HEAD_EXPIRY_SIGNATURE_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_SIGNED_TREE_HEAD_EXPIRY_SIGNATURE_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_SIGNED_TREE_HEAD_EXPIRY_SIGNATURE_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_merkle_freshness_ledger_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_lint_ready_count": lint_ready_count,
            "upstream_payload_merkle_freshness_ledger_ready_count": upstream_ready_count,
            "upstream_payload_merkle_freshness_ledger_blocked_count": record_count - upstream_ready_count,
            "source_transparency_log_signed_tree_head_required_count": source_required,
            "source_transparency_log_signed_tree_head_present_count": source_present_count,
            "source_transparency_log_signed_tree_head_hash_bound_count": source_hash_count,
            "source_transparency_log_signed_tree_head_signature_valid_count": source_signature_count,
            "source_transparency_log_signed_tree_head_checkpoint_consistent_count": source_consistent_count,
            "source_transparency_log_signed_tree_head_ready_count": source_ready_count,
            "value_revocation_root_freshness_timestamp_expiry_required_count": value_required,
            "value_revocation_root_freshness_timestamp_present_count": value_timestamp_count,
            "value_revocation_root_freshness_timestamp_valid_count": value_timestamp_valid_count,
            "value_revocation_root_freshness_expiry_present_count": value_expiry_count,
            "value_revocation_root_freshness_expiry_valid_count": value_expiry_valid_count,
            "value_revocation_root_freshness_timestamp_expiry_ready_count": value_ready_count,
            "checksum_expected_source_cross_binding_operator_signature_required_count": checksum_required,
            "checksum_expected_source_cross_binding_operator_signature_present_count": checksum_signature_count,
            "checksum_expected_source_cross_binding_operator_signature_valid_count": checksum_signature_valid_count,
            "checksum_expected_source_cross_binding_operator_identity_bound_count": checksum_identity_count,
            "checksum_expected_source_cross_binding_operator_signature_hash_bound_count": checksum_hash_count,
            "checksum_expected_source_cross_binding_operator_signature_ready_count": checksum_ready_count,
            "source_anti_replay_ledger_append_only_sequence_session_root_required_count": source_root_required,
            "source_anti_replay_ledger_append_only_sequence_present_count": source_sequence_count,
            "source_anti_replay_ledger_append_only_sequence_valid_count": source_sequence_valid_count,
            "source_anti_replay_ledger_session_root_present_count": source_session_root_count,
            "source_anti_replay_ledger_session_root_valid_count": source_session_root_valid_count,
            "source_anti_replay_ledger_append_only_sequence_session_root_ready_count": source_root_ready_count,
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_required_count": receipt_signature_required,
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_present_count": receipt_signature_count,
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_valid_count": receipt_signature_valid_count,
            "receipt_signer_certificate_revocation_root_freshness_authority_identity_bound_count": receipt_identity_count,
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_hash_bound_count": receipt_hash_count,
            "receipt_signer_certificate_revocation_root_freshness_authority_signature_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source transparency-log signed tree heads, value revocation root freshness timestamps/expiry windows, checksum cross-binding operator signatures, source append-only ledger session roots, and receipt revocation root freshness authority signatures.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Signed Tree Head Expiry Signature Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_signed_tree_head_expiry_signature_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
