"""Human-input artifact source/value payload transparency/revocation replay verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-transparency-revocation-replay-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_count",
    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready_count",
    "upstream_payload_trust_root_attestation_ready_count",
    "upstream_payload_trust_root_attestation_blocked_count",
    "source_validator_public_key_signature_transparency_log_required_count",
    "source_validator_public_key_signature_transparency_log_present_count",
    "source_validator_public_key_signature_transparency_log_hash_bound_count",
    "source_validator_public_key_signature_transparency_inclusion_verified_count",
    "source_validator_public_key_signature_transparency_log_ready_count",
    "value_trust_chain_digest_revocation_expiry_window_required_count",
    "value_trust_chain_digest_revocation_status_present_count",
    "value_trust_chain_digest_not_revoked_count",
    "value_trust_chain_digest_expiry_window_present_count",
    "value_trust_chain_digest_expiry_window_valid_count",
    "value_trust_chain_digest_revocation_expiry_ready_count",
    "checksum_operator_attestation_public_key_trust_payload_digest_required_count",
    "checksum_operator_attestation_public_key_trust_present_count",
    "checksum_operator_attestation_public_key_trust_hash_bound_count",
    "checksum_operator_attestation_payload_digest_present_count",
    "checksum_operator_attestation_payload_digest_sha_match_count",
    "checksum_operator_attestation_public_key_trust_payload_digest_ready_count",
    "source_replay_guard_nonce_session_binding_required_count",
    "source_replay_guard_nonce_present_count",
    "source_replay_guard_nonce_unique_count",
    "source_replay_guard_session_binding_present_count",
    "source_replay_guard_session_binding_valid_count",
    "source_replay_guard_nonce_session_binding_ready_count",
    "receipt_trust_root_digest_revocation_authorization_signer_binding_required_count",
    "receipt_trust_root_digest_revocation_status_present_count",
    "receipt_trust_root_digest_not_revoked_count",
    "receipt_authorization_signer_binding_present_count",
    "receipt_authorization_signer_binding_valid_count",
    "receipt_trust_root_revocation_authorization_signer_binding_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _source_transparency_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_validator_operator_public_key_fingerprint_schema_binding_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_binding_path = (
            item.get(
                "expected_source_validator_operator_public_key_fingerprint_schema_binding_path"
            )
            or ""
        )
        expected_log_path = (
            item.get("expected_source_validator_public_key_signature_transparency_log_path")
            or _sidecar(expected_binding_path, ".signature-transparency-log.json")
        )
        upstream_ready = bool(
            item.get(
                "source_validator_operator_public_key_fingerprint_schema_binding_ready"
            )
        )
        log_present = bool(
            item.get("source_validator_public_key_signature_transparency_log_present")
        )
        log_hash = bool(
            item.get("source_validator_public_key_signature_transparency_log_hash_bound")
        )
        inclusion = bool(
            item.get(
                "source_validator_public_key_signature_transparency_inclusion_verified"
            )
        )
        template_verified = bool(
            expected_binding_path
            and expected_log_path
            and str(expected_binding_path).endswith(".json")
            and str(expected_log_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("source_validator_operator_public_key_fingerprint_present")
            and item.get("source_validator_operator_public_key_fingerprint_hash_bound")
            and item.get("source_validator_operator_schema_binding_present")
            and item.get("source_validator_operator_schema_binding_valid")
            and log_present
            and log_hash
            and inclusion
        )
        payload = {
            "field": field,
            "expected_source_validator_operator_public_key_fingerprint_schema_binding_path": expected_binding_path,
            "expected_source_validator_public_key_signature_transparency_log_path": expected_log_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "source_validator_public_key_signature_transparency_log_verifier_id": (
                    f"referee-repair-source-transparency-{record_sha[:16]}"
                ),
                "source_validator_public_key_signature_transparency_log_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_validator_operator_public_key_fingerprint_schema_binding_path": expected_binding_path,
                "expected_source_validator_public_key_signature_transparency_log_path": expected_log_path,
                "source_validator_public_key_signature_transparency_log_template_verified": template_verified,
                "source_validator_operator_public_key_fingerprint_present": bool(
                    item.get("source_validator_operator_public_key_fingerprint_present")
                ),
                "source_validator_operator_public_key_fingerprint_hash_bound": bool(
                    item.get("source_validator_operator_public_key_fingerprint_hash_bound")
                ),
                "source_validator_operator_schema_binding_present": bool(
                    item.get("source_validator_operator_schema_binding_present")
                ),
                "source_validator_operator_schema_binding_valid": bool(
                    item.get("source_validator_operator_schema_binding_valid")
                ),
                "source_validator_public_key_signature_transparency_log_present": log_present,
                "source_validator_public_key_signature_transparency_log_hash_bound": log_hash,
                "source_validator_public_key_signature_transparency_inclusion_verified": inclusion,
                "source_validator_public_key_signature_transparency_log_ready": ready,
                "upstream_source_validator_operator_public_key_fingerprint_schema_binding_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_revocation_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_issuer_root_trust_chain_signature_digest_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_digest_path = (
            item.get("expected_value_issuer_root_trust_chain_signature_digest_path")
            or ""
        )
        expected_revocation_path = (
            item.get("expected_value_trust_chain_digest_revocation_expiry_window_path")
            or _sidecar(expected_digest_path, ".revocation-expiry-window.json")
        )
        upstream_ready = bool(
            item.get("value_issuer_root_trust_chain_signature_digest_ready")
        )
        revocation = bool(item.get("value_trust_chain_digest_revocation_status_present"))
        not_revoked = bool(item.get("value_trust_chain_digest_not_revoked"))
        expiry = bool(item.get("value_trust_chain_digest_expiry_window_present"))
        expiry_valid = bool(item.get("value_trust_chain_digest_expiry_window_valid"))
        template_verified = bool(
            expected_digest_path
            and expected_revocation_path
            and str(expected_digest_path).endswith(".json")
            and str(expected_revocation_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("value_issuer_root_trust_chain_signature_present")
            and item.get("value_issuer_root_trust_chain_signature_digest_present")
            and item.get("value_issuer_root_trust_chain_signature_digest_sha_match")
            and item.get("value_issuer_root_trust_chain_signature_digest_hash_bound")
            and revocation
            and not_revoked
            and expiry
            and expiry_valid
        )
        payload = {
            "field": field,
            "expected_value_issuer_root_trust_chain_signature_digest_path": expected_digest_path,
            "expected_value_trust_chain_digest_revocation_expiry_window_path": expected_revocation_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "value_trust_chain_digest_revocation_expiry_window_verifier_id": (
                    f"referee-repair-value-revocation-{record_sha[:16]}"
                ),
                "value_trust_chain_digest_revocation_expiry_window_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_issuer_root_trust_chain_signature_digest_path": expected_digest_path,
                "expected_value_trust_chain_digest_revocation_expiry_window_path": expected_revocation_path,
                "value_trust_chain_digest_revocation_expiry_window_template_verified": template_verified,
                "value_issuer_root_trust_chain_signature_present": bool(
                    item.get("value_issuer_root_trust_chain_signature_present")
                ),
                "value_issuer_root_trust_chain_signature_digest_present": bool(
                    item.get("value_issuer_root_trust_chain_signature_digest_present")
                ),
                "value_issuer_root_trust_chain_signature_digest_sha_match": bool(
                    item.get("value_issuer_root_trust_chain_signature_digest_sha_match")
                ),
                "value_issuer_root_trust_chain_signature_digest_hash_bound": bool(
                    item.get("value_issuer_root_trust_chain_signature_digest_hash_bound")
                ),
                "value_trust_chain_digest_revocation_status_present": revocation,
                "value_trust_chain_digest_not_revoked": not_revoked,
                "value_trust_chain_digest_expiry_window_present": expiry,
                "value_trust_chain_digest_expiry_window_valid": expiry_valid,
                "value_trust_chain_digest_revocation_expiry_ready": ready,
                "upstream_value_issuer_root_trust_chain_signature_digest_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_payload_trust_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_expected_source_digest_chain_operator_attestation_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_attestation_path = (
            item.get("expected_checksum_expected_source_digest_chain_operator_attestation_path")
            or ""
        )
        expected_trust_path = (
            item.get(
                "expected_checksum_operator_attestation_public_key_trust_payload_digest_path"
            )
            or _sidecar(
                expected_attestation_path,
                ".public-key-trust-payload-digest.json",
            )
        )
        upstream_ready = bool(
            item.get("checksum_expected_source_digest_chain_operator_attestation_ready")
        )
        public_key_trust = bool(
            item.get("checksum_operator_attestation_public_key_trust_present")
        )
        public_key_hash = bool(
            item.get("checksum_operator_attestation_public_key_trust_hash_bound")
        )
        payload_digest = bool(
            item.get("checksum_operator_attestation_payload_digest_present")
        )
        payload_sha_match = bool(
            item.get("checksum_operator_attestation_payload_digest_sha_match")
        )
        template_verified = bool(
            expected_attestation_path
            and expected_trust_path
            and str(expected_attestation_path).endswith(".json")
            and str(expected_trust_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("checksum_expected_source_digest_chain_operator_attestation_present")
            and item.get(
                "checksum_expected_source_digest_chain_operator_attestation_signature_valid"
            )
            and item.get(
                "checksum_expected_source_digest_chain_operator_attestation_hash_bound"
            )
            and public_key_trust
            and public_key_hash
            and payload_digest
            and payload_sha_match
        )
        payload = {
            "field": field,
            "expected_checksum_expected_source_digest_chain_operator_attestation_path": expected_attestation_path,
            "expected_checksum_operator_attestation_public_key_trust_payload_digest_path": expected_trust_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "checksum_operator_attestation_public_key_trust_payload_digest_verifier_id": (
                    f"referee-repair-checksum-payload-trust-{record_sha[:16]}"
                ),
                "checksum_operator_attestation_public_key_trust_payload_digest_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_expected_source_digest_chain_operator_attestation_path": expected_attestation_path,
                "expected_checksum_operator_attestation_public_key_trust_payload_digest_path": expected_trust_path,
                "checksum_operator_attestation_public_key_trust_payload_digest_template_verified": template_verified,
                "checksum_expected_source_digest_chain_operator_attestation_present": bool(
                    item.get("checksum_expected_source_digest_chain_operator_attestation_present")
                ),
                "checksum_expected_source_digest_chain_operator_attestation_signature_valid": bool(
                    item.get(
                        "checksum_expected_source_digest_chain_operator_attestation_signature_valid"
                    )
                ),
                "checksum_expected_source_digest_chain_operator_attestation_hash_bound": bool(
                    item.get(
                        "checksum_expected_source_digest_chain_operator_attestation_hash_bound"
                    )
                ),
                "checksum_operator_attestation_public_key_trust_present": public_key_trust,
                "checksum_operator_attestation_public_key_trust_hash_bound": public_key_hash,
                "checksum_operator_attestation_payload_digest_present": payload_digest,
                "checksum_operator_attestation_payload_digest_sha_match": payload_sha_match,
                "checksum_operator_attestation_public_key_trust_payload_digest_ready": ready,
                "upstream_checksum_expected_source_digest_chain_operator_attestation_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_nonce_session_binding(record, payload_sha):
    source = dict(record.get("source_quarantine_signature_timestamp_replay_guard") or {})
    expected_guard_path = (
        source.get("expected_source_quarantine_signature_timestamp_replay_guard_path") or ""
    )
    expected_binding_path = (
        source.get("expected_source_replay_guard_nonce_session_binding_path")
        or _sidecar(expected_guard_path, ".nonce-session-binding.json")
    )
    upstream_ready = bool(
        source.get("source_quarantine_signature_timestamp_replay_guard_ready")
    )
    nonce = bool(source.get("source_replay_guard_nonce_present"))
    nonce_unique = bool(source.get("source_replay_guard_nonce_unique"))
    session = bool(source.get("source_replay_guard_session_binding_present"))
    session_valid = bool(source.get("source_replay_guard_session_binding_valid"))
    template_verified = bool(
        expected_guard_path
        and expected_binding_path
        and str(expected_guard_path).endswith(".json")
        and str(expected_binding_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and source.get("source_quarantine_signature_timestamp_present")
        and source.get("source_quarantine_signature_timestamp_monotonic")
        and source.get("source_quarantine_signature_replay_guard_present")
        and source.get("source_quarantine_signature_replay_guard_valid")
        and nonce
        and nonce_unique
        and session
        and session_valid
    )
    return {
        "source_replay_guard_nonce_session_binding_verifier_id": (
            f"referee-repair-source-nonce-session-{payload_sha[:16]}"
        ),
        "expected_source_quarantine_signature_timestamp_replay_guard_path": expected_guard_path,
        "expected_source_replay_guard_nonce_session_binding_path": expected_binding_path,
        "source_replay_guard_nonce_session_binding_template_verified": template_verified,
        "source_quarantine_signature_timestamp_present": bool(
            source.get("source_quarantine_signature_timestamp_present")
        ),
        "source_quarantine_signature_timestamp_monotonic": bool(
            source.get("source_quarantine_signature_timestamp_monotonic")
        ),
        "source_quarantine_signature_replay_guard_present": bool(
            source.get("source_quarantine_signature_replay_guard_present")
        ),
        "source_quarantine_signature_replay_guard_valid": bool(
            source.get("source_quarantine_signature_replay_guard_valid")
        ),
        "source_replay_guard_nonce_present": nonce,
        "source_replay_guard_nonce_unique": nonce_unique,
        "source_replay_guard_session_binding_present": session,
        "source_replay_guard_session_binding_valid": session_valid,
        "source_replay_guard_nonce_session_binding_ready": ready,
        "upstream_source_quarantine_signature_timestamp_replay_guard_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_revocation_signer_binding(record, payload_sha):
    receipt = dict(record.get("receipt_authorization_chain_public_key_trust_root_digest") or {})
    expected_trust_root_path = (
        receipt.get("expected_receipt_authorization_chain_public_key_trust_root_digest_path")
        or ""
    )
    expected_binding_path = (
        receipt.get(
            "expected_receipt_trust_root_digest_revocation_authorization_signer_binding_path"
        )
        or _sidecar(expected_trust_root_path, ".revocation-signer-binding.json")
    )
    upstream_ready = bool(
        receipt.get("receipt_authorization_chain_public_key_trust_root_digest_ready")
    )
    revocation = bool(
        receipt.get("receipt_trust_root_digest_revocation_status_present")
    )
    not_revoked = bool(receipt.get("receipt_trust_root_digest_not_revoked"))
    signer = bool(receipt.get("receipt_authorization_signer_binding_present"))
    signer_valid = bool(receipt.get("receipt_authorization_signer_binding_valid"))
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_trust_root_path
        and expected_binding_path
        and str(expected_trust_root_path).endswith(".json")
        and str(expected_binding_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and receipt.get("receipt_authorization_chain_public_key_trust_present")
        and receipt.get("receipt_authorization_chain_public_key_trust_hash_bound")
        and receipt.get("receipt_authorization_chain_root_digest_present")
        and receipt.get("receipt_authorization_chain_root_digest_sha_match")
        and revocation
        and not_revoked
        and signer
        and signer_valid
        and not performed
    )
    return {
        "receipt_trust_root_digest_revocation_authorization_signer_binding_verifier_id": (
            f"referee-repair-receipt-signer-binding-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_chain_public_key_trust_root_digest_path": expected_trust_root_path,
        "expected_receipt_trust_root_digest_revocation_authorization_signer_binding_path": expected_binding_path,
        "receipt_trust_root_digest_revocation_authorization_signer_binding_template_verified": template_verified,
        "receipt_authorization_chain_public_key_trust_present": bool(
            receipt.get("receipt_authorization_chain_public_key_trust_present")
        ),
        "receipt_authorization_chain_public_key_trust_hash_bound": bool(
            receipt.get("receipt_authorization_chain_public_key_trust_hash_bound")
        ),
        "receipt_authorization_chain_root_digest_present": bool(
            receipt.get("receipt_authorization_chain_root_digest_present")
        ),
        "receipt_authorization_chain_root_digest_sha_match": bool(
            receipt.get("receipt_authorization_chain_root_digest_sha_match")
        ),
        "receipt_trust_root_digest_revocation_status_present": revocation,
        "receipt_trust_root_digest_not_revoked": not_revoked,
        "receipt_authorization_signer_binding_present": signer,
        "receipt_authorization_signer_binding_valid": signer_valid,
        "receipt_trust_root_revocation_authorization_signer_binding_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_authorization_chain_public_key_trust_root_digest_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_records = _source_transparency_records(packet_record, payload_sha)
    value_records = _value_revocation_records(packet_record, payload_sha)
    checksum_records = _checksum_payload_trust_records(packet_record, payload_sha)
    source_binding = _source_nonce_session_binding(packet_record, payload_sha)
    receipt_binding = _receipt_revocation_signer_binding(packet_record, payload_sha)
    source_required = _required_count(source_records)
    source_ready = _count(
        source_records, "source_validator_public_key_signature_transparency_log_ready"
    )
    value_required = _required_count(value_records)
    value_ready = _count(value_records, "value_trust_chain_digest_revocation_expiry_ready")
    checksum_required = _required_count(checksum_records)
    checksum_ready = _count(
        checksum_records,
        "checksum_operator_attestation_public_key_trust_payload_digest_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_binding.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_binding.get("source_replay_guard_nonce_session_binding_ready")
        and receipt_binding.get(
            "receipt_trust_root_revocation_authorization_signer_binding_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append("source_validator_public_key_signature_transparency_log_missing")
    if value_ready != value_required:
        blockers.append("value_trust_chain_digest_revocation_expiry_window_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_operator_attestation_public_key_trust_payload_digest_missing")
    if not source_binding.get("source_replay_guard_nonce_session_binding_ready"):
        blockers.append("source_replay_guard_nonce_session_binding_missing")
    if not receipt_binding.get(
        "receipt_trust_root_revocation_authorization_signer_binding_ready"
    ):
        blockers.append("receipt_trust_root_revocation_authorization_signer_binding_missing")
    if consumable:
        blockers.append("payload_transparency_revocation_replay_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_id": (
            f"referee-repair-human-input-source-value-payload-transparency-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256"
            )
            or ""
        ),
        "source_validator_public_key_signature_transparency_log_records": source_records,
        "source_validator_public_key_signature_transparency_log_required_count": source_required,
        "source_validator_public_key_signature_transparency_log_ready_count": source_ready,
        "value_trust_chain_digest_revocation_expiry_window_records": value_records,
        "value_trust_chain_digest_revocation_expiry_window_required_count": value_required,
        "value_trust_chain_digest_revocation_expiry_window_ready_count": value_ready,
        "checksum_operator_attestation_public_key_trust_payload_digest_records": checksum_records,
        "checksum_operator_attestation_public_key_trust_payload_digest_required_count": checksum_required,
        "checksum_operator_attestation_public_key_trust_payload_digest_ready_count": checksum_ready,
        "source_replay_guard_nonce_session_binding": source_binding,
        "receipt_trust_root_digest_revocation_authorization_signer_binding": receipt_binding,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "transparency/revocation/replay verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source signature-transparency logs, value revocation/expiry windows, checksum attestation public-key trust payload digests, source nonce/session replay guards, and receipt revocation/signer bindings"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_id": (
            f"referee-repair-request-human-input-source-value-payload-transparency-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _sum(records, key):
    return sum(1 for item in records if item.get(key))


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_validator_public_key_signature_transparency_log_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get(
            "value_trust_chain_digest_revocation_expiry_window_records"
        )
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_operator_attestation_public_key_trust_payload_digest_records"
        )
        or []
    ]
    source_binding_records = [
        record.get("source_replay_guard_nonce_session_binding") or {}
        for record in verifier_records
    ]
    receipt_binding_records = [
        record.get("receipt_trust_root_digest_revocation_authorization_signer_binding")
        or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_hash_bound",
    )
    lint_ready_count = _sum(
        verifier_records,
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready",
    )
    upstream_ready_count = _sum(
        upstream_packet_records,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready",
    )
    source_required = _required_count(source_records)
    source_log_count = _count(
        source_records, "source_validator_public_key_signature_transparency_log_present"
    )
    source_log_hash_count = _count(
        source_records, "source_validator_public_key_signature_transparency_log_hash_bound"
    )
    source_inclusion_count = _count(
        source_records,
        "source_validator_public_key_signature_transparency_inclusion_verified",
    )
    source_ready_count = _count(
        source_records, "source_validator_public_key_signature_transparency_log_ready"
    )
    value_required = _required_count(value_records)
    value_revocation_count = _count(
        value_records, "value_trust_chain_digest_revocation_status_present"
    )
    value_not_revoked_count = _count(
        value_records, "value_trust_chain_digest_not_revoked"
    )
    value_expiry_count = _count(
        value_records, "value_trust_chain_digest_expiry_window_present"
    )
    value_expiry_valid_count = _count(
        value_records, "value_trust_chain_digest_expiry_window_valid"
    )
    value_ready_count = _count(
        value_records, "value_trust_chain_digest_revocation_expiry_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_public_key_count = _count(
        checksum_records, "checksum_operator_attestation_public_key_trust_present"
    )
    checksum_public_key_hash_count = _count(
        checksum_records, "checksum_operator_attestation_public_key_trust_hash_bound"
    )
    checksum_payload_digest_count = _count(
        checksum_records, "checksum_operator_attestation_payload_digest_present"
    )
    checksum_payload_digest_sha_count = _count(
        checksum_records, "checksum_operator_attestation_payload_digest_sha_match"
    )
    checksum_ready_count = _count(
        checksum_records,
        "checksum_operator_attestation_public_key_trust_payload_digest_ready",
    )
    source_binding_required = record_count
    source_nonce_count = _sum(source_binding_records, "source_replay_guard_nonce_present")
    source_nonce_unique_count = _sum(
        source_binding_records, "source_replay_guard_nonce_unique"
    )
    source_session_count = _sum(
        source_binding_records, "source_replay_guard_session_binding_present"
    )
    source_session_valid_count = _sum(
        source_binding_records, "source_replay_guard_session_binding_valid"
    )
    source_binding_ready_count = _sum(
        source_binding_records, "source_replay_guard_nonce_session_binding_ready"
    )
    receipt_binding_required = record_count
    receipt_revocation_count = _sum(
        receipt_binding_records, "receipt_trust_root_digest_revocation_status_present"
    )
    receipt_not_revoked_count = _sum(
        receipt_binding_records, "receipt_trust_root_digest_not_revoked"
    )
    receipt_signer_count = _sum(
        receipt_binding_records, "receipt_authorization_signer_binding_present"
    )
    receipt_signer_valid_count = _sum(
        receipt_binding_records, "receipt_authorization_signer_binding_valid"
    )
    receipt_ready_count = _sum(
        receipt_binding_records,
        "receipt_trust_root_revocation_authorization_signer_binding_ready",
    )
    receipt_performed_count = _sum(receipt_binding_records, "receipt_authorization_performed")
    expected_file_creation_count = _sum(
        verifier_records, "expected_packet_file_creation_performed"
    )
    receipt_creation_count = _sum(verifier_records, "redrive_receipt_creation_performed")
    evidence_release_count = _sum(verifier_records, "evidence_release_performed")
    promoted_count = _sum(verifier_records, "repair_evidence_promoted")
    closure_count = _sum(verifier_records, "request_closure_performed")
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_binding_ready_count == source_binding_required
        and receipt_ready_count == receipt_binding_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_trust_root_attestation_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_trust_root_attestation_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_validator_public_key_signature_transparency_logs_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} logs={source_log_count} inclusion={source_inclusion_count}",
    )
    _add_check(
        checks,
        "value_trust_chain_digest_revocation_expiry_windows_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} revocation={value_revocation_count} expiry={value_expiry_count}",
    )
    _add_check(
        checks,
        "checksum_operator_attestation_public_key_trust_payload_digests_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} public_key_trust={checksum_public_key_count} payload_digest={checksum_payload_digest_count}",
    )
    _add_check(
        checks,
        "source_replay_guard_nonce_session_bindings_ready",
        source_binding_required > 0
        and source_binding_ready_count == source_binding_required,
        f"ready={source_binding_ready_count}/{source_binding_required} nonce={source_nonce_count} session={source_session_count}",
    )
    _add_check(
        checks,
        "receipt_trust_root_revocation_authorization_signer_bindings_ready",
        receipt_binding_required > 0 and receipt_ready_count == receipt_binding_required,
        f"ready={receipt_ready_count}/{receipt_binding_required} revocation={receipt_revocation_count} signer={receipt_signer_count}",
    )
    _add_check(
        checks,
        "all_request_payload_transparency_revocation_replay_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_transparency_revocation_replay_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRANSPARENCY_REVOCATION_REPLAY_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRANSPARENCY_REVOCATION_REPLAY_UPSTREAM_LINT"
    elif (
        source_log_count != source_required
        or source_log_hash_count != source_required
        or source_inclusion_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_VALIDATOR_PUBLIC_KEY_SIGNATURE_TRANSPARENCY_LOG_MISSING"
    elif (
        value_revocation_count != value_required
        or value_not_revoked_count != value_required
        or value_expiry_count != value_required
        or value_expiry_valid_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_TRUST_CHAIN_DIGEST_REVOCATION_EXPIRY_WINDOW_MISSING"
    elif (
        checksum_public_key_count != checksum_required
        or checksum_public_key_hash_count != checksum_required
        or checksum_payload_digest_count != checksum_required
        or checksum_payload_digest_sha_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_OPERATOR_ATTESTATION_PUBLIC_KEY_TRUST_PAYLOAD_DIGEST_MISSING"
    elif (
        source_nonce_count != source_binding_required
        or source_nonce_unique_count != source_binding_required
        or source_session_count != source_binding_required
        or source_session_valid_count != source_binding_required
        or source_binding_ready_count != source_binding_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_REPLAY_GUARD_NONCE_SESSION_BINDING_MISSING"
    elif (
        receipt_revocation_count != receipt_binding_required
        or receipt_not_revoked_count != receipt_binding_required
        or receipt_signer_count != receipt_binding_required
        or receipt_signer_valid_count != receipt_binding_required
        or receipt_ready_count != receipt_binding_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_TRUST_ROOT_DIGEST_REVOCATION_AUTHORIZATION_SIGNER_BINDING_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRANSPARENCY_REVOCATION_REPLAY_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRANSPARENCY_REVOCATION_REPLAY_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRANSPARENCY_REVOCATION_REPLAY_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_TRANSPARENCY_REVOCATION_REPLAY_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_lint_ready_count": lint_ready_count,
            "upstream_payload_trust_root_attestation_ready_count": upstream_ready_count,
            "upstream_payload_trust_root_attestation_blocked_count": record_count - upstream_ready_count,
            "source_validator_public_key_signature_transparency_log_required_count": source_required,
            "source_validator_public_key_signature_transparency_log_present_count": source_log_count,
            "source_validator_public_key_signature_transparency_log_hash_bound_count": source_log_hash_count,
            "source_validator_public_key_signature_transparency_inclusion_verified_count": source_inclusion_count,
            "source_validator_public_key_signature_transparency_log_ready_count": source_ready_count,
            "value_trust_chain_digest_revocation_expiry_window_required_count": value_required,
            "value_trust_chain_digest_revocation_status_present_count": value_revocation_count,
            "value_trust_chain_digest_not_revoked_count": value_not_revoked_count,
            "value_trust_chain_digest_expiry_window_present_count": value_expiry_count,
            "value_trust_chain_digest_expiry_window_valid_count": value_expiry_valid_count,
            "value_trust_chain_digest_revocation_expiry_ready_count": value_ready_count,
            "checksum_operator_attestation_public_key_trust_payload_digest_required_count": checksum_required,
            "checksum_operator_attestation_public_key_trust_present_count": checksum_public_key_count,
            "checksum_operator_attestation_public_key_trust_hash_bound_count": checksum_public_key_hash_count,
            "checksum_operator_attestation_payload_digest_present_count": checksum_payload_digest_count,
            "checksum_operator_attestation_payload_digest_sha_match_count": checksum_payload_digest_sha_count,
            "checksum_operator_attestation_public_key_trust_payload_digest_ready_count": checksum_ready_count,
            "source_replay_guard_nonce_session_binding_required_count": source_binding_required,
            "source_replay_guard_nonce_present_count": source_nonce_count,
            "source_replay_guard_nonce_unique_count": source_nonce_unique_count,
            "source_replay_guard_session_binding_present_count": source_session_count,
            "source_replay_guard_session_binding_valid_count": source_session_valid_count,
            "source_replay_guard_nonce_session_binding_ready_count": source_binding_ready_count,
            "receipt_trust_root_digest_revocation_authorization_signer_binding_required_count": receipt_binding_required,
            "receipt_trust_root_digest_revocation_status_present_count": receipt_revocation_count,
            "receipt_trust_root_digest_not_revoked_count": receipt_not_revoked_count,
            "receipt_authorization_signer_binding_present_count": receipt_signer_count,
            "receipt_authorization_signer_binding_valid_count": receipt_signer_valid_count,
            "receipt_trust_root_revocation_authorization_signer_binding_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source validator signature-transparency logs, value trust-chain digest revocation/expiry windows, checksum operator-attestation public-key trust payload digests, source replay guard nonce/session bindings, and receipt trust-root revocation/authorization signer bindings.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Transparency Revocation Replay Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_transparency_revocation_replay_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
