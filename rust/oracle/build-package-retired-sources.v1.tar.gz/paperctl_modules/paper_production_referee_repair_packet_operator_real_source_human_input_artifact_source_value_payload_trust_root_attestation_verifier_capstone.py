"""Human-input artifact source/value payload trust-root attestation verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-input-"
    "artifact-source-value-payload-trust-root-attestation-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_record_count",
    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_record_count",
    "hash_bound_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_count",
    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready_count",
    "upstream_payload_identity_signature_chain_ready_count",
    "upstream_payload_identity_signature_chain_blocked_count",
    "source_validator_operator_public_key_fingerprint_schema_binding_required_count",
    "source_validator_operator_public_key_fingerprint_present_count",
    "source_validator_operator_public_key_fingerprint_hash_bound_count",
    "source_validator_operator_schema_binding_present_count",
    "source_validator_operator_schema_binding_valid_count",
    "source_validator_operator_public_key_fingerprint_schema_binding_ready_count",
    "value_issuer_root_trust_chain_signature_digest_required_count",
    "value_issuer_root_trust_chain_signature_present_count",
    "value_issuer_root_trust_chain_signature_digest_present_count",
    "value_issuer_root_trust_chain_signature_digest_sha_match_count",
    "value_issuer_root_trust_chain_signature_digest_hash_bound_count",
    "value_issuer_root_trust_chain_signature_digest_ready_count",
    "checksum_expected_source_digest_chain_operator_attestation_required_count",
    "checksum_expected_source_digest_chain_operator_attestation_present_count",
    "checksum_expected_source_digest_chain_operator_attestation_signature_valid_count",
    "checksum_expected_source_digest_chain_operator_attestation_hash_bound_count",
    "checksum_expected_source_digest_chain_operator_attestation_ready_count",
    "source_quarantine_signature_timestamp_replay_guard_required_count",
    "source_quarantine_signature_timestamp_present_count",
    "source_quarantine_signature_timestamp_monotonic_count",
    "source_quarantine_signature_replay_guard_present_count",
    "source_quarantine_signature_replay_guard_valid_count",
    "source_quarantine_signature_timestamp_replay_guard_ready_count",
    "receipt_authorization_chain_public_key_trust_root_digest_required_count",
    "receipt_authorization_chain_public_key_trust_present_count",
    "receipt_authorization_chain_public_key_trust_hash_bound_count",
    "receipt_authorization_chain_root_digest_present_count",
    "receipt_authorization_chain_root_digest_sha_match_count",
    "receipt_authorization_chain_public_key_trust_root_digest_ready_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_record_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready_count",
    "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _sidecar(path, suffix):
    path = str(path or "")
    if path.endswith(".json"):
        return path[:-5] + suffix
    return ""


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _required_count(records):
    return sum(1 for item in records if item.get("required"))


def _count(records, key):
    return sum(1 for item in records if item.get("required") and item.get(key))


def _source_public_key_binding_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "source_provenance_validator_operator_identity_signature_marker_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_signature_path = (
            item.get("expected_source_provenance_validator_operator_identity_signature_marker_path")
            or ""
        )
        expected_binding_path = (
            item.get("expected_source_validator_operator_public_key_fingerprint_schema_binding_path")
            or _sidecar(
                expected_signature_path,
                ".public-key-fingerprint-schema-binding.json",
            )
        )
        upstream_ready = bool(
            item.get("source_provenance_validator_operator_identity_signature_ready")
        )
        fingerprint = bool(
            item.get("source_validator_operator_public_key_fingerprint_present")
        )
        fingerprint_hash = bool(
            item.get("source_validator_operator_public_key_fingerprint_hash_bound")
        )
        schema_binding = bool(
            item.get("source_validator_operator_schema_binding_present")
        )
        schema_valid = bool(item.get("source_validator_operator_schema_binding_valid"))
        template_verified = bool(
            expected_signature_path
            and expected_binding_path
            and str(expected_signature_path).endswith(".json")
            and str(expected_binding_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("source_provenance_validator_operator_identity_present")
            and item.get("source_provenance_validator_operator_identity_hash_bound")
            and item.get("source_provenance_validator_signature_marker_present")
            and item.get("source_provenance_validator_signature_marker_valid")
            and fingerprint
            and fingerprint_hash
            and schema_binding
            and schema_valid
        )
        payload = {
            "field": field,
            "expected_source_provenance_validator_operator_identity_signature_marker_path": expected_signature_path,
            "expected_source_validator_operator_public_key_fingerprint_schema_binding_path": expected_binding_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "source_validator_operator_public_key_fingerprint_schema_binding_verifier_id": (
                    f"referee-repair-source-validator-public-key-{record_sha[:16]}"
                ),
                "source_validator_operator_public_key_fingerprint_schema_binding_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_source_provenance_validator_operator_identity_signature_marker_path": expected_signature_path,
                "expected_source_validator_operator_public_key_fingerprint_schema_binding_path": expected_binding_path,
                "source_validator_operator_public_key_fingerprint_schema_binding_template_verified": template_verified,
                "source_provenance_validator_operator_identity_present": bool(
                    item.get("source_provenance_validator_operator_identity_present")
                ),
                "source_provenance_validator_operator_identity_hash_bound": bool(
                    item.get("source_provenance_validator_operator_identity_hash_bound")
                ),
                "source_provenance_validator_signature_marker_present": bool(
                    item.get("source_provenance_validator_signature_marker_present")
                ),
                "source_provenance_validator_signature_marker_valid": bool(
                    item.get("source_provenance_validator_signature_marker_valid")
                ),
                "source_validator_operator_public_key_fingerprint_present": fingerprint,
                "source_validator_operator_public_key_fingerprint_hash_bound": fingerprint_hash,
                "source_validator_operator_schema_binding_present": schema_binding,
                "source_validator_operator_schema_binding_valid": schema_valid,
                "source_validator_operator_public_key_fingerprint_schema_binding_ready": ready,
                "upstream_source_provenance_validator_operator_identity_signature_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _value_trust_digest_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "value_certificate_chain_issuer_root_identity_hash_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_issuer_root_path = (
            item.get("expected_value_certificate_chain_issuer_root_identity_hash_path")
            or ""
        )
        expected_digest_path = (
            item.get("expected_value_issuer_root_trust_chain_signature_digest_path")
            or _sidecar(expected_issuer_root_path, ".trust-chain-signature-digest.json")
        )
        upstream_ready = bool(item.get("value_certificate_chain_issuer_root_identity_ready"))
        signature = bool(item.get("value_issuer_root_trust_chain_signature_present"))
        digest = bool(
            item.get("value_issuer_root_trust_chain_signature_digest_present")
        )
        digest_sha = bool(
            item.get("value_issuer_root_trust_chain_signature_digest_sha_match")
        )
        digest_hash = bool(
            item.get("value_issuer_root_trust_chain_signature_digest_hash_bound")
        )
        template_verified = bool(
            expected_issuer_root_path
            and expected_digest_path
            and str(expected_issuer_root_path).endswith(".json")
            and str(expected_digest_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("value_certificate_chain_issuer_identity_present")
            and item.get("value_certificate_chain_issuer_identity_hash_bound")
            and item.get("value_certificate_chain_root_identity_present")
            and item.get("value_certificate_chain_root_identity_hash_bound")
            and item.get("value_certificate_chain_issuer_root_identity_hash_verified")
            and signature
            and digest
            and digest_sha
            and digest_hash
        )
        payload = {
            "field": field,
            "expected_value_certificate_chain_issuer_root_identity_hash_path": expected_issuer_root_path,
            "expected_value_issuer_root_trust_chain_signature_digest_path": expected_digest_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "value_issuer_root_trust_chain_signature_digest_verifier_id": (
                    f"referee-repair-value-trust-digest-{record_sha[:16]}"
                ),
                "value_issuer_root_trust_chain_signature_digest_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_value_certificate_chain_issuer_root_identity_hash_path": expected_issuer_root_path,
                "expected_value_issuer_root_trust_chain_signature_digest_path": expected_digest_path,
                "value_issuer_root_trust_chain_signature_digest_template_verified": template_verified,
                "value_certificate_chain_issuer_identity_present": bool(
                    item.get("value_certificate_chain_issuer_identity_present")
                ),
                "value_certificate_chain_issuer_identity_hash_bound": bool(
                    item.get("value_certificate_chain_issuer_identity_hash_bound")
                ),
                "value_certificate_chain_root_identity_present": bool(
                    item.get("value_certificate_chain_root_identity_present")
                ),
                "value_certificate_chain_root_identity_hash_bound": bool(
                    item.get("value_certificate_chain_root_identity_hash_bound")
                ),
                "value_certificate_chain_issuer_root_identity_hash_verified": bool(
                    item.get("value_certificate_chain_issuer_root_identity_hash_verified")
                ),
                "value_issuer_root_trust_chain_signature_present": signature,
                "value_issuer_root_trust_chain_signature_digest_present": digest,
                "value_issuer_root_trust_chain_signature_digest_sha_match": digest_sha,
                "value_issuer_root_trust_chain_signature_digest_hash_bound": digest_hash,
                "value_issuer_root_trust_chain_signature_digest_ready": ready,
                "upstream_value_certificate_chain_issuer_root_identity_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _checksum_operator_attestation_records(packet_record, payload_sha):
    records = []
    for item in packet_record.get(
        "checksum_materialization_expected_source_digest_chain_comparison_records"
    ) or []:
        if not isinstance(item, dict):
            continue
        field = item.get("field") or ""
        required = bool(item.get("required"))
        expected_comparison_path = (
            item.get("expected_checksum_materialization_expected_source_digest_chain_comparison_path")
            or ""
        )
        expected_attestation_path = (
            item.get("expected_checksum_expected_source_digest_chain_operator_attestation_path")
            or _sidecar(expected_comparison_path, ".operator-attestation.json")
        )
        upstream_ready = bool(
            item.get(
                "checksum_materialization_expected_source_digest_chain_comparison_ready"
            )
        )
        attestation = bool(
            item.get("checksum_expected_source_digest_chain_operator_attestation_present")
        )
        signature = bool(
            item.get(
                "checksum_expected_source_digest_chain_operator_attestation_signature_valid"
            )
        )
        attestation_hash = bool(
            item.get(
                "checksum_expected_source_digest_chain_operator_attestation_hash_bound"
            )
        )
        template_verified = bool(
            expected_comparison_path
            and expected_attestation_path
            and str(expected_comparison_path).endswith(".json")
            and str(expected_attestation_path).endswith(".json")
        )
        ready = bool(
            required
            and template_verified
            and upstream_ready
            and item.get("checksum_materialization_expected_digest_chain_present")
            and item.get("checksum_materialization_source_digest_chain_present")
            and item.get("checksum_materialization_expected_source_digest_chain_match")
            and item.get("checksum_materialization_digest_chain_comparison_hash_bound")
            and attestation
            and signature
            and attestation_hash
        )
        payload = {
            "field": field,
            "expected_checksum_materialization_expected_source_digest_chain_comparison_path": expected_comparison_path,
            "expected_checksum_expected_source_digest_chain_operator_attestation_path": expected_attestation_path,
            "parent_payload_sha256": payload_sha,
        }
        record_sha = _sha(payload)
        records.append(
            {
                "checksum_expected_source_digest_chain_operator_attestation_verifier_id": (
                    f"referee-repair-checksum-attestation-{record_sha[:16]}"
                ),
                "checksum_expected_source_digest_chain_operator_attestation_payload_sha256": record_sha,
                "field": field,
                "required": required,
                "expected_checksum_materialization_expected_source_digest_chain_comparison_path": expected_comparison_path,
                "expected_checksum_expected_source_digest_chain_operator_attestation_path": expected_attestation_path,
                "checksum_expected_source_digest_chain_operator_attestation_template_verified": template_verified,
                "checksum_materialization_expected_digest_chain_present": bool(
                    item.get("checksum_materialization_expected_digest_chain_present")
                ),
                "checksum_materialization_source_digest_chain_present": bool(
                    item.get("checksum_materialization_source_digest_chain_present")
                ),
                "checksum_materialization_expected_source_digest_chain_match": bool(
                    item.get("checksum_materialization_expected_source_digest_chain_match")
                ),
                "checksum_materialization_digest_chain_comparison_hash_bound": bool(
                    item.get("checksum_materialization_digest_chain_comparison_hash_bound")
                ),
                "checksum_expected_source_digest_chain_operator_attestation_present": attestation,
                "checksum_expected_source_digest_chain_operator_attestation_signature_valid": signature,
                "checksum_expected_source_digest_chain_operator_attestation_hash_bound": attestation_hash,
                "checksum_expected_source_digest_chain_operator_attestation_ready": ready,
                "upstream_checksum_materialization_expected_source_digest_chain_comparison_ready": upstream_ready,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _source_timestamp_replay_guard(record, payload_sha):
    source = dict(
        record.get("source_attestation_certificate_issuer_quarantine_signature") or {}
    )
    expected_signature_path = (
        source.get("expected_source_attestation_certificate_issuer_quarantine_signature_path")
        or ""
    )
    expected_guard_path = (
        source.get("expected_source_quarantine_signature_timestamp_replay_guard_path")
        or _sidecar(expected_signature_path, ".timestamp-replay-guard.json")
    )
    upstream_ready = bool(
        source.get("source_attestation_certificate_issuer_quarantine_signature_ready")
    )
    timestamp = bool(source.get("source_quarantine_signature_timestamp_present"))
    monotonic = bool(source.get("source_quarantine_signature_timestamp_monotonic"))
    replay_guard = bool(source.get("source_quarantine_signature_replay_guard_present"))
    replay_valid = bool(source.get("source_quarantine_signature_replay_guard_valid"))
    template_verified = bool(
        expected_signature_path
        and expected_guard_path
        and str(expected_signature_path).endswith(".json")
        and str(expected_guard_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and source.get("source_attestation_quarantine_signature_present")
        and source.get("source_attestation_quarantine_signature_valid")
        and timestamp
        and monotonic
        and replay_guard
        and replay_valid
    )
    return {
        "source_quarantine_signature_timestamp_replay_guard_verifier_id": (
            f"referee-repair-source-replay-guard-{payload_sha[:16]}"
        ),
        "expected_source_attestation_certificate_issuer_quarantine_signature_path": expected_signature_path,
        "expected_source_quarantine_signature_timestamp_replay_guard_path": expected_guard_path,
        "source_quarantine_signature_timestamp_replay_guard_template_verified": template_verified,
        "source_attestation_quarantine_signature_present": bool(
            source.get("source_attestation_quarantine_signature_present")
        ),
        "source_attestation_quarantine_signature_valid": bool(
            source.get("source_attestation_quarantine_signature_valid")
        ),
        "source_quarantine_signature_timestamp_present": timestamp,
        "source_quarantine_signature_timestamp_monotonic": monotonic,
        "source_quarantine_signature_replay_guard_present": replay_guard,
        "source_quarantine_signature_replay_guard_valid": replay_valid,
        "source_quarantine_signature_timestamp_replay_guard_ready": ready,
        "upstream_source_attestation_certificate_issuer_quarantine_signature_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _receipt_trust_root_digest(record, payload_sha):
    receipt = dict(
        record.get("receipt_signature_marker_public_identity_certificate_authorization_chain")
        or {}
    )
    expected_authorization_path = (
        receipt.get("expected_receipt_signature_marker_public_identity_certificate_authorization_chain_path")
        or ""
    )
    expected_trust_root_path = (
        receipt.get("expected_receipt_authorization_chain_public_key_trust_root_digest_path")
        or _sidecar(expected_authorization_path, ".public-key-trust-root-digest.json")
    )
    upstream_ready = bool(
        receipt.get(
            "receipt_signature_marker_public_identity_certificate_authorization_chain_ready"
        )
    )
    public_key_trust = bool(
        receipt.get("receipt_authorization_chain_public_key_trust_present")
    )
    public_key_trust_hash = bool(
        receipt.get("receipt_authorization_chain_public_key_trust_hash_bound")
    )
    root_digest = bool(receipt.get("receipt_authorization_chain_root_digest_present"))
    root_digest_sha = bool(
        receipt.get("receipt_authorization_chain_root_digest_sha_match")
    )
    performed = bool(receipt.get("receipt_authorization_performed"))
    template_verified = bool(
        expected_authorization_path
        and expected_trust_root_path
        and str(expected_authorization_path).endswith(".json")
        and str(expected_trust_root_path).endswith(".json")
    )
    ready = bool(
        template_verified
        and upstream_ready
        and receipt.get("receipt_signature_marker_public_identity_certificate_present")
        and receipt.get("receipt_signature_marker_public_identity_certificate_hash_bound")
        and receipt.get("receipt_authorization_chain_present")
        and receipt.get("receipt_authorization_chain_hash_bound")
        and receipt.get(
            "receipt_signature_marker_public_identity_authorization_chain_verified"
        )
        and public_key_trust
        and public_key_trust_hash
        and root_digest
        and root_digest_sha
        and not performed
    )
    return {
        "receipt_authorization_chain_public_key_trust_root_digest_verifier_id": (
            f"referee-repair-receipt-trust-root-{payload_sha[:16]}"
        ),
        "expected_receipt_signature_marker_public_identity_certificate_authorization_chain_path": expected_authorization_path,
        "expected_receipt_authorization_chain_public_key_trust_root_digest_path": expected_trust_root_path,
        "receipt_authorization_chain_public_key_trust_root_digest_template_verified": template_verified,
        "receipt_signature_marker_public_identity_certificate_present": bool(
            receipt.get("receipt_signature_marker_public_identity_certificate_present")
        ),
        "receipt_signature_marker_public_identity_certificate_hash_bound": bool(
            receipt.get("receipt_signature_marker_public_identity_certificate_hash_bound")
        ),
        "receipt_authorization_chain_present": bool(
            receipt.get("receipt_authorization_chain_present")
        ),
        "receipt_authorization_chain_hash_bound": bool(
            receipt.get("receipt_authorization_chain_hash_bound")
        ),
        "receipt_signature_marker_public_identity_authorization_chain_verified": bool(
            receipt.get(
                "receipt_signature_marker_public_identity_authorization_chain_verified"
            )
        ),
        "receipt_authorization_chain_public_key_trust_present": public_key_trust,
        "receipt_authorization_chain_public_key_trust_hash_bound": public_key_trust_hash,
        "receipt_authorization_chain_root_digest_present": root_digest,
        "receipt_authorization_chain_root_digest_sha_match": root_digest_sha,
        "receipt_authorization_chain_public_key_trust_root_digest_ready": ready,
        "receipt_authorization_performed": performed,
        "upstream_receipt_signature_marker_public_identity_certificate_authorization_chain_ready": upstream_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_verifier_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    source_records = _source_public_key_binding_records(packet_record, payload_sha)
    value_records = _value_trust_digest_records(packet_record, payload_sha)
    checksum_records = _checksum_operator_attestation_records(packet_record, payload_sha)
    source_replay_guard = _source_timestamp_replay_guard(packet_record, payload_sha)
    receipt_trust_root = _receipt_trust_root_digest(packet_record, payload_sha)
    source_required = _required_count(source_records)
    source_ready = _count(
        source_records,
        "source_validator_operator_public_key_fingerprint_schema_binding_ready",
    )
    value_required = _required_count(value_records)
    value_ready = _count(
        value_records, "value_issuer_root_trust_chain_signature_digest_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_ready = _count(
        checksum_records,
        "checksum_expected_source_digest_chain_operator_attestation_ready",
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_trust_root.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    hash_bound = bool(
        payload_sha
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_hash_bound"
        )
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready"
        )
        and source_required
        and value_required
        and checksum_required
    )
    ready = bool(
        lint_ready
        and packet_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready"
        )
        and source_required
        and source_ready == source_required
        and value_required
        and value_ready == value_required
        and checksum_required
        and checksum_ready == checksum_required
        and source_replay_guard.get(
            "source_quarantine_signature_timestamp_replay_guard_ready"
        )
        and receipt_trust_root.get(
            "receipt_authorization_chain_public_key_trust_root_digest_ready"
        )
        and not consumable
    )
    blockers = []
    if source_ready != source_required:
        blockers.append(
            "source_validator_operator_public_key_fingerprint_schema_binding_missing"
        )
    if value_ready != value_required:
        blockers.append("value_issuer_root_trust_chain_signature_digest_missing")
    if checksum_ready != checksum_required:
        blockers.append("checksum_expected_source_digest_chain_operator_attestation_missing")
    if not source_replay_guard.get(
        "source_quarantine_signature_timestamp_replay_guard_ready"
    ):
        blockers.append("source_quarantine_signature_timestamp_replay_guard_missing")
    if not receipt_trust_root.get(
        "receipt_authorization_chain_public_key_trust_root_digest_ready"
    ):
        blockers.append("receipt_authorization_chain_public_key_trust_root_digest_missing")
    if consumable:
        blockers.append("payload_trust_root_attestation_action_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_id": (
            f"referee-repair-human-input-source-value-payload-trust-root-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256": payload_sha,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_hash_bound": hash_bound,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready": lint_ready,
        "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256": (
            packet_record.get(
                "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_payload_sha256"
            )
            or ""
        ),
        "source_validator_operator_public_key_fingerprint_schema_binding_records": source_records,
        "source_validator_operator_public_key_fingerprint_schema_binding_required_count": source_required,
        "source_validator_operator_public_key_fingerprint_schema_binding_ready_count": source_ready,
        "value_issuer_root_trust_chain_signature_digest_records": value_records,
        "value_issuer_root_trust_chain_signature_digest_required_count": value_required,
        "value_issuer_root_trust_chain_signature_digest_ready_count": value_ready,
        "checksum_expected_source_digest_chain_operator_attestation_records": checksum_records,
        "checksum_expected_source_digest_chain_operator_attestation_required_count": checksum_required,
        "checksum_expected_source_digest_chain_operator_attestation_ready_count": checksum_ready,
        "source_quarantine_signature_timestamp_replay_guard": source_replay_guard,
        "receipt_authorization_chain_public_key_trust_root_digest": receipt_trust_root,
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready": ready,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_blockers": blockers,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "trust-root attestation verifiers are ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide source validator public-key/schema bindings, value trust-chain signature digests, checksum operator attestations, source timestamp/replay guards, and receipt public-key trust-root digests"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, verifier_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready"
        )
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256s": [
            item.get(
                "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256"
            )
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_id": (
            f"referee-repair-request-human-input-source-value-payload-trust-root-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_payload_sha256": payload_sha,
        "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_hash_bound"
                )
                for item in verifier_records
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready"
                )
                for item in verifier_records
            )
        ),
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_record_count": len(
            verifier_records
        ),
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready_count": sum(
            1
            for item in verifier_records
            if item.get(
                "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready"
            )
        ),
        "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready": ready,
        "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_records": verifier_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_capstone(
    operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_report,
    operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_report
        or {}
    )
    upstream_ref = dict(
        operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_ref
        or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get(
                "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_lint_ready"
            )
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _packet_verifier_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_records"
        )
        or []
    ]
    source_records = [
        item
        for record in verifier_records
        for item in record.get(
            "source_validator_operator_public_key_fingerprint_schema_binding_records"
        )
        or []
    ]
    value_records = [
        item
        for record in verifier_records
        for item in record.get("value_issuer_root_trust_chain_signature_digest_records")
        or []
    ]
    checksum_records = [
        item
        for record in verifier_records
        for item in record.get(
            "checksum_expected_source_digest_chain_operator_attestation_records"
        )
        or []
    ]
    source_replay_records = [
        record.get("source_quarantine_signature_timestamp_replay_guard") or {}
        for record in verifier_records
    ]
    receipt_trust_records = [
        record.get("receipt_authorization_chain_public_key_trust_root_digest") or {}
        for record in verifier_records
    ]
    record_count = len(verifier_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_hash_bound"
        )
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready"
        )
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get(
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_ready"
        )
    )
    source_required = _required_count(source_records)
    source_fingerprint_count = _count(
        source_records, "source_validator_operator_public_key_fingerprint_present"
    )
    source_fingerprint_hash_count = _count(
        source_records, "source_validator_operator_public_key_fingerprint_hash_bound"
    )
    source_schema_binding_count = _count(
        source_records, "source_validator_operator_schema_binding_present"
    )
    source_schema_valid_count = _count(
        source_records, "source_validator_operator_schema_binding_valid"
    )
    source_ready_count = _count(
        source_records,
        "source_validator_operator_public_key_fingerprint_schema_binding_ready",
    )
    value_required = _required_count(value_records)
    value_signature_count = _count(
        value_records, "value_issuer_root_trust_chain_signature_present"
    )
    value_digest_count = _count(
        value_records, "value_issuer_root_trust_chain_signature_digest_present"
    )
    value_digest_sha_count = _count(
        value_records, "value_issuer_root_trust_chain_signature_digest_sha_match"
    )
    value_digest_hash_count = _count(
        value_records, "value_issuer_root_trust_chain_signature_digest_hash_bound"
    )
    value_ready_count = _count(
        value_records, "value_issuer_root_trust_chain_signature_digest_ready"
    )
    checksum_required = _required_count(checksum_records)
    checksum_attestation_count = _count(
        checksum_records, "checksum_expected_source_digest_chain_operator_attestation_present"
    )
    checksum_attestation_signature_count = _count(
        checksum_records,
        "checksum_expected_source_digest_chain_operator_attestation_signature_valid",
    )
    checksum_attestation_hash_count = _count(
        checksum_records, "checksum_expected_source_digest_chain_operator_attestation_hash_bound"
    )
    checksum_ready_count = _count(
        checksum_records, "checksum_expected_source_digest_chain_operator_attestation_ready"
    )
    source_replay_required = record_count
    source_timestamp_count = sum(
        1
        for item in source_replay_records
        if item.get("source_quarantine_signature_timestamp_present")
    )
    source_timestamp_monotonic_count = sum(
        1
        for item in source_replay_records
        if item.get("source_quarantine_signature_timestamp_monotonic")
    )
    source_replay_guard_count = sum(
        1
        for item in source_replay_records
        if item.get("source_quarantine_signature_replay_guard_present")
    )
    source_replay_valid_count = sum(
        1
        for item in source_replay_records
        if item.get("source_quarantine_signature_replay_guard_valid")
    )
    source_replay_ready_count = sum(
        1
        for item in source_replay_records
        if item.get("source_quarantine_signature_timestamp_replay_guard_ready")
    )
    receipt_trust_required = record_count
    receipt_public_key_trust_count = sum(
        1
        for item in receipt_trust_records
        if item.get("receipt_authorization_chain_public_key_trust_present")
    )
    receipt_public_key_trust_hash_count = sum(
        1
        for item in receipt_trust_records
        if item.get("receipt_authorization_chain_public_key_trust_hash_bound")
    )
    receipt_root_digest_count = sum(
        1
        for item in receipt_trust_records
        if item.get("receipt_authorization_chain_root_digest_present")
    )
    receipt_root_digest_sha_count = sum(
        1
        for item in receipt_trust_records
        if item.get("receipt_authorization_chain_root_digest_sha_match")
    )
    receipt_ready_count = sum(
        1
        for item in receipt_trust_records
        if item.get("receipt_authorization_chain_public_key_trust_root_digest_ready")
    )
    receipt_performed_count = sum(
        1 for item in receipt_trust_records if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1 for item in verifier_records if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in verifier_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1 for item in verifier_records if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1 for item in verifier_records if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1 for item in verifier_records if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        upstream_report_valid
        and upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and upstream_ready_count == record_count
        and source_required
        and source_ready_count == source_required
        and value_required
        and value_ready_count == value_required
        and checksum_required
        and checksum_ready_count == checksum_required
        and source_replay_ready_count == source_replay_required
        and receipt_ready_count == receipt_trust_required
        and request_blocked_count == 0
        and not consumable_count
    )
    checks = []
    _add_check(
        checks,
        "upstream_payload_identity_signature_chain_report_present",
        upstream_report_valid,
        f"path={upstream_ref.get('path') or ''} status={_status(upstream_report, upstream_ref) or 'MISSING'}",
    )
    _add_check(
        checks,
        "upstream_payload_identity_signature_chain_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} packets={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "source_validator_operator_public_key_fingerprint_schema_bindings_ready",
        source_required > 0 and source_ready_count == source_required,
        f"ready={source_ready_count}/{source_required} fingerprints={source_fingerprint_count} schema_bindings={source_schema_binding_count}",
    )
    _add_check(
        checks,
        "value_issuer_root_trust_chain_signature_digests_ready",
        value_required > 0 and value_ready_count == value_required,
        f"ready={value_ready_count}/{value_required} signatures={value_signature_count} digests={value_digest_count}",
    )
    _add_check(
        checks,
        "checksum_expected_source_digest_chain_operator_attestations_ready",
        checksum_required > 0 and checksum_ready_count == checksum_required,
        f"ready={checksum_ready_count}/{checksum_required} attestations={checksum_attestation_count} signatures={checksum_attestation_signature_count}",
    )
    _add_check(
        checks,
        "source_quarantine_signature_timestamp_replay_guards_ready",
        source_replay_required > 0 and source_replay_ready_count == source_replay_required,
        f"ready={source_replay_ready_count}/{source_replay_required} timestamps={source_timestamp_count} replay_guards={source_replay_guard_count}",
    )
    _add_check(
        checks,
        "receipt_authorization_chain_public_key_trust_root_digests_ready",
        receipt_trust_required > 0 and receipt_ready_count == receipt_trust_required,
        f"ready={receipt_ready_count}/{receipt_trust_required} public_key_trust={receipt_public_key_trust_count} root_digests={receipt_root_digest_count}",
    )
    _add_check(
        checks,
        "all_request_payload_trust_root_attestation_verifiers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "payload_trust_root_attestation_verifier_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRUST_ROOT_ATTESTATION_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRUST_ROOT_ATTESTATION_UPSTREAM_LINT"
    elif (
        source_fingerprint_count != source_required
        or source_fingerprint_hash_count != source_required
        or source_schema_binding_count != source_required
        or source_schema_valid_count != source_required
        or source_ready_count != source_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_VALIDATOR_OPERATOR_PUBLIC_KEY_FINGERPRINT_SCHEMA_BINDING_MISSING"
    elif (
        value_signature_count != value_required
        or value_digest_count != value_required
        or value_digest_sha_count != value_required
        or value_digest_hash_count != value_required
        or value_ready_count != value_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_VALUE_ISSUER_ROOT_TRUST_CHAIN_SIGNATURE_DIGEST_MISSING"
    elif (
        checksum_attestation_count != checksum_required
        or checksum_attestation_signature_count != checksum_required
        or checksum_attestation_hash_count != checksum_required
        or checksum_ready_count != checksum_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_CHECKSUM_EXPECTED_SOURCE_DIGEST_CHAIN_OPERATOR_ATTESTATION_MISSING"
    elif (
        source_timestamp_count != source_replay_required
        or source_timestamp_monotonic_count != source_replay_required
        or source_replay_guard_count != source_replay_required
        or source_replay_valid_count != source_replay_required
        or source_replay_ready_count != source_replay_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_SOURCE_QUARANTINE_SIGNATURE_TIMESTAMP_REPLAY_GUARD_MISSING"
    elif (
        receipt_public_key_trust_count != receipt_trust_required
        or receipt_public_key_trust_hash_count != receipt_trust_required
        or receipt_root_digest_count != receipt_trust_required
        or receipt_root_digest_sha_count != receipt_trust_required
        or receipt_ready_count != receipt_trust_required
    ):
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTHORIZATION_CHAIN_PUBLIC_KEY_TRUST_ROOT_DIGEST_MISSING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRUST_ROOT_ATTESTATION_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRUST_ROOT_ATTESTATION_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_PAYLOAD_TRUST_ROOT_ATTESTATION_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INPUT_ARTIFACT_SOURCE_VALUE_PAYLOAD_TRUST_ROOT_ATTESTATION_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_human_input_artifact_source_value_payload_identity_signature_chain_verifier_record_count"
                )
            ),
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_record_count": record_count,
            "hash_bound_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_count": hash_bound_count,
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_lint_ready_count": lint_ready_count,
            "upstream_payload_identity_signature_chain_ready_count": upstream_ready_count,
            "upstream_payload_identity_signature_chain_blocked_count": record_count - upstream_ready_count,
            "source_validator_operator_public_key_fingerprint_schema_binding_required_count": source_required,
            "source_validator_operator_public_key_fingerprint_present_count": source_fingerprint_count,
            "source_validator_operator_public_key_fingerprint_hash_bound_count": source_fingerprint_hash_count,
            "source_validator_operator_schema_binding_present_count": source_schema_binding_count,
            "source_validator_operator_schema_binding_valid_count": source_schema_valid_count,
            "source_validator_operator_public_key_fingerprint_schema_binding_ready_count": source_ready_count,
            "value_issuer_root_trust_chain_signature_digest_required_count": value_required,
            "value_issuer_root_trust_chain_signature_present_count": value_signature_count,
            "value_issuer_root_trust_chain_signature_digest_present_count": value_digest_count,
            "value_issuer_root_trust_chain_signature_digest_sha_match_count": value_digest_sha_count,
            "value_issuer_root_trust_chain_signature_digest_hash_bound_count": value_digest_hash_count,
            "value_issuer_root_trust_chain_signature_digest_ready_count": value_ready_count,
            "checksum_expected_source_digest_chain_operator_attestation_required_count": checksum_required,
            "checksum_expected_source_digest_chain_operator_attestation_present_count": checksum_attestation_count,
            "checksum_expected_source_digest_chain_operator_attestation_signature_valid_count": checksum_attestation_signature_count,
            "checksum_expected_source_digest_chain_operator_attestation_hash_bound_count": checksum_attestation_hash_count,
            "checksum_expected_source_digest_chain_operator_attestation_ready_count": checksum_ready_count,
            "source_quarantine_signature_timestamp_replay_guard_required_count": source_replay_required,
            "source_quarantine_signature_timestamp_present_count": source_timestamp_count,
            "source_quarantine_signature_timestamp_monotonic_count": source_timestamp_monotonic_count,
            "source_quarantine_signature_replay_guard_present_count": source_replay_guard_count,
            "source_quarantine_signature_replay_guard_valid_count": source_replay_valid_count,
            "source_quarantine_signature_timestamp_replay_guard_ready_count": source_replay_ready_count,
            "receipt_authorization_chain_public_key_trust_root_digest_required_count": receipt_trust_required,
            "receipt_authorization_chain_public_key_trust_present_count": receipt_public_key_trust_count,
            "receipt_authorization_chain_public_key_trust_hash_bound_count": receipt_public_key_trust_hash_count,
            "receipt_authorization_chain_root_digest_present_count": receipt_root_digest_count,
            "receipt_authorization_chain_root_digest_sha_match_count": receipt_root_digest_sha_count,
            "receipt_authorization_chain_public_key_trust_root_digest_ready_count": receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_record_count": request_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_ready_count": request_ready_count,
            "request_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source validator public-key/schema bindings, value trust-chain signature digests, checksum expected/source digest-chain operator attestations, source quarantine timestamp/replay guards, and receipt public-key trust-root digests.",
            "Verifier records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready verifier still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, receipt approval packets, receipt signature payloads, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Human-Input Artifact Source Value Payload Trust Root Attestation Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_input_artifact_source_value_payload_trust_root_attestation_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
