"""Operator real-source human intake provenance/auth quarantine."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-human-intake-"
    "provenance-auth-quarantine-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_human_intake_provenance_auth_quarantine_capstone.v1"
)
HUMAN_SOURCE_MATERIAL_INTAKE_PACKET_SPEC_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_human_source_material_intake_packet_spec.v1"
)
AUTHORED_VALUE_PROVENANCE_MANIFEST_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_operator_authored_value_provenance_manifest.v1"
)
RECEIPT_AUTH_HUMAN_APPROVAL_INTAKE_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_receipt_authorization_human_approval_intake_quarantine.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_human_intake_provenance_auth_quarantine_state",
    "report_schema",
    "summary",
    "operator_real_source_human_intake_provenance_auth_quarantine_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_authoring_requirement_template_record_count",
    "operator_real_source_human_intake_provenance_auth_quarantine_record_count",
    "hash_bound_operator_real_source_human_intake_provenance_auth_quarantine_count",
    "operator_real_source_human_intake_provenance_auth_lint_ready_count",
    "upstream_authoring_requirement_template_ready_count",
    "upstream_authoring_requirement_template_blocked_count",
    "human_source_material_intake_packet_spec_template_record_count",
    "human_source_material_intake_packet_spec_template_verified_count",
    "human_source_material_intake_packet_spec_present_count",
    "human_source_material_intake_packet_spec_missing_count",
    "human_source_material_intake_packet_spec_valid_count",
    "source_material_reference_hash_binding_ready_count",
    "source_material_reference_hash_binding_unbound_count",
    "authored_value_provenance_manifest_required_count",
    "authored_value_provenance_manifest_template_verified_count",
    "authored_value_provenance_manifest_present_count",
    "authored_value_provenance_manifest_missing_count",
    "authored_value_provenance_manifest_hash_bound_count",
    "receipt_authorization_human_approval_intake_required_count",
    "receipt_authorization_human_approval_intake_template_verified_count",
    "receipt_authorization_human_approval_intake_present_count",
    "receipt_authorization_human_approval_intake_missing_count",
    "receipt_authorization_human_approval_intake_valid_count",
    "receipt_authorization_human_approval_intake_ready_count",
    "receipt_authorization_human_approval_intake_quarantined_count",
    "receipt_authorization_performed_count",
    "request_operator_real_source_human_intake_provenance_auth_quarantine_record_count",
    "request_operator_real_source_human_intake_provenance_auth_quarantine_ready_count",
    "request_operator_real_source_human_intake_provenance_auth_quarantine_blocked_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_human_intake_provenance_auth_quarantine_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _request_records(report):
    return [
        dict(item or {})
        for item in (report or {}).get(
            "operator_real_source_authoring_requirement_template_verifier_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _packet_records(request_record):
    return [
        dict(item or {})
        for item in (request_record or {}).get(
            "operator_real_source_authoring_requirement_template_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _field_records(packet_record):
    return [
        dict(item or {})
        for item in (packet_record or {}).get(
            "operator_field_authoring_requirement_records"
        )
        or []
        if isinstance(item, dict)
    ]


def _human_source_material_intake_spec(packet_record, payload_sha):
    source_template = dict(
        packet_record.get("source_material_reference_intake_envelope_template") or {}
    )
    source_path = (
        source_template.get("expected_source_material_reference_intake_envelope_path")
        or ""
    )
    if source_path.endswith(".source-material-reference-intake.json"):
        spec_path = (
            source_path[: -len(".source-material-reference-intake.json")]
            + ".human-source-material-intake-spec.json"
        )
    elif source_path.endswith(".json"):
        spec_path = source_path[:-5] + ".human-source-material-intake-spec.json"
    else:
        spec_path = source_path + ".human-source-material-intake-spec.json" if source_path else ""
    required_fields = [
        "schema_id",
        "request_id",
        "slug",
        "packet_type",
        "expected_packet_path",
        "source_material_reference_intake_envelope_path",
        "operator_real_source_authoring_requirement_template_payload_sha256",
        "human_operator_source_material_intake_packet_spec",
        "explicit_human_operator_source_material_intake",
    ]
    template_verified = bool(
        spec_path
        and packet_record.get("request_id") is not None
        and packet_record.get("slug")
        and packet_record.get("packet_type")
        and packet_record.get("expected_packet_path")
        and packet_record.get(
            "operator_real_source_authoring_requirement_template_payload_sha256"
        )
    )
    present = bool(packet_record.get("source_material_reference_intake_envelope_present"))
    valid = bool(packet_record.get("source_material_reference_intake_envelope_valid"))
    hash_ready = bool(packet_record.get("source_material_reference_hash_binding_ready"))
    return {
        "schema_id": HUMAN_SOURCE_MATERIAL_INTAKE_PACKET_SPEC_SCHEMA_ID,
        "human_source_material_intake_packet_spec_id": (
            f"referee-repair-human-source-intake-spec-{payload_sha[:16]}"
        ),
        "expected_human_source_material_intake_packet_spec_path": spec_path,
        "source_material_reference_intake_envelope_path": source_path,
        "required_template_fields": required_fields,
        "required_template_field_count": len(required_fields),
        "human_source_material_intake_packet_spec_template_verified": template_verified,
        "human_source_material_intake_packet_spec_present": present,
        "human_source_material_intake_packet_spec_missing": not present,
        "human_source_material_intake_packet_spec_valid": valid,
        "source_material_reference_sha256_declared": bool(
            packet_record.get("source_material_reference_sha256_declared")
        ),
        "source_material_reference_sha256_verified": bool(
            packet_record.get("source_material_reference_sha256_verified")
        ),
        "source_material_reference_hash_binding_ready": hash_ready,
        "source_material_reference_hash_binding_unbound": not hash_ready,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _authored_value_provenance_records(packet_record, payload_sha):
    records = []
    expected_packet_path = packet_record.get("expected_packet_path") or ""
    manifest_base = (
        expected_packet_path[:-5]
        if expected_packet_path.endswith(".json")
        else expected_packet_path
    )
    for field in _field_records(packet_record):
        required = bool(field.get("required"))
        present = bool(field.get("operator_field_authoring_evidence_present"))
        field_name = field.get("name") or ""
        payload = {
            "schema_id": AUTHORED_VALUE_PROVENANCE_MANIFEST_SCHEMA_ID,
            "operator_real_source_human_intake_provenance_auth_payload_sha256": payload_sha,
            "field": field_name,
            "field_requirement_payload_sha256": (
                field.get("operator_field_authoring_requirement_payload_sha256") or ""
            ),
            "required": required,
        }
        field_sha = _sha(payload)
        path_suffix = field_name.replace("/", "_").replace(" ", "_") or "field"
        expected_path = f"{manifest_base}.{path_suffix}.authored-value-provenance.json"
        template_verified = bool(
            field.get("template_spec_verified")
            and field_name
            and field.get("operator_field_authoring_requirement_payload_sha256")
        )
        records.append(
            {
                "authored_value_provenance_manifest_id": (
                    f"referee-repair-authored-value-provenance-{field_sha[:16]}"
                ),
                "authored_value_provenance_manifest_payload_sha256": field_sha,
                "expected_authored_value_provenance_manifest_path": expected_path,
                "field": field_name,
                "required": required,
                "authored_value_provenance_manifest_template_verified": template_verified,
                "authored_value_provenance_manifest_present": present,
                "authored_value_provenance_manifest_missing": bool(required and not present),
                "authored_value_provenance_manifest_hash_bound": bool(
                    present and field.get("operator_field_authoring_requirement_payload_sha256")
                ),
                "source_field_authoring_requirement_payload_sha256": (
                    field.get("operator_field_authoring_requirement_payload_sha256") or ""
                ),
                "source_field_authoring_requirement_missing": bool(
                    field.get("operator_field_authoring_requirement_missing")
                ),
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return records


def _receipt_authorization_human_approval_intake(packet_record, payload_sha):
    receipt_template = dict(packet_record.get("receipt_authorization_envelope_template") or {})
    request_path = receipt_template.get("expected_receipt_authorization_envelope_path") or ""
    if request_path.endswith(".redrive-receipt-authorization-request.json"):
        approval_path = (
            request_path[: -len(".redrive-receipt-authorization-request.json")]
            + ".receipt-auth-human-approval-intake.json"
        )
    elif request_path.endswith(".json"):
        approval_path = request_path[:-5] + ".human-approval-intake.json"
    else:
        approval_path = request_path + ".human-approval-intake.json" if request_path else ""
    required_fields = [
        "schema_id",
        "request_id",
        "slug",
        "packet_type",
        "expected_redrive_execution_receipt_path",
        "receipt_authorization_envelope_path",
        "operator_real_source_authoring_requirement_template_payload_sha256",
        "explicit_human_receipt_authorization_approval",
        "redrive_receipt_authoring_authorization_performed",
    ]
    template_verified = bool(
        approval_path
        and packet_record.get("request_id") is not None
        and packet_record.get("slug")
        and packet_record.get("packet_type")
        and packet_record.get("expected_redrive_execution_receipt_path")
        and packet_record.get(
            "operator_real_source_authoring_requirement_template_payload_sha256"
        )
    )
    present = bool(packet_record.get("receipt_authorization_envelope_present"))
    valid = bool(packet_record.get("receipt_authorization_envelope_valid"))
    ready = bool(packet_record.get("receipt_authorization_envelope_ready"))
    performed = bool(packet_record.get("receipt_authorization_performed"))
    return {
        "schema_id": RECEIPT_AUTH_HUMAN_APPROVAL_INTAKE_SCHEMA_ID,
        "receipt_authorization_human_approval_intake_id": (
            f"referee-repair-receipt-auth-human-approval-{payload_sha[:16]}"
        ),
        "expected_receipt_authorization_human_approval_intake_path": approval_path,
        "receipt_authorization_envelope_path": request_path,
        "required_template_fields": required_fields,
        "required_template_field_count": len(required_fields),
        "receipt_authorization_human_approval_intake_template_verified": template_verified,
        "receipt_authorization_human_approval_intake_present": present,
        "receipt_authorization_human_approval_intake_missing": not present,
        "receipt_authorization_human_approval_intake_valid": valid,
        "receipt_authorization_human_approval_intake_ready": ready,
        "receipt_authorization_human_approval_intake_quarantined": not ready,
        "receipt_authorization_performed": performed,
        "receipt_creation_allowed": False,
        "request_closure_allowed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _packet_quarantine_record(packet_record):
    packet_record = dict(packet_record or {})
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_operator_real_source_human_intake_provenance_auth_quarantine_record.v1"
        ),
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_authoring_requirement_template_payload_sha256": (
            packet_record.get(
                "operator_real_source_authoring_requirement_template_payload_sha256"
            )
            or ""
        ),
    }
    payload_sha = _sha(payload)
    hash_bound = bool(
        payload_sha
        and packet_record.get("operator_real_source_authoring_requirement_template_hash_bound")
    )
    lint_ready = bool(
        hash_bound
        and packet_record.get("operator_real_source_authoring_requirement_template_lint_ready")
        and packet_record.get("request_id") is not None
        and packet_record.get("slug")
        and packet_record.get("packet_type")
        and packet_record.get("expected_packet_path")
        and packet_record.get("expected_redrive_execution_receipt_path")
    )
    source_spec = _human_source_material_intake_spec(packet_record, payload_sha)
    provenance_records = _authored_value_provenance_records(packet_record, payload_sha)
    receipt_approval = _receipt_authorization_human_approval_intake(
        packet_record, payload_sha
    )
    required_provenance = sum(1 for item in provenance_records if item.get("required"))
    present_provenance = sum(
        1
        for item in provenance_records
        if item.get("required") and item.get("authored_value_provenance_manifest_present")
    )
    hash_bound_provenance = sum(
        1
        for item in provenance_records
        if item.get("required")
        and item.get("authored_value_provenance_manifest_hash_bound")
    )
    expected_file_creation = bool(packet_record.get("expected_packet_file_creation_performed"))
    receipt_creation = bool(packet_record.get("redrive_receipt_creation_performed"))
    receipt_performed = bool(receipt_approval.get("receipt_authorization_performed"))
    evidence_release = bool(packet_record.get("evidence_release_performed"))
    promoted = bool(packet_record.get("repair_evidence_promoted"))
    closure = bool(packet_record.get("request_closure_performed"))
    consumable = bool(
        packet_record.get("consumable_as_repair_evidence")
        or packet_record.get("consumable_as_release_evidence")
        or packet_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or receipt_performed
        or evidence_release
        or promoted
        or closure
    )
    ready = bool(
        lint_ready
        and packet_record.get("operator_real_source_authoring_requirement_template_ready")
        and source_spec.get("human_source_material_intake_packet_spec_valid")
        and source_spec.get("source_material_reference_hash_binding_ready")
        and present_provenance == required_provenance
        and hash_bound_provenance == required_provenance
        and receipt_approval.get("receipt_authorization_human_approval_intake_ready")
        and not receipt_performed
        and not consumable
    )
    issues = []
    if not source_spec.get("human_source_material_intake_packet_spec_present"):
        issues.append("human_source_material_intake_packet_spec_missing")
    if (
        source_spec.get("human_source_material_intake_packet_spec_present")
        and not source_spec.get("human_source_material_intake_packet_spec_valid")
    ):
        issues.append("human_source_material_intake_packet_spec_invalid")
    if present_provenance != required_provenance:
        issues.append("authored_value_provenance_manifest_missing")
    if hash_bound_provenance != required_provenance:
        issues.append("authored_value_provenance_manifest_hash_unbound")
    if not source_spec.get("source_material_reference_hash_binding_ready"):
        issues.append("source_material_reference_hash_unbound")
    if not receipt_approval.get("receipt_authorization_human_approval_intake_present"):
        issues.append("receipt_authorization_human_approval_intake_missing")
    if (
        receipt_approval.get("receipt_authorization_human_approval_intake_present")
        and not receipt_approval.get("receipt_authorization_human_approval_intake_valid")
    ):
        issues.append("receipt_authorization_human_approval_intake_invalid")
    if not receipt_approval.get("receipt_authorization_human_approval_intake_ready"):
        issues.append("receipt_authorization_human_approval_intake_quarantined")
    if consumable:
        issues.append("operator_real_source_human_intake_action_or_evidence_leak")
    return {
        "request_id": packet_record.get("request_id"),
        "slug": packet_record.get("slug") or "",
        "packet_type": packet_record.get("packet_type") or "",
        "operator_real_source_human_intake_provenance_auth_quarantine_id": (
            f"referee-repair-operator-human-intake-provenance-auth-{packet_record.get('request_id')}-{packet_record.get('packet_type')}-{payload_sha[:16]}"
        ),
        "operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256": payload_sha,
        "operator_real_source_human_intake_provenance_auth_quarantine_hash_bound": hash_bound,
        "operator_real_source_human_intake_provenance_auth_quarantine_lint_ready": lint_ready,
        "operator_real_source_authoring_requirement_template_payload_sha256": (
            packet_record.get(
                "operator_real_source_authoring_requirement_template_payload_sha256"
            )
            or ""
        ),
        "expected_packet_path": packet_record.get("expected_packet_path") or "",
        "expected_redrive_execution_receipt_path": (
            packet_record.get("expected_redrive_execution_receipt_path") or ""
        ),
        "human_source_material_intake_packet_spec": source_spec,
        "human_source_material_intake_packet_spec_template_verified": source_spec[
            "human_source_material_intake_packet_spec_template_verified"
        ],
        "human_source_material_intake_packet_spec_present": source_spec[
            "human_source_material_intake_packet_spec_present"
        ],
        "human_source_material_intake_packet_spec_valid": source_spec[
            "human_source_material_intake_packet_spec_valid"
        ],
        "source_material_reference_hash_binding_ready": source_spec[
            "source_material_reference_hash_binding_ready"
        ],
        "authored_value_provenance_manifest_records": provenance_records,
        "authored_value_provenance_manifest_required_count": required_provenance,
        "authored_value_provenance_manifest_template_verified_count": sum(
            1
            for item in provenance_records
            if item.get("required")
            and item.get("authored_value_provenance_manifest_template_verified")
        ),
        "authored_value_provenance_manifest_present_count": present_provenance,
        "authored_value_provenance_manifest_missing_count": required_provenance
        - present_provenance,
        "authored_value_provenance_manifest_hash_bound_count": hash_bound_provenance,
        "receipt_authorization_human_approval_intake": receipt_approval,
        "receipt_authorization_human_approval_intake_template_verified": receipt_approval[
            "receipt_authorization_human_approval_intake_template_verified"
        ],
        "receipt_authorization_human_approval_intake_present": receipt_approval[
            "receipt_authorization_human_approval_intake_present"
        ],
        "receipt_authorization_human_approval_intake_valid": receipt_approval[
            "receipt_authorization_human_approval_intake_valid"
        ],
        "receipt_authorization_human_approval_intake_ready": receipt_approval[
            "receipt_authorization_human_approval_intake_ready"
        ],
        "receipt_authorization_performed": receipt_performed,
        "operator_real_source_human_intake_provenance_auth_quarantine_ready": ready,
        "operator_real_source_human_intake_provenance_auth_quarantine_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "human intake provenance/auth quarantine is ready for downstream review; do not create source, receipt, release, or closure here"
            if ready
            else "provide human source-material intake spec, authored-value provenance manifests, and receipt authorization human approval intake"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(upstream_request_record, quarantine_records):
    request_id = upstream_request_record.get("request_id")
    slug = upstream_request_record.get("slug") or ""
    blocked = [
        item
        for item in quarantine_records
        if not item.get("operator_real_source_human_intake_provenance_auth_quarantine_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_human_intake_provenance_auth_quarantine_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_human_intake_provenance_auth_payload_sha256s": [
            item.get(
                "operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256"
            )
            for item in quarantine_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(quarantine_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_human_intake_provenance_auth_quarantine_id": (
            f"referee-repair-request-operator-human-intake-provenance-auth-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_human_intake_provenance_auth_quarantine_payload_sha256": payload_sha,
        "request_operator_real_source_human_intake_provenance_auth_quarantine_hash_bound": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_intake_provenance_auth_quarantine_hash_bound"
                )
                for item in quarantine_records
            )
        ),
        "request_operator_real_source_human_intake_provenance_auth_quarantine_lint_ready": bool(
            payload_sha
            and all(
                item.get(
                    "operator_real_source_human_intake_provenance_auth_quarantine_lint_ready"
                )
                for item in quarantine_records
            )
        ),
        "operator_real_source_human_intake_provenance_auth_quarantine_record_count": len(
            quarantine_records
        ),
        "operator_real_source_human_intake_provenance_auth_quarantine_ready_count": sum(
            1
            for item in quarantine_records
            if item.get("operator_real_source_human_intake_provenance_auth_quarantine_ready")
        ),
        "request_operator_real_source_human_intake_provenance_auth_quarantine_ready": ready,
        "request_operator_real_source_human_intake_provenance_auth_quarantine_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_human_intake_provenance_auth_quarantine_records": quarantine_records,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_human_intake_provenance_auth_quarantine_capstone(
    operator_real_source_authoring_requirement_template_verifier_report,
    operator_real_source_authoring_requirement_template_verifier_ref=None,
    label="",
    created_at="",
):
    upstream_report = dict(
        operator_real_source_authoring_requirement_template_verifier_report or {}
    )
    upstream_ref = dict(
        operator_real_source_authoring_requirement_template_verifier_ref or {}
    )
    upstream_summary = _summary(upstream_report)
    upstream_request_records = _request_records(upstream_report)
    upstream_packet_records = [
        record
        for request_record in upstream_request_records
        for record in _packet_records(request_record)
    ]
    upstream_report_valid = bool(
        upstream_ref.get("path")
        and upstream_ref.get("sha256_match")
        and upstream_report
        and _status(upstream_report, upstream_ref) in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_authoring_requirement_template_record_count"
            )
        )
        == len(upstream_request_records)
        and all(
            request.get(
                "request_operator_real_source_authoring_requirement_template_lint_ready"
            )
            for request in upstream_request_records
        )
        and all(
            record.get("operator_real_source_authoring_requirement_template_lint_ready")
            for record in upstream_packet_records
        )
    )
    request_records = []
    for request_record in sorted(
        upstream_request_records, key=lambda item: str(item.get("request_id"))
    ):
        quarantine_records = [
            _packet_quarantine_record(record) for record in _packet_records(request_record)
        ]
        request_records.append(_request_record(request_record, quarantine_records))
    quarantine_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_human_intake_provenance_auth_quarantine_records"
        )
        or []
    ]
    record_count = len(quarantine_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get(
            "request_operator_real_source_human_intake_provenance_auth_quarantine_ready"
        )
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in quarantine_records
        if item.get("operator_real_source_human_intake_provenance_auth_quarantine_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in quarantine_records
        if item.get("operator_real_source_human_intake_provenance_auth_quarantine_lint_ready")
    )
    upstream_ready_count = sum(
        1
        for item in upstream_packet_records
        if item.get("operator_real_source_authoring_requirement_template_ready")
    )
    source_template_count = record_count
    source_template_verified_count = sum(
        1
        for item in quarantine_records
        if item.get("human_source_material_intake_packet_spec_template_verified")
    )
    source_present_count = sum(
        1
        for item in quarantine_records
        if item.get("human_source_material_intake_packet_spec_present")
    )
    source_valid_count = sum(
        1
        for item in quarantine_records
        if item.get("human_source_material_intake_packet_spec_valid")
    )
    source_hash_ready_count = sum(
        1
        for item in quarantine_records
        if item.get("source_material_reference_hash_binding_ready")
    )
    provenance_required_count = sum(
        _int(item.get("authored_value_provenance_manifest_required_count"))
        for item in quarantine_records
    )
    provenance_template_verified_count = sum(
        _int(item.get("authored_value_provenance_manifest_template_verified_count"))
        for item in quarantine_records
    )
    provenance_present_count = sum(
        _int(item.get("authored_value_provenance_manifest_present_count"))
        for item in quarantine_records
    )
    provenance_hash_bound_count = sum(
        _int(item.get("authored_value_provenance_manifest_hash_bound_count"))
        for item in quarantine_records
    )
    receipt_required_count = record_count
    receipt_template_verified_count = sum(
        1
        for item in quarantine_records
        if item.get("receipt_authorization_human_approval_intake_template_verified")
    )
    receipt_present_count = sum(
        1
        for item in quarantine_records
        if item.get("receipt_authorization_human_approval_intake_present")
    )
    receipt_valid_count = sum(
        1
        for item in quarantine_records
        if item.get("receipt_authorization_human_approval_intake_valid")
    )
    receipt_ready_count = sum(
        1
        for item in quarantine_records
        if item.get("receipt_authorization_human_approval_intake_ready")
    )
    receipt_performed_count = sum(
        1
        for item in quarantine_records
        if item.get("receipt_authorization_performed")
    )
    expected_file_creation_count = sum(
        1
        for item in quarantine_records
        if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in quarantine_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in quarantine_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in quarantine_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in quarantine_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in quarantine_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
        or item.get("receipt_authorization_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and source_template_verified_count == source_template_count
        and source_valid_count == source_template_count
        and source_hash_ready_count == source_template_count
        and provenance_present_count == provenance_required_count
        and provenance_hash_bound_count == provenance_required_count
        and receipt_template_verified_count == receipt_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "operator_real_source_authoring_requirement_template_verifier_available",
        upstream_report_valid,
        upstream_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "operator_real_source_authoring_requirement_template_lint_ready",
        upstream_lint_ready,
        f"requests={len(upstream_request_records)} records={len(upstream_packet_records)}",
    )
    _add_check(
        checks,
        "all_operator_real_source_human_intake_provenance_auth_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_human_source_material_intake_packet_specs_verified",
        source_template_verified_count == source_template_count,
        f"template_verified={source_template_verified_count} records={source_template_count}",
    )
    _add_check(
        checks,
        "all_human_source_material_intake_packet_specs_present_valid_hash_bound",
        source_present_count == source_template_count
        and source_valid_count == source_template_count
        and source_hash_ready_count == source_template_count,
        (
            f"present={source_present_count} valid={source_valid_count} "
            f"hash_bound={source_hash_ready_count} records={source_template_count}"
        ),
    )
    _add_check(
        checks,
        "all_authored_value_provenance_manifests_present_and_hash_bound",
        provenance_present_count == provenance_required_count
        and provenance_hash_bound_count == provenance_required_count,
        (
            f"present={provenance_present_count} "
            f"hash_bound={provenance_hash_bound_count} "
            f"required={provenance_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_receipt_authorization_human_approval_intakes_present_ready_and_not_performed",
        receipt_present_count == receipt_required_count
        and receipt_valid_count == receipt_required_count
        and receipt_ready_count == receipt_required_count
        and receipt_performed_count == 0,
        (
            f"present={receipt_present_count} valid={receipt_valid_count} "
            f"ready={receipt_ready_count} performed={receipt_performed_count} "
            f"records={receipt_required_count}"
        ),
    )
    _add_check(
        checks,
        "all_request_operator_real_source_human_intake_provenance_auth_quarantines_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "operator_real_source_human_intake_provenance_auth_quarantine_is_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and receipt_performed_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} "
            f"receipt_auth_performed={receipt_performed_count} "
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INTAKE_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INTAKE_UPSTREAM_LINT"
    elif source_template_verified_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_SOURCE_MATERIAL_INTAKE_TEMPLATE"
    elif source_present_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_SOURCE_MATERIAL_INTAKE_PACKET_SPEC_MISSING"
    elif source_valid_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_SOURCE_MATERIAL_INTAKE_PACKET_SPEC_INVALID"
    elif source_hash_ready_count != source_template_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_SOURCE_MATERIAL_HASH_BINDING"
    elif provenance_present_count != provenance_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORED_VALUE_PROVENANCE_MISSING"
    elif provenance_hash_bound_count != provenance_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_AUTHORED_VALUE_PROVENANCE_HASH_BINDING"
    elif expected_file_creation_count or receipt_creation_count or receipt_performed_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INTAKE_ACTION_LEAK"
    elif receipt_template_verified_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTH_HUMAN_APPROVAL_TEMPLATE"
    elif receipt_present_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTH_HUMAN_APPROVAL_MISSING"
    elif receipt_valid_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTH_HUMAN_APPROVAL_INVALID"
    elif receipt_ready_count != receipt_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_RECEIPT_AUTH_HUMAN_APPROVAL_QUARANTINE"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INTAKE_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INTAKE_PREFLIGHT"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_HUMAN_INTAKE_PROVENANCE_AUTH_QUARANTINE_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_human_intake_provenance_auth_quarantine_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_authoring_requirement_template_record_count": _int(
                upstream_summary.get(
                    "operator_real_source_authoring_requirement_template_record_count"
                )
            ),
            "operator_real_source_human_intake_provenance_auth_quarantine_record_count": record_count,
            "hash_bound_operator_real_source_human_intake_provenance_auth_quarantine_count": hash_bound_count,
            "operator_real_source_human_intake_provenance_auth_lint_ready_count": lint_ready_count,
            "upstream_authoring_requirement_template_ready_count": upstream_ready_count,
            "upstream_authoring_requirement_template_blocked_count": record_count
            - upstream_ready_count,
            "human_source_material_intake_packet_spec_template_record_count": source_template_count,
            "human_source_material_intake_packet_spec_template_verified_count": source_template_verified_count,
            "human_source_material_intake_packet_spec_present_count": source_present_count,
            "human_source_material_intake_packet_spec_missing_count": source_template_count
            - source_present_count,
            "human_source_material_intake_packet_spec_valid_count": source_valid_count,
            "source_material_reference_hash_binding_ready_count": source_hash_ready_count,
            "source_material_reference_hash_binding_unbound_count": source_template_count
            - source_hash_ready_count,
            "authored_value_provenance_manifest_required_count": provenance_required_count,
            "authored_value_provenance_manifest_template_verified_count": provenance_template_verified_count,
            "authored_value_provenance_manifest_present_count": provenance_present_count,
            "authored_value_provenance_manifest_missing_count": provenance_required_count
            - provenance_present_count,
            "authored_value_provenance_manifest_hash_bound_count": provenance_hash_bound_count,
            "receipt_authorization_human_approval_intake_required_count": receipt_required_count,
            "receipt_authorization_human_approval_intake_template_verified_count": receipt_template_verified_count,
            "receipt_authorization_human_approval_intake_present_count": receipt_present_count,
            "receipt_authorization_human_approval_intake_missing_count": receipt_required_count
            - receipt_present_count,
            "receipt_authorization_human_approval_intake_valid_count": receipt_valid_count,
            "receipt_authorization_human_approval_intake_ready_count": receipt_ready_count,
            "receipt_authorization_human_approval_intake_quarantined_count": receipt_required_count
            - receipt_ready_count,
            "receipt_authorization_performed_count": receipt_performed_count,
            "request_operator_real_source_human_intake_provenance_auth_quarantine_record_count": request_count,
            "request_operator_real_source_human_intake_provenance_auth_quarantine_ready_count": request_ready_count,
            "request_operator_real_source_human_intake_provenance_auth_quarantine_blocked_count": request_blocked_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_human_intake_provenance_auth_quarantine_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_human_intake_provenance_auth_quarantine_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies human operator source-material intake specs, authored-value provenance manifests, and receipt authorization human approval intake quarantine records.",
            "Human intake specs, authored-value provenance manifests, and receipt authorization approval quarantine records are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready human intake provenance/auth quarantine still does not write operator intake packets, write source packets, write receipts, authorize receipt authoring, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, source-material reference envelopes, receipt authorization envelopes, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Operator Real-Source Human Intake Provenance/Auth Quarantine",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_human_intake_provenance_auth_quarantine_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
