"""Operator real-source intake checklist verifier for referee repair packets."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-intake-"
    "checklist-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_intake_checklist_verifier_capstone.v1"
)
OPERATOR_INTAKE_PACKET_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_intake_packet.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_intake_checklist_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_intake_checklist_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "real_source_provenance_intake_record_count",
    "operator_real_source_intake_checklist_record_count",
    "hash_bound_operator_real_source_intake_checklist_count",
    "operator_real_source_intake_checklist_lint_ready_count",
    "upstream_real_source_provenance_ready_count",
    "upstream_real_source_provenance_blocked_count",
    "operator_real_source_intake_packet_required_count",
    "operator_real_source_intake_packet_present_count",
    "operator_real_source_intake_packet_missing_count",
    "operator_real_source_intake_packet_json_ok_count",
    "operator_real_source_intake_packet_json_error_count",
    "operator_real_source_intake_packet_schema_match_count",
    "operator_real_source_intake_packet_schema_mismatch_count",
    "operator_real_source_intake_packet_binding_match_count",
    "operator_real_source_intake_packet_binding_mismatch_count",
    "operator_real_source_intake_packet_hash_bound_count",
    "operator_real_source_intake_packet_hash_unbound_count",
    "operator_real_source_intake_packet_explicit_count",
    "operator_real_source_intake_packet_valid_count",
    "operator_real_source_intake_packet_invalid_count",
    "source_material_absence_ledger_entry_count",
    "source_material_evidence_reference_present_count",
    "source_material_evidence_reference_missing_count",
    "source_sha256_declared_count",
    "source_sha256_missing_count",
    "source_packet_authoring_plan_present_count",
    "source_packet_authoring_plan_missing_count",
    "redrive_receipt_plan_present_count",
    "redrive_receipt_plan_missing_count",
    "referee_rejudge_provenance_plan_required_count",
    "referee_rejudge_provenance_plan_present_count",
    "referee_rejudge_provenance_plan_missing_count",
    "human_input_checklist_required_count",
    "human_input_checklist_satisfied_count",
    "human_input_checklist_missing_count",
    "request_operator_real_source_intake_checklist_record_count",
    "request_operator_real_source_intake_checklist_ready_count",
    "request_operator_real_source_intake_checklist_blocked_count",
    "proof_status_operator_real_source_intake_required_count",
    "proof_status_operator_real_source_intake_ready_count",
    "evidence_manifest_operator_real_source_intake_required_count",
    "evidence_manifest_operator_real_source_intake_ready_count",
    "appendix_supplement_operator_real_source_intake_required_count",
    "appendix_supplement_operator_real_source_intake_ready_count",
    "claim_downgrade_operator_real_source_intake_required_count",
    "claim_downgrade_operator_real_source_intake_ready_count",
    "referee_rejudge_operator_real_source_intake_required_count",
    "referee_rejudge_operator_real_source_intake_ready_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_intake_checklist_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def expected_operator_real_source_intake_path(expected_packet_path):
    if not expected_packet_path:
        return ""
    if expected_packet_path.endswith(".json"):
        return expected_packet_path[:-5] + ".operator-real-source-intake.json"
    return expected_packet_path + ".operator-real-source-intake.json"


def _slot_data(inventory, path):
    return dict((inventory or {}).get(path) or {})


def _packet_hash_bound(data):
    if not isinstance(data, dict):
        return False
    return bool(
        data.get("operator_real_source_intake_packet_hash_bound")
        or data.get("real_source_intake_packet_hash_bound")
        or data.get("intake_packet_hash_bound")
        or data.get("hash_bound")
    )


def _packet_explicit(data):
    if not isinstance(data, dict):
        return False
    return bool(
        data.get("explicit_operator_real_source_intake")
        or data.get("operator_real_source_intake_explicit")
        or data.get("human_real_source_intake_explicit")
    )


def _first_text(data, keys):
    for key in keys:
        value = (data or {}).get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ""


def _has_truthy(data, keys):
    return any(bool((data or {}).get(key)) for key in keys)


def _checklist_item(name, required, satisfied, detail):
    return {
        "name": name,
        "required": bool(required),
        "satisfied": bool(satisfied),
        "detail": detail,
    }


def _checklist_record(provenance_record, operator_slot):
    provenance_record = dict(provenance_record or {})
    operator_slot = dict(operator_slot or {})
    operator_data = (
        operator_slot.get("json") if isinstance(operator_slot.get("json"), dict) else {}
    )
    request_id = provenance_record.get("request_id")
    slug = provenance_record.get("slug") or ""
    packet_type = provenance_record.get("packet_type") or ""
    expected_packet_path = provenance_record.get("expected_packet_path") or ""
    expected_receipt_path = (
        provenance_record.get("expected_redrive_execution_receipt_path") or ""
    )
    required_schema_id = provenance_record.get("required_packet_schema_id") or ""
    upstream_sha = (
        provenance_record.get("real_source_provenance_intake_payload_sha256") or ""
    )
    expected_intake_path = expected_operator_real_source_intake_path(
        expected_packet_path
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_operator_real_source_intake_checklist_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_packet_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "expected_operator_real_source_intake_path": expected_intake_path,
        "real_source_provenance_intake_payload_sha256": upstream_sha,
    }
    payload_sha = _sha(payload)
    upstream_hash_bound = bool(
        provenance_record.get("real_source_provenance_intake_hash_bound")
    )
    upstream_lint_ready = bool(
        provenance_record.get("real_source_provenance_intake_lint_ready")
    )
    lint_ready = bool(
        request_id is not None
        and slug
        and packet_type
        and expected_packet_path
        and expected_receipt_path
        and expected_intake_path
        and upstream_sha
        and upstream_lint_ready
        and payload_sha
    )
    hash_bound = bool(payload_sha and upstream_hash_bound)
    packet_present = bool(operator_slot.get("present"))
    packet_json_ok = bool(operator_slot.get("json_ok"))
    packet_json_error = bool(packet_present and not packet_json_ok)
    observed_schema_id = (
        operator_data.get("schema_id") or operator_slot.get("schema_id") or ""
    )
    packet_schema_match = bool(
        packet_present
        and packet_json_ok
        and observed_schema_id == OPERATOR_INTAKE_PACKET_SCHEMA_ID
    )
    packet_schema_mismatch = bool(
        packet_present and packet_json_ok and not packet_schema_match
    )
    packet_binding_match = bool(
        packet_present
        and packet_json_ok
        and operator_data.get("request_id") == request_id
        and (operator_data.get("slug") or "") == slug
        and (operator_data.get("packet_type") or "") == packet_type
        and (operator_data.get("expected_packet_path") or "") == expected_packet_path
        and (operator_data.get("required_packet_schema_id") or "")
        == required_schema_id
        and (
            operator_data.get("real_source_provenance_intake_payload_sha256")
            or ""
        )
        == upstream_sha
    )
    packet_hash_bound = bool(packet_present and packet_json_ok and _packet_hash_bound(operator_data))
    packet_explicit = bool(packet_present and packet_json_ok and _packet_explicit(operator_data))
    source_material_reference = _first_text(
        operator_data,
        [
            "real_source_material_evidence_path",
            "real_source_material_reference",
            "source_material_evidence_path",
            "source_material_reference",
        ],
    )
    source_material_reference_present = bool(
        source_material_reference
        and _has_truthy(
            operator_data,
            [
                "operator_confirms_real_source_material",
                "real_source_material_present",
                "source_material_evidence_present",
            ],
        )
    )
    source_sha256 = _first_text(
        operator_data,
        [
            "request_specific_source_sha256",
            "source_sha256",
            "source_material_sha256",
        ],
    )
    source_sha256_declared = bool(len(source_sha256) >= 32)
    source_packet_plan_present = bool(
        _has_truthy(
            operator_data,
            [
                "source_packet_authoring_plan_present",
                "source_packet_json_authoring_ready",
                "schema_conformant_source_packet_plan",
            ],
        )
        or _first_text(operator_data, ["source_packet_authoring_plan"])
    )
    receipt_plan_present = bool(
        _has_truthy(
            operator_data,
            [
                "redrive_receipt_plan_present",
                "redrive_receipt_authoring_plan_present",
                "redrive_execution_receipt_plan_ready",
            ],
        )
        or _first_text(operator_data, ["redrive_receipt_plan"])
    )
    rejudge_required = packet_type == "referee_rejudge"
    rejudge_plan_present = bool(
        not rejudge_required
        or _has_truthy(
            operator_data,
            [
                "referee_rejudge_provenance_plan_present",
                "referee_rejudge_provenance_plan_ready",
                "referee_rejudge_operator_input_present",
            ],
        )
        or _first_text(operator_data, ["referee_rejudge_provenance_plan"])
    )
    checklist = [
        _checklist_item(
            "operator_real_source_intake_packet_present",
            True,
            packet_present,
            expected_intake_path,
        ),
        _checklist_item(
            "operator_real_source_intake_packet_schema_bound",
            True,
            packet_schema_match and packet_hash_bound,
            OPERATOR_INTAKE_PACKET_SCHEMA_ID,
        ),
        _checklist_item(
            "explicit_operator_real_source_intake",
            True,
            packet_explicit,
            "Human/operator intake must be explicit and request-bound.",
        ),
        _checklist_item(
            "operator_intake_request_binding_match",
            True,
            packet_binding_match,
            "request_id, slug, packet_type, expected path, schema, and upstream hash must match",
        ),
        _checklist_item(
            "real_source_material_evidence_reference_present",
            True,
            source_material_reference_present,
            "Reference real request-specific source material; do not fabricate it here.",
        ),
        _checklist_item(
            "request_specific_source_sha256_declared",
            True,
            source_sha256_declared,
            "Hash must come from the real request-specific source material.",
        ),
        _checklist_item(
            "source_packet_authoring_plan_present",
            True,
            source_packet_plan_present,
            expected_packet_path,
        ),
        _checklist_item(
            "redrive_receipt_plan_present",
            True,
            receipt_plan_present,
            expected_receipt_path,
        ),
    ]
    if rejudge_required:
        checklist.append(
            _checklist_item(
                "referee_rejudge_provenance_plan_present",
                True,
                rejudge_plan_present,
                "Referee rejudge packets require explicit provenance plan.",
            )
        )
    checklist_required_count = sum(1 for item in checklist if item.get("required"))
    checklist_satisfied_count = sum(
        1 for item in checklist if item.get("required") and item.get("satisfied")
    )
    expected_file_creation = bool(
        provenance_record.get("expected_packet_file_creation_performed")
        or operator_data.get("expected_packet_file_creation_performed")
        or operator_data.get("source_packet_created_by_this_intake")
    )
    receipt_creation = bool(
        operator_data.get("redrive_receipt_creation_performed")
        or operator_data.get("redrive_execution_receipt_created_by_this_intake")
    )
    evidence_release = bool(
        provenance_record.get("evidence_release_performed")
        or operator_data.get("evidence_release_performed")
    )
    promoted = bool(
        provenance_record.get("repair_evidence_promoted")
        or operator_data.get("repair_evidence_promoted")
    )
    closure = bool(
        provenance_record.get("request_closure_performed")
        or operator_data.get("request_closure_performed")
    )
    consumable = bool(
        operator_data.get("consumable_as_repair_evidence")
        or operator_data.get("consumable_as_release_evidence")
        or operator_data.get("consumable_as_request_closure")
        or evidence_release
        or promoted
        or closure
        or expected_file_creation
        or receipt_creation
    )
    packet_valid = bool(
        packet_present
        and packet_json_ok
        and packet_schema_match
        and packet_binding_match
        and packet_hash_bound
        and packet_explicit
    )
    ready = bool(
        hash_bound
        and lint_ready
        and packet_valid
        and checklist_satisfied_count == checklist_required_count
        and not consumable
    )
    issues = []
    if not packet_present:
        issues.append("operator_real_source_intake_packet_missing")
    if packet_present and not packet_json_ok:
        issues.append("operator_real_source_intake_packet_json_error")
    if packet_present and packet_json_ok and not packet_schema_match:
        issues.append("operator_real_source_intake_packet_schema_mismatch")
    if packet_present and packet_json_ok and not packet_binding_match:
        issues.append("operator_real_source_intake_packet_binding_mismatch")
    if packet_present and packet_json_ok and not packet_hash_bound:
        issues.append("operator_real_source_intake_packet_hash_unbound")
    if packet_present and packet_json_ok and not packet_explicit:
        issues.append("operator_real_source_intake_packet_not_explicit")
    if not source_material_reference_present:
        issues.append("source_material_evidence_reference_missing")
    if not source_sha256_declared:
        issues.append("source_sha256_missing")
    if not source_packet_plan_present:
        issues.append("source_packet_authoring_plan_missing")
    if not receipt_plan_present:
        issues.append("redrive_receipt_plan_missing")
    if rejudge_required and not rejudge_plan_present:
        issues.append("referee_rejudge_provenance_plan_missing")
    if consumable:
        issues.append("operator_real_source_intake_action_or_evidence_leak")
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "operator_real_source_intake_checklist_id": (
            f"referee-repair-operator-real-source-intake-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "operator_real_source_intake_checklist_payload_sha256": payload_sha,
        "operator_real_source_intake_checklist_hash_bound": hash_bound,
        "operator_real_source_intake_checklist_lint_ready": lint_ready,
        "real_source_provenance_intake_payload_sha256": upstream_sha,
        "upstream_real_source_provenance_ready": bool(
            provenance_record.get("real_source_provenance_intake_ready")
        ),
        "expected_packet_path": expected_packet_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "required_packet_schema_id": required_schema_id,
        "expected_operator_real_source_intake_path": expected_intake_path,
        "operator_real_source_intake_packet_present": packet_present,
        "operator_real_source_intake_packet_json_ok": packet_json_ok,
        "operator_real_source_intake_packet_json_error": packet_json_error,
        "operator_real_source_intake_packet_schema_match": packet_schema_match,
        "operator_real_source_intake_packet_schema_mismatch": packet_schema_mismatch,
        "operator_real_source_intake_packet_binding_match": packet_binding_match,
        "operator_real_source_intake_packet_binding_mismatch": bool(
            packet_present and packet_json_ok and not packet_binding_match
        ),
        "operator_real_source_intake_packet_hash_bound": packet_hash_bound,
        "operator_real_source_intake_packet_explicit": packet_explicit,
        "operator_real_source_intake_packet_valid": packet_valid,
        "source_material_absence_ledger_entry": not source_material_reference_present,
        "source_material_evidence_reference_present": source_material_reference_present,
        "source_material_evidence_reference": source_material_reference,
        "source_sha256_declared": source_sha256_declared,
        "declared_source_sha256": source_sha256,
        "source_packet_authoring_plan_present": source_packet_plan_present,
        "redrive_receipt_plan_present": receipt_plan_present,
        "referee_rejudge_provenance_plan_required": rejudge_required,
        "referee_rejudge_provenance_plan_present": bool(
            rejudge_required and rejudge_plan_present
        ),
        "human_input_checklist": checklist,
        "human_input_checklist_required_count": checklist_required_count,
        "human_input_checklist_satisfied_count": checklist_satisfied_count,
        "human_input_checklist_missing_count": (
            checklist_required_count - checklist_satisfied_count
        ),
        "operator_real_source_intake_checklist_ready": ready,
        "operator_real_source_intake_checklist_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "operator real-source intake checklist is ready for source authoring review; do not release or close here"
            if ready
            else "provide explicit operator real-source intake packet with real material reference, source sha256, request binding, source-packet plan, receipt plan, and rejudge provenance when required"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, checklist_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in checklist_records
        if not item.get("operator_real_source_intake_checklist_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_intake_checklist_verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_intake_checklist_payload_sha256s": [
            item.get("operator_real_source_intake_checklist_payload_sha256")
            for item in checklist_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(checklist_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_intake_checklist_verifier_id": (
            f"referee-repair-request-operator-real-source-intake-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_intake_checklist_payload_sha256": payload_sha,
        "request_operator_real_source_intake_checklist_hash_bound": bool(
            payload_sha
            and all(
                item.get("operator_real_source_intake_checklist_hash_bound")
                for item in checklist_records
            )
        ),
        "request_operator_real_source_intake_checklist_lint_ready": bool(
            payload_sha
            and all(
                item.get("operator_real_source_intake_checklist_lint_ready")
                for item in checklist_records
            )
        ),
        "operator_real_source_intake_checklist_record_count": len(checklist_records),
        "operator_real_source_intake_checklist_ready_count": sum(
            1
            for item in checklist_records
            if item.get("operator_real_source_intake_checklist_ready")
        ),
        "request_operator_real_source_intake_checklist_ready": ready,
        "request_operator_real_source_intake_checklist_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_intake_checklist_records": checklist_records,
        "next_required_action": (
            "complete operator real-source intake checklist for blocked packet types"
            if blocked
            else "operator real-source intake checklist is ready for downstream source authoring review"
        ),
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_intake_checklist_verifier_capstone(
    real_source_provenance_intake_verifier_report,
    real_source_provenance_intake_verifier_ref=None,
    operator_real_source_intake_packet_inventory=None,
    label="",
    created_at="",
):
    real_source_provenance_intake_verifier_report = dict(
        real_source_provenance_intake_verifier_report or {}
    )
    real_source_provenance_intake_verifier_ref = dict(
        real_source_provenance_intake_verifier_ref or {}
    )
    operator_real_source_intake_packet_inventory = dict(
        operator_real_source_intake_packet_inventory or {}
    )
    upstream_summary = _summary(real_source_provenance_intake_verifier_report)
    request_provenance_records = [
        dict(item or {})
        for item in real_source_provenance_intake_verifier_report.get(
            "real_source_provenance_intake_verifier_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    provenance_records = [
        dict(record or {})
        for request_record in request_provenance_records
        for record in request_record.get("real_source_provenance_intake_records") or []
    ]
    upstream_report_valid = bool(
        real_source_provenance_intake_verifier_ref.get("path")
        and real_source_provenance_intake_verifier_ref.get("sha256_match")
        and real_source_provenance_intake_verifier_report
        and _status(
            real_source_provenance_intake_verifier_report,
            real_source_provenance_intake_verifier_ref,
        )
        in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get("request_real_source_provenance_intake_record_count")
        )
        == len(request_provenance_records)
        and all(
            request.get("request_real_source_provenance_intake_lint_ready")
            for request in request_provenance_records
        )
        and all(
            record.get("real_source_provenance_intake_lint_ready")
            for record in provenance_records
        )
    )
    request_records = []
    for request_record in sorted(
        request_provenance_records, key=lambda item: str(item.get("request_id"))
    ):
        checklist_records = []
        for provenance_record in request_record.get(
            "real_source_provenance_intake_records"
        ) or []:
            provenance_record = dict(provenance_record or {})
            expected_path = expected_operator_real_source_intake_path(
                provenance_record.get("expected_packet_path") or ""
            )
            checklist_records.append(
                _checklist_record(
                    provenance_record,
                    _slot_data(operator_real_source_intake_packet_inventory, expected_path),
                )
            )
        request_records.append(_request_record(request_record, checklist_records))
    checklist_records = [
        record
        for request_record in request_records
        for record in request_record.get("operator_real_source_intake_checklist_records")
        or []
    ]
    record_count = len(checklist_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_operator_real_source_intake_checklist_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1 for item in checklist_records if item.get("operator_real_source_intake_checklist_hash_bound")
    )
    lint_ready_count = sum(
        1 for item in checklist_records if item.get("operator_real_source_intake_checklist_lint_ready")
    )
    upstream_ready_count = sum(
        1 for item in checklist_records if item.get("upstream_real_source_provenance_ready")
    )
    packet_present_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_present"))
    packet_json_ok_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_json_ok"))
    packet_json_error_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_json_error"))
    packet_schema_match_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_schema_match"))
    packet_schema_mismatch_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_schema_mismatch"))
    packet_binding_match_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_binding_match"))
    packet_binding_mismatch_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_binding_mismatch"))
    packet_hash_bound_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_hash_bound"))
    packet_explicit_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_explicit"))
    packet_valid_count = sum(1 for item in checklist_records if item.get("operator_real_source_intake_packet_valid"))
    material_reference_count = sum(1 for item in checklist_records if item.get("source_material_evidence_reference_present"))
    source_sha_count = sum(1 for item in checklist_records if item.get("source_sha256_declared"))
    source_packet_plan_count = sum(1 for item in checklist_records if item.get("source_packet_authoring_plan_present"))
    receipt_plan_count = sum(1 for item in checklist_records if item.get("redrive_receipt_plan_present"))
    rejudge_required_count = sum(1 for item in checklist_records if item.get("referee_rejudge_provenance_plan_required"))
    rejudge_plan_count = sum(1 for item in checklist_records if item.get("referee_rejudge_provenance_plan_present"))
    checklist_required_count = sum(
        _int(item.get("human_input_checklist_required_count"))
        for item in checklist_records
    )
    checklist_satisfied_count = sum(
        _int(item.get("human_input_checklist_satisfied_count"))
        for item in checklist_records
    )
    expected_file_creation_count = sum(
        1 for item in checklist_records if item.get("expected_packet_file_creation_performed")
    )
    receipt_creation_count = sum(
        1 for item in checklist_records if item.get("redrive_receipt_creation_performed")
    )
    evidence_release_count = sum(
        1
        for item in checklist_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in checklist_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in checklist_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in checklist_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and packet_valid_count == record_count
        and checklist_satisfied_count == checklist_required_count
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "real_source_provenance_intake_verifier_available",
        upstream_report_valid,
        real_source_provenance_intake_verifier_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "real_source_provenance_intake_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(request_provenance_records)} records={len(provenance_records)}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_checklists_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_checklists_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packets_present",
        packet_present_count == record_count,
        f"present={packet_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packets_json_schema_ready",
        packet_json_ok_count == record_count and packet_schema_match_count == record_count,
        f"json_ok={packet_json_ok_count} schema_match={packet_schema_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packets_request_bound",
        packet_binding_match_count == record_count,
        f"binding={packet_binding_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packets_hash_bound_and_explicit",
        packet_hash_bound_count == record_count and packet_explicit_count == record_count,
        f"hash_bound={packet_hash_bound_count} explicit={packet_explicit_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_material_references_present",
        material_reference_count == record_count,
        f"material_refs={material_reference_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_sha256s_declared",
        source_sha_count == record_count,
        f"source_sha={source_sha_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_packet_and_receipt_plans_present",
        source_packet_plan_count == record_count and receipt_plan_count == record_count,
        f"source_packet_plan={source_packet_plan_count} receipt_plan={receipt_plan_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_referee_rejudge_provenance_plans_present",
        rejudge_plan_count == rejudge_required_count,
        f"rejudge_plan={rejudge_plan_count} required={rejudge_required_count}",
    )
    _add_check(
        checks,
        "all_human_input_checklists_complete",
        checklist_satisfied_count == checklist_required_count,
        f"satisfied={checklist_satisfied_count} required={checklist_required_count}",
    )
    _add_check(
        checks,
        "all_request_operator_real_source_intake_checklists_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "operator_real_source_intake_checklists_are_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} release={evidence_release_count} "
            f"promoted={promoted_count} closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_PROVENANCE_REPORT_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_UPSTREAM_LINT"
    elif packet_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_PACKET_MISSING"
    elif packet_json_ok_count != record_count or packet_schema_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_PACKET_JSON_SCHEMA"
    elif packet_binding_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_PACKET_BINDING"
    elif packet_hash_bound_count != record_count or packet_explicit_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_PACKET_NOT_EXPLICIT_OR_HASH_BOUND"
    elif material_reference_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_MATERIAL_REFERENCE_MISSING"
    elif source_sha_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_SOURCE_SHA256_MISSING"
    elif source_packet_plan_count != record_count or receipt_plan_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_SOURCE_OR_RECEIPT_PLAN_MISSING"
    elif rejudge_plan_count != rejudge_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_REFEREE_REJUDGE_PLAN_MISSING"
    elif expected_file_creation_count or receipt_creation_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_REQUEST_CHECKLIST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_CHECKLIST_VERIFIER"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_CHECKLIST_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_intake_checklist_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "real_source_provenance_intake_record_count": _int(
                upstream_summary.get("real_source_provenance_intake_record_count")
            ),
            "operator_real_source_intake_checklist_record_count": record_count,
            "hash_bound_operator_real_source_intake_checklist_count": hash_bound_count,
            "operator_real_source_intake_checklist_lint_ready_count": lint_ready_count,
            "upstream_real_source_provenance_ready_count": upstream_ready_count,
            "upstream_real_source_provenance_blocked_count": record_count
            - upstream_ready_count,
            "operator_real_source_intake_packet_required_count": record_count,
            "operator_real_source_intake_packet_present_count": packet_present_count,
            "operator_real_source_intake_packet_missing_count": record_count
            - packet_present_count,
            "operator_real_source_intake_packet_json_ok_count": packet_json_ok_count,
            "operator_real_source_intake_packet_json_error_count": packet_json_error_count,
            "operator_real_source_intake_packet_schema_match_count": packet_schema_match_count,
            "operator_real_source_intake_packet_schema_mismatch_count": packet_schema_mismatch_count,
            "operator_real_source_intake_packet_binding_match_count": packet_binding_match_count,
            "operator_real_source_intake_packet_binding_mismatch_count": packet_binding_mismatch_count,
            "operator_real_source_intake_packet_hash_bound_count": packet_hash_bound_count,
            "operator_real_source_intake_packet_hash_unbound_count": record_count
            - packet_hash_bound_count,
            "operator_real_source_intake_packet_explicit_count": packet_explicit_count,
            "operator_real_source_intake_packet_valid_count": packet_valid_count,
            "operator_real_source_intake_packet_invalid_count": record_count
            - packet_valid_count,
            "source_material_absence_ledger_entry_count": record_count
            - material_reference_count,
            "source_material_evidence_reference_present_count": material_reference_count,
            "source_material_evidence_reference_missing_count": record_count
            - material_reference_count,
            "source_sha256_declared_count": source_sha_count,
            "source_sha256_missing_count": record_count - source_sha_count,
            "source_packet_authoring_plan_present_count": source_packet_plan_count,
            "source_packet_authoring_plan_missing_count": record_count
            - source_packet_plan_count,
            "redrive_receipt_plan_present_count": receipt_plan_count,
            "redrive_receipt_plan_missing_count": record_count - receipt_plan_count,
            "referee_rejudge_provenance_plan_required_count": rejudge_required_count,
            "referee_rejudge_provenance_plan_present_count": rejudge_plan_count,
            "referee_rejudge_provenance_plan_missing_count": rejudge_required_count
            - rejudge_plan_count,
            "human_input_checklist_required_count": checklist_required_count,
            "human_input_checklist_satisfied_count": checklist_satisfied_count,
            "human_input_checklist_missing_count": checklist_required_count
            - checklist_satisfied_count,
            "request_operator_real_source_intake_checklist_record_count": request_count,
            "request_operator_real_source_intake_checklist_ready_count": request_ready_count,
            "request_operator_real_source_intake_checklist_blocked_count": request_blocked_count,
            "proof_status_operator_real_source_intake_required_count": _count(
                checklist_records, "proof_status"
            ),
            "proof_status_operator_real_source_intake_ready_count": _count(
                checklist_records,
                "proof_status",
                "operator_real_source_intake_checklist_ready",
            ),
            "evidence_manifest_operator_real_source_intake_required_count": _count(
                checklist_records, "evidence_manifest"
            ),
            "evidence_manifest_operator_real_source_intake_ready_count": _count(
                checklist_records,
                "evidence_manifest",
                "operator_real_source_intake_checklist_ready",
            ),
            "appendix_supplement_operator_real_source_intake_required_count": _count(
                checklist_records, "appendix_supplement"
            ),
            "appendix_supplement_operator_real_source_intake_ready_count": _count(
                checklist_records,
                "appendix_supplement",
                "operator_real_source_intake_checklist_ready",
            ),
            "claim_downgrade_operator_real_source_intake_required_count": _count(
                checklist_records, "claim_downgrade"
            ),
            "claim_downgrade_operator_real_source_intake_ready_count": _count(
                checklist_records,
                "claim_downgrade",
                "operator_real_source_intake_checklist_ready",
            ),
            "referee_rejudge_operator_real_source_intake_required_count": _count(
                checklist_records, "referee_rejudge"
            ),
            "referee_rejudge_operator_real_source_intake_ready_count": _count(
                checklist_records,
                "referee_rejudge",
                "operator_real_source_intake_checklist_ready",
            ),
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_intake_checklist_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_intake_checklist_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies operator real-source intake checklist packets and records source-material absence.",
            "Operator real-source intake checklist records and absence-ledger entries are not source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready operator real-source intake checklist still does not write source packets, write receipts, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Operator Real-Source Intake Checklist Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_intake_checklist_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
