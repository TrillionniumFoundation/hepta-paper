"""Operator real-source intake packet template/spec verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-operator-real-source-intake-"
    "packet-template-spec-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_intake_packet_template_spec_verifier_capstone.v1"
)
OPERATOR_INTAKE_PACKET_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_operator_real_source_intake_packet.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_operator_real_source_intake_packet_template_spec_verifier_state",
    "report_schema",
    "summary",
    "operator_real_source_intake_packet_template_spec_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "operator_real_source_intake_checklist_record_count",
    "operator_real_source_intake_packet_template_spec_record_count",
    "hash_bound_operator_real_source_intake_packet_template_spec_count",
    "operator_real_source_intake_packet_template_spec_lint_ready_count",
    "upstream_operator_real_source_intake_checklist_ready_count",
    "upstream_operator_real_source_intake_checklist_blocked_count",
    "operator_real_source_intake_packet_required_count",
    "operator_real_source_intake_packet_present_count",
    "operator_real_source_intake_packet_missing_count",
    "operator_real_source_intake_packet_valid_count",
    "operator_real_source_intake_packet_invalid_count",
    "required_template_field_count",
    "required_template_field_verified_count",
    "required_template_field_missing_count",
    "human_input_manifest_entry_count",
    "human_input_manifest_required_count",
    "human_input_manifest_satisfied_count",
    "human_input_manifest_missing_count",
    "source_material_provenance_handoff_quarantine_record_count",
    "source_material_provenance_handoff_ready_count",
    "source_material_provenance_handoff_blocked_count",
    "source_material_evidence_reference_present_count",
    "source_material_evidence_reference_missing_count",
    "source_sha256_declared_count",
    "source_sha256_missing_count",
    "source_packet_authoring_plan_present_count",
    "source_packet_authoring_plan_missing_count",
    "redrive_receipt_plan_present_count",
    "redrive_receipt_plan_missing_count",
    "referee_rejudge_provenance_plan_required_count",
    "referee_rejudge_provenance_plan_present_count",
    "referee_rejudge_provenance_plan_missing_count",
    "request_operator_real_source_intake_packet_template_spec_record_count",
    "request_operator_real_source_intake_packet_template_spec_ready_count",
    "request_operator_real_source_intake_packet_template_spec_blocked_count",
    "proof_status_operator_real_source_intake_template_spec_required_count",
    "proof_status_operator_real_source_intake_template_spec_ready_count",
    "evidence_manifest_operator_real_source_intake_template_spec_required_count",
    "evidence_manifest_operator_real_source_intake_template_spec_ready_count",
    "appendix_supplement_operator_real_source_intake_template_spec_required_count",
    "appendix_supplement_operator_real_source_intake_template_spec_ready_count",
    "claim_downgrade_operator_real_source_intake_template_spec_required_count",
    "claim_downgrade_operator_real_source_intake_template_spec_ready_count",
    "referee_rejudge_operator_real_source_intake_template_spec_required_count",
    "referee_rejudge_operator_real_source_intake_template_spec_ready_count",
    "expected_packet_file_creation_performed_count",
    "redrive_receipt_creation_performed_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "operator_real_source_intake_packet_template_spec_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def _template_field(name, required_value="", required=True):
    return {
        "name": name,
        "required": bool(required),
        "required_value": required_value,
        "verified_in_template_spec": bool(name and (required_value != "" or required)),
    }


def _required_template_fields(checklist_record):
    fields = [
        _template_field("schema_id", OPERATOR_INTAKE_PACKET_SCHEMA_ID),
        _template_field("request_id", checklist_record.get("request_id")),
        _template_field("slug", checklist_record.get("slug") or ""),
        _template_field("packet_type", checklist_record.get("packet_type") or ""),
        _template_field(
            "expected_packet_path",
            checklist_record.get("expected_packet_path") or "",
        ),
        _template_field(
            "required_packet_schema_id",
            checklist_record.get("required_packet_schema_id") or "",
        ),
        _template_field(
            "real_source_provenance_intake_payload_sha256",
            checklist_record.get("real_source_provenance_intake_payload_sha256") or "",
        ),
        _template_field("operator_real_source_intake_packet_hash_bound", True),
        _template_field("explicit_operator_real_source_intake", True),
        _template_field("operator_confirms_real_source_material", True),
        _template_field(
            "real_source_material_evidence_path",
            "real request-specific source material reference required",
        ),
        _template_field(
            "request_specific_source_sha256",
            "sha256 of real request-specific source material required",
        ),
        _template_field(
            "source_packet_authoring_plan",
            checklist_record.get("expected_packet_path") or "",
        ),
        _template_field(
            "redrive_receipt_plan",
            checklist_record.get("expected_redrive_execution_receipt_path") or "",
        ),
    ]
    if checklist_record.get("packet_type") == "referee_rejudge":
        fields.append(
            _template_field(
                "referee_rejudge_provenance_plan",
                "explicit referee rejudge provenance plan required",
            )
        )
    return fields


def _human_manifest_entries(checklist_record, spec_sha):
    entries = []
    for index, item in enumerate(checklist_record.get("human_input_checklist") or [], 1):
        item = dict(item or {})
        name = item.get("name") or f"human_input_{index}"
        entry_payload = {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_human_input_manifest_entry.v1"
            ),
            "operator_real_source_intake_packet_template_spec_payload_sha256": spec_sha,
            "name": name,
            "required": bool(item.get("required")),
        }
        entry_sha = _sha(entry_payload)
        entries.append(
            {
                "human_input_manifest_entry_id": (
                    f"operator-real-source-human-input-{entry_sha[:16]}"
                ),
                "human_input_manifest_entry_payload_sha256": entry_sha,
                "name": name,
                "required": bool(item.get("required")),
                "satisfied": bool(item.get("satisfied")),
                "missing": bool(item.get("required") and not item.get("satisfied")),
                "detail": item.get("detail") or "",
                "source_checklist_item": name,
                "consumable_as_repair_evidence": False,
                "consumable_as_release_evidence": False,
                "consumable_as_request_closure": False,
            }
        )
    return entries


def _template_spec_record(checklist_record):
    checklist_record = dict(checklist_record or {})
    request_id = checklist_record.get("request_id")
    slug = checklist_record.get("slug") or ""
    packet_type = checklist_record.get("packet_type") or ""
    expected_packet_path = checklist_record.get("expected_packet_path") or ""
    expected_receipt_path = (
        checklist_record.get("expected_redrive_execution_receipt_path") or ""
    )
    expected_intake_path = (
        checklist_record.get("expected_operator_real_source_intake_path") or ""
    )
    upstream_sha = (
        checklist_record.get("operator_real_source_intake_checklist_payload_sha256")
        or ""
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_operator_real_source_intake_packet_template_spec_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_packet_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "expected_operator_real_source_intake_path": expected_intake_path,
        "operator_real_source_intake_checklist_payload_sha256": upstream_sha,
    }
    payload_sha = _sha(payload)
    required_fields = _required_template_fields(checklist_record)
    required_field_count = sum(1 for item in required_fields if item.get("required"))
    verified_field_count = sum(
        1
        for item in required_fields
        if item.get("required") and item.get("verified_in_template_spec")
    )
    manifest_entries = _human_manifest_entries(checklist_record, payload_sha)
    manifest_required_count = sum(1 for item in manifest_entries if item.get("required"))
    manifest_satisfied_count = sum(
        1 for item in manifest_entries if item.get("required") and item.get("satisfied")
    )
    packet_present = bool(checklist_record.get("operator_real_source_intake_packet_present"))
    packet_valid = bool(checklist_record.get("operator_real_source_intake_packet_valid"))
    material_ref = bool(
        checklist_record.get("source_material_evidence_reference_present")
    )
    source_sha = bool(checklist_record.get("source_sha256_declared"))
    source_plan = bool(checklist_record.get("source_packet_authoring_plan_present"))
    receipt_plan = bool(checklist_record.get("redrive_receipt_plan_present"))
    rejudge_required = packet_type == "referee_rejudge"
    rejudge_plan = bool(
        not rejudge_required
        or checklist_record.get("referee_rejudge_provenance_plan_present")
    )
    handoff_ready = bool(
        packet_valid
        and material_ref
        and source_sha
        and source_plan
        and receipt_plan
        and rejudge_plan
        and manifest_required_count == manifest_satisfied_count
    )
    expected_file_creation = bool(
        checklist_record.get("expected_packet_file_creation_performed")
    )
    receipt_creation = bool(checklist_record.get("redrive_receipt_creation_performed"))
    evidence_release = bool(checklist_record.get("evidence_release_performed"))
    promoted = bool(checklist_record.get("repair_evidence_promoted"))
    closure = bool(checklist_record.get("request_closure_performed"))
    consumable = bool(
        checklist_record.get("consumable_as_repair_evidence")
        or checklist_record.get("consumable_as_release_evidence")
        or checklist_record.get("consumable_as_request_closure")
        or expected_file_creation
        or receipt_creation
        or evidence_release
        or promoted
        or closure
    )
    lint_ready = bool(
        request_id is not None
        and slug
        and packet_type
        and expected_packet_path
        and expected_receipt_path
        and expected_intake_path
        and upstream_sha
        and payload_sha
        and checklist_record.get("operator_real_source_intake_checklist_lint_ready")
        and required_field_count == verified_field_count
        and manifest_entries
    )
    hash_bound = bool(
        payload_sha
        and checklist_record.get("operator_real_source_intake_checklist_hash_bound")
    )
    template_spec_verified = bool(
        hash_bound
        and lint_ready
        and required_field_count == verified_field_count
    )
    ready = bool(
        template_spec_verified
        and packet_present
        and packet_valid
        and handoff_ready
        and not consumable
    )
    issues = []
    if not template_spec_verified:
        issues.append("operator_real_source_intake_packet_template_spec_unverified")
    if not packet_present:
        issues.append("operator_real_source_intake_packet_missing")
    if packet_present and not packet_valid:
        issues.append("operator_real_source_intake_packet_invalid")
    if manifest_required_count != manifest_satisfied_count:
        issues.append("human_input_manifest_incomplete")
    if not handoff_ready:
        issues.append("source_material_provenance_handoff_quarantined")
    if consumable:
        issues.append("operator_real_source_intake_template_spec_action_or_evidence_leak")
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "operator_real_source_intake_packet_template_spec_id": (
            f"referee-repair-operator-real-source-intake-template-spec-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "operator_real_source_intake_packet_template_spec_payload_sha256": payload_sha,
        "operator_real_source_intake_packet_template_spec_hash_bound": hash_bound,
        "operator_real_source_intake_packet_template_spec_lint_ready": lint_ready,
        "operator_real_source_intake_packet_template_spec_verified": template_spec_verified,
        "operator_real_source_intake_checklist_payload_sha256": upstream_sha,
        "expected_operator_real_source_intake_path": expected_intake_path,
        "operator_real_source_intake_packet_schema_id": OPERATOR_INTAKE_PACKET_SCHEMA_ID,
        "expected_packet_path": expected_packet_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "required_packet_schema_id": checklist_record.get("required_packet_schema_id") or "",
        "required_template_fields": required_fields,
        "required_template_field_count": required_field_count,
        "required_template_field_verified_count": verified_field_count,
        "required_template_field_missing_count": required_field_count
        - verified_field_count,
        "operator_real_source_intake_packet_present": packet_present,
        "operator_real_source_intake_packet_valid": packet_valid,
        "human_input_manifest_entries": manifest_entries,
        "human_input_manifest_entry_count": len(manifest_entries),
        "human_input_manifest_required_count": manifest_required_count,
        "human_input_manifest_satisfied_count": manifest_satisfied_count,
        "human_input_manifest_missing_count": manifest_required_count
        - manifest_satisfied_count,
        "source_material_provenance_handoff_quarantine": {
            "schema_id": (
                "paper_factory.paper_production."
                "referee_repair_packet_source_material_provenance_handoff_quarantine.v1"
            ),
            "quarantine_id": (
                f"referee-repair-source-material-handoff-quarantine-{request_id}-{packet_type}-{payload_sha[:16]}"
            ),
            "quarantined": not handoff_ready,
            "handoff_ready": handoff_ready,
            "release_allowed": False,
            "request_closure_allowed": False,
            "detail": (
                "Source-material handoff is quarantined until explicit operator intake packet and human-input manifest are complete."
            ),
        },
        "source_material_provenance_handoff_ready": handoff_ready,
        "source_material_evidence_reference_present": material_ref,
        "source_sha256_declared": source_sha,
        "source_packet_authoring_plan_present": source_plan,
        "redrive_receipt_plan_present": receipt_plan,
        "referee_rejudge_provenance_plan_required": rejudge_required,
        "referee_rejudge_provenance_plan_present": bool(
            rejudge_required and rejudge_plan
        ),
        "operator_real_source_intake_packet_template_spec_ready": ready,
        "operator_real_source_intake_packet_template_spec_blockers": issues,
        "expected_packet_file_creation_performed": expected_file_creation,
        "redrive_receipt_creation_performed": receipt_creation,
        "evidence_release_performed": evidence_release,
        "repair_evidence_promoted": promoted,
        "request_closure_performed": closure,
        "next_required_action": (
            "operator intake template/spec is ready for downstream source-material review; do not release or close here"
            if ready
            else "complete explicit operator intake packet and all human-input manifest entries before any source authoring handoff"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, spec_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in spec_records
        if not item.get("operator_real_source_intake_packet_template_spec_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_operator_real_source_intake_packet_template_spec_verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "operator_real_source_intake_packet_template_spec_payload_sha256s": [
            item.get("operator_real_source_intake_packet_template_spec_payload_sha256")
            for item in spec_records
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(spec_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_operator_real_source_intake_packet_template_spec_verifier_id": (
            f"referee-repair-request-operator-real-source-intake-template-spec-{request_id}-{payload_sha[:16]}"
        ),
        "request_operator_real_source_intake_packet_template_spec_payload_sha256": payload_sha,
        "request_operator_real_source_intake_packet_template_spec_hash_bound": bool(
            payload_sha
            and all(
                item.get("operator_real_source_intake_packet_template_spec_hash_bound")
                for item in spec_records
            )
        ),
        "request_operator_real_source_intake_packet_template_spec_lint_ready": bool(
            payload_sha
            and all(
                item.get("operator_real_source_intake_packet_template_spec_lint_ready")
                for item in spec_records
            )
        ),
        "operator_real_source_intake_packet_template_spec_record_count": len(spec_records),
        "operator_real_source_intake_packet_template_spec_ready_count": sum(
            1
            for item in spec_records
            if item.get("operator_real_source_intake_packet_template_spec_ready")
        ),
        "request_operator_real_source_intake_packet_template_spec_ready": ready,
        "request_operator_real_source_intake_packet_template_spec_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "operator_real_source_intake_packet_template_spec_records": spec_records,
        "next_required_action": (
            "complete operator intake packet template/spec manifest for blocked packet types"
            if blocked
            else "operator intake packet template/spec is ready for downstream source-material handoff review"
        ),
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_operator_real_source_intake_packet_template_spec_verifier_capstone(
    operator_real_source_intake_checklist_verifier_report,
    operator_real_source_intake_checklist_verifier_ref=None,
    label="",
    created_at="",
):
    operator_real_source_intake_checklist_verifier_report = dict(
        operator_real_source_intake_checklist_verifier_report or {}
    )
    operator_real_source_intake_checklist_verifier_ref = dict(
        operator_real_source_intake_checklist_verifier_ref or {}
    )
    upstream_summary = _summary(operator_real_source_intake_checklist_verifier_report)
    request_checklist_records = [
        dict(item or {})
        for item in operator_real_source_intake_checklist_verifier_report.get(
            "operator_real_source_intake_checklist_verifier_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    checklist_records = [
        dict(record or {})
        for request_record in request_checklist_records
        for record in request_record.get("operator_real_source_intake_checklist_records")
        or []
    ]
    upstream_report_valid = bool(
        operator_real_source_intake_checklist_verifier_ref.get("path")
        and operator_real_source_intake_checklist_verifier_ref.get("sha256_match")
        and operator_real_source_intake_checklist_verifier_report
        and _status(
            operator_real_source_intake_checklist_verifier_report,
            operator_real_source_intake_checklist_verifier_ref,
        )
        in {"PASS", "FAIL"}
    )
    upstream_lint_ready = bool(
        upstream_report_valid
        and _int(
            upstream_summary.get(
                "request_operator_real_source_intake_checklist_record_count"
            )
        )
        == len(request_checklist_records)
        and all(
            request.get("request_operator_real_source_intake_checklist_lint_ready")
            for request in request_checklist_records
        )
        and all(
            record.get("operator_real_source_intake_checklist_lint_ready")
            for record in checklist_records
        )
    )
    request_records = []
    for request_record in sorted(
        request_checklist_records, key=lambda item: str(item.get("request_id"))
    ):
        spec_records = [
            _template_spec_record(dict(record or {}))
            for record in request_record.get(
                "operator_real_source_intake_checklist_records"
            )
            or []
        ]
        request_records.append(_request_record(request_record, spec_records))
    spec_records = [
        record
        for request_record in request_records
        for record in request_record.get(
            "operator_real_source_intake_packet_template_spec_records"
        )
        or []
    ]
    record_count = len(spec_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_operator_real_source_intake_packet_template_spec_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1 for item in spec_records if item.get("operator_real_source_intake_packet_template_spec_hash_bound")
    )
    lint_ready_count = sum(
        1 for item in spec_records if item.get("operator_real_source_intake_packet_template_spec_lint_ready")
    )
    upstream_ready_count = sum(
        1 for item in checklist_records if item.get("operator_real_source_intake_checklist_ready")
    )
    packet_present_count = sum(1 for item in spec_records if item.get("operator_real_source_intake_packet_present"))
    packet_valid_count = sum(1 for item in spec_records if item.get("operator_real_source_intake_packet_valid"))
    template_verified_count = sum(
        1 for item in spec_records if item.get("operator_real_source_intake_packet_template_spec_verified")
    )
    template_field_count = sum(_int(item.get("required_template_field_count")) for item in spec_records)
    template_field_verified_count = sum(_int(item.get("required_template_field_verified_count")) for item in spec_records)
    manifest_entry_count = sum(_int(item.get("human_input_manifest_entry_count")) for item in spec_records)
    manifest_required_count = sum(_int(item.get("human_input_manifest_required_count")) for item in spec_records)
    manifest_satisfied_count = sum(_int(item.get("human_input_manifest_satisfied_count")) for item in spec_records)
    handoff_ready_count = sum(1 for item in spec_records if item.get("source_material_provenance_handoff_ready"))
    material_ref_count = sum(1 for item in spec_records if item.get("source_material_evidence_reference_present"))
    source_sha_count = sum(1 for item in spec_records if item.get("source_sha256_declared"))
    source_plan_count = sum(1 for item in spec_records if item.get("source_packet_authoring_plan_present"))
    receipt_plan_count = sum(1 for item in spec_records if item.get("redrive_receipt_plan_present"))
    rejudge_required_count = sum(1 for item in spec_records if item.get("referee_rejudge_provenance_plan_required"))
    rejudge_plan_count = sum(1 for item in spec_records if item.get("referee_rejudge_provenance_plan_present"))
    expected_file_creation_count = sum(1 for item in spec_records if item.get("expected_packet_file_creation_performed"))
    receipt_creation_count = sum(1 for item in spec_records if item.get("redrive_receipt_creation_performed"))
    evidence_release_count = sum(
        1
        for item in spec_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in spec_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in spec_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in spec_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
        or item.get("redrive_receipt_creation_performed")
    )
    ready = bool(
        upstream_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and template_verified_count == record_count
        and packet_present_count == record_count
        and packet_valid_count == record_count
        and template_field_verified_count == template_field_count
        and manifest_satisfied_count == manifest_required_count
        and handoff_ready_count == record_count
        and request_blocked_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "operator_real_source_intake_checklist_verifier_available",
        upstream_report_valid,
        operator_real_source_intake_checklist_verifier_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "operator_real_source_intake_checklist_verifier_lint_ready",
        upstream_lint_ready,
        f"requests={len(request_checklist_records)} records={len(checklist_records)}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packet_template_specs_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packet_template_specs_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packet_template_specs_verified",
        template_verified_count == record_count,
        f"verified={template_verified_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packets_present",
        packet_present_count == record_count,
        f"present={packet_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_real_source_intake_packets_valid",
        packet_valid_count == record_count,
        f"valid={packet_valid_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_required_template_fields_verified",
        template_field_verified_count == template_field_count,
        f"verified={template_field_verified_count} required={template_field_count}",
    )
    _add_check(
        checks,
        "all_human_input_manifest_entries_satisfied",
        manifest_satisfied_count == manifest_required_count,
        f"satisfied={manifest_satisfied_count} required={manifest_required_count}",
    )
    _add_check(
        checks,
        "all_source_material_provenance_handoffs_ready",
        handoff_ready_count == record_count,
        f"handoff_ready={handoff_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_operator_real_source_intake_packet_template_specs_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "operator_real_source_intake_packet_template_specs_are_not_source_receipt_release_or_closure_evidence",
        consumable_count == 0
        and expected_file_creation_count == 0
        and receipt_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"source_creation={expected_file_creation_count} "
            f"receipt_creation={receipt_creation_count} release={evidence_release_count} "
            f"promoted={promoted_count} closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not upstream_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_UPSTREAM_MISSING"
    elif not upstream_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_UPSTREAM_LINT"
    elif template_verified_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_UNVERIFIED"
    elif packet_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_PACKET_MISSING"
    elif packet_valid_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_PACKET_INVALID"
    elif manifest_satisfied_count != manifest_required_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_HUMAN_MANIFEST_INCOMPLETE"
    elif handoff_ready_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_HANDOFF_QUARANTINED"
    elif expected_file_creation_count or receipt_creation_count or evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_REQUEST"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_VERIFIER"
    else:
        state = "REFEREE_REPAIR_OPERATOR_REAL_SOURCE_INTAKE_TEMPLATE_SPEC_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_operator_real_source_intake_packet_template_spec_verifier_state": state,
        "summary": {
            "open_request_count": _int(upstream_summary.get("open_request_count")),
            "operator_real_source_intake_checklist_record_count": _int(
                upstream_summary.get("operator_real_source_intake_checklist_record_count")
            ),
            "operator_real_source_intake_packet_template_spec_record_count": record_count,
            "hash_bound_operator_real_source_intake_packet_template_spec_count": hash_bound_count,
            "operator_real_source_intake_packet_template_spec_lint_ready_count": lint_ready_count,
            "upstream_operator_real_source_intake_checklist_ready_count": upstream_ready_count,
            "upstream_operator_real_source_intake_checklist_blocked_count": record_count
            - upstream_ready_count,
            "operator_real_source_intake_packet_required_count": record_count,
            "operator_real_source_intake_packet_present_count": packet_present_count,
            "operator_real_source_intake_packet_missing_count": record_count
            - packet_present_count,
            "operator_real_source_intake_packet_valid_count": packet_valid_count,
            "operator_real_source_intake_packet_invalid_count": record_count
            - packet_valid_count,
            "required_template_field_count": template_field_count,
            "required_template_field_verified_count": template_field_verified_count,
            "required_template_field_missing_count": template_field_count
            - template_field_verified_count,
            "human_input_manifest_entry_count": manifest_entry_count,
            "human_input_manifest_required_count": manifest_required_count,
            "human_input_manifest_satisfied_count": manifest_satisfied_count,
            "human_input_manifest_missing_count": manifest_required_count
            - manifest_satisfied_count,
            "source_material_provenance_handoff_quarantine_record_count": record_count,
            "source_material_provenance_handoff_ready_count": handoff_ready_count,
            "source_material_provenance_handoff_blocked_count": record_count
            - handoff_ready_count,
            "source_material_evidence_reference_present_count": material_ref_count,
            "source_material_evidence_reference_missing_count": record_count
            - material_ref_count,
            "source_sha256_declared_count": source_sha_count,
            "source_sha256_missing_count": record_count - source_sha_count,
            "source_packet_authoring_plan_present_count": source_plan_count,
            "source_packet_authoring_plan_missing_count": record_count
            - source_plan_count,
            "redrive_receipt_plan_present_count": receipt_plan_count,
            "redrive_receipt_plan_missing_count": record_count - receipt_plan_count,
            "referee_rejudge_provenance_plan_required_count": rejudge_required_count,
            "referee_rejudge_provenance_plan_present_count": rejudge_plan_count,
            "referee_rejudge_provenance_plan_missing_count": rejudge_required_count
            - rejudge_plan_count,
            "request_operator_real_source_intake_packet_template_spec_record_count": request_count,
            "request_operator_real_source_intake_packet_template_spec_ready_count": request_ready_count,
            "request_operator_real_source_intake_packet_template_spec_blocked_count": request_blocked_count,
            "proof_status_operator_real_source_intake_template_spec_required_count": _count(
                spec_records, "proof_status"
            ),
            "proof_status_operator_real_source_intake_template_spec_ready_count": _count(
                spec_records,
                "proof_status",
                "operator_real_source_intake_packet_template_spec_ready",
            ),
            "evidence_manifest_operator_real_source_intake_template_spec_required_count": _count(
                spec_records, "evidence_manifest"
            ),
            "evidence_manifest_operator_real_source_intake_template_spec_ready_count": _count(
                spec_records,
                "evidence_manifest",
                "operator_real_source_intake_packet_template_spec_ready",
            ),
            "appendix_supplement_operator_real_source_intake_template_spec_required_count": _count(
                spec_records, "appendix_supplement"
            ),
            "appendix_supplement_operator_real_source_intake_template_spec_ready_count": _count(
                spec_records,
                "appendix_supplement",
                "operator_real_source_intake_packet_template_spec_ready",
            ),
            "claim_downgrade_operator_real_source_intake_template_spec_required_count": _count(
                spec_records, "claim_downgrade"
            ),
            "claim_downgrade_operator_real_source_intake_template_spec_ready_count": _count(
                spec_records,
                "claim_downgrade",
                "operator_real_source_intake_packet_template_spec_ready",
            ),
            "referee_rejudge_operator_real_source_intake_template_spec_required_count": _count(
                spec_records, "referee_rejudge"
            ),
            "referee_rejudge_operator_real_source_intake_template_spec_ready_count": _count(
                spec_records,
                "referee_rejudge",
                "operator_real_source_intake_packet_template_spec_ready",
            ),
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "redrive_receipt_creation_performed_count": receipt_creation_count,
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "operator_real_source_intake_packet_template_spec_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "operator_real_source_intake_packet_template_spec_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies operator real-source intake packet template/spec records, human-input manifests, and source-material handoff quarantine records.",
            "Template/spec records, human-input manifest entries, and handoff quarantine entries are not operator intake packets, source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready template/spec still does not write operator intake packets, write source packets, write receipts, release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes operator intake packets, source packets, receipts, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Operator Real-Source Intake Packet Template Spec Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_operator_real_source_intake_packet_template_spec_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
