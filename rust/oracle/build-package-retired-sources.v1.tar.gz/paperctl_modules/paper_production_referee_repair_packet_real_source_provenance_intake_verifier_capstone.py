"""Real-source provenance intake verifier for referee repair packets."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-real-source-provenance-intake-"
    "verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_real_source_provenance_intake_verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_real_source_provenance_intake_verifier_state",
    "report_schema",
    "summary",
    "real_source_provenance_intake_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "source_authoring_prerequisite_template_record_count",
    "source_slot_fulfillment_record_count",
    "real_source_provenance_intake_record_count",
    "hash_bound_real_source_provenance_intake_count",
    "real_source_provenance_intake_lint_ready_count",
    "template_record_present_count",
    "template_record_missing_count",
    "fulfillment_record_present_count",
    "fulfillment_record_missing_count",
    "prerequisite_template_verified_count",
    "prerequisite_template_unverified_count",
    "real_source_material_present_count",
    "real_source_material_missing_count",
    "source_packet_present_count",
    "source_packet_missing_count",
    "source_packet_json_ok_count",
    "source_packet_json_error_count",
    "source_packet_schema_match_count",
    "source_packet_schema_mismatch_count",
    "source_sha256_present_count",
    "source_sha256_missing_count",
    "source_hash_bound_count",
    "source_hash_unbound_count",
    "request_binding_present_count",
    "request_binding_missing_count",
    "request_binding_match_count",
    "request_binding_mismatch_count",
    "redrive_receipt_present_count",
    "redrive_receipt_missing_count",
    "redrive_receipt_schema_match_count",
    "redrive_receipt_schema_mismatch_count",
    "redrive_receipt_binding_match_count",
    "redrive_receipt_binding_mismatch_count",
    "redrive_receipt_performed_count",
    "redrive_receipt_not_performed_count",
    "referee_rejudge_provenance_required_count",
    "referee_rejudge_provenance_ready_count",
    "referee_rejudge_provenance_missing_count",
    "redrive_execution_performed_count",
    "expected_packet_file_creation_performed_count",
    "request_real_source_provenance_intake_record_count",
    "request_real_source_provenance_intake_ready_count",
    "request_real_source_provenance_intake_blocked_count",
    "proof_status_real_source_provenance_required_count",
    "proof_status_real_source_provenance_ready_count",
    "evidence_manifest_real_source_provenance_required_count",
    "evidence_manifest_real_source_provenance_ready_count",
    "appendix_supplement_real_source_provenance_required_count",
    "appendix_supplement_real_source_provenance_ready_count",
    "claim_downgrade_real_source_provenance_required_count",
    "claim_downgrade_real_source_provenance_ready_count",
    "referee_rejudge_real_source_provenance_required_count",
    "referee_rejudge_real_source_provenance_ready_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "real_source_provenance_intake_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _key(record):
    return (
        str(record.get("request_id")),
        record.get("slug") or "",
        record.get("packet_type") or "",
        record.get("expected_packet_path") or "",
    )


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def _provenance_record(template_record, fulfillment_record):
    template_record = dict(template_record or {})
    fulfillment_record = dict(fulfillment_record or {})
    request_id = template_record.get("request_id")
    slug = template_record.get("slug") or ""
    packet_type = template_record.get("packet_type") or ""
    expected_path = template_record.get("expected_packet_path") or ""
    expected_receipt_path = (
        template_record.get("expected_redrive_execution_receipt_path") or ""
    )
    required_schema = (
        template_record.get("required_packet_schema_id")
        or fulfillment_record.get("required_packet_schema_id")
        or ""
    )
    template_sha = (
        template_record.get("source_authoring_prerequisite_template_payload_sha256")
        or ""
    )
    fulfillment_sha = (
        fulfillment_record.get("source_slot_fulfillment_intake_payload_sha256") or ""
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_real_source_provenance_intake_verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "source_authoring_prerequisite_template_payload_sha256": template_sha,
        "source_slot_fulfillment_intake_payload_sha256": fulfillment_sha,
    }
    payload_sha = _sha(payload)
    template_present = bool(template_record)
    fulfillment_present = bool(fulfillment_record)
    fulfillment_path_match = bool(
        fulfillment_present
        and fulfillment_record.get("expected_packet_path") == expected_path
        and fulfillment_record.get("expected_redrive_execution_receipt_path")
        == expected_receipt_path
        and fulfillment_record.get("request_id") == request_id
        and (fulfillment_record.get("slug") or "") == slug
        and (fulfillment_record.get("packet_type") or "") == packet_type
    )
    template_verified = bool(
        template_present
        and template_record.get("source_authoring_prerequisite_template_hash_bound")
        and template_record.get("source_authoring_prerequisite_template_lint_ready")
        and template_record.get("source_packet_template_verified")
        and template_record.get("redrive_receipt_template_verified")
        and template_record.get("required_packet_schema_verified")
        and expected_path
        and expected_receipt_path
        and required_schema
    )
    source_packet_present = bool(fulfillment_record.get("source_slot_present"))
    source_json_ok = bool(fulfillment_record.get("source_slot_json_ok"))
    source_json_error = bool(fulfillment_record.get("source_slot_json_error"))
    source_schema_match = bool(fulfillment_record.get("source_slot_schema_match"))
    source_schema_mismatch = bool(
        fulfillment_record.get("source_slot_schema_mismatch")
        or (source_packet_present and source_json_ok and not source_schema_match)
    )
    real_source_material_present = bool(
        template_record.get("real_source_material_present") and source_packet_present
    )
    source_sha256_present = bool(
        template_record.get("source_sha256_present")
        and fulfillment_record.get("source_hash_present")
    )
    source_hash_bound = bool(fulfillment_record.get("source_hash_bound"))
    request_binding_present = bool(template_record.get("request_binding_present"))
    request_binding_match = bool(
        request_binding_present and fulfillment_record.get("request_binding_match")
    )
    schema_packet_json_ok = bool(
        template_record.get("schema_packet_present")
        and source_packet_present
        and source_json_ok
        and source_schema_match
    )
    receipt_present = bool(fulfillment_record.get("redrive_execution_receipt_present"))
    receipt_schema_match = bool(
        fulfillment_record.get("redrive_execution_receipt_schema_match")
    )
    receipt_schema_mismatch = bool(
        fulfillment_record.get("redrive_execution_receipt_schema_mismatch")
        or (receipt_present and not receipt_schema_match)
    )
    receipt_binding_match = bool(
        fulfillment_record.get("redrive_execution_receipt_binding_match")
    )
    receipt_binding_mismatch = bool(
        fulfillment_record.get("redrive_execution_receipt_binding_mismatch")
        or (receipt_present and not receipt_binding_match)
    )
    receipt_performed = bool(
        fulfillment_record.get("redrive_execution_receipt_performed")
    )
    receipt_provenance_ready = bool(
        receipt_present
        and receipt_schema_match
        and receipt_binding_match
        and receipt_performed
    )
    rejudge_required = packet_type == "referee_rejudge"
    rejudge_provenance_ready = bool(
        rejudge_required
        and template_record.get("referee_rejudge_provenance_ready")
        and real_source_material_present
        and source_sha256_present
        and schema_packet_json_ok
        and request_binding_match
        and receipt_provenance_ready
    )
    redrive_execution_performed = bool(
        template_record.get("redrive_execution_performed")
        or fulfillment_record.get("upstream_redrive_execution_performed")
    )
    expected_packet_file_creation_performed = bool(
        template_record.get("expected_packet_file_creation_performed")
    )
    action_leak = bool(
        template_record.get("evidence_release_performed")
        or template_record.get("repair_evidence_promoted")
        or template_record.get("request_closure_performed")
        or fulfillment_record.get("request_closure_performed")
        or expected_packet_file_creation_performed
        or template_record.get("consumable_as_repair_evidence")
        or template_record.get("consumable_as_release_evidence")
        or template_record.get("consumable_as_request_closure")
        or fulfillment_record.get("consumable_as_repair_evidence")
        or fulfillment_record.get("consumable_as_request_closure")
        or fulfillment_record.get("consumable_as_referee_rejudge")
    )
    ready = bool(
        template_verified
        and fulfillment_present
        and fulfillment_path_match
        and real_source_material_present
        and source_packet_present
        and schema_packet_json_ok
        and source_sha256_present
        and source_hash_bound
        and request_binding_match
        and receipt_provenance_ready
        and (not rejudge_required or rejudge_provenance_ready)
        and not action_leak
    )
    issues = []
    if not template_present:
        issues.append("source_authoring_prerequisite_template_record_missing")
    if not fulfillment_present:
        issues.append("source_fulfillment_record_missing")
    if fulfillment_present and not fulfillment_path_match:
        issues.append("source_fulfillment_record_path_mismatch")
    if not template_verified:
        issues.append("source_authoring_prerequisite_template_unverified")
    if not real_source_material_present:
        issues.append("real_source_material_missing")
    if not source_packet_present:
        issues.append("source_packet_missing")
    if source_packet_present and not source_json_ok:
        issues.append("source_packet_json_not_ok")
    if source_packet_present and source_json_ok and not source_schema_match:
        issues.append("source_packet_schema_mismatch")
    if not source_sha256_present:
        issues.append("source_sha256_missing")
    if not source_hash_bound:
        issues.append("source_hash_unbound")
    if not request_binding_present:
        issues.append("request_binding_prerequisite_missing")
    if not request_binding_match:
        issues.append("request_binding_mismatch")
    if not receipt_present:
        issues.append("redrive_receipt_missing")
    if receipt_present and not receipt_schema_match:
        issues.append("redrive_receipt_schema_mismatch")
    if receipt_present and not receipt_binding_match:
        issues.append("redrive_receipt_binding_mismatch")
    if not receipt_performed:
        issues.append("redrive_receipt_not_performed")
    if rejudge_required and not rejudge_provenance_ready:
        issues.append("referee_rejudge_provenance_missing")
    if action_leak:
        issues.append("real_source_provenance_action_or_evidence_leak")
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "real_source_provenance_intake_verifier_id": (
            f"referee-repair-real-source-provenance-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "real_source_provenance_intake_payload_sha256": payload_sha,
        "real_source_provenance_intake_hash_bound": bool(
            payload_sha
            and template_record.get("source_authoring_prerequisite_template_hash_bound")
            and fulfillment_record.get("source_slot_fulfillment_intake_hash_bound")
        ),
        "real_source_provenance_intake_lint_ready": bool(
            template_record.get("source_authoring_prerequisite_template_lint_ready")
            and fulfillment_record.get("source_slot_fulfillment_intake_lint_ready")
            and payload_sha
            and expected_path
            and expected_receipt_path
            and required_schema
        ),
        "source_authoring_prerequisite_template_payload_sha256": template_sha,
        "source_slot_fulfillment_intake_payload_sha256": fulfillment_sha,
        "template_record_present": template_present,
        "fulfillment_record_present": fulfillment_present,
        "fulfillment_record_path_match": fulfillment_path_match,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "required_packet_schema_id": required_schema,
        "observed_source_schema_id": fulfillment_record.get("observed_source_schema_id") or "",
        "source_packet_template_verified": template_verified,
        "real_source_material_present": real_source_material_present,
        "source_packet_present": source_packet_present,
        "source_packet_json_ok": source_json_ok,
        "source_packet_json_error": source_json_error,
        "source_packet_schema_match": source_schema_match,
        "source_packet_schema_mismatch": source_schema_mismatch,
        "source_sha256_present": source_sha256_present,
        "observed_source_slot_sha256": fulfillment_record.get("source_slot_sha256") or "",
        "source_hash_bound": source_hash_bound,
        "request_binding_present": request_binding_present,
        "request_binding_match": request_binding_match,
        "schema_packet_json_ok": schema_packet_json_ok,
        "redrive_receipt_present": receipt_present,
        "redrive_receipt_schema_match": receipt_schema_match,
        "redrive_receipt_schema_mismatch": receipt_schema_mismatch,
        "redrive_receipt_binding_match": receipt_binding_match,
        "redrive_receipt_binding_mismatch": receipt_binding_mismatch,
        "redrive_receipt_performed": receipt_performed,
        "redrive_receipt_provenance_ready": receipt_provenance_ready,
        "redrive_execution_performed": redrive_execution_performed,
        "expected_packet_file_creation_performed": expected_packet_file_creation_performed,
        "referee_rejudge_provenance_required": rejudge_required,
        "referee_rejudge_provenance_ready": rejudge_provenance_ready,
        "real_source_provenance_intake_ready": ready,
        "real_source_provenance_intake_blockers": issues,
        "evidence_release_performed": bool(
            template_record.get("evidence_release_performed")
        ),
        "repair_evidence_promoted": bool(
            template_record.get("repair_evidence_promoted")
        ),
        "request_closure_performed": bool(
            template_record.get("request_closure_performed")
            or fulfillment_record.get("request_closure_performed")
        ),
        "next_required_action": (
            "ready for source/rejudge input-index revalidation; do not release or close here"
            if ready
            else "provide real source material, source sha256, schema-valid packet JSON, binding, receipt, and referee rejudge provenance"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, provenance_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in provenance_records
        if not item.get("real_source_provenance_intake_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_real_source_provenance_intake_verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "real_source_provenance_intake_payload_sha256s": [
            item.get("real_source_provenance_intake_payload_sha256")
            for item in provenance_records
        ],
    }
    payload_sha = _sha(payload)
    lint_ready = bool(
        request_id is not None
        and slug
        and payload_sha
        and all(
            item.get("real_source_provenance_intake_lint_ready")
            for item in provenance_records
        )
    )
    hash_bound = bool(
        payload_sha
        and all(
            item.get("real_source_provenance_intake_hash_bound")
            for item in provenance_records
        )
    )
    ready = bool(provenance_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_real_source_provenance_intake_verifier_id": (
            f"referee-repair-request-real-source-provenance-{request_id}-{payload_sha[:16]}"
        ),
        "request_real_source_provenance_intake_payload_sha256": payload_sha,
        "request_real_source_provenance_intake_hash_bound": hash_bound,
        "request_real_source_provenance_intake_lint_ready": lint_ready,
        "real_source_provenance_intake_record_count": len(provenance_records),
        "real_source_provenance_intake_ready_count": sum(
            1
            for item in provenance_records
            if item.get("real_source_provenance_intake_ready")
        ),
        "request_real_source_provenance_intake_ready": ready,
        "request_real_source_provenance_intake_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "real_source_provenance_intake_records": provenance_records,
        "next_required_action": (
            "complete real-source provenance intake for blocked packet types"
            if blocked
            else "real-source provenance intake is ready for downstream revalidation"
        ),
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_real_source_provenance_intake_verifier_capstone(
    source_authoring_prerequisite_template_verifier_report,
    source_slot_fulfillment_intake_report,
    source_authoring_prerequisite_template_verifier_ref=None,
    source_slot_fulfillment_intake_ref=None,
    label="",
    created_at="",
):
    source_authoring_prerequisite_template_verifier_report = dict(
        source_authoring_prerequisite_template_verifier_report or {}
    )
    source_slot_fulfillment_intake_report = dict(
        source_slot_fulfillment_intake_report or {}
    )
    source_authoring_prerequisite_template_verifier_ref = dict(
        source_authoring_prerequisite_template_verifier_ref or {}
    )
    source_slot_fulfillment_intake_ref = dict(
        source_slot_fulfillment_intake_ref or {}
    )
    template_summary = _summary(
        source_authoring_prerequisite_template_verifier_report
    )
    fulfillment_summary = _summary(source_slot_fulfillment_intake_report)
    request_template_records = [
        dict(item or {})
        for item in source_authoring_prerequisite_template_verifier_report.get(
            "source_authoring_prerequisite_template_verifier_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    template_records = [
        dict(record or {})
        for request_record in request_template_records
        for record in request_record.get("source_authoring_prerequisite_template_records")
        or []
    ]
    request_fulfillment_records = [
        dict(item or {})
        for item in source_slot_fulfillment_intake_report.get(
            "source_slot_fulfillment_intake_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    fulfillment_records = [
        dict(record or {})
        for request_record in request_fulfillment_records
        for record in request_record.get("source_slot_fulfillment_records") or []
    ]
    fulfillment_by_key = {_key(record): record for record in fulfillment_records}
    template_report_valid = bool(
        source_authoring_prerequisite_template_verifier_ref.get("path")
        and source_authoring_prerequisite_template_verifier_ref.get("sha256_match")
        and source_authoring_prerequisite_template_verifier_report
        and _status(
            source_authoring_prerequisite_template_verifier_report,
            source_authoring_prerequisite_template_verifier_ref,
        )
        in {"PASS", "FAIL"}
    )
    fulfillment_report_valid = bool(
        source_slot_fulfillment_intake_ref.get("path")
        and source_slot_fulfillment_intake_ref.get("sha256_match")
        and source_slot_fulfillment_intake_report
        and _status(
            source_slot_fulfillment_intake_report,
            source_slot_fulfillment_intake_ref,
        )
        in {"PASS", "FAIL"}
    )
    template_lint_ready = bool(
        template_report_valid
        and _int(
            template_summary.get(
                "request_source_authoring_prerequisite_template_record_count"
            )
        )
        == len(request_template_records)
        and all(
            request.get("request_source_authoring_prerequisite_template_lint_ready")
            for request in request_template_records
        )
        and all(
            record.get("source_authoring_prerequisite_template_lint_ready")
            for record in template_records
        )
    )
    fulfillment_lint_ready = bool(
        fulfillment_report_valid
        and _int(fulfillment_summary.get("request_fulfillment_intake_record_count"))
        == len(request_fulfillment_records)
        and all(
            request.get("request_source_slot_fulfillment_intake_lint_ready")
            for request in request_fulfillment_records
        )
        and all(
            record.get("source_slot_fulfillment_intake_lint_ready")
            for record in fulfillment_records
        )
    )
    request_records = []
    for request_record in sorted(
        request_template_records, key=lambda item: str(item.get("request_id"))
    ):
        provenance_records = []
        for template_record in (
            request_record.get("source_authoring_prerequisite_template_records") or []
        ):
            template_record = dict(template_record or {})
            provenance_records.append(
                _provenance_record(
                    template_record,
                    fulfillment_by_key.get(_key(template_record)) or {},
                )
            )
        request_records.append(_request_record(request_record, provenance_records))
    provenance_records = [
        record
        for request_record in request_records
        for record in request_record.get("real_source_provenance_intake_records") or []
    ]
    record_count = len(provenance_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_real_source_provenance_intake_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1 for item in provenance_records if item.get("real_source_provenance_intake_hash_bound")
    )
    lint_ready_count = sum(
        1 for item in provenance_records if item.get("real_source_provenance_intake_lint_ready")
    )
    template_present_count = sum(1 for item in provenance_records if item.get("template_record_present"))
    fulfillment_present_count = sum(1 for item in provenance_records if item.get("fulfillment_record_present"))
    template_verified_count = sum(1 for item in provenance_records if item.get("source_packet_template_verified"))
    real_source_present_count = sum(1 for item in provenance_records if item.get("real_source_material_present"))
    source_packet_present_count = sum(1 for item in provenance_records if item.get("source_packet_present"))
    source_json_ok_count = sum(1 for item in provenance_records if item.get("source_packet_json_ok"))
    source_json_error_count = sum(1 for item in provenance_records if item.get("source_packet_json_error"))
    source_schema_match_count = sum(1 for item in provenance_records if item.get("source_packet_schema_match"))
    source_schema_mismatch_count = sum(1 for item in provenance_records if item.get("source_packet_schema_mismatch"))
    source_sha256_present_count = sum(1 for item in provenance_records if item.get("source_sha256_present"))
    source_hash_bound_count = sum(1 for item in provenance_records if item.get("source_hash_bound"))
    request_binding_present_count = sum(1 for item in provenance_records if item.get("request_binding_present"))
    request_binding_match_count = sum(1 for item in provenance_records if item.get("request_binding_match"))
    receipt_present_count = sum(1 for item in provenance_records if item.get("redrive_receipt_present"))
    receipt_schema_match_count = sum(1 for item in provenance_records if item.get("redrive_receipt_schema_match"))
    receipt_schema_mismatch_count = sum(1 for item in provenance_records if item.get("redrive_receipt_schema_mismatch"))
    receipt_binding_match_count = sum(1 for item in provenance_records if item.get("redrive_receipt_binding_match"))
    receipt_binding_mismatch_count = sum(1 for item in provenance_records if item.get("redrive_receipt_binding_mismatch"))
    receipt_performed_count = sum(1 for item in provenance_records if item.get("redrive_receipt_performed"))
    rejudge_required_count = sum(1 for item in provenance_records if item.get("referee_rejudge_provenance_required"))
    rejudge_ready_count = sum(1 for item in provenance_records if item.get("referee_rejudge_provenance_ready"))
    redrive_execution_performed_count = sum(1 for item in provenance_records if item.get("redrive_execution_performed"))
    expected_file_creation_count = sum(1 for item in provenance_records if item.get("expected_packet_file_creation_performed"))
    evidence_release_count = sum(
        1
        for item in provenance_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in provenance_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in provenance_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in provenance_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("expected_packet_file_creation_performed")
    )
    ready = bool(
        template_lint_ready
        and fulfillment_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and template_present_count == record_count
        and fulfillment_present_count == record_count
        and template_verified_count == record_count
        and real_source_present_count == record_count
        and source_packet_present_count == record_count
        and source_json_ok_count == record_count
        and source_schema_match_count == record_count
        and source_sha256_present_count == record_count
        and source_hash_bound_count == record_count
        and request_binding_present_count == record_count
        and request_binding_match_count == record_count
        and receipt_present_count == record_count
        and receipt_schema_match_count == record_count
        and receipt_binding_match_count == record_count
        and receipt_performed_count == record_count
        and rejudge_ready_count == rejudge_required_count
        and request_blocked_count == 0
        and redrive_execution_performed_count == record_count
        and expected_file_creation_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "source_authoring_prerequisite_template_verifier_available",
        template_report_valid,
        source_authoring_prerequisite_template_verifier_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_slot_fulfillment_intake_available",
        fulfillment_report_valid,
        source_slot_fulfillment_intake_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_authoring_prerequisite_template_verifier_lint_ready",
        template_lint_ready,
        f"requests={len(request_template_records)} records={len(template_records)}",
    )
    _add_check(
        checks,
        "source_slot_fulfillment_intake_lint_ready",
        fulfillment_lint_ready,
        f"requests={len(request_fulfillment_records)} records={len(fulfillment_records)}",
    )
    _add_check(
        checks,
        "all_real_source_provenance_intake_records_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_real_source_provenance_intake_records_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_fulfillment_records_present",
        fulfillment_present_count == record_count,
        f"present={fulfillment_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_prerequisite_templates_verified",
        template_verified_count == record_count,
        f"verified={template_verified_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_real_source_material_present",
        real_source_present_count == record_count,
        f"present={real_source_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_packets_present",
        source_packet_present_count == record_count,
        f"present={source_packet_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_packets_json_schema_ready",
        source_json_ok_count == record_count and source_schema_match_count == record_count,
        f"json_ok={source_json_ok_count} schema_match={source_schema_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_sha256s_present",
        source_sha256_present_count == record_count,
        f"present={source_sha256_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_hashes_bound",
        source_hash_bound_count == record_count,
        f"bound={source_hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_bindings_match",
        request_binding_present_count == record_count and request_binding_match_count == record_count,
        f"present={request_binding_present_count} match={request_binding_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipts_present_and_performed",
        receipt_present_count == record_count and receipt_performed_count == record_count,
        f"present={receipt_present_count} performed={receipt_performed_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipts_schema_and_binding_match",
        receipt_schema_match_count == record_count and receipt_binding_match_count == record_count,
        f"schema={receipt_schema_match_count} binding={receipt_binding_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_referee_rejudge_provenance_ready",
        rejudge_ready_count == rejudge_required_count,
        f"ready={rejudge_ready_count} required={rejudge_required_count}",
    )
    _add_check(
        checks,
        "all_request_real_source_provenance_intakes_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "real_source_provenance_intakes_are_not_release_or_closure_evidence",
        consumable_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and expected_file_creation_count == 0,
        (
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} file_creation={expected_file_creation_count} "
            f"consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not template_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_TEMPLATE_VERIFIER_MISSING"
    elif not fulfillment_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_FULFILLMENT_INTAKE_MISSING"
    elif not template_lint_ready or not fulfillment_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_UPSTREAM_LINT"
    elif fulfillment_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_FULFILLMENT_RECORD_MISSING"
    elif template_verified_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_TEMPLATE_UNVERIFIED"
    elif real_source_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_SOURCE_MATERIAL_MISSING"
    elif source_packet_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_SOURCE_PACKET_MISSING"
    elif source_json_ok_count != record_count or source_schema_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_SOURCE_PACKET_JSON_SCHEMA"
    elif source_sha256_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_SOURCE_SHA256_MISSING"
    elif source_hash_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_SOURCE_HASH_NOT_BOUND"
    elif request_binding_present_count != record_count or request_binding_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_REQUEST_BINDING"
    elif receipt_present_count != record_count or receipt_performed_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_REDRIVE_RECEIPT_NOT_READY"
    elif receipt_schema_match_count != record_count or receipt_binding_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_REDRIVE_RECEIPT_BINDING"
    elif rejudge_ready_count != rejudge_required_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_REFEREE_REJUDGE"
    elif evidence_release_count or promoted_count or closure_count or consumable_count or expected_file_creation_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_REQUEST_INTAKE"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_INTAKE_VERIFIER"
    else:
        state = "REFEREE_REPAIR_REAL_SOURCE_PROVENANCE_INTAKE_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_real_source_provenance_intake_verifier_state": state,
        "summary": {
            "open_request_count": _int(template_summary.get("open_request_count")),
            "source_authoring_prerequisite_template_record_count": _int(
                template_summary.get("source_authoring_prerequisite_template_record_count")
            ),
            "source_slot_fulfillment_record_count": _int(
                fulfillment_summary.get("source_slot_fulfillment_record_count")
            ),
            "real_source_provenance_intake_record_count": record_count,
            "hash_bound_real_source_provenance_intake_count": hash_bound_count,
            "real_source_provenance_intake_lint_ready_count": lint_ready_count,
            "template_record_present_count": template_present_count,
            "template_record_missing_count": record_count - template_present_count,
            "fulfillment_record_present_count": fulfillment_present_count,
            "fulfillment_record_missing_count": record_count - fulfillment_present_count,
            "prerequisite_template_verified_count": template_verified_count,
            "prerequisite_template_unverified_count": record_count - template_verified_count,
            "real_source_material_present_count": real_source_present_count,
            "real_source_material_missing_count": record_count - real_source_present_count,
            "source_packet_present_count": source_packet_present_count,
            "source_packet_missing_count": record_count - source_packet_present_count,
            "source_packet_json_ok_count": source_json_ok_count,
            "source_packet_json_error_count": source_json_error_count,
            "source_packet_schema_match_count": source_schema_match_count,
            "source_packet_schema_mismatch_count": source_schema_mismatch_count,
            "source_sha256_present_count": source_sha256_present_count,
            "source_sha256_missing_count": record_count - source_sha256_present_count,
            "source_hash_bound_count": source_hash_bound_count,
            "source_hash_unbound_count": record_count - source_hash_bound_count,
            "request_binding_present_count": request_binding_present_count,
            "request_binding_missing_count": record_count - request_binding_present_count,
            "request_binding_match_count": request_binding_match_count,
            "request_binding_mismatch_count": record_count - request_binding_match_count,
            "redrive_receipt_present_count": receipt_present_count,
            "redrive_receipt_missing_count": record_count - receipt_present_count,
            "redrive_receipt_schema_match_count": receipt_schema_match_count,
            "redrive_receipt_schema_mismatch_count": receipt_schema_mismatch_count,
            "redrive_receipt_binding_match_count": receipt_binding_match_count,
            "redrive_receipt_binding_mismatch_count": receipt_binding_mismatch_count,
            "redrive_receipt_performed_count": receipt_performed_count,
            "redrive_receipt_not_performed_count": record_count - receipt_performed_count,
            "referee_rejudge_provenance_required_count": rejudge_required_count,
            "referee_rejudge_provenance_ready_count": rejudge_ready_count,
            "referee_rejudge_provenance_missing_count": rejudge_required_count
            - rejudge_ready_count,
            "redrive_execution_performed_count": redrive_execution_performed_count,
            "expected_packet_file_creation_performed_count": expected_file_creation_count,
            "request_real_source_provenance_intake_record_count": request_count,
            "request_real_source_provenance_intake_ready_count": request_ready_count,
            "request_real_source_provenance_intake_blocked_count": request_blocked_count,
            "proof_status_real_source_provenance_required_count": _count(
                provenance_records, "proof_status"
            ),
            "proof_status_real_source_provenance_ready_count": _count(
                provenance_records, "proof_status", "real_source_provenance_intake_ready"
            ),
            "evidence_manifest_real_source_provenance_required_count": _count(
                provenance_records, "evidence_manifest"
            ),
            "evidence_manifest_real_source_provenance_ready_count": _count(
                provenance_records,
                "evidence_manifest",
                "real_source_provenance_intake_ready",
            ),
            "appendix_supplement_real_source_provenance_required_count": _count(
                provenance_records, "appendix_supplement"
            ),
            "appendix_supplement_real_source_provenance_ready_count": _count(
                provenance_records,
                "appendix_supplement",
                "real_source_provenance_intake_ready",
            ),
            "claim_downgrade_real_source_provenance_required_count": _count(
                provenance_records, "claim_downgrade"
            ),
            "claim_downgrade_real_source_provenance_ready_count": _count(
                provenance_records,
                "claim_downgrade",
                "real_source_provenance_intake_ready",
            ),
            "referee_rejudge_real_source_provenance_required_count": _count(
                provenance_records, "referee_rejudge"
            ),
            "referee_rejudge_real_source_provenance_ready_count": _count(
                provenance_records,
                "referee_rejudge",
                "real_source_provenance_intake_ready",
            ),
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "real_source_provenance_intake_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "real_source_provenance_intake_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies real-source provenance intake for referee repair packet source slots.",
            "Real-source provenance intake records are not source packets, receipts, repair evidence, proof_status updates, evidence_manifest updates, appendix/supplement content, referee rejudge results, release evidence, or request closure evidence.",
            "A ready provenance intake still does not release evidence, promote repair evidence, apply decisions, authorize review, or close requests.",
            "The command never writes source packets, receipts, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Real-Source Provenance Intake Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_real_source_provenance_intake_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
