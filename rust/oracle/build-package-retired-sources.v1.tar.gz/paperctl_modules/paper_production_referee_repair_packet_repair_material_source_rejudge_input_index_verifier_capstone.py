"""Repair-material source and referee-rejudge input index verifier."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-repair-material-source-rejudge-"
    "input-index-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_repair_material_source_rejudge_input_index_"
    "verifier_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_repair_material_source_rejudge_input_index_verifier_state",
    "report_schema",
    "summary",
    "repair_material_source_rejudge_input_index_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "repair_evidence_release_prerequisite_closure_audit_record_count",
    "source_slot_fulfillment_record_count",
    "repair_material_source_rejudge_input_index_record_count",
    "hash_bound_repair_material_source_rejudge_input_index_count",
    "repair_material_source_rejudge_input_index_lint_ready_count",
    "closure_audit_record_present_count",
    "closure_audit_record_missing_count",
    "source_fulfillment_record_present_count",
    "source_fulfillment_record_missing_count",
    "input_template_verified_count",
    "input_template_unverified_count",
    "source_slot_present_count",
    "source_slot_missing_count",
    "source_slot_fulfilled_count",
    "source_slot_unfulfilled_count",
    "redrive_execution_receipt_present_count",
    "redrive_execution_receipt_missing_count",
    "redrive_execution_receipt_performed_count",
    "redrive_execution_receipt_not_performed_count",
    "source_hash_bound_count",
    "source_hash_unbound_count",
    "request_binding_match_count",
    "request_binding_mismatch_count",
    "repair_material_source_input_ready_count",
    "repair_material_source_input_blocked_count",
    "referee_rejudge_input_required_count",
    "referee_rejudge_input_ready_count",
    "referee_rejudge_input_missing_count",
    "closure_chain_source_consistent_count",
    "closure_chain_source_mismatch_count",
    "request_repair_material_source_rejudge_input_index_record_count",
    "request_repair_material_source_rejudge_input_index_ready_count",
    "request_repair_material_source_rejudge_input_index_blocked_count",
    "proof_status_source_input_required_count",
    "proof_status_source_input_ready_count",
    "evidence_manifest_source_input_required_count",
    "evidence_manifest_source_input_ready_count",
    "appendix_supplement_source_input_required_count",
    "appendix_supplement_source_input_ready_count",
    "claim_downgrade_source_input_required_count",
    "claim_downgrade_source_input_ready_count",
    "referee_rejudge_source_input_required_count",
    "referee_rejudge_source_input_ready_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "repair_material_source_rejudge_input_index_verifier_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _key(record):
    return (
        str(record.get("request_id")),
        record.get("slug") or "",
        record.get("packet_type") or "",
        record.get("expected_packet_path") or "",
    )


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def _verifier_record(closure_record, fulfillment_record):
    closure_record = dict(closure_record or {})
    fulfillment_record = dict(fulfillment_record or {})
    request_id = closure_record.get("request_id")
    slug = closure_record.get("slug") or ""
    packet_type = closure_record.get("packet_type") or ""
    expected_path = closure_record.get("expected_packet_path") or ""
    expected_receipt_path = (
        closure_record.get("expected_redrive_execution_receipt_path") or ""
    )
    closure_sha = (
        closure_record.get(
            "repair_evidence_release_prerequisite_closure_audit_payload_sha256"
        )
        or ""
    )
    fulfillment_sha = (
        fulfillment_record.get("source_slot_fulfillment_intake_payload_sha256")
        or ""
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_repair_material_source_rejudge_input_index_"
            "verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "repair_evidence_release_prerequisite_closure_audit_payload_sha256": (
            closure_sha
        ),
        "source_slot_fulfillment_intake_payload_sha256": fulfillment_sha,
    }
    payload_sha = _sha(payload)
    fulfillment_present = bool(fulfillment_record)
    closure_present = bool(closure_record)
    input_template_verified = bool(
        closure_present
        and request_id is not None
        and slug
        and packet_type
        and expected_path
        and expected_receipt_path
        and closure_sha
        and fulfillment_present
        and fulfillment_record.get("expected_packet_path") == expected_path
        and fulfillment_record.get("expected_redrive_execution_receipt_path")
        == expected_receipt_path
        and fulfillment_record.get("required_packet_schema_id")
    )
    lint_ready = bool(
        input_template_verified
        and payload_sha
        and closure_record.get(
            "repair_evidence_release_prerequisite_closure_audit_lint_ready"
        )
        and fulfillment_record.get("source_slot_fulfillment_intake_lint_ready")
    )
    hash_bound = bool(
        payload_sha
        and closure_record.get(
            "repair_evidence_release_prerequisite_closure_audit_hash_bound"
        )
        and fulfillment_record.get("source_slot_fulfillment_intake_hash_bound")
    )
    source_present = bool(fulfillment_record.get("source_slot_present"))
    source_fulfilled = bool(fulfillment_record.get("source_slot_fulfilled"))
    receipt_present = bool(
        fulfillment_record.get("redrive_execution_receipt_present")
    )
    receipt_performed = bool(
        fulfillment_record.get("redrive_execution_receipt_performed")
    )
    source_hash_bound = bool(fulfillment_record.get("source_hash_bound"))
    request_binding_match = bool(fulfillment_record.get("request_binding_match"))
    source_input_ready = bool(
        source_fulfilled
        and receipt_present
        and receipt_performed
        and source_hash_bound
        and request_binding_match
    )
    rejudge_required = packet_type == "referee_rejudge"
    rejudge_ready = bool(rejudge_required and source_input_ready)
    closure_source_consistent = bool(
        fulfillment_present
        and closure_record.get("source_slot_fulfilled") == source_fulfilled
        and closure_record.get("redrive_execution_receipt_performed")
        == receipt_performed
        and closure_record.get("source_hash_bound") == source_hash_bound
        and closure_record.get("request_binding_match") == request_binding_match
    )
    action_leak = bool(
        closure_record.get("evidence_release_performed")
        or closure_record.get("repair_evidence_promoted")
        or closure_record.get("request_closure_performed")
        or fulfillment_record.get("request_closure_performed")
        or fulfillment_record.get("consumable_as_repair_evidence")
        or fulfillment_record.get("consumable_as_request_closure")
    )
    ready = bool(
        lint_ready
        and hash_bound
        and input_template_verified
        and source_input_ready
        and (not rejudge_required or rejudge_ready)
        and closure_source_consistent
        and not action_leak
    )
    issues = []
    if not closure_present:
        issues.append("closure_audit_record_missing")
    if not fulfillment_present:
        issues.append("source_fulfillment_record_missing")
    if not input_template_verified:
        issues.append("input_template_unverified")
    if not source_present:
        issues.append("source_slot_missing")
    if not source_fulfilled:
        issues.append("source_slot_unfulfilled")
    if not receipt_present:
        issues.append("redrive_execution_receipt_missing")
    if not receipt_performed:
        issues.append("redrive_execution_receipt_not_performed")
    if not source_hash_bound:
        issues.append("source_hash_unbound")
    if not request_binding_match:
        issues.append("request_binding_mismatch")
    if rejudge_required and not rejudge_ready:
        issues.append("referee_rejudge_input_not_ready")
    if not closure_source_consistent:
        issues.append("closure_chain_source_state_mismatch")
    if action_leak:
        issues.append("release_or_closure_action_leak")
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "repair_material_source_rejudge_input_index_verifier_id": (
            "referee-repair-material-source-rejudge-input-index-"
            f"{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "repair_material_source_rejudge_input_index_payload_sha256": payload_sha,
        "repair_material_source_rejudge_input_index_hash_bound": hash_bound,
        "repair_material_source_rejudge_input_index_lint_ready": lint_ready,
        "repair_evidence_release_prerequisite_closure_audit_payload_sha256": (
            closure_sha
        ),
        "source_slot_fulfillment_intake_payload_sha256": fulfillment_sha,
        "closure_audit_record_present": closure_present,
        "source_fulfillment_record_present": fulfillment_present,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "required_packet_schema_id": fulfillment_record.get("required_packet_schema_id")
        or "",
        "input_template_verified": input_template_verified,
        "source_slot_present": source_present,
        "source_slot_fulfilled": source_fulfilled,
        "redrive_execution_receipt_present": receipt_present,
        "redrive_execution_receipt_performed": receipt_performed,
        "source_hash_bound": source_hash_bound,
        "request_binding_match": request_binding_match,
        "repair_material_source_input_ready": source_input_ready,
        "referee_rejudge_input_required": rejudge_required,
        "referee_rejudge_input_ready": rejudge_ready,
        "closure_chain_source_consistent": closure_source_consistent,
        "repair_material_source_rejudge_input_index_ready": ready,
        "input_index_blockers": issues,
        "evidence_release_performed": bool(
            closure_record.get("evidence_release_performed")
        ),
        "repair_evidence_promoted": bool(
            closure_record.get("repair_evidence_promoted")
        ),
        "request_closure_performed": bool(
            closure_record.get("request_closure_performed")
            or fulfillment_record.get("request_closure_performed")
        ),
        "next_required_action": (
            "ready for later release-request envelope preflight; do not release or close here"
            if ready
            else "author real request-bound source, redrive receipt, source hash, request binding, and referee rejudge input"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, verifier_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get("repair_material_source_rejudge_input_index_ready")
    ]
    by_type = {}
    for item in verifier_records:
        by_type.setdefault(item.get("packet_type"), []).append(item)
    proof_status_ready = any(
        item.get("repair_material_source_input_ready")
        for item in by_type.get("proof_status", [])
    )
    evidence_manifest_ready = any(
        item.get("repair_material_source_input_ready")
        for item in by_type.get("evidence_manifest", [])
    )
    claim_downgrade_ready = any(
        item.get("repair_material_source_input_ready")
        for item in by_type.get("claim_downgrade", [])
    )
    referee_rejudge_ready = any(
        item.get("referee_rejudge_input_ready")
        for item in by_type.get("referee_rejudge", [])
    )
    required_type_ready = bool(
        proof_status_ready
        and evidence_manifest_ready
        and claim_downgrade_ready
        and referee_rejudge_ready
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_repair_material_source_rejudge_input_index_"
            "verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "repair_material_source_rejudge_input_index_payload_sha256s": [
            item.get("repair_material_source_rejudge_input_index_payload_sha256")
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    lint_ready = bool(
        request_id is not None
        and slug
        and payload_sha
        and all(
            item.get("repair_material_source_rejudge_input_index_lint_ready")
            for item in verifier_records
        )
    )
    hash_bound = bool(
        payload_sha
        and all(
            item.get("repair_material_source_rejudge_input_index_hash_bound")
            for item in verifier_records
        )
    )
    ready = bool(verifier_records) and not blocked and required_type_ready
    return {
        "request_id": request_id,
        "slug": slug,
        "request_repair_material_source_rejudge_input_index_verifier_id": (
            "referee-repair-request-material-source-rejudge-input-index-"
            f"{request_id}-{payload_sha[:16]}"
        ),
        "request_repair_material_source_rejudge_input_index_payload_sha256": (
            payload_sha
        ),
        "request_repair_material_source_rejudge_input_index_hash_bound": hash_bound,
        "request_repair_material_source_rejudge_input_index_lint_ready": lint_ready,
        "input_index_record_count": len(verifier_records),
        "input_index_ready_count": sum(
            1
            for item in verifier_records
            if item.get("repair_material_source_rejudge_input_index_ready")
        ),
        "required_type_input_index_ready": required_type_ready,
        "proof_status_source_input_ready": proof_status_ready,
        "evidence_manifest_source_input_ready": evidence_manifest_ready,
        "claim_downgrade_source_input_ready": claim_downgrade_ready,
        "referee_rejudge_input_ready": referee_rejudge_ready,
        "request_repair_material_source_rejudge_input_index_ready": ready,
        "request_repair_material_source_rejudge_input_index_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "repair_material_source_rejudge_input_index_records": verifier_records,
        "next_required_action": (
            "complete request-bound material source and referee rejudge input index"
            if not ready
            else "eligible only for later nonclosure release-request preflight"
        ),
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_repair_material_source_rejudge_input_index_verifier_capstone(
    repair_evidence_release_prerequisite_closure_audit_report,
    source_slot_fulfillment_intake_report,
    repair_evidence_release_prerequisite_closure_audit_ref=None,
    source_slot_fulfillment_intake_ref=None,
    label="",
    created_at="",
):
    repair_evidence_release_prerequisite_closure_audit_report = dict(
        repair_evidence_release_prerequisite_closure_audit_report or {}
    )
    source_slot_fulfillment_intake_report = dict(
        source_slot_fulfillment_intake_report or {}
    )
    repair_evidence_release_prerequisite_closure_audit_ref = dict(
        repair_evidence_release_prerequisite_closure_audit_ref or {}
    )
    source_slot_fulfillment_intake_ref = dict(
        source_slot_fulfillment_intake_ref or {}
    )
    closure_summary = _summary(
        repair_evidence_release_prerequisite_closure_audit_report
    )
    fulfillment_summary = _summary(source_slot_fulfillment_intake_report)
    request_closure_records = [
        dict(item or {})
        for item in repair_evidence_release_prerequisite_closure_audit_report.get(
            "repair_evidence_release_prerequisite_closure_audit_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    closure_records = [
        dict(entry or {})
        for request_record in request_closure_records
        for entry in request_record.get(
            "repair_evidence_release_prerequisite_closure_audit_records"
        )
        or []
    ]
    request_fulfillment_records = [
        dict(item or {})
        for item in source_slot_fulfillment_intake_report.get(
            "source_slot_fulfillment_intake_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    fulfillment_records = [
        dict(entry or {})
        for request_record in request_fulfillment_records
        for entry in request_record.get("source_slot_fulfillment_records") or []
    ]
    closure_report_valid = bool(
        repair_evidence_release_prerequisite_closure_audit_ref.get("path")
        and repair_evidence_release_prerequisite_closure_audit_ref.get(
            "sha256_match"
        )
        and repair_evidence_release_prerequisite_closure_audit_report
        and _status(
            repair_evidence_release_prerequisite_closure_audit_report,
            repair_evidence_release_prerequisite_closure_audit_ref,
        )
        in {"PASS", "FAIL"}
    )
    fulfillment_report_valid = bool(
        source_slot_fulfillment_intake_ref.get("path")
        and source_slot_fulfillment_intake_ref.get("sha256_match")
        and source_slot_fulfillment_intake_report
        and _status(
            source_slot_fulfillment_intake_report,
            source_slot_fulfillment_intake_ref,
        )
        in {"PASS", "FAIL"}
    )
    closure_lint_ready = bool(
        closure_report_valid
        and _int(
            closure_summary.get(
                "request_repair_evidence_release_prerequisite_closure_audit_record_count"
            )
        )
        == len(request_closure_records)
        and _int(
            closure_summary.get(
                "repair_evidence_release_prerequisite_closure_audit_record_count"
            )
        )
        == len(closure_records)
        and all(
            item.get(
                "request_repair_evidence_release_prerequisite_closure_audit_lint_ready"
            )
            for item in request_closure_records
        )
        and all(
            item.get(
                "repair_evidence_release_prerequisite_closure_audit_lint_ready"
            )
            for item in closure_records
        )
    )
    fulfillment_lint_ready = bool(
        fulfillment_report_valid
        and _int(fulfillment_summary.get("request_fulfillment_intake_record_count"))
        == len(request_fulfillment_records)
        and _int(fulfillment_summary.get("source_slot_fulfillment_record_count"))
        == len(fulfillment_records)
        and all(
            item.get("request_source_slot_fulfillment_intake_lint_ready")
            for item in request_fulfillment_records
        )
        and all(
            item.get("source_slot_fulfillment_intake_lint_ready")
            for item in fulfillment_records
        )
    )
    fulfillment_by_key = {_key(record): record for record in fulfillment_records}
    request_records = []
    for request_record in sorted(
        request_closure_records, key=lambda item: str(item.get("request_id"))
    ):
        verifier_records = [
            _verifier_record(entry, fulfillment_by_key.get(_key(entry)) or {})
            for entry in request_record.get(
                "repair_evidence_release_prerequisite_closure_audit_records"
            )
            or []
        ]
        request_records.append(_request_record(request_record, verifier_records))
    verifier_records = [
        item
        for request_record in request_records
        for item in request_record.get(
            "repair_material_source_rejudge_input_index_records"
        )
        or []
    ]
    request_count = len(request_records)
    record_count = len(verifier_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_repair_material_source_rejudge_input_index_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in verifier_records
        if item.get("repair_material_source_rejudge_input_index_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in verifier_records
        if item.get("repair_material_source_rejudge_input_index_lint_ready")
    )
    closure_present_count = sum(
        1 for item in verifier_records if item.get("closure_audit_record_present")
    )
    fulfillment_present_count = sum(
        1 for item in verifier_records if item.get("source_fulfillment_record_present")
    )
    template_verified_count = sum(
        1 for item in verifier_records if item.get("input_template_verified")
    )
    source_present_count = sum(
        1 for item in verifier_records if item.get("source_slot_present")
    )
    source_fulfilled_count = sum(
        1 for item in verifier_records if item.get("source_slot_fulfilled")
    )
    receipt_present_count = sum(
        1
        for item in verifier_records
        if item.get("redrive_execution_receipt_present")
    )
    receipt_performed_count = sum(
        1
        for item in verifier_records
        if item.get("redrive_execution_receipt_performed")
    )
    source_hash_bound_count = sum(
        1 for item in verifier_records if item.get("source_hash_bound")
    )
    request_binding_match_count = sum(
        1 for item in verifier_records if item.get("request_binding_match")
    )
    source_input_ready_count = sum(
        1
        for item in verifier_records
        if item.get("repair_material_source_input_ready")
    )
    rejudge_required_count = sum(
        1 for item in verifier_records if item.get("referee_rejudge_input_required")
    )
    rejudge_ready_count = sum(
        1 for item in verifier_records if item.get("referee_rejudge_input_ready")
    )
    consistent_count = sum(
        1 for item in verifier_records if item.get("closure_chain_source_consistent")
    )
    evidence_release_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in verifier_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    ready = bool(
        closure_lint_ready
        and fulfillment_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and closure_present_count == record_count
        and fulfillment_present_count == record_count
        and template_verified_count == record_count
        and source_fulfilled_count == record_count
        and receipt_present_count == record_count
        and receipt_performed_count == record_count
        and source_hash_bound_count == record_count
        and request_binding_match_count == record_count
        and source_input_ready_count == record_count
        and rejudge_ready_count == rejudge_required_count
        and consistent_count == record_count
        and request_blocked_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "repair_evidence_release_prerequisite_closure_audit_available",
        closure_report_valid,
        repair_evidence_release_prerequisite_closure_audit_ref.get("path")
        or "missing",
    )
    _add_check(
        checks,
        "source_slot_fulfillment_intake_available",
        fulfillment_report_valid,
        source_slot_fulfillment_intake_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "repair_evidence_release_prerequisite_closure_audit_lint_ready",
        closure_lint_ready,
        f"requests={len(request_closure_records)} records={len(closure_records)}",
    )
    _add_check(
        checks,
        "source_slot_fulfillment_intake_lint_ready",
        fulfillment_lint_ready,
        f"requests={len(request_fulfillment_records)} records={len(fulfillment_records)}",
    )
    _add_check(
        checks,
        "all_input_index_records_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_input_index_records_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_fulfillment_records_present",
        fulfillment_present_count == record_count,
        f"present={fulfillment_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_input_templates_verified",
        template_verified_count == record_count,
        f"verified={template_verified_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_bound_source_slots_fulfilled",
        source_fulfilled_count == record_count,
        f"fulfilled={source_fulfilled_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipts_present_and_performed",
        receipt_present_count == record_count and receipt_performed_count == record_count,
        f"present={receipt_present_count} performed={receipt_performed_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_hashes_bound",
        source_hash_bound_count == record_count,
        f"bound={source_hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_bindings_match",
        request_binding_match_count == record_count,
        f"match={request_binding_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_referee_rejudge_inputs_ready",
        rejudge_ready_count == rejudge_required_count,
        f"ready={rejudge_ready_count} required={rejudge_required_count}",
    )
    _add_check(
        checks,
        "closure_chain_source_flags_match_fulfillment_index",
        consistent_count == record_count,
        f"consistent={consistent_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_source_rejudge_indexes_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "input_index_records_are_not_release_or_closure_evidence",
        consumable_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not closure_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_CLOSURE_AUDIT_MISSING"
    elif not fulfillment_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_SOURCE_FULFILLMENT_MISSING"
    elif not closure_lint_ready or not fulfillment_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_UPSTREAM_LINT"
    elif fulfillment_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_FULFILLMENT_INDEX_MISSING"
    elif template_verified_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_TEMPLATE_INDEX"
    elif source_fulfilled_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_SOURCE_MISSING_OR_INVALID"
    elif receipt_present_count != record_count or receipt_performed_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_REDRIVE_RECEIPT_NOT_READY"
    elif source_hash_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_SOURCE_HASH_NOT_BOUND"
    elif request_binding_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_REQUEST_BINDING_MISMATCH"
    elif rejudge_ready_count != rejudge_required_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_REFEREE_REJUDGE_INPUT_NOT_READY"
    elif consistent_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_CLOSURE_SOURCE_STATE_DRIFT"
    elif evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_REQUEST_INDEX"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_INPUT_INDEX_VERIFIER"
    else:
        state = "REFEREE_REPAIR_MATERIAL_SOURCE_REJUDGE_INPUT_INDEX_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_repair_material_source_rejudge_input_index_verifier_state": (
            state
        ),
        "summary": {
            "open_request_count": _int(closure_summary.get("open_request_count")),
            "repair_evidence_release_prerequisite_closure_audit_record_count": _int(
                closure_summary.get(
                    "repair_evidence_release_prerequisite_closure_audit_record_count"
                )
            ),
            "source_slot_fulfillment_record_count": _int(
                fulfillment_summary.get("source_slot_fulfillment_record_count")
            ),
            "repair_material_source_rejudge_input_index_record_count": record_count,
            "hash_bound_repair_material_source_rejudge_input_index_count": (
                hash_bound_count
            ),
            "repair_material_source_rejudge_input_index_lint_ready_count": (
                lint_ready_count
            ),
            "closure_audit_record_present_count": closure_present_count,
            "closure_audit_record_missing_count": record_count - closure_present_count,
            "source_fulfillment_record_present_count": fulfillment_present_count,
            "source_fulfillment_record_missing_count": record_count
            - fulfillment_present_count,
            "input_template_verified_count": template_verified_count,
            "input_template_unverified_count": record_count - template_verified_count,
            "source_slot_present_count": source_present_count,
            "source_slot_missing_count": record_count - source_present_count,
            "source_slot_fulfilled_count": source_fulfilled_count,
            "source_slot_unfulfilled_count": record_count - source_fulfilled_count,
            "redrive_execution_receipt_present_count": receipt_present_count,
            "redrive_execution_receipt_missing_count": record_count
            - receipt_present_count,
            "redrive_execution_receipt_performed_count": receipt_performed_count,
            "redrive_execution_receipt_not_performed_count": record_count
            - receipt_performed_count,
            "source_hash_bound_count": source_hash_bound_count,
            "source_hash_unbound_count": record_count - source_hash_bound_count,
            "request_binding_match_count": request_binding_match_count,
            "request_binding_mismatch_count": record_count
            - request_binding_match_count,
            "repair_material_source_input_ready_count": source_input_ready_count,
            "repair_material_source_input_blocked_count": record_count
            - source_input_ready_count,
            "referee_rejudge_input_required_count": rejudge_required_count,
            "referee_rejudge_input_ready_count": rejudge_ready_count,
            "referee_rejudge_input_missing_count": rejudge_required_count
            - rejudge_ready_count,
            "closure_chain_source_consistent_count": consistent_count,
            "closure_chain_source_mismatch_count": record_count - consistent_count,
            "request_repair_material_source_rejudge_input_index_record_count": (
                request_count
            ),
            "request_repair_material_source_rejudge_input_index_ready_count": (
                request_ready_count
            ),
            "request_repair_material_source_rejudge_input_index_blocked_count": (
                request_blocked_count
            ),
            "proof_status_source_input_required_count": _count(
                verifier_records, "proof_status"
            ),
            "proof_status_source_input_ready_count": _count(
                verifier_records, "proof_status", "repair_material_source_input_ready"
            ),
            "evidence_manifest_source_input_required_count": _count(
                verifier_records, "evidence_manifest"
            ),
            "evidence_manifest_source_input_ready_count": _count(
                verifier_records,
                "evidence_manifest",
                "repair_material_source_input_ready",
            ),
            "appendix_supplement_source_input_required_count": _count(
                verifier_records, "appendix_supplement"
            ),
            "appendix_supplement_source_input_ready_count": _count(
                verifier_records,
                "appendix_supplement",
                "repair_material_source_input_ready",
            ),
            "claim_downgrade_source_input_required_count": _count(
                verifier_records, "claim_downgrade"
            ),
            "claim_downgrade_source_input_ready_count": _count(
                verifier_records,
                "claim_downgrade",
                "repair_material_source_input_ready",
            ),
            "referee_rejudge_source_input_required_count": _count(
                verifier_records, "referee_rejudge"
            ),
            "referee_rejudge_source_input_ready_count": _count(
                verifier_records,
                "referee_rejudge",
                "repair_material_source_input_ready",
            ),
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "repair_material_source_rejudge_input_index_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "repair_material_source_rejudge_input_index_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies the request-bound source, receipt, hash, request binding, and referee-rejudge input index behind repair-material closure prerequisites.",
            "A ready input index still does not release evidence, promote repair evidence, apply decisions, or close requests.",
            "Input-index verifier records are not proof_status, evidence_manifest, appendix/supplement content, referee rejudge results, release evidence, source-ready closure, request closure, or repair evidence.",
            "The command never writes source, receipt, release request, authorization, decision, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes promotion review; performs promotion review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Material Source Rejudge Input Index Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_repair_material_source_rejudge_input_index_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
