"""Source-authoring prerequisite template verifier for referee repair packets."""

import hashlib
import json


COMMAND = (
    "paper-production-referee-repair-packet-source-authoring-prerequisite-"
    "template-verifier-capstone"
)
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_source_authoring_prerequisite_template_verifier_"
    "capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_source_authoring_prerequisite_template_verifier_state",
    "report_schema",
    "summary",
    "source_authoring_prerequisite_template_verifier_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "source_rejudge_input_index_record_count",
    "source_authoring_redrive_entry_count",
    "source_authoring_prerequisite_template_record_count",
    "hash_bound_source_authoring_prerequisite_template_count",
    "source_authoring_prerequisite_template_lint_ready_count",
    "redrive_entry_present_count",
    "redrive_entry_missing_count",
    "source_packet_template_verified_count",
    "source_packet_template_unverified_count",
    "redrive_receipt_template_verified_count",
    "redrive_receipt_template_unverified_count",
    "required_packet_schema_verified_count",
    "required_packet_schema_missing_count",
    "real_source_material_required_count",
    "real_source_material_present_count",
    "real_source_material_missing_count",
    "source_sha256_required_count",
    "source_sha256_present_count",
    "source_sha256_missing_count",
    "request_binding_required_count",
    "request_binding_present_count",
    "request_binding_missing_count",
    "schema_packet_required_count",
    "schema_packet_present_count",
    "schema_packet_missing_count",
    "real_input_missing_count",
    "source_packet_present_count",
    "source_packet_missing_count",
    "redrive_receipt_present_count",
    "redrive_receipt_missing_count",
    "redrive_receipt_performed_count",
    "redrive_receipt_not_performed_count",
    "source_hash_bound_count",
    "source_hash_unbound_count",
    "request_binding_match_count",
    "request_binding_mismatch_count",
    "redrive_execution_authorized_count",
    "redrive_execution_performed_count",
    "expected_packet_file_creation_performed_count",
    "referee_rejudge_provenance_required_count",
    "referee_rejudge_provenance_ready_count",
    "referee_rejudge_provenance_missing_count",
    "request_source_authoring_prerequisite_template_record_count",
    "request_source_authoring_prerequisite_template_ready_count",
    "request_source_authoring_prerequisite_template_blocked_count",
    "proof_status_source_authoring_prerequisite_required_count",
    "proof_status_source_authoring_prerequisite_ready_count",
    "evidence_manifest_source_authoring_prerequisite_required_count",
    "evidence_manifest_source_authoring_prerequisite_ready_count",
    "appendix_supplement_source_authoring_prerequisite_required_count",
    "appendix_supplement_source_authoring_prerequisite_ready_count",
    "claim_downgrade_source_authoring_prerequisite_required_count",
    "claim_downgrade_source_authoring_prerequisite_ready_count",
    "referee_rejudge_source_authoring_prerequisite_required_count",
    "referee_rejudge_source_authoring_prerequisite_ready_count",
    "evidence_release_performed_count",
    "repair_evidence_promoted_count",
    "request_closure_performed_count",
    "consumable_as_release_or_closure_evidence_count",
    "source_authoring_prerequisite_template_verifier_ready",
    "failed_check_count",
]


REAL_INPUT_NAMES = {
    "real_source_material": "real_request_specific_repair_material",
    "source_sha256": "request_specific_source_sha256",
    "request_binding": "request_binding",
    "schema_packet": "schema_conformant_packet_json",
}


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _key(record):
    return (
        str(record.get("request_id")),
        record.get("slug") or "",
        record.get("packet_type") or "",
        record.get("expected_packet_path") or "",
    )


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def _required_input_present(redrive_entry, name):
    for item in redrive_entry.get("required_real_inputs") or []:
        if item.get("name") == name:
            return bool(item.get("present"))
    return False


def _template_record(source_index_record, redrive_entry):
    source_index_record = dict(source_index_record or {})
    redrive_entry = dict(redrive_entry or {})
    request_id = source_index_record.get("request_id")
    slug = source_index_record.get("slug") or ""
    packet_type = source_index_record.get("packet_type") or ""
    expected_path = source_index_record.get("expected_packet_path") or ""
    expected_receipt_path = (
        source_index_record.get("expected_redrive_execution_receipt_path") or ""
    )
    required_schema = (
        source_index_record.get("required_packet_schema_id")
        or redrive_entry.get("required_packet_schema_id")
        or ""
    )
    source_index_sha = (
        source_index_record.get("repair_material_source_rejudge_input_index_payload_sha256")
        or ""
    )
    redrive_sha = redrive_entry.get("source_slot_authoring_redrive_ledger_payload_sha256") or ""
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_source_authoring_prerequisite_template_"
            "verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "repair_material_source_rejudge_input_index_payload_sha256": source_index_sha,
        "source_slot_authoring_redrive_ledger_payload_sha256": redrive_sha,
    }
    payload_sha = _sha(payload)
    redrive_present = bool(redrive_entry)
    redrive_path_match = bool(
        redrive_present
        and redrive_entry.get("expected_packet_path") == expected_path
        and (redrive_entry.get("request_id") == request_id)
        and (redrive_entry.get("slug") or "") == slug
        and (redrive_entry.get("packet_type") or "") == packet_type
    )
    redrive_hash_bound = bool(
        redrive_present and redrive_entry.get("source_slot_authoring_redrive_ledger_hash_bound")
    )
    redrive_lint_ready = bool(
        redrive_present and redrive_entry.get("source_slot_authoring_redrive_ledger_lint_ready")
    )
    source_packet_template_verified = bool(
        redrive_path_match and redrive_hash_bound and redrive_lint_ready and required_schema
    )
    redrive_receipt_template_verified = bool(
        source_packet_template_verified and expected_receipt_path and redrive_sha
    )
    real_source_present = _required_input_present(
        redrive_entry, REAL_INPUT_NAMES["real_source_material"]
    )
    source_sha_present = _required_input_present(redrive_entry, REAL_INPUT_NAMES["source_sha256"])
    request_binding_present = _required_input_present(
        redrive_entry, REAL_INPUT_NAMES["request_binding"]
    )
    schema_packet_present = _required_input_present(
        redrive_entry, REAL_INPUT_NAMES["schema_packet"]
    )
    real_input_missing_count = _int(redrive_entry.get("real_input_missing_count"))
    if not redrive_present:
        real_input_missing_count = 4
    source_packet_present = bool(source_index_record.get("source_slot_present"))
    receipt_present = bool(source_index_record.get("redrive_execution_receipt_present"))
    receipt_performed = bool(source_index_record.get("redrive_execution_receipt_performed"))
    source_hash_bound = bool(source_index_record.get("source_hash_bound"))
    request_binding_match = bool(source_index_record.get("request_binding_match"))
    rejudge_required = packet_type == "referee_rejudge"
    rejudge_provenance_ready = bool(
        rejudge_required
        and source_index_record.get("referee_rejudge_input_ready")
        and real_source_present
        and source_sha_present
        and request_binding_present
        and schema_packet_present
    )
    action_leak = bool(
        source_index_record.get("evidence_release_performed")
        or source_index_record.get("repair_evidence_promoted")
        or source_index_record.get("request_closure_performed")
        or redrive_entry.get("redrive_execution_authorized")
        or redrive_entry.get("expected_packet_file_creation_performed")
        or redrive_entry.get("consumable_as_repair_evidence")
        or redrive_entry.get("consumable_as_request_closure")
        or redrive_entry.get("consumable_as_referee_rejudge")
    )
    template_ready = bool(
        source_packet_template_verified
        and redrive_receipt_template_verified
        and real_input_missing_count == 0
        and source_packet_present
        and receipt_present
        and receipt_performed
        and source_hash_bound
        and request_binding_match
        and (not rejudge_required or rejudge_provenance_ready)
        and not action_leak
    )
    issues = []
    if not redrive_present:
        issues.append("source_authoring_redrive_entry_missing")
    if not source_packet_template_verified:
        issues.append("source_packet_template_unverified")
    if not redrive_receipt_template_verified:
        issues.append("redrive_receipt_template_unverified")
    if not required_schema:
        issues.append("required_packet_schema_missing")
    if not real_source_present:
        issues.append("real_source_material_missing")
    if not source_sha_present:
        issues.append("request_specific_source_sha256_missing")
    if not request_binding_present:
        issues.append("request_binding_prerequisite_missing")
    if not schema_packet_present:
        issues.append("schema_conformant_packet_json_missing")
    if not source_packet_present:
        issues.append("source_packet_missing")
    if not receipt_present:
        issues.append("redrive_execution_receipt_missing")
    if not receipt_performed:
        issues.append("redrive_execution_receipt_not_performed")
    if not source_hash_bound:
        issues.append("source_hash_unbound")
    if not request_binding_match:
        issues.append("request_binding_mismatch")
    if rejudge_required and not rejudge_provenance_ready:
        issues.append("referee_rejudge_provenance_missing")
    if action_leak:
        issues.append("source_authoring_action_or_evidence_leak")
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "source_authoring_prerequisite_template_verifier_id": (
            "referee-repair-source-authoring-prerequisite-template-"
            f"{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "source_authoring_prerequisite_template_payload_sha256": payload_sha,
        "source_authoring_prerequisite_template_hash_bound": bool(
            payload_sha
            and source_index_record.get("repair_material_source_rejudge_input_index_hash_bound")
            and redrive_hash_bound
        ),
        "source_authoring_prerequisite_template_lint_ready": bool(
            source_index_record.get("repair_material_source_rejudge_input_index_lint_ready")
            and redrive_lint_ready
            and source_packet_template_verified
            and redrive_receipt_template_verified
            and payload_sha
        ),
        "repair_material_source_rejudge_input_index_payload_sha256": source_index_sha,
        "source_slot_authoring_redrive_ledger_payload_sha256": redrive_sha,
        "redrive_entry_present": redrive_present,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "required_packet_schema_id": required_schema,
        "source_packet_template_verified": source_packet_template_verified,
        "redrive_receipt_template_verified": redrive_receipt_template_verified,
        "required_packet_schema_verified": bool(required_schema),
        "real_source_material_required": True,
        "real_source_material_present": real_source_present,
        "source_sha256_required": True,
        "source_sha256_present": source_sha_present,
        "request_binding_required": True,
        "request_binding_present": request_binding_present,
        "schema_packet_required": True,
        "schema_packet_present": schema_packet_present,
        "real_input_missing_count": real_input_missing_count,
        "source_packet_present": source_packet_present,
        "redrive_receipt_present": receipt_present,
        "redrive_receipt_performed": receipt_performed,
        "source_hash_bound": source_hash_bound,
        "request_binding_match": request_binding_match,
        "redrive_execution_authorized": bool(redrive_entry.get("redrive_execution_authorized")),
        "redrive_execution_performed": bool(redrive_entry.get("redrive_execution_performed")),
        "expected_packet_file_creation_performed": bool(
            redrive_entry.get("expected_packet_file_creation_performed")
        ),
        "referee_rejudge_provenance_required": rejudge_required,
        "referee_rejudge_provenance_ready": rejudge_provenance_ready,
        "source_authoring_prerequisite_template_ready": template_ready,
        "source_authoring_prerequisite_template_blockers": issues,
        "evidence_release_performed": bool(source_index_record.get("evidence_release_performed")),
        "repair_evidence_promoted": bool(source_index_record.get("repair_evidence_promoted")),
        "request_closure_performed": bool(source_index_record.get("request_closure_performed")),
        "next_required_action": (
            "ready for source/rejudge input-index revalidation; do not release or close here"
            if template_ready
            else "collect real request-bound source material, packet JSON, source hash, receipt, and referee rejudge provenance"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def _request_record(request_record, verifier_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item
        for item in verifier_records
        if not item.get("source_authoring_prerequisite_template_ready")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_source_authoring_prerequisite_template_"
            "verifier_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "source_authoring_prerequisite_template_payload_sha256s": [
            item.get("source_authoring_prerequisite_template_payload_sha256")
            for item in verifier_records
        ],
    }
    payload_sha = _sha(payload)
    lint_ready = bool(
        request_id is not None
        and slug
        and payload_sha
        and all(
            item.get("source_authoring_prerequisite_template_lint_ready")
            for item in verifier_records
        )
    )
    hash_bound = bool(
        payload_sha
        and all(
            item.get("source_authoring_prerequisite_template_hash_bound")
            for item in verifier_records
        )
    )
    ready = bool(verifier_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_source_authoring_prerequisite_template_verifier_id": (
            "referee-repair-request-source-authoring-prerequisite-template-"
            f"{request_id}-{payload_sha[:16]}"
        ),
        "request_source_authoring_prerequisite_template_payload_sha256": payload_sha,
        "request_source_authoring_prerequisite_template_hash_bound": hash_bound,
        "request_source_authoring_prerequisite_template_lint_ready": lint_ready,
        "source_authoring_prerequisite_template_record_count": len(verifier_records),
        "source_authoring_prerequisite_template_ready_count": sum(
            1
            for item in verifier_records
            if item.get("source_authoring_prerequisite_template_ready")
        ),
        "request_source_authoring_prerequisite_template_ready": ready,
        "request_source_authoring_prerequisite_template_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "source_authoring_prerequisite_template_records": verifier_records,
        "next_required_action": (
            "complete real source-authoring prerequisites for blocked packet types"
            if blocked
            else "source-authoring prerequisites are ready for downstream source/rejudge index revalidation"
        ),
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_release_evidence": False,
        "consumable_as_request_closure": False,
    }


def build_referee_repair_packet_source_authoring_prerequisite_template_verifier_capstone(
    source_rejudge_input_index_verifier_report,
    source_slot_authoring_redrive_ledger_report,
    source_rejudge_input_index_verifier_ref=None,
    source_slot_authoring_redrive_ledger_ref=None,
    label="",
    created_at="",
):
    source_rejudge_input_index_verifier_report = dict(
        source_rejudge_input_index_verifier_report or {}
    )
    source_slot_authoring_redrive_ledger_report = dict(
        source_slot_authoring_redrive_ledger_report or {}
    )
    source_rejudge_input_index_verifier_ref = dict(
        source_rejudge_input_index_verifier_ref or {}
    )
    source_slot_authoring_redrive_ledger_ref = dict(
        source_slot_authoring_redrive_ledger_ref or {}
    )
    index_summary = _summary(source_rejudge_input_index_verifier_report)
    redrive_summary = _summary(source_slot_authoring_redrive_ledger_report)
    request_index_records = [
        dict(item or {})
        for item in source_rejudge_input_index_verifier_report.get(
            "repair_material_source_rejudge_input_index_verifier_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    source_index_records = [
        dict(record or {})
        for request_record in request_index_records
        for record in request_record.get("repair_material_source_rejudge_input_index_records") or []
    ]
    request_redrive_records = [
        dict(item or {})
        for item in source_slot_authoring_redrive_ledger_report.get(
            "source_slot_authoring_redrive_ledger_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    redrive_entries = [
        dict(entry or {})
        for request_record in request_redrive_records
        for entry in request_record.get("source_slot_authoring_redrive_entries") or []
    ]
    redrive_by_key = {_key(entry): entry for entry in redrive_entries}
    index_report_valid = bool(
        source_rejudge_input_index_verifier_ref.get("path")
        and source_rejudge_input_index_verifier_ref.get("sha256_match")
        and source_rejudge_input_index_verifier_report
        and _status(
            source_rejudge_input_index_verifier_report,
            source_rejudge_input_index_verifier_ref,
        )
        in {"PASS", "FAIL"}
    )
    redrive_report_valid = bool(
        source_slot_authoring_redrive_ledger_ref.get("path")
        and source_slot_authoring_redrive_ledger_ref.get("sha256_match")
        and source_slot_authoring_redrive_ledger_report
        and _status(
            source_slot_authoring_redrive_ledger_report,
            source_slot_authoring_redrive_ledger_ref,
        )
        in {"PASS", "FAIL"}
    )
    index_lint_ready = bool(
        index_report_valid
        and _int(index_summary.get("request_repair_material_source_rejudge_input_index_record_count"))
        == len(request_index_records)
        and all(
            request.get("request_repair_material_source_rejudge_input_index_lint_ready")
            for request in request_index_records
        )
        and all(
            record.get("repair_material_source_rejudge_input_index_lint_ready")
            for record in source_index_records
        )
    )
    redrive_lint_ready = bool(
        redrive_report_valid
        and _int(redrive_summary.get("request_redrive_ledger_record_count"))
        == len(request_redrive_records)
        and all(
            request.get("request_source_slot_authoring_redrive_ledger_lint_ready")
            for request in request_redrive_records
        )
        and all(
            entry.get("source_slot_authoring_redrive_ledger_lint_ready")
            for entry in redrive_entries
        )
    )
    request_records = []
    for request_record in sorted(request_index_records, key=lambda item: str(item.get("request_id"))):
        template_records = []
        for source_index in request_record.get("repair_material_source_rejudge_input_index_records") or []:
            source_index = dict(source_index or {})
            template_records.append(
                _template_record(source_index, redrive_by_key.get(_key(source_index)) or {})
            )
        request_records.append(_request_record(request_record, template_records))
    template_records = [
        record
        for request_record in request_records
        for record in request_record.get("source_authoring_prerequisite_template_records") or []
    ]
    record_count = len(template_records)
    request_count = len(request_records)
    request_ready_count = sum(
        1
        for item in request_records
        if item.get("request_source_authoring_prerequisite_template_ready")
    )
    request_blocked_count = request_count - request_ready_count
    hash_bound_count = sum(
        1
        for item in template_records
        if item.get("source_authoring_prerequisite_template_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in template_records
        if item.get("source_authoring_prerequisite_template_lint_ready")
    )
    redrive_present_count = sum(1 for item in template_records if item.get("redrive_entry_present"))
    source_template_verified_count = sum(
        1 for item in template_records if item.get("source_packet_template_verified")
    )
    receipt_template_verified_count = sum(
        1 for item in template_records if item.get("redrive_receipt_template_verified")
    )
    schema_verified_count = sum(
        1 for item in template_records if item.get("required_packet_schema_verified")
    )
    real_source_present_count = sum(
        1 for item in template_records if item.get("real_source_material_present")
    )
    source_sha_present_count = sum(
        1 for item in template_records if item.get("source_sha256_present")
    )
    request_binding_present_count = sum(
        1 for item in template_records if item.get("request_binding_present")
    )
    schema_packet_present_count = sum(
        1 for item in template_records if item.get("schema_packet_present")
    )
    real_input_missing_count = sum(
        item.get("real_input_missing_count") or 0 for item in template_records
    )
    source_packet_present_count = sum(
        1 for item in template_records if item.get("source_packet_present")
    )
    receipt_present_count = sum(
        1 for item in template_records if item.get("redrive_receipt_present")
    )
    receipt_performed_count = sum(
        1 for item in template_records if item.get("redrive_receipt_performed")
    )
    source_hash_bound_count = sum(
        1 for item in template_records if item.get("source_hash_bound")
    )
    request_binding_match_count = sum(
        1 for item in template_records if item.get("request_binding_match")
    )
    rejudge_required_count = sum(
        1 for item in template_records if item.get("referee_rejudge_provenance_required")
    )
    rejudge_ready_count = sum(
        1 for item in template_records if item.get("referee_rejudge_provenance_ready")
    )
    evidence_release_count = sum(
        1
        for item in template_records + request_records
        if item.get("evidence_release_performed")
    )
    promoted_count = sum(
        1
        for item in template_records + request_records
        if item.get("repair_evidence_promoted")
    )
    closure_count = sum(
        1
        for item in template_records + request_records
        if item.get("request_closure_performed")
    )
    consumable_count = sum(
        1
        for item in template_records + request_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_release_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
        or item.get("redrive_execution_authorized")
        or item.get("expected_packet_file_creation_performed")
    )
    ready = bool(
        index_lint_ready
        and redrive_lint_ready
        and record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and redrive_present_count == record_count
        and source_template_verified_count == record_count
        and receipt_template_verified_count == record_count
        and schema_verified_count == record_count
        and real_input_missing_count == 0
        and source_packet_present_count == record_count
        and receipt_present_count == record_count
        and receipt_performed_count == record_count
        and source_hash_bound_count == record_count
        and request_binding_match_count == record_count
        and rejudge_ready_count == rejudge_required_count
        and request_blocked_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "source_rejudge_input_index_verifier_available",
        index_report_valid,
        source_rejudge_input_index_verifier_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_slot_authoring_redrive_ledger_available",
        redrive_report_valid,
        source_slot_authoring_redrive_ledger_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_rejudge_input_index_verifier_lint_ready",
        index_lint_ready,
        f"requests={len(request_index_records)} records={len(source_index_records)}",
    )
    _add_check(
        checks,
        "source_slot_authoring_redrive_ledger_lint_ready",
        redrive_lint_ready,
        f"requests={len(request_redrive_records)} entries={len(redrive_entries)}",
    )
    _add_check(
        checks,
        "all_source_authoring_prerequisite_templates_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_authoring_prerequisite_templates_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_authoring_redrive_entries_present",
        redrive_present_count == record_count,
        f"present={redrive_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_packet_templates_verified",
        source_template_verified_count == record_count,
        f"verified={source_template_verified_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipt_templates_verified",
        receipt_template_verified_count == record_count,
        f"verified={receipt_template_verified_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_real_source_authoring_inputs_present",
        real_input_missing_count == 0,
        f"missing_real_inputs={real_input_missing_count}",
    )
    _add_check(
        checks,
        "all_expected_source_packets_present",
        source_packet_present_count == record_count,
        f"present={source_packet_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipts_present_and_performed",
        receipt_present_count == record_count and receipt_performed_count == record_count,
        f"present={receipt_present_count} performed={receipt_performed_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_hashes_bound",
        source_hash_bound_count == record_count,
        f"bound={source_hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_bindings_match",
        request_binding_match_count == record_count,
        f"match={request_binding_match_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_referee_rejudge_provenance_ready",
        rejudge_ready_count == rejudge_required_count,
        f"ready={rejudge_ready_count} required={rejudge_required_count}",
    )
    _add_check(
        checks,
        "all_request_source_authoring_prerequisite_templates_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "source_authoring_prerequisite_templates_are_not_release_or_closure_evidence",
        consumable_count == 0
        and evidence_release_count == 0
        and promoted_count == 0
        and closure_count == 0,
        (
            f"release={evidence_release_count} promoted={promoted_count} "
            f"closure={closure_count} consumable={consumable_count}"
        ),
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != "PASS"
    ]
    if not index_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_SOURCE_REJUDGE_INDEX_MISSING"
    elif not redrive_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REDRIVE_LEDGER_MISSING"
    elif not index_lint_ready or not redrive_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_UPSTREAM_LINT"
    elif redrive_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REDRIVE_ENTRY_MISSING"
    elif source_template_verified_count != record_count or receipt_template_verified_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_TEMPLATE_UNVERIFIED"
    elif real_input_missing_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REAL_INPUTS_MISSING"
    elif source_packet_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_SOURCE_PACKET_MISSING"
    elif receipt_present_count != record_count or receipt_performed_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REDRIVE_RECEIPT_NOT_READY"
    elif source_hash_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_SOURCE_HASH_NOT_BOUND"
    elif request_binding_match_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REQUEST_BINDING_MISMATCH"
    elif rejudge_ready_count != rejudge_required_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REFEREE_REJUDGE_PROVENANCE"
    elif evidence_release_count or promoted_count or closure_count or consumable_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_ACTION_LEAK"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_REQUEST_TEMPLATE"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_TEMPLATE_VERIFIER"
    else:
        state = "REFEREE_REPAIR_SOURCE_AUTHORING_PREREQUISITE_TEMPLATE_VERIFIER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_source_authoring_prerequisite_template_verifier_state": state,
        "summary": {
            "open_request_count": _int(index_summary.get("open_request_count")),
            "source_rejudge_input_index_record_count": _int(
                index_summary.get("repair_material_source_rejudge_input_index_record_count")
            ),
            "source_authoring_redrive_entry_count": _int(
                redrive_summary.get("redrive_ledger_entry_count")
            ),
            "source_authoring_prerequisite_template_record_count": record_count,
            "hash_bound_source_authoring_prerequisite_template_count": hash_bound_count,
            "source_authoring_prerequisite_template_lint_ready_count": lint_ready_count,
            "redrive_entry_present_count": redrive_present_count,
            "redrive_entry_missing_count": record_count - redrive_present_count,
            "source_packet_template_verified_count": source_template_verified_count,
            "source_packet_template_unverified_count": record_count
            - source_template_verified_count,
            "redrive_receipt_template_verified_count": receipt_template_verified_count,
            "redrive_receipt_template_unverified_count": record_count
            - receipt_template_verified_count,
            "required_packet_schema_verified_count": schema_verified_count,
            "required_packet_schema_missing_count": record_count - schema_verified_count,
            "real_source_material_required_count": record_count,
            "real_source_material_present_count": real_source_present_count,
            "real_source_material_missing_count": record_count - real_source_present_count,
            "source_sha256_required_count": record_count,
            "source_sha256_present_count": source_sha_present_count,
            "source_sha256_missing_count": record_count - source_sha_present_count,
            "request_binding_required_count": record_count,
            "request_binding_present_count": request_binding_present_count,
            "request_binding_missing_count": record_count - request_binding_present_count,
            "schema_packet_required_count": record_count,
            "schema_packet_present_count": schema_packet_present_count,
            "schema_packet_missing_count": record_count - schema_packet_present_count,
            "real_input_missing_count": real_input_missing_count,
            "source_packet_present_count": source_packet_present_count,
            "source_packet_missing_count": record_count - source_packet_present_count,
            "redrive_receipt_present_count": receipt_present_count,
            "redrive_receipt_missing_count": record_count - receipt_present_count,
            "redrive_receipt_performed_count": receipt_performed_count,
            "redrive_receipt_not_performed_count": record_count - receipt_performed_count,
            "source_hash_bound_count": source_hash_bound_count,
            "source_hash_unbound_count": record_count - source_hash_bound_count,
            "request_binding_match_count": request_binding_match_count,
            "request_binding_mismatch_count": record_count - request_binding_match_count,
            "redrive_execution_authorized_count": sum(
                1 for item in template_records if item.get("redrive_execution_authorized")
            ),
            "redrive_execution_performed_count": sum(
                1 for item in template_records if item.get("redrive_execution_performed")
            ),
            "expected_packet_file_creation_performed_count": sum(
                1
                for item in template_records
                if item.get("expected_packet_file_creation_performed")
            ),
            "referee_rejudge_provenance_required_count": rejudge_required_count,
            "referee_rejudge_provenance_ready_count": rejudge_ready_count,
            "referee_rejudge_provenance_missing_count": rejudge_required_count
            - rejudge_ready_count,
            "request_source_authoring_prerequisite_template_record_count": request_count,
            "request_source_authoring_prerequisite_template_ready_count": request_ready_count,
            "request_source_authoring_prerequisite_template_blocked_count": (
                request_blocked_count
            ),
            "proof_status_source_authoring_prerequisite_required_count": _count(
                template_records, "proof_status"
            ),
            "proof_status_source_authoring_prerequisite_ready_count": _count(
                template_records, "proof_status", "source_authoring_prerequisite_template_ready"
            ),
            "evidence_manifest_source_authoring_prerequisite_required_count": _count(
                template_records, "evidence_manifest"
            ),
            "evidence_manifest_source_authoring_prerequisite_ready_count": _count(
                template_records,
                "evidence_manifest",
                "source_authoring_prerequisite_template_ready",
            ),
            "appendix_supplement_source_authoring_prerequisite_required_count": _count(
                template_records, "appendix_supplement"
            ),
            "appendix_supplement_source_authoring_prerequisite_ready_count": _count(
                template_records,
                "appendix_supplement",
                "source_authoring_prerequisite_template_ready",
            ),
            "claim_downgrade_source_authoring_prerequisite_required_count": _count(
                template_records, "claim_downgrade"
            ),
            "claim_downgrade_source_authoring_prerequisite_ready_count": _count(
                template_records,
                "claim_downgrade",
                "source_authoring_prerequisite_template_ready",
            ),
            "referee_rejudge_source_authoring_prerequisite_required_count": _count(
                template_records, "referee_rejudge"
            ),
            "referee_rejudge_source_authoring_prerequisite_ready_count": _count(
                template_records,
                "referee_rejudge",
                "source_authoring_prerequisite_template_ready",
            ),
            "evidence_release_performed_count": evidence_release_count,
            "repair_evidence_promoted_count": promoted_count,
            "request_closure_performed_count": closure_count,
            "consumable_as_release_or_closure_evidence_count": consumable_count,
            "source_authoring_prerequisite_template_verifier_ready": ready,
            "failed_check_count": len(failed),
        },
        "source_authoring_prerequisite_template_verifier_records": request_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only verifies source-authoring prerequisite templates for missing referee repair packet source slots.",
            "A verified prerequisite template is not a packet source, receipt, proof_status update, evidence_manifest update, appendix/supplement, referee rejudge result, release evidence, or closure evidence.",
            "The command never writes source packets, receipts, release requests, authorization packets, decision packets, or closure files; edits manuscripts; applies patches; rebuilds packages; uploads; emails; submits; performs external actions; authorizes review; releases evidence; promotes repair evidence; closes requests; or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Source Authoring Prerequisite Template Verifier",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        "- State: "
        f"{report.get('referee_repair_packet_source_authoring_prerequisite_template_verifier_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
