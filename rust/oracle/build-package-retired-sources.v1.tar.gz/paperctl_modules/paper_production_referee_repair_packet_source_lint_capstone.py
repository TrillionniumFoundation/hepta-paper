"""Source-discovery lint for referee repair packets."""


COMMAND = "paper-production-referee-repair-packet-source-lint-capstone"
SCHEMA_ID = "paper_factory.paper_production.referee_repair_packet_source_lint_capstone.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_source_lint_state",
    "report_schema",
    "summary",
    "source_lint_items",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "required_packet_count",
    "source_present_count",
    "source_missing_count",
    "source_lint_pass_count",
    "source_lint_failed_count",
    "proof_status_source_present_count",
    "proof_status_source_lint_pass_count",
    "evidence_manifest_source_present_count",
    "evidence_manifest_source_lint_pass_count",
    "appendix_supplement_source_present_count",
    "appendix_supplement_source_lint_pass_count",
    "claim_downgrade_source_present_count",
    "claim_downgrade_source_lint_pass_count",
    "referee_rejudge_source_present_count",
    "referee_rejudge_source_lint_pass_count",
    "source_ready_invalidation_source_present_count",
    "source_ready_invalidation_source_lint_pass_count",
    "packet_completion_ready",
    "source_lint_ready",
    "failed_check_count",
]


PACKET_TYPES = [
    "proof_status",
    "evidence_manifest",
    "appendix_supplement",
    "claim_downgrade",
    "referee_rejudge",
    "source_ready_invalidation",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _source_entry(inventory, slug, packet_type):
    inventory = inventory or {}
    slug_sources = ((inventory.get("sources_by_slug") or {}).get(slug) or {})
    global_sources = inventory.get("global_sources") or {}
    source = slug_sources.get(packet_type) or global_sources.get(packet_type) or {}
    return source if isinstance(source, dict) else {}


def _source_item(packet, source):
    source = dict(source or {})
    paths = list(source.get("paths") or ([] if not source.get("path") else [source.get("path")]))
    issues = list(source.get("issues") or [])
    source_present = bool(source.get("present") or paths)
    source_lint_pass = bool(source_present and source.get("lint_pass") is True and not issues)
    if not source_present and not issues:
        issues.append("required packet source is missing")
    elif source_present and source.get("lint_pass") is not True and not issues:
        issues.append("required packet source did not pass lint")
    return {
        "request_id": packet.get("request_id"),
        "slug": packet.get("slug") or "",
        "packet_type": packet.get("packet_type") or "",
        "packet_id": packet.get("packet_id") or "",
        "packet_payload_sha256": packet.get("packet_payload_sha256") or "",
        "packet_required": bool(packet.get("packet_required")),
        "source_present": source_present,
        "source_lint_pass": source_lint_pass,
        "source_paths": paths,
        "source_sha256s": list(source.get("sha256s") or []),
        "source_issue_count": len(issues),
        "source_issues": issues[:20],
        "source_discovery_kind": source.get("kind") or packet.get("packet_type") or "",
        "source_request_specific": bool(source.get("request_specific")),
        "consumable_as_repair_evidence": False,
        "consumable_as_request_closure": False,
    }


def _count(items, packet_type, key):
    return sum(1 for item in items if item.get("packet_type") == packet_type and item.get(key))


def build_referee_repair_packet_source_lint_capstone(
    packet_readiness_report,
    packet_readiness_ref=None,
    source_inventory=None,
    label="",
    created_at="",
):
    packet_readiness_report = dict(packet_readiness_report or {})
    packet_readiness_ref = dict(packet_readiness_ref or {})
    packet_summary = _summary(packet_readiness_report)
    packets = [
        dict(item or {})
        for item in packet_readiness_report.get("packet_readiness_items") or []
        if item.get("packet_required")
    ]
    packet_report_valid = bool(
        packet_readiness_ref.get("path")
        and packet_readiness_ref.get("sha256_match")
        and packet_readiness_report
        and _status(packet_readiness_report, packet_readiness_ref) in {"PASS", "FAIL"}
    )
    packet_lint_contract_ready = bool(
        packet_report_valid
        and _int(packet_summary.get("required_packet_count")) == len(packets)
        and _int(packet_summary.get("packet_lint_ready_count")) == len(packets)
    )
    source_items = [
        _source_item(packet, _source_entry(source_inventory, packet.get("slug") or "", packet.get("packet_type") or ""))
        for packet in packets
    ]
    required_packet_count = len(source_items)
    source_present_count = sum(1 for item in source_items if item.get("source_present"))
    source_lint_pass_count = sum(1 for item in source_items if item.get("source_lint_pass"))
    source_missing_count = required_packet_count - source_present_count
    source_lint_failed_count = required_packet_count - source_lint_pass_count
    source_lint_ready = bool(
        packet_lint_contract_ready
        and required_packet_count
        and source_missing_count == 0
        and source_lint_failed_count == 0
        and not any(item.get("consumable_as_request_closure") for item in source_items)
    )
    checks = []
    _add_check(
        checks,
        "referee_repair_packet_readiness_capstone_available",
        packet_report_valid,
        packet_readiness_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "referee_repair_packet_lint_contract_ready",
        packet_lint_contract_ready,
        f"required={packet_summary.get('required_packet_count')} lint_ready={packet_summary.get('packet_lint_ready_count')} observed={len(packets)}",
    )
    _add_check(
        checks,
        "all_required_packet_sources_present",
        source_missing_count == 0,
        f"missing={source_missing_count} required={required_packet_count}",
    )
    _add_check(
        checks,
        "all_required_packet_sources_lint_pass",
        source_lint_failed_count == 0,
        f"lint_failed={source_lint_failed_count} required={required_packet_count}",
    )
    _add_check(
        checks,
        "packet_source_lint_records_are_not_closure_evidence",
        not any(
            item.get("consumable_as_repair_evidence")
            or item.get("consumable_as_request_closure")
            for item in source_items
        ),
        "source-lint records remain audit records only",
    )
    failed = [check for check in checks if check.get("blocking") and check.get("status") != "PASS"]
    if not packet_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_READINESS_REPORT_MISSING"
    elif not packet_lint_contract_ready:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_LINT_CONTRACT_NOT_READY"
    elif source_missing_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCES_MISSING"
    elif source_lint_failed_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_LINT"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_LINT_CAPSTONE"
    else:
        state = "REFEREE_REPAIR_PACKET_SOURCE_LINT_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_source_lint_state": state,
        "summary": {
            "open_request_count": _int(packet_summary.get("open_request_count")),
            "required_packet_count": required_packet_count,
            "source_present_count": source_present_count,
            "source_missing_count": source_missing_count,
            "source_lint_pass_count": source_lint_pass_count,
            "source_lint_failed_count": source_lint_failed_count,
            "proof_status_source_present_count": _count(source_items, "proof_status", "source_present"),
            "proof_status_source_lint_pass_count": _count(source_items, "proof_status", "source_lint_pass"),
            "evidence_manifest_source_present_count": _count(source_items, "evidence_manifest", "source_present"),
            "evidence_manifest_source_lint_pass_count": _count(source_items, "evidence_manifest", "source_lint_pass"),
            "appendix_supplement_source_present_count": _count(source_items, "appendix_supplement", "source_present"),
            "appendix_supplement_source_lint_pass_count": _count(source_items, "appendix_supplement", "source_lint_pass"),
            "claim_downgrade_source_present_count": _count(source_items, "claim_downgrade", "source_present"),
            "claim_downgrade_source_lint_pass_count": _count(source_items, "claim_downgrade", "source_lint_pass"),
            "referee_rejudge_source_present_count": _count(source_items, "referee_rejudge", "source_present"),
            "referee_rejudge_source_lint_pass_count": _count(source_items, "referee_rejudge", "source_lint_pass"),
            "source_ready_invalidation_source_present_count": _count(source_items, "source_ready_invalidation", "source_present"),
            "source_ready_invalidation_source_lint_pass_count": _count(source_items, "source_ready_invalidation", "source_lint_pass"),
            "packet_completion_ready": bool(packet_summary.get("repair_packet_completion_ready")),
            "source_lint_ready": source_lint_ready,
            "failed_check_count": len(failed),
        },
        "source_lint_items": source_items,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone discovers and lints existing local sources for required referee repair packets only.",
            "Source-lint records are not proof_status.md, evidence_manifest.md, appendix/supplement content, referee rejudge results, or request closure evidence.",
            "PASS here means source discovery/lint passed; packet completion and request closure remain separate downstream gates.",
            "The command never edits manuscripts, creates proof evidence, applies patches, rebuilds packages, uploads, emails, submits, or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Packet Source-Lint Capstone",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_packet_source_lint_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(
        [
            "",
            "## Source Lint",
            "",
            "| request | slug | packet | source present | lint pass | issues |",
            "| ---: | --- | --- | --- | --- | ---: |",
        ]
    )
    for item in report.get("source_lint_items") or []:
        lines.append(
            f"| {item.get('request_id', '')} | {item.get('slug', '')} | "
            f"{item.get('packet_type', '')} | {item.get('source_present')} | "
            f"{item.get('source_lint_pass')} | {item.get('source_issue_count', 0)} |"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
