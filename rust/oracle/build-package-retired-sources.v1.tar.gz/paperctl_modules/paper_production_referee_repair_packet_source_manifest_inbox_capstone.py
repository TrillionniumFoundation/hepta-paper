"""Source manifest inbox gate for referee repair packets."""

import hashlib
import json


COMMAND = "paper-production-referee-repair-packet-source-manifest-inbox-capstone"
SCHEMA_ID = "paper_factory.paper_production.referee_repair_packet_source_manifest_inbox_capstone.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_source_manifest_inbox_state",
    "report_schema",
    "summary",
    "source_manifest_inbox_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "request_with_gap_count",
    "source_binding_record_count",
    "source_manifest_record_count",
    "hash_bound_source_manifest_count",
    "source_manifest_lint_ready_count",
    "request_bound_source_manifest_count",
    "required_source_manifest_count",
    "source_manifest_present_count",
    "source_manifest_missing_count",
    "request_specific_source_hash_present_count",
    "request_specific_source_hash_bound_count",
    "closure_audit_eligible_upstream_count",
    "closure_audit_ineligible_upstream_count",
    "repair_packet_inbox_ready_count",
    "repair_packet_inbox_blocked_count",
    "proof_status_source_manifest_required_count",
    "proof_status_source_manifest_present_count",
    "evidence_manifest_source_manifest_required_count",
    "evidence_manifest_source_manifest_present_count",
    "appendix_supplement_source_manifest_required_count",
    "appendix_supplement_source_manifest_present_count",
    "claim_downgrade_source_manifest_required_count",
    "claim_downgrade_source_manifest_present_count",
    "referee_rejudge_source_manifest_required_count",
    "referee_rejudge_source_manifest_present_count",
    "missing_source_binding_count",
    "source_lint_issue_binding_count",
    "request_binding_gap_count",
    "source_ready_invalidation_clean_request_count",
    "consumable_as_repair_packet_count",
    "packet_source_manifest_inbox_ready",
    "failed_check_count",
]


MANIFEST_BY_PACKET_TYPE = {
    "proof_status": (
        "proof_status_update_source_manifest",
        "request-specific proof_status update source manifest",
    ),
    "evidence_manifest": (
        "evidence_manifest_boundary_source_manifest",
        "request-specific evidence_manifest boundary source manifest",
    ),
    "appendix_supplement": (
        "appendix_supplement_source_manifest",
        "request-specific appendix or supplement source manifest",
    ),
    "claim_downgrade": (
        "claim_downgrade_request_binding_source_manifest",
        "request-specific claim downgrade or no-downgrade binding source manifest",
    ),
    "referee_rejudge": (
        "referee_rejudge_result_source_manifest",
        "request-specific referee rejudge result source manifest",
    ),
}


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _source_hashes(record):
    values = (
        record.get("request_specific_source_hashes")
        or record.get("source_sha256s")
        or ([] if not record.get("source_sha256") else [record.get("source_sha256")])
    )
    return [str(item) for item in values or [] if item]


def _manifest_record(record):
    packet_type = record.get("packet_type") or ""
    manifest_type, requirement = MANIFEST_BY_PACKET_TYPE.get(
        packet_type,
        (
            f"{packet_type}_source_manifest",
            "request-specific referee repair packet source manifest",
        ),
    )
    source_hashes = _source_hashes(record)
    source_gap_state = record.get("source_gap_state") or ""
    payload = {
        "schema_id": "paper_factory.paper_production.referee_repair_packet_source_manifest_inbox.v1",
        "request_id": record.get("request_id"),
        "slug": record.get("slug") or "",
        "packet_type": packet_type,
        "source_binding_payload_sha256": record.get("source_binding_payload_sha256") or "",
        "source_manifest_type": manifest_type,
        "source_sha256s": source_hashes,
    }
    payload_sha = _sha(payload)
    request_bound = bool(
        record.get("request_bound")
        and record.get("request_id") is not None
        and record.get("slug")
    )
    source_hash_present = bool(source_hashes)
    source_hash_bound = bool(
        source_hash_present
        and record.get("request_specific_source_hash_bound")
        and record.get("source_binding_hash_bound")
        and payload.get("source_binding_payload_sha256")
    )
    closure_eligible = bool(record.get("closure_audit_eligible"))
    manifest_present = bool(closure_eligible and source_hash_bound)
    lint_ready = bool(
        record.get("source_binding_lint_ready")
        and request_bound
        and packet_type
        and manifest_type
        and payload.get("source_binding_payload_sha256")
    )
    inbox_ready = bool(
        lint_ready
        and manifest_present
        and source_hash_bound
        and closure_eligible
        and source_gap_state not in {
            "MISSING_SOURCE",
            "SOURCE_LINT_ISSUE",
            "REQUEST_SPECIFIC_SOURCE_GAP",
        }
    )
    return {
        "request_id": record.get("request_id"),
        "slug": record.get("slug") or "",
        "packet_type": packet_type,
        "source_manifest_type": manifest_type,
        "source_manifest_requirement": requirement,
        "source_binding_payload_sha256": payload.get("source_binding_payload_sha256"),
        "source_manifest_payload_sha256": payload_sha,
        "source_manifest_hash_bound": bool(record.get("source_binding_hash_bound") and payload_sha),
        "source_manifest_lint_ready": lint_ready,
        "source_manifest_required": True,
        "source_manifest_present": manifest_present,
        "source_manifest_missing": not manifest_present,
        "request_bound": request_bound,
        "source_gap_state": source_gap_state,
        "missing_source": source_gap_state == "MISSING_SOURCE",
        "source_lint_issue": source_gap_state == "SOURCE_LINT_ISSUE",
        "request_binding_gap": source_gap_state == "REQUEST_SPECIFIC_SOURCE_GAP",
        "request_specific_source_hashes": source_hashes,
        "request_specific_source_hash_present": source_hash_present,
        "request_specific_source_hash_bound": source_hash_bound,
        "upstream_closure_audit_eligible": closure_eligible,
        "repair_packet_inbox_ready": inbox_ready,
        "repair_packet_inbox_materialized": manifest_present,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_proof_status": False,
        "consumable_as_evidence_manifest": False,
        "consumable_as_appendix_supplement": False,
        "consumable_as_referee_rejudge": False,
        "consumable_as_request_closure": False,
        "next_required_source_manifest": record.get("next_required_closure_audit") or requirement,
    }


def _count(records, packet_type, key):
    return sum(1 for item in records if item.get("packet_type") == packet_type and item.get(key))


def build_referee_repair_packet_source_manifest_inbox_capstone(
    source_binding_closure_audit_report,
    source_binding_closure_audit_ref=None,
    label="",
    created_at="",
):
    source_binding_closure_audit_report = dict(source_binding_closure_audit_report or {})
    source_binding_closure_audit_ref = dict(source_binding_closure_audit_ref or {})
    binding_summary = _summary(source_binding_closure_audit_report)
    binding_records = [
        dict(item or {})
        for item in source_binding_closure_audit_report.get("source_binding_closure_records") or []
        if item.get("packet_type")
    ]
    binding_report_valid = bool(
        source_binding_closure_audit_ref.get("path")
        and source_binding_closure_audit_ref.get("sha256_match")
        and source_binding_closure_audit_report
        and _status(source_binding_closure_audit_report, source_binding_closure_audit_ref)
        in {"PASS", "FAIL"}
    )
    binding_lint_ready = bool(
        binding_report_valid
        and _int(binding_summary.get("source_binding_record_count")) == len(binding_records)
        and _int(binding_summary.get("source_binding_lint_ready_count")) == len(binding_records)
    )
    records = [_manifest_record(record) for record in binding_records]
    record_count = len(records)
    hash_bound_count = sum(1 for item in records if item.get("source_manifest_hash_bound"))
    lint_ready_count = sum(1 for item in records if item.get("source_manifest_lint_ready"))
    request_bound_count = sum(1 for item in records if item.get("request_bound"))
    required_count = sum(1 for item in records if item.get("source_manifest_required"))
    present_count = sum(1 for item in records if item.get("source_manifest_present"))
    missing_count = sum(1 for item in records if item.get("source_manifest_missing"))
    source_hash_present_count = sum(
        1 for item in records if item.get("request_specific_source_hash_present")
    )
    source_hash_bound_count = sum(
        1 for item in records if item.get("request_specific_source_hash_bound")
    )
    upstream_eligible_count = sum(
        1 for item in records if item.get("upstream_closure_audit_eligible")
    )
    upstream_ineligible_count = record_count - upstream_eligible_count
    inbox_ready_count = sum(1 for item in records if item.get("repair_packet_inbox_ready"))
    inbox_blocked_count = record_count - inbox_ready_count
    missing_source_count = sum(1 for item in records if item.get("missing_source"))
    source_lint_issue_count = sum(1 for item in records if item.get("source_lint_issue"))
    request_binding_gap_count = sum(1 for item in records if item.get("request_binding_gap"))
    consumable_count = sum(
        1
        for item in records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("consumable_as_referee_rejudge")
    )
    inbox_ready = bool(
        binding_lint_ready
        and (record_count == 0 or hash_bound_count == record_count)
        and (record_count == 0 or lint_ready_count == record_count)
        and request_bound_count == record_count
        and present_count == required_count
        and source_hash_present_count == record_count
        and source_hash_bound_count == record_count
        and upstream_eligible_count == record_count
        and inbox_ready_count == record_count
        and missing_source_count == 0
        and source_lint_issue_count == 0
        and request_binding_gap_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "referee_repair_packet_source_binding_closure_audit_capstone_available",
        binding_report_valid,
        source_binding_closure_audit_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "referee_repair_packet_source_binding_closure_audit_lint_ready",
        binding_lint_ready,
        f"required={binding_summary.get('source_binding_record_count')} lint_ready={binding_summary.get('source_binding_lint_ready_count')} observed={len(binding_records)}",
    )
    _add_check(
        checks,
        "all_packet_source_manifest_records_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} required={record_count}",
    )
    _add_check(
        checks,
        "all_packet_source_manifest_records_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} required={record_count}",
    )
    _add_check(
        checks,
        "all_packet_source_manifest_records_request_bound",
        request_bound_count == record_count,
        f"request_bound={request_bound_count} required={record_count}",
    )
    _add_check(
        checks,
        "all_required_packet_source_manifests_present",
        present_count == required_count,
        f"present={present_count} required={required_count}",
    )
    _add_check(
        checks,
        "all_packet_source_manifests_have_source_hash",
        source_hash_present_count == record_count,
        f"source_hash_present={source_hash_present_count} required={record_count}",
    )
    _add_check(
        checks,
        "all_packet_source_manifests_source_hash_bound",
        source_hash_bound_count == record_count,
        f"source_hash_bound={source_hash_bound_count} required={record_count}",
    )
    _add_check(
        checks,
        "all_upstream_source_binding_records_closure_eligible",
        upstream_eligible_count == record_count,
        f"closure_eligible={upstream_eligible_count} required={record_count}",
    )
    _add_check(
        checks,
        "all_repair_packet_inbox_entries_ready",
        inbox_ready_count == record_count,
        f"inbox_ready={inbox_ready_count} required={record_count}",
    )
    _add_check(
        checks,
        "no_source_manifest_missing_source",
        missing_source_count == 0,
        f"missing_source={missing_source_count}",
    )
    _add_check(
        checks,
        "no_source_manifest_source_lint_issue",
        source_lint_issue_count == 0,
        f"source_lint_issue={source_lint_issue_count}",
    )
    _add_check(
        checks,
        "no_source_manifest_request_binding_gap",
        request_binding_gap_count == 0,
        f"request_binding_gap={request_binding_gap_count}",
    )
    _add_check(
        checks,
        "source_manifest_records_are_not_repair_packets_or_closure",
        consumable_count == 0,
        f"consumable={consumable_count}",
    )
    failed = [check for check in checks if check.get("blocking") and check.get("status") != "PASS"]
    if not binding_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_BINDING_CLOSURE_AUDIT_REPORT_MISSING"
    elif not binding_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_UPSTREAM_BINDING"
    elif hash_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_HASH"
    elif lint_ready_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_LINT"
    elif request_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_REQUEST"
    elif present_count != required_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_MISSING"
    elif source_hash_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_SOURCE_HASH_MISSING"
    elif source_hash_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_SOURCE_HASH"
    elif upstream_eligible_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_UPSTREAM_CLOSURE_INELIGIBLE"
    elif inbox_ready_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_INBOX_NOT_READY"
    elif missing_source_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_SOURCE_MISSING"
    elif source_lint_issue_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_SOURCE_LINT"
    elif request_binding_gap_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_REQUEST_GAP"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_INBOX"
    else:
        state = "REFEREE_REPAIR_PACKET_SOURCE_MANIFEST_INBOX_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_source_manifest_inbox_state": state,
        "summary": {
            "open_request_count": _int(binding_summary.get("open_request_count")),
            "request_with_gap_count": _int(binding_summary.get("request_with_gap_count")),
            "source_binding_record_count": _int(binding_summary.get("source_binding_record_count")),
            "source_manifest_record_count": record_count,
            "hash_bound_source_manifest_count": hash_bound_count,
            "source_manifest_lint_ready_count": lint_ready_count,
            "request_bound_source_manifest_count": request_bound_count,
            "required_source_manifest_count": required_count,
            "source_manifest_present_count": present_count,
            "source_manifest_missing_count": missing_count,
            "request_specific_source_hash_present_count": source_hash_present_count,
            "request_specific_source_hash_bound_count": source_hash_bound_count,
            "closure_audit_eligible_upstream_count": upstream_eligible_count,
            "closure_audit_ineligible_upstream_count": upstream_ineligible_count,
            "repair_packet_inbox_ready_count": inbox_ready_count,
            "repair_packet_inbox_blocked_count": inbox_blocked_count,
            "proof_status_source_manifest_required_count": sum(
                1 for item in records if item.get("packet_type") == "proof_status"
            ),
            "proof_status_source_manifest_present_count": _count(
                records, "proof_status", "source_manifest_present"
            ),
            "evidence_manifest_source_manifest_required_count": sum(
                1 for item in records if item.get("packet_type") == "evidence_manifest"
            ),
            "evidence_manifest_source_manifest_present_count": _count(
                records, "evidence_manifest", "source_manifest_present"
            ),
            "appendix_supplement_source_manifest_required_count": sum(
                1 for item in records if item.get("packet_type") == "appendix_supplement"
            ),
            "appendix_supplement_source_manifest_present_count": _count(
                records, "appendix_supplement", "source_manifest_present"
            ),
            "claim_downgrade_source_manifest_required_count": sum(
                1 for item in records if item.get("packet_type") == "claim_downgrade"
            ),
            "claim_downgrade_source_manifest_present_count": _count(
                records, "claim_downgrade", "source_manifest_present"
            ),
            "referee_rejudge_source_manifest_required_count": sum(
                1 for item in records if item.get("packet_type") == "referee_rejudge"
            ),
            "referee_rejudge_source_manifest_present_count": _count(
                records, "referee_rejudge", "source_manifest_present"
            ),
            "missing_source_binding_count": missing_source_count,
            "source_lint_issue_binding_count": source_lint_issue_count,
            "request_binding_gap_count": request_binding_gap_count,
            "source_ready_invalidation_clean_request_count": _int(
                binding_summary.get("source_ready_invalidation_clean_request_count")
            ),
            "consumable_as_repair_packet_count": consumable_count,
            "packet_source_manifest_inbox_ready": inbox_ready,
            "failed_check_count": len(failed),
        },
        "source_manifest_inbox_records": records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone audits request-specific source manifest and repair packet inbox readiness for referee repair packets.",
            "Source-manifest inbox records are not repair evidence, proof-status updates, evidence manifests, appendix/supplement content, referee rejudge results, source-ready closure, or request closure evidence.",
            "Missing source manifests, missing source hashes, upstream closure ineligibility, source issues, or request gaps keep referee repair and downstream readiness fail-closed.",
            "The command never edits manuscripts, creates proof evidence, applies patches, rebuilds packages, uploads, emails, submits, or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Packet Source Manifest Inbox Capstone",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_packet_source_manifest_inbox_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(
        [
            "",
            "## Source Manifest Inbox Records",
            "",
            "| request | slug | packet | manifest | hash-bound | lint-ready | source hash | manifest present | inbox ready |",
            "| ---: | --- | --- | --- | --- | --- | --- | --- | --- |",
        ]
    )
    for item in report.get("source_manifest_inbox_records") or []:
        lines.append(
            f"| {item.get('request_id', '')} | {item.get('slug', '')} | "
            f"{item.get('packet_type', '')} | {item.get('source_manifest_type', '')} | "
            f"{item.get('source_manifest_hash_bound')} | "
            f"{item.get('source_manifest_lint_ready')} | "
            f"{item.get('request_specific_source_hash_present')} | "
            f"{item.get('source_manifest_present')} | "
            f"{item.get('repair_packet_inbox_ready')} |"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
