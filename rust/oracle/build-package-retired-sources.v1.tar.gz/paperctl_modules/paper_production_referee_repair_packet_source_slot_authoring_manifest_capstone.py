"""Source-slot authoring manifest for referee repair packet sources."""

import hashlib
import json


COMMAND = "paper-production-referee-repair-packet-source-slot-authoring-manifest-capstone"
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_source_slot_authoring_manifest_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_source_slot_authoring_manifest_state",
    "report_schema",
    "summary",
    "source_slot_authoring_manifest_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "request_with_gap_count",
    "packet_skeleton_inventory_record_count",
    "source_slot_stale_or_missing_count",
    "source_slot_authoring_manifest_record_count",
    "hash_bound_source_slot_authoring_manifest_count",
    "source_slot_authoring_manifest_lint_ready_count",
    "safe_draft_queue_entry_count",
    "safe_draft_queue_ready_count",
    "safe_draft_queue_blocked_count",
    "source_slot_authoring_complete_count",
    "source_slot_authoring_incomplete_count",
    "required_json_schema_count",
    "source_hash_checklist_item_count",
    "validation_redrive_plan_count",
    "request_authoring_manifest_record_count",
    "request_authoring_manifest_ready_count",
    "request_authoring_manifest_blocked_count",
    "proof_status_authoring_required_count",
    "proof_status_authoring_complete_count",
    "evidence_manifest_authoring_required_count",
    "evidence_manifest_authoring_complete_count",
    "appendix_supplement_authoring_required_count",
    "appendix_supplement_authoring_complete_count",
    "claim_downgrade_authoring_required_count",
    "claim_downgrade_authoring_complete_count",
    "referee_rejudge_authoring_required_count",
    "referee_rejudge_authoring_complete_count",
    "upstream_skeleton_current_count",
    "upstream_skeleton_blocked_count",
    "consumable_as_repair_evidence_authoring_count",
    "source_slot_authoring_manifest_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _required_json_fields(slot_record):
    return [
        {"name": "schema_id", "required_value": slot_record.get("expected_packet_schema_id") or ""},
        {"name": "request_id", "required_value": slot_record.get("request_id")},
        {"name": "slug", "required_value": slot_record.get("slug") or ""},
        {"name": "packet_type", "required_value": slot_record.get("packet_type") or ""},
        {
            "name": "request_specific_source_sha256",
            "required_value": "real request-specific source sha256 required",
        },
        {
            "name": "request_specific_source_hash_bound",
            "required_value": True,
        },
    ]


def _source_hash_checklist(slot_record):
    return [
        {
            "name": "real_source_material_selected",
            "required": True,
            "satisfied": bool(slot_record.get("source_slot_current")),
            "detail": "Select real local repair material; do not synthesize a hash.",
        },
        {
            "name": "request_specific_source_sha256_present",
            "required": True,
            "satisfied": bool(slot_record.get("source_hash_present")),
            "detail": "Hash must come from the real request-specific packet source.",
        },
        {
            "name": "source_hash_bound_to_request_packet",
            "required": True,
            "satisfied": bool(slot_record.get("source_hash_bound")),
            "detail": "Hash must bind to request_id, slug, and packet_type.",
        },
        {
            "name": "slot_revalidates_in_skeleton_inventory_currentness",
            "required": True,
            "satisfied": bool(slot_record.get("source_slot_current")),
            "detail": "Rerun skeleton inventory/currentness after authoring the source slot.",
        },
    ]


def _authoring_manifest(slot_record):
    request_id = slot_record.get("request_id")
    slug = slot_record.get("slug") or ""
    packet_type = slot_record.get("packet_type") or ""
    expected_path = slot_record.get("expected_packet_path") or ""
    expected_schema_id = slot_record.get("expected_packet_schema_id") or ""
    issues = list(slot_record.get("source_slot_currentness_issues") or [])
    action = (
        "refresh_request_specific_repair_packet_source_slot"
        if slot_record.get("source_slot_present")
        else "create_request_specific_repair_packet_source_slot"
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_source_slot_authoring_manifest.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_path,
        "expected_packet_schema_id": expected_schema_id,
        "upstream_packet_skeleton_inventory_payload_sha256": slot_record.get(
            "packet_skeleton_inventory_payload_sha256"
        )
        or "",
        "authoring_action": action,
    }
    payload_sha = _sha(payload)
    lint_ready = bool(
        request_id is not None
        and slug
        and packet_type
        and expected_path
        and expected_schema_id
        and slot_record.get("packet_skeleton_inventory_hash_bound")
        and slot_record.get("packet_skeleton_inventory_lint_ready")
        and payload_sha
    )
    source_hash_checklist = _source_hash_checklist(slot_record)
    authoring_complete = bool(slot_record.get("source_slot_current"))
    safe_queue_ready = bool(lint_ready and not authoring_complete)
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "source_slot_authoring_manifest_id": (
            f"referee-repair-source-slot-authoring-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "source_slot_authoring_manifest_payload_sha256": payload_sha,
        "source_slot_authoring_manifest_hash_bound": bool(
            payload_sha and slot_record.get("packet_skeleton_inventory_hash_bound")
        ),
        "source_slot_authoring_manifest_lint_ready": lint_ready,
        "expected_packet_path": expected_path,
        "required_packet_schema_id": expected_schema_id,
        "authoring_action": action,
        "source_slot_currentness_issues": issues,
        "required_json_fields": _required_json_fields(slot_record),
        "source_hash_binding_checklist": source_hash_checklist,
        "source_hash_checklist_item_count": len(source_hash_checklist),
        "source_hash_checklist_satisfied_count": sum(
            1 for item in source_hash_checklist if item.get("satisfied")
        ),
        "validation_redrive_plan": [
            "author real request-specific packet source material outside this report",
            "write it to expected_packet_path with the required schema and binding fields",
            "rerun paper-production-referee-repair-packet-skeleton-inventory-currentness-capstone",
            "rerun downstream material validation and closure prerequisite audits",
        ],
        "safe_local_draft_queue_entry": True,
        "safe_local_draft_queue_ready": safe_queue_ready,
        "source_slot_authoring_complete": authoring_complete,
        "source_slot_authoring_blocked": not authoring_complete,
        "expected_packet_file_creation_performed": False,
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_proof_status": False,
        "consumable_as_evidence_manifest": False,
        "consumable_as_appendix_supplement": False,
        "consumable_as_referee_rejudge": False,
        "consumable_as_request_closure": False,
    }


def _request_authoring_record(request_record, authoring_manifests):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_source_slot_authoring_manifest.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "source_slot_authoring_manifest_payload_sha256s": [
            item.get("source_slot_authoring_manifest_payload_sha256")
            for item in authoring_manifests
        ],
    }
    payload_sha = _sha(payload)
    ready = not authoring_manifests
    return {
        "request_id": request_id,
        "slug": slug,
        "request_source_slot_authoring_manifest_id": (
            f"referee-repair-request-source-slot-authoring-{request_id}-{payload_sha[:16]}"
        ),
        "request_source_slot_authoring_manifest_payload_sha256": payload_sha,
        "request_source_slot_authoring_manifest_hash_bound": bool(
            payload_sha
            and all(
                item.get("source_slot_authoring_manifest_hash_bound")
                for item in authoring_manifests
            )
        ),
        "request_source_slot_authoring_manifest_lint_ready": bool(
            request_id is not None
            and slug
            and payload_sha
            and all(
                item.get("source_slot_authoring_manifest_lint_ready")
                for item in authoring_manifests
            )
        ),
        "source_slot_authoring_manifest_count": len(authoring_manifests),
        "safe_local_draft_queue_entry_count": sum(
            1 for item in authoring_manifests if item.get("safe_local_draft_queue_entry")
        ),
        "source_slot_authoring_complete_count": sum(
            1 for item in authoring_manifests if item.get("source_slot_authoring_complete")
        ),
        "source_slot_authoring_blocked_count": sum(
            1 for item in authoring_manifests if item.get("source_slot_authoring_blocked")
        ),
        "request_source_slot_authoring_ready": ready,
        "request_source_slot_authoring_blocked": not ready,
        "source_slot_authoring_manifests": authoring_manifests,
        "next_required_action": (
            "author real request-specific repair packet source slots, then rerun skeleton inventory/currentness"
            if authoring_manifests
            else "request source slots are current; continue material validation"
        ),
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_request_closure": False,
    }


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def build_referee_repair_packet_source_slot_authoring_manifest_capstone(
    skeleton_inventory_currentness_report,
    skeleton_inventory_currentness_ref=None,
    label="",
    created_at="",
):
    skeleton_inventory_currentness_report = dict(
        skeleton_inventory_currentness_report or {}
    )
    skeleton_inventory_currentness_ref = dict(skeleton_inventory_currentness_ref or {})
    skeleton_summary = _summary(skeleton_inventory_currentness_report)
    request_records = [
        dict(item or {})
        for item in skeleton_inventory_currentness_report.get(
            "packet_skeleton_inventory_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    slot_records = [
        dict(slot or {})
        for request_record in request_records
        for slot in request_record.get("packet_skeleton_inventory_records") or []
    ]
    stale_slot_records = [
        item for item in slot_records if item.get("source_slot_stale_or_missing")
    ]
    skeleton_report_valid = bool(
        skeleton_inventory_currentness_ref.get("path")
        and skeleton_inventory_currentness_ref.get("sha256_match")
        and skeleton_inventory_currentness_report
        and _status(
            skeleton_inventory_currentness_report,
            skeleton_inventory_currentness_ref,
        )
        in {"PASS", "FAIL"}
    )
    skeleton_lint_ready = bool(
        skeleton_report_valid
        and _int(skeleton_summary.get("request_skeleton_inventory_record_count"))
        == len(request_records)
        and all(
            request.get("request_packet_skeleton_inventory_lint_ready")
            for request in request_records
        )
        and all(
            slot.get("packet_skeleton_inventory_lint_ready") for slot in slot_records
        )
    )
    request_authoring_records = []
    for request_record in sorted(request_records, key=lambda item: str(item.get("request_id"))):
        manifests = [
            _authoring_manifest(slot)
            for slot in request_record.get("packet_skeleton_inventory_records") or []
            if slot.get("source_slot_stale_or_missing")
        ]
        request_authoring_records.append(
            _request_authoring_record(request_record, manifests)
        )
    manifest_records = [
        manifest
        for request_record in request_authoring_records
        for manifest in request_record.get("source_slot_authoring_manifests") or []
    ]
    request_count = len(request_authoring_records)
    request_ready_count = sum(
        1
        for item in request_authoring_records
        if item.get("request_source_slot_authoring_ready")
    )
    request_blocked_count = request_count - request_ready_count
    manifest_count = len(manifest_records)
    manifest_hash_bound_count = sum(
        1
        for item in manifest_records
        if item.get("source_slot_authoring_manifest_hash_bound")
    )
    manifest_lint_ready_count = sum(
        1
        for item in manifest_records
        if item.get("source_slot_authoring_manifest_lint_ready")
    )
    safe_draft_ready_count = sum(
        1 for item in manifest_records if item.get("safe_local_draft_queue_ready")
    )
    authoring_complete_count = sum(
        1 for item in slot_records if item.get("source_slot_current")
    )
    authoring_incomplete_count = len(slot_records) - authoring_complete_count
    consumable_count = sum(
        1
        for item in manifest_records + request_authoring_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("consumable_as_referee_rejudge")
    )
    manifest_ready = bool(
        skeleton_lint_ready
        and manifest_hash_bound_count == manifest_count
        and manifest_lint_ready_count == manifest_count
        and not stale_slot_records
        and request_blocked_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "skeleton_inventory_currentness_available",
        skeleton_report_valid,
        skeleton_inventory_currentness_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "skeleton_inventory_currentness_lint_ready",
        skeleton_lint_ready,
        f"requests={len(request_records)} slots={len(slot_records)}",
    )
    _add_check(
        checks,
        "all_source_slot_authoring_manifests_hash_bound",
        manifest_hash_bound_count == manifest_count,
        f"hash_bound={manifest_hash_bound_count} manifests={manifest_count}",
    )
    _add_check(
        checks,
        "all_source_slot_authoring_manifests_lint_ready",
        manifest_lint_ready_count == manifest_count,
        f"lint_ready={manifest_lint_ready_count} manifests={manifest_count}",
    )
    _add_check(
        checks,
        "all_safe_local_draft_queue_entries_ready",
        safe_draft_ready_count == manifest_count,
        f"ready={safe_draft_ready_count} manifests={manifest_count}",
    )
    _add_check(
        checks,
        "no_source_slots_require_authoring",
        not stale_slot_records,
        f"stale_or_missing={len(stale_slot_records)}",
    )
    _add_check(
        checks,
        "all_request_source_slot_authoring_complete",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "source_slot_authoring_manifests_are_not_repair_or_closure_evidence",
        consumable_count == 0,
        f"consumable={consumable_count}",
    )
    failed = [check for check in checks if check.get("blocking") and check.get("status") != "PASS"]
    if not skeleton_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SKELETON_INVENTORY_CURRENTNESS_MISSING"
    elif not skeleton_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_UPSTREAM_SKELETON"
    elif manifest_hash_bound_count != manifest_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_HASH"
    elif manifest_lint_ready_count != manifest_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_LINT"
    elif stale_slot_records:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REQUIRED"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_REQUEST_SOURCE_SLOT_AUTHORING_INCOMPLETE"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_MANIFEST"
    else:
        state = "REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_MANIFEST_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_source_slot_authoring_manifest_state": state,
        "summary": {
            "open_request_count": _int(skeleton_summary.get("open_request_count")),
            "request_with_gap_count": _int(skeleton_summary.get("request_with_gap_count")),
            "packet_skeleton_inventory_record_count": len(slot_records),
            "source_slot_stale_or_missing_count": len(stale_slot_records),
            "source_slot_authoring_manifest_record_count": manifest_count,
            "hash_bound_source_slot_authoring_manifest_count": manifest_hash_bound_count,
            "source_slot_authoring_manifest_lint_ready_count": manifest_lint_ready_count,
            "safe_draft_queue_entry_count": manifest_count,
            "safe_draft_queue_ready_count": safe_draft_ready_count,
            "safe_draft_queue_blocked_count": manifest_count - safe_draft_ready_count,
            "source_slot_authoring_complete_count": authoring_complete_count,
            "source_slot_authoring_incomplete_count": authoring_incomplete_count,
            "required_json_schema_count": sum(
                1 for item in manifest_records if item.get("required_packet_schema_id")
            ),
            "source_hash_checklist_item_count": sum(
                item.get("source_hash_checklist_item_count") or 0
                for item in manifest_records
            ),
            "validation_redrive_plan_count": sum(
                1 for item in manifest_records if item.get("validation_redrive_plan")
            ),
            "request_authoring_manifest_record_count": request_count,
            "request_authoring_manifest_ready_count": request_ready_count,
            "request_authoring_manifest_blocked_count": request_blocked_count,
            "proof_status_authoring_required_count": _count(manifest_records, "proof_status"),
            "proof_status_authoring_complete_count": _count(
                manifest_records, "proof_status", "source_slot_authoring_complete"
            ),
            "evidence_manifest_authoring_required_count": _count(
                manifest_records, "evidence_manifest"
            ),
            "evidence_manifest_authoring_complete_count": _count(
                manifest_records, "evidence_manifest", "source_slot_authoring_complete"
            ),
            "appendix_supplement_authoring_required_count": _count(
                manifest_records, "appendix_supplement"
            ),
            "appendix_supplement_authoring_complete_count": _count(
                manifest_records, "appendix_supplement", "source_slot_authoring_complete"
            ),
            "claim_downgrade_authoring_required_count": _count(
                manifest_records, "claim_downgrade"
            ),
            "claim_downgrade_authoring_complete_count": _count(
                manifest_records, "claim_downgrade", "source_slot_authoring_complete"
            ),
            "referee_rejudge_authoring_required_count": _count(
                manifest_records, "referee_rejudge"
            ),
            "referee_rejudge_authoring_complete_count": _count(
                manifest_records, "referee_rejudge", "source_slot_authoring_complete"
            ),
            "upstream_skeleton_current_count": sum(
                1 for item in slot_records if item.get("source_slot_current")
            ),
            "upstream_skeleton_blocked_count": sum(
                1 for item in slot_records if item.get("source_slot_stale_or_missing")
            ),
            "consumable_as_repair_evidence_authoring_count": consumable_count,
            "source_slot_authoring_manifest_ready": manifest_ready,
            "failed_check_count": len(failed),
        },
        "source_slot_authoring_manifest_records": request_authoring_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only emits request-specific source-slot authoring manifests and safe local draft queue entries.",
            "It never writes, creates, or refreshes expected repair packet source files.",
            "Authoring manifests and draft queue entries are not repair evidence, proof-status updates, evidence manifests, appendix/supplement content, referee rejudge results, source-ready closure, or request closure evidence.",
            "The command never edits manuscripts, creates proof evidence, applies patches, rebuilds packages, uploads, emails, submits, or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Packet Source-Slot Authoring Manifest",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_packet_source_slot_authoring_manifest_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
