"""Redrive ledger for referee repair packet source-slot authoring."""

import hashlib
import json


COMMAND = "paper-production-referee-repair-packet-source-slot-authoring-redrive-ledger-capstone"
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_source_slot_authoring_redrive_ledger_capstone.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_source_slot_authoring_redrive_ledger_state",
    "report_schema",
    "summary",
    "source_slot_authoring_redrive_ledger_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "request_with_gap_count",
    "source_slot_authoring_manifest_record_count",
    "redrive_ledger_entry_count",
    "hash_bound_redrive_ledger_entry_count",
    "redrive_ledger_lint_ready_count",
    "safe_redrive_entry_count",
    "blocked_redrive_entry_count",
    "real_input_required_count",
    "real_input_missing_count",
    "redrive_execution_authorized_count",
    "redrive_execution_performed_count",
    "expected_packet_file_creation_performed_count",
    "source_slot_authoring_complete_count",
    "source_slot_authoring_incomplete_count",
    "request_redrive_ledger_record_count",
    "request_redrive_ready_count",
    "request_redrive_blocked_count",
    "proof_status_redrive_required_count",
    "proof_status_redrive_performed_count",
    "evidence_manifest_redrive_required_count",
    "evidence_manifest_redrive_performed_count",
    "appendix_supplement_redrive_required_count",
    "appendix_supplement_redrive_performed_count",
    "claim_downgrade_redrive_required_count",
    "claim_downgrade_redrive_performed_count",
    "referee_rejudge_redrive_required_count",
    "referee_rejudge_redrive_performed_count",
    "safe_draft_queue_ready_count",
    "upstream_authoring_manifest_ready_count",
    "upstream_authoring_manifest_blocked_count",
    "consumable_as_repair_evidence_redrive_count",
    "source_slot_authoring_redrive_ledger_ready",
    "failed_check_count",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _required_real_inputs(manifest):
    return [
        {
            "name": "real_request_specific_repair_material",
            "required": True,
            "present": bool(manifest.get("source_slot_authoring_complete")),
            "detail": "Real local repair material must be authored outside this report.",
        },
        {
            "name": "request_specific_source_sha256",
            "required": True,
            "present": False,
            "detail": "The sha256 must be computed from the real request-specific packet source.",
        },
        {
            "name": "request_binding",
            "required": True,
            "present": bool(
                manifest.get("request_id") is not None
                and manifest.get("slug")
                and manifest.get("packet_type")
            ),
            "detail": "The packet must bind request_id, slug, and packet_type.",
        },
        {
            "name": "schema_conformant_packet_json",
            "required": True,
            "present": False,
            "detail": "The packet source must parse as JSON and match the required packet schema.",
        },
    ]


def _redrive_entry(manifest):
    request_id = manifest.get("request_id")
    slug = manifest.get("slug") or ""
    packet_type = manifest.get("packet_type") or ""
    expected_path = manifest.get("expected_packet_path") or ""
    schema_id = manifest.get("required_packet_schema_id") or ""
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_source_slot_authoring_redrive_ledger_entry.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_path,
        "required_packet_schema_id": schema_id,
        "upstream_source_slot_authoring_manifest_payload_sha256": manifest.get(
            "source_slot_authoring_manifest_payload_sha256"
        )
        or "",
    }
    payload_sha = _sha(payload)
    required_inputs = _required_real_inputs(manifest)
    real_input_missing_count = sum(
        1 for item in required_inputs if item.get("required") and not item.get("present")
    )
    lint_ready = bool(
        request_id is not None
        and slug
        and packet_type
        and expected_path
        and schema_id
        and manifest.get("source_slot_authoring_manifest_hash_bound")
        and manifest.get("source_slot_authoring_manifest_lint_ready")
        and payload_sha
    )
    safe_to_redrive = bool(
        lint_ready
        and manifest.get("safe_local_draft_queue_ready")
        and not manifest.get("source_slot_authoring_complete")
        and not manifest.get("expected_packet_file_creation_performed")
        and not manifest.get("consumable_as_repair_evidence")
        and not manifest.get("consumable_as_request_closure")
    )
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "source_slot_authoring_redrive_ledger_id": (
            f"referee-repair-source-slot-authoring-redrive-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "source_slot_authoring_redrive_ledger_payload_sha256": payload_sha,
        "source_slot_authoring_redrive_ledger_hash_bound": bool(
            payload_sha and manifest.get("source_slot_authoring_manifest_hash_bound")
        ),
        "source_slot_authoring_redrive_ledger_lint_ready": lint_ready,
        "upstream_source_slot_authoring_manifest_payload_sha256": manifest.get(
            "source_slot_authoring_manifest_payload_sha256"
        )
        or "",
        "expected_packet_path": expected_path,
        "required_packet_schema_id": schema_id,
        "authoring_action": manifest.get("authoring_action") or "",
        "source_slot_currentness_issues": list(
            manifest.get("source_slot_currentness_issues") or []
        ),
        "safe_local_draft_queue_ready": bool(manifest.get("safe_local_draft_queue_ready")),
        "safe_to_redrive": safe_to_redrive,
        "redrive_blocked": not safe_to_redrive,
        "real_input_required": True,
        "required_real_inputs": required_inputs,
        "real_input_missing_count": real_input_missing_count,
        "material_packet_required": True,
        "referee_rejudge_required": packet_type == "referee_rejudge",
        "redrive_execution_authorized": False,
        "redrive_execution_performed": False,
        "expected_packet_file_creation_performed": False,
        "source_slot_authoring_complete": bool(manifest.get("source_slot_authoring_complete")),
        "source_slot_authoring_blocked": bool(manifest.get("source_slot_authoring_blocked")),
        "next_required_action": (
            "collect real request-specific source material, author packet JSON, compute source hash, "
            "then rerun skeleton/currentness and material validation"
        ),
        "consumable_as_repair_evidence": False,
        "consumable_as_proof_status": False,
        "consumable_as_evidence_manifest": False,
        "consumable_as_appendix_supplement": False,
        "consumable_as_referee_rejudge": False,
        "consumable_as_request_closure": False,
    }


def _request_redrive_record(request_record, entries):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_source_slot_authoring_redrive_ledger.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "source_slot_authoring_redrive_payload_sha256s": [
            item.get("source_slot_authoring_redrive_ledger_payload_sha256")
            for item in entries
        ],
    }
    payload_sha = _sha(payload)
    ready = bool(
        not entries
        or (
            all(item.get("redrive_execution_performed") for item in entries)
            and all(item.get("real_input_missing_count") == 0 for item in entries)
        )
    )
    return {
        "request_id": request_id,
        "slug": slug,
        "request_source_slot_authoring_redrive_ledger_id": (
            f"referee-repair-request-source-slot-authoring-redrive-{request_id}-{payload_sha[:16]}"
        ),
        "request_source_slot_authoring_redrive_ledger_payload_sha256": payload_sha,
        "request_source_slot_authoring_redrive_ledger_hash_bound": bool(
            payload_sha
            and all(
                item.get("source_slot_authoring_redrive_ledger_hash_bound")
                for item in entries
            )
        ),
        "request_source_slot_authoring_redrive_ledger_lint_ready": bool(
            request_id is not None
            and slug
            and payload_sha
            and all(
                item.get("source_slot_authoring_redrive_ledger_lint_ready")
                for item in entries
            )
        ),
        "source_slot_authoring_redrive_entry_count": len(entries),
        "safe_redrive_entry_count": sum(1 for item in entries if item.get("safe_to_redrive")),
        "real_input_missing_count": sum(
            item.get("real_input_missing_count") or 0 for item in entries
        ),
        "redrive_execution_performed_count": sum(
            1 for item in entries if item.get("redrive_execution_performed")
        ),
        "request_source_slot_authoring_redrive_ready": ready,
        "request_source_slot_authoring_redrive_blocked": not ready,
        "source_slot_authoring_redrive_entries": entries,
        "next_required_action": (
            "execute local/human source-slot authoring with real inputs, then rerun currentness and validation"
            if entries
            else "request source slots require no redrive"
        ),
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_request_closure": False,
    }


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def build_referee_repair_packet_source_slot_authoring_redrive_ledger_capstone(
    source_slot_authoring_manifest_report,
    source_slot_authoring_manifest_ref=None,
    label="",
    created_at="",
):
    source_slot_authoring_manifest_report = dict(
        source_slot_authoring_manifest_report or {}
    )
    source_slot_authoring_manifest_ref = dict(source_slot_authoring_manifest_ref or {})
    manifest_summary = _summary(source_slot_authoring_manifest_report)
    request_manifest_records = [
        dict(item or {})
        for item in source_slot_authoring_manifest_report.get(
            "source_slot_authoring_manifest_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    manifest_records = [
        dict(manifest or {})
        for request_record in request_manifest_records
        for manifest in request_record.get("source_slot_authoring_manifests") or []
    ]
    authoring_report_valid = bool(
        source_slot_authoring_manifest_ref.get("path")
        and source_slot_authoring_manifest_ref.get("sha256_match")
        and source_slot_authoring_manifest_report
        and _status(
            source_slot_authoring_manifest_report,
            source_slot_authoring_manifest_ref,
        )
        in {"PASS", "FAIL"}
    )
    authoring_manifest_lint_ready = bool(
        authoring_report_valid
        and _int(manifest_summary.get("request_authoring_manifest_record_count"))
        == len(request_manifest_records)
        and all(
            request.get("request_source_slot_authoring_manifest_lint_ready")
            for request in request_manifest_records
        )
        and all(
            manifest.get("source_slot_authoring_manifest_lint_ready")
            for manifest in manifest_records
        )
    )
    request_redrive_records = []
    for request_record in sorted(
        request_manifest_records, key=lambda item: str(item.get("request_id"))
    ):
        entries = [
            _redrive_entry(manifest)
            for manifest in request_record.get("source_slot_authoring_manifests") or []
        ]
        request_redrive_records.append(_request_redrive_record(request_record, entries))
    redrive_entries = [
        entry
        for request_record in request_redrive_records
        for entry in request_record.get("source_slot_authoring_redrive_entries") or []
    ]
    request_count = len(request_redrive_records)
    request_ready_count = sum(
        1
        for item in request_redrive_records
        if item.get("request_source_slot_authoring_redrive_ready")
    )
    request_blocked_count = request_count - request_ready_count
    entry_count = len(redrive_entries)
    hash_bound_count = sum(
        1
        for item in redrive_entries
        if item.get("source_slot_authoring_redrive_ledger_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in redrive_entries
        if item.get("source_slot_authoring_redrive_ledger_lint_ready")
    )
    safe_redrive_count = sum(1 for item in redrive_entries if item.get("safe_to_redrive"))
    real_input_missing_count = sum(
        item.get("real_input_missing_count") or 0 for item in redrive_entries
    )
    redrive_execution_performed_count = sum(
        1 for item in redrive_entries if item.get("redrive_execution_performed")
    )
    consumable_count = sum(
        1
        for item in redrive_entries + request_redrive_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("consumable_as_referee_rejudge")
    )
    ledger_ready = bool(
        authoring_manifest_lint_ready
        and hash_bound_count == entry_count
        and lint_ready_count == entry_count
        and real_input_missing_count == 0
        and redrive_execution_performed_count == entry_count
        and request_blocked_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "source_slot_authoring_manifest_available",
        authoring_report_valid,
        source_slot_authoring_manifest_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_slot_authoring_manifest_lint_ready",
        authoring_manifest_lint_ready,
        f"requests={len(request_manifest_records)} manifests={len(manifest_records)}",
    )
    _add_check(
        checks,
        "all_source_slot_authoring_redrive_entries_hash_bound",
        hash_bound_count == entry_count,
        f"hash_bound={hash_bound_count} entries={entry_count}",
    )
    _add_check(
        checks,
        "all_source_slot_authoring_redrive_entries_lint_ready",
        lint_ready_count == entry_count,
        f"lint_ready={lint_ready_count} entries={entry_count}",
    )
    _add_check(
        checks,
        "all_source_slot_authoring_redrive_entries_safe_to_queue",
        safe_redrive_count == entry_count,
        f"safe={safe_redrive_count} entries={entry_count}",
    )
    _add_check(
        checks,
        "no_source_slot_authoring_redrive_entries_missing_real_inputs",
        real_input_missing_count == 0,
        f"missing_real_inputs={real_input_missing_count}",
    )
    _add_check(
        checks,
        "all_source_slot_authoring_redrive_entries_executed",
        redrive_execution_performed_count == entry_count,
        f"executed={redrive_execution_performed_count} entries={entry_count}",
    )
    _add_check(
        checks,
        "all_request_source_slot_authoring_redrive_ledgers_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "source_slot_authoring_redrive_ledgers_are_not_repair_or_closure_evidence",
        consumable_count == 0,
        f"consumable={consumable_count}",
    )
    failed = [check for check in checks if check.get("blocking") and check.get("status") != "PASS"]
    if not authoring_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_MANIFEST_MISSING"
    elif not authoring_manifest_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_UPSTREAM_MANIFEST"
    elif hash_bound_count != entry_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_HASH"
    elif lint_ready_count != entry_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_LINT"
    elif safe_redrive_count != entry_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_UNSAFE"
    elif real_input_missing_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_REAL_INPUTS_MISSING"
    elif redrive_execution_performed_count != entry_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_NOT_EXECUTED"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_REQUEST_SOURCE_SLOT_AUTHORING_REDRIVE_BLOCKED"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_LEDGER"
    else:
        state = "REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_LEDGER_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_source_slot_authoring_redrive_ledger_state": state,
        "summary": {
            "open_request_count": _int(manifest_summary.get("open_request_count")),
            "request_with_gap_count": _int(manifest_summary.get("request_with_gap_count")),
            "source_slot_authoring_manifest_record_count": len(manifest_records),
            "redrive_ledger_entry_count": entry_count,
            "hash_bound_redrive_ledger_entry_count": hash_bound_count,
            "redrive_ledger_lint_ready_count": lint_ready_count,
            "safe_redrive_entry_count": safe_redrive_count,
            "blocked_redrive_entry_count": entry_count - safe_redrive_count,
            "real_input_required_count": entry_count,
            "real_input_missing_count": real_input_missing_count,
            "redrive_execution_authorized_count": sum(
                1 for item in redrive_entries if item.get("redrive_execution_authorized")
            ),
            "redrive_execution_performed_count": redrive_execution_performed_count,
            "expected_packet_file_creation_performed_count": sum(
                1
                for item in redrive_entries
                if item.get("expected_packet_file_creation_performed")
            ),
            "source_slot_authoring_complete_count": sum(
                1 for item in redrive_entries if item.get("source_slot_authoring_complete")
            ),
            "source_slot_authoring_incomplete_count": sum(
                1 for item in redrive_entries if not item.get("source_slot_authoring_complete")
            ),
            "request_redrive_ledger_record_count": request_count,
            "request_redrive_ready_count": request_ready_count,
            "request_redrive_blocked_count": request_blocked_count,
            "proof_status_redrive_required_count": _count(redrive_entries, "proof_status"),
            "proof_status_redrive_performed_count": _count(
                redrive_entries, "proof_status", "redrive_execution_performed"
            ),
            "evidence_manifest_redrive_required_count": _count(
                redrive_entries, "evidence_manifest"
            ),
            "evidence_manifest_redrive_performed_count": _count(
                redrive_entries, "evidence_manifest", "redrive_execution_performed"
            ),
            "appendix_supplement_redrive_required_count": _count(
                redrive_entries, "appendix_supplement"
            ),
            "appendix_supplement_redrive_performed_count": _count(
                redrive_entries, "appendix_supplement", "redrive_execution_performed"
            ),
            "claim_downgrade_redrive_required_count": _count(
                redrive_entries, "claim_downgrade"
            ),
            "claim_downgrade_redrive_performed_count": _count(
                redrive_entries, "claim_downgrade", "redrive_execution_performed"
            ),
            "referee_rejudge_redrive_required_count": _count(
                redrive_entries, "referee_rejudge"
            ),
            "referee_rejudge_redrive_performed_count": _count(
                redrive_entries, "referee_rejudge", "redrive_execution_performed"
            ),
            "safe_draft_queue_ready_count": sum(
                1 for item in redrive_entries if item.get("safe_local_draft_queue_ready")
            ),
            "upstream_authoring_manifest_ready_count": sum(
                1
                for item in manifest_records
                if item.get("source_slot_authoring_manifest_lint_ready")
                and not item.get("source_slot_authoring_blocked")
            ),
            "upstream_authoring_manifest_blocked_count": sum(
                1
                for item in manifest_records
                if item.get("source_slot_authoring_blocked")
            ),
            "consumable_as_repair_evidence_redrive_count": consumable_count,
            "source_slot_authoring_redrive_ledger_ready": ledger_ready,
            "failed_check_count": len(failed),
        },
        "source_slot_authoring_redrive_ledger_records": request_redrive_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only emits source-slot authoring execution preflight and redrive ledger records.",
            "It never writes, creates, refreshes, or validates expected repair packet source files.",
            "Redrive ledger records are not repair evidence, proof-status updates, evidence manifests, appendix/supplement content, referee rejudge results, source-ready closure, or request closure evidence.",
            "The command never edits manuscripts, creates proof evidence, applies patches, rebuilds packages, uploads, emails, submits, performs external actions, or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Packet Source-Slot Authoring Redrive Ledger",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_packet_source_slot_authoring_redrive_ledger_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
