"""Fulfillment intake for referee repair packet source slots."""

import hashlib
import json


COMMAND = "paper-production-referee-repair-packet-source-slot-fulfillment-intake-capstone"
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_source_slot_fulfillment_intake_capstone.v1"
)
RECEIPT_SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_packet_source_slot_authoring_redrive_execution_receipt.v1"
)

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_packet_source_slot_fulfillment_intake_state",
    "report_schema",
    "summary",
    "source_slot_fulfillment_intake_records",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "open_request_count",
    "request_with_gap_count",
    "redrive_ledger_entry_count",
    "source_slot_fulfillment_record_count",
    "hash_bound_source_slot_fulfillment_count",
    "source_slot_fulfillment_lint_ready_count",
    "source_slot_present_count",
    "source_slot_missing_count",
    "source_slot_json_ok_count",
    "source_slot_json_error_count",
    "source_slot_schema_match_count",
    "source_slot_schema_mismatch_count",
    "request_binding_match_count",
    "request_binding_mismatch_count",
    "source_hash_present_count",
    "source_hash_missing_count",
    "source_hash_bound_count",
    "source_hash_unbound_count",
    "source_slot_fulfilled_count",
    "source_slot_unfulfilled_count",
    "redrive_execution_receipt_required_count",
    "redrive_execution_receipt_present_count",
    "redrive_execution_receipt_missing_count",
    "redrive_execution_receipt_json_ok_count",
    "redrive_execution_receipt_json_error_count",
    "redrive_execution_receipt_schema_match_count",
    "redrive_execution_receipt_schema_mismatch_count",
    "redrive_execution_receipt_binding_match_count",
    "redrive_execution_receipt_binding_mismatch_count",
    "redrive_execution_receipt_performed_count",
    "redrive_execution_receipt_not_performed_count",
    "request_fulfillment_intake_record_count",
    "request_fulfillment_ready_count",
    "request_fulfillment_blocked_count",
    "proof_status_fulfillment_required_count",
    "proof_status_fulfilled_count",
    "evidence_manifest_fulfillment_required_count",
    "evidence_manifest_fulfilled_count",
    "appendix_supplement_fulfillment_required_count",
    "appendix_supplement_fulfilled_count",
    "claim_downgrade_fulfillment_required_count",
    "claim_downgrade_fulfilled_count",
    "referee_rejudge_fulfillment_required_count",
    "referee_rejudge_fulfilled_count",
    "upstream_redrive_safe_count",
    "upstream_redrive_blocked_count",
    "consumable_as_repair_evidence_fulfillment_count",
    "source_slot_fulfillment_intake_ready",
    "failed_check_count",
]

SOURCE_HASH_FIELDS = [
    "request_specific_source_sha256",
    "request_specific_source_hash",
    "source_sha256",
    "source_hash",
    "sha256",
]


def _summary(report):
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report, ref=None):
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or ""
    )


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def _sha(payload):
    encoded = json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _add_check(checks, name, ok, detail="", blocking=True):
    checks.append(
        {
            "name": name,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _source_hash(data):
    if not isinstance(data, dict):
        return ""
    for key in SOURCE_HASH_FIELDS:
        value = data.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()
    hashes = data.get("source_hashes")
    if isinstance(hashes, list):
        for value in hashes:
            if isinstance(value, str) and value.strip():
                return value.strip()
    return ""


def _source_hash_bound(data):
    if not isinstance(data, dict):
        return False
    return bool(
        data.get("request_specific_source_hash_bound")
        or data.get("source_hash_bound")
        or data.get("hash_bound")
    )


def expected_redrive_receipt_path(expected_packet_path):
    if not expected_packet_path:
        return ""
    if expected_packet_path.endswith(".json"):
        return expected_packet_path[:-5] + ".redrive-receipt.json"
    return expected_packet_path + ".redrive-receipt.json"


def _slot_data(inventory, path):
    return dict((inventory or {}).get(path) or {})


def _fulfillment_record(redrive_entry, source_slot, receipt_slot):
    source_slot = dict(source_slot or {})
    receipt_slot = dict(receipt_slot or {})
    source_data = source_slot.get("json") if isinstance(source_slot.get("json"), dict) else {}
    receipt_data = receipt_slot.get("json") if isinstance(receipt_slot.get("json"), dict) else {}
    request_id = redrive_entry.get("request_id")
    slug = redrive_entry.get("slug") or ""
    packet_type = redrive_entry.get("packet_type") or ""
    expected_path = redrive_entry.get("expected_packet_path") or ""
    expected_schema_id = redrive_entry.get("required_packet_schema_id") or ""
    expected_receipt_path = expected_redrive_receipt_path(expected_path)
    source_present = bool(source_slot.get("present"))
    source_json_ok = bool(source_slot.get("json_ok"))
    source_schema_id = source_data.get("schema_id") or source_slot.get("schema_id") or ""
    source_schema_match = bool(
        source_present and source_json_ok and source_schema_id == expected_schema_id
    )
    source_request_binding_match = bool(
        source_present
        and source_json_ok
        and source_data.get("request_id") == request_id
        and (source_data.get("slug") or "") == slug
        and (source_data.get("packet_type") or "") == packet_type
    )
    source_hash = _source_hash(source_data)
    source_hash_present = bool(source_present and source_json_ok and source_hash)
    source_hash_bound = bool(source_hash_present and _source_hash_bound(source_data))
    source_fulfilled = bool(
        source_present
        and source_json_ok
        and source_schema_match
        and source_request_binding_match
        and source_hash_present
        and source_hash_bound
    )
    receipt_present = bool(receipt_slot.get("present"))
    receipt_json_ok = bool(receipt_slot.get("json_ok"))
    receipt_schema_id = receipt_data.get("schema_id") or receipt_slot.get("schema_id") or ""
    receipt_schema_match = bool(
        receipt_present and receipt_json_ok and receipt_schema_id == RECEIPT_SCHEMA_ID
    )
    receipt_binding_match = bool(
        receipt_present
        and receipt_json_ok
        and receipt_data.get("request_id") == request_id
        and (receipt_data.get("slug") or "") == slug
        and (receipt_data.get("packet_type") or "") == packet_type
        and (receipt_data.get("expected_packet_path") or "") == expected_path
        and (
            receipt_data.get("source_slot_authoring_redrive_ledger_payload_sha256")
            or ""
        )
        == (redrive_entry.get("source_slot_authoring_redrive_ledger_payload_sha256") or "")
    )
    receipt_performed = bool(
        receipt_present
        and receipt_json_ok
        and receipt_binding_match
        and receipt_data.get("redrive_execution_performed") is True
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_packet_source_slot_fulfillment_intake_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": expected_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "source_slot_authoring_redrive_ledger_payload_sha256": redrive_entry.get(
            "source_slot_authoring_redrive_ledger_payload_sha256"
        )
        or "",
        "observed_source_slot_sha256": source_slot.get("sha256") or "",
        "observed_receipt_sha256": receipt_slot.get("sha256") or "",
    }
    payload_sha = _sha(payload)
    lint_ready = bool(
        request_id is not None
        and slug
        and packet_type
        and expected_path
        and expected_schema_id
        and expected_receipt_path
        and redrive_entry.get("source_slot_authoring_redrive_ledger_hash_bound")
        and redrive_entry.get("source_slot_authoring_redrive_ledger_lint_ready")
        and payload_sha
    )
    issues = []
    if not source_present:
        issues.append("source_slot_missing")
    if source_present and not source_json_ok:
        issues.append("source_slot_json_error")
    if source_present and source_json_ok and not source_schema_match:
        issues.append("source_slot_schema_mismatch")
    if source_present and source_json_ok and not source_request_binding_match:
        issues.append("source_slot_request_binding_mismatch")
    if source_present and source_json_ok and not source_hash_present:
        issues.append("source_hash_missing")
    if source_present and source_json_ok and source_hash_present and not source_hash_bound:
        issues.append("source_hash_unbound")
    if not receipt_present:
        issues.append("redrive_execution_receipt_missing")
    if receipt_present and not receipt_json_ok:
        issues.append("redrive_execution_receipt_json_error")
    if receipt_present and receipt_json_ok and not receipt_schema_match:
        issues.append("redrive_execution_receipt_schema_mismatch")
    if receipt_present and receipt_json_ok and not receipt_binding_match:
        issues.append("redrive_execution_receipt_binding_mismatch")
    if receipt_present and receipt_json_ok and not receipt_performed:
        issues.append("redrive_execution_not_performed")
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "source_slot_fulfillment_intake_id": (
            f"referee-repair-source-slot-fulfillment-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "source_slot_fulfillment_intake_payload_sha256": payload_sha,
        "source_slot_fulfillment_intake_hash_bound": bool(
            payload_sha and redrive_entry.get("source_slot_authoring_redrive_ledger_hash_bound")
        ),
        "source_slot_fulfillment_intake_lint_ready": lint_ready,
        "upstream_source_slot_authoring_redrive_ledger_payload_sha256": redrive_entry.get(
            "source_slot_authoring_redrive_ledger_payload_sha256"
        )
        or "",
        "expected_packet_path": expected_path,
        "required_packet_schema_id": expected_schema_id,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "source_slot_present": source_present,
        "source_slot_json_ok": source_json_ok,
        "source_slot_json_error": bool(source_present and not source_json_ok),
        "source_slot_sha256": source_slot.get("sha256") or "",
        "observed_source_schema_id": source_schema_id,
        "source_slot_schema_match": source_schema_match,
        "source_slot_schema_mismatch": bool(
            source_present and source_json_ok and not source_schema_match
        ),
        "request_binding_match": source_request_binding_match,
        "request_binding_mismatch": bool(
            source_present and source_json_ok and not source_request_binding_match
        ),
        "source_hash_present": source_hash_present,
        "source_hash_missing": bool(source_present and source_json_ok and not source_hash_present),
        "source_hash_bound": source_hash_bound,
        "source_hash_unbound": bool(
            source_present and source_json_ok and source_hash_present and not source_hash_bound
        ),
        "source_slot_fulfilled": source_fulfilled,
        "redrive_execution_receipt_present": receipt_present,
        "redrive_execution_receipt_json_ok": receipt_json_ok,
        "redrive_execution_receipt_json_error": bool(receipt_present and not receipt_json_ok),
        "redrive_execution_receipt_sha256": receipt_slot.get("sha256") or "",
        "observed_receipt_schema_id": receipt_schema_id,
        "redrive_execution_receipt_schema_match": receipt_schema_match,
        "redrive_execution_receipt_schema_mismatch": bool(
            receipt_present and receipt_json_ok and not receipt_schema_match
        ),
        "redrive_execution_receipt_binding_match": receipt_binding_match,
        "redrive_execution_receipt_binding_mismatch": bool(
            receipt_present and receipt_json_ok and not receipt_binding_match
        ),
        "redrive_execution_receipt_performed": receipt_performed,
        "source_slot_fulfillment_ready": bool(source_fulfilled and receipt_performed),
        "source_slot_fulfillment_blocked": not bool(source_fulfilled and receipt_performed),
        "source_slot_fulfillment_issues": issues,
        "upstream_safe_to_redrive": bool(redrive_entry.get("safe_to_redrive")),
        "upstream_redrive_execution_performed": bool(
            redrive_entry.get("redrive_execution_performed")
        ),
        "expected_packet_file_creation_performed": bool(source_present),
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_proof_status": False,
        "consumable_as_evidence_manifest": False,
        "consumable_as_appendix_supplement": False,
        "consumable_as_referee_rejudge": False,
        "consumable_as_request_closure": False,
    }


def _request_fulfillment_record(request_record, fulfillment_records):
    request_id = request_record.get("request_id")
    slug = request_record.get("slug") or ""
    blocked = [
        item for item in fulfillment_records if item.get("source_slot_fulfillment_blocked")
    ]
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_request_source_slot_fulfillment_intake_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "source_slot_fulfillment_intake_payload_sha256s": [
            item.get("source_slot_fulfillment_intake_payload_sha256")
            for item in fulfillment_records
        ],
    }
    payload_sha = _sha(payload)
    lint_ready = bool(
        request_id is not None
        and slug
        and payload_sha
        and all(
            item.get("source_slot_fulfillment_intake_lint_ready")
            for item in fulfillment_records
        )
    )
    ready = bool(fulfillment_records) and not blocked
    return {
        "request_id": request_id,
        "slug": slug,
        "request_source_slot_fulfillment_intake_id": (
            f"referee-repair-request-source-slot-fulfillment-{request_id}-{payload_sha[:16]}"
        ),
        "request_source_slot_fulfillment_intake_payload_sha256": payload_sha,
        "request_source_slot_fulfillment_intake_hash_bound": bool(
            payload_sha
            and all(
                item.get("source_slot_fulfillment_intake_hash_bound")
                for item in fulfillment_records
            )
        ),
        "request_source_slot_fulfillment_intake_lint_ready": lint_ready,
        "source_slot_fulfillment_intake_count": len(fulfillment_records),
        "source_slot_fulfilled_count": sum(
            1 for item in fulfillment_records if item.get("source_slot_fulfilled")
        ),
        "redrive_execution_receipt_performed_count": sum(
            1
            for item in fulfillment_records
            if item.get("redrive_execution_receipt_performed")
        ),
        "request_source_slot_fulfillment_ready": ready,
        "request_source_slot_fulfillment_blocked": not ready,
        "blocked_packet_types": [item.get("packet_type") for item in blocked],
        "source_slot_fulfillment_records": fulfillment_records,
        "next_required_action": (
            "author real packet source slot and redrive execution receipt, then rerun fulfillment intake"
            if blocked
            else "request source-slot fulfillment intake is ready for material validation"
        ),
        "request_closure_performed": False,
        "consumable_as_repair_evidence": False,
        "consumable_as_request_closure": False,
    }


def _count(records, packet_type, key=None):
    if key is None:
        return sum(1 for item in records if item.get("packet_type") == packet_type)
    return sum(
        1
        for item in records
        if item.get("packet_type") == packet_type and item.get(key)
    )


def build_referee_repair_packet_source_slot_fulfillment_intake_capstone(
    source_slot_authoring_redrive_ledger_report,
    source_slot_authoring_redrive_ledger_ref=None,
    source_slot_inventory=None,
    redrive_execution_receipt_inventory=None,
    label="",
    created_at="",
):
    source_slot_authoring_redrive_ledger_report = dict(
        source_slot_authoring_redrive_ledger_report or {}
    )
    source_slot_authoring_redrive_ledger_ref = dict(
        source_slot_authoring_redrive_ledger_ref or {}
    )
    source_slot_inventory = dict(source_slot_inventory or {})
    redrive_execution_receipt_inventory = dict(redrive_execution_receipt_inventory or {})
    redrive_summary = _summary(source_slot_authoring_redrive_ledger_report)
    request_redrive_records = [
        dict(item or {})
        for item in source_slot_authoring_redrive_ledger_report.get(
            "source_slot_authoring_redrive_ledger_records"
        )
        or []
        if item.get("request_id") is not None
    ]
    redrive_entries = [
        dict(entry or {})
        for request_record in request_redrive_records
        for entry in request_record.get("source_slot_authoring_redrive_entries") or []
    ]
    redrive_report_valid = bool(
        source_slot_authoring_redrive_ledger_ref.get("path")
        and source_slot_authoring_redrive_ledger_ref.get("sha256_match")
        and source_slot_authoring_redrive_ledger_report
        and _status(
            source_slot_authoring_redrive_ledger_report,
            source_slot_authoring_redrive_ledger_ref,
        )
        in {"PASS", "FAIL"}
    )
    redrive_lint_ready = bool(
        redrive_report_valid
        and _int(redrive_summary.get("request_redrive_ledger_record_count"))
        == len(request_redrive_records)
        and all(
            request.get("request_source_slot_authoring_redrive_ledger_lint_ready")
            for request in request_redrive_records
        )
        and all(
            entry.get("source_slot_authoring_redrive_ledger_lint_ready")
            for entry in redrive_entries
        )
    )
    request_fulfillment_records = []
    for request_record in sorted(
        request_redrive_records, key=lambda item: str(item.get("request_id"))
    ):
        fulfillment_records = []
        for redrive_entry in request_record.get("source_slot_authoring_redrive_entries") or []:
            expected_path = redrive_entry.get("expected_packet_path") or ""
            receipt_path = expected_redrive_receipt_path(expected_path)
            fulfillment_records.append(
                _fulfillment_record(
                    redrive_entry,
                    _slot_data(source_slot_inventory, expected_path),
                    _slot_data(redrive_execution_receipt_inventory, receipt_path),
                )
            )
        request_fulfillment_records.append(
            _request_fulfillment_record(request_record, fulfillment_records)
        )
    fulfillment_records = [
        record
        for request_record in request_fulfillment_records
        for record in request_record.get("source_slot_fulfillment_records") or []
    ]
    request_count = len(request_fulfillment_records)
    request_ready_count = sum(
        1
        for item in request_fulfillment_records
        if item.get("request_source_slot_fulfillment_ready")
    )
    request_blocked_count = request_count - request_ready_count
    record_count = len(fulfillment_records)
    hash_bound_count = sum(
        1
        for item in fulfillment_records
        if item.get("source_slot_fulfillment_intake_hash_bound")
    )
    lint_ready_count = sum(
        1
        for item in fulfillment_records
        if item.get("source_slot_fulfillment_intake_lint_ready")
    )
    fulfilled_count = sum(
        1 for item in fulfillment_records if item.get("source_slot_fulfilled")
    )
    receipt_present_count = sum(
        1 for item in fulfillment_records if item.get("redrive_execution_receipt_present")
    )
    receipt_performed_count = sum(
        1
        for item in fulfillment_records
        if item.get("redrive_execution_receipt_performed")
    )
    consumable_count = sum(
        1
        for item in fulfillment_records + request_fulfillment_records
        if item.get("consumable_as_repair_evidence")
        or item.get("consumable_as_request_closure")
        or item.get("consumable_as_referee_rejudge")
    )
    intake_ready = bool(
        redrive_lint_ready
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and fulfilled_count == record_count
        and receipt_present_count == record_count
        and receipt_performed_count == record_count
        and request_blocked_count == 0
        and consumable_count == 0
    )
    checks = []
    _add_check(
        checks,
        "source_slot_authoring_redrive_ledger_available",
        redrive_report_valid,
        source_slot_authoring_redrive_ledger_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_slot_authoring_redrive_ledger_lint_ready",
        redrive_lint_ready,
        f"requests={len(request_redrive_records)} entries={len(redrive_entries)}",
    )
    _add_check(
        checks,
        "all_source_slot_fulfillment_intake_records_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_slot_fulfillment_intake_records_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_expected_source_slots_fulfilled",
        fulfilled_count == record_count,
        f"fulfilled={fulfilled_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_execution_receipts_present",
        receipt_present_count == record_count,
        f"present={receipt_present_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_execution_receipts_performed",
        receipt_performed_count == record_count,
        f"performed={receipt_performed_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_request_source_slot_fulfillment_intakes_ready",
        request_blocked_count == 0,
        f"blocked_requests={request_blocked_count} requests={request_count}",
    )
    _add_check(
        checks,
        "source_slot_fulfillment_intake_records_are_not_repair_or_closure_evidence",
        consumable_count == 0,
        f"consumable={consumable_count}",
    )
    failed = [check for check in checks if check.get("blocking") and check.get("status") != "PASS"]
    if not redrive_report_valid:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_AUTHORING_REDRIVE_LEDGER_MISSING"
    elif not redrive_lint_ready:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_FULFILLMENT_UPSTREAM_REDRIVE"
    elif hash_bound_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_FULFILLMENT_HASH"
    elif lint_ready_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_FULFILLMENT_LINT"
    elif fulfilled_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_FULFILLMENT_SOURCE_MISSING_OR_INVALID"
    elif receipt_present_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_REDRIVE_RECEIPTS_MISSING"
    elif receipt_performed_count != record_count:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_REDRIVE_RECEIPTS_NOT_PERFORMED"
    elif request_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_REQUEST_SOURCE_SLOT_FULFILLMENT_INTAKE"
    elif failed:
        state = "BLOCKED_REFEREE_REPAIR_PACKET_SOURCE_SLOT_FULFILLMENT_INTAKE"
    else:
        state = "REFEREE_REPAIR_PACKET_SOURCE_SLOT_FULFILLMENT_INTAKE_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "referee_repair_packet_source_slot_fulfillment_intake_state": state,
        "summary": {
            "open_request_count": _int(redrive_summary.get("open_request_count")),
            "request_with_gap_count": _int(redrive_summary.get("request_with_gap_count")),
            "redrive_ledger_entry_count": _int(redrive_summary.get("redrive_ledger_entry_count")),
            "source_slot_fulfillment_record_count": record_count,
            "hash_bound_source_slot_fulfillment_count": hash_bound_count,
            "source_slot_fulfillment_lint_ready_count": lint_ready_count,
            "source_slot_present_count": sum(
                1 for item in fulfillment_records if item.get("source_slot_present")
            ),
            "source_slot_missing_count": sum(
                1 for item in fulfillment_records if not item.get("source_slot_present")
            ),
            "source_slot_json_ok_count": sum(
                1 for item in fulfillment_records if item.get("source_slot_json_ok")
            ),
            "source_slot_json_error_count": sum(
                1 for item in fulfillment_records if item.get("source_slot_json_error")
            ),
            "source_slot_schema_match_count": sum(
                1 for item in fulfillment_records if item.get("source_slot_schema_match")
            ),
            "source_slot_schema_mismatch_count": sum(
                1 for item in fulfillment_records if item.get("source_slot_schema_mismatch")
            ),
            "request_binding_match_count": sum(
                1 for item in fulfillment_records if item.get("request_binding_match")
            ),
            "request_binding_mismatch_count": sum(
                1 for item in fulfillment_records if item.get("request_binding_mismatch")
            ),
            "source_hash_present_count": sum(
                1 for item in fulfillment_records if item.get("source_hash_present")
            ),
            "source_hash_missing_count": sum(
                1
                for item in fulfillment_records
                if item.get("source_hash_missing") or not item.get("source_slot_present")
            ),
            "source_hash_bound_count": sum(
                1 for item in fulfillment_records if item.get("source_hash_bound")
            ),
            "source_hash_unbound_count": sum(
                1
                for item in fulfillment_records
                if item.get("source_hash_unbound") or not item.get("source_slot_present")
            ),
            "source_slot_fulfilled_count": fulfilled_count,
            "source_slot_unfulfilled_count": record_count - fulfilled_count,
            "redrive_execution_receipt_required_count": record_count,
            "redrive_execution_receipt_present_count": receipt_present_count,
            "redrive_execution_receipt_missing_count": record_count - receipt_present_count,
            "redrive_execution_receipt_json_ok_count": sum(
                1
                for item in fulfillment_records
                if item.get("redrive_execution_receipt_json_ok")
            ),
            "redrive_execution_receipt_json_error_count": sum(
                1
                for item in fulfillment_records
                if item.get("redrive_execution_receipt_json_error")
            ),
            "redrive_execution_receipt_schema_match_count": sum(
                1
                for item in fulfillment_records
                if item.get("redrive_execution_receipt_schema_match")
            ),
            "redrive_execution_receipt_schema_mismatch_count": sum(
                1
                for item in fulfillment_records
                if item.get("redrive_execution_receipt_schema_mismatch")
            ),
            "redrive_execution_receipt_binding_match_count": sum(
                1
                for item in fulfillment_records
                if item.get("redrive_execution_receipt_binding_match")
            ),
            "redrive_execution_receipt_binding_mismatch_count": sum(
                1
                for item in fulfillment_records
                if item.get("redrive_execution_receipt_binding_mismatch")
            ),
            "redrive_execution_receipt_performed_count": receipt_performed_count,
            "redrive_execution_receipt_not_performed_count": record_count - receipt_performed_count,
            "request_fulfillment_intake_record_count": request_count,
            "request_fulfillment_ready_count": request_ready_count,
            "request_fulfillment_blocked_count": request_blocked_count,
            "proof_status_fulfillment_required_count": _count(
                fulfillment_records, "proof_status"
            ),
            "proof_status_fulfilled_count": _count(
                fulfillment_records, "proof_status", "source_slot_fulfilled"
            ),
            "evidence_manifest_fulfillment_required_count": _count(
                fulfillment_records, "evidence_manifest"
            ),
            "evidence_manifest_fulfilled_count": _count(
                fulfillment_records, "evidence_manifest", "source_slot_fulfilled"
            ),
            "appendix_supplement_fulfillment_required_count": _count(
                fulfillment_records, "appendix_supplement"
            ),
            "appendix_supplement_fulfilled_count": _count(
                fulfillment_records, "appendix_supplement", "source_slot_fulfilled"
            ),
            "claim_downgrade_fulfillment_required_count": _count(
                fulfillment_records, "claim_downgrade"
            ),
            "claim_downgrade_fulfilled_count": _count(
                fulfillment_records, "claim_downgrade", "source_slot_fulfilled"
            ),
            "referee_rejudge_fulfillment_required_count": _count(
                fulfillment_records, "referee_rejudge"
            ),
            "referee_rejudge_fulfilled_count": _count(
                fulfillment_records, "referee_rejudge", "source_slot_fulfilled"
            ),
            "upstream_redrive_safe_count": sum(
                1 for item in fulfillment_records if item.get("upstream_safe_to_redrive")
            ),
            "upstream_redrive_blocked_count": sum(
                1 for item in fulfillment_records if not item.get("upstream_safe_to_redrive")
            ),
            "consumable_as_repair_evidence_fulfillment_count": consumable_count,
            "source_slot_fulfillment_intake_ready": intake_ready,
            "failed_check_count": len(failed),
        },
        "source_slot_fulfillment_intake_records": request_fulfillment_records,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This capstone only inventories source-slot fulfillment and redrive execution receipt intake.",
            "It never writes, creates, refreshes, or validates expected repair packet source files or receipts.",
            "Fulfillment intake and redrive receipt records are not repair evidence, proof-status updates, evidence manifests, appendix/supplement content, referee rejudge results, source-ready closure, or request closure evidence.",
            "The command never edits manuscripts, creates proof evidence, applies patches, rebuilds packages, uploads, emails, submits, performs external actions, or fabricates proof/referee evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Referee Repair Packet Source-Slot Fulfillment Intake",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_packet_source_slot_fulfillment_intake_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Manual Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
