"""Real source artifact intake queue for referee repair production.

This report validates existing source/operator-intake/redrive artifacts named
by the source authoring surface. It never creates source material or receipts.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import shlex
from pathlib import Path


COMMAND = "paper-production-referee-repair-source-artifact-intake-queue"
SCHEMA_ID = "paper_factory.paper_production.referee_repair_source_artifact_intake_queue.v1"

PASS = "PASS"
FAIL = "FAIL"

READY_STATE = "REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_QUEUE_READY"
AUTHORING_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_AUTHORING_SURFACE"
INPUT_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_INPUT_FILES"
IDENTITY_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_IDENTITY"
RESOURCE_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_RESOURCE"
STABILITY_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_STABILITY"
SHAPE_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_SHAPE"
REAL_INTAKE_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_REAL_INTAKE"
ATTESTATION_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_ATTESTATION"
ACTION_LEAK_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_ACTION_LEAK"
TARGET_SCOPE_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_ARTIFACT_INTAKE_TARGET_SCOPE"

REPAIR_SOURCE_ROOT = Path("logs/paperctl/_repair_packet_sources")
MAX_ARTIFACT_BYTES = 5 * 1024 * 1024

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_source_artifact_intake_queue_state",
    "external_action_authorized",
    "external_action_performed",
    "report_schema",
    "summary",
    "target_scope",
    "source_artifact_intake_records",
    "source_artifact_attestation_validation",
    "source_artifact_attestation_checklist_validation",
    "source_artifact_attestation_manifest_binding",
    "source_artifact_attestation_validation_closure_rows",
    "source_artifact_attestation_group_closure_rows",
    "source_artifact_local_candidate_discovery",
    "source_artifact_local_candidate_discovery_rows",
    "source_artifact_round_trip_status",
    "source_artifact_round_trip_status_rows",
    "source_artifact_round_trip_action_packet",
    "source_artifact_round_trip_action_rows",
    "source_artifact_authoring_work_order_manifest",
    "source_artifact_authoring_work_order_rows",
    "source_artifact_work_order_attestation_manifest_bridge",
    "source_artifact_work_order_attestation_manifest_bridge_rows",
    "source_artifact_work_order_attestation_manifest_fill_packet",
    "source_artifact_work_order_attestation_manifest_fill_packet_rows",
    "source_artifact_work_order_attestation_manifest_filled_preflight",
    "source_artifact_work_order_attestation_manifest_filled_preflight_rows",
    "source_artifact_attestation_manifest_filled_preflight_detail",
    "source_artifact_attestation_manifest_filled_preflight_detail_rows",
    "source_artifact_operator_reviewer_execution_packet",
    "source_artifact_operator_reviewer_execution_packet_rows",
    "source_artifact_production_evidence_closure_packet",
    "source_artifact_production_evidence_closure_packet_rows",
    "source_artifact_real_evidence_intake_review_packet",
    "source_artifact_real_evidence_intake_review_packet_rows",
    "source_artifact_operator_fill_reviewer_acceptance_packet",
    "source_artifact_operator_fill_reviewer_acceptance_packet_rows",
    "source_artifact_closure_gap_summary",
    "source_artifact_closure_gap_summary_rows",
    "source_artifact_real_closure_intake_packet",
    "source_artifact_real_closure_intake_packet_rows",
    "source_artifact_real_closure_stage_preflight_packet",
    "source_artifact_real_closure_stage_preflight_packet_rows",
    "source_artifact_real_closure_operator_action_queue",
    "source_artifact_real_closure_operator_action_queue_rows",
    "source_artifact_attestation_manifest_template",
    "source_artifact_attestation_manifest_template_rows",
    "generated_artifacts",
    "upstream_refs",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "authoring_surface_status",
    "authoring_surface_state",
    "authoring_surface_ready",
    "target_scope_enforced",
    "target_scope_status",
    "target_scope_state",
    "target_scope_ready",
    "target_paper_count",
    "target_scoped_slug_count",
    "target_slug_set_hash",
    "target_scope_failed_check_count",
    "target_scope_report_path",
    "source_authoring_surface_record_count",
    "expected_source_packet_count",
    "source_packet_present_count",
    "source_packet_valid_count",
    "expected_operator_intake_packet_count",
    "operator_intake_packet_present_count",
    "operator_intake_packet_valid_count",
    "expected_redrive_receipt_count",
    "redrive_receipt_present_count",
    "redrive_receipt_valid_count",
    "total_expected_artifact_count",
    "total_present_artifact_count",
    "total_valid_artifact_count",
    "missing_artifact_count",
    "identity_invalid_count",
    "resource_invalid_count",
    "stability_unstable_count",
    "shape_invalid_count",
    "source_artifact_attestation_row_count",
    "source_artifact_attestation_required_count",
    "source_artifact_attestation_matched_count",
    "source_artifact_attestation_missing_count",
    "source_artifact_attestation_unexpected_count",
    "source_artifact_attestation_duplicate_count",
    "source_artifact_attestation_sha_invalid_count",
    "source_artifact_attestation_sha_mismatch_count",
    "source_artifact_attestation_sha_unavailable_count",
    "source_artifact_attestation_metadata_missing_count",
    "source_artifact_attestation_ready",
    "source_artifact_attestation_source",
    "source_artifact_attestation_manifest_bound_to_real_intake",
    "source_artifact_attestation_manifest_binding_source",
    "source_artifact_attestation_manifest_binding_manifest_path",
    "source_artifact_attestation_manifest_binding_manifest_sha256",
    "source_artifact_attestation_manifest_binding_real_intake_path",
    "source_artifact_attestation_manifest_binding_path_match",
    "source_artifact_attestation_manifest_binding_row_count_match",
    "source_artifact_attestation_manifest_binding_issue_count",
    "source_artifact_attestation_manifest_binding_hash",
    "source_artifact_attestation_checklist_ready",
    "source_artifact_attestation_checklist_row_count",
    "source_artifact_attestation_checklist_required_count",
    "source_artifact_attestation_checklist_matched_count",
    "source_artifact_attestation_checklist_missing_count",
    "source_artifact_attestation_checklist_unexpected_count",
    "source_artifact_attestation_checklist_duplicate_count",
    "source_artifact_attestation_checklist_closure_present_count",
    "source_artifact_attestation_checklist_closure_command_present_count",
    "source_artifact_attestation_checklist_attestation_row_present_count",
    "source_artifact_attestation_checklist_attested_sha_valid_count",
    "source_artifact_attestation_checklist_file_present_count",
    "source_artifact_attestation_checklist_file_sha_available_count",
    "source_artifact_attestation_checklist_sha_match_count",
    "source_artifact_attestation_checklist_sha_mismatch_count",
    "source_artifact_attestation_checklist_metadata_ready_count",
    "source_artifact_attestation_checklist_first_missing_path",
    "source_artifact_attestation_checklist_first_open_path",
    "source_artifact_attestation_checklist_hash",
    "source_artifact_attestation_validation_closure_csv_path",
    "source_artifact_attestation_validation_closure_csv_sha256",
    "source_artifact_attestation_validation_closure_csv_row_count",
    "source_artifact_attestation_group_closure_csv_path",
    "source_artifact_attestation_group_closure_csv_sha256",
    "source_artifact_attestation_group_closure_csv_row_count",
    "source_artifact_attestation_group_closure_ready_count",
    "source_artifact_attestation_group_closure_open_count",
    "source_artifact_attestation_group_closure_first_open_key",
    "source_artifact_local_candidate_discovery_csv_path",
    "source_artifact_local_candidate_discovery_csv_sha256",
    "source_artifact_local_candidate_discovery_csv_row_count",
    "source_artifact_local_candidate_discovery_expected_count",
    "source_artifact_local_candidate_discovery_candidate_count",
    "source_artifact_local_candidate_discovery_with_candidates_count",
    "source_artifact_local_candidate_discovery_first_unresolved_path",
    "source_artifact_local_candidate_discovery_first_candidate_path",
    "source_artifact_local_candidate_discovery_scanned_file_count",
    "source_artifact_local_candidate_discovery_complete",
    "source_artifact_local_candidate_discovery_hash",
    "source_artifact_round_trip_status_packet_ready",
    "source_artifact_round_trip_status_row_count",
    "source_artifact_round_trip_status_local_ready_count",
    "source_artifact_round_trip_status_missing_count",
    "source_artifact_round_trip_status_attestation_ready_count",
    "source_artifact_round_trip_status_attestation_missing_count",
    "source_artifact_round_trip_status_metadata_ready_count",
    "source_artifact_round_trip_status_shape_ready_count",
    "source_artifact_round_trip_status_first_unready_path",
    "source_artifact_round_trip_status_hash",
    "source_artifact_round_trip_status_csv_path",
    "source_artifact_round_trip_status_csv_sha256",
    "source_artifact_round_trip_status_json_path",
    "source_artifact_round_trip_status_json_sha256",
    "source_artifact_round_trip_action_packet_ready",
    "source_artifact_round_trip_action_row_count",
    "source_artifact_round_trip_action_open_count",
    "source_artifact_round_trip_action_candidate_count",
    "source_artifact_round_trip_action_with_candidates_count",
    "source_artifact_round_trip_action_first_open_path",
    "source_artifact_round_trip_action_hash",
    "source_artifact_round_trip_action_csv_path",
    "source_artifact_round_trip_action_csv_sha256",
    "source_artifact_round_trip_action_json_path",
    "source_artifact_round_trip_action_json_sha256",
    "source_artifact_authoring_work_order_manifest_ready",
    "source_artifact_authoring_work_order_row_count",
    "source_artifact_authoring_work_order_open_count",
    "source_artifact_authoring_work_order_ready_count",
    "source_artifact_authoring_work_order_missing_artifact_count",
    "source_artifact_authoring_work_order_candidate_count",
    "source_artifact_authoring_work_order_with_candidates_count",
    "source_artifact_authoring_work_order_first_open_path",
    "source_artifact_authoring_work_order_hash",
    "source_artifact_authoring_work_order_csv_path",
    "source_artifact_authoring_work_order_csv_sha256",
    "source_artifact_authoring_work_order_json_path",
    "source_artifact_authoring_work_order_json_sha256",
    "source_artifact_work_order_attestation_manifest_bridge_ready",
    "source_artifact_work_order_attestation_manifest_bridge_row_count",
    "source_artifact_work_order_attestation_manifest_bridge_matched_count",
    "source_artifact_work_order_attestation_manifest_bridge_open_count",
    "source_artifact_work_order_attestation_manifest_bridge_missing_artifact_count",
    "source_artifact_work_order_attestation_manifest_bridge_unmatched_work_order_count",
    "source_artifact_work_order_attestation_manifest_bridge_unmatched_manifest_row_count",
    "source_artifact_work_order_attestation_manifest_bridge_unmatched_status_row_count",
    "source_artifact_work_order_attestation_manifest_bridge_first_open_path",
    "source_artifact_work_order_attestation_manifest_bridge_hash",
    "source_artifact_work_order_attestation_manifest_bridge_csv_path",
    "source_artifact_work_order_attestation_manifest_bridge_csv_sha256",
    "source_artifact_work_order_attestation_manifest_bridge_json_path",
    "source_artifact_work_order_attestation_manifest_bridge_json_sha256",
    "source_artifact_work_order_attestation_manifest_fill_packet_ready",
    "source_artifact_work_order_attestation_manifest_fill_packet_row_count",
    "source_artifact_work_order_attestation_manifest_fill_packet_ready_count",
    "source_artifact_work_order_attestation_manifest_fill_packet_open_count",
    "source_artifact_work_order_attestation_manifest_fill_packet_missing_artifact_count",
    "source_artifact_work_order_attestation_manifest_fill_packet_template_row_count",
    "source_artifact_work_order_attestation_manifest_fill_packet_real_intake_manifest_path",
    "source_artifact_work_order_attestation_manifest_fill_packet_first_open_path",
    "source_artifact_work_order_attestation_manifest_fill_packet_hash",
    "source_artifact_work_order_attestation_manifest_fill_packet_csv_path",
    "source_artifact_work_order_attestation_manifest_fill_packet_csv_sha256",
    "source_artifact_work_order_attestation_manifest_fill_packet_json_path",
    "source_artifact_work_order_attestation_manifest_fill_packet_json_sha256",
    "source_artifact_work_order_attestation_manifest_filled_preflight_ready",
    "source_artifact_work_order_attestation_manifest_filled_preflight_row_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_ready_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_open_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_expected_row_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_filled_row_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_missing_attestation_row_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_duplicate_attestation_row_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_unexpected_attestation_row_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_sha_valid_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_sha_match_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_metadata_ready_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_missing_artifact_count",
    "source_artifact_work_order_attestation_manifest_filled_preflight_manifest_path",
    "source_artifact_work_order_attestation_manifest_filled_preflight_first_open_path",
    "source_artifact_work_order_attestation_manifest_filled_preflight_hash",
    "source_artifact_work_order_attestation_manifest_filled_preflight_csv_path",
    "source_artifact_work_order_attestation_manifest_filled_preflight_csv_sha256",
    "source_artifact_work_order_attestation_manifest_filled_preflight_json_path",
    "source_artifact_work_order_attestation_manifest_filled_preflight_json_sha256",
    "source_artifact_attestation_manifest_filled_preflight_detail_ready",
    "source_artifact_attestation_manifest_filled_preflight_detail_row_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_ready_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_open_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_missing_artifact_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_missing_attestation_row_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_sha_valid_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_sha_match_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_metadata_ready_count",
    "source_artifact_attestation_manifest_filled_preflight_detail_first_open_path",
    "source_artifact_attestation_manifest_filled_preflight_detail_hash",
    "source_artifact_attestation_manifest_filled_preflight_detail_csv_path",
    "source_artifact_attestation_manifest_filled_preflight_detail_csv_sha256",
    "source_artifact_attestation_manifest_filled_preflight_detail_json_path",
    "source_artifact_attestation_manifest_filled_preflight_detail_json_sha256",
    "source_artifact_operator_reviewer_execution_packet_ready",
    "source_artifact_operator_reviewer_execution_packet_row_count",
    "source_artifact_operator_reviewer_execution_packet_ready_count",
    "source_artifact_operator_reviewer_execution_packet_open_count",
    "source_artifact_operator_reviewer_execution_packet_operator_blocked_count",
    "source_artifact_operator_reviewer_execution_packet_reviewer_blocked_count",
    "source_artifact_operator_reviewer_execution_packet_missing_artifact_count",
    "source_artifact_operator_reviewer_execution_packet_missing_attestation_row_count",
    "source_artifact_operator_reviewer_execution_packet_sha_blocked_count",
    "source_artifact_operator_reviewer_execution_packet_metadata_blocked_count",
    "source_artifact_operator_reviewer_execution_packet_first_operator_path",
    "source_artifact_operator_reviewer_execution_packet_first_reviewer_path",
    "source_artifact_operator_reviewer_execution_packet_hash",
    "source_artifact_operator_reviewer_execution_packet_csv_path",
    "source_artifact_operator_reviewer_execution_packet_csv_sha256",
    "source_artifact_operator_reviewer_execution_packet_json_path",
    "source_artifact_operator_reviewer_execution_packet_json_sha256",
    "source_artifact_production_evidence_closure_packet_ready",
    "source_artifact_production_evidence_closure_packet_row_count",
    "source_artifact_production_evidence_closure_packet_ready_count",
    "source_artifact_production_evidence_closure_packet_open_count",
    "source_artifact_production_evidence_closure_packet_local_artifact_ready_count",
    "source_artifact_production_evidence_closure_packet_missing_artifact_count",
    "source_artifact_production_evidence_closure_packet_attestation_ready_count",
    "source_artifact_production_evidence_closure_packet_missing_attestation_row_count",
    "source_artifact_production_evidence_closure_packet_sha_match_count",
    "source_artifact_production_evidence_closure_packet_metadata_ready_count",
    "source_artifact_production_evidence_closure_packet_operator_reviewer_ready_count",
    "source_artifact_production_evidence_closure_packet_operator_blocked_count",
    "source_artifact_production_evidence_closure_packet_reviewer_blocked_count",
    "source_artifact_production_evidence_closure_packet_manifest_bound_to_real_intake",
    "source_artifact_production_evidence_closure_packet_manifest_binding_issue_count",
    "source_artifact_production_evidence_closure_packet_real_intake_operator_closure_ready",
    "source_artifact_production_evidence_closure_packet_real_intake_attestation_packet_ready",
    "source_artifact_production_evidence_closure_packet_real_intake_operator_input_missing_count",
    "source_artifact_production_evidence_closure_packet_first_open_path",
    "source_artifact_production_evidence_closure_packet_blocking_state",
    "source_artifact_production_evidence_closure_packet_blocking_reason",
    "source_artifact_production_evidence_closure_packet_hash",
    "source_artifact_production_evidence_closure_packet_csv_path",
    "source_artifact_production_evidence_closure_packet_csv_sha256",
    "source_artifact_production_evidence_closure_packet_json_path",
    "source_artifact_production_evidence_closure_packet_json_sha256",
    "source_artifact_real_evidence_intake_review_packet_ready",
    "source_artifact_real_evidence_intake_review_packet_row_count",
    "source_artifact_real_evidence_intake_review_packet_ready_count",
    "source_artifact_real_evidence_intake_review_packet_open_count",
    "source_artifact_real_evidence_intake_review_packet_operator_action_required_count",
    "source_artifact_real_evidence_intake_review_packet_reviewer_action_required_count",
    "source_artifact_real_evidence_intake_review_packet_missing_artifact_count",
    "source_artifact_real_evidence_intake_review_packet_missing_attestation_row_count",
    "source_artifact_real_evidence_intake_review_packet_ready_for_local_review_count",
    "source_artifact_real_evidence_intake_review_packet_first_open_path",
    "source_artifact_real_evidence_intake_review_packet_blocking_state",
    "source_artifact_real_evidence_intake_review_packet_blocking_reason",
    "source_artifact_real_evidence_intake_review_packet_hash",
    "source_artifact_real_evidence_intake_review_packet_csv_path",
    "source_artifact_real_evidence_intake_review_packet_csv_sha256",
    "source_artifact_real_evidence_intake_review_packet_json_path",
    "source_artifact_real_evidence_intake_review_packet_json_sha256",
    "source_artifact_operator_fill_reviewer_acceptance_packet_ready",
    "source_artifact_operator_fill_reviewer_acceptance_packet_row_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_ready_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_open_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_operator_fill_required_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_reviewer_acceptance_required_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_attestation_row_closure_required_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_missing_artifact_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_missing_attestation_row_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_ready_for_reviewer_count",
    "source_artifact_operator_fill_reviewer_acceptance_packet_first_open_path",
    "source_artifact_operator_fill_reviewer_acceptance_packet_blocking_state",
    "source_artifact_operator_fill_reviewer_acceptance_packet_blocking_reason",
    "source_artifact_operator_fill_reviewer_acceptance_packet_hash",
    "source_artifact_operator_fill_reviewer_acceptance_packet_csv_path",
    "source_artifact_operator_fill_reviewer_acceptance_packet_csv_sha256",
    "source_artifact_operator_fill_reviewer_acceptance_packet_json_path",
    "source_artifact_operator_fill_reviewer_acceptance_packet_json_sha256",
    "source_artifact_closure_gap_summary_ready",
    "source_artifact_closure_gap_summary_row_count",
    "source_artifact_closure_gap_summary_ready_count",
    "source_artifact_closure_gap_summary_open_count",
    "source_artifact_closure_gap_summary_missing_file_count",
    "source_artifact_closure_gap_summary_missing_attestation_row_count",
    "source_artifact_closure_gap_summary_operator_fill_required_count",
    "source_artifact_closure_gap_summary_reviewer_acceptance_required_count",
    "source_artifact_closure_gap_summary_attestation_row_closure_required_count",
    "source_artifact_closure_gap_summary_first_open_path",
    "source_artifact_closure_gap_summary_first_next_action",
    "source_artifact_closure_gap_summary_hash",
    "source_artifact_closure_gap_summary_csv_path",
    "source_artifact_closure_gap_summary_csv_sha256",
    "source_artifact_closure_gap_summary_csv_row_count",
    "source_artifact_real_closure_intake_packet_ready",
    "source_artifact_real_closure_intake_packet_row_count",
    "source_artifact_real_closure_intake_packet_ready_count",
    "source_artifact_real_closure_intake_packet_open_count",
    "source_artifact_real_closure_intake_packet_operator_stage_count",
    "source_artifact_real_closure_intake_packet_reviewer_stage_count",
    "source_artifact_real_closure_intake_packet_attestation_stage_count",
    "source_artifact_real_closure_intake_packet_blocked_before_reviewer_count",
    "source_artifact_real_closure_intake_packet_blocked_before_attestation_count",
    "source_artifact_real_closure_intake_packet_first_open_path",
    "source_artifact_real_closure_intake_packet_first_next_owner",
    "source_artifact_real_closure_intake_packet_first_next_action",
    "source_artifact_real_closure_intake_packet_hash",
    "source_artifact_real_closure_intake_packet_csv_path",
    "source_artifact_real_closure_intake_packet_csv_sha256",
    "source_artifact_real_closure_intake_packet_json_path",
    "source_artifact_real_closure_intake_packet_json_sha256",
    "source_artifact_real_closure_stage_preflight_packet_ready",
    "source_artifact_real_closure_stage_preflight_packet_row_count",
    "source_artifact_real_closure_stage_preflight_packet_ready_count",
    "source_artifact_real_closure_stage_preflight_packet_open_count",
    "source_artifact_real_closure_stage_preflight_packet_actionable_count",
    "source_artifact_real_closure_stage_preflight_packet_blocked_count",
    "source_artifact_real_closure_stage_preflight_packet_operator_stage_row_count",
    "source_artifact_real_closure_stage_preflight_packet_operator_actionable_count",
    "source_artifact_real_closure_stage_preflight_packet_reviewer_stage_row_count",
    "source_artifact_real_closure_stage_preflight_packet_reviewer_blocked_count",
    "source_artifact_real_closure_stage_preflight_packet_attestation_stage_row_count",
    "source_artifact_real_closure_stage_preflight_packet_attestation_blocked_count",
    "source_artifact_real_closure_stage_preflight_packet_first_actionable_path",
    "source_artifact_real_closure_stage_preflight_packet_first_actionable_stage",
    "source_artifact_real_closure_stage_preflight_packet_first_actionable_next_action",
    "source_artifact_real_closure_stage_preflight_packet_hash",
    "source_artifact_real_closure_stage_preflight_packet_csv_path",
    "source_artifact_real_closure_stage_preflight_packet_csv_sha256",
    "source_artifact_real_closure_stage_preflight_packet_json_path",
    "source_artifact_real_closure_stage_preflight_packet_json_sha256",
    "source_artifact_real_closure_operator_action_queue_ready",
    "source_artifact_real_closure_operator_action_queue_row_count",
    "source_artifact_real_closure_operator_action_queue_required_field_count",
    "source_artifact_real_closure_operator_action_queue_missing_source_count",
    "source_artifact_real_closure_operator_action_queue_first_expected_path",
    "source_artifact_real_closure_operator_action_queue_first_request_id",
    "source_artifact_real_closure_operator_action_queue_first_next_action",
    "source_artifact_real_closure_operator_action_queue_hash",
    "source_artifact_real_closure_operator_action_queue_csv_path",
    "source_artifact_real_closure_operator_action_queue_csv_sha256",
    "source_artifact_real_closure_operator_action_queue_json_path",
    "source_artifact_real_closure_operator_action_queue_json_sha256",
    "source_artifact_attestation_manifest_template_ready",
    "source_artifact_attestation_manifest_template_required_row_count",
    "source_artifact_attestation_manifest_template_row_count",
    "source_artifact_attestation_manifest_template_hash",
    "source_artifact_attestation_manifest_template_json_path",
    "source_artifact_attestation_manifest_template_json_sha256",
    "source_artifact_attestation_manifest_fill_template_csv_path",
    "source_artifact_attestation_manifest_fill_template_csv_sha256",
    "source_artifact_attestation_manifest_fill_template_csv_row_count",
    "real_intake_acceptance_status",
    "real_intake_acceptance_state",
    "real_intake_operator_input_expected_count",
    "real_intake_operator_input_present_count",
    "real_intake_operator_input_missing_count",
    "real_intake_operator_input_closure_packet_ready",
    "real_intake_operator_input_closure_packet_required_count",
    "real_intake_operator_input_closure_packet_satisfied_count",
    "real_intake_operator_input_closure_packet_open_count",
    "real_intake_operator_input_closure_packet_missing_file_count",
    "real_intake_operator_input_closure_packet_first_open_path",
    "real_intake_operator_input_closure_packet_hash",
    "real_intake_operator_input_template_ready",
    "real_intake_operator_input_template_required_count",
    "real_intake_operator_input_template_row_count",
    "real_intake_operator_input_template_hash",
    "real_intake_operator_input_template_json_path",
    "real_intake_operator_input_template_json_sha256",
    "real_intake_operator_input_fill_template_csv_path",
    "real_intake_operator_input_fill_template_csv_sha256",
    "real_intake_operator_input_fill_template_csv_row_count",
    "real_intake_operator_input_local_candidate_discovery_csv_path",
    "real_intake_operator_input_local_candidate_discovery_csv_sha256",
    "real_intake_operator_input_local_candidate_discovery_csv_row_count",
    "real_intake_operator_input_local_candidate_discovery_expected_count",
    "real_intake_operator_input_local_candidate_discovery_candidate_count",
    "real_intake_operator_input_local_candidate_discovery_with_candidates_count",
    "real_intake_operator_input_local_candidate_discovery_first_unresolved_path",
    "real_intake_operator_input_local_candidate_discovery_first_candidate_path",
    "real_intake_operator_input_local_candidate_discovery_scanned_file_count",
    "real_intake_operator_input_local_candidate_discovery_complete",
    "real_intake_operator_input_local_candidate_discovery_hash",
    "real_intake_operator_input_round_trip_packet_ready",
    "real_intake_operator_input_round_trip_packet_row_count",
    "real_intake_operator_input_round_trip_packet_open_count",
    "real_intake_operator_input_round_trip_packet_candidate_count",
    "real_intake_operator_input_round_trip_packet_with_candidates_count",
    "real_intake_operator_input_round_trip_packet_first_open_path",
    "real_intake_operator_input_round_trip_packet_hash",
    "real_intake_operator_input_round_trip_packet_path",
    "real_intake_operator_input_round_trip_packet_sha256",
    "real_intake_operator_input_round_trip_action_csv_path",
    "real_intake_operator_input_round_trip_action_csv_sha256",
    "real_intake_operator_input_round_trip_action_csv_row_count",
    "real_intake_operator_input_round_trip_status_packet_ready",
    "real_intake_operator_input_round_trip_status_row_count",
    "real_intake_operator_input_round_trip_status_local_ready_count",
    "real_intake_operator_input_round_trip_status_missing_count",
    "real_intake_operator_input_round_trip_status_shape_ready_count",
    "real_intake_operator_input_round_trip_status_shape_invalid_count",
    "real_intake_operator_input_round_trip_status_first_unready_path",
    "real_intake_operator_input_round_trip_status_hash",
    "real_intake_operator_input_round_trip_status_csv_path",
    "real_intake_operator_input_round_trip_status_csv_sha256",
    "real_intake_operator_input_round_trip_status_json_path",
    "real_intake_operator_input_round_trip_status_json_sha256",
    "real_intake_operator_input_filled_preflight_ready",
    "real_intake_operator_input_filled_preflight_row_count",
    "real_intake_operator_input_filled_preflight_expected_count",
    "real_intake_operator_input_filled_preflight_ready_count",
    "real_intake_operator_input_filled_preflight_open_count",
    "real_intake_operator_input_filled_preflight_missing_count",
    "real_intake_operator_input_filled_preflight_shape_invalid_count",
    "real_intake_operator_input_filled_preflight_first_open_path",
    "real_intake_operator_input_filled_preflight_hash",
    "real_intake_operator_input_filled_preflight_csv_path",
    "real_intake_operator_input_filled_preflight_csv_sha256",
    "real_intake_operator_input_filled_preflight_json_path",
    "real_intake_operator_input_filled_preflight_json_sha256",
    "real_intake_source_artifact_operator_closure_csv_required",
    "real_intake_source_artifact_operator_closure_csv_ready",
    "real_intake_source_artifact_operator_closure_expected_row_count",
    "real_intake_source_artifact_operator_closure_row_count",
    "real_intake_source_artifact_operator_closure_csv_path",
    "real_intake_source_artifact_operator_closure_csv_sha256_match",
    "real_intake_source_artifact_operator_closure_csv_shape_ready",
    "real_intake_source_artifact_attestation_packet_ready",
    "real_intake_source_artifact_attestation_packet_required_row_count",
    "real_intake_source_artifact_attestation_packet_row_count",
    "real_intake_source_artifact_attestation_packet_closure_row_count",
    "real_intake_source_artifact_attestation_packet_closure_matched_count",
    "real_intake_source_artifact_attestation_packet_closure_missing_count",
    "real_intake_source_artifact_attestation_packet_manifest_path",
    "real_intake_source_artifact_attestation_packet_operator_input_missing_count",
    "real_intake_source_artifact_attestation_packet_hash",
    "real_intake_source_artifact_attestation_checklist_csv_path",
    "real_intake_source_artifact_attestation_checklist_csv_sha256",
    "real_intake_source_artifact_attestation_checklist_csv_row_count",
    "real_intake_attestation_present",
    "real_intake_failed_check_count",
    "forbidden_action_count",
    "first_missing_artifact_path",
    "first_invalid_artifact_path",
    "referee_repair_source_artifact_intake_queue_ready",
    "failed_check_count",
    "source_artifact_intake_queue_hash",
]

SOURCE_ARTIFACT_ATTESTATION_VALIDATION_CLOSURE_CSV_FIELDS = [
    "row_index",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "ready",
    "blocking_reason",
    "required_operator_action",
    "checklist_row_present",
    "closure_row_present",
    "closure_command_present",
    "file_present",
    "file_sha_available",
    "actual_file_sha256",
    "attestation_row_present",
    "attested_artifact_sha256",
    "attested_sha_valid",
    "sha_match",
    "metadata_ready",
    "attested_by",
    "attested_at",
    "attestation_source",
    "closure_action_id",
    "closure_status",
    "closure_local_sha256_command",
    "closure_filled_manifest_command",
    "closure_intake_validation_command",
    "manual_boundary",
]

SOURCE_ARTIFACT_ATTESTATION_MANIFEST_FILL_TEMPLATE_CSV_FIELDS = [
    "row_index",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "artifact_sha256",
    "provided_by",
    "provided_at",
    "attestation_source",
    "notes",
    "blocking_reason",
    "required_operator_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "source_validation_closure_row_index",
    "source_validation_closure_ready",
    "manual_boundary",
]

SOURCE_ARTIFACT_ATTESTATION_GROUP_CLOSURE_CSV_FIELDS = [
    "group_index",
    "request_id",
    "slug",
    "packet_type",
    "ready",
    "expected_artifact_count",
    "present_artifact_count",
    "missing_artifact_count",
    "attestation_row_present_count",
    "metadata_ready_count",
    "source_packet_path",
    "operator_intake_packet_path",
    "redrive_receipt_path",
    "blocking_reason",
    "required_operator_action",
    "mkdir_command",
    "local_sha256_commands",
    "filled_manifest_command",
    "intake_validation_command",
    "manual_boundary",
]

SOURCE_ARTIFACT_LOCAL_CANDIDATE_DISCOVERY_CSV_FIELDS = [
    "row_index",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "expected_basename",
    "expected_present",
    "candidate_count",
    "best_candidate_path",
    "best_candidate_score",
    "best_candidate_reason",
    "best_candidate_byte_count",
    "best_candidate_sha256",
    "copy_candidate_command",
    "local_sha256_command",
    "intake_validation_command",
    "scan_roots",
    "scan_complete",
    "manual_boundary",
]

SOURCE_ARTIFACT_ROUND_TRIP_STATUS_CSV_FIELDS = [
    "row_index",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "local_ready",
    "file_present",
    "file_sha_available",
    "actual_file_sha256",
    "attestation_ready",
    "attestation_row_present",
    "attested_artifact_sha256",
    "attested_sha_valid",
    "sha_match",
    "metadata_ready",
    "shape_ready",
    "checklist_row_present",
    "closure_row_present",
    "closure_command_present",
    "blocking_reason",
    "required_operator_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "attested_by",
    "attested_at",
    "attestation_source",
    "manual_boundary",
]

SOURCE_ARTIFACT_ROUND_TRIP_ACTION_CSV_FIELDS = [
    "row_index",
    "action_id",
    "action_status",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "local_ready",
    "attestation_ready",
    "shape_ready",
    "blocking_reason",
    "required_operator_action",
    "candidate_count",
    "best_candidate_path",
    "best_candidate_sha256",
    "copy_candidate_command",
    "artifact_sha256",
    "provided_by",
    "provided_at",
    "attestation_source",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "status_row_index",
    "attestation_template_row_index",
    "validation_closure_row_index",
    "manual_boundary",
]

SOURCE_ARTIFACT_AUTHORING_WORK_ORDER_CSV_FIELDS = [
    "work_order_index",
    "work_order_id",
    "work_order_status",
    "request_id",
    "slug",
    "packet_type",
    "expected_artifact_count",
    "ready_artifact_count",
    "missing_artifact_count",
    "candidate_count",
    "candidate_hit_count",
    "attestation_row_present_count",
    "metadata_ready_count",
    "source_packet_path",
    "operator_intake_packet_path",
    "redrive_receipt_path",
    "first_missing_path",
    "first_candidate_path",
    "mkdir_command",
    "local_sha256_commands",
    "copy_candidate_commands",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "required_operator_action",
    "manual_boundary",
]

SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_BRIDGE_CSV_FIELDS = [
    "bridge_index",
    "work_order_id",
    "work_order_status",
    "request_id",
    "slug",
    "packet_type",
    "bridge_ready",
    "expected_artifact_count",
    "manifest_template_row_count",
    "round_trip_status_row_count",
    "real_intake_checklist_row_count",
    "local_ready_count",
    "attestation_ready_count",
    "shape_ready_count",
    "missing_artifact_count",
    "unmatched_manifest_artifact_kinds",
    "unmatched_status_artifact_kinds",
    "source_packet_path",
    "operator_intake_packet_path",
    "redrive_receipt_path",
    "first_open_path",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "required_operator_action",
    "manual_boundary",
]

SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_FILL_PACKET_CSV_FIELDS = [
    "fill_packet_index",
    "work_order_id",
    "fill_packet_status",
    "request_id",
    "slug",
    "packet_type",
    "real_intake_attestation_manifest_path",
    "expected_artifact_count",
    "manifest_template_row_count",
    "round_trip_status_row_count",
    "real_intake_checklist_row_count",
    "local_ready_count",
    "attestation_ready_count",
    "metadata_ready_count",
    "shape_ready_count",
    "missing_artifact_count",
    "open_attestation_row_count",
    "source_packet_path",
    "operator_intake_packet_path",
    "redrive_receipt_path",
    "first_open_path",
    "attestation_template_row_indexes",
    "attestation_template_expected_paths",
    "local_sha256_commands",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "required_operator_action",
    "manual_boundary",
]

SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_FILLED_PREFLIGHT_CSV_FIELDS = [
    "preflight_index",
    "work_order_id",
    "preflight_status",
    "request_id",
    "slug",
    "packet_type",
    "attestation_manifest_path",
    "expected_artifact_count",
    "filled_attestation_row_count",
    "missing_attestation_row_count",
    "duplicate_attestation_row_count",
    "unexpected_attestation_row_count",
    "local_ready_count",
    "sha_valid_count",
    "sha_match_count",
    "metadata_ready_count",
    "ready_artifact_count",
    "missing_artifact_count",
    "first_open_path",
    "expected_paths",
    "missing_expected_paths",
    "invalid_sha_paths",
    "missing_metadata_paths",
    "sha_mismatch_paths",
    "blocking_reason",
    "required_operator_action",
    "manual_boundary",
]

SOURCE_ARTIFACT_ATTESTATION_MANIFEST_FILLED_PREFLIGHT_DETAIL_CSV_FIELDS = [
    "detail_index",
    "detail_status",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "attestation_manifest_path",
    "local_ready",
    "file_present",
    "file_sha_available",
    "actual_file_sha256",
    "attestation_row_present",
    "attested_artifact_sha256",
    "attested_sha_valid",
    "sha_match",
    "metadata_ready",
    "provided_by",
    "provided_at",
    "attestation_source",
    "candidate_count",
    "best_candidate_path",
    "best_candidate_sha256",
    "copy_candidate_command",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "missing_artifact",
    "missing_attestation_row",
    "sha_invalid",
    "sha_mismatch",
    "missing_metadata",
    "blocking_reason",
    "required_operator_action",
    "status_row_index",
    "action_row_index",
    "attestation_template_row_index",
    "manual_boundary",
]

SOURCE_ARTIFACT_OPERATOR_REVIEWER_EXECUTION_PACKET_CSV_FIELDS = [
    "execution_index",
    "execution_status",
    "actor_blocking",
    "operator_blocked",
    "reviewer_blocked",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "attestation_manifest_path",
    "local_ready",
    "attestation_ready",
    "file_present",
    "actual_file_sha256",
    "attestation_row_present",
    "attested_artifact_sha256",
    "sha_match",
    "metadata_ready",
    "operator_next_action",
    "reviewer_next_action",
    "copy_candidate_command",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_PRODUCTION_EVIDENCE_CLOSURE_PACKET_CSV_FIELDS = [
    "closure_index",
    "closure_status",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "attestation_manifest_path",
    "local_artifact_ready",
    "source_artifact_file_present",
    "source_artifact_sha_available",
    "source_artifact_sha256",
    "attestation_ready",
    "attestation_row_present",
    "attested_artifact_sha256",
    "attested_sha_valid",
    "sha_match",
    "attestation_metadata_ready",
    "operator_reviewer_packet_ready",
    "operator_blocked",
    "reviewer_blocked",
    "manifest_bound_to_real_intake",
    "manifest_binding_issue_count",
    "real_intake_source_artifact_operator_closure_ready",
    "real_intake_source_artifact_attestation_packet_ready",
    "real_intake_operator_input_missing_count",
    "production_evidence_closure_ready",
    "blocking_reason",
    "required_operator_action",
    "operator_next_action",
    "reviewer_next_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "manual_boundary",
]

SOURCE_ARTIFACT_REAL_EVIDENCE_INTAKE_REVIEW_PACKET_CSV_FIELDS = [
    "review_index",
    "review_status",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "attestation_manifest_path",
    "source_artifact_file_present",
    "attestation_row_present",
    "operator_action_required",
    "reviewer_action_required",
    "ready_for_local_review",
    "production_evidence_closure_ready",
    "required_operator_action",
    "required_reviewer_action",
    "operator_next_action",
    "reviewer_next_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_OPERATOR_FILL_REVIEWER_ACCEPTANCE_PACKET_CSV_FIELDS = [
    "closure_index",
    "closure_status",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "attestation_manifest_path",
    "operator_fill_required",
    "operator_fill_state",
    "reviewer_acceptance_required",
    "reviewer_acceptance_state",
    "attestation_row_closure_required",
    "attestation_row_closure_state",
    "source_artifact_file_present",
    "attestation_row_present",
    "ready_for_reviewer",
    "production_evidence_closure_ready",
    "required_operator_action",
    "required_reviewer_action",
    "operator_next_action",
    "reviewer_next_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_CLOSURE_GAP_SUMMARY_CSV_FIELDS = [
    "gap_index",
    "gap_status",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "missing_file",
    "missing_attestation_row",
    "operator_fill_required",
    "reviewer_acceptance_required",
    "attestation_row_closure_required",
    "ready_for_reviewer",
    "production_evidence_closure_ready",
    "next_blocking_role",
    "next_action",
    "required_operator_fields",
    "required_reviewer_fields",
    "required_attestation_fields",
    "required_operator_field_count",
    "required_reviewer_field_count",
    "required_attestation_field_count",
    "required_field_count",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_REAL_CLOSURE_INTAKE_PACKET_CSV_FIELDS = [
    "intake_index",
    "intake_status",
    "closure_stage",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "source_material_present",
    "attestation_row_present",
    "operator_stage_open",
    "reviewer_stage_open",
    "attestation_stage_open",
    "reviewer_acceptance_allowed",
    "attestation_closure_allowed",
    "production_evidence_closure_ready",
    "next_owner",
    "next_action",
    "operator_required_fields",
    "reviewer_required_fields",
    "attestation_required_fields",
    "operator_required_field_count",
    "reviewer_required_field_count",
    "attestation_required_field_count",
    "total_required_field_count",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_REAL_CLOSURE_STAGE_PREFLIGHT_PACKET_CSV_FIELDS = [
    "stage_index",
    "intake_index",
    "stage_status",
    "stage_owner",
    "stage_name",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "stage_actionable",
    "allowed_to_start",
    "blocked_by_stage",
    "required_fields",
    "required_field_count",
    "source_material_present",
    "attestation_row_present",
    "production_evidence_closure_ready",
    "next_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_REAL_CLOSURE_OPERATOR_ACTION_QUEUE_CSV_FIELDS = [
    "queue_index",
    "stage_index",
    "intake_index",
    "request_id",
    "slug",
    "packet_type",
    "artifact_kind",
    "expected_path",
    "required_fields",
    "required_field_count",
    "next_action",
    "local_sha256_command",
    "filled_manifest_command",
    "intake_validation_command",
    "blocking_reason",
    "manual_boundary",
]

SOURCE_ARTIFACT_OPERATOR_REQUIRED_FIELDS = [
    "provided_local_path",
    "provided_sha256",
    "source_provenance_kind",
    "source_reference",
    "source_observed_at",
    "operator_notes",
]

SOURCE_ARTIFACT_REVIEWER_REQUIRED_FIELDS = [
    "attestation_provider",
    "attestation_reviewed_by",
    "attestation_reviewed_at",
]

SOURCE_ARTIFACT_ATTESTATION_REQUIRED_FIELDS = [
    "artifact_sha256",
    "provided_by",
    "provided_at",
    "attestation_source",
    "notes",
]

LOCAL_CANDIDATE_SCAN_ROOTS = (
    "logs",
    "registry",
    "submission",
)
LOCAL_CANDIDATE_SCAN_MAX_FILES = 750000
LOCAL_CANDIDATE_MAX_PER_ROW = 5


def _created_at() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _summary(report: dict | None) -> dict:
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report: dict | None, ref: dict | None = None) -> str:
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or "MISSING"
    )


def _as_int(value) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _target_scope_validation(
    target_scope_report: dict | None = None,
    target_scope_ref: dict | None = None,
) -> dict:
    report = dict(target_scope_report or {})
    ref = dict(target_scope_ref or {})
    enforced = target_scope_report is not None or target_scope_ref is not None
    if not enforced:
        return {
            "enforced": False,
            "present": False,
            "status": "NOT_ENFORCED",
            "state": "NOT_ENFORCED",
            "ready": True,
            "target_paper_count": 0,
            "scoped_slug_count": 0,
            "target_slug_set_hash": "",
            "failed_check_count": 0,
            "report_path": "",
        }

    summary = _summary(report)
    status = _status(report, ref)
    state = report.get("target_scope_state") or ""
    target_paper_count = _as_int(summary.get("target_paper_count"))
    scoped_slug_count = _as_int(summary.get("scoped_slug_count"))
    target_slug_set_hash = str(summary.get("target_slug_set_hash") or "")
    failed_check_count = _as_int(
        summary.get("failed_check_count") or len(report.get("failed_checks") or [])
    )
    ready = bool(
        status == PASS
        and state == "TARGET_SCOPE_RESOLVED"
        and target_paper_count > 0
        and scoped_slug_count > 0
        and len(target_slug_set_hash) == 64
    )
    return {
        "enforced": True,
        "present": bool(report or ref.get("path")),
        "status": status,
        "state": state or ("MISSING" if status == "MISSING" else ""),
        "ready": ready,
        "target_paper_count": target_paper_count,
        "scoped_slug_count": scoped_slug_count,
        "target_slug_set_hash": target_slug_set_hash,
        "failed_check_count": failed_check_count,
        "report_path": ref.get("path") or report.get("report_path") or "",
    }


def _truthy(value) -> bool:
    if isinstance(value, bool):
        return value
    if isinstance(value, str):
        return value.strip().lower() in {"1", "true", "yes", "y"}
    return bool(value)


def _stable_hash(kind: str, payload) -> str:
    encoded = json.dumps(
        {"kind": kind, "payload": payload},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _add_check(checks: list[dict], name: str, ok: bool, detail: str) -> None:
    checks.append(
        {
            "name": name,
            "status": PASS if ok else FAIL,
            "detail": str(detail),
            "blocking": True,
        }
    )


def _inside_root(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _sha256_file(path: Path) -> tuple[str, bool]:
    before = path.stat()
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    after = path.stat()
    stable = (
        before.st_size == after.st_size
        and before.st_mtime_ns == after.st_mtime_ns
        and before.st_ino == after.st_ino
    )
    return digest.hexdigest(), stable


def _placeholder_value(value) -> bool:
    if not isinstance(value, str):
        return False
    lowered = value.lower()
    return (
        "sha256 of" in lowered
        or "real source" in lowered
        or "operator-provided" in lowered
        or "plan " in lowered
        or "author " in lowered
    )


def _hex_sha256(value) -> bool:
    if not isinstance(value, str) or len(value) != 64:
        return False
    return all(char in "0123456789abcdefABCDEF" for char in value)


def _artifact_key(
    *,
    request_id,
    slug: str,
    packet_type: str,
    artifact_kind: str,
    expected_path: str,
) -> tuple[str, str, str, str, str]:
    return (
        str(request_id or ""),
        str(slug or ""),
        str(packet_type or ""),
        str(artifact_kind or ""),
        str(expected_path or ""),
    )


def _attested_source_artifact_rows(report: dict | None) -> tuple[list[dict], str]:
    if not isinstance(report, dict) or not report:
        return [], "missing"
    rows = report.get("attested_source_artifact_intake_rows")
    if isinstance(rows, list):
        return [dict(row or {}) for row in rows], "remaining_input_autopilot"
    source = report.get("source_artifact_intake")
    if isinstance(source, dict) and isinstance(source.get("rows"), list):
        return [dict(row or {}) for row in source.get("rows") or []], "attestation_manifest"
    return [], "missing"


def _validate_source_artifact_attestations(
    records: list[dict],
    source_artifact_attestation_report: dict | None = None,
) -> dict:
    rows, source = _attested_source_artifact_rows(source_artifact_attestation_report)
    expected_items = []
    for record in records:
        for artifact in (record.get("artifacts") or {}).values():
            if not (artifact or {}).get("expected"):
                continue
            expected_items.append({
                "key": _artifact_key(
                    request_id=record.get("request_id"),
                    slug=record.get("slug") or "",
                    packet_type=record.get("packet_type") or "",
                    artifact_kind=artifact.get("artifact_kind") or "",
                    expected_path=artifact.get("expected_path") or "",
                ),
                "artifact": artifact,
            })

    seen: dict[tuple[str, str, str, str, str], dict] = {}
    duplicate_count = 0
    sha_invalid_count = 0
    metadata_missing_count = 0
    for row in rows:
        key = _artifact_key(
            request_id=row.get("request_id"),
            slug=row.get("slug") or "",
            packet_type=row.get("packet_type") or "",
            artifact_kind=row.get("artifact_kind") or "",
            expected_path=row.get("expected_path") or "",
        )
        if key in seen:
            duplicate_count += 1
        else:
            seen[key] = row
        if not _hex_sha256(row.get("artifact_sha256")):
            sha_invalid_count += 1
        if not (
            str(row.get("provided_by") or "").strip()
            and str(row.get("provided_at") or "").strip()
            and str(row.get("attestation_source") or "").strip()
        ):
            metadata_missing_count += 1

    expected_keys = {item["key"] for item in expected_items}
    unexpected_count = sum(1 for key in seen if key not in expected_keys)
    missing_count = 0
    matched_count = 0
    sha_mismatch_count = 0
    sha_unavailable_count = 0
    first_missing_key = ""
    first_mismatch_key = ""
    for item in expected_items:
        key = item["key"]
        row = seen.get(key)
        if row is None:
            missing_count += 1
            if not first_missing_key:
                first_missing_key = "|".join(key)
            continue
        matched_count += 1
        actual_sha = (item["artifact"] or {}).get("sha256") or ""
        attested_sha = row.get("artifact_sha256") or ""
        if not actual_sha:
            sha_unavailable_count += 1
            continue
        if actual_sha.lower() != str(attested_sha).lower():
            sha_mismatch_count += 1
            if not first_mismatch_key:
                first_mismatch_key = "|".join(key)

    issue_counts = {
        "source_artifact_attestation_missing": missing_count,
        "source_artifact_attestation_unexpected": unexpected_count,
        "source_artifact_attestation_duplicate": duplicate_count,
        "source_artifact_attestation_sha_invalid": sha_invalid_count,
        "source_artifact_attestation_sha_mismatch": sha_mismatch_count,
        "source_artifact_attestation_sha_unavailable": sha_unavailable_count,
        "source_artifact_attestation_metadata_missing": metadata_missing_count,
    }
    issues = [
        f"{name}:{count}"
        for name, count in issue_counts.items()
        if count
    ]
    ready = bool(
        expected_items
        and matched_count == len(expected_items)
        and not issues
    )
    return {
        "ready": ready,
        "source": source,
        "row_count": len(rows),
        "required_count": len(expected_items),
        "matched_count": matched_count,
        "missing_count": missing_count,
        "unexpected_count": unexpected_count,
        "duplicate_count": duplicate_count,
        "sha_invalid_count": sha_invalid_count,
        "sha_mismatch_count": sha_mismatch_count,
        "sha_unavailable_count": sha_unavailable_count,
        "metadata_missing_count": metadata_missing_count,
        "first_missing_key": first_missing_key,
        "first_mismatch_key": first_mismatch_key,
        "issues": issues,
    }


def _source_artifact_attestation_packet_rows(
    report: dict | None,
) -> tuple[list[dict], dict]:
    if not isinstance(report, dict) or not report:
        return [], {}
    packet = report.get("source_artifact_attestation_packet")
    packet = packet if isinstance(packet, dict) else {}
    rows = packet.get("rows")
    if isinstance(rows, list):
        return [dict(row or {}) for row in rows], packet
    return [], packet


def _validate_source_artifact_attestation_checklist(
    records: list[dict],
    real_intake_acceptance_report: dict | None = None,
) -> dict:
    rows, packet = _source_artifact_attestation_packet_rows(
        real_intake_acceptance_report
    )
    summary = _summary(real_intake_acceptance_report)
    expected_items = []
    for record in records:
        for artifact in (record.get("artifacts") or {}).values():
            if not (artifact or {}).get("expected"):
                continue
            expected_items.append(
                {
                    "key": _artifact_key(
                        request_id=record.get("request_id"),
                        slug=record.get("slug") or "",
                        packet_type=record.get("packet_type") or "",
                        artifact_kind=artifact.get("artifact_kind") or "",
                        expected_path=artifact.get("expected_path") or "",
                    ),
                    "artifact": artifact,
                }
            )

    seen: dict[tuple[str, str, str, str, str], dict] = {}
    duplicate_count = 0
    for row in rows:
        key = _artifact_key(
            request_id=row.get("request_id"),
            slug=row.get("slug") or "",
            packet_type=row.get("packet_type") or "",
            artifact_kind=row.get("artifact_kind") or "",
            expected_path=row.get("expected_path") or "",
        )
        if key in seen:
            duplicate_count += 1
        else:
            seen[key] = row

    expected_keys = {item["key"] for item in expected_items}
    unexpected_count = sum(1 for key in seen if key not in expected_keys)
    row_statuses: list[dict] = []
    missing_count = 0
    matched_count = 0
    closure_present_count = 0
    closure_command_present_count = 0
    attestation_row_present_count = 0
    attested_sha_valid_count = 0
    file_present_count = 0
    file_sha_available_count = 0
    sha_match_count = 0
    sha_mismatch_count = 0
    metadata_ready_count = 0
    first_missing_path = ""
    first_open_path = ""
    for item in expected_items:
        key = item["key"]
        artifact = item["artifact"] or {}
        row = seen.get(key)
        expected_path = artifact.get("expected_path") or key[-1]
        if row is None:
            missing_count += 1
            if not first_missing_path:
                first_missing_path = expected_path
            issues = ["checklist_row_missing"]
            row_statuses.append(
                {
                    "row_index": "",
                    "request_id": key[0],
                    "slug": key[1],
                    "packet_type": key[2],
                    "artifact_kind": key[3],
                    "key": "|".join(key),
                    "expected_path": expected_path,
                    "checklist_row_present": False,
                    "ready": False,
                    "issues": issues,
                    "blocking_reason": ";".join(issues),
                    "required_operator_action": (
                        "restore the real-intake source artifact checklist row, "
                        "then provide the real local artifact and filled attestation"
                    ),
                    "manual_boundary": (
                        "local checklist only; do not fabricate source artifacts, "
                        "attestations, provider metadata, uploads, submissions, or external actions"
                    ),
                }
            )
            if not first_open_path:
                first_open_path = expected_path
            continue

        matched_count += 1
        closure_present = _truthy(row.get("closure_row_present"))
        command_present = all(
            str(row.get(name) or "").strip()
            for name in (
                "closure_local_sha256_command",
                "closure_filled_manifest_command",
                "closure_intake_validation_command",
            )
        )
        attestation_present = _truthy(row.get("attestation_row_present"))
        attested_sha = str(row.get("attested_artifact_sha256") or "").strip()
        sha_valid = _hex_sha256(attested_sha)
        actual_sha = str(artifact.get("sha256") or "").strip()
        file_present = bool(artifact.get("nonempty"))
        file_sha_available = bool(actual_sha)
        sha_match = bool(
            file_sha_available
            and sha_valid
            and actual_sha.lower() == attested_sha.lower()
        )
        metadata_ready = bool(
            str(row.get("attested_by") or "").strip()
            and str(row.get("attested_at") or "").strip()
            and str(row.get("attestation_source") or "").strip()
        )

        if closure_present:
            closure_present_count += 1
        if command_present:
            closure_command_present_count += 1
        if attestation_present:
            attestation_row_present_count += 1
        if sha_valid:
            attested_sha_valid_count += 1
        if file_present:
            file_present_count += 1
        if file_sha_available:
            file_sha_available_count += 1
        if sha_match:
            sha_match_count += 1
        if file_sha_available and sha_valid and not sha_match:
            sha_mismatch_count += 1
        if metadata_ready:
            metadata_ready_count += 1

        issues = []
        if not closure_present:
            issues.append("closure_row_missing")
        if not command_present:
            issues.append("closure_command_missing")
        if not file_present:
            issues.append("file_missing")
        if not file_sha_available:
            issues.append("file_sha_unavailable")
        if not attestation_present:
            issues.append("attestation_row_missing")
        if not sha_valid:
            issues.append("attested_sha_invalid")
        if not metadata_ready:
            issues.append("attestation_metadata_missing")
        if file_sha_available and sha_valid and not sha_match:
            issues.append("sha_mismatch")
        if issues and not first_open_path:
            first_open_path = expected_path

        row_statuses.append(
            {
                "row_index": row.get("row_index") or "",
                "request_id": key[0],
                "slug": key[1],
                "packet_type": key[2],
                "artifact_kind": key[3],
                "key": "|".join(key),
                "expected_path": expected_path,
                "checklist_row_present": True,
                "closure_row_present": closure_present,
                "closure_command_present": command_present,
                "file_present": file_present,
                "file_sha_available": file_sha_available,
                "actual_file_sha256": actual_sha,
                "attestation_row_present": attestation_present,
                "attested_artifact_sha256": attested_sha,
                "attested_sha_valid": sha_valid,
                "metadata_ready": metadata_ready,
                "attested_by": str(row.get("attested_by") or ""),
                "attested_at": str(row.get("attested_at") or ""),
                "attestation_source": str(row.get("attestation_source") or ""),
                "sha_match": sha_match,
                "ready": not issues,
                "issues": issues,
                "blocking_reason": ";".join(issues),
                "required_operator_action": (
                    "provide the real local artifact, run the closure sha256 command, "
                    "fill provider/timestamp/source attestation metadata, and rerun "
                    "the intake validation command"
                    if issues
                    else "none"
                ),
                "closure_action_id": row.get("closure_action_id") or "",
                "closure_status": row.get("closure_status") or "",
                "closure_local_sha256_command": (
                    row.get("closure_local_sha256_command") or ""
                ),
                "closure_filled_manifest_command": (
                    row.get("closure_filled_manifest_command") or ""
                ),
                "closure_intake_validation_command": (
                    row.get("closure_intake_validation_command") or ""
                ),
                "manual_boundary": (
                    "local checklist only; do not fabricate source artifacts, "
                    "attestations, provider metadata, uploads, submissions, or external actions"
                ),
            }
        )

    required_count = len(expected_items)
    issue_counts = {
        "checklist_missing": missing_count,
        "checklist_unexpected": unexpected_count,
        "checklist_duplicate": duplicate_count,
        "closure_missing": required_count - closure_present_count,
        "closure_command_missing": required_count - closure_command_present_count,
        "file_missing": required_count - file_present_count,
        "file_sha_unavailable": required_count - file_sha_available_count,
        "attestation_row_missing": required_count - attestation_row_present_count,
        "attested_sha_invalid": required_count - attested_sha_valid_count,
        "sha_mismatch": sha_mismatch_count,
        "sha_not_matched": required_count - sha_match_count,
        "attestation_metadata_missing": required_count - metadata_ready_count,
    }
    issues = [
        f"{name}:{count}"
        for name, count in issue_counts.items()
        if count
    ]
    ready = bool(
        required_count
        and matched_count == required_count
        and not issues
    )
    return {
        "ready": ready,
        "row_count": len(rows),
        "required_count": required_count,
        "matched_count": matched_count,
        "missing_count": missing_count,
        "unexpected_count": unexpected_count,
        "duplicate_count": duplicate_count,
        "closure_present_count": closure_present_count,
        "closure_command_present_count": closure_command_present_count,
        "attestation_row_present_count": attestation_row_present_count,
        "attested_sha_valid_count": attested_sha_valid_count,
        "file_present_count": file_present_count,
        "file_sha_available_count": file_sha_available_count,
        "sha_match_count": sha_match_count,
        "sha_mismatch_count": sha_mismatch_count,
        "metadata_ready_count": metadata_ready_count,
        "first_missing_path": first_missing_path,
        "first_open_path": first_open_path,
        "checklist_csv_path": summary.get(
            "source_artifact_attestation_checklist_csv_path"
        )
        or (packet.get("checklist_csv_artifact") or {}).get("path")
        or "",
        "checklist_csv_sha256": summary.get(
            "source_artifact_attestation_checklist_csv_sha256"
        )
        or (packet.get("checklist_csv_artifact") or {}).get("sha256")
        or "",
        "checklist_csv_row_count": _as_int(
            summary.get("source_artifact_attestation_checklist_csv_row_count")
            or (packet.get("checklist_csv_artifact") or {}).get("row_count")
        ),
        "hash": _stable_hash(
            "source_artifact_attestation_checklist_validation",
            {
                "row_count": len(rows),
                "required_count": required_count,
                "matched_count": matched_count,
                "issues": issues,
                "first_open_path": first_open_path,
                "checklist_csv_sha256": summary.get(
                    "source_artifact_attestation_checklist_csv_sha256"
                )
                or (packet.get("checklist_csv_artifact") or {}).get("sha256")
                or "",
            },
        ),
        "issues": issues,
        "rows": row_statuses,
    }


def _build_source_artifact_attestation_manifest_template(
    label: str,
    checklist_validation: dict,
) -> tuple[dict, list[dict]]:
    validation_rows = [
        dict(row or {})
        for row in (checklist_validation or {}).get("rows") or []
    ]
    fill_rows: list[dict] = []
    manifest_rows: list[dict] = []
    for index, row in enumerate(validation_rows, start=1):
        actual_sha = str(row.get("actual_file_sha256") or "").strip()
        artifact_sha = actual_sha if _hex_sha256(actual_sha) else ""
        base_row = {
            "request_id": str(row.get("request_id") or "").strip(),
            "slug": str(row.get("slug") or "").strip(),
            "packet_type": str(row.get("packet_type") or "").strip(),
            "artifact_kind": str(row.get("artifact_kind") or "").strip(),
            "expected_path": str(row.get("expected_path") or "").strip(),
            "artifact_sha256": artifact_sha,
            "provided_by": "",
            "provided_at": "",
            "attestation_source": "",
            "notes": "",
        }
        expected_path = base_row["expected_path"]
        local_sha256_command = (
            row.get("closure_local_sha256_command")
            or (f"sha256sum {expected_path}" if expected_path else "")
        )
        filled_manifest_command = (
            row.get("closure_filled_manifest_command")
            or (
                "./bin/paperctl paper-production-remaining-input-autopilot "
                f"--label {label} --attestation-manifest "
                "'<filled-remaining-input-attestation.json>' --write --json"
            )
        )
        intake_validation_command = (
            row.get("closure_intake_validation_command")
            or (
                "./bin/paperctl "
                "paper-production-referee-repair-source-artifact-intake-queue "
                f"--label {label} --attestation-manifest "
                "'<filled-remaining-input-attestation.json>' --write --json"
            )
        )
        manifest_rows.append(dict(base_row))
        fill_rows.append(
            {
                "row_index": index,
                **base_row,
                "blocking_reason": row.get("blocking_reason") or "",
                "required_operator_action": row.get("required_operator_action")
                or "",
                "local_sha256_command": local_sha256_command,
                "filled_manifest_command": filled_manifest_command,
                "intake_validation_command": intake_validation_command,
                "source_validation_closure_row_index": row.get("row_index")
                or "",
                "source_validation_closure_ready": bool(row.get("ready")),
                "manual_boundary": (
                    "fill only from real local artifact files and real provider/"
                    "timestamp/source attestations; do not fabricate artifacts, "
                    "metadata, uploads, submissions, or external actions"
                ),
            }
        )

    template_hash = _stable_hash(
        "source_artifact_attestation_manifest_template",
        {
            "label": label,
            "rows": manifest_rows,
            "checklist_hash": (checklist_validation or {}).get("hash") or "",
        },
    )
    template = {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_attestation_manifest_fill_template.v1"
        ),
        "label": label,
        "generated_at": "",
        "template_hash": template_hash,
        "source_artifact_intake": {
            "required_row_count": len(manifest_rows),
            "rows": manifest_rows,
        },
        "operator_instructions": [
            "For each row, provide the real local artifact at expected_path.",
            "Run the local sha256 command from the fill template and copy only the observed SHA256 into artifact_sha256.",
            "Fill provided_by, provided_at, and attestation_source from real reviewer/operator provenance.",
            "Run paper-production-remaining-input-autopilot with the filled JSON manifest, then rerun source-artifact intake.",
        ],
        "source_validation_closure": {
            "checklist_hash": (checklist_validation or {}).get("hash") or "",
            "required_row_count": (checklist_validation or {}).get(
                "required_count",
                0,
            ),
            "matched_row_count": (checklist_validation or {}).get(
                "matched_count",
                0,
            ),
            "file_present_count": (checklist_validation or {}).get(
                "file_present_count",
                0,
            ),
            "attestation_row_present_count": (checklist_validation or {}).get(
                "attestation_row_present_count",
                0,
            ),
            "sha_match_count": (checklist_validation or {}).get(
                "sha_match_count",
                0,
            ),
            "metadata_ready_count": (checklist_validation or {}).get(
                "metadata_ready_count",
                0,
            ),
            "issues": list((checklist_validation or {}).get("issues") or []),
        },
        "boundary": {
            "local_template_only": True,
            "creates_source_artifacts": False,
            "creates_attestation_metadata": False,
            "authorizes_external_action": False,
            "performs_upload": False,
            "performs_submission": False,
        },
    }
    return template, fill_rows


def _source_artifact_attestation_group_closure_rows(
    label: str,
    checklist_validation: dict,
) -> list[dict]:
    rows = [dict(row or {}) for row in (checklist_validation or {}).get("rows") or []]
    groups: dict[tuple[str, str, str], list[dict]] = {}
    group_order: list[tuple[str, str, str]] = []
    for row in rows:
        key = (
            str(row.get("request_id") or "").strip(),
            str(row.get("slug") or "").strip(),
            str(row.get("packet_type") or "").strip(),
        )
        if key not in groups:
            groups[key] = []
            group_order.append(key)
        groups[key].append(row)

    artifact_order = ["source_packet", "operator_intake_packet", "redrive_receipt"]
    group_rows: list[dict] = []
    for index, key in enumerate(group_order, start=1):
        request_id, slug, packet_type = key
        artifacts = groups[key]
        by_kind = {
            str(row.get("artifact_kind") or "").strip(): row for row in artifacts
        }
        expected_paths = [
            str(by_kind.get(kind, {}).get("expected_path") or "").strip()
            for kind in artifact_order
        ]
        present_count = sum(1 for row in artifacts if _truthy(row.get("file_present")))
        attestation_row_count = sum(
            1 for row in artifacts if _truthy(row.get("attestation_row_present"))
        )
        metadata_ready_count = sum(
            1 for row in artifacts if _truthy(row.get("metadata_ready"))
        )
        ready = bool(
            artifacts
            and all(_truthy(row.get("ready")) for row in artifacts)
            and present_count == len(artifacts)
            and attestation_row_count == len(artifacts)
            and metadata_ready_count == len(artifacts)
        )
        reasons: list[str] = []
        for row in artifacts:
            for reason in str(row.get("blocking_reason") or "").split(";"):
                reason = reason.strip()
                if reason and reason not in reasons:
                    reasons.append(reason)
        expected_dir = ""
        for path_text in expected_paths:
            if path_text:
                expected_dir = str(Path(path_text).parent)
                break
        sha_commands = [
            str(row.get("closure_local_sha256_command") or "").strip()
            for row in artifacts
            if str(row.get("closure_local_sha256_command") or "").strip()
        ]
        filled_manifest_command = next(
            (
                str(row.get("closure_filled_manifest_command") or "").strip()
                for row in artifacts
                if str(row.get("closure_filled_manifest_command") or "").strip()
            ),
            (
                "./bin/paperctl paper-production-remaining-input-autopilot "
                f"--label {label} --attestation-manifest "
                "'<filled-remaining-input-attestation.json>' --write --json"
            ),
        )
        intake_validation_command = next(
            (
                str(row.get("closure_intake_validation_command") or "").strip()
                for row in artifacts
                if str(row.get("closure_intake_validation_command") or "").strip()
            ),
            (
                "./bin/paperctl "
                "paper-production-referee-repair-source-artifact-intake-queue "
                f"--label {label} --attestation-manifest "
                "'<filled-remaining-input-attestation.json>' --write --json"
            ),
        )
        group_rows.append(
            {
                "group_index": index,
                "request_id": request_id,
                "slug": slug,
                "packet_type": packet_type,
                "ready": ready,
                "expected_artifact_count": len(artifacts),
                "present_artifact_count": present_count,
                "missing_artifact_count": max(len(artifacts) - present_count, 0),
                "attestation_row_present_count": attestation_row_count,
                "metadata_ready_count": metadata_ready_count,
                "source_packet_path": expected_paths[0],
                "operator_intake_packet_path": expected_paths[1],
                "redrive_receipt_path": expected_paths[2],
                "blocking_reason": ";".join(reasons),
                "required_operator_action": (
                    "provide the three real local artifacts for this request/"
                    "packet group, fill matching SHA/provider/timestamp/source "
                    "attestation rows, then rerun the validation command"
                ),
                "mkdir_command": f"mkdir -p {expected_dir}" if expected_dir else "",
                "local_sha256_commands": " && ".join(sha_commands),
                "filled_manifest_command": filled_manifest_command,
                "intake_validation_command": intake_validation_command,
                "manual_boundary": (
                    "local grouped checklist only; do not fabricate source "
                    "artifacts, attestation metadata, uploads, submissions, or "
                    "external actions"
                ),
            }
        )
    return group_rows


def _rel_path(root: Path, path: Path) -> str:
    try:
        return str(path.relative_to(root))
    except ValueError:
        return str(path)


def _shell_join(parts: list[str]) -> str:
    return " ".join(shlex.quote(str(part)) for part in parts)


def _expected_candidate_items(records: list[dict]) -> list[dict]:
    items: list[dict] = []
    for record in records:
        for artifact in (record.get("artifacts") or {}).values():
            if not (artifact or {}).get("expected"):
                continue
            expected_path = str(artifact.get("expected_path") or "")
            items.append(
                {
                    "request_id": str(record.get("request_id") or ""),
                    "slug": str(record.get("slug") or ""),
                    "packet_type": str(record.get("packet_type") or ""),
                    "artifact_kind": str(artifact.get("artifact_kind") or ""),
                    "expected_path": expected_path,
                    "expected_basename": Path(expected_path).name,
                    "expected_present": bool(artifact.get("nonempty")),
                }
            )
    return items


def _source_artifact_local_candidate_discovery(
    *,
    root: Path,
    label: str,
    records: list[dict],
) -> dict:
    items = _expected_candidate_items(records)
    missing_items = [item for item in items if not item.get("expected_present")]
    expected_basenames = {
        item.get("expected_basename")
        for item in missing_items
        if item.get("expected_basename")
    }
    request_tokens = {
        f"request-{item.get('request_id')}".lower()
        for item in missing_items
        if item.get("request_id")
    }
    scan_roots = []
    for rel_root in LOCAL_CANDIDATE_SCAN_ROOTS:
        path = root / rel_root
        if path.exists() and path.is_dir():
            scan_roots.append(path)

    candidate_index: dict[str, list[Path]] = {name: [] for name in expected_basenames}
    request_index: dict[str, list[Path]] = {token: [] for token in request_tokens}
    seen_paths: set[str] = set()
    scanned_file_count = 0
    scan_complete = True
    for scan_root in scan_roots:
        for path in scan_root.rglob("*.json"):
            if scanned_file_count >= LOCAL_CANDIDATE_SCAN_MAX_FILES:
                scan_complete = False
                break
            if not path.is_file() or path.is_symlink():
                continue
            resolved_key = str(path)
            if resolved_key in seen_paths:
                continue
            seen_paths.add(resolved_key)
            scanned_file_count += 1
            if path.name in candidate_index:
                candidate_index[path.name].append(path)
            rel_text_lower = _rel_path(root, path).lower()
            for token in request_tokens:
                if token in rel_text_lower:
                    request_index[token].append(path)
        if not scan_complete:
            break

    rows = []
    total_candidate_count = 0
    first_unresolved_path = ""
    first_candidate_path = ""
    scan_root_text = ";".join(_rel_path(root, item) for item in scan_roots)
    for index, item in enumerate(items, start=1):
        expected_path = item.get("expected_path") or ""
        expected_basename = item.get("expected_basename") or ""
        request_token = f"request-{item.get('request_id')}".lower()
        raw_candidates: list[Path] = []
        raw_candidates.extend(candidate_index.get(expected_basename, []))
        raw_candidates.extend(request_index.get(request_token, []))
        candidates = []
        seen_candidate_paths: set[str] = set()
        for candidate_path in raw_candidates:
            rel_candidate = _rel_path(root, candidate_path)
            if rel_candidate == expected_path or rel_candidate in seen_candidate_paths:
                continue
            seen_candidate_paths.add(rel_candidate)
            lower = rel_candidate.lower()
            reasons = []
            score = 0
            if candidate_path.name == expected_basename:
                score += 100
                reasons.append("basename_match")
            if request_token and request_token in lower:
                score += 40
                reasons.append("request_token_match")
            packet_type = str(item.get("packet_type") or "").lower()
            if packet_type and packet_type.replace("_", "-") in lower:
                score += 20
                reasons.append("packet_type_match")
            if packet_type and packet_type.replace("_", "_") in lower:
                score += 20
                reasons.append("packet_type_match")
            artifact_kind = str(item.get("artifact_kind") or "").lower()
            if artifact_kind and artifact_kind in lower:
                score += 10
                reasons.append("artifact_kind_match")
            if score < 80:
                continue
            candidates.append((score, rel_candidate, candidate_path, reasons))
        candidates.sort(key=lambda value: (-value[0], value[1]))
        candidates = candidates[:LOCAL_CANDIDATE_MAX_PER_ROW]
        candidate_count = len(candidates)
        total_candidate_count += candidate_count
        best_path = ""
        best_score = 0
        best_reason = ""
        best_size = 0
        best_sha = ""
        if candidates:
            best_score, best_path, best_abs_path, best_reasons = candidates[0]
            best_reason = ";".join(best_reasons)
            try:
                best_size = best_abs_path.stat().st_size
                if best_size <= MAX_ARTIFACT_BYTES:
                    best_sha, _stable = _sha256_file(best_abs_path)
            except Exception:
                best_size = 0
                best_sha = ""
            if not first_candidate_path:
                first_candidate_path = best_path
        elif not item.get("expected_present") and not first_unresolved_path:
            first_unresolved_path = expected_path

        expected_parent = str(Path(expected_path).parent) if expected_path else ""
        copy_command = ""
        if best_path and expected_path:
            copy_command = (
                f"{_shell_join(['mkdir', '-p', expected_parent])} && "
                f"{_shell_join(['cp', '--', best_path, expected_path])}"
            )
        rows.append(
            {
                "row_index": index,
                "request_id": item.get("request_id") or "",
                "slug": item.get("slug") or "",
                "packet_type": item.get("packet_type") or "",
                "artifact_kind": item.get("artifact_kind") or "",
                "expected_path": expected_path,
                "expected_basename": expected_basename,
                "expected_present": bool(item.get("expected_present")),
                "candidate_count": candidate_count,
                "best_candidate_path": best_path,
                "best_candidate_score": best_score,
                "best_candidate_reason": best_reason,
                "best_candidate_byte_count": best_size,
                "best_candidate_sha256": best_sha,
                "copy_candidate_command": copy_command,
                "local_sha256_command": (
                    _shell_join(["sha256sum", expected_path])
                    if expected_path
                    else ""
                ),
                "intake_validation_command": (
                    "./bin/paperctl "
                    "paper-production-referee-repair-source-artifact-intake-queue "
                    f"--label {label} --write --json"
                ),
                "scan_roots": scan_root_text,
                "scan_complete": scan_complete,
                "manual_boundary": (
                    "candidate discovery only; review provenance before copying; "
                    "do not treat candidates as evidence until expected_path, "
                    "sha256, provider, timestamp, and source attestation validate"
                ),
            }
        )

    with_candidates_count = sum(
        1 for row in rows if _as_int(row.get("candidate_count")) > 0
    )
    discovery_hash = _stable_hash(
        "source_artifact_local_candidate_discovery",
        {
            "label": label,
            "scan_roots": scan_root_text,
            "scanned_file_count": scanned_file_count,
            "scan_complete": scan_complete,
            "rows": [
                {
                    "expected_path": row.get("expected_path"),
                    "candidate_count": row.get("candidate_count"),
                    "best_candidate_path": row.get("best_candidate_path"),
                    "best_candidate_sha256": row.get("best_candidate_sha256"),
                }
                for row in rows
            ],
        },
    )
    return {
        "ready": bool(rows),
        "expected_count": len(rows),
        "candidate_count": total_candidate_count,
        "with_candidates_count": with_candidates_count,
        "first_unresolved_path": first_unresolved_path,
        "first_candidate_path": first_candidate_path,
        "scanned_file_count": scanned_file_count,
        "scan_roots": scan_root_text,
        "scan_complete": scan_complete,
        "hash": discovery_hash,
        "rows": rows,
    }


def _source_artifact_round_trip_status_packet(
    *,
    label: str,
    checklist_validation: dict,
) -> dict:
    validation_rows = [
        dict(row or {})
        for row in (checklist_validation or {}).get("rows") or []
    ]
    rows: list[dict] = []
    for index, row in enumerate(validation_rows, start=1):
        expected_path = str(row.get("expected_path") or "").strip()
        file_present = _truthy(row.get("file_present"))
        file_sha_available = _truthy(row.get("file_sha_available"))
        attestation_row_present = _truthy(row.get("attestation_row_present"))
        attested_sha_valid = _truthy(row.get("attested_sha_valid"))
        sha_match = _truthy(row.get("sha_match"))
        metadata_ready = _truthy(row.get("metadata_ready"))
        closure_row_present = _truthy(row.get("closure_row_present"))
        closure_command_present = _truthy(row.get("closure_command_present"))
        checklist_row_present = _truthy(row.get("checklist_row_present"))
        local_ready = bool(file_present and file_sha_available)
        attestation_ready = bool(
            attestation_row_present
            and attested_sha_valid
            and sha_match
            and metadata_ready
        )
        shape_ready = bool(
            local_ready
            and attestation_ready
            and closure_row_present
            and closure_command_present
        )
        blocking_reason = str(row.get("blocking_reason") or "").strip()
        if not blocking_reason and not shape_ready:
            reasons = []
            if not file_present:
                reasons.append("file_missing")
            if file_present and not file_sha_available:
                reasons.append("file_sha_unavailable")
            if not attestation_row_present:
                reasons.append("attestation_row_missing")
            if attestation_row_present and not attested_sha_valid:
                reasons.append("attested_sha_invalid")
            if attested_sha_valid and not sha_match:
                reasons.append("sha_mismatch")
            if not metadata_ready:
                reasons.append("attestation_metadata_missing")
            if not closure_row_present:
                reasons.append("closure_row_missing")
            if not closure_command_present:
                reasons.append("closure_command_missing")
            blocking_reason = ";".join(reasons)

        rows.append(
            {
                "row_index": row.get("row_index") or index,
                "request_id": row.get("request_id") or "",
                "slug": row.get("slug") or "",
                "packet_type": row.get("packet_type") or "",
                "artifact_kind": row.get("artifact_kind") or "",
                "expected_path": expected_path,
                "local_ready": local_ready,
                "file_present": file_present,
                "file_sha_available": file_sha_available,
                "actual_file_sha256": row.get("actual_file_sha256") or "",
                "attestation_ready": attestation_ready,
                "attestation_row_present": attestation_row_present,
                "attested_artifact_sha256": (
                    row.get("attested_artifact_sha256") or ""
                ),
                "attested_sha_valid": attested_sha_valid,
                "sha_match": sha_match,
                "metadata_ready": metadata_ready,
                "shape_ready": shape_ready,
                "checklist_row_present": checklist_row_present,
                "closure_row_present": closure_row_present,
                "closure_command_present": closure_command_present,
                "blocking_reason": blocking_reason,
                "required_operator_action": (
                    row.get("required_operator_action")
                    or (
                        "provide the real local source artifact, compute SHA256, "
                        "fill matching provider/timestamp/source attestation, "
                        "then rerun source-artifact intake"
                        if not shape_ready
                        else "none"
                    )
                ),
                "local_sha256_command": (
                    row.get("closure_local_sha256_command")
                    or (_shell_join(["sha256sum", expected_path]) if expected_path else "")
                ),
                "filled_manifest_command": (
                    row.get("closure_filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    row.get("closure_intake_validation_command")
                    or (
                        "./bin/paperctl "
                        "paper-production-referee-repair-source-artifact-intake-queue "
                        f"--label {label} --write --json"
                    )
                ),
                "attested_by": row.get("attested_by") or "",
                "attested_at": row.get("attested_at") or "",
                "attestation_source": row.get("attestation_source") or "",
                "manual_boundary": (
                    "local source-artifact round-trip status only; this does "
                    "not create artifacts, import attestations, approve evidence, "
                    "upload, submit, or perform external actions"
                ),
            }
        )

    unready_rows = [row for row in rows if not row.get("shape_ready")]
    local_ready_count = sum(1 for row in rows if row.get("local_ready"))
    missing_count = sum(1 for row in rows if not row.get("file_present"))
    attestation_ready_count = sum(1 for row in rows if row.get("attestation_ready"))
    metadata_ready_count = sum(1 for row in rows if row.get("metadata_ready"))
    shape_ready_count = sum(1 for row in rows if row.get("shape_ready"))
    status_hash = _stable_hash(
        "source_artifact_round_trip_status_packet",
        {
            "label": label,
            "checklist_hash": (checklist_validation or {}).get("hash") or "",
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "local_ready": bool(row.get("local_ready")),
                    "attestation_ready": bool(row.get("attestation_ready")),
                    "shape_ready": bool(row.get("shape_ready")),
                    "blocking_reason": row.get("blocking_reason") or "",
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_round_trip_status_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows),
        "round_trip_status_state": (
            "SOURCE_ARTIFACT_ROUND_TRIP_LOCAL_READY"
            if rows and shape_ready_count == len(rows)
            else "SOURCE_ARTIFACT_ROUND_TRIP_OPEN"
        ),
        "row_count": len(rows),
        "local_ready_count": local_ready_count,
        "missing_count": missing_count,
        "attestation_ready_count": attestation_ready_count,
        "attestation_missing_count": max(
            len(rows) - attestation_ready_count,
            0,
        ),
        "metadata_ready_count": metadata_ready_count,
        "shape_ready_count": shape_ready_count,
        "first_unready_path": (
            unready_rows[0].get("expected_path") if unready_rows else ""
        ),
        "status_hash": status_hash if rows else "",
        "rows": rows,
        "sidecar_refs": {},
        "boundary": {
            "local_round_trip_status_only": True,
            "status_is_not_evidence_acceptance": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_round_trip_action_packet(
    *,
    label: str,
    status_packet: dict,
    local_candidate_discovery: dict,
    attestation_manifest_template_rows: list[dict],
) -> dict:
    status_rows = [
        dict(row or {})
        for row in (status_packet or {}).get("rows") or []
    ]
    candidate_by_path = {
        str(row.get("expected_path") or "").strip(): dict(row or {})
        for row in (local_candidate_discovery or {}).get("rows") or []
        if str((row or {}).get("expected_path") or "").strip()
    }
    template_by_path = {
        str(row.get("expected_path") or "").strip(): dict(row or {})
        for row in attestation_manifest_template_rows or []
        if str((row or {}).get("expected_path") or "").strip()
    }
    rows: list[dict] = []
    for index, status_row in enumerate(status_rows, start=1):
        expected_path = str(status_row.get("expected_path") or "").strip()
        candidate_row = candidate_by_path.get(expected_path, {})
        template_row = template_by_path.get(expected_path, {})
        shape_ready = _truthy(status_row.get("shape_ready"))
        request_id = str(status_row.get("request_id") or "").strip()
        packet_type = str(status_row.get("packet_type") or "").strip()
        artifact_kind = str(status_row.get("artifact_kind") or "").strip()
        action_id_parts = [
            "source_artifact_round_trip",
            str(index),
            request_id,
            packet_type,
            artifact_kind,
        ]
        rows.append(
            {
                "row_index": index,
                "action_id": ":".join(
                    part for part in action_id_parts if part
                ),
                "action_status": "READY" if shape_ready else "OPEN",
                "request_id": request_id,
                "slug": status_row.get("slug") or "",
                "packet_type": packet_type,
                "artifact_kind": artifact_kind,
                "expected_path": expected_path,
                "local_ready": _truthy(status_row.get("local_ready")),
                "attestation_ready": _truthy(
                    status_row.get("attestation_ready")
                ),
                "shape_ready": shape_ready,
                "blocking_reason": status_row.get("blocking_reason") or "",
                "required_operator_action": (
                    "none"
                    if shape_ready
                    else (
                        status_row.get("required_operator_action")
                        or "provide real source artifact and matching attestation"
                    )
                ),
                "candidate_count": _as_int(candidate_row.get("candidate_count")),
                "best_candidate_path": (
                    candidate_row.get("best_candidate_path") or ""
                ),
                "best_candidate_sha256": (
                    candidate_row.get("best_candidate_sha256") or ""
                ),
                "copy_candidate_command": (
                    candidate_row.get("copy_candidate_command") or ""
                ),
                "artifact_sha256": template_row.get("artifact_sha256") or "",
                "provided_by": template_row.get("provided_by") or "",
                "provided_at": template_row.get("provided_at") or "",
                "attestation_source": (
                    template_row.get("attestation_source") or ""
                ),
                "local_sha256_command": (
                    status_row.get("local_sha256_command")
                    or template_row.get("local_sha256_command")
                    or (
                        _shell_join(["sha256sum", expected_path])
                        if expected_path
                        else ""
                    )
                ),
                "filled_manifest_command": (
                    template_row.get("filled_manifest_command")
                    or status_row.get("filled_manifest_command")
                    or ""
                ),
                "intake_validation_command": (
                    status_row.get("intake_validation_command")
                    or template_row.get("intake_validation_command")
                    or (
                        "./bin/paperctl "
                        "paper-production-referee-repair-source-artifact-intake-queue "
                        f"--label {label} --write --json"
                    )
                ),
                "status_row_index": status_row.get("row_index") or "",
                "attestation_template_row_index": (
                    template_row.get("row_index") or ""
                ),
                "validation_closure_row_index": (
                    template_row.get("source_validation_closure_row_index")
                    or status_row.get("row_index")
                    or ""
                ),
                "manual_boundary": (
                    "operator work package only; review any candidate before "
                    "copying; fill attestation only from real local artifacts "
                    "and real provenance; this does not create evidence, "
                    "approve, upload, submit, or perform external actions"
                ),
            }
        )

    open_rows = [row for row in rows if row.get("action_status") != "READY"]
    candidate_count = sum(_as_int(row.get("candidate_count")) for row in rows)
    with_candidates_count = sum(
        1 for row in rows if _as_int(row.get("candidate_count")) > 0
    )
    action_hash = _stable_hash(
        "source_artifact_round_trip_action_packet",
        {
            "label": label,
            "status_hash": (status_packet or {}).get("status_hash") or "",
            "candidate_hash": (
                (local_candidate_discovery or {}).get("hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "action_status": row.get("action_status") or "",
                    "blocking_reason": row.get("blocking_reason") or "",
                    "candidate_count": row.get("candidate_count") or 0,
                    "best_candidate_path": (
                        row.get("best_candidate_path") or ""
                    ),
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_round_trip_action_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows),
        "round_trip_action_state": (
            "SOURCE_ARTIFACT_ROUND_TRIP_ACTIONS_READY"
            if rows and not open_rows
            else "SOURCE_ARTIFACT_ROUND_TRIP_ACTIONS_OPEN"
        ),
        "row_count": len(rows),
        "open_count": len(open_rows),
        "candidate_count": candidate_count,
        "with_candidates_count": with_candidates_count,
        "first_open_path": (
            open_rows[0].get("expected_path") if open_rows else ""
        ),
        "action_hash": action_hash if rows else "",
        "rows": rows,
        "sidecar_refs": {},
        "boundary": {
            "operator_work_package_only": True,
            "action_packet_is_not_evidence_acceptance": True,
            "does_not_copy_candidates": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_authoring_work_order_manifest(
    *,
    label: str,
    group_closure_rows: list[dict],
    local_candidate_rows: list[dict],
    round_trip_action_rows: list[dict],
) -> dict:
    candidate_by_path = {
        str(row.get("expected_path") or "").strip(): dict(row or {})
        for row in local_candidate_rows or []
        if str((row or {}).get("expected_path") or "").strip()
    }
    action_by_path = {
        str(row.get("expected_path") or "").strip(): dict(row or {})
        for row in round_trip_action_rows or []
        if str((row or {}).get("expected_path") or "").strip()
    }
    rows: list[dict] = []
    for index, group_row in enumerate(group_closure_rows or [], start=1):
        request_id = str(group_row.get("request_id") or "").strip()
        slug = str(group_row.get("slug") or "").strip()
        packet_type = str(group_row.get("packet_type") or "").strip()
        paths = [
            str(group_row.get("source_packet_path") or "").strip(),
            str(group_row.get("operator_intake_packet_path") or "").strip(),
            str(group_row.get("redrive_receipt_path") or "").strip(),
        ]
        action_rows = [action_by_path.get(path, {}) for path in paths if path]
        candidate_rows = [candidate_by_path.get(path, {}) for path in paths if path]
        ready_artifact_count = sum(
            1 for row in action_rows if str(row.get("action_status") or "") == "READY"
        )
        candidate_count = sum(
            _as_int(row.get("candidate_count")) for row in candidate_rows
        )
        candidate_hit_count = sum(
            1 for row in candidate_rows if _as_int(row.get("candidate_count")) > 0
        )
        first_missing_path = next(
            (
                str(row.get("expected_path") or "").strip()
                for row in action_rows
                if str(row.get("action_status") or "") != "READY"
            ),
            "",
        )
        if not first_missing_path:
            first_missing_path = next((path for path in paths if path), "")
        first_candidate_path = next(
            (
                str(row.get("best_candidate_path") or "").strip()
                for row in candidate_rows
                if str(row.get("best_candidate_path") or "").strip()
            ),
            "",
        )
        copy_candidate_commands = [
            str(row.get("copy_candidate_command") or "").strip()
            for row in action_rows
            if str(row.get("copy_candidate_command") or "").strip()
        ]
        group_ready = _truthy(group_row.get("ready"))
        rows.append(
            {
                "work_order_index": index,
                "work_order_id": ":".join(
                    part
                    for part in (
                        "source_artifact_authoring_work_order",
                        request_id,
                        packet_type,
                    )
                    if part
                ),
                "work_order_status": "READY" if group_ready else "OPEN",
                "request_id": request_id,
                "slug": slug,
                "packet_type": packet_type,
                "expected_artifact_count": _as_int(
                    group_row.get("expected_artifact_count")
                ),
                "ready_artifact_count": ready_artifact_count,
                "missing_artifact_count": _as_int(
                    group_row.get("missing_artifact_count")
                ),
                "candidate_count": candidate_count,
                "candidate_hit_count": candidate_hit_count,
                "attestation_row_present_count": _as_int(
                    group_row.get("attestation_row_present_count")
                ),
                "metadata_ready_count": _as_int(
                    group_row.get("metadata_ready_count")
                ),
                "source_packet_path": paths[0] if len(paths) > 0 else "",
                "operator_intake_packet_path": paths[1] if len(paths) > 1 else "",
                "redrive_receipt_path": paths[2] if len(paths) > 2 else "",
                "first_missing_path": "" if group_ready else first_missing_path,
                "first_candidate_path": first_candidate_path,
                "mkdir_command": group_row.get("mkdir_command") or "",
                "local_sha256_commands": (
                    group_row.get("local_sha256_commands") or ""
                ),
                "copy_candidate_commands": " && ".join(copy_candidate_commands),
                "filled_manifest_command": (
                    group_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    group_row.get("intake_validation_command")
                    or (
                        "./bin/paperctl "
                        "paper-production-referee-repair-source-artifact-intake-queue "
                        f"--label {label} --write --json"
                    )
                ),
                "blocking_reason": (
                    ""
                    if group_ready
                    else (
                        group_row.get("blocking_reason")
                        or "source_artifact_group_not_ready"
                    )
                ),
                "required_operator_action": (
                    "none"
                    if group_ready
                    else (
                        group_row.get("required_operator_action")
                        or (
                            "provide the real source packet, operator intake "
                            "packet, redrive receipt, and matching attestation rows"
                        )
                    )
                ),
                "manual_boundary": (
                    "request-level operator work order only; candidates are "
                    "not evidence; do not fabricate source artifacts, "
                    "attestation metadata, uploads, submissions, approvals, "
                    "or external actions"
                ),
            }
        )

    open_rows = [row for row in rows if row.get("work_order_status") != "READY"]
    ready_rows = [row for row in rows if row.get("work_order_status") == "READY"]
    manifest_hash = _stable_hash(
        "source_artifact_authoring_work_order_manifest",
        {
            "label": label,
            "rows": [
                {
                    "work_order_id": row.get("work_order_id") or "",
                    "work_order_status": row.get("work_order_status") or "",
                    "missing_artifact_count": row.get("missing_artifact_count") or 0,
                    "candidate_count": row.get("candidate_count") or 0,
                    "first_missing_path": row.get("first_missing_path") or "",
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_authoring_work_order_manifest.v1"
        ),
        "label": label,
        "manifest_ready": bool(rows) and not open_rows,
        "work_order_manifest_state": (
            "SOURCE_ARTIFACT_AUTHORING_WORK_ORDERS_READY"
            if rows and not open_rows
            else "SOURCE_ARTIFACT_AUTHORING_WORK_ORDERS_OPEN"
        ),
        "row_count": len(rows),
        "open_count": len(open_rows),
        "ready_count": len(ready_rows),
        "missing_artifact_count": sum(
            _as_int(row.get("missing_artifact_count")) for row in rows
        ),
        "candidate_count": sum(_as_int(row.get("candidate_count")) for row in rows),
        "with_candidates_count": sum(
            1 for row in rows if _as_int(row.get("candidate_count")) > 0
        ),
        "first_open_path": (
            open_rows[0].get("first_missing_path") if open_rows else ""
        ),
        "manifest_hash": manifest_hash if rows else "",
        "rows": rows,
        "sidecar_refs": {},
        "boundary": {
            "request_level_work_order_only": True,
            "candidate_paths_are_not_evidence": True,
            "does_not_copy_candidates": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_work_order_attestation_manifest_bridge(
    *,
    label: str,
    work_order_rows: list[dict],
    attestation_manifest_template_rows: list[dict],
    round_trip_status_rows: list[dict],
) -> dict:
    artifact_fields = [
        ("source_packet", "source_packet_path"),
        ("operator_intake_packet", "operator_intake_packet_path"),
        ("redrive_receipt", "redrive_receipt_path"),
    ]

    def key_for(row: dict, artifact_kind: str | None = None, path: str | None = None):
        return (
            str(row.get("request_id") or "").strip(),
            str(row.get("slug") or "").strip(),
            str(row.get("packet_type") or "").strip(),
            str(artifact_kind if artifact_kind is not None else row.get("artifact_kind") or "").strip(),
            str(path if path is not None else row.get("expected_path") or "").strip(),
        )

    template_by_key = {
        key_for(row): dict(row or {})
        for row in attestation_manifest_template_rows or []
        if any(key_for(row))
    }
    status_by_key = {
        key_for(row): dict(row or {})
        for row in round_trip_status_rows or []
        if any(key_for(row))
    }
    expected_keys: set[tuple[str, str, str, str, str]] = set()
    rows: list[dict] = []

    for index, work_order in enumerate(work_order_rows or [], start=1):
        expected_count = 0
        template_count = 0
        status_count = 0
        checklist_count = 0
        local_ready_count = 0
        attestation_ready_count = 0
        shape_ready_count = 0
        unmatched_template_kinds: list[str] = []
        unmatched_status_kinds: list[str] = []
        open_paths: list[str] = []

        for artifact_kind, path_field in artifact_fields:
            expected_path = str(work_order.get(path_field) or "").strip()
            if not expected_path:
                continue
            expected_count += 1
            key = key_for(work_order, artifact_kind, expected_path)
            expected_keys.add(key)
            template_row = template_by_key.get(key)
            status_row = status_by_key.get(key)
            if template_row:
                template_count += 1
            else:
                unmatched_template_kinds.append(artifact_kind)
            if status_row:
                status_count += 1
            else:
                unmatched_status_kinds.append(artifact_kind)
            if status_row and _truthy(status_row.get("checklist_row_present")):
                checklist_count += 1
            if status_row and _truthy(status_row.get("local_ready")):
                local_ready_count += 1
            if status_row and _truthy(status_row.get("attestation_ready")):
                attestation_ready_count += 1
            if status_row and _truthy(status_row.get("shape_ready")):
                shape_ready_count += 1
            if not status_row or not _truthy(status_row.get("shape_ready")):
                open_paths.append(expected_path)

        bridge_ready = bool(
            expected_count
            and template_count == expected_count
            and status_count == expected_count
            and checklist_count == expected_count
        )
        blocking_reasons = []
        if not expected_count:
            blocking_reasons.append("work_order_expected_paths_missing")
        if template_count != expected_count:
            blocking_reasons.append("attestation_manifest_template_rows_not_bound")
        if status_count != expected_count:
            blocking_reasons.append("round_trip_status_rows_not_bound")
        if checklist_count != expected_count:
            blocking_reasons.append("real_intake_checklist_rows_not_bound")
        work_order_open = str(work_order.get("work_order_status") or "") != "READY"
        if work_order_open:
            blocking_reasons.append("source_artifact_work_order_open")
        first_open_path = (
            work_order.get("first_missing_path")
            or (open_paths[0] if open_paths else "")
        )
        rows.append(
            {
                "bridge_index": index,
                "work_order_id": work_order.get("work_order_id") or "",
                "work_order_status": work_order.get("work_order_status") or "",
                "request_id": work_order.get("request_id") or "",
                "slug": work_order.get("slug") or "",
                "packet_type": work_order.get("packet_type") or "",
                "bridge_ready": bridge_ready,
                "expected_artifact_count": expected_count,
                "manifest_template_row_count": template_count,
                "round_trip_status_row_count": status_count,
                "real_intake_checklist_row_count": checklist_count,
                "local_ready_count": local_ready_count,
                "attestation_ready_count": attestation_ready_count,
                "shape_ready_count": shape_ready_count,
                "missing_artifact_count": _as_int(
                    work_order.get("missing_artifact_count")
                ),
                "unmatched_manifest_artifact_kinds": ";".join(
                    unmatched_template_kinds
                ),
                "unmatched_status_artifact_kinds": ";".join(
                    unmatched_status_kinds
                ),
                "source_packet_path": work_order.get("source_packet_path") or "",
                "operator_intake_packet_path": (
                    work_order.get("operator_intake_packet_path") or ""
                ),
                "redrive_receipt_path": (
                    work_order.get("redrive_receipt_path") or ""
                ),
                "first_open_path": first_open_path,
                "filled_manifest_command": (
                    work_order.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    work_order.get("intake_validation_command") or ""
                ),
                "blocking_reason": ";".join(blocking_reasons),
                "required_operator_action": (
                    "none"
                    if bridge_ready and not work_order_open
                    else (
                        "fill the canonical source artifact attestation manifest "
                        "rows for this work order from real local files, then "
                        "rerun real-intake and source-artifact validation"
                    )
                ),
                "manual_boundary": (
                    "control-plane bridge only; templates, status rows, and "
                    "work orders are not evidence; do not fabricate source "
                    "artifacts, attestation metadata, uploads, submissions, "
                    "or external actions"
                ),
            }
        )

    unmatched_template_keys = sorted(key for key in template_by_key if key not in expected_keys)
    unmatched_status_keys = sorted(key for key in status_by_key if key not in expected_keys)
    matched_rows = [row for row in rows if row.get("bridge_ready")]
    open_rows = [row for row in rows if row.get("work_order_status") != "READY"]
    bridge_ready = bool(
        rows
        and len(matched_rows) == len(rows)
        and not unmatched_template_keys
        and not unmatched_status_keys
    )
    first_open_path = next(
        (
            str(row.get("first_open_path") or "").strip()
            for row in rows
            if str(row.get("first_open_path") or "").strip()
        ),
        "",
    )
    bridge_hash = _stable_hash(
        "source_artifact_work_order_attestation_manifest_bridge",
        {
            "label": label,
            "bridge_ready": bridge_ready,
            "rows": [
                {
                    "work_order_id": row.get("work_order_id") or "",
                    "bridge_ready": bool(row.get("bridge_ready")),
                    "expected_artifact_count": row.get("expected_artifact_count") or 0,
                    "manifest_template_row_count": row.get(
                        "manifest_template_row_count"
                    )
                    or 0,
                    "round_trip_status_row_count": row.get(
                        "round_trip_status_row_count"
                    )
                    or 0,
                    "real_intake_checklist_row_count": row.get(
                        "real_intake_checklist_row_count"
                    )
                    or 0,
                    "missing_artifact_count": row.get("missing_artifact_count") or 0,
                }
                for row in rows
            ],
            "unmatched_template_keys": ["|".join(key) for key in unmatched_template_keys],
            "unmatched_status_keys": ["|".join(key) for key in unmatched_status_keys],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_work_order_attestation_manifest_bridge.v1"
        ),
        "label": label,
        "bridge_ready": bridge_ready,
        "bridge_state": (
            "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_BOUND"
            if bridge_ready
            else "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_OPEN"
        ),
        "row_count": len(rows),
        "matched_count": len(matched_rows),
        "open_count": len(open_rows),
        "missing_artifact_count": sum(
            _as_int(row.get("missing_artifact_count")) for row in rows
        ),
        "unmatched_work_order_count": max(len(rows) - len(matched_rows), 0),
        "unmatched_manifest_row_count": len(unmatched_template_keys),
        "unmatched_status_row_count": len(unmatched_status_keys),
        "first_open_path": first_open_path,
        "bridge_hash": bridge_hash if rows else "",
        "rows": rows,
        "unmatched_manifest_keys": ["|".join(key) for key in unmatched_template_keys],
        "unmatched_status_keys": ["|".join(key) for key in unmatched_status_keys],
        "boundary": {
            "control_plane_bridge_only": True,
            "templates_are_not_evidence": True,
            "status_rows_are_not_evidence": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_work_order_attestation_manifest_fill_packet(
    *,
    label: str,
    work_order_rows: list[dict],
    bridge_rows: list[dict],
    attestation_manifest_template_rows: list[dict],
    attestation_manifest_binding: dict,
    real_intake_validation: dict,
) -> dict:
    real_intake_manifest_path = (
        attestation_manifest_binding.get("real_intake_manifest_path")
        or real_intake_validation.get("attestation_packet_manifest_path")
        or ""
    )
    manifest_arg = real_intake_manifest_path or "<filled-remaining-input-attestation.json>"
    label_arg = label or "<label>"
    filled_manifest_command = (
        "./bin/paperctl paper-production-remaining-input-autopilot "
        f"--label {shlex.quote(label_arg)} "
        f"--attestation-manifest {shlex.quote(manifest_arg)} --write --json"
    )
    intake_validation_command = (
        "./bin/paperctl paper-production-referee-repair-source-artifact-intake-queue "
        f"--label {shlex.quote(label_arg)} "
        f"--attestation-manifest {shlex.quote(manifest_arg)} --write --json"
    )
    bridge_by_work_order_id = {
        str(row.get("work_order_id") or "").strip(): dict(row or {})
        for row in bridge_rows or []
        if str((row or {}).get("work_order_id") or "").strip()
    }
    bridge_by_key = {
        (
            str(row.get("request_id") or "").strip(),
            str(row.get("slug") or "").strip(),
            str(row.get("packet_type") or "").strip(),
        ): dict(row or {})
        for row in bridge_rows or []
    }
    templates_by_key: dict[tuple[str, str, str], list[dict]] = {}
    for row in attestation_manifest_template_rows or []:
        key = (
            str(row.get("request_id") or "").strip(),
            str(row.get("slug") or "").strip(),
            str(row.get("packet_type") or "").strip(),
        )
        templates_by_key.setdefault(key, []).append(dict(row or {}))

    rows: list[dict] = []
    for index, work_order in enumerate(work_order_rows or [], start=1):
        key = (
            str(work_order.get("request_id") or "").strip(),
            str(work_order.get("slug") or "").strip(),
            str(work_order.get("packet_type") or "").strip(),
        )
        work_order_id = str(work_order.get("work_order_id") or "").strip()
        bridge_row = bridge_by_work_order_id.get(work_order_id) or bridge_by_key.get(key) or {}
        template_rows = templates_by_key.get(key, [])
        expected_count = _as_int(
            bridge_row.get("expected_artifact_count")
            or work_order.get("expected_artifact_count")
        )
        template_count = _as_int(
            bridge_row.get("manifest_template_row_count") or len(template_rows)
        )
        status_count = _as_int(bridge_row.get("round_trip_status_row_count"))
        checklist_count = _as_int(bridge_row.get("real_intake_checklist_row_count"))
        local_ready_count = _as_int(bridge_row.get("local_ready_count"))
        attestation_ready_count = _as_int(bridge_row.get("attestation_ready_count"))
        shape_ready_count = _as_int(bridge_row.get("shape_ready_count"))
        metadata_ready_count = _as_int(work_order.get("metadata_ready_count"))
        missing_artifact_count = _as_int(
            bridge_row.get("missing_artifact_count")
            or work_order.get("missing_artifact_count")
        )
        template_row_indexes = [
            str(row.get("row_index") or "")
            for row in template_rows
            if str(row.get("row_index") or "")
        ]
        template_expected_paths = [
            str(row.get("expected_path") or "").strip()
            for row in template_rows
            if str(row.get("expected_path") or "").strip()
        ]
        local_sha256_commands = [
            str(row.get("local_sha256_command") or "").strip()
            for row in template_rows
            if str(row.get("local_sha256_command") or "").strip()
        ]
        if not local_sha256_commands and work_order.get("local_sha256_commands"):
            local_sha256_commands = [str(work_order.get("local_sha256_commands") or "")]
        first_open_path = (
            bridge_row.get("first_open_path")
            or work_order.get("first_missing_path")
            or (template_expected_paths[0] if template_expected_paths else "")
        )
        blocking_reasons = []
        if not real_intake_manifest_path:
            blocking_reasons.append("real_intake_attestation_manifest_path_missing")
        if not bridge_row:
            blocking_reasons.append("work_order_attestation_manifest_bridge_row_missing")
        if expected_count <= 0:
            blocking_reasons.append("work_order_expected_artifact_count_missing")
        if template_count != expected_count:
            blocking_reasons.append("attestation_manifest_template_rows_not_bound")
        if status_count != expected_count:
            blocking_reasons.append("round_trip_status_rows_not_bound")
        if checklist_count != expected_count:
            blocking_reasons.append("real_intake_checklist_rows_not_bound")
        if missing_artifact_count:
            blocking_reasons.append("source_artifacts_missing")
        if local_ready_count < expected_count:
            blocking_reasons.append("local_source_artifacts_not_ready")
        if attestation_ready_count < expected_count:
            blocking_reasons.append("attestation_rows_not_ready")
        if metadata_ready_count < expected_count:
            blocking_reasons.append("attestation_metadata_not_ready")
        if shape_ready_count < expected_count:
            blocking_reasons.append("source_artifact_shape_not_ready")

        fill_ready = bool(expected_count and not blocking_reasons)
        rows.append(
            {
                "fill_packet_index": index,
                "work_order_id": work_order_id,
                "fill_packet_status": "READY" if fill_ready else "OPEN",
                "request_id": key[0],
                "slug": key[1],
                "packet_type": key[2],
                "real_intake_attestation_manifest_path": real_intake_manifest_path,
                "expected_artifact_count": expected_count,
                "manifest_template_row_count": template_count,
                "round_trip_status_row_count": status_count,
                "real_intake_checklist_row_count": checklist_count,
                "local_ready_count": local_ready_count,
                "attestation_ready_count": attestation_ready_count,
                "metadata_ready_count": metadata_ready_count,
                "shape_ready_count": shape_ready_count,
                "missing_artifact_count": missing_artifact_count,
                "open_attestation_row_count": max(
                    expected_count - attestation_ready_count,
                    0,
                ),
                "source_packet_path": work_order.get("source_packet_path") or "",
                "operator_intake_packet_path": (
                    work_order.get("operator_intake_packet_path") or ""
                ),
                "redrive_receipt_path": work_order.get("redrive_receipt_path") or "",
                "first_open_path": "" if fill_ready else first_open_path,
                "attestation_template_row_indexes": ";".join(template_row_indexes),
                "attestation_template_expected_paths": ";".join(template_expected_paths),
                "local_sha256_commands": " && ".join(local_sha256_commands),
                "filled_manifest_command": filled_manifest_command,
                "intake_validation_command": intake_validation_command,
                "blocking_reason": ";".join(blocking_reasons),
                "required_operator_action": (
                    "none"
                    if fill_ready
                    else (
                        "fill the real-intake attestation manifest rows for this "
                        "work order using real local files, observed sha256 values, "
                        "and reviewer/provider metadata; then rerun source intake"
                    )
                ),
                "manual_boundary": (
                    "operator fill packet only; does not create source artifacts, "
                    "does not fill attestations, does not accept evidence, and "
                    "does not authorize uploads, submissions, approvals, or "
                    "external actions"
                ),
            }
        )

    control_ready_rows = [
        row
        for row in rows
        if row.get("real_intake_attestation_manifest_path")
        and _as_int(row.get("expected_artifact_count"))
        and _as_int(row.get("manifest_template_row_count"))
        == _as_int(row.get("expected_artifact_count"))
        and _as_int(row.get("round_trip_status_row_count"))
        == _as_int(row.get("expected_artifact_count"))
        and _as_int(row.get("real_intake_checklist_row_count"))
        == _as_int(row.get("expected_artifact_count"))
    ]
    ready_rows = [row for row in rows if row.get("fill_packet_status") == "READY"]
    open_rows = [row for row in rows if row.get("fill_packet_status") != "READY"]
    packet_ready = bool(rows and len(control_ready_rows) == len(rows))
    first_open_path = next(
        (
            str(row.get("first_open_path") or "").strip()
            for row in open_rows
            if str(row.get("first_open_path") or "").strip()
        ),
        "",
    )
    packet_hash = _stable_hash(
        "source_artifact_work_order_attestation_manifest_fill_packet",
        {
            "label": label,
            "real_intake_manifest_path": real_intake_manifest_path,
            "rows": [
                {
                    "work_order_id": row.get("work_order_id") or "",
                    "status": row.get("fill_packet_status") or "",
                    "missing": row.get("missing_artifact_count") or 0,
                    "open_attestation_rows": row.get("open_attestation_row_count") or 0,
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_work_order_attestation_manifest_fill_packet.v1"
        ),
        "label": label,
        "packet_ready": packet_ready,
        "packet_state": (
            "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_FILL_PACKET_READY"
            if packet_ready and not open_rows
            else (
                "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_FILL_PACKET_READY_OPEN_WORK_ORDERS"
                if packet_ready
                else "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_FILL_PACKET_OPEN"
            )
        ),
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "missing_artifact_count": sum(
            _as_int(row.get("missing_artifact_count")) for row in rows
        ),
        "template_row_count": sum(
            _as_int(row.get("manifest_template_row_count")) for row in rows
        ),
        "real_intake_attestation_manifest_path": real_intake_manifest_path,
        "first_open_path": first_open_path,
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "operator_fill_packet_only": True,
            "templates_are_not_evidence": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_work_order_attestation_manifest_filled_preflight(
    *,
    label: str,
    records: list[dict],
    fill_packet_rows: list[dict],
    attestation_manifest_template_rows: list[dict],
    source_artifact_attestation_report: dict | None,
    attestation_manifest_binding: dict,
) -> dict:
    attested_rows, attestation_source = _attested_source_artifact_rows(
        source_artifact_attestation_report
    )
    manifest_path = (
        attestation_manifest_binding.get("manifest_path")
        or attestation_manifest_binding.get("real_intake_manifest_path")
        or ""
    )
    artifact_by_key: dict[tuple[str, str, str, str, str], dict] = {}
    for record in records or []:
        for artifact in (record.get("artifacts") or {}).values():
            if not (artifact or {}).get("expected"):
                continue
            key = _artifact_key(
                request_id=record.get("request_id"),
                slug=record.get("slug") or "",
                packet_type=record.get("packet_type") or "",
                artifact_kind=artifact.get("artifact_kind") or "",
                expected_path=artifact.get("expected_path") or "",
            )
            artifact_by_key[key] = dict(artifact or {})

    template_by_work_order: dict[tuple[str, str, str], list[dict]] = {}
    for row in attestation_manifest_template_rows or []:
        key = (
            str(row.get("request_id") or "").strip(),
            str(row.get("slug") or "").strip(),
            str(row.get("packet_type") or "").strip(),
        )
        template_by_work_order.setdefault(key, []).append(dict(row or {}))

    attested_by_key: dict[tuple[str, str, str, str, str], list[dict]] = {}
    attested_keys_by_work_order: dict[
        tuple[str, str, str],
        set[tuple[str, str, str, str, str]],
    ] = {}
    for row in attested_rows or []:
        key = _artifact_key(
            request_id=row.get("request_id"),
            slug=row.get("slug") or "",
            packet_type=row.get("packet_type") or "",
            artifact_kind=row.get("artifact_kind") or "",
            expected_path=row.get("expected_path") or "",
        )
        work_order_key = key[:3]
        attested_by_key.setdefault(key, []).append(dict(row or {}))
        attested_keys_by_work_order.setdefault(work_order_key, set()).add(key)

    rows: list[dict] = []
    for index, fill_row in enumerate(fill_packet_rows or [], start=1):
        work_order_key = (
            str(fill_row.get("request_id") or "").strip(),
            str(fill_row.get("slug") or "").strip(),
            str(fill_row.get("packet_type") or "").strip(),
        )
        template_rows = template_by_work_order.get(work_order_key, [])
        expected_keys = [
            _artifact_key(
                request_id=row.get("request_id"),
                slug=row.get("slug") or "",
                packet_type=row.get("packet_type") or "",
                artifact_kind=row.get("artifact_kind") or "",
                expected_path=row.get("expected_path") or "",
            )
            for row in template_rows
        ]
        expected_key_set = set(expected_keys)
        attested_work_order_keys = attested_keys_by_work_order.get(
            work_order_key,
            set(),
        )
        unexpected_keys = sorted(attested_work_order_keys - expected_key_set)
        expected_paths = [
            str(row.get("expected_path") or "").strip()
            for row in template_rows
            if str(row.get("expected_path") or "").strip()
        ]
        missing_paths: list[str] = []
        invalid_sha_paths: list[str] = []
        missing_metadata_paths: list[str] = []
        sha_mismatch_paths: list[str] = []
        duplicate_count = 0
        filled_count = 0
        local_ready_count = 0
        sha_valid_count = 0
        sha_match_count = 0
        metadata_ready_count = 0
        ready_artifact_count = 0
        missing_artifact_count = 0

        for key in expected_keys:
            expected_path = key[-1]
            matching_rows = attested_by_key.get(key, [])
            if len(matching_rows) > 1:
                duplicate_count += len(matching_rows) - 1
            row = matching_rows[0] if matching_rows else {}
            artifact = artifact_by_key.get(key, {})
            local_ready = bool(artifact.get("nonempty"))
            actual_sha = str(artifact.get("sha256") or "").strip()
            attested_sha = str(row.get("artifact_sha256") or "").strip()
            sha_valid = _hex_sha256(attested_sha)
            metadata_ready = bool(
                str(row.get("provided_by") or "").strip()
                and str(row.get("provided_at") or "").strip()
                and str(row.get("attestation_source") or "").strip()
            )
            sha_match = bool(
                actual_sha
                and sha_valid
                and actual_sha.lower() == attested_sha.lower()
            )
            if matching_rows:
                filled_count += 1
            else:
                missing_paths.append(expected_path)
            if local_ready:
                local_ready_count += 1
            else:
                missing_artifact_count += 1
            if sha_valid:
                sha_valid_count += 1
            elif matching_rows:
                invalid_sha_paths.append(expected_path)
            if metadata_ready:
                metadata_ready_count += 1
            elif matching_rows:
                missing_metadata_paths.append(expected_path)
            if sha_match:
                sha_match_count += 1
            elif matching_rows and actual_sha and sha_valid:
                sha_mismatch_paths.append(expected_path)
            if matching_rows and local_ready and sha_valid and metadata_ready and sha_match:
                ready_artifact_count += 1

        expected_count = len(expected_keys)
        blocking_reasons = []
        if not expected_count:
            blocking_reasons.append("work_order_expected_attestation_rows_missing")
        if not attestation_manifest_binding.get("bound_to_real_intake"):
            blocking_reasons.append("attestation_manifest_not_bound_to_real_intake")
        if filled_count != expected_count:
            blocking_reasons.append("attestation_manifest_rows_missing")
        if duplicate_count:
            blocking_reasons.append("attestation_manifest_duplicate_rows")
        if unexpected_keys:
            blocking_reasons.append("attestation_manifest_unexpected_rows")
        if missing_artifact_count:
            blocking_reasons.append("source_artifacts_missing")
        if sha_valid_count != expected_count:
            blocking_reasons.append("attestation_sha_invalid")
        if sha_match_count != expected_count:
            blocking_reasons.append("attestation_sha_not_matched_to_local_file")
        if metadata_ready_count != expected_count:
            blocking_reasons.append("attestation_metadata_missing")
        row_ready = bool(expected_count and not blocking_reasons)
        first_open_path = ""
        for values in (
            missing_paths,
            invalid_sha_paths,
            missing_metadata_paths,
            sha_mismatch_paths,
            expected_paths,
        ):
            if values:
                first_open_path = values[0]
                break
        if row_ready:
            first_open_path = ""
        rows.append(
            {
                "preflight_index": index,
                "work_order_id": fill_row.get("work_order_id") or "",
                "preflight_status": "READY" if row_ready else "OPEN",
                "request_id": work_order_key[0],
                "slug": work_order_key[1],
                "packet_type": work_order_key[2],
                "attestation_manifest_path": manifest_path,
                "expected_artifact_count": expected_count,
                "filled_attestation_row_count": filled_count,
                "missing_attestation_row_count": max(expected_count - filled_count, 0),
                "duplicate_attestation_row_count": duplicate_count,
                "unexpected_attestation_row_count": len(unexpected_keys),
                "local_ready_count": local_ready_count,
                "sha_valid_count": sha_valid_count,
                "sha_match_count": sha_match_count,
                "metadata_ready_count": metadata_ready_count,
                "ready_artifact_count": ready_artifact_count,
                "missing_artifact_count": missing_artifact_count,
                "first_open_path": first_open_path,
                "expected_paths": ";".join(expected_paths),
                "missing_expected_paths": ";".join(missing_paths),
                "invalid_sha_paths": ";".join(invalid_sha_paths),
                "missing_metadata_paths": ";".join(missing_metadata_paths),
                "sha_mismatch_paths": ";".join(sha_mismatch_paths),
                "blocking_reason": ";".join(blocking_reasons),
                "required_operator_action": (
                    "none"
                    if row_ready
                    else (
                        "provide the real local source artifacts and fill the "
                        "attestation manifest rows with observed sha256 values "
                        "and reviewer/provider provenance, then rerun source "
                        "artifact intake"
                    )
                ),
                "manual_boundary": (
                    "filled-manifest preflight only; reads local files and "
                    "attestation rows, but does not create artifacts, fill "
                    "metadata, accept evidence, approve, upload, submit, or "
                    "perform external actions"
                ),
            }
        )

    ready_rows = [row for row in rows if row.get("preflight_status") == "READY"]
    open_rows = [row for row in rows if row.get("preflight_status") != "READY"]
    first_open_path = next(
        (
            str(row.get("first_open_path") or "").strip()
            for row in open_rows
            if str(row.get("first_open_path") or "").strip()
        ),
        "",
    )
    preflight_hash = _stable_hash(
        "source_artifact_work_order_attestation_manifest_filled_preflight",
        {
            "label": label,
            "attestation_source": attestation_source,
            "manifest_path": manifest_path,
            "rows": [
                {
                    "work_order_id": row.get("work_order_id") or "",
                    "status": row.get("preflight_status") or "",
                    "filled": row.get("filled_attestation_row_count") or 0,
                    "missing": row.get("missing_attestation_row_count") or 0,
                    "ready": row.get("ready_artifact_count") or 0,
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_work_order_attestation_manifest_filled_preflight.v1"
        ),
        "label": label,
        "preflight_ready": bool(rows and len(ready_rows) == len(rows)),
        "preflight_state": (
            "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_FILLED_READY"
            if rows and len(ready_rows) == len(rows)
            else "SOURCE_ARTIFACT_WORK_ORDER_ATTESTATION_MANIFEST_FILLED_OPEN"
        ),
        "attestation_source": attestation_source,
        "attestation_manifest_path": manifest_path,
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "expected_row_count": sum(
            _as_int(row.get("expected_artifact_count")) for row in rows
        ),
        "filled_row_count": sum(
            _as_int(row.get("filled_attestation_row_count")) for row in rows
        ),
        "missing_attestation_row_count": sum(
            _as_int(row.get("missing_attestation_row_count")) for row in rows
        ),
        "duplicate_attestation_row_count": sum(
            _as_int(row.get("duplicate_attestation_row_count")) for row in rows
        ),
        "unexpected_attestation_row_count": sum(
            _as_int(row.get("unexpected_attestation_row_count")) for row in rows
        ),
        "sha_valid_count": sum(_as_int(row.get("sha_valid_count")) for row in rows),
        "sha_match_count": sum(_as_int(row.get("sha_match_count")) for row in rows),
        "metadata_ready_count": sum(
            _as_int(row.get("metadata_ready_count")) for row in rows
        ),
        "missing_artifact_count": sum(
            _as_int(row.get("missing_artifact_count")) for row in rows
        ),
        "first_open_path": first_open_path,
        "preflight_hash": preflight_hash if rows else "",
        "rows": rows,
        "boundary": {
            "filled_manifest_preflight_only": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_attestation_manifest_filled_preflight_detail(
    *,
    label: str,
    status_rows: list[dict],
    action_rows: list[dict],
    attestation_manifest_template_rows: list[dict],
    source_artifact_attestation_report: dict | None,
    attestation_manifest_binding: dict,
) -> dict:
    attested_rows, attestation_source = _attested_source_artifact_rows(
        source_artifact_attestation_report
    )
    manifest_path = (
        attestation_manifest_binding.get("manifest_path")
        or attestation_manifest_binding.get("real_intake_manifest_path")
        or ""
    )

    def row_key(row: dict) -> tuple[str, str, str, str, str]:
        return _artifact_key(
            request_id=row.get("request_id"),
            slug=row.get("slug") or "",
            packet_type=row.get("packet_type") or "",
            artifact_kind=row.get("artifact_kind") or "",
            expected_path=row.get("expected_path") or "",
        )

    action_by_path = {
        str(row.get("expected_path") or "").strip(): dict(row or {})
        for row in action_rows or []
        if str((row or {}).get("expected_path") or "").strip()
    }
    template_by_path = {
        str(row.get("expected_path") or "").strip(): dict(row or {})
        for row in attestation_manifest_template_rows or []
        if str((row or {}).get("expected_path") or "").strip()
    }
    attested_by_key: dict[tuple[str, str, str, str, str], list[dict]] = {}
    for row in attested_rows or []:
        attested_by_key.setdefault(row_key(row), []).append(dict(row or {}))

    rows: list[dict] = []
    for index, status_row in enumerate(status_rows or [], start=1):
        status_row = dict(status_row or {})
        expected_path = str(status_row.get("expected_path") or "").strip()
        key = row_key(status_row)
        action_row = action_by_path.get(expected_path, {})
        template_row = template_by_path.get(expected_path, {})
        matching_attestation_rows = attested_by_key.get(key, [])
        attestation_row = matching_attestation_rows[0] if matching_attestation_rows else {}
        file_present = _truthy(status_row.get("file_present"))
        file_sha_available = _truthy(status_row.get("file_sha_available"))
        local_ready = bool(file_present and file_sha_available)
        actual_sha = str(status_row.get("actual_file_sha256") or "").strip()
        attested_sha = str(
            attestation_row.get("artifact_sha256")
            or status_row.get("attested_artifact_sha256")
            or ""
        ).strip()
        attested_sha_valid = _hex_sha256(attested_sha)
        sha_match = bool(
            actual_sha
            and attested_sha_valid
            and actual_sha.lower() == attested_sha.lower()
        )
        provided_by = str(
            attestation_row.get("provided_by")
            or status_row.get("attested_by")
            or template_row.get("provided_by")
            or ""
        ).strip()
        provided_at = str(
            attestation_row.get("provided_at")
            or status_row.get("attested_at")
            or template_row.get("provided_at")
            or ""
        ).strip()
        row_attestation_source = str(
            attestation_row.get("attestation_source")
            or status_row.get("attestation_source")
            or template_row.get("attestation_source")
            or ""
        ).strip()
        metadata_ready = bool(provided_by and provided_at and row_attestation_source)
        attestation_row_present = bool(matching_attestation_rows)

        blocking_reasons = []
        if not file_present:
            blocking_reasons.append("source_artifact_missing")
        elif not file_sha_available:
            blocking_reasons.append("source_artifact_sha_unavailable")
        if not attestation_row_present:
            blocking_reasons.append("attestation_row_missing")
        elif not attested_sha_valid:
            blocking_reasons.append("attestation_sha_invalid")
        if attestation_row_present and actual_sha and attested_sha_valid and not sha_match:
            blocking_reasons.append("attestation_sha_not_matched_to_local_file")
        if attestation_row_present and not metadata_ready:
            blocking_reasons.append("attestation_metadata_missing")
        if not attestation_manifest_binding.get("bound_to_real_intake"):
            blocking_reasons.append("attestation_manifest_not_bound_to_real_intake")
        row_ready = bool(
            local_ready
            and attestation_row_present
            and attested_sha_valid
            and sha_match
            and metadata_ready
            and attestation_manifest_binding.get("bound_to_real_intake")
        )
        rows.append(
            {
                "detail_index": index,
                "detail_status": "READY" if row_ready else "OPEN",
                "request_id": key[0],
                "slug": key[1],
                "packet_type": key[2],
                "artifact_kind": key[3],
                "expected_path": expected_path,
                "attestation_manifest_path": manifest_path,
                "local_ready": local_ready,
                "file_present": file_present,
                "file_sha_available": file_sha_available,
                "actual_file_sha256": actual_sha,
                "attestation_row_present": attestation_row_present,
                "attested_artifact_sha256": attested_sha,
                "attested_sha_valid": attested_sha_valid,
                "sha_match": sha_match,
                "metadata_ready": metadata_ready,
                "provided_by": provided_by,
                "provided_at": provided_at,
                "attestation_source": row_attestation_source,
                "candidate_count": _as_int(action_row.get("candidate_count")),
                "best_candidate_path": action_row.get("best_candidate_path") or "",
                "best_candidate_sha256": (
                    action_row.get("best_candidate_sha256") or ""
                ),
                "copy_candidate_command": (
                    action_row.get("copy_candidate_command") or ""
                ),
                "local_sha256_command": (
                    status_row.get("local_sha256_command")
                    or action_row.get("local_sha256_command")
                    or template_row.get("local_sha256_command")
                    or (_shell_join(["sha256sum", expected_path]) if expected_path else "")
                ),
                "filled_manifest_command": (
                    action_row.get("filled_manifest_command")
                    or template_row.get("filled_manifest_command")
                    or status_row.get("filled_manifest_command")
                    or ""
                ),
                "intake_validation_command": (
                    status_row.get("intake_validation_command")
                    or action_row.get("intake_validation_command")
                    or template_row.get("intake_validation_command")
                    or (
                        "./bin/paperctl "
                        "paper-production-referee-repair-source-artifact-intake-queue "
                        f"--label {label} --write --json"
                    )
                ),
                "missing_artifact": not file_present,
                "missing_attestation_row": not attestation_row_present,
                "sha_invalid": bool(attestation_row_present and not attested_sha_valid),
                "sha_mismatch": bool(
                    attestation_row_present
                    and actual_sha
                    and attested_sha_valid
                    and not sha_match
                ),
                "missing_metadata": bool(
                    attestation_row_present and not metadata_ready
                ),
                "blocking_reason": ";".join(blocking_reasons),
                "required_operator_action": (
                    "none"
                    if row_ready
                    else (
                        "provide the real local source artifact, fill the matching "
                        "attestation manifest row with observed sha256 and real "
                        "provider/timestamp/source metadata, then rerun source "
                        "artifact intake"
                    )
                ),
                "status_row_index": status_row.get("row_index") or "",
                "action_row_index": action_row.get("row_index") or "",
                "attestation_template_row_index": template_row.get("row_index") or "",
                "manual_boundary": (
                    "artifact-level filled-preflight detail only; reads local "
                    "status and attestation rows, but does not create source "
                    "artifacts, fill metadata, accept evidence, approve, upload, "
                    "submit, or perform external actions"
                ),
            }
        )

    ready_rows = [row for row in rows if row.get("detail_status") == "READY"]
    open_rows = [row for row in rows if row.get("detail_status") != "READY"]
    first_open_path = next(
        (
            str(row.get("expected_path") or "").strip()
            for row in open_rows
            if str(row.get("expected_path") or "").strip()
        ),
        "",
    )
    detail_hash = _stable_hash(
        "source_artifact_attestation_manifest_filled_preflight_detail",
        {
            "label": label,
            "attestation_source": attestation_source,
            "manifest_path": manifest_path,
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "status": row.get("detail_status") or "",
                    "file_present": bool(row.get("file_present")),
                    "attestation_row_present": bool(
                        row.get("attestation_row_present")
                    ),
                    "sha_match": bool(row.get("sha_match")),
                    "metadata_ready": bool(row.get("metadata_ready")),
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_attestation_manifest_filled_preflight_detail.v1"
        ),
        "label": label,
        "detail_ready": bool(rows and len(ready_rows) == len(rows)),
        "detail_state": (
            "SOURCE_ARTIFACT_ATTESTATION_MANIFEST_FILLED_PREFLIGHT_DETAIL_READY"
            if rows and len(ready_rows) == len(rows)
            else "SOURCE_ARTIFACT_ATTESTATION_MANIFEST_FILLED_PREFLIGHT_DETAIL_OPEN"
        ),
        "attestation_source": attestation_source,
        "attestation_manifest_path": manifest_path,
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "missing_artifact_count": sum(1 for row in rows if row.get("missing_artifact")),
        "missing_attestation_row_count": sum(
            1 for row in rows if row.get("missing_attestation_row")
        ),
        "sha_valid_count": sum(1 for row in rows if row.get("attested_sha_valid")),
        "sha_match_count": sum(1 for row in rows if row.get("sha_match")),
        "metadata_ready_count": sum(1 for row in rows if row.get("metadata_ready")),
        "first_open_path": first_open_path,
        "detail_hash": detail_hash if rows else "",
        "rows": rows,
        "boundary": {
            "artifact_level_filled_preflight_detail_only": True,
            "candidates_are_not_evidence": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_operator_reviewer_execution_packet(
    *,
    label: str,
    filled_preflight_detail: dict,
) -> dict:
    detail_rows = filled_preflight_detail.get("rows") or []
    rows: list[dict] = []
    for index, detail_row in enumerate(detail_rows, start=1):
        detail_row = dict(detail_row or {})
        expected_path = str(detail_row.get("expected_path") or "").strip()
        file_present = _truthy(detail_row.get("file_present"))
        local_ready = _truthy(detail_row.get("local_ready"))
        attestation_row_present = _truthy(
            detail_row.get("attestation_row_present")
        )
        sha_match = _truthy(detail_row.get("sha_match"))
        metadata_ready = _truthy(detail_row.get("metadata_ready"))
        attested_sha_valid = _truthy(detail_row.get("attested_sha_valid"))
        operator_blocked = bool(
            detail_row.get("missing_artifact")
            or not local_ready
            or not file_present
        )
        reviewer_blocked = bool(
            detail_row.get("missing_attestation_row")
            or not attestation_row_present
            or not attested_sha_valid
            or not sha_match
            or not metadata_ready
        )
        actor_blocking = []
        if operator_blocked:
            actor_blocking.append("local_operator")
        if reviewer_blocked:
            actor_blocking.append("reviewer")
        copy_candidate_command = str(
            detail_row.get("copy_candidate_command") or ""
        ).strip()
        local_sha256_command = str(
            detail_row.get("local_sha256_command") or ""
        ).strip()
        filled_manifest_command = str(
            detail_row.get("filled_manifest_command") or ""
        ).strip()
        intake_validation_command = str(
            detail_row.get("intake_validation_command") or ""
        ).strip()
        operator_next_action = "none"
        if operator_blocked:
            operator_next_action = (
                copy_candidate_command
                or (
                    "provide_real_source_artifact_at_expected_path"
                    if expected_path
                    else "resolve_missing_expected_source_artifact_path"
                )
            )
        reviewer_next_action = "none"
        if reviewer_blocked:
            if operator_blocked:
                reviewer_next_action = (
                    "after_local_artifact_exists_fill_attestation_manifest_row_"
                    "with_observed_sha256_provider_timestamp_and_source"
                )
            else:
                reviewer_next_action = (
                    "fill_or_correct_attestation_manifest_row_with_observed_"
                    "sha256_provider_timestamp_and_source"
                )
        execution_status = "READY" if not actor_blocking else "OPEN"
        rows.append(
            {
                "execution_index": index,
                "execution_status": execution_status,
                "actor_blocking": ";".join(actor_blocking) or "none",
                "operator_blocked": operator_blocked,
                "reviewer_blocked": reviewer_blocked,
                "request_id": detail_row.get("request_id") or "",
                "slug": detail_row.get("slug") or "",
                "packet_type": detail_row.get("packet_type") or "",
                "artifact_kind": detail_row.get("artifact_kind") or "",
                "expected_path": expected_path,
                "attestation_manifest_path": (
                    detail_row.get("attestation_manifest_path") or ""
                ),
                "local_ready": local_ready,
                "attestation_ready": bool(
                    attestation_row_present
                    and attested_sha_valid
                    and sha_match
                    and metadata_ready
                ),
                "file_present": file_present,
                "actual_file_sha256": detail_row.get("actual_file_sha256") or "",
                "attestation_row_present": attestation_row_present,
                "attested_artifact_sha256": (
                    detail_row.get("attested_artifact_sha256") or ""
                ),
                "sha_match": sha_match,
                "metadata_ready": metadata_ready,
                "operator_next_action": operator_next_action,
                "reviewer_next_action": reviewer_next_action,
                "copy_candidate_command": copy_candidate_command,
                "local_sha256_command": local_sha256_command,
                "filled_manifest_command": filled_manifest_command,
                "intake_validation_command": intake_validation_command,
                "blocking_reason": detail_row.get("blocking_reason") or "",
                "manual_boundary": (
                    "operator/reviewer execution packet only; derived from "
                    "artifact-level filled-preflight detail and does not "
                    "create source artifacts, fill attestation metadata, "
                    "accept evidence, approve, upload, submit, or perform "
                    "external actions"
                ),
            }
        )

    ready_rows = [row for row in rows if row.get("execution_status") == "READY"]
    open_rows = [row for row in rows if row.get("execution_status") != "READY"]
    first_operator_path = next(
        (
            str(row.get("expected_path") or "").strip()
            for row in open_rows
            if row.get("operator_blocked") and str(row.get("expected_path") or "").strip()
        ),
        "",
    )
    first_reviewer_path = next(
        (
            str(row.get("expected_path") or "").strip()
            for row in open_rows
            if row.get("reviewer_blocked") and str(row.get("expected_path") or "").strip()
        ),
        "",
    )
    packet_hash = _stable_hash(
        "source_artifact_operator_reviewer_execution_packet",
        {
            "label": label,
            "detail_hash": filled_preflight_detail.get("detail_hash") or "",
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "status": row.get("execution_status") or "",
                    "operator_blocked": bool(row.get("operator_blocked")),
                    "reviewer_blocked": bool(row.get("reviewer_blocked")),
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_operator_reviewer_execution_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows and len(ready_rows) == len(rows)),
        "packet_state": (
            "SOURCE_ARTIFACT_OPERATOR_REVIEWER_EXECUTION_PACKET_READY"
            if rows and len(ready_rows) == len(rows)
            else "SOURCE_ARTIFACT_OPERATOR_REVIEWER_EXECUTION_PACKET_OPEN"
        ),
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "operator_blocked_count": sum(
            1 for row in rows if row.get("operator_blocked")
        ),
        "reviewer_blocked_count": sum(
            1 for row in rows if row.get("reviewer_blocked")
        ),
        "missing_artifact_count": sum(
            1 for row in rows if row.get("operator_blocked")
        ),
        "missing_attestation_row_count": sum(
            1
            for row in rows
            if row.get("reviewer_blocked")
            and not row.get("attestation_row_present")
        ),
        "sha_blocked_count": sum(
            1
            for row in rows
            if row.get("reviewer_blocked")
            and row.get("attestation_row_present")
            and not row.get("sha_match")
        ),
        "metadata_blocked_count": sum(
            1
            for row in rows
            if row.get("reviewer_blocked")
            and row.get("attestation_row_present")
            and not row.get("metadata_ready")
        ),
        "first_operator_path": first_operator_path,
        "first_reviewer_path": first_reviewer_path,
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "operator_reviewer_execution_packet_only": True,
            "derived_from_filled_preflight_detail": True,
            "candidates_are_not_evidence": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_production_evidence_closure_packet(
    *,
    label: str,
    filled_preflight_detail: dict,
    operator_reviewer_packet: dict,
    attestation_manifest_binding: dict,
    real_intake_validation: dict,
) -> dict:
    """Compose the artifact, attestation, and reviewer surfaces into one gate."""

    detail_rows = [dict(row or {}) for row in (filled_preflight_detail.get("rows") or [])]
    execution_rows = [
        dict(row or {}) for row in (operator_reviewer_packet.get("rows") or [])
    ]
    execution_by_path = {
        str(row.get("expected_path") or "").strip(): row
        for row in execution_rows
        if str(row.get("expected_path") or "").strip()
    }
    manifest_bound = bool(
        attestation_manifest_binding.get("bound_to_real_intake")
    )
    manifest_issue_count = _as_int(attestation_manifest_binding.get("issue_count"))
    real_intake_closure_ready = bool(
        real_intake_validation.get("closure_ready")
        and real_intake_validation.get("closure_csv_sha256_match")
        and real_intake_validation.get("closure_csv_shape_ready")
    )
    real_intake_attestation_packet_ready = bool(
        real_intake_validation.get("attestation_packet_ready")
    )
    real_intake_operator_input_missing_count = _as_int(
        real_intake_validation.get("operator_input_missing_count")
    )
    gate_ready = bool(
        manifest_bound
        and manifest_issue_count == 0
        and real_intake_closure_ready
        and real_intake_attestation_packet_ready
    )

    rows: list[dict] = []
    for index, detail_row in enumerate(detail_rows, start=1):
        expected_path = str(detail_row.get("expected_path") or "").strip()
        execution_row = execution_by_path.get(expected_path, {})
        file_present = _truthy(detail_row.get("file_present"))
        file_sha_available = _truthy(detail_row.get("file_sha_available")) or bool(
            str(detail_row.get("actual_file_sha256") or "").strip()
        )
        local_artifact_ready = bool(
            _truthy(detail_row.get("local_ready"))
            and file_present
            and file_sha_available
        )
        attestation_row_present = _truthy(detail_row.get("attestation_row_present"))
        attested_sha_valid = _truthy(detail_row.get("attested_sha_valid"))
        sha_match = _truthy(detail_row.get("sha_match"))
        metadata_ready = _truthy(detail_row.get("metadata_ready"))
        attestation_ready = bool(
            attestation_row_present
            and attested_sha_valid
            and sha_match
            and metadata_ready
        )
        operator_blocked = _truthy(execution_row.get("operator_blocked"))
        reviewer_blocked = _truthy(execution_row.get("reviewer_blocked"))
        operator_reviewer_ready = bool(
            str(execution_row.get("execution_status") or "") == "READY"
            and not operator_blocked
            and not reviewer_blocked
        )
        blockers: list[str] = []
        if not file_present:
            blockers.append("source_artifact_file_missing")
        elif not file_sha_available:
            blockers.append("source_artifact_sha_unavailable")
        elif not local_artifact_ready:
            blockers.append("source_artifact_local_validation_not_ready")
        if not attestation_row_present:
            blockers.append("source_artifact_attestation_row_missing")
        elif not attested_sha_valid:
            blockers.append("source_artifact_attested_sha_invalid")
        elif not sha_match:
            blockers.append("source_artifact_sha_mismatch")
        elif not metadata_ready:
            blockers.append("source_artifact_attestation_metadata_missing")
        if not operator_reviewer_ready:
            blockers.append("operator_reviewer_execution_packet_open")
        if not manifest_bound or manifest_issue_count:
            blockers.append("attestation_manifest_not_bound_to_real_intake")
        if not real_intake_closure_ready:
            blockers.append("real_intake_operator_closure_not_ready")
        if not real_intake_attestation_packet_ready:
            blockers.append("real_intake_source_artifact_attestation_packet_not_ready")

        production_ready = bool(
            local_artifact_ready
            and attestation_ready
            and operator_reviewer_ready
            and gate_ready
        )
        rows.append(
            {
                "closure_index": index,
                "closure_status": "READY" if production_ready else "OPEN",
                "request_id": detail_row.get("request_id") or "",
                "slug": detail_row.get("slug") or "",
                "packet_type": detail_row.get("packet_type") or "",
                "artifact_kind": detail_row.get("artifact_kind") or "",
                "expected_path": expected_path,
                "attestation_manifest_path": (
                    detail_row.get("attestation_manifest_path") or ""
                ),
                "local_artifact_ready": local_artifact_ready,
                "source_artifact_file_present": file_present,
                "source_artifact_sha_available": file_sha_available,
                "source_artifact_sha256": detail_row.get("actual_file_sha256") or "",
                "attestation_ready": attestation_ready,
                "attestation_row_present": attestation_row_present,
                "attested_artifact_sha256": (
                    detail_row.get("attested_artifact_sha256") or ""
                ),
                "attested_sha_valid": attested_sha_valid,
                "sha_match": sha_match,
                "attestation_metadata_ready": metadata_ready,
                "operator_reviewer_packet_ready": operator_reviewer_ready,
                "operator_blocked": operator_blocked,
                "reviewer_blocked": reviewer_blocked,
                "manifest_bound_to_real_intake": manifest_bound,
                "manifest_binding_issue_count": manifest_issue_count,
                "real_intake_source_artifact_operator_closure_ready": (
                    real_intake_closure_ready
                ),
                "real_intake_source_artifact_attestation_packet_ready": (
                    real_intake_attestation_packet_ready
                ),
                "real_intake_operator_input_missing_count": (
                    real_intake_operator_input_missing_count
                ),
                "production_evidence_closure_ready": production_ready,
                "blocking_reason": ";".join(dict.fromkeys(blockers)),
                "required_operator_action": (
                    detail_row.get("required_operator_action")
                    or "provide_real_source_artifact_and_reviewed_attestation"
                ),
                "operator_next_action": (
                    execution_row.get("operator_next_action")
                    or detail_row.get("copy_candidate_command")
                    or "provide_real_source_artifact_at_expected_path"
                ),
                "reviewer_next_action": (
                    execution_row.get("reviewer_next_action")
                    or "fill_or_review_attestation_manifest_row"
                ),
                "local_sha256_command": detail_row.get("local_sha256_command") or "",
                "filled_manifest_command": (
                    detail_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    detail_row.get("intake_validation_command") or ""
                ),
                "manual_boundary": (
                    "production evidence closure packet only; reads local "
                    "artifact and attestation state, but does not create source "
                    "artifacts, fill attestations, approve, upload, submit, "
                    "stage, commit, reset, or mutate source/package/archive/registry"
                ),
            }
        )

    ready_rows = [row for row in rows if row.get("closure_status") == "READY"]
    open_rows = [row for row in rows if row.get("closure_status") != "READY"]
    first_open_path = next(
        (
            str(row.get("expected_path") or "").strip()
            for row in open_rows
            if str(row.get("expected_path") or "").strip()
        ),
        "",
    )
    packet_hash = _stable_hash(
        "source_artifact_production_evidence_closure_packet",
        {
            "label": label,
            "detail_hash": filled_preflight_detail.get("detail_hash") or "",
            "operator_reviewer_packet_hash": (
                operator_reviewer_packet.get("packet_hash") or ""
            ),
            "manifest_bound": manifest_bound,
            "manifest_issue_count": manifest_issue_count,
            "real_intake_closure_ready": real_intake_closure_ready,
            "real_intake_attestation_packet_ready": (
                real_intake_attestation_packet_ready
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "status": row.get("closure_status") or "",
                    "blocking_reason": row.get("blocking_reason") or "",
                }
                for row in rows
            ],
        },
    )
    missing_artifact_count = sum(
        1 for row in rows if not row.get("local_artifact_ready")
    )
    missing_attestation_count = sum(
        1 for row in rows if not row.get("attestation_row_present")
    )
    blocking_reasons = []
    for row in open_rows:
        for reason in str(row.get("blocking_reason") or "").split(";"):
            reason = reason.strip()
            if reason and reason not in blocking_reasons:
                blocking_reasons.append(reason)
    if not rows:
        blocking_state = "SOURCE_ARTIFACT_PRODUCTION_EVIDENCE_CLOSURE_PACKET_EMPTY"
    elif not open_rows:
        blocking_state = "SOURCE_ARTIFACT_PRODUCTION_EVIDENCE_CLOSURE_PACKET_READY"
    elif missing_artifact_count:
        blocking_state = "OPEN_SOURCE_ARTIFACT_PRODUCTION_EVIDENCE_MISSING"
    elif missing_attestation_count:
        blocking_state = "OPEN_SOURCE_ARTIFACT_PRODUCTION_ATTESTATION_MISSING"
    else:
        blocking_state = "OPEN_SOURCE_ARTIFACT_PRODUCTION_EVIDENCE_NOT_REVIEWED"
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_production_evidence_closure_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows and not open_rows),
        "packet_state": blocking_state,
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "local_artifact_ready_count": sum(
            1 for row in rows if row.get("local_artifact_ready")
        ),
        "missing_artifact_count": missing_artifact_count,
        "attestation_ready_count": sum(
            1 for row in rows if row.get("attestation_ready")
        ),
        "missing_attestation_row_count": missing_attestation_count,
        "sha_match_count": sum(1 for row in rows if row.get("sha_match")),
        "metadata_ready_count": sum(
            1 for row in rows if row.get("attestation_metadata_ready")
        ),
        "operator_reviewer_ready_count": sum(
            1 for row in rows if row.get("operator_reviewer_packet_ready")
        ),
        "operator_blocked_count": sum(
            1 for row in rows if row.get("operator_blocked")
        ),
        "reviewer_blocked_count": sum(
            1 for row in rows if row.get("reviewer_blocked")
        ),
        "manifest_bound_to_real_intake": manifest_bound,
        "manifest_binding_issue_count": manifest_issue_count,
        "real_intake_operator_closure_ready": real_intake_closure_ready,
        "real_intake_attestation_packet_ready": real_intake_attestation_packet_ready,
        "real_intake_operator_input_missing_count": (
            real_intake_operator_input_missing_count
        ),
        "first_open_path": first_open_path,
        "blocking_state": blocking_state,
        "blocking_reason": ";".join(blocking_reasons),
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "production_evidence_closure_packet_only": True,
            "derived_from_filled_preflight_detail_and_operator_reviewer_packet": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_real_evidence_intake_review_packet(
    *,
    label: str,
    production_evidence_packet: dict,
) -> dict:
    """Turn production-evidence gaps into an operator/reviewer intake surface."""

    production_rows = [
        dict(row or {}) for row in (production_evidence_packet.get("rows") or [])
    ]
    rows: list[dict] = []
    for index, production_row in enumerate(production_rows, start=1):
        expected_path = str(production_row.get("expected_path") or "").strip()
        artifact_present = _truthy(
            production_row.get("source_artifact_file_present")
        )
        attestation_present = _truthy(
            production_row.get("attestation_row_present")
        )
        production_ready = _truthy(
            production_row.get("production_evidence_closure_ready")
        )
        operator_action_required = bool(
            not artifact_present or _truthy(production_row.get("operator_blocked"))
        )
        reviewer_action_required = bool(
            not attestation_present
            or _truthy(production_row.get("reviewer_blocked"))
            or not _truthy(production_row.get("attestation_ready"))
        )
        ready_for_local_review = bool(
            artifact_present and attestation_present and not operator_action_required
        )
        required_operator_action = "none"
        if operator_action_required:
            required_operator_action = (
                production_row.get("operator_next_action")
                or production_row.get("required_operator_action")
                or "provide_real_source_artifact_at_expected_path"
            )
        required_reviewer_action = "none"
        if reviewer_action_required:
            required_reviewer_action = (
                production_row.get("reviewer_next_action")
                or "fill_or_review_attestation_manifest_row"
            )
        blockers = []
        for reason in str(production_row.get("blocking_reason") or "").split(";"):
            reason = reason.strip()
            if reason and reason not in blockers:
                blockers.append(reason)
        review_status = (
            "READY_FOR_PRODUCTION_CLOSURE"
            if production_ready
            else "OPEN_REAL_SOURCE_EVIDENCE_INTAKE"
        )
        rows.append(
            {
                "review_index": index,
                "review_status": review_status,
                "request_id": production_row.get("request_id") or "",
                "slug": production_row.get("slug") or "",
                "packet_type": production_row.get("packet_type") or "",
                "artifact_kind": production_row.get("artifact_kind") or "",
                "expected_path": expected_path,
                "attestation_manifest_path": (
                    production_row.get("attestation_manifest_path") or ""
                ),
                "source_artifact_file_present": artifact_present,
                "attestation_row_present": attestation_present,
                "operator_action_required": operator_action_required,
                "reviewer_action_required": reviewer_action_required,
                "ready_for_local_review": ready_for_local_review,
                "production_evidence_closure_ready": production_ready,
                "required_operator_action": required_operator_action,
                "required_reviewer_action": required_reviewer_action,
                "operator_next_action": production_row.get("operator_next_action")
                or "",
                "reviewer_next_action": production_row.get("reviewer_next_action")
                or "",
                "local_sha256_command": production_row.get("local_sha256_command")
                or "",
                "filled_manifest_command": (
                    production_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    production_row.get("intake_validation_command") or ""
                ),
                "blocking_reason": ";".join(blockers),
                "manual_boundary": (
                    "real evidence intake/review packet only; converts "
                    "production-evidence gaps into operator/reviewer actions "
                    "without creating artifacts, filling attestations, "
                    "accepting evidence, approving, uploading, submitting, "
                    "staging, committing, resetting, or mutating registries"
                ),
            }
        )

    ready_rows = [
        row
        for row in rows
        if row.get("review_status") == "READY_FOR_PRODUCTION_CLOSURE"
    ]
    open_rows = [
        row
        for row in rows
        if row.get("review_status") != "READY_FOR_PRODUCTION_CLOSURE"
    ]
    first_open_path = next(
        (
            str(row.get("expected_path") or "").strip()
            for row in open_rows
            if str(row.get("expected_path") or "").strip()
        ),
        "",
    )
    missing_artifact_count = sum(
        1 for row in rows if not row.get("source_artifact_file_present")
    )
    missing_attestation_count = sum(
        1 for row in rows if not row.get("attestation_row_present")
    )
    blocking_reasons = []
    for row in open_rows:
        for reason in str(row.get("blocking_reason") or "").split(";"):
            reason = reason.strip()
            if reason and reason not in blocking_reasons:
                blocking_reasons.append(reason)
    if not rows:
        packet_state = "SOURCE_ARTIFACT_REAL_EVIDENCE_INTAKE_REVIEW_PACKET_EMPTY"
    elif not open_rows:
        packet_state = "SOURCE_ARTIFACT_REAL_EVIDENCE_INTAKE_REVIEW_PACKET_READY"
    elif missing_artifact_count:
        packet_state = "OPEN_REAL_SOURCE_ARTIFACT_INTAKE_REQUIRED"
    elif missing_attestation_count:
        packet_state = "OPEN_REVIEWED_SOURCE_ATTESTATION_REQUIRED"
    else:
        packet_state = "OPEN_REAL_SOURCE_EVIDENCE_REVIEW_REQUIRED"
    packet_hash = _stable_hash(
        "source_artifact_real_evidence_intake_review_packet",
        {
            "label": label,
            "production_evidence_hash": (
                production_evidence_packet.get("packet_hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "status": row.get("review_status") or "",
                    "operator_action_required": bool(
                        row.get("operator_action_required")
                    ),
                    "reviewer_action_required": bool(
                        row.get("reviewer_action_required")
                    ),
                    "blocking_reason": row.get("blocking_reason") or "",
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_real_evidence_intake_review_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows and not open_rows),
        "packet_state": packet_state,
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "operator_action_required_count": sum(
            1 for row in rows if row.get("operator_action_required")
        ),
        "reviewer_action_required_count": sum(
            1 for row in rows if row.get("reviewer_action_required")
        ),
        "missing_artifact_count": missing_artifact_count,
        "missing_attestation_row_count": missing_attestation_count,
        "ready_for_local_review_count": sum(
            1 for row in rows if row.get("ready_for_local_review")
        ),
        "first_open_path": first_open_path,
        "blocking_state": packet_state,
        "blocking_reason": ";".join(blocking_reasons),
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "real_evidence_intake_review_packet_only": True,
            "derived_from_production_evidence_closure_packet": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_operator_fill_reviewer_acceptance_packet(
    *,
    label: str,
    real_evidence_review_packet: dict,
) -> dict:
    """Split real-evidence intake rows into operator, reviewer, and row closure gates."""

    review_rows = [
        dict(row or {}) for row in (real_evidence_review_packet.get("rows") or [])
    ]
    rows: list[dict] = []
    for index, review_row in enumerate(review_rows, start=1):
        expected_path = str(review_row.get("expected_path") or "").strip()
        artifact_present = _truthy(review_row.get("source_artifact_file_present"))
        attestation_present = _truthy(review_row.get("attestation_row_present"))
        production_ready = _truthy(
            review_row.get("production_evidence_closure_ready")
        )
        operator_fill_required = _truthy(
            review_row.get("operator_action_required")
        ) or not artifact_present
        reviewer_acceptance_required = _truthy(
            review_row.get("reviewer_action_required")
        ) or not attestation_present
        attestation_row_closure_required = not attestation_present
        ready_for_reviewer = bool(
            artifact_present
            and not operator_fill_required
            and (
                attestation_present
                or attestation_row_closure_required
                or reviewer_acceptance_required
            )
        )
        blockers = []
        for reason in str(review_row.get("blocking_reason") or "").split(";"):
            reason = reason.strip()
            if reason and reason not in blockers:
                blockers.append(reason)
        if operator_fill_required and "operator_fill_required" not in blockers:
            blockers.append("operator_fill_required")
        if (
            reviewer_acceptance_required
            and "reviewer_acceptance_required" not in blockers
        ):
            blockers.append("reviewer_acceptance_required")
        if (
            attestation_row_closure_required
            and "attestation_row_closure_required" not in blockers
        ):
            blockers.append("attestation_row_closure_required")
        closure_ready = bool(production_ready and not blockers)
        rows.append(
            {
                "closure_index": index,
                "closure_status": (
                    "READY_FOR_FINAL_SOURCE_CLOSURE"
                    if closure_ready
                    else "OPEN_OPERATOR_FILL_REVIEWER_ACCEPTANCE"
                ),
                "request_id": review_row.get("request_id") or "",
                "slug": review_row.get("slug") or "",
                "packet_type": review_row.get("packet_type") or "",
                "artifact_kind": review_row.get("artifact_kind") or "",
                "expected_path": expected_path,
                "attestation_manifest_path": (
                    review_row.get("attestation_manifest_path") or ""
                ),
                "operator_fill_required": operator_fill_required,
                "operator_fill_state": (
                    "OPEN_OPERATOR_SOURCE_ARTIFACT_FILL_REQUIRED"
                    if operator_fill_required
                    else "OPERATOR_SOURCE_ARTIFACT_FILL_CLOSED"
                ),
                "reviewer_acceptance_required": reviewer_acceptance_required,
                "reviewer_acceptance_state": (
                    "OPEN_REVIEWER_SOURCE_EVIDENCE_ACCEPTANCE_REQUIRED"
                    if reviewer_acceptance_required
                    else "REVIEWER_SOURCE_EVIDENCE_ACCEPTANCE_CLOSED"
                ),
                "attestation_row_closure_required": (
                    attestation_row_closure_required
                ),
                "attestation_row_closure_state": (
                    "OPEN_REVIEWED_ATTESTATION_ROW_CLOSURE_REQUIRED"
                    if attestation_row_closure_required
                    else "REVIEWED_ATTESTATION_ROW_CLOSURE_CLOSED"
                ),
                "source_artifact_file_present": artifact_present,
                "attestation_row_present": attestation_present,
                "ready_for_reviewer": ready_for_reviewer,
                "production_evidence_closure_ready": production_ready,
                "required_operator_action": (
                    review_row.get("required_operator_action") or "none"
                ),
                "required_reviewer_action": (
                    review_row.get("required_reviewer_action") or "none"
                ),
                "operator_next_action": review_row.get("operator_next_action") or "",
                "reviewer_next_action": review_row.get("reviewer_next_action") or "",
                "local_sha256_command": review_row.get("local_sha256_command") or "",
                "filled_manifest_command": (
                    review_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    review_row.get("intake_validation_command") or ""
                ),
                "blocking_reason": ";".join(blockers),
                "manual_boundary": (
                    "operator fill/reviewer acceptance closure packet only; "
                    "splits real evidence intake work into operator artifact "
                    "fill, reviewer acceptance, and attestation-row closure "
                    "without creating artifacts, filling attestations, "
                    "accepting evidence, approving, uploading, submitting, "
                    "staging, committing, resetting, or mutating registries"
                ),
            }
        )

    ready_rows = [
        row
        for row in rows
        if row.get("closure_status") == "READY_FOR_FINAL_SOURCE_CLOSURE"
    ]
    open_rows = [
        row
        for row in rows
        if row.get("closure_status") != "READY_FOR_FINAL_SOURCE_CLOSURE"
    ]
    first_open_path = next(
        (
            str(row.get("expected_path") or "").strip()
            for row in open_rows
            if str(row.get("expected_path") or "").strip()
        ),
        "",
    )
    missing_artifact_count = sum(
        1 for row in rows if not row.get("source_artifact_file_present")
    )
    missing_attestation_count = sum(
        1 for row in rows if not row.get("attestation_row_present")
    )
    operator_fill_required_count = sum(
        1 for row in rows if row.get("operator_fill_required")
    )
    reviewer_acceptance_required_count = sum(
        1 for row in rows if row.get("reviewer_acceptance_required")
    )
    attestation_row_closure_required_count = sum(
        1 for row in rows if row.get("attestation_row_closure_required")
    )
    blocking_reasons = []
    for row in open_rows:
        for reason in str(row.get("blocking_reason") or "").split(";"):
            reason = reason.strip()
            if reason and reason not in blocking_reasons:
                blocking_reasons.append(reason)
    if not rows:
        packet_state = "SOURCE_ARTIFACT_OPERATOR_FILL_REVIEWER_ACCEPTANCE_PACKET_EMPTY"
    elif not open_rows:
        packet_state = "SOURCE_ARTIFACT_OPERATOR_FILL_REVIEWER_ACCEPTANCE_PACKET_READY"
    elif operator_fill_required_count:
        packet_state = "OPEN_OPERATOR_SOURCE_ARTIFACT_FILL_REQUIRED"
    elif attestation_row_closure_required_count:
        packet_state = "OPEN_REVIEWED_ATTESTATION_ROW_CLOSURE_REQUIRED"
    elif reviewer_acceptance_required_count:
        packet_state = "OPEN_REVIEWER_SOURCE_EVIDENCE_ACCEPTANCE_REQUIRED"
    else:
        packet_state = "OPEN_SOURCE_ARTIFACT_OPERATOR_REVIEWER_CLOSURE_REQUIRED"
    packet_hash = _stable_hash(
        "source_artifact_operator_fill_reviewer_acceptance_packet",
        {
            "label": label,
            "real_evidence_review_hash": (
                real_evidence_review_packet.get("packet_hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "status": row.get("closure_status") or "",
                    "operator_fill_required": bool(
                        row.get("operator_fill_required")
                    ),
                    "reviewer_acceptance_required": bool(
                        row.get("reviewer_acceptance_required")
                    ),
                    "attestation_row_closure_required": bool(
                        row.get("attestation_row_closure_required")
                    ),
                    "blocking_reason": row.get("blocking_reason") or "",
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_operator_fill_reviewer_acceptance_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows and not open_rows),
        "packet_state": packet_state,
        "row_count": len(rows),
        "ready_count": len(ready_rows),
        "open_count": len(open_rows),
        "operator_fill_required_count": operator_fill_required_count,
        "reviewer_acceptance_required_count": reviewer_acceptance_required_count,
        "attestation_row_closure_required_count": (
            attestation_row_closure_required_count
        ),
        "missing_artifact_count": missing_artifact_count,
        "missing_attestation_row_count": missing_attestation_count,
        "ready_for_reviewer_count": sum(
            1 for row in rows if row.get("ready_for_reviewer")
        ),
        "first_open_path": first_open_path,
        "blocking_state": packet_state,
        "blocking_reason": ";".join(blocking_reasons),
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "operator_fill_reviewer_acceptance_packet_only": True,
            "derived_from_real_evidence_intake_review_packet": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_closure_gap_summary(
    *,
    label: str,
    operator_fill_reviewer_acceptance_packet: dict,
) -> dict:
    """Flatten final source-artifact closure blockers into an operator-facing list."""

    source_rows = [
        dict(row or {})
        for row in (operator_fill_reviewer_acceptance_packet.get("rows") or [])
    ]
    rows: list[dict] = []
    for index, source_row in enumerate(source_rows, start=1):
        missing_file = not _truthy(source_row.get("source_artifact_file_present"))
        missing_attestation_row = not _truthy(
            source_row.get("attestation_row_present")
        )
        operator_fill_required = _truthy(source_row.get("operator_fill_required"))
        reviewer_acceptance_required = _truthy(
            source_row.get("reviewer_acceptance_required")
        )
        attestation_row_closure_required = _truthy(
            source_row.get("attestation_row_closure_required")
        )
        ready = bool(
            str(source_row.get("closure_status") or "")
            == "READY_FOR_FINAL_SOURCE_CLOSURE"
        )
        next_roles = []
        if missing_file or operator_fill_required:
            next_roles.append("operator")
        if reviewer_acceptance_required:
            next_roles.append("reviewer")
        if attestation_row_closure_required:
            next_roles.append("attestation_closure")
        required_operator_fields = (
            list(SOURCE_ARTIFACT_OPERATOR_REQUIRED_FIELDS)
            if missing_file or operator_fill_required
            else []
        )
        required_reviewer_fields = (
            list(SOURCE_ARTIFACT_REVIEWER_REQUIRED_FIELDS)
            if reviewer_acceptance_required
            else []
        )
        required_attestation_fields = (
            list(SOURCE_ARTIFACT_ATTESTATION_REQUIRED_FIELDS)
            if attestation_row_closure_required
            else []
        )
        next_action = ""
        if missing_file or operator_fill_required:
            next_action = (
                source_row.get("operator_next_action")
                or source_row.get("required_operator_action")
                or ""
            )
        elif reviewer_acceptance_required or attestation_row_closure_required:
            next_action = (
                source_row.get("reviewer_next_action")
                or source_row.get("required_reviewer_action")
                or ""
            )
        rows.append(
            {
                "gap_index": index,
                "gap_status": "READY" if ready else "OPEN",
                "request_id": source_row.get("request_id") or "",
                "slug": source_row.get("slug") or "",
                "packet_type": source_row.get("packet_type") or "",
                "artifact_kind": source_row.get("artifact_kind") or "",
                "expected_path": source_row.get("expected_path") or "",
                "missing_file": missing_file,
                "missing_attestation_row": missing_attestation_row,
                "operator_fill_required": operator_fill_required,
                "reviewer_acceptance_required": reviewer_acceptance_required,
                "attestation_row_closure_required": attestation_row_closure_required,
                "ready_for_reviewer": _truthy(source_row.get("ready_for_reviewer")),
                "production_evidence_closure_ready": _truthy(
                    source_row.get("production_evidence_closure_ready")
                ),
                "next_blocking_role": ";".join(next_roles) or "none",
                "next_action": next_action,
                "required_operator_fields": ";".join(required_operator_fields),
                "required_reviewer_fields": ";".join(required_reviewer_fields),
                "required_attestation_fields": ";".join(
                    required_attestation_fields
                ),
                "required_operator_field_count": len(required_operator_fields),
                "required_reviewer_field_count": len(required_reviewer_fields),
                "required_attestation_field_count": len(
                    required_attestation_fields
                ),
                "required_field_count": (
                    len(required_operator_fields)
                    + len(required_reviewer_fields)
                    + len(required_attestation_fields)
                ),
                "local_sha256_command": source_row.get("local_sha256_command") or "",
                "filled_manifest_command": (
                    source_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    source_row.get("intake_validation_command") or ""
                ),
                "blocking_reason": source_row.get("blocking_reason") or "",
                "manual_boundary": (
                    "human-readable gap summary only; does not create source "
                    "artifacts, fill attestations, accept evidence, approve, "
                    "upload, submit, stage, commit, reset, or mutate registries"
                ),
            }
        )

    open_rows = [row for row in rows if row.get("gap_status") != "READY"]
    first_open = open_rows[0] if open_rows else {}
    summary_hash = _stable_hash(
        "source_artifact_closure_gap_summary",
        {
            "label": label,
            "operator_fill_reviewer_acceptance_packet_hash": (
                operator_fill_reviewer_acceptance_packet.get("packet_hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "gap_status": row.get("gap_status") or "",
                    "missing_file": bool(row.get("missing_file")),
                    "missing_attestation_row": bool(
                        row.get("missing_attestation_row")
                    ),
                    "next_blocking_role": row.get("next_blocking_role") or "",
                    "next_action": row.get("next_action") or "",
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_closure_gap_summary.v1"
        ),
        "label": label,
        "summary_ready": bool(rows and not open_rows),
        "row_count": len(rows),
        "ready_count": len(rows) - len(open_rows),
        "open_count": len(open_rows),
        "missing_file_count": sum(1 for row in rows if row.get("missing_file")),
        "missing_attestation_row_count": sum(
            1 for row in rows if row.get("missing_attestation_row")
        ),
        "operator_fill_required_count": sum(
            1 for row in rows if row.get("operator_fill_required")
        ),
        "reviewer_acceptance_required_count": sum(
            1 for row in rows if row.get("reviewer_acceptance_required")
        ),
        "attestation_row_closure_required_count": sum(
            1 for row in rows if row.get("attestation_row_closure_required")
        ),
        "first_open_path": first_open.get("expected_path") or "",
        "first_next_action": first_open.get("next_action") or "",
        "summary_hash": summary_hash if rows else "",
        "rows": rows,
        "boundary": {
            "summary_only": True,
            "derived_from_operator_fill_reviewer_acceptance_packet": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_real_closure_intake_packet(
    *,
    label: str,
    closure_gap_summary: dict,
) -> dict:
    """Make the 93 source/attestation gaps executable without closing them."""

    gap_rows = [
        dict(row or {}) for row in (closure_gap_summary.get("rows") or [])
    ]
    rows: list[dict] = []
    for index, gap_row in enumerate(gap_rows, start=1):
        missing_file = _truthy(gap_row.get("missing_file"))
        missing_attestation_row = _truthy(gap_row.get("missing_attestation_row"))
        operator_stage_open = _truthy(gap_row.get("operator_fill_required"))
        reviewer_stage_open = _truthy(gap_row.get("reviewer_acceptance_required"))
        attestation_stage_open = _truthy(
            gap_row.get("attestation_row_closure_required")
        )
        source_material_present = not missing_file
        reviewer_acceptance_allowed = bool(
            source_material_present and not operator_stage_open
        )
        attestation_closure_allowed = bool(
            reviewer_acceptance_allowed and not reviewer_stage_open
        )
        ready = _truthy(gap_row.get("production_evidence_closure_ready"))
        if source_material_present and str(gap_row.get("gap_status") or "") == "READY":
            ready = True

        if missing_file or operator_stage_open:
            closure_stage = "WAITING_FOR_REAL_SOURCE_ARTIFACT"
            next_owner = "operator"
        elif reviewer_stage_open:
            closure_stage = "WAITING_FOR_REVIEWER_ACCEPTANCE"
            next_owner = "reviewer"
        elif attestation_stage_open:
            closure_stage = "WAITING_FOR_ATTESTATION_ROW_CLOSURE"
            next_owner = "attestation_closure"
        else:
            closure_stage = "READY_FOR_FINAL_SOURCE_CLOSURE"
            next_owner = "none"

        rows.append(
            {
                "intake_index": index,
                "intake_status": "READY" if ready else "OPEN",
                "closure_stage": closure_stage,
                "request_id": gap_row.get("request_id") or "",
                "slug": gap_row.get("slug") or "",
                "packet_type": gap_row.get("packet_type") or "",
                "artifact_kind": gap_row.get("artifact_kind") or "",
                "expected_path": gap_row.get("expected_path") or "",
                "source_material_present": source_material_present,
                "attestation_row_present": not missing_attestation_row,
                "operator_stage_open": operator_stage_open,
                "reviewer_stage_open": reviewer_stage_open,
                "attestation_stage_open": attestation_stage_open,
                "reviewer_acceptance_allowed": reviewer_acceptance_allowed,
                "attestation_closure_allowed": attestation_closure_allowed,
                "production_evidence_closure_ready": ready,
                "next_owner": next_owner,
                "next_action": gap_row.get("next_action") or "",
                "operator_required_fields": (
                    gap_row.get("required_operator_fields") or ""
                ),
                "reviewer_required_fields": (
                    gap_row.get("required_reviewer_fields") or ""
                ),
                "attestation_required_fields": (
                    gap_row.get("required_attestation_fields") or ""
                ),
                "operator_required_field_count": _as_int(
                    gap_row.get("required_operator_field_count")
                ),
                "reviewer_required_field_count": _as_int(
                    gap_row.get("required_reviewer_field_count")
                ),
                "attestation_required_field_count": _as_int(
                    gap_row.get("required_attestation_field_count")
                ),
                "total_required_field_count": _as_int(
                    gap_row.get("required_field_count")
                ),
                "local_sha256_command": gap_row.get("local_sha256_command") or "",
                "filled_manifest_command": (
                    gap_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    gap_row.get("intake_validation_command") or ""
                ),
                "blocking_reason": gap_row.get("blocking_reason") or "",
                "manual_boundary": (
                    "real closure intake packet only; does not create source "
                    "artifacts, fill attestations, accept reviewer evidence, "
                    "approve, upload, submit, stage, commit, reset, or mutate "
                    "registries"
                ),
            }
        )

    open_rows = [row for row in rows if row.get("intake_status") != "READY"]
    first_open = open_rows[0] if open_rows else {}
    packet_hash = _stable_hash(
        "source_artifact_real_closure_intake_packet",
        {
            "label": label,
            "closure_gap_summary_hash": (
                closure_gap_summary.get("summary_hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "intake_status": row.get("intake_status") or "",
                    "closure_stage": row.get("closure_stage") or "",
                    "next_owner": row.get("next_owner") or "",
                    "total_required_field_count": _as_int(
                        row.get("total_required_field_count")
                    ),
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_real_closure_intake_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows and not open_rows),
        "row_count": len(rows),
        "ready_count": len(rows) - len(open_rows),
        "open_count": len(open_rows),
        "operator_stage_count": sum(
            1 for row in rows if row.get("operator_stage_open")
        ),
        "reviewer_stage_count": sum(
            1 for row in rows if row.get("reviewer_stage_open")
        ),
        "attestation_stage_count": sum(
            1 for row in rows if row.get("attestation_stage_open")
        ),
        "blocked_before_reviewer_count": sum(
            1 for row in rows if not row.get("reviewer_acceptance_allowed")
        ),
        "blocked_before_attestation_count": sum(
            1 for row in rows if not row.get("attestation_closure_allowed")
        ),
        "first_open_path": first_open.get("expected_path") or "",
        "first_next_owner": first_open.get("next_owner") or "",
        "first_next_action": first_open.get("next_action") or "",
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "intake_packet_only": True,
            "derived_from_closure_gap_summary": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_reviewer_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_real_closure_stage_preflight_packet(
    *,
    label: str,
    real_closure_intake_packet: dict,
) -> dict:
    """Explode each source closure row into operator/reviewer/attestation stages."""

    intake_rows = [
        dict(row or {}) for row in (real_closure_intake_packet.get("rows") or [])
    ]
    rows: list[dict] = []

    def add_stage(
        *,
        intake_row: dict,
        intake_index: int,
        stage_owner: str,
        stage_name: str,
        stage_status: str,
        stage_actionable: bool,
        allowed_to_start: bool,
        blocked_by_stage: str,
        required_fields: str,
        required_field_count: int,
        next_action: str,
    ) -> None:
        rows.append(
            {
                "stage_index": len(rows) + 1,
                "intake_index": intake_index,
                "stage_status": stage_status,
                "stage_owner": stage_owner,
                "stage_name": stage_name,
                "request_id": intake_row.get("request_id") or "",
                "slug": intake_row.get("slug") or "",
                "packet_type": intake_row.get("packet_type") or "",
                "artifact_kind": intake_row.get("artifact_kind") or "",
                "expected_path": intake_row.get("expected_path") or "",
                "stage_actionable": stage_actionable,
                "allowed_to_start": allowed_to_start,
                "blocked_by_stage": blocked_by_stage,
                "required_fields": required_fields,
                "required_field_count": required_field_count,
                "source_material_present": _truthy(
                    intake_row.get("source_material_present")
                ),
                "attestation_row_present": _truthy(
                    intake_row.get("attestation_row_present")
                ),
                "production_evidence_closure_ready": _truthy(
                    intake_row.get("production_evidence_closure_ready")
                ),
                "next_action": next_action,
                "local_sha256_command": (
                    intake_row.get("local_sha256_command") or ""
                ),
                "filled_manifest_command": (
                    intake_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    intake_row.get("intake_validation_command") or ""
                ),
                "blocking_reason": intake_row.get("blocking_reason") or "",
                "manual_boundary": (
                    "real closure stage preflight only; does not create source "
                    "artifacts, fill attestations, accept reviewer evidence, "
                    "approve, upload, submit, stage, commit, reset, or mutate "
                    "registries"
                ),
            }
        )

    for intake_index, intake_row in enumerate(intake_rows, start=1):
        operator_open = _truthy(intake_row.get("operator_stage_open"))
        reviewer_open = _truthy(intake_row.get("reviewer_stage_open"))
        attestation_open = _truthy(intake_row.get("attestation_stage_open"))
        reviewer_allowed = _truthy(intake_row.get("reviewer_acceptance_allowed"))
        attestation_allowed = _truthy(intake_row.get("attestation_closure_allowed"))

        add_stage(
            intake_row=intake_row,
            intake_index=intake_index,
            stage_owner="operator",
            stage_name="operator_source_material_and_metadata_fill",
            stage_status="OPEN" if operator_open else "READY",
            stage_actionable=operator_open,
            allowed_to_start=True,
            blocked_by_stage="",
            required_fields=intake_row.get("operator_required_fields") or "",
            required_field_count=_as_int(
                intake_row.get("operator_required_field_count")
            ),
            next_action=(
                (
                    intake_row.get("next_action")
                    or "provide_real_source_artifact_at_expected_path"
                )
                if operator_open
                else ""
            ),
        )

        if reviewer_open and reviewer_allowed:
            reviewer_status = "OPEN"
            reviewer_actionable = True
            reviewer_blocked_by = ""
            reviewer_next_action = "record_reviewer_acceptance_for_real_source"
        elif reviewer_open:
            reviewer_status = "BLOCKED_BEFORE_REVIEWER"
            reviewer_actionable = False
            reviewer_blocked_by = "operator"
            reviewer_next_action = "wait_for_operator_source_material_closure"
        else:
            reviewer_status = "READY"
            reviewer_actionable = False
            reviewer_blocked_by = ""
            reviewer_next_action = ""
        add_stage(
            intake_row=intake_row,
            intake_index=intake_index,
            stage_owner="reviewer",
            stage_name="reviewer_acceptance",
            stage_status=reviewer_status,
            stage_actionable=reviewer_actionable,
            allowed_to_start=reviewer_allowed,
            blocked_by_stage=reviewer_blocked_by,
            required_fields=intake_row.get("reviewer_required_fields") or "",
            required_field_count=_as_int(
                intake_row.get("reviewer_required_field_count")
            ),
            next_action=reviewer_next_action,
        )

        if attestation_open and attestation_allowed:
            attestation_status = "OPEN"
            attestation_actionable = True
            attestation_blocked_by = ""
            attestation_next_action = "record_final_attestation_row_closure"
        elif attestation_open:
            attestation_status = "BLOCKED_BEFORE_ATTESTATION"
            attestation_actionable = False
            attestation_blocked_by = (
                "reviewer" if reviewer_allowed else "operator"
            )
            attestation_next_action = (
                "wait_for_reviewer_acceptance"
                if reviewer_allowed
                else "wait_for_operator_source_material_closure"
            )
        else:
            attestation_status = "READY"
            attestation_actionable = False
            attestation_blocked_by = ""
            attestation_next_action = ""
        add_stage(
            intake_row=intake_row,
            intake_index=intake_index,
            stage_owner="attestation_closure",
            stage_name="attestation_row_closure",
            stage_status=attestation_status,
            stage_actionable=attestation_actionable,
            allowed_to_start=attestation_allowed,
            blocked_by_stage=attestation_blocked_by,
            required_fields=intake_row.get("attestation_required_fields") or "",
            required_field_count=_as_int(
                intake_row.get("attestation_required_field_count")
            ),
            next_action=attestation_next_action,
        )

    open_rows = [row for row in rows if row.get("stage_status") != "READY"]
    actionable_rows = [row for row in rows if row.get("stage_actionable")]
    blocked_rows = [
        row
        for row in rows
        if str(row.get("stage_status") or "").startswith("BLOCKED_")
    ]
    first_actionable = actionable_rows[0] if actionable_rows else {}
    packet_hash = _stable_hash(
        "source_artifact_real_closure_stage_preflight_packet",
        {
            "label": label,
            "real_closure_intake_packet_hash": (
                real_closure_intake_packet.get("packet_hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "stage_owner": row.get("stage_owner") or "",
                    "stage_status": row.get("stage_status") or "",
                    "stage_actionable": bool(row.get("stage_actionable")),
                    "required_field_count": _as_int(
                        row.get("required_field_count")
                    ),
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_real_closure_stage_preflight_packet.v1"
        ),
        "label": label,
        "packet_ready": bool(rows and not open_rows),
        "row_count": len(rows),
        "ready_count": len(rows) - len(open_rows),
        "open_count": len(open_rows),
        "actionable_count": len(actionable_rows),
        "blocked_count": len(blocked_rows),
        "operator_stage_row_count": sum(
            1 for row in rows if row.get("stage_owner") == "operator"
        ),
        "operator_actionable_count": sum(
            1
            for row in actionable_rows
            if row.get("stage_owner") == "operator"
        ),
        "reviewer_stage_row_count": sum(
            1 for row in rows if row.get("stage_owner") == "reviewer"
        ),
        "reviewer_blocked_count": sum(
            1
            for row in blocked_rows
            if row.get("stage_owner") == "reviewer"
        ),
        "attestation_stage_row_count": sum(
            1 for row in rows if row.get("stage_owner") == "attestation_closure"
        ),
        "attestation_blocked_count": sum(
            1
            for row in blocked_rows
            if row.get("stage_owner") == "attestation_closure"
        ),
        "first_actionable_path": first_actionable.get("expected_path") or "",
        "first_actionable_stage": first_actionable.get("stage_name") or "",
        "first_actionable_next_action": first_actionable.get("next_action") or "",
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "stage_preflight_only": True,
            "derived_from_real_closure_intake_packet": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_reviewer_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _source_artifact_real_closure_operator_action_queue(
    *,
    label: str,
    stage_preflight_packet: dict,
) -> dict:
    """Extract the currently actionable operator rows from stage preflight."""

    stage_rows = [
        dict(row or {}) for row in (stage_preflight_packet.get("rows") or [])
    ]
    actionable_operator_rows = [
        row
        for row in stage_rows
        if row.get("stage_owner") == "operator"
        and _truthy(row.get("stage_actionable"))
    ]
    rows: list[dict] = []
    for queue_index, stage_row in enumerate(actionable_operator_rows, start=1):
        rows.append(
            {
                "queue_index": queue_index,
                "stage_index": _as_int(stage_row.get("stage_index")),
                "intake_index": _as_int(stage_row.get("intake_index")),
                "request_id": stage_row.get("request_id") or "",
                "slug": stage_row.get("slug") or "",
                "packet_type": stage_row.get("packet_type") or "",
                "artifact_kind": stage_row.get("artifact_kind") or "",
                "expected_path": stage_row.get("expected_path") or "",
                "required_fields": stage_row.get("required_fields") or "",
                "required_field_count": _as_int(
                    stage_row.get("required_field_count")
                ),
                "next_action": (
                    stage_row.get("next_action")
                    or "provide_real_source_artifact_at_expected_path"
                ),
                "local_sha256_command": (
                    stage_row.get("local_sha256_command") or ""
                ),
                "filled_manifest_command": (
                    stage_row.get("filled_manifest_command") or ""
                ),
                "intake_validation_command": (
                    stage_row.get("intake_validation_command") or ""
                ),
                "blocking_reason": stage_row.get("blocking_reason") or "",
                "manual_boundary": (
                    "operator action queue only; provide real source material "
                    "and metadata, then rerun validation; does not create source "
                    "artifacts, fill attestations, accept reviewer evidence, "
                    "approve, upload, submit, stage, commit, reset, or mutate "
                    "registries"
                ),
            }
        )

    first_row = rows[0] if rows else {}
    packet_hash = _stable_hash(
        "source_artifact_real_closure_operator_action_queue",
        {
            "label": label,
            "stage_preflight_packet_hash": (
                stage_preflight_packet.get("packet_hash") or ""
            ),
            "rows": [
                {
                    "expected_path": row.get("expected_path") or "",
                    "next_action": row.get("next_action") or "",
                    "required_field_count": _as_int(
                        row.get("required_field_count")
                    ),
                }
                for row in rows
            ],
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_real_closure_operator_action_queue.v1"
        ),
        "label": label,
        "queue_ready": not rows,
        "row_count": len(rows),
        "required_field_count": sum(
            _as_int(row.get("required_field_count")) for row in rows
        ),
        "missing_source_count": len(rows),
        "first_expected_path": first_row.get("expected_path") or "",
        "first_request_id": first_row.get("request_id") or "",
        "first_next_action": first_row.get("next_action") or "",
        "packet_hash": packet_hash if rows else "",
        "rows": rows,
        "boundary": {
            "operator_queue_only": True,
            "derived_from_real_closure_stage_preflight_packet": True,
            "does_not_create_source_artifacts": True,
            "does_not_create_attestation_metadata": True,
            "does_not_accept_reviewer_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _real_intake_source_closure_validation(
    real_intake_acceptance_report: dict | None = None,
) -> dict:
    report = real_intake_acceptance_report or {}
    summary = _summary(report)
    packet = report.get("source_artifact_attestation_packet")
    packet = packet if isinstance(packet, dict) else {}
    input_closure_packet = report.get("operator_input_closure_packet")
    input_closure_packet = (
        input_closure_packet if isinstance(input_closure_packet, dict) else {}
    )
    operator_input_template = report.get("operator_input_template")
    operator_input_template = (
        operator_input_template if isinstance(operator_input_template, dict) else {}
    )
    template_json_artifact = (
        operator_input_template.get("template_json_artifact") or {}
        if isinstance(operator_input_template, dict)
        else {}
    )
    fill_template_csv_artifact = (
        operator_input_template.get("fill_template_csv_artifact") or {}
        if isinstance(operator_input_template, dict)
        else {}
    )
    input_discovery = report.get("operator_input_local_candidate_discovery")
    input_discovery = input_discovery if isinstance(input_discovery, dict) else {}
    input_discovery_artifact = (
        input_discovery.get("candidate_discovery_csv_artifact") or {}
    )
    round_trip_packet = report.get("operator_input_round_trip_packet")
    round_trip_packet = (
        round_trip_packet if isinstance(round_trip_packet, dict) else {}
    )
    round_trip_action_artifact = (
        round_trip_packet.get("action_csv_artifact") or {}
    )
    round_trip_json_artifact = (
        round_trip_packet.get("packet_json_artifact") or {}
    )
    round_trip_status_packet = report.get("operator_input_round_trip_status_packet")
    round_trip_status_packet = (
        round_trip_status_packet
        if isinstance(round_trip_status_packet, dict)
        else {}
    )
    round_trip_status_csv_artifact = (
        round_trip_status_packet.get("status_csv_artifact") or {}
    )
    round_trip_status_json_artifact = (
        round_trip_status_packet.get("status_json_artifact") or {}
    )
    input_filled_preflight = report.get("operator_input_filled_preflight")
    input_filled_preflight = (
        input_filled_preflight if isinstance(input_filled_preflight, dict) else {}
    )
    input_filled_preflight_csv_artifact = (
        input_filled_preflight.get("preflight_csv_artifact") or {}
    )
    input_filled_preflight_json_artifact = (
        input_filled_preflight.get("preflight_json_artifact") or {}
    )
    input_filled_preflight_reported = (
        "operator_input_filled_preflight_ready" in summary
        or "operator_input_filled_preflight_row_count" in summary
        or bool(input_filled_preflight)
    )
    input_filled_preflight_ready = bool(
        (
            summary.get("operator_input_filled_preflight_ready")
            if "operator_input_filled_preflight_ready" in summary
            else input_filled_preflight.get("preflight_ready")
        )
        if input_filled_preflight_reported
        else True
    )
    status = _status(report)
    required = bool(
        summary.get("source_artifact_operator_closure_csv_required")
        or summary.get("source_artifact_operator_closure_expected_row_count")
        or summary.get("source_artifact_operator_closure_csv_path")
    )
    closure_ready = bool(summary.get("source_artifact_operator_closure_csv_ready"))
    expected_rows = _as_int(
        summary.get("source_artifact_operator_closure_expected_row_count")
    )
    row_count = _as_int(summary.get("source_artifact_operator_closure_row_count"))
    ready = bool(
        required
        and closure_ready
        and expected_rows > 0
        and row_count >= expected_rows
        and summary.get("source_artifact_operator_closure_csv_sha256_match") is True
        and summary.get("source_artifact_operator_closure_csv_shape_ready") is True
        and (
            summary.get("source_artifact_attestation_packet_ready") is True
            or packet.get("packet_ready") is True
        )
        and input_filled_preflight_ready
    )
    return {
        "ready": ready,
        "status": status,
        "state": report.get("submission_evidence_real_intake_acceptance_state") or "",
        "operator_input_expected_count": _as_int(
            summary.get("operator_input_file_expected_count")
        ),
        "operator_input_present_count": _as_int(
            summary.get("operator_input_file_present_count")
        ),
        "operator_input_missing_count": _as_int(
            summary.get("operator_input_file_missing_count")
        ),
        "operator_input_closure_packet_ready": bool(
            summary.get("operator_input_closure_packet_ready")
            or input_closure_packet.get("packet_ready")
        ),
        "operator_input_closure_packet_required_count": _as_int(
            summary.get("operator_input_closure_packet_required_count")
            or input_closure_packet.get("required_count")
        ),
        "operator_input_closure_packet_satisfied_count": _as_int(
            summary.get("operator_input_closure_packet_satisfied_count")
            or input_closure_packet.get("satisfied_count")
        ),
        "operator_input_closure_packet_open_count": _as_int(
            summary.get("operator_input_closure_packet_open_count")
            or input_closure_packet.get("open_count")
        ),
        "operator_input_closure_packet_missing_file_count": _as_int(
            summary.get("operator_input_closure_packet_missing_file_count")
            or input_closure_packet.get("missing_file_count")
        ),
        "operator_input_closure_packet_first_open_path": (
            summary.get("operator_input_closure_packet_first_open_path")
            or input_closure_packet.get("first_open_path")
            or ""
        ),
        "operator_input_closure_packet_hash": (
            summary.get("operator_input_closure_packet_hash")
            or input_closure_packet.get("packet_hash")
            or ""
        ),
        "operator_input_template_ready": bool(
            summary.get("operator_input_template_ready")
            or operator_input_template.get("template_ready")
        ),
        "operator_input_template_required_count": _as_int(
            summary.get("operator_input_template_required_count")
            or operator_input_template.get("required_count")
        ),
        "operator_input_template_row_count": _as_int(
            summary.get("operator_input_template_row_count")
            or operator_input_template.get("row_count")
        ),
        "operator_input_template_hash": (
            summary.get("operator_input_template_hash")
            or operator_input_template.get("template_hash")
            or ""
        ),
        "operator_input_template_json_path": (
            summary.get("operator_input_template_json_path")
            or template_json_artifact.get("path")
            or ""
        ),
        "operator_input_template_json_sha256": (
            summary.get("operator_input_template_json_sha256")
            or template_json_artifact.get("sha256")
            or ""
        ),
        "operator_input_fill_template_csv_path": (
            summary.get("operator_input_fill_template_csv_path")
            or fill_template_csv_artifact.get("path")
            or ""
        ),
        "operator_input_fill_template_csv_sha256": (
            summary.get("operator_input_fill_template_csv_sha256")
            or fill_template_csv_artifact.get("sha256")
            or ""
        ),
        "operator_input_fill_template_csv_row_count": _as_int(
            summary.get("operator_input_fill_template_csv_row_count")
            or fill_template_csv_artifact.get("row_count")
        ),
        "operator_input_local_candidate_discovery_csv_path": (
            summary.get("operator_input_local_candidate_discovery_csv_path")
            or input_discovery_artifact.get("path")
            or ""
        ),
        "operator_input_local_candidate_discovery_csv_sha256": (
            summary.get("operator_input_local_candidate_discovery_csv_sha256")
            or input_discovery_artifact.get("sha256")
            or ""
        ),
        "operator_input_local_candidate_discovery_csv_row_count": _as_int(
            summary.get("operator_input_local_candidate_discovery_csv_row_count")
            or input_discovery_artifact.get("row_count")
        ),
        "operator_input_local_candidate_discovery_expected_count": _as_int(
            summary.get("operator_input_local_candidate_discovery_expected_count")
            or input_discovery.get("expected_count")
        ),
        "operator_input_local_candidate_discovery_candidate_count": _as_int(
            summary.get("operator_input_local_candidate_discovery_candidate_count")
            or input_discovery.get("candidate_count")
        ),
        "operator_input_local_candidate_discovery_with_candidates_count": _as_int(
            summary.get(
                "operator_input_local_candidate_discovery_with_candidates_count"
            )
            or input_discovery.get("with_candidates_count")
        ),
        "operator_input_local_candidate_discovery_first_unresolved_path": (
            summary.get(
                "operator_input_local_candidate_discovery_first_unresolved_path"
            )
            or input_discovery.get("first_unresolved_path")
            or ""
        ),
        "operator_input_local_candidate_discovery_first_candidate_path": (
            summary.get(
                "operator_input_local_candidate_discovery_first_candidate_path"
            )
            or input_discovery.get("first_candidate_path")
            or ""
        ),
        "operator_input_local_candidate_discovery_scanned_file_count": _as_int(
            summary.get(
                "operator_input_local_candidate_discovery_scanned_file_count"
            )
            or input_discovery.get("scanned_file_count")
        ),
        "operator_input_local_candidate_discovery_complete": bool(
            summary.get("operator_input_local_candidate_discovery_complete")
            or input_discovery.get("scan_complete")
        ),
        "operator_input_local_candidate_discovery_hash": (
            summary.get("operator_input_local_candidate_discovery_hash")
            or input_discovery.get("hash")
            or ""
        ),
        "operator_input_round_trip_packet_ready": bool(
            summary.get("operator_input_round_trip_packet_ready")
            or round_trip_packet.get("packet_ready")
        ),
        "operator_input_round_trip_packet_row_count": _as_int(
            summary.get("operator_input_round_trip_packet_row_count")
            or round_trip_packet.get("row_count")
        ),
        "operator_input_round_trip_packet_open_count": _as_int(
            summary.get("operator_input_round_trip_packet_open_count")
            or round_trip_packet.get("open_count")
        ),
        "operator_input_round_trip_packet_candidate_count": _as_int(
            summary.get("operator_input_round_trip_packet_candidate_count")
            or round_trip_packet.get("candidate_count")
        ),
        "operator_input_round_trip_packet_with_candidates_count": _as_int(
            summary.get("operator_input_round_trip_packet_with_candidates_count")
            or round_trip_packet.get("with_candidates_count")
        ),
        "operator_input_round_trip_packet_first_open_path": (
            summary.get("operator_input_round_trip_packet_first_open_path")
            or round_trip_packet.get("first_open_path")
            or ""
        ),
        "operator_input_round_trip_packet_hash": (
            summary.get("operator_input_round_trip_packet_hash")
            or round_trip_packet.get("packet_hash")
            or ""
        ),
        "operator_input_round_trip_packet_path": (
            summary.get("operator_input_round_trip_packet_path")
            or round_trip_json_artifact.get("path")
            or ""
        ),
        "operator_input_round_trip_packet_sha256": (
            summary.get("operator_input_round_trip_packet_sha256")
            or round_trip_json_artifact.get("sha256")
            or ""
        ),
        "operator_input_round_trip_action_csv_path": (
            summary.get("operator_input_round_trip_action_csv_path")
            or round_trip_action_artifact.get("path")
            or ""
        ),
        "operator_input_round_trip_action_csv_sha256": (
            summary.get("operator_input_round_trip_action_csv_sha256")
            or round_trip_action_artifact.get("sha256")
            or ""
        ),
        "operator_input_round_trip_action_csv_row_count": _as_int(
            summary.get("operator_input_round_trip_action_csv_row_count")
            or round_trip_action_artifact.get("row_count")
        ),
        "operator_input_round_trip_status_packet_ready": bool(
            summary.get("operator_input_round_trip_status_packet_ready")
            or round_trip_status_packet.get("packet_ready")
        ),
        "operator_input_round_trip_status_row_count": _as_int(
            summary.get("operator_input_round_trip_status_row_count")
            or round_trip_status_packet.get("row_count")
        ),
        "operator_input_round_trip_status_local_ready_count": _as_int(
            summary.get("operator_input_round_trip_status_local_ready_count")
            or round_trip_status_packet.get("local_ready_count")
        ),
        "operator_input_round_trip_status_missing_count": _as_int(
            summary.get("operator_input_round_trip_status_missing_count")
            or round_trip_status_packet.get("missing_count")
        ),
        "operator_input_round_trip_status_shape_ready_count": _as_int(
            summary.get("operator_input_round_trip_status_shape_ready_count")
            or round_trip_status_packet.get("shape_ready_count")
        ),
        "operator_input_round_trip_status_shape_invalid_count": _as_int(
            summary.get("operator_input_round_trip_status_shape_invalid_count")
            or round_trip_status_packet.get("shape_invalid_count")
        ),
        "operator_input_round_trip_status_first_unready_path": (
            summary.get("operator_input_round_trip_status_first_unready_path")
            or round_trip_status_packet.get("first_unready_path")
            or ""
        ),
        "operator_input_round_trip_status_hash": (
            summary.get("operator_input_round_trip_status_hash")
            or round_trip_status_packet.get("status_hash")
            or ""
        ),
        "operator_input_round_trip_status_csv_path": (
            summary.get("operator_input_round_trip_status_csv_path")
            or round_trip_status_csv_artifact.get("path")
            or ""
        ),
        "operator_input_round_trip_status_csv_sha256": (
            summary.get("operator_input_round_trip_status_csv_sha256")
            or round_trip_status_csv_artifact.get("sha256")
            or ""
        ),
        "operator_input_round_trip_status_json_path": (
            summary.get("operator_input_round_trip_status_json_path")
            or round_trip_status_json_artifact.get("path")
            or ""
        ),
        "operator_input_round_trip_status_json_sha256": (
            summary.get("operator_input_round_trip_status_json_sha256")
            or round_trip_status_json_artifact.get("sha256")
            or ""
        ),
        "operator_input_filled_preflight_ready": input_filled_preflight_ready,
        "operator_input_filled_preflight_row_count": _as_int(
            summary.get("operator_input_filled_preflight_row_count")
            or input_filled_preflight.get("row_count")
        ),
        "operator_input_filled_preflight_expected_count": _as_int(
            summary.get("operator_input_filled_preflight_expected_count")
            or input_filled_preflight.get("expected_count")
        ),
        "operator_input_filled_preflight_ready_count": _as_int(
            summary.get("operator_input_filled_preflight_ready_count")
            or input_filled_preflight.get("ready_count")
        ),
        "operator_input_filled_preflight_open_count": _as_int(
            summary.get("operator_input_filled_preflight_open_count")
            or input_filled_preflight.get("open_count")
        ),
        "operator_input_filled_preflight_missing_count": _as_int(
            summary.get("operator_input_filled_preflight_missing_count")
            or input_filled_preflight.get("missing_count")
        ),
        "operator_input_filled_preflight_shape_invalid_count": _as_int(
            summary.get("operator_input_filled_preflight_shape_invalid_count")
            or input_filled_preflight.get("shape_invalid_count")
        ),
        "operator_input_filled_preflight_first_open_path": (
            summary.get("operator_input_filled_preflight_first_open_path")
            or input_filled_preflight.get("first_open_path")
            or ""
        ),
        "operator_input_filled_preflight_hash": (
            summary.get("operator_input_filled_preflight_hash")
            or input_filled_preflight.get("preflight_hash")
            or ""
        ),
        "operator_input_filled_preflight_csv_path": (
            summary.get("operator_input_filled_preflight_csv_path")
            or input_filled_preflight_csv_artifact.get("path")
            or ""
        ),
        "operator_input_filled_preflight_csv_sha256": (
            summary.get("operator_input_filled_preflight_csv_sha256")
            or input_filled_preflight_csv_artifact.get("sha256")
            or ""
        ),
        "operator_input_filled_preflight_json_path": (
            summary.get("operator_input_filled_preflight_json_path")
            or input_filled_preflight_json_artifact.get("path")
            or ""
        ),
        "operator_input_filled_preflight_json_sha256": (
            summary.get("operator_input_filled_preflight_json_sha256")
            or input_filled_preflight_json_artifact.get("sha256")
            or ""
        ),
        "closure_required": required,
        "closure_ready": closure_ready,
        "closure_expected_row_count": expected_rows,
        "closure_row_count": row_count,
        "closure_csv_path": summary.get("source_artifact_operator_closure_csv_path")
        or "",
        "closure_csv_sha256_match": bool(
            summary.get("source_artifact_operator_closure_csv_sha256_match")
        ),
        "closure_csv_shape_ready": bool(
            summary.get("source_artifact_operator_closure_csv_shape_ready")
        ),
        "attestation_packet_ready": bool(
            summary.get("source_artifact_attestation_packet_ready")
            or packet.get("packet_ready")
        ),
        "attestation_packet_required_row_count": _as_int(
            summary.get("source_artifact_attestation_packet_required_row_count")
            or packet.get("required_row_count")
        ),
        "attestation_packet_row_count": _as_int(
            summary.get("source_artifact_attestation_packet_row_count")
            or packet.get("row_count")
        ),
        "attestation_packet_closure_row_count": _as_int(
            summary.get("source_artifact_attestation_packet_closure_row_count")
            or packet.get("closure_row_count")
        ),
        "attestation_packet_closure_matched_count": _as_int(
            summary.get("source_artifact_attestation_packet_closure_matched_count")
            or packet.get("closure_matched_count")
        ),
        "attestation_packet_closure_missing_count": _as_int(
            summary.get("source_artifact_attestation_packet_closure_missing_count")
            or packet.get("closure_missing_count")
        ),
        "attestation_packet_manifest_path": (
            summary.get("source_artifact_attestation_packet_manifest_path")
            or packet.get("attestation_manifest_path")
            or ""
        ),
        "attestation_packet_operator_input_missing_count": _as_int(
            summary.get(
                "source_artifact_attestation_packet_operator_input_missing_count"
            )
            or packet.get("operator_input_missing_count")
        ),
        "attestation_packet_hash": (
            summary.get("source_artifact_attestation_packet_hash")
            or packet.get("packet_hash")
            or ""
        ),
        "attestation_checklist_csv_path": (
            summary.get("source_artifact_attestation_checklist_csv_path")
            or (packet.get("checklist_csv_artifact") or {}).get("path")
            or ""
        ),
        "attestation_checklist_csv_sha256": (
            summary.get("source_artifact_attestation_checklist_csv_sha256")
            or (packet.get("checklist_csv_artifact") or {}).get("sha256")
            or ""
        ),
        "attestation_checklist_csv_row_count": _as_int(
            summary.get("source_artifact_attestation_checklist_csv_row_count")
            or (packet.get("checklist_csv_artifact") or {}).get("row_count")
        ),
        "attestation_present": bool(summary.get("attestation_present")),
        "failed_check_count": _as_int(summary.get("failed_check_count")),
    }


def _field_matches(payload: dict, field: dict) -> tuple[bool, str]:
    name = field.get("name")
    if not name:
        return True, ""
    value = payload.get(name)
    if value in (None, ""):
        return False, f"{name}:missing"
    required = field.get("required_value")
    if str(name).endswith("sha256"):
        return (_hex_sha256(value), f"{name}:not_sha256")
    if str(name).endswith("hash_bound") or str(name).endswith("reference_hash_bound"):
        return (value is True, f"{name}:not_true")
    if required is not None and not _placeholder_value(required) and value != required:
        return False, f"{name}:value_mismatch"
    return True, ""


def _shape_check(
    *,
    payload: dict | None,
    required_fields: list[dict],
    request_id,
    slug: str,
    packet_type: str,
    kind: str,
) -> tuple[bool, list[str]]:
    if not isinstance(payload, dict):
        return False, ["json_payload_not_object"]
    issues: list[str] = []
    for field in required_fields:
        ok, issue = _field_matches(payload, field if isinstance(field, dict) else {})
        if not ok:
            issues.append(issue)
    if payload.get("request_id") != request_id:
        issues.append("request_id_mismatch")
    if payload.get("slug") != slug:
        issues.append("slug_mismatch")
    if payload.get("packet_type") != packet_type:
        issues.append("packet_type_mismatch")
    if payload.get("external_action_authorized") is True:
        issues.append("external_action_authorized_true")
    if payload.get("external_action_performed") is True:
        issues.append("external_action_performed_true")
    if kind == "redrive_receipt" and payload.get("receipt_creation_authorized") is True:
        issues.append("receipt_creation_authorized_true")
    return not issues, issues


def _artifact_status(
    *,
    root: Path,
    expected_path: str,
    kind: str,
    required_fields: list[dict],
    request_id,
    slug: str,
    packet_type: str,
) -> dict:
    expected_path = str(expected_path or "")
    expected = bool(expected_path)
    path = Path(expected_path)
    absolute_issue = path.is_absolute()
    full_path = path if absolute_issue else root / path
    repair_root = (root / REPAIR_SOURCE_ROOT).resolve()
    exists = bool(expected and full_path.exists())
    is_file = bool(exists and full_path.is_file())
    is_symlink = bool(exists and full_path.is_symlink())
    byte_count = full_path.stat().st_size if is_file else 0
    nonempty = bool(is_file and byte_count > 0)
    identity_issues: list[str] = []
    resolved_path = ""
    inside_root = False
    if not expected:
        identity_issues.append("expected_path_missing")
    if absolute_issue:
        identity_issues.append("expected_path_absolute")
    if exists:
        try:
            resolved = full_path.resolve()
            resolved_path = str(resolved)
            inside_root = _inside_root(resolved, repair_root)
        except Exception:
            resolved_path = ""
            inside_root = False
            identity_issues.append("resolve_failed")
        if not is_file:
            identity_issues.append("not_regular_file")
        if is_symlink:
            identity_issues.append("symlink_not_allowed")
        if not inside_root:
            identity_issues.append("outside_repair_source_root")
    identity_ready = bool(nonempty and not identity_issues)
    resource_issues = []
    if identity_ready and byte_count > MAX_ARTIFACT_BYTES:
        resource_issues.append("artifact_too_large")
    resource_ready = bool(identity_ready and not resource_issues)
    sha256 = ""
    stable = True
    stability_issues = []
    if resource_ready:
        try:
            sha256, stable = _sha256_file(full_path)
            if not stable:
                stability_issues.append("file_changed_during_hash")
                sha256 = ""
        except Exception as exc:
            stable = False
            stability_issues.append(f"hash_failed:{type(exc).__name__}")
    stability_ready = bool(resource_ready and stable and not stability_issues)
    shape_issues = []
    shape_ready = False
    if stability_ready:
        try:
            payload = json.loads(full_path.read_text(encoding="utf-8"))
            shape_ready, shape_issues = _shape_check(
                payload=payload,
                required_fields=required_fields,
                request_id=request_id,
                slug=slug,
                packet_type=packet_type,
                kind=kind,
            )
        except Exception as exc:
            shape_issues = [f"json_parse_failed:{type(exc).__name__}"]
    valid = bool(shape_ready and not shape_issues)
    return {
        "artifact_kind": kind,
        "expected_path": expected_path,
        "expected": expected,
        "exists": exists,
        "is_file": is_file,
        "is_symlink": is_symlink,
        "resolved_path": resolved_path,
        "inside_repair_source_root": inside_root if exists else False,
        "byte_count": byte_count,
        "nonempty": nonempty,
        "sha256": sha256,
        "identity_ready": identity_ready or not nonempty,
        "identity_issues": identity_issues,
        "resource_ready": resource_ready or not identity_ready,
        "resource_issues": resource_issues,
        "stability_ready": stability_ready or not resource_ready,
        "stability_issues": stability_issues,
        "shape_ready": shape_ready or not stability_ready,
        "shape_issues": shape_issues,
        "valid_evidence": valid,
        "external_action_authorized": False,
        "external_action_performed": False,
    }


def _normalise_manifest_path(root: Path, path_text: str) -> str:
    path_text = str(path_text or "").strip()
    if not path_text:
        return ""
    path = Path(path_text)
    if path.is_absolute():
        try:
            return str(path.relative_to(root))
        except ValueError:
            return str(path)
    return path_text


def _source_artifact_attestation_manifest_binding(
    *,
    root: Path,
    attestation_validation: dict,
    source_artifact_attestation_report: dict | None,
    source_artifact_attestation_ref: dict | None,
    real_intake_validation: dict,
) -> dict:
    report = source_artifact_attestation_report or {}
    ref = source_artifact_attestation_ref or {}
    attestation_source = attestation_validation.get("source") or "missing"
    manifest_path = ""
    manifest_sha256 = ""
    if attestation_source == "remaining_input_autopilot":
        artifact = report.get("attestation_artifact") or {}
        if isinstance(artifact, dict):
            manifest_path = artifact.get("path") or ""
            manifest_sha256 = artifact.get("sha256") or ""
    elif attestation_source == "attestation_manifest":
        manifest_path = ref.get("path") or ""
        manifest_sha256 = ref.get("sha256") or ""

    real_intake_manifest_path = (
        real_intake_validation.get("attestation_packet_manifest_path") or ""
    )
    normalised_manifest_path = _normalise_manifest_path(root, manifest_path)
    normalised_real_intake_path = _normalise_manifest_path(
        root,
        real_intake_manifest_path,
    )
    manifest_row_count = _as_int(attestation_validation.get("row_count"))
    real_intake_packet_row_count = _as_int(
        real_intake_validation.get("attestation_packet_row_count")
    )
    required = bool(
        attestation_source != "missing"
        or manifest_row_count
        or real_intake_manifest_path
        or real_intake_packet_row_count
    )
    path_match = bool(
        normalised_manifest_path
        and normalised_real_intake_path
        and normalised_manifest_path == normalised_real_intake_path
    )
    row_count_match = bool(
        manifest_row_count
        and real_intake_packet_row_count
        and manifest_row_count == real_intake_packet_row_count
    )
    sha_valid = bool(not manifest_sha256 or _hex_sha256(manifest_sha256))
    issues = []
    if required and not manifest_path:
        issues.append("attestation_manifest_path_missing")
    if required and not real_intake_manifest_path:
        issues.append("real_intake_attestation_manifest_path_missing")
    if required and manifest_path and real_intake_manifest_path and not path_match:
        issues.append("attestation_manifest_path_mismatch")
    if required and not row_count_match:
        issues.append("attestation_manifest_row_count_mismatch")
    if manifest_sha256 and not sha_valid:
        issues.append("attestation_manifest_sha256_invalid")
    bound = bool((not required) or (path_match and row_count_match and sha_valid))
    binding_hash = _stable_hash(
        "source_artifact_attestation_manifest_binding",
        {
            "source": attestation_source,
            "manifest_path": normalised_manifest_path,
            "manifest_sha256": manifest_sha256,
            "real_intake_manifest_path": normalised_real_intake_path,
            "manifest_row_count": manifest_row_count,
            "real_intake_packet_row_count": real_intake_packet_row_count,
            "issues": issues,
        },
    )
    return {
        "schema_id": (
            "paper_factory.paper_production."
            "source_artifact_attestation_manifest_binding.v1"
        ),
        "bound_to_real_intake": bound,
        "binding_required": required,
        "attestation_source": attestation_source,
        "manifest_path": normalised_manifest_path,
        "manifest_sha256": manifest_sha256,
        "real_intake_manifest_path": normalised_real_intake_path,
        "path_match": path_match,
        "manifest_row_count": manifest_row_count,
        "real_intake_packet_row_count": real_intake_packet_row_count,
        "row_count_match": row_count_match,
        "issues": issues,
        "issue_count": len(issues),
        "binding_hash": binding_hash,
        "boundary": {
            "binding_check_only": True,
            "does_not_create_attestation_manifest": True,
            "does_not_accept_evidence": True,
            "does_not_authorize_external_action": True,
        },
    }


def _receipt_fields(record: dict) -> list[dict]:
    return [
        {"name": "schema_id", "required": True},
        {"name": "request_id", "required": True, "required_value": record.get("request_id")},
        {"name": "slug", "required": True, "required_value": record.get("slug")},
        {"name": "packet_type", "required": True, "required_value": record.get("packet_type")},
        {"name": "source_packet_sha256", "required": True, "required_value": "sha256 of real source packet"},
        {"name": "operator_intake_packet_sha256", "required": True, "required_value": "sha256 of real operator intake packet"},
    ]


def _record_status(root: Path, record: dict) -> dict:
    source_fields = (record.get("source_packet_authoring_contract") or {}).get("required_fields") or []
    operator_fields = (record.get("operator_intake_authoring_contract") or {}).get("required_fields") or []
    request_id = record.get("request_id")
    slug = record.get("slug") or ""
    packet_type = record.get("packet_type") or ""
    artifacts = {
        "source_packet": _artifact_status(
            root=root,
            expected_path=record.get("expected_packet_path") or "",
            kind="source_packet",
            required_fields=source_fields,
            request_id=request_id,
            slug=slug,
            packet_type=packet_type,
        ),
        "operator_intake_packet": _artifact_status(
            root=root,
            expected_path=record.get("expected_operator_real_source_intake_path") or "",
            kind="operator_intake_packet",
            required_fields=operator_fields,
            request_id=request_id,
            slug=slug,
            packet_type=packet_type,
        ),
        "redrive_receipt": _artifact_status(
            root=root,
            expected_path=record.get("expected_redrive_execution_receipt_path") or "",
            kind="redrive_receipt",
            required_fields=_receipt_fields(record),
            request_id=request_id,
            slug=slug,
            packet_type=packet_type,
        ),
    }
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "source_authoring_surface_id": record.get("source_authoring_surface_id") or "",
        "artifacts": artifacts,
        "source_packet_valid": artifacts["source_packet"]["valid_evidence"],
        "operator_intake_packet_valid": artifacts["operator_intake_packet"]["valid_evidence"],
        "redrive_receipt_valid": artifacts["redrive_receipt"]["valid_evidence"],
        "all_artifacts_valid": all(item["valid_evidence"] for item in artifacts.values()),
        "external_action_authorized": False,
        "external_action_performed": False,
    }


def build_referee_repair_source_artifact_intake_queue(
    source_authoring_surface_report: dict | None = None,
    source_authoring_surface_ref: dict | None = None,
    source_artifact_attestation_report: dict | None = None,
    source_artifact_attestation_ref: dict | None = None,
    real_intake_acceptance_report: dict | None = None,
    real_intake_acceptance_ref: dict | None = None,
    target_scope_report: dict | None = None,
    target_scope_ref: dict | None = None,
    upstream_refs: dict | None = None,
    label: str = "",
    root: str | Path = ".",
    created_at: str | None = None,
) -> dict:
    root = Path(root)
    report = dict(source_authoring_surface_report or {})
    ref = dict(source_authoring_surface_ref or {})
    upstream_refs = dict(upstream_refs or {})
    if ref:
        upstream_refs.setdefault(
            "paper_production_referee_repair_source_authoring_surface_matrix",
            ref,
        )
    if source_artifact_attestation_ref:
        upstream_refs.setdefault(
            "paper_production_remaining_input_autopilot",
            source_artifact_attestation_ref,
        )
    if real_intake_acceptance_ref:
        upstream_refs.setdefault(
            "paper_production_submission_evidence_real_intake_acceptance_gate",
            real_intake_acceptance_ref,
        )
    if target_scope_ref:
        upstream_refs.setdefault("paper_production_target_scope_audit", target_scope_ref)
    target_scope = _target_scope_validation(target_scope_report, target_scope_ref)
    target_scope_ready = bool(target_scope.get("ready"))
    summary = _summary(report)
    authoring_status = _status(report, ref)
    authoring_state = report.get("referee_repair_source_authoring_surface_state") or ""
    authoring_ready = bool(
        authoring_status == PASS and summary.get("source_authoring_surface_ready")
    )
    records = [
        _record_status(root, dict(record or {}))
        for record in report.get("source_authoring_surface_records") or []
    ]
    artifacts = [
        artifact
        for record in records
        for artifact in (record.get("artifacts") or {}).values()
    ]
    expected = [artifact for artifact in artifacts if artifact.get("expected")]
    present = [artifact for artifact in expected if artifact.get("nonempty")]
    valid = [artifact for artifact in expected if artifact.get("valid_evidence")]
    missing = [artifact for artifact in expected if not artifact.get("nonempty")]
    identity_invalid = [
        artifact
        for artifact in expected
        if artifact.get("nonempty") and artifact.get("identity_issues")
    ]
    resource_invalid = [
        artifact
        for artifact in expected
        if artifact.get("identity_ready") and artifact.get("resource_issues")
    ]
    stability_unstable = [
        artifact
        for artifact in expected
        if artifact.get("resource_ready") and artifact.get("stability_issues")
    ]
    shape_invalid = [
        artifact
        for artifact in expected
        if artifact.get("stability_ready") and artifact.get("shape_issues")
    ]
    source_artifacts = [record["artifacts"]["source_packet"] for record in records]
    operator_artifacts = [record["artifacts"]["operator_intake_packet"] for record in records]
    receipt_artifacts = [record["artifacts"]["redrive_receipt"] for record in records]
    attestation_validation = _validate_source_artifact_attestations(
        records,
        source_artifact_attestation_report,
    )
    real_intake_validation = _real_intake_source_closure_validation(
        real_intake_acceptance_report,
    )
    checklist_validation = _validate_source_artifact_attestation_checklist(
        records,
        real_intake_acceptance_report,
    )
    attestation_manifest_binding = (
        _source_artifact_attestation_manifest_binding(
            root=root,
            attestation_validation=attestation_validation,
            source_artifact_attestation_report=source_artifact_attestation_report,
            source_artifact_attestation_ref=source_artifact_attestation_ref,
            real_intake_validation=real_intake_validation,
        )
    )
    forbidden_count = sum(
        1
        for item in [report] + records + artifacts
        if isinstance(item, dict)
        and (
            item.get("external_action_authorized") is True
            or item.get("external_action_performed") is True
        )
    )
    queue_ready = bool(
        target_scope_ready
        and authoring_ready
        and expected
        and len(valid) == len(expected)
        and real_intake_validation.get("ready")
        and attestation_manifest_binding.get("bound_to_real_intake")
        and attestation_validation.get("ready")
        and checklist_validation.get("ready")
        and forbidden_count == 0
    )
    checks: list[dict] = []
    if target_scope.get("enforced"):
        _add_check(
            checks,
            "canonical_target_scope_ready",
            target_scope_ready,
            (
                f"status={target_scope.get('status') or 'MISSING'} "
                f"state={target_scope.get('state') or '-'} "
                f"papers={target_scope.get('target_paper_count', 0)} "
                f"slugs={target_scope.get('scoped_slug_count', 0)} "
                f"hash={target_scope.get('target_slug_set_hash') or '-'}"
            ),
        )
    _add_check(
        checks,
        "source_authoring_surface_ready",
        authoring_ready,
        f"status={authoring_status} state={authoring_state or '-'}",
    )
    _add_check(
        checks,
        "all_expected_source_artifacts_present",
        not missing and bool(expected),
        f"missing={len(missing)} expected={len(expected)}",
    )
    _add_check(
        checks,
        "all_source_artifact_paths_identity_safe",
        not identity_invalid,
        f"invalid={len(identity_invalid)}",
    )
    _add_check(
        checks,
        "all_source_artifacts_within_resource_limits",
        not resource_invalid,
        f"invalid={len(resource_invalid)} max_bytes={MAX_ARTIFACT_BYTES}",
    )
    _add_check(
        checks,
        "all_source_artifacts_stable_during_hash",
        not stability_unstable,
        f"unstable={len(stability_unstable)}",
    )
    _add_check(
        checks,
        "all_source_artifacts_shape_valid",
        not shape_invalid and bool(expected),
        f"invalid={len(shape_invalid)}",
    )
    _add_check(
        checks,
        "source_artifact_operator_closure_verified_by_real_intake",
        bool(real_intake_validation.get("ready")),
        (
            f"status={real_intake_validation.get('status') or 'MISSING'} "
            f"state={real_intake_validation.get('state') or '-'} "
            f"inputs={real_intake_validation.get('operator_input_present_count', 0)}/"
            f"{real_intake_validation.get('operator_input_expected_count', 0)} "
            f"input_missing={real_intake_validation.get('operator_input_missing_count', 0)} "
            f"closure_ready={real_intake_validation.get('closure_ready')} "
            f"rows={real_intake_validation.get('closure_row_count', 0)}/"
            f"{real_intake_validation.get('closure_expected_row_count', 0)} "
            f"sha_match={real_intake_validation.get('closure_csv_sha256_match')} "
            f"shape={real_intake_validation.get('closure_csv_shape_ready')} "
            f"packet={real_intake_validation.get('attestation_packet_ready')} "
            f"packet_rows={real_intake_validation.get('attestation_packet_row_count', 0)}/"
            f"{real_intake_validation.get('attestation_packet_required_row_count', 0)} "
            f"packet_closure_matched="
            f"{real_intake_validation.get('attestation_packet_closure_matched_count', 0)}/"
            f"{real_intake_validation.get('attestation_packet_required_row_count', 0)} "
            f"attestation={real_intake_validation.get('attestation_present')}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_attestation_manifest_bound_to_real_intake",
        bool(attestation_manifest_binding.get("bound_to_real_intake")),
        (
            f"source={attestation_manifest_binding.get('attestation_source') or 'missing'} "
            f"manifest={attestation_manifest_binding.get('manifest_path') or '-'} "
            f"real_intake_manifest="
            f"{attestation_manifest_binding.get('real_intake_manifest_path') or '-'} "
            f"path_match={attestation_manifest_binding.get('path_match')} "
            f"rows={attestation_manifest_binding.get('manifest_row_count', 0)}/"
            f"{attestation_manifest_binding.get('real_intake_packet_row_count', 0)} "
            f"row_count_match={attestation_manifest_binding.get('row_count_match')} "
            f"issues={';'.join(attestation_manifest_binding.get('issues') or []) or '-'}"
        ),
    )
    _add_check(
        checks,
        "all_source_artifacts_attested_with_matching_sha",
        bool(attestation_validation.get("ready")),
        (
            f"matched={attestation_validation.get('matched_count', 0)}/"
            f"{attestation_validation.get('required_count', 0)} "
            f"missing={attestation_validation.get('missing_count', 0)} "
            f"sha_invalid={attestation_validation.get('sha_invalid_count', 0)} "
            f"sha_mismatch={attestation_validation.get('sha_mismatch_count', 0)} "
            f"sha_unavailable={attestation_validation.get('sha_unavailable_count', 0)} "
            f"metadata_missing={attestation_validation.get('metadata_missing_count', 0)} "
            f"source={attestation_validation.get('source') or 'missing'}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_attestation_checklist_binds_each_local_artifact",
        bool(checklist_validation.get("ready")),
        (
            f"matched={checklist_validation.get('matched_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"rows={checklist_validation.get('row_count', 0)} "
            f"closure={checklist_validation.get('closure_present_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"commands={checklist_validation.get('closure_command_present_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"files={checklist_validation.get('file_present_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"file_sha={checklist_validation.get('file_sha_available_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"attestation_rows={checklist_validation.get('attestation_row_present_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"sha_valid={checklist_validation.get('attested_sha_valid_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"sha_match={checklist_validation.get('sha_match_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"metadata={checklist_validation.get('metadata_ready_count', 0)}/"
            f"{checklist_validation.get('required_count', 0)} "
            f"first_open={checklist_validation.get('first_open_path') or '-'}"
        ),
    )
    _add_check(
        checks,
        "no_source_artifact_external_action_leak",
        forbidden_count == 0,
        f"forbidden={forbidden_count}",
    )
    failed = [check for check in checks if check.get("status") != PASS]
    if not target_scope_ready:
        state = TARGET_SCOPE_STATE
    elif forbidden_count:
        state = ACTION_LEAK_STATE
    elif not authoring_ready:
        state = AUTHORING_STATE
    elif missing:
        state = INPUT_STATE
    elif identity_invalid:
        state = IDENTITY_STATE
    elif resource_invalid:
        state = RESOURCE_STATE
    elif stability_unstable:
        state = STABILITY_STATE
    elif shape_invalid:
        state = SHAPE_STATE
    elif not real_intake_validation.get("ready"):
        state = REAL_INTAKE_STATE
    elif not attestation_manifest_binding.get("bound_to_real_intake"):
        state = ATTESTATION_STATE
    elif not checklist_validation.get("ready"):
        state = ATTESTATION_STATE
    elif not attestation_validation.get("ready"):
        state = ATTESTATION_STATE
    else:
        state = READY_STATE
    first_missing = missing[0].get("expected_path") if missing else ""
    invalids = identity_invalid or resource_invalid or stability_unstable or shape_invalid
    first_invalid = invalids[0].get("expected_path") if invalids else ""
    attestation_manifest_template, attestation_manifest_template_rows = (
        _build_source_artifact_attestation_manifest_template(
            label,
            checklist_validation,
        )
    )
    group_closure_rows = _source_artifact_attestation_group_closure_rows(
        label,
        checklist_validation,
    )
    group_closure_ready_count = sum(
        1 for row in group_closure_rows if _truthy(row.get("ready"))
    )
    group_closure_open_count = max(
        len(group_closure_rows) - group_closure_ready_count,
        0,
    )
    group_closure_first_open_key = next(
        (
            f"{row.get('request_id')}:{row.get('packet_type')}"
            for row in group_closure_rows
            if not _truthy(row.get("ready"))
        ),
        "",
    )
    group_closure_hash = _stable_hash(
        "source_artifact_attestation_group_closure",
        {
            "label": label,
            "rows": group_closure_rows,
            "checklist_hash": checklist_validation.get("hash") or "",
        },
    )
    local_candidate_discovery = _source_artifact_local_candidate_discovery(
        root=root,
        label=label,
        records=records,
    )
    local_candidate_rows = local_candidate_discovery.get("rows") or []
    source_artifact_round_trip_status = _source_artifact_round_trip_status_packet(
        label=label,
        checklist_validation=checklist_validation,
    )
    source_artifact_round_trip_rows = (
        source_artifact_round_trip_status.get("rows") or []
    )
    source_artifact_round_trip_action_packet = (
        _source_artifact_round_trip_action_packet(
            label=label,
            status_packet=source_artifact_round_trip_status,
            local_candidate_discovery=local_candidate_discovery,
            attestation_manifest_template_rows=attestation_manifest_template_rows,
        )
    )
    source_artifact_round_trip_action_rows = (
        source_artifact_round_trip_action_packet.get("rows") or []
    )
    source_artifact_authoring_work_order_manifest = (
        _source_artifact_authoring_work_order_manifest(
            label=label,
            group_closure_rows=group_closure_rows,
            local_candidate_rows=local_candidate_rows,
            round_trip_action_rows=source_artifact_round_trip_action_rows,
        )
    )
    source_artifact_authoring_work_order_rows = (
        source_artifact_authoring_work_order_manifest.get("rows") or []
    )
    source_artifact_work_order_attestation_manifest_bridge = (
        _source_artifact_work_order_attestation_manifest_bridge(
            label=label,
            work_order_rows=source_artifact_authoring_work_order_rows,
            attestation_manifest_template_rows=attestation_manifest_template_rows,
            round_trip_status_rows=source_artifact_round_trip_rows,
        )
    )
    source_artifact_work_order_attestation_manifest_bridge_rows = (
        source_artifact_work_order_attestation_manifest_bridge.get("rows") or []
    )
    source_artifact_work_order_attestation_manifest_fill_packet = (
        _source_artifact_work_order_attestation_manifest_fill_packet(
            label=label,
            work_order_rows=source_artifact_authoring_work_order_rows,
            bridge_rows=source_artifact_work_order_attestation_manifest_bridge_rows,
            attestation_manifest_template_rows=attestation_manifest_template_rows,
            attestation_manifest_binding=attestation_manifest_binding,
            real_intake_validation=real_intake_validation,
        )
    )
    source_artifact_work_order_attestation_manifest_fill_packet_rows = (
        source_artifact_work_order_attestation_manifest_fill_packet.get("rows") or []
    )
    source_artifact_work_order_attestation_manifest_filled_preflight = (
        _source_artifact_work_order_attestation_manifest_filled_preflight(
            label=label,
            records=records,
            fill_packet_rows=(
                source_artifact_work_order_attestation_manifest_fill_packet_rows
            ),
            attestation_manifest_template_rows=attestation_manifest_template_rows,
            source_artifact_attestation_report=source_artifact_attestation_report,
            attestation_manifest_binding=attestation_manifest_binding,
        )
    )
    source_artifact_work_order_attestation_manifest_filled_preflight_rows = (
        source_artifact_work_order_attestation_manifest_filled_preflight.get("rows")
        or []
    )
    source_artifact_attestation_manifest_filled_preflight_detail = (
        _source_artifact_attestation_manifest_filled_preflight_detail(
            label=label,
            status_rows=source_artifact_round_trip_rows,
            action_rows=source_artifact_round_trip_action_rows,
            attestation_manifest_template_rows=attestation_manifest_template_rows,
            source_artifact_attestation_report=source_artifact_attestation_report,
            attestation_manifest_binding=attestation_manifest_binding,
        )
    )
    source_artifact_attestation_manifest_filled_preflight_detail_rows = (
        source_artifact_attestation_manifest_filled_preflight_detail.get("rows")
        or []
    )
    source_artifact_operator_reviewer_execution_packet = (
        _source_artifact_operator_reviewer_execution_packet(
            label=label,
            filled_preflight_detail=(
                source_artifact_attestation_manifest_filled_preflight_detail
            ),
        )
    )
    source_artifact_operator_reviewer_execution_packet_rows = (
        source_artifact_operator_reviewer_execution_packet.get("rows") or []
    )
    source_artifact_production_evidence_closure_packet = (
        _source_artifact_production_evidence_closure_packet(
            label=label,
            filled_preflight_detail=(
                source_artifact_attestation_manifest_filled_preflight_detail
            ),
            operator_reviewer_packet=source_artifact_operator_reviewer_execution_packet,
            attestation_manifest_binding=attestation_manifest_binding,
            real_intake_validation=real_intake_validation,
        )
    )
    source_artifact_production_evidence_closure_packet_rows = (
        source_artifact_production_evidence_closure_packet.get("rows") or []
    )
    source_artifact_real_evidence_intake_review_packet = (
        _source_artifact_real_evidence_intake_review_packet(
            label=label,
            production_evidence_packet=source_artifact_production_evidence_closure_packet,
        )
    )
    source_artifact_real_evidence_intake_review_packet_rows = (
        source_artifact_real_evidence_intake_review_packet.get("rows") or []
    )
    source_artifact_operator_fill_reviewer_acceptance_packet = (
        _source_artifact_operator_fill_reviewer_acceptance_packet(
            label=label,
            real_evidence_review_packet=(
                source_artifact_real_evidence_intake_review_packet
            ),
        )
    )
    source_artifact_operator_fill_reviewer_acceptance_packet_rows = (
        source_artifact_operator_fill_reviewer_acceptance_packet.get("rows") or []
    )
    source_artifact_closure_gap_summary = (
        _source_artifact_closure_gap_summary(
            label=label,
            operator_fill_reviewer_acceptance_packet=(
                source_artifact_operator_fill_reviewer_acceptance_packet
            ),
        )
    )
    source_artifact_closure_gap_summary_rows = (
        source_artifact_closure_gap_summary.get("rows") or []
    )
    source_artifact_real_closure_intake_packet = (
        _source_artifact_real_closure_intake_packet(
            label=label,
            closure_gap_summary=source_artifact_closure_gap_summary,
        )
    )
    source_artifact_real_closure_intake_packet_rows = (
        source_artifact_real_closure_intake_packet.get("rows") or []
    )
    source_artifact_real_closure_stage_preflight_packet = (
        _source_artifact_real_closure_stage_preflight_packet(
            label=label,
            real_closure_intake_packet=(
                source_artifact_real_closure_intake_packet
            ),
        )
    )
    source_artifact_real_closure_stage_preflight_packet_rows = (
        source_artifact_real_closure_stage_preflight_packet.get("rows") or []
    )
    source_artifact_real_closure_operator_action_queue = (
        _source_artifact_real_closure_operator_action_queue(
            label=label,
            stage_preflight_packet=(
                source_artifact_real_closure_stage_preflight_packet
            ),
        )
    )
    source_artifact_real_closure_operator_action_queue_rows = (
        source_artifact_real_closure_operator_action_queue.get("rows") or []
    )
    _add_check(
        checks,
        "source_artifact_work_orders_bound_to_attestation_manifest_rows",
        bool(source_artifact_work_order_attestation_manifest_bridge.get("bridge_ready")),
        (
            f"matched="
            f"{source_artifact_work_order_attestation_manifest_bridge.get('matched_count', 0)}/"
            f"{source_artifact_work_order_attestation_manifest_bridge.get('row_count', 0)} "
            f"unmatched_work_orders="
            f"{source_artifact_work_order_attestation_manifest_bridge.get('unmatched_work_order_count', 0)} "
            f"unmatched_manifest_rows="
            f"{source_artifact_work_order_attestation_manifest_bridge.get('unmatched_manifest_row_count', 0)} "
            f"unmatched_status_rows="
            f"{source_artifact_work_order_attestation_manifest_bridge.get('unmatched_status_row_count', 0)} "
            f"open="
            f"{source_artifact_work_order_attestation_manifest_bridge.get('open_count', 0)} "
            f"missing="
            f"{source_artifact_work_order_attestation_manifest_bridge.get('missing_artifact_count', 0)}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_work_order_attestation_manifest_fill_packet_ready",
        bool(
            source_artifact_work_order_attestation_manifest_fill_packet.get(
                "packet_ready"
            )
        ),
        (
            f"rows="
            f"{source_artifact_work_order_attestation_manifest_fill_packet.get('row_count', 0)} "
            f"open="
            f"{source_artifact_work_order_attestation_manifest_fill_packet.get('open_count', 0)} "
            f"missing="
            f"{source_artifact_work_order_attestation_manifest_fill_packet.get('missing_artifact_count', 0)} "
            f"manifest="
            f"{source_artifact_work_order_attestation_manifest_fill_packet.get('real_intake_attestation_manifest_path') or '-'}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_work_order_attestation_manifest_filled_preflight_ready",
        bool(
            source_artifact_work_order_attestation_manifest_filled_preflight.get(
                "preflight_ready"
            )
        ),
        (
            f"ready="
            f"{source_artifact_work_order_attestation_manifest_filled_preflight.get('ready_count', 0)}/"
            f"{source_artifact_work_order_attestation_manifest_filled_preflight.get('row_count', 0)} "
            f"filled="
            f"{source_artifact_work_order_attestation_manifest_filled_preflight.get('filled_row_count', 0)}/"
            f"{source_artifact_work_order_attestation_manifest_filled_preflight.get('expected_row_count', 0)} "
            f"missing_rows="
            f"{source_artifact_work_order_attestation_manifest_filled_preflight.get('missing_attestation_row_count', 0)} "
            f"missing_artifacts="
            f"{source_artifact_work_order_attestation_manifest_filled_preflight.get('missing_artifact_count', 0)}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_attestation_manifest_filled_preflight_detail_ready",
        bool(
            source_artifact_attestation_manifest_filled_preflight_detail.get(
                "detail_ready"
            )
        ),
        (
            f"ready="
            f"{source_artifact_attestation_manifest_filled_preflight_detail.get('ready_count', 0)}/"
            f"{source_artifact_attestation_manifest_filled_preflight_detail.get('row_count', 0)} "
            f"open="
            f"{source_artifact_attestation_manifest_filled_preflight_detail.get('open_count', 0)} "
            f"missing_artifacts="
            f"{source_artifact_attestation_manifest_filled_preflight_detail.get('missing_artifact_count', 0)} "
            f"missing_rows="
            f"{source_artifact_attestation_manifest_filled_preflight_detail.get('missing_attestation_row_count', 0)}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_operator_reviewer_execution_packet_ready",
        bool(
            source_artifact_operator_reviewer_execution_packet.get("packet_ready")
        ),
        (
            f"ready="
            f"{source_artifact_operator_reviewer_execution_packet.get('ready_count', 0)}/"
            f"{source_artifact_operator_reviewer_execution_packet.get('row_count', 0)} "
            f"operator_blocked="
            f"{source_artifact_operator_reviewer_execution_packet.get('operator_blocked_count', 0)} "
            f"reviewer_blocked="
            f"{source_artifact_operator_reviewer_execution_packet.get('reviewer_blocked_count', 0)} "
            f"first_operator="
            f"{source_artifact_operator_reviewer_execution_packet.get('first_operator_path') or '-'} "
            f"first_reviewer="
            f"{source_artifact_operator_reviewer_execution_packet.get('first_reviewer_path') or '-'}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_production_evidence_closure_packet_ready",
        bool(
            source_artifact_production_evidence_closure_packet.get("packet_ready")
        ),
        (
            f"ready="
            f"{source_artifact_production_evidence_closure_packet.get('ready_count', 0)}/"
            f"{source_artifact_production_evidence_closure_packet.get('row_count', 0)} "
            f"open="
            f"{source_artifact_production_evidence_closure_packet.get('open_count', 0)} "
            f"missing_artifacts="
            f"{source_artifact_production_evidence_closure_packet.get('missing_artifact_count', 0)} "
            f"missing_attestation_rows="
            f"{source_artifact_production_evidence_closure_packet.get('missing_attestation_row_count', 0)} "
            f"operator_reviewer_ready="
            f"{source_artifact_production_evidence_closure_packet.get('operator_reviewer_ready_count', 0)} "
            f"manifest_bound="
            f"{source_artifact_production_evidence_closure_packet.get('manifest_bound_to_real_intake')} "
            f"first_open="
            f"{source_artifact_production_evidence_closure_packet.get('first_open_path') or '-'}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_real_evidence_intake_review_packet_ready",
        bool(
            source_artifact_real_evidence_intake_review_packet.get("packet_ready")
        ),
        (
            f"ready="
            f"{source_artifact_real_evidence_intake_review_packet.get('ready_count', 0)}/"
            f"{source_artifact_real_evidence_intake_review_packet.get('row_count', 0)} "
            f"open="
            f"{source_artifact_real_evidence_intake_review_packet.get('open_count', 0)} "
            f"operator_action_required="
            f"{source_artifact_real_evidence_intake_review_packet.get('operator_action_required_count', 0)} "
            f"reviewer_action_required="
            f"{source_artifact_real_evidence_intake_review_packet.get('reviewer_action_required_count', 0)} "
            f"missing_artifacts="
            f"{source_artifact_real_evidence_intake_review_packet.get('missing_artifact_count', 0)} "
            f"missing_attestation_rows="
            f"{source_artifact_real_evidence_intake_review_packet.get('missing_attestation_row_count', 0)} "
            f"first_open="
            f"{source_artifact_real_evidence_intake_review_packet.get('first_open_path') or '-'}"
        ),
    )
    _add_check(
        checks,
        "source_artifact_operator_fill_reviewer_acceptance_packet_ready",
        bool(
            source_artifact_operator_fill_reviewer_acceptance_packet.get(
                "packet_ready"
            )
        ),
        (
            f"ready="
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('ready_count', 0)}/"
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('row_count', 0)} "
            f"open="
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('open_count', 0)} "
            f"operator_fill_required="
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('operator_fill_required_count', 0)} "
            f"reviewer_acceptance_required="
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('reviewer_acceptance_required_count', 0)} "
            f"attestation_row_closure_required="
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('attestation_row_closure_required_count', 0)} "
            f"first_open="
            f"{source_artifact_operator_fill_reviewer_acceptance_packet.get('first_open_path') or '-'}"
        ),
    )
    failed = [check for check in checks if check.get("status") != PASS]
    queue_ready = bool(
        queue_ready
        and source_artifact_work_order_attestation_manifest_bridge.get("bridge_ready")
        and source_artifact_work_order_attestation_manifest_fill_packet.get("packet_ready")
        and source_artifact_work_order_attestation_manifest_filled_preflight.get(
            "preflight_ready"
        )
        and source_artifact_attestation_manifest_filled_preflight_detail.get(
            "detail_ready"
        )
        and source_artifact_operator_reviewer_execution_packet.get("packet_ready")
        and source_artifact_production_evidence_closure_packet.get("packet_ready")
        and source_artifact_real_evidence_intake_review_packet.get("packet_ready")
        and source_artifact_operator_fill_reviewer_acceptance_packet.get(
            "packet_ready"
        )
    )
    if (
        state == READY_STATE
        and (
            not source_artifact_work_order_attestation_manifest_bridge.get("bridge_ready")
            or not source_artifact_work_order_attestation_manifest_fill_packet.get(
                "packet_ready"
            )
            or not source_artifact_work_order_attestation_manifest_filled_preflight.get(
                "preflight_ready"
            )
            or not source_artifact_attestation_manifest_filled_preflight_detail.get(
                "detail_ready"
            )
            or not source_artifact_operator_reviewer_execution_packet.get(
                "packet_ready"
            )
            or not source_artifact_production_evidence_closure_packet.get(
                "packet_ready"
            )
            or not source_artifact_real_evidence_intake_review_packet.get(
                "packet_ready"
            )
            or not source_artifact_operator_fill_reviewer_acceptance_packet.get(
                "packet_ready"
            )
        )
    ):
        state = ATTESTATION_STATE
    attestation_manifest_template["generated_at"] = created_at or _created_at()
    queue_hash = _stable_hash(
        "paper_production_referee_repair_source_artifact_intake_queue",
        {
            "records": [
                {
                    "request_id": record.get("request_id"),
                    "packet_type": record.get("packet_type"),
                    "source": record.get("source_packet_valid"),
                    "operator": record.get("operator_intake_packet_valid"),
                    "receipt": record.get("redrive_receipt_valid"),
                }
                for record in records
            ],
            "target_scope": target_scope,
            "real_intake_validation": real_intake_validation,
            "attestation_validation": attestation_validation,
            "checklist_validation": checklist_validation,
            "group_closure_hash": group_closure_hash,
            "local_candidate_discovery_hash": (
                local_candidate_discovery.get("hash") or ""
            ),
            "source_artifact_round_trip_status_hash": (
                source_artifact_round_trip_status.get("status_hash") or ""
            ),
            "source_artifact_round_trip_action_hash": (
                source_artifact_round_trip_action_packet.get("action_hash") or ""
            ),
            "source_artifact_authoring_work_order_manifest_hash": (
                source_artifact_authoring_work_order_manifest.get("manifest_hash")
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_bridge_hash": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "bridge_hash"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_hash": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_hash": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "preflight_hash"
                )
                or ""
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_hash": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "detail_hash"
                )
                or ""
            ),
            "source_artifact_operator_reviewer_execution_packet_hash": (
                source_artifact_operator_reviewer_execution_packet.get("packet_hash")
                or ""
            ),
            "source_artifact_production_evidence_closure_packet_hash": (
                source_artifact_production_evidence_closure_packet.get("packet_hash")
                or ""
            ),
            "source_artifact_real_evidence_intake_review_packet_hash": (
                source_artifact_real_evidence_intake_review_packet.get("packet_hash")
                or ""
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_hash": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_closure_gap_summary_hash": (
                source_artifact_closure_gap_summary.get("summary_hash") or ""
            ),
            "attestation_manifest_template_hash": (
                attestation_manifest_template.get("template_hash") or ""
            ),
        },
    )
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": PASS if queue_ready and not failed else FAIL,
        "label": label or report.get("label") or "",
        "created_at": created_at or _created_at(),
        "referee_repair_source_artifact_intake_queue_state": state,
        "external_action_authorized": False,
        "external_action_performed": False,
        "summary": {
            "authoring_surface_status": authoring_status,
            "authoring_surface_state": authoring_state,
            "authoring_surface_ready": authoring_ready,
            "target_scope_enforced": bool(target_scope.get("enforced")),
            "target_scope_status": target_scope.get("status") or "",
            "target_scope_state": target_scope.get("state") or "",
            "target_scope_ready": bool(target_scope.get("ready")),
            "target_paper_count": target_scope.get("target_paper_count", 0),
            "target_scoped_slug_count": target_scope.get("scoped_slug_count", 0),
            "target_slug_set_hash": target_scope.get("target_slug_set_hash") or "",
            "target_scope_failed_check_count": target_scope.get(
                "failed_check_count",
                0,
            ),
            "target_scope_report_path": target_scope.get("report_path") or "",
            "source_authoring_surface_record_count": len(records),
            "expected_source_packet_count": len(source_artifacts),
            "source_packet_present_count": sum(1 for item in source_artifacts if item.get("nonempty")),
            "source_packet_valid_count": sum(1 for item in source_artifacts if item.get("valid_evidence")),
            "expected_operator_intake_packet_count": len(operator_artifacts),
            "operator_intake_packet_present_count": sum(1 for item in operator_artifacts if item.get("nonempty")),
            "operator_intake_packet_valid_count": sum(1 for item in operator_artifacts if item.get("valid_evidence")),
            "expected_redrive_receipt_count": len(receipt_artifacts),
            "redrive_receipt_present_count": sum(1 for item in receipt_artifacts if item.get("nonempty")),
            "redrive_receipt_valid_count": sum(1 for item in receipt_artifacts if item.get("valid_evidence")),
            "total_expected_artifact_count": len(expected),
            "total_present_artifact_count": len(present),
            "total_valid_artifact_count": len(valid),
            "missing_artifact_count": len(missing),
            "identity_invalid_count": len(identity_invalid),
            "resource_invalid_count": len(resource_invalid),
            "stability_unstable_count": len(stability_unstable),
            "shape_invalid_count": len(shape_invalid),
            "source_artifact_attestation_row_count": attestation_validation.get("row_count", 0),
            "source_artifact_attestation_required_count": attestation_validation.get("required_count", 0),
            "source_artifact_attestation_matched_count": attestation_validation.get("matched_count", 0),
            "source_artifact_attestation_missing_count": attestation_validation.get("missing_count", 0),
            "source_artifact_attestation_unexpected_count": attestation_validation.get("unexpected_count", 0),
            "source_artifact_attestation_duplicate_count": attestation_validation.get("duplicate_count", 0),
            "source_artifact_attestation_sha_invalid_count": attestation_validation.get("sha_invalid_count", 0),
            "source_artifact_attestation_sha_mismatch_count": attestation_validation.get("sha_mismatch_count", 0),
            "source_artifact_attestation_sha_unavailable_count": attestation_validation.get("sha_unavailable_count", 0),
            "source_artifact_attestation_metadata_missing_count": attestation_validation.get("metadata_missing_count", 0),
            "source_artifact_attestation_ready": bool(attestation_validation.get("ready")),
            "source_artifact_attestation_source": attestation_validation.get("source") or "missing",
            "source_artifact_attestation_manifest_bound_to_real_intake": bool(
                attestation_manifest_binding.get("bound_to_real_intake")
            ),
            "source_artifact_attestation_manifest_binding_source": (
                attestation_manifest_binding.get("attestation_source") or "missing"
            ),
            "source_artifact_attestation_manifest_binding_manifest_path": (
                attestation_manifest_binding.get("manifest_path") or ""
            ),
            "source_artifact_attestation_manifest_binding_manifest_sha256": (
                attestation_manifest_binding.get("manifest_sha256") or ""
            ),
            "source_artifact_attestation_manifest_binding_real_intake_path": (
                attestation_manifest_binding.get("real_intake_manifest_path") or ""
            ),
            "source_artifact_attestation_manifest_binding_path_match": bool(
                attestation_manifest_binding.get("path_match")
            ),
            "source_artifact_attestation_manifest_binding_row_count_match": bool(
                attestation_manifest_binding.get("row_count_match")
            ),
            "source_artifact_attestation_manifest_binding_issue_count": _as_int(
                attestation_manifest_binding.get("issue_count")
            ),
            "source_artifact_attestation_manifest_binding_hash": (
                attestation_manifest_binding.get("binding_hash") or ""
            ),
            "source_artifact_attestation_checklist_ready": bool(
                checklist_validation.get("ready")
            ),
            "source_artifact_attestation_checklist_row_count": checklist_validation.get(
                "row_count",
                0,
            ),
            "source_artifact_attestation_checklist_required_count": (
                checklist_validation.get("required_count", 0)
            ),
            "source_artifact_attestation_checklist_matched_count": (
                checklist_validation.get("matched_count", 0)
            ),
            "source_artifact_attestation_checklist_missing_count": (
                checklist_validation.get("missing_count", 0)
            ),
            "source_artifact_attestation_checklist_unexpected_count": (
                checklist_validation.get("unexpected_count", 0)
            ),
            "source_artifact_attestation_checklist_duplicate_count": (
                checklist_validation.get("duplicate_count", 0)
            ),
            "source_artifact_attestation_checklist_closure_present_count": (
                checklist_validation.get("closure_present_count", 0)
            ),
            "source_artifact_attestation_checklist_closure_command_present_count": (
                checklist_validation.get("closure_command_present_count", 0)
            ),
            "source_artifact_attestation_checklist_attestation_row_present_count": (
                checklist_validation.get("attestation_row_present_count", 0)
            ),
            "source_artifact_attestation_checklist_attested_sha_valid_count": (
                checklist_validation.get("attested_sha_valid_count", 0)
            ),
            "source_artifact_attestation_checklist_file_present_count": (
                checklist_validation.get("file_present_count", 0)
            ),
            "source_artifact_attestation_checklist_file_sha_available_count": (
                checklist_validation.get("file_sha_available_count", 0)
            ),
            "source_artifact_attestation_checklist_sha_match_count": (
                checklist_validation.get("sha_match_count", 0)
            ),
            "source_artifact_attestation_checklist_sha_mismatch_count": (
                checklist_validation.get("sha_mismatch_count", 0)
            ),
            "source_artifact_attestation_checklist_metadata_ready_count": (
                checklist_validation.get("metadata_ready_count", 0)
            ),
            "source_artifact_attestation_checklist_first_missing_path": (
                checklist_validation.get("first_missing_path") or ""
            ),
            "source_artifact_attestation_checklist_first_open_path": (
                checklist_validation.get("first_open_path") or ""
            ),
            "source_artifact_attestation_checklist_hash": (
                checklist_validation.get("hash") or ""
            ),
            "source_artifact_attestation_validation_closure_csv_path": "",
            "source_artifact_attestation_validation_closure_csv_sha256": "",
            "source_artifact_attestation_validation_closure_csv_row_count": len(
                checklist_validation.get("rows") or []
            ),
            "source_artifact_attestation_group_closure_csv_path": "",
            "source_artifact_attestation_group_closure_csv_sha256": "",
            "source_artifact_attestation_group_closure_csv_row_count": len(
                group_closure_rows
            ),
            "source_artifact_attestation_group_closure_ready_count": (
                group_closure_ready_count
            ),
            "source_artifact_attestation_group_closure_open_count": (
                group_closure_open_count
            ),
            "source_artifact_attestation_group_closure_first_open_key": (
                group_closure_first_open_key
            ),
            "source_artifact_local_candidate_discovery_csv_path": "",
            "source_artifact_local_candidate_discovery_csv_sha256": "",
            "source_artifact_local_candidate_discovery_csv_row_count": len(
                local_candidate_rows
            ),
            "source_artifact_local_candidate_discovery_expected_count": (
                local_candidate_discovery.get("expected_count", 0)
            ),
            "source_artifact_local_candidate_discovery_candidate_count": (
                local_candidate_discovery.get("candidate_count", 0)
            ),
            "source_artifact_local_candidate_discovery_with_candidates_count": (
                local_candidate_discovery.get("with_candidates_count", 0)
            ),
            "source_artifact_local_candidate_discovery_first_unresolved_path": (
                local_candidate_discovery.get("first_unresolved_path") or ""
            ),
            "source_artifact_local_candidate_discovery_first_candidate_path": (
                local_candidate_discovery.get("first_candidate_path") or ""
            ),
            "source_artifact_local_candidate_discovery_scanned_file_count": (
                local_candidate_discovery.get("scanned_file_count", 0)
            ),
            "source_artifact_local_candidate_discovery_complete": bool(
                local_candidate_discovery.get("scan_complete")
            ),
            "source_artifact_local_candidate_discovery_hash": (
                local_candidate_discovery.get("hash") or ""
            ),
            "source_artifact_round_trip_status_packet_ready": bool(
                source_artifact_round_trip_status.get("packet_ready")
            ),
            "source_artifact_round_trip_status_row_count": (
                source_artifact_round_trip_status.get("row_count", 0)
            ),
            "source_artifact_round_trip_status_local_ready_count": (
                source_artifact_round_trip_status.get("local_ready_count", 0)
            ),
            "source_artifact_round_trip_status_missing_count": (
                source_artifact_round_trip_status.get("missing_count", 0)
            ),
            "source_artifact_round_trip_status_attestation_ready_count": (
                source_artifact_round_trip_status.get(
                    "attestation_ready_count",
                    0,
                )
            ),
            "source_artifact_round_trip_status_attestation_missing_count": (
                source_artifact_round_trip_status.get(
                    "attestation_missing_count",
                    0,
                )
            ),
            "source_artifact_round_trip_status_metadata_ready_count": (
                source_artifact_round_trip_status.get("metadata_ready_count", 0)
            ),
            "source_artifact_round_trip_status_shape_ready_count": (
                source_artifact_round_trip_status.get("shape_ready_count", 0)
            ),
            "source_artifact_round_trip_status_first_unready_path": (
                source_artifact_round_trip_status.get("first_unready_path") or ""
            ),
            "source_artifact_round_trip_status_hash": (
                source_artifact_round_trip_status.get("status_hash") or ""
            ),
            "source_artifact_round_trip_status_csv_path": "",
            "source_artifact_round_trip_status_csv_sha256": "",
            "source_artifact_round_trip_status_json_path": "",
            "source_artifact_round_trip_status_json_sha256": "",
            "source_artifact_round_trip_action_packet_ready": bool(
                source_artifact_round_trip_action_packet.get("packet_ready")
            ),
            "source_artifact_round_trip_action_row_count": (
                source_artifact_round_trip_action_packet.get("row_count", 0)
            ),
            "source_artifact_round_trip_action_open_count": (
                source_artifact_round_trip_action_packet.get("open_count", 0)
            ),
            "source_artifact_round_trip_action_candidate_count": (
                source_artifact_round_trip_action_packet.get(
                    "candidate_count",
                    0,
                )
            ),
            "source_artifact_round_trip_action_with_candidates_count": (
                source_artifact_round_trip_action_packet.get(
                    "with_candidates_count",
                    0,
                )
            ),
            "source_artifact_round_trip_action_first_open_path": (
                source_artifact_round_trip_action_packet.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_round_trip_action_hash": (
                source_artifact_round_trip_action_packet.get("action_hash") or ""
            ),
            "source_artifact_round_trip_action_csv_path": "",
            "source_artifact_round_trip_action_csv_sha256": "",
            "source_artifact_round_trip_action_json_path": "",
            "source_artifact_round_trip_action_json_sha256": "",
            "source_artifact_authoring_work_order_manifest_ready": bool(
                source_artifact_authoring_work_order_manifest.get("manifest_ready")
            ),
            "source_artifact_authoring_work_order_row_count": (
                source_artifact_authoring_work_order_manifest.get("row_count", 0)
            ),
            "source_artifact_authoring_work_order_open_count": (
                source_artifact_authoring_work_order_manifest.get("open_count", 0)
            ),
            "source_artifact_authoring_work_order_ready_count": (
                source_artifact_authoring_work_order_manifest.get("ready_count", 0)
            ),
            "source_artifact_authoring_work_order_missing_artifact_count": (
                source_artifact_authoring_work_order_manifest.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_authoring_work_order_candidate_count": (
                source_artifact_authoring_work_order_manifest.get(
                    "candidate_count",
                    0,
                )
            ),
            "source_artifact_authoring_work_order_with_candidates_count": (
                source_artifact_authoring_work_order_manifest.get(
                    "with_candidates_count",
                    0,
                )
            ),
            "source_artifact_authoring_work_order_first_open_path": (
                source_artifact_authoring_work_order_manifest.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_authoring_work_order_hash": (
                source_artifact_authoring_work_order_manifest.get("manifest_hash")
                or ""
            ),
            "source_artifact_authoring_work_order_csv_path": "",
            "source_artifact_authoring_work_order_csv_sha256": "",
            "source_artifact_authoring_work_order_json_path": "",
            "source_artifact_authoring_work_order_json_sha256": "",
            "source_artifact_work_order_attestation_manifest_bridge_ready": bool(
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "bridge_ready"
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_row_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_matched_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "matched_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_open_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_missing_artifact_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_unmatched_work_order_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "unmatched_work_order_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_unmatched_manifest_row_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "unmatched_manifest_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_unmatched_status_row_count": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "unmatched_status_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_bridge_first_open_path": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_bridge_hash": (
                source_artifact_work_order_attestation_manifest_bridge.get(
                    "bridge_hash"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_bridge_csv_path": "",
            "source_artifact_work_order_attestation_manifest_bridge_csv_sha256": "",
            "source_artifact_work_order_attestation_manifest_bridge_json_path": "",
            "source_artifact_work_order_attestation_manifest_bridge_json_sha256": "",
            "source_artifact_work_order_attestation_manifest_fill_packet_ready": bool(
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "packet_ready"
                )
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_row_count": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_ready_count": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_open_count": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_missing_artifact_count": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_template_row_count": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "template_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_real_intake_manifest_path": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "real_intake_attestation_manifest_path"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_first_open_path": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_hash": (
                source_artifact_work_order_attestation_manifest_fill_packet.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_fill_packet_csv_path": "",
            "source_artifact_work_order_attestation_manifest_fill_packet_csv_sha256": "",
            "source_artifact_work_order_attestation_manifest_fill_packet_json_path": "",
            "source_artifact_work_order_attestation_manifest_fill_packet_json_sha256": "",
            "source_artifact_work_order_attestation_manifest_filled_preflight_ready": bool(
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "preflight_ready"
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_row_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_ready_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_open_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_expected_row_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "expected_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_filled_row_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "filled_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_missing_attestation_row_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_duplicate_attestation_row_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "duplicate_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_unexpected_attestation_row_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "unexpected_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_sha_valid_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "sha_valid_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_sha_match_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "sha_match_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_metadata_ready_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "metadata_ready_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_missing_artifact_count": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_manifest_path": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "attestation_manifest_path"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_first_open_path": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_hash": (
                source_artifact_work_order_attestation_manifest_filled_preflight.get(
                    "preflight_hash"
                )
                or ""
            ),
            "source_artifact_work_order_attestation_manifest_filled_preflight_csv_path": "",
            "source_artifact_work_order_attestation_manifest_filled_preflight_csv_sha256": "",
            "source_artifact_work_order_attestation_manifest_filled_preflight_json_path": "",
            "source_artifact_work_order_attestation_manifest_filled_preflight_json_sha256": "",
            "source_artifact_attestation_manifest_filled_preflight_detail_ready": bool(
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "detail_ready"
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_row_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_ready_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_open_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_missing_artifact_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_missing_attestation_row_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_sha_valid_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "sha_valid_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_sha_match_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "sha_match_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_metadata_ready_count": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "metadata_ready_count",
                    0,
                )
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_first_open_path": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_hash": (
                source_artifact_attestation_manifest_filled_preflight_detail.get(
                    "detail_hash"
                )
                or ""
            ),
            "source_artifact_attestation_manifest_filled_preflight_detail_csv_path": "",
            "source_artifact_attestation_manifest_filled_preflight_detail_csv_sha256": "",
            "source_artifact_attestation_manifest_filled_preflight_detail_json_path": "",
            "source_artifact_attestation_manifest_filled_preflight_detail_json_sha256": "",
            "source_artifact_operator_reviewer_execution_packet_ready": bool(
                source_artifact_operator_reviewer_execution_packet.get("packet_ready")
            ),
            "source_artifact_operator_reviewer_execution_packet_row_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_ready_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_open_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_operator_blocked_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "operator_blocked_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_reviewer_blocked_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "reviewer_blocked_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_missing_artifact_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_missing_attestation_row_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_sha_blocked_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "sha_blocked_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_metadata_blocked_count": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "metadata_blocked_count",
                    0,
                )
            ),
            "source_artifact_operator_reviewer_execution_packet_first_operator_path": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "first_operator_path"
                )
                or ""
            ),
            "source_artifact_operator_reviewer_execution_packet_first_reviewer_path": (
                source_artifact_operator_reviewer_execution_packet.get(
                    "first_reviewer_path"
                )
                or ""
            ),
            "source_artifact_operator_reviewer_execution_packet_hash": (
                source_artifact_operator_reviewer_execution_packet.get("packet_hash")
                or ""
            ),
            "source_artifact_operator_reviewer_execution_packet_csv_path": "",
            "source_artifact_operator_reviewer_execution_packet_csv_sha256": "",
            "source_artifact_operator_reviewer_execution_packet_json_path": "",
            "source_artifact_operator_reviewer_execution_packet_json_sha256": "",
            "source_artifact_production_evidence_closure_packet_ready": bool(
                source_artifact_production_evidence_closure_packet.get("packet_ready")
            ),
            "source_artifact_production_evidence_closure_packet_row_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_ready_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_open_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_local_artifact_ready_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "local_artifact_ready_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_missing_artifact_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_attestation_ready_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "attestation_ready_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_missing_attestation_row_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_sha_match_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "sha_match_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_metadata_ready_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "metadata_ready_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_operator_reviewer_ready_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "operator_reviewer_ready_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_operator_blocked_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "operator_blocked_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_reviewer_blocked_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "reviewer_blocked_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_manifest_bound_to_real_intake": bool(
                source_artifact_production_evidence_closure_packet.get(
                    "manifest_bound_to_real_intake"
                )
            ),
            "source_artifact_production_evidence_closure_packet_manifest_binding_issue_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "manifest_binding_issue_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_real_intake_operator_closure_ready": bool(
                source_artifact_production_evidence_closure_packet.get(
                    "real_intake_operator_closure_ready"
                )
            ),
            "source_artifact_production_evidence_closure_packet_real_intake_attestation_packet_ready": bool(
                source_artifact_production_evidence_closure_packet.get(
                    "real_intake_attestation_packet_ready"
                )
            ),
            "source_artifact_production_evidence_closure_packet_real_intake_operator_input_missing_count": (
                source_artifact_production_evidence_closure_packet.get(
                    "real_intake_operator_input_missing_count",
                    0,
                )
            ),
            "source_artifact_production_evidence_closure_packet_first_open_path": (
                source_artifact_production_evidence_closure_packet.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_production_evidence_closure_packet_blocking_state": (
                source_artifact_production_evidence_closure_packet.get(
                    "blocking_state"
                )
                or ""
            ),
            "source_artifact_production_evidence_closure_packet_blocking_reason": (
                source_artifact_production_evidence_closure_packet.get(
                    "blocking_reason"
                )
                or ""
            ),
            "source_artifact_production_evidence_closure_packet_hash": (
                source_artifact_production_evidence_closure_packet.get("packet_hash")
                or ""
            ),
            "source_artifact_production_evidence_closure_packet_csv_path": "",
            "source_artifact_production_evidence_closure_packet_csv_sha256": "",
            "source_artifact_production_evidence_closure_packet_json_path": "",
            "source_artifact_production_evidence_closure_packet_json_sha256": "",
            "source_artifact_real_evidence_intake_review_packet_ready": bool(
                source_artifact_real_evidence_intake_review_packet.get("packet_ready")
            ),
            "source_artifact_real_evidence_intake_review_packet_row_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_ready_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_open_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_operator_action_required_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "operator_action_required_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_reviewer_action_required_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "reviewer_action_required_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_missing_artifact_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_missing_attestation_row_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_ready_for_local_review_count": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "ready_for_local_review_count",
                    0,
                )
            ),
            "source_artifact_real_evidence_intake_review_packet_first_open_path": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_real_evidence_intake_review_packet_blocking_state": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "blocking_state"
                )
                or ""
            ),
            "source_artifact_real_evidence_intake_review_packet_blocking_reason": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "blocking_reason"
                )
                or ""
            ),
            "source_artifact_real_evidence_intake_review_packet_hash": (
                source_artifact_real_evidence_intake_review_packet.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_real_evidence_intake_review_packet_csv_path": "",
            "source_artifact_real_evidence_intake_review_packet_csv_sha256": "",
            "source_artifact_real_evidence_intake_review_packet_json_path": "",
            "source_artifact_real_evidence_intake_review_packet_json_sha256": "",
            "source_artifact_operator_fill_reviewer_acceptance_packet_ready": bool(
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "packet_ready"
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_row_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_ready_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_open_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_operator_fill_required_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "operator_fill_required_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_reviewer_acceptance_required_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "reviewer_acceptance_required_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_attestation_row_closure_required_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "attestation_row_closure_required_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_missing_artifact_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "missing_artifact_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_missing_attestation_row_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_ready_for_reviewer_count": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "ready_for_reviewer_count",
                    0,
                )
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_first_open_path": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "first_open_path"
                )
                or ""
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_blocking_state": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "blocking_state"
                )
                or ""
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_blocking_reason": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "blocking_reason"
                )
                or ""
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_hash": (
                source_artifact_operator_fill_reviewer_acceptance_packet.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_operator_fill_reviewer_acceptance_packet_csv_path": "",
            "source_artifact_operator_fill_reviewer_acceptance_packet_csv_sha256": "",
            "source_artifact_operator_fill_reviewer_acceptance_packet_json_path": "",
            "source_artifact_operator_fill_reviewer_acceptance_packet_json_sha256": "",
            "source_artifact_closure_gap_summary_ready": bool(
                source_artifact_closure_gap_summary.get("summary_ready")
            ),
            "source_artifact_closure_gap_summary_row_count": (
                source_artifact_closure_gap_summary.get("row_count", 0)
            ),
            "source_artifact_closure_gap_summary_ready_count": (
                source_artifact_closure_gap_summary.get("ready_count", 0)
            ),
            "source_artifact_closure_gap_summary_open_count": (
                source_artifact_closure_gap_summary.get("open_count", 0)
            ),
            "source_artifact_closure_gap_summary_missing_file_count": (
                source_artifact_closure_gap_summary.get("missing_file_count", 0)
            ),
            "source_artifact_closure_gap_summary_missing_attestation_row_count": (
                source_artifact_closure_gap_summary.get(
                    "missing_attestation_row_count",
                    0,
                )
            ),
            "source_artifact_closure_gap_summary_operator_fill_required_count": (
                source_artifact_closure_gap_summary.get(
                    "operator_fill_required_count",
                    0,
                )
            ),
            "source_artifact_closure_gap_summary_reviewer_acceptance_required_count": (
                source_artifact_closure_gap_summary.get(
                    "reviewer_acceptance_required_count",
                    0,
                )
            ),
            "source_artifact_closure_gap_summary_attestation_row_closure_required_count": (
                source_artifact_closure_gap_summary.get(
                    "attestation_row_closure_required_count",
                    0,
                )
            ),
            "source_artifact_closure_gap_summary_first_open_path": (
                source_artifact_closure_gap_summary.get("first_open_path") or ""
            ),
            "source_artifact_closure_gap_summary_first_next_action": (
                source_artifact_closure_gap_summary.get("first_next_action") or ""
            ),
            "source_artifact_closure_gap_summary_hash": (
                source_artifact_closure_gap_summary.get("summary_hash") or ""
            ),
            "source_artifact_closure_gap_summary_csv_path": "",
            "source_artifact_closure_gap_summary_csv_sha256": "",
            "source_artifact_closure_gap_summary_csv_row_count": (
                len(source_artifact_closure_gap_summary_rows)
            ),
            "source_artifact_real_closure_intake_packet_ready": bool(
                source_artifact_real_closure_intake_packet.get("packet_ready")
            ),
            "source_artifact_real_closure_intake_packet_row_count": (
                source_artifact_real_closure_intake_packet.get("row_count", 0)
            ),
            "source_artifact_real_closure_intake_packet_ready_count": (
                source_artifact_real_closure_intake_packet.get("ready_count", 0)
            ),
            "source_artifact_real_closure_intake_packet_open_count": (
                source_artifact_real_closure_intake_packet.get("open_count", 0)
            ),
            "source_artifact_real_closure_intake_packet_operator_stage_count": (
                source_artifact_real_closure_intake_packet.get(
                    "operator_stage_count",
                    0,
                )
            ),
            "source_artifact_real_closure_intake_packet_reviewer_stage_count": (
                source_artifact_real_closure_intake_packet.get(
                    "reviewer_stage_count",
                    0,
                )
            ),
            "source_artifact_real_closure_intake_packet_attestation_stage_count": (
                source_artifact_real_closure_intake_packet.get(
                    "attestation_stage_count",
                    0,
                )
            ),
            "source_artifact_real_closure_intake_packet_blocked_before_reviewer_count": (
                source_artifact_real_closure_intake_packet.get(
                    "blocked_before_reviewer_count",
                    0,
                )
            ),
            "source_artifact_real_closure_intake_packet_blocked_before_attestation_count": (
                source_artifact_real_closure_intake_packet.get(
                    "blocked_before_attestation_count",
                    0,
                )
            ),
            "source_artifact_real_closure_intake_packet_first_open_path": (
                source_artifact_real_closure_intake_packet.get("first_open_path")
                or ""
            ),
            "source_artifact_real_closure_intake_packet_first_next_owner": (
                source_artifact_real_closure_intake_packet.get(
                    "first_next_owner"
                )
                or ""
            ),
            "source_artifact_real_closure_intake_packet_first_next_action": (
                source_artifact_real_closure_intake_packet.get(
                    "first_next_action"
                )
                or ""
            ),
            "source_artifact_real_closure_intake_packet_hash": (
                source_artifact_real_closure_intake_packet.get("packet_hash")
                or ""
            ),
            "source_artifact_real_closure_intake_packet_csv_path": "",
            "source_artifact_real_closure_intake_packet_csv_sha256": "",
            "source_artifact_real_closure_intake_packet_json_path": "",
            "source_artifact_real_closure_intake_packet_json_sha256": "",
            "source_artifact_real_closure_stage_preflight_packet_ready": bool(
                source_artifact_real_closure_stage_preflight_packet.get(
                    "packet_ready"
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_row_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_ready_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "ready_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_open_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "open_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_actionable_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "actionable_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_blocked_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "blocked_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_operator_stage_row_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "operator_stage_row_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_operator_actionable_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "operator_actionable_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_reviewer_stage_row_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "reviewer_stage_row_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_reviewer_blocked_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "reviewer_blocked_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_attestation_stage_row_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "attestation_stage_row_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_attestation_blocked_count": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "attestation_blocked_count",
                    0,
                )
            ),
            "source_artifact_real_closure_stage_preflight_packet_first_actionable_path": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "first_actionable_path"
                )
                or ""
            ),
            "source_artifact_real_closure_stage_preflight_packet_first_actionable_stage": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "first_actionable_stage"
                )
                or ""
            ),
            "source_artifact_real_closure_stage_preflight_packet_first_actionable_next_action": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "first_actionable_next_action"
                )
                or ""
            ),
            "source_artifact_real_closure_stage_preflight_packet_hash": (
                source_artifact_real_closure_stage_preflight_packet.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_real_closure_stage_preflight_packet_csv_path": "",
            "source_artifact_real_closure_stage_preflight_packet_csv_sha256": "",
            "source_artifact_real_closure_stage_preflight_packet_json_path": "",
            "source_artifact_real_closure_stage_preflight_packet_json_sha256": "",
            "source_artifact_real_closure_operator_action_queue_ready": bool(
                source_artifact_real_closure_operator_action_queue.get(
                    "queue_ready"
                )
            ),
            "source_artifact_real_closure_operator_action_queue_row_count": (
                source_artifact_real_closure_operator_action_queue.get(
                    "row_count",
                    0,
                )
            ),
            "source_artifact_real_closure_operator_action_queue_required_field_count": (
                source_artifact_real_closure_operator_action_queue.get(
                    "required_field_count",
                    0,
                )
            ),
            "source_artifact_real_closure_operator_action_queue_missing_source_count": (
                source_artifact_real_closure_operator_action_queue.get(
                    "missing_source_count",
                    0,
                )
            ),
            "source_artifact_real_closure_operator_action_queue_first_expected_path": (
                source_artifact_real_closure_operator_action_queue.get(
                    "first_expected_path"
                )
                or ""
            ),
            "source_artifact_real_closure_operator_action_queue_first_request_id": (
                source_artifact_real_closure_operator_action_queue.get(
                    "first_request_id"
                )
                or ""
            ),
            "source_artifact_real_closure_operator_action_queue_first_next_action": (
                source_artifact_real_closure_operator_action_queue.get(
                    "first_next_action"
                )
                or ""
            ),
            "source_artifact_real_closure_operator_action_queue_hash": (
                source_artifact_real_closure_operator_action_queue.get(
                    "packet_hash"
                )
                or ""
            ),
            "source_artifact_real_closure_operator_action_queue_csv_path": "",
            "source_artifact_real_closure_operator_action_queue_csv_sha256": "",
            "source_artifact_real_closure_operator_action_queue_json_path": "",
            "source_artifact_real_closure_operator_action_queue_json_sha256": "",
            "source_artifact_attestation_manifest_template_ready": bool(
                attestation_manifest_template_rows
            ),
            "source_artifact_attestation_manifest_template_required_row_count": (
                checklist_validation.get("required_count", 0)
            ),
            "source_artifact_attestation_manifest_template_row_count": len(
                attestation_manifest_template_rows
            ),
            "source_artifact_attestation_manifest_template_hash": (
                attestation_manifest_template.get("template_hash") or ""
            ),
            "source_artifact_attestation_manifest_template_json_path": "",
            "source_artifact_attestation_manifest_template_json_sha256": "",
            "source_artifact_attestation_manifest_fill_template_csv_path": "",
            "source_artifact_attestation_manifest_fill_template_csv_sha256": "",
            "source_artifact_attestation_manifest_fill_template_csv_row_count": len(
                attestation_manifest_template_rows
            ),
            "real_intake_acceptance_status": real_intake_validation.get("status")
            or "MISSING",
            "real_intake_acceptance_state": real_intake_validation.get("state") or "",
            "real_intake_operator_input_expected_count": real_intake_validation.get(
                "operator_input_expected_count",
                0,
            ),
            "real_intake_operator_input_present_count": real_intake_validation.get(
                "operator_input_present_count",
                0,
            ),
            "real_intake_operator_input_missing_count": real_intake_validation.get(
                "operator_input_missing_count",
                0,
            ),
            "real_intake_operator_input_closure_packet_ready": bool(
                real_intake_validation.get("operator_input_closure_packet_ready")
            ),
            "real_intake_operator_input_closure_packet_required_count": (
                real_intake_validation.get(
                    "operator_input_closure_packet_required_count",
                    0,
                )
            ),
            "real_intake_operator_input_closure_packet_satisfied_count": (
                real_intake_validation.get(
                    "operator_input_closure_packet_satisfied_count",
                    0,
                )
            ),
            "real_intake_operator_input_closure_packet_open_count": (
                real_intake_validation.get(
                    "operator_input_closure_packet_open_count",
                    0,
                )
            ),
            "real_intake_operator_input_closure_packet_missing_file_count": (
                real_intake_validation.get(
                    "operator_input_closure_packet_missing_file_count",
                    0,
                )
            ),
            "real_intake_operator_input_closure_packet_first_open_path": (
                real_intake_validation.get(
                    "operator_input_closure_packet_first_open_path"
                )
                or ""
            ),
            "real_intake_operator_input_closure_packet_hash": (
                real_intake_validation.get("operator_input_closure_packet_hash")
                or ""
            ),
            "real_intake_operator_input_template_ready": bool(
                real_intake_validation.get("operator_input_template_ready")
            ),
            "real_intake_operator_input_template_required_count": (
                real_intake_validation.get(
                    "operator_input_template_required_count",
                    0,
                )
            ),
            "real_intake_operator_input_template_row_count": (
                real_intake_validation.get("operator_input_template_row_count", 0)
            ),
            "real_intake_operator_input_template_hash": (
                real_intake_validation.get("operator_input_template_hash") or ""
            ),
            "real_intake_operator_input_template_json_path": (
                real_intake_validation.get("operator_input_template_json_path") or ""
            ),
            "real_intake_operator_input_template_json_sha256": (
                real_intake_validation.get("operator_input_template_json_sha256")
                or ""
            ),
            "real_intake_operator_input_fill_template_csv_path": (
                real_intake_validation.get("operator_input_fill_template_csv_path")
                or ""
            ),
            "real_intake_operator_input_fill_template_csv_sha256": (
                real_intake_validation.get("operator_input_fill_template_csv_sha256")
                or ""
            ),
            "real_intake_operator_input_fill_template_csv_row_count": (
                real_intake_validation.get(
                    "operator_input_fill_template_csv_row_count",
                    0,
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_csv_path": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_csv_path"
                )
                or ""
            ),
            "real_intake_operator_input_local_candidate_discovery_csv_sha256": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_csv_sha256"
                )
                or ""
            ),
            "real_intake_operator_input_local_candidate_discovery_csv_row_count": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_csv_row_count",
                    0,
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_expected_count": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_expected_count",
                    0,
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_candidate_count": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_candidate_count",
                    0,
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_with_candidates_count": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_with_candidates_count",
                    0,
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_first_unresolved_path": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_first_unresolved_path"
                )
                or ""
            ),
            "real_intake_operator_input_local_candidate_discovery_first_candidate_path": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_first_candidate_path"
                )
                or ""
            ),
            "real_intake_operator_input_local_candidate_discovery_scanned_file_count": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_scanned_file_count",
                    0,
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_complete": bool(
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_complete"
                )
            ),
            "real_intake_operator_input_local_candidate_discovery_hash": (
                real_intake_validation.get(
                    "operator_input_local_candidate_discovery_hash"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_packet_ready": bool(
                real_intake_validation.get("operator_input_round_trip_packet_ready")
            ),
            "real_intake_operator_input_round_trip_packet_row_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_packet_row_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_packet_open_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_packet_open_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_packet_candidate_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_packet_candidate_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_packet_with_candidates_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_packet_with_candidates_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_packet_first_open_path": (
                real_intake_validation.get(
                    "operator_input_round_trip_packet_first_open_path"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_packet_hash": (
                real_intake_validation.get("operator_input_round_trip_packet_hash")
                or ""
            ),
            "real_intake_operator_input_round_trip_packet_path": (
                real_intake_validation.get("operator_input_round_trip_packet_path")
                or ""
            ),
            "real_intake_operator_input_round_trip_packet_sha256": (
                real_intake_validation.get("operator_input_round_trip_packet_sha256")
                or ""
            ),
            "real_intake_operator_input_round_trip_action_csv_path": (
                real_intake_validation.get("operator_input_round_trip_action_csv_path")
                or ""
            ),
            "real_intake_operator_input_round_trip_action_csv_sha256": (
                real_intake_validation.get(
                    "operator_input_round_trip_action_csv_sha256"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_action_csv_row_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_action_csv_row_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_status_packet_ready": bool(
                real_intake_validation.get(
                    "operator_input_round_trip_status_packet_ready"
                )
            ),
            "real_intake_operator_input_round_trip_status_row_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_row_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_status_local_ready_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_local_ready_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_status_missing_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_missing_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_status_shape_ready_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_shape_ready_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_status_shape_invalid_count": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_shape_invalid_count",
                    0,
                )
            ),
            "real_intake_operator_input_round_trip_status_first_unready_path": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_first_unready_path"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_status_hash": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_hash"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_status_csv_path": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_csv_path"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_status_csv_sha256": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_csv_sha256"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_status_json_path": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_json_path"
                )
                or ""
            ),
            "real_intake_operator_input_round_trip_status_json_sha256": (
                real_intake_validation.get(
                    "operator_input_round_trip_status_json_sha256"
                )
                or ""
            ),
            "real_intake_operator_input_filled_preflight_ready": bool(
                real_intake_validation.get("operator_input_filled_preflight_ready")
            ),
            "real_intake_operator_input_filled_preflight_row_count": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_row_count",
                    0,
                )
            ),
            "real_intake_operator_input_filled_preflight_expected_count": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_expected_count",
                    0,
                )
            ),
            "real_intake_operator_input_filled_preflight_ready_count": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_ready_count",
                    0,
                )
            ),
            "real_intake_operator_input_filled_preflight_open_count": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_open_count",
                    0,
                )
            ),
            "real_intake_operator_input_filled_preflight_missing_count": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_missing_count",
                    0,
                )
            ),
            "real_intake_operator_input_filled_preflight_shape_invalid_count": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_shape_invalid_count",
                    0,
                )
            ),
            "real_intake_operator_input_filled_preflight_first_open_path": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_first_open_path"
                )
                or ""
            ),
            "real_intake_operator_input_filled_preflight_hash": (
                real_intake_validation.get("operator_input_filled_preflight_hash")
                or ""
            ),
            "real_intake_operator_input_filled_preflight_csv_path": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_csv_path"
                )
                or ""
            ),
            "real_intake_operator_input_filled_preflight_csv_sha256": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_csv_sha256"
                )
                or ""
            ),
            "real_intake_operator_input_filled_preflight_json_path": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_json_path"
                )
                or ""
            ),
            "real_intake_operator_input_filled_preflight_json_sha256": (
                real_intake_validation.get(
                    "operator_input_filled_preflight_json_sha256"
                )
                or ""
            ),
            "real_intake_source_artifact_operator_closure_csv_required": bool(
                real_intake_validation.get("closure_required")
            ),
            "real_intake_source_artifact_operator_closure_csv_ready": bool(
                real_intake_validation.get("closure_ready")
            ),
            "real_intake_source_artifact_operator_closure_expected_row_count": (
                real_intake_validation.get("closure_expected_row_count", 0)
            ),
            "real_intake_source_artifact_operator_closure_row_count": (
                real_intake_validation.get("closure_row_count", 0)
            ),
            "real_intake_source_artifact_operator_closure_csv_path": (
                real_intake_validation.get("closure_csv_path") or ""
            ),
            "real_intake_source_artifact_operator_closure_csv_sha256_match": bool(
                real_intake_validation.get("closure_csv_sha256_match")
            ),
            "real_intake_source_artifact_operator_closure_csv_shape_ready": bool(
                real_intake_validation.get("closure_csv_shape_ready")
            ),
            "real_intake_source_artifact_attestation_packet_ready": bool(
                real_intake_validation.get("attestation_packet_ready")
            ),
            "real_intake_source_artifact_attestation_packet_required_row_count": (
                real_intake_validation.get("attestation_packet_required_row_count", 0)
            ),
            "real_intake_source_artifact_attestation_packet_row_count": (
                real_intake_validation.get("attestation_packet_row_count", 0)
            ),
            "real_intake_source_artifact_attestation_packet_closure_row_count": (
                real_intake_validation.get("attestation_packet_closure_row_count", 0)
            ),
            "real_intake_source_artifact_attestation_packet_closure_matched_count": (
                real_intake_validation.get("attestation_packet_closure_matched_count", 0)
            ),
            "real_intake_source_artifact_attestation_packet_closure_missing_count": (
                real_intake_validation.get("attestation_packet_closure_missing_count", 0)
            ),
            "real_intake_source_artifact_attestation_packet_manifest_path": (
                real_intake_validation.get("attestation_packet_manifest_path") or ""
            ),
            "real_intake_source_artifact_attestation_packet_operator_input_missing_count": (
                real_intake_validation.get(
                    "attestation_packet_operator_input_missing_count",
                    0,
                )
            ),
            "real_intake_source_artifact_attestation_packet_hash": (
                real_intake_validation.get("attestation_packet_hash") or ""
            ),
            "real_intake_source_artifact_attestation_checklist_csv_path": (
                real_intake_validation.get("attestation_checklist_csv_path") or ""
            ),
            "real_intake_source_artifact_attestation_checklist_csv_sha256": (
                real_intake_validation.get("attestation_checklist_csv_sha256") or ""
            ),
            "real_intake_source_artifact_attestation_checklist_csv_row_count": (
                real_intake_validation.get(
                    "attestation_checklist_csv_row_count",
                    0,
                )
            ),
            "real_intake_attestation_present": bool(
                real_intake_validation.get("attestation_present")
            ),
            "real_intake_failed_check_count": real_intake_validation.get(
                "failed_check_count",
                0,
            ),
            "forbidden_action_count": forbidden_count,
            "first_missing_artifact_path": first_missing,
            "first_invalid_artifact_path": first_invalid,
            "referee_repair_source_artifact_intake_queue_ready": queue_ready,
            "failed_check_count": len(failed),
            "source_artifact_intake_queue_hash": queue_hash,
        },
        "target_scope": target_scope,
        "source_artifact_intake_records": records,
        "source_artifact_attestation_validation": attestation_validation,
        "source_artifact_attestation_checklist_validation": checklist_validation,
        "source_artifact_attestation_manifest_binding": (
            attestation_manifest_binding
        ),
        "source_artifact_attestation_validation_closure_rows": checklist_validation.get(
            "rows",
            [],
        ),
        "source_artifact_attestation_group_closure_rows": group_closure_rows,
        "source_artifact_local_candidate_discovery": local_candidate_discovery,
        "source_artifact_local_candidate_discovery_rows": local_candidate_rows,
        "source_artifact_round_trip_status": source_artifact_round_trip_status,
        "source_artifact_round_trip_status_rows": source_artifact_round_trip_rows,
        "source_artifact_round_trip_action_packet": (
            source_artifact_round_trip_action_packet
        ),
        "source_artifact_round_trip_action_rows": (
            source_artifact_round_trip_action_rows
        ),
        "source_artifact_authoring_work_order_manifest": (
            source_artifact_authoring_work_order_manifest
        ),
        "source_artifact_authoring_work_order_rows": (
            source_artifact_authoring_work_order_rows
        ),
        "source_artifact_work_order_attestation_manifest_bridge": (
            source_artifact_work_order_attestation_manifest_bridge
        ),
        "source_artifact_work_order_attestation_manifest_bridge_rows": (
            source_artifact_work_order_attestation_manifest_bridge_rows
        ),
        "source_artifact_work_order_attestation_manifest_fill_packet": (
            source_artifact_work_order_attestation_manifest_fill_packet
        ),
        "source_artifact_work_order_attestation_manifest_fill_packet_rows": (
            source_artifact_work_order_attestation_manifest_fill_packet_rows
        ),
        "source_artifact_work_order_attestation_manifest_filled_preflight": (
            source_artifact_work_order_attestation_manifest_filled_preflight
        ),
        "source_artifact_work_order_attestation_manifest_filled_preflight_rows": (
            source_artifact_work_order_attestation_manifest_filled_preflight_rows
        ),
        "source_artifact_attestation_manifest_filled_preflight_detail": (
            source_artifact_attestation_manifest_filled_preflight_detail
        ),
        "source_artifact_attestation_manifest_filled_preflight_detail_rows": (
            source_artifact_attestation_manifest_filled_preflight_detail_rows
        ),
        "source_artifact_operator_reviewer_execution_packet": (
            source_artifact_operator_reviewer_execution_packet
        ),
        "source_artifact_operator_reviewer_execution_packet_rows": (
            source_artifact_operator_reviewer_execution_packet_rows
        ),
        "source_artifact_production_evidence_closure_packet": (
            source_artifact_production_evidence_closure_packet
        ),
        "source_artifact_production_evidence_closure_packet_rows": (
            source_artifact_production_evidence_closure_packet_rows
        ),
        "source_artifact_real_evidence_intake_review_packet": (
            source_artifact_real_evidence_intake_review_packet
        ),
        "source_artifact_real_evidence_intake_review_packet_rows": (
            source_artifact_real_evidence_intake_review_packet_rows
        ),
        "source_artifact_operator_fill_reviewer_acceptance_packet": (
            source_artifact_operator_fill_reviewer_acceptance_packet
        ),
        "source_artifact_operator_fill_reviewer_acceptance_packet_rows": (
            source_artifact_operator_fill_reviewer_acceptance_packet_rows
        ),
        "source_artifact_closure_gap_summary": (
            source_artifact_closure_gap_summary
        ),
        "source_artifact_closure_gap_summary_rows": (
            source_artifact_closure_gap_summary_rows
        ),
        "source_artifact_real_closure_intake_packet": (
            source_artifact_real_closure_intake_packet
        ),
        "source_artifact_real_closure_intake_packet_rows": (
            source_artifact_real_closure_intake_packet_rows
        ),
        "source_artifact_real_closure_stage_preflight_packet": (
            source_artifact_real_closure_stage_preflight_packet
        ),
        "source_artifact_real_closure_stage_preflight_packet_rows": (
            source_artifact_real_closure_stage_preflight_packet_rows
        ),
        "source_artifact_real_closure_operator_action_queue": (
            source_artifact_real_closure_operator_action_queue
        ),
        "source_artifact_real_closure_operator_action_queue_rows": (
            source_artifact_real_closure_operator_action_queue_rows
        ),
        "source_artifact_attestation_manifest_template": (
            attestation_manifest_template
        ),
        "source_artifact_attestation_manifest_template_rows": (
            attestation_manifest_template_rows
        ),
        "generated_artifacts": {},
        "upstream_refs": upstream_refs,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This queue validates existing source packet, operator real-source intake, and redrive receipt files named by the source authoring surface.",
            "Each expected artifact must also be attested by matching request, slug, packet type, artifact kind, expected path, and SHA256 before the queue can pass.",
            "The real-intake source-artifact attestation packet must bind the attestation manifest path, operator closure CSV rows, and expected source artifacts before local artifact validation can pass.",
            "The real-intake source-artifact checklist is revalidated row-by-row against local artifact presence, file SHA, attestation row, provider, timestamp, and source metadata.",
            "Each source artifact work order must bind to exactly its three attestation manifest/template and round-trip status rows; that bridge is a control-plane check only and is not evidence.",
            "The source artifact work-order attestation fill packet is an operator execution aid only; it binds each work order to the canonical real-intake manifest path but does not fill or accept evidence.",
            "The artifact-level filled preflight detail is a per-expected-path diagnostic surface only; it does not create files, fill attestation rows, or accept evidence.",
            "The operator/reviewer execution packet splits local artifact supply from reviewer attestation work; it is a local execution aid and not evidence.",
            "The production evidence closure packet composes local artifact, reviewed attestation, manifest binding, and operator/reviewer state into a fail-closed 93-row source-evidence gate; it is still read-only and does not create or accept evidence.",
            "The real evidence intake/review packet turns the same 93 rows into explicit operator/reviewer work items; it is not evidence and cannot fill, accept, approve, upload, submit, stage, commit, reset, or mutate registries.",
            "The operator fill/reviewer acceptance packet further splits those work items into operator artifact fill, reviewer acceptance, and attestation-row closure states; it is read-only and cannot create, fill, accept, approve, upload, submit, stage, commit, reset, or mutate registries.",
            "The source artifact closure gap summary is only a human-readable view over those rows; it does not create files, fill attestations, accept evidence, or perform external actions.",
            "The real closure intake packet turns the same gap rows into a stage-ordered work packet; it does not supply source material, fill attestation metadata, accept reviewer evidence, or authorize external actions.",
            "The real closure operator action queue extracts only currently actionable operator source-material rows; it does not create source material, mark reviewer acceptance, close attestations, or authorize external actions.",
            "It only reads local artifact metadata/content for identity, resource, stability, shape, and hash checks; it never creates source files, intake packets, receipts, releases, closures, uploads, portal submissions, or external actions.",
            "PASS means the expected local artifacts are present and structurally valid. It does not mean repair evidence has been promoted or any external lifecycle action has run.",
        ],
    }


def markdown(report: dict) -> str:
    summary = report.get("summary") or {}
    lines = [
        "# paper_factory Referee Repair Source Artifact Intake Queue",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_source_artifact_intake_queue_state', '')}",
        f"- Ready: {summary.get('referee_repair_source_artifact_intake_queue_ready')}",
        f"- Expected artifacts: {summary.get('total_expected_artifact_count', 0)}",
        f"- Present artifacts: {summary.get('total_present_artifact_count', 0)}",
        f"- Valid artifacts: {summary.get('total_valid_artifact_count', 0)}",
        f"- Attested artifacts: {summary.get('source_artifact_attestation_matched_count', 0)}",
        f"- Attestation ready: {summary.get('source_artifact_attestation_ready')}",
        f"- Attestation checklist ready: {summary.get('source_artifact_attestation_checklist_ready')}",
        f"- Attestation checklist rows: {summary.get('source_artifact_attestation_checklist_matched_count', 0)}/{summary.get('source_artifact_attestation_checklist_required_count', 0)}",
        f"- Real-intake source closure verified: {summary.get('real_intake_source_artifact_operator_closure_csv_ready')}",
        f"- First missing: {summary.get('first_missing_artifact_path') or '-'}",
        "",
        "## Records",
        "",
        "| request | packet_type | source | operator | receipt |",
        "| ---: | --- | ---: | ---: | ---: |",
    ]
    for record in report.get("source_artifact_intake_records") or []:
        lines.append(
            f"| {record.get('request_id', '')} | {record.get('packet_type', '')} | "
            f"{record.get('source_packet_valid', False)} | "
            f"{record.get('operator_intake_packet_valid', False)} | "
            f"{record.get('redrive_receipt_valid', False)} |"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
