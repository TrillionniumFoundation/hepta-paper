"""Authoring surface matrix for referee repair real-source materialization."""

from __future__ import annotations

import datetime as dt
import hashlib
import json


COMMAND = "paper-production-referee-repair-source-authoring-surface-matrix"
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_source_authoring_surface_matrix.v1"
)

PASS = "PASS"
FAIL = "FAIL"

READY_STATE = "REFEREE_REPAIR_SOURCE_AUTHORING_SURFACE_READY_REPORT_ONLY"
NOOP_STATE = "REFEREE_REPAIR_SOURCE_AUTHORING_SURFACE_NOOP"
MISSING_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_ACTIONABILITY_MISSING"
ACTIONABILITY_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_ACTIONABILITY"
CONTRACT_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_SURFACE_CONTRACT"
ACTION_LEAK_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_SURFACE_ACTION_LEAK"
TARGET_SCOPE_STATE = "BLOCKED_REFEREE_REPAIR_SOURCE_AUTHORING_TARGET_SCOPE"

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_source_authoring_surface_state",
    "report_schema",
    "summary",
    "target_scope",
    "source_authoring_surface_records",
    "upstream_refs",
    "checks",
    "failed_checks",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "actionability_status",
    "actionability_state",
    "actionability_ready",
    "target_scope_enforced",
    "target_scope_status",
    "target_scope_state",
    "target_scope_ready",
    "target_paper_count",
    "target_scoped_slug_count",
    "target_slug_set_hash",
    "target_scope_failed_check_count",
    "target_scope_report_path",
    "actionability_work_item_count",
    "target_scope_source_materialization_backlog_count",
    "target_scope_actionable_source_materialization_count",
    "source_authoring_surface_record_count",
    "source_packet_authoring_ready_count",
    "operator_intake_authoring_ready_count",
    "redrive_receipt_quarantine_ready_count",
    "source_packet_template_field_count",
    "operator_intake_template_field_count",
    "expected_packet_path_bound_count",
    "expected_operator_intake_path_bound_count",
    "expected_receipt_path_bound_count",
    "source_slot_present_count",
    "operator_intake_packet_present_count",
    "redrive_receipt_performed_count",
    "forbidden_action_count",
    "report_only_no_source_created_count",
    "source_authoring_surface_ready",
    "source_authoring_surface_matrix_hash",
    "failed_check_count",
]


def _created_at() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _summary(report: dict | None) -> dict:
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report: dict | None, ref: dict | None = None) -> str:
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or "MISSING"
    )


def _as_int(value) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _target_scope_validation(
    target_scope_report: dict | None = None,
    target_scope_ref: dict | None = None,
) -> dict:
    report = dict(target_scope_report or {})
    ref = dict(target_scope_ref or {})
    enforced = target_scope_report is not None or target_scope_ref is not None
    if not enforced:
        return {
            "enforced": False,
            "present": False,
            "status": "NOT_ENFORCED",
            "state": "NOT_ENFORCED",
            "ready": True,
            "target_paper_count": 0,
            "scoped_slug_count": 0,
            "target_slug_set_hash": "",
            "failed_check_count": 0,
            "report_path": "",
        }
    summary = _summary(report)
    status = _status(report, ref)
    state = report.get("target_scope_state") or ""
    target_paper_count = _as_int(summary.get("target_paper_count"))
    scoped_slug_count = _as_int(summary.get("scoped_slug_count"))
    target_slug_set_hash = str(summary.get("target_slug_set_hash") or "")
    failed_check_count = _as_int(
        summary.get("failed_check_count") or len(report.get("failed_checks") or [])
    )
    ready = bool(
        status == PASS
        and state == "TARGET_SCOPE_RESOLVED"
        and target_paper_count > 0
        and scoped_slug_count > 0
        and len(target_slug_set_hash) == 64
    )
    return {
        "enforced": True,
        "present": bool(report or ref.get("path")),
        "status": status,
        "state": state or ("MISSING" if status == "MISSING" else ""),
        "ready": ready,
        "target_paper_count": target_paper_count,
        "scoped_slug_count": scoped_slug_count,
        "target_slug_set_hash": target_slug_set_hash,
        "failed_check_count": failed_check_count,
        "report_path": ref.get("path") or report.get("report_path") or "",
    }


def _stable_hash(kind: str, payload) -> str:
    encoded = json.dumps(
        {"kind": kind, "payload": payload},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _add_check(checks: list[dict], name: str, ok: bool, detail: str) -> None:
    checks.append(
        {
            "name": name,
            "status": PASS if ok else FAIL,
            "detail": str(detail),
            "blocking": True,
        }
    )


def _report_present(report: dict, ref: dict | None = None) -> bool:
    return bool(report and _status(report, ref) in {PASS, FAIL})


def _source_packet_fields(item: dict) -> list[dict]:
    return [
        {
            "name": "schema_id",
            "required": True,
            "required_value": item.get("required_packet_schema_id") or "",
        },
        {
            "name": "request_id",
            "required": True,
            "required_value": item.get("request_id"),
        },
        {
            "name": "slug",
            "required": True,
            "required_value": item.get("slug") or "",
        },
        {
            "name": "packet_type",
            "required": True,
            "required_value": item.get("packet_type") or "",
        },
        {
            "name": "request_specific_source_sha256",
            "required": True,
            "required_value": "sha256 of real request-specific source material",
        },
        {
            "name": "request_specific_source_hash_bound",
            "required": True,
            "required_value": True,
        },
        {
            "name": "source_material_reference",
            "required": True,
            "required_value": "operator-provided real source reference, not generated text",
        },
    ]


def _operator_intake_fields(item: dict) -> list[dict]:
    return [
        {
            "name": "schema_id",
            "required": True,
            "required_value": (
                "paper_factory.paper_production."
                "referee_repair_operator_real_source_intake_packet.v1"
            ),
        },
        {
            "name": "request_id",
            "required": True,
            "required_value": item.get("request_id"),
        },
        {
            "name": "slug",
            "required": True,
            "required_value": item.get("slug") or "",
        },
        {
            "name": "packet_type",
            "required": True,
            "required_value": item.get("packet_type") or "",
        },
        {
            "name": "expected_packet_path",
            "required": True,
            "required_value": item.get("expected_packet_path") or "",
        },
        {
            "name": "expected_redrive_execution_receipt_path",
            "required": True,
            "required_value": item.get("expected_redrive_execution_receipt_path") or "",
        },
        {
            "name": "source_material_evidence_reference",
            "required": True,
            "required_value": "real source material evidence reference",
        },
        {
            "name": "source_sha256",
            "required": True,
            "required_value": "sha256 of real source material",
        },
        {
            "name": "source_material_reference_hash_bound",
            "required": True,
            "required_value": True,
        },
        {
            "name": "source_packet_authoring_plan",
            "required": True,
            "required_value": "author source packet only from real source material",
        },
        {
            "name": "redrive_receipt_plan",
            "required": True,
            "required_value": "plan receipt after real source packet is authored",
        },
    ]


def _surface_record(item: dict) -> dict:
    request_id = item.get("request_id")
    slug = item.get("slug") or ""
    packet_type = item.get("packet_type") or ""
    packet_path = item.get("expected_packet_path") or ""
    intake_path = item.get("expected_operator_real_source_intake_path") or ""
    receipt_path = item.get("expected_redrive_execution_receipt_path") or ""
    schema_id = item.get("required_packet_schema_id") or ""
    source_fields = _source_packet_fields(item)
    operator_fields = _operator_intake_fields(item)
    forbidden = _as_int(item.get("forbidden_action_count"))
    item_actionable = bool(
        item.get("in_target_scope")
        and item.get("ready_for_real_source_materialization")
        and not item.get("materialization_intake_materialized")
    )
    source_ready = bool(
        item_actionable
        and packet_path
        and schema_id
        and item.get("expected_packet_path_bound")
        and forbidden == 0
    )
    operator_ready = bool(
        item_actionable
        and intake_path
        and packet_path
        and item.get("expected_operator_intake_path_bound")
        and item.get("operator_intake_template_verified")
        and forbidden == 0
    )
    receipt_quarantine_ready = bool(
        item_actionable
        and receipt_path
        and not item.get("redrive_execution_receipt_performed")
        and forbidden == 0
    )
    blocked_reasons = []
    if not item.get("in_target_scope"):
        blocked_reasons.append("not_in_target_scope")
    if item.get("materialization_intake_materialized"):
        blocked_reasons.append("source_already_materialized")
    if not item.get("ready_for_real_source_materialization"):
        blocked_reasons.extend(item.get("blocked_reasons") or ["not_actionable"])
    if not packet_path or not item.get("expected_packet_path_bound"):
        blocked_reasons.append("expected_packet_path_not_bound")
    if not intake_path or not item.get("expected_operator_intake_path_bound"):
        blocked_reasons.append("expected_operator_intake_path_not_bound")
    if not receipt_path:
        blocked_reasons.append("expected_redrive_receipt_path_missing")
    if not schema_id:
        blocked_reasons.append("required_packet_schema_missing")
    if forbidden:
        blocked_reasons.append("forbidden_action_observed")
    surface_ready = bool(
        source_ready and operator_ready and receipt_quarantine_ready and not blocked_reasons
    )
    payload = {
        "schema_id": (
            "paper_factory.paper_production."
            "referee_repair_source_authoring_surface_record.v1"
        ),
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "expected_packet_path": packet_path,
        "expected_operator_real_source_intake_path": intake_path,
        "expected_redrive_execution_receipt_path": receipt_path,
        "required_packet_schema_id": schema_id,
        "materialization_intake_payload_sha256": (
            item.get("materialization_intake_payload_sha256") or ""
        ),
    }
    payload_sha = _stable_hash("source_authoring_surface_record", payload)
    return {
        "request_id": request_id,
        "slug": slug,
        "packet_type": packet_type,
        "source_authoring_surface_id": (
            f"referee-repair-source-authoring-{request_id}-{packet_type}-{payload_sha[:16]}"
        ),
        "source_authoring_surface_payload_sha256": payload_sha,
        "source_authoring_surface_hash_bound": bool(payload_sha and packet_path and intake_path),
        "source_authoring_surface_lint_ready": bool(
            request_id is not None
            and slug
            and packet_type
            and packet_path
            and intake_path
            and receipt_path
            and schema_id
        ),
        "expected_packet_path": packet_path,
        "expected_operator_real_source_intake_path": intake_path,
        "expected_redrive_execution_receipt_path": receipt_path,
        "required_packet_schema_id": schema_id,
        "source_packet_authoring_contract": {
            "contract_id": f"source-packet-authoring-{payload_sha[:16]}",
            "authoring_allowed": source_ready,
            "write_performed": False,
            "required_fields": source_fields,
            "consumable_as_repair_evidence": False,
            "consumable_as_request_closure": False,
        },
        "operator_intake_authoring_contract": {
            "contract_id": f"operator-intake-authoring-{payload_sha[:16]}",
            "authoring_allowed": operator_ready,
            "write_performed": False,
            "required_fields": operator_fields,
            "consumable_as_repair_evidence": False,
            "consumable_as_request_closure": False,
        },
        "redrive_receipt_authoring_quarantine": {
            "contract_id": f"redrive-receipt-quarantine-{payload_sha[:16]}",
            "quarantine_ready": receipt_quarantine_ready,
            "receipt_creation_allowed": False,
            "receipt_creation_performed": False,
            "detail": "Receipt remains quarantined until real source packet and operator intake are authored and revalidated.",
        },
        "validation_redrive_sequence": [
            "author real request-specific source packet from real source material",
            "author operator real-source intake packet with source hash and provenance",
            "rerun source-slot skeleton inventory/currentness",
            "rerun source-slot redrive ledger and fulfillment intake",
            "rerun operator real-source intake acceptance preflight",
            "rerun materialization intake and typed evidence contract",
        ],
        "source_packet_authoring_ready": source_ready,
        "operator_intake_authoring_ready": operator_ready,
        "redrive_receipt_quarantine_ready": receipt_quarantine_ready,
        "source_authoring_surface_ready": surface_ready,
        "source_slot_present": bool(item.get("source_slot_present")),
        "operator_intake_packet_present": bool(item.get("operator_intake_packet_present")),
        "redrive_execution_receipt_performed": bool(
            item.get("redrive_execution_receipt_performed")
        ),
        "forbidden_action_count": forbidden,
        "blocked_reasons": blocked_reasons,
        "report_only_no_source_created": True,
        "source_packet_created": False,
        "operator_intake_packet_created": False,
        "redrive_receipt_created": False,
        "evidence_release_performed": False,
        "repair_evidence_promoted": False,
        "request_closure_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
    }


def build_referee_repair_source_authoring_surface_matrix(
    source_materialization_actionability_report: dict | None = None,
    source_materialization_actionability_ref: dict | None = None,
    target_scope_report: dict | None = None,
    target_scope_ref: dict | None = None,
    upstream_refs: dict | None = None,
    label: str = "",
    created_at: str | None = None,
) -> dict:
    actionability_report = dict(source_materialization_actionability_report or {})
    actionability_ref = dict(source_materialization_actionability_ref or {})
    upstream_refs = dict(upstream_refs or {})
    if actionability_ref:
        upstream_refs.setdefault(
            "paper_production_referee_repair_source_materialization_actionability_matrix",
            actionability_ref,
        )
    if target_scope_ref:
        upstream_refs.setdefault("paper_production_target_scope_audit", target_scope_ref)
    target_scope = _target_scope_validation(target_scope_report, target_scope_ref)
    target_scope_ready = bool(target_scope.get("ready"))
    actionability_summary = _summary(actionability_report)
    actionability_status = _status(actionability_report, actionability_ref)
    actionability_state = (
        actionability_report.get("referee_repair_source_materialization_actionability_state")
        or ""
    )
    actionability_present = _report_present(actionability_report, actionability_ref)
    actionability_ready = bool(
        actionability_status == PASS
        and actionability_summary.get("source_materialization_actionability_ready")
    )
    work_items = [
        dict(item or {})
        for item in actionability_report.get("actionability_matrix") or []
        if item.get("in_target_scope")
        and not item.get("materialization_intake_materialized")
    ]
    records = [_surface_record(item) for item in work_items]
    record_count = len(records)
    hash_bound_count = sum(
        1 for item in records if item.get("source_authoring_surface_hash_bound")
    )
    lint_ready_count = sum(
        1 for item in records if item.get("source_authoring_surface_lint_ready")
    )
    source_packet_ready_count = sum(
        1 for item in records if item.get("source_packet_authoring_ready")
    )
    operator_ready_count = sum(
        1 for item in records if item.get("operator_intake_authoring_ready")
    )
    receipt_quarantine_ready_count = sum(
        1 for item in records if item.get("redrive_receipt_quarantine_ready")
    )
    surface_ready_count = sum(
        1 for item in records if item.get("source_authoring_surface_ready")
    )
    source_present_count = sum(1 for item in records if item.get("source_slot_present"))
    operator_present_count = sum(
        1 for item in records if item.get("operator_intake_packet_present")
    )
    receipt_performed_count = sum(
        1 for item in records if item.get("redrive_execution_receipt_performed")
    )
    forbidden_count = sum(_as_int(item.get("forbidden_action_count")) for item in records)
    write_performed_count = sum(
        1
        for item in records
        if item.get("source_packet_created")
        or item.get("operator_intake_packet_created")
        or item.get("redrive_receipt_created")
        or item.get("evidence_release_performed")
        or item.get("repair_evidence_promoted")
        or item.get("request_closure_performed")
    )
    target_backlog_count = _as_int(
        actionability_summary.get("target_scope_source_materialization_backlog_count")
    )
    target_actionable_count = _as_int(
        actionability_summary.get("target_scope_actionable_source_materialization_count")
    )
    surface_ready = bool(
        target_scope_ready
        and actionability_ready
        and target_backlog_count == record_count
        and target_actionable_count == record_count
        and hash_bound_count == record_count
        and lint_ready_count == record_count
        and source_packet_ready_count == record_count
        and operator_ready_count == record_count
        and receipt_quarantine_ready_count == record_count
        and surface_ready_count == record_count
        and forbidden_count == 0
        and write_performed_count == 0
    )
    noop_ready = bool(
        target_scope_ready
        and actionability_ready
        and target_backlog_count == 0
        and record_count == 0
    )
    checks = []
    if target_scope.get("enforced"):
        _add_check(
            checks,
            "canonical_target_scope_ready",
            target_scope_ready,
            (
                f"status={target_scope.get('status') or 'MISSING'} "
                f"state={target_scope.get('state') or '-'} "
                f"papers={target_scope.get('target_paper_count', 0)} "
                f"slugs={target_scope.get('scoped_slug_count', 0)} "
                f"hash={target_scope.get('target_slug_set_hash') or '-'}"
            ),
        )
    _add_check(
        checks,
        "source_materialization_actionability_available",
        actionability_present,
        actionability_ref.get("path") or "missing",
    )
    _add_check(
        checks,
        "source_materialization_actionability_ready",
        actionability_ready,
        f"status={actionability_status} state={actionability_state}",
    )
    _add_check(
        checks,
        "target_backlog_matches_authoring_surface_records",
        target_backlog_count == record_count,
        f"backlog={target_backlog_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_authoring_surfaces_hash_bound",
        hash_bound_count == record_count,
        f"hash_bound={hash_bound_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_authoring_surfaces_lint_ready",
        lint_ready_count == record_count,
        f"lint_ready={lint_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_source_packet_authoring_contracts_ready",
        source_packet_ready_count == record_count,
        f"ready={source_packet_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_operator_intake_authoring_contracts_ready",
        operator_ready_count == record_count,
        f"ready={operator_ready_count} records={record_count}",
    )
    _add_check(
        checks,
        "all_redrive_receipts_quarantined_not_created",
        receipt_quarantine_ready_count == record_count and receipt_performed_count == 0,
        (
            f"quarantine_ready={receipt_quarantine_ready_count} "
            f"receipt_performed={receipt_performed_count} records={record_count}"
        ),
    )
    _add_check(
        checks,
        "no_source_operator_receipt_release_or_closure_action_performed",
        forbidden_count == 0 and write_performed_count == 0,
        f"forbidden={forbidden_count} writes={write_performed_count}",
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != PASS
    ]
    if not target_scope_ready:
        state = TARGET_SCOPE_STATE
    elif not actionability_present:
        state = MISSING_STATE
    elif not actionability_ready:
        state = ACTIONABILITY_STATE
    elif noop_ready:
        state = NOOP_STATE
    elif forbidden_count or write_performed_count:
        state = ACTION_LEAK_STATE
    elif not surface_ready:
        state = CONTRACT_STATE
    else:
        state = READY_STATE
    matrix_hash = _stable_hash("referee_repair_source_authoring_surface", records)
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": PASS if not failed else FAIL,
        "label": label or actionability_report.get("label") or "",
        "created_at": created_at or _created_at(),
        "referee_repair_source_authoring_surface_state": state,
        "summary": {
            "actionability_status": actionability_status,
            "actionability_state": actionability_state,
            "actionability_ready": actionability_ready,
            "target_scope_enforced": bool(target_scope.get("enforced")),
            "target_scope_status": target_scope.get("status") or "",
            "target_scope_state": target_scope.get("state") or "",
            "target_scope_ready": bool(target_scope.get("ready")),
            "target_paper_count": target_scope.get("target_paper_count", 0),
            "target_scoped_slug_count": target_scope.get("scoped_slug_count", 0),
            "target_slug_set_hash": target_scope.get("target_slug_set_hash") or "",
            "target_scope_failed_check_count": target_scope.get(
                "failed_check_count",
                0,
            ),
            "target_scope_report_path": target_scope.get("report_path") or "",
            "actionability_work_item_count": _as_int(
                actionability_summary.get("actionability_work_item_count")
            ),
            "target_scope_source_materialization_backlog_count": target_backlog_count,
            "target_scope_actionable_source_materialization_count": (
                target_actionable_count
            ),
            "source_authoring_surface_record_count": record_count,
            "source_packet_authoring_ready_count": source_packet_ready_count,
            "operator_intake_authoring_ready_count": operator_ready_count,
            "redrive_receipt_quarantine_ready_count": receipt_quarantine_ready_count,
            "source_packet_template_field_count": sum(
                len((item.get("source_packet_authoring_contract") or {}).get("required_fields") or [])
                for item in records
            ),
            "operator_intake_template_field_count": sum(
                len((item.get("operator_intake_authoring_contract") or {}).get("required_fields") or [])
                for item in records
            ),
            "expected_packet_path_bound_count": sum(
                1 for item in records if item.get("expected_packet_path")
            ),
            "expected_operator_intake_path_bound_count": sum(
                1 for item in records if item.get("expected_operator_real_source_intake_path")
            ),
            "expected_receipt_path_bound_count": sum(
                1 for item in records if item.get("expected_redrive_execution_receipt_path")
            ),
            "source_slot_present_count": source_present_count,
            "operator_intake_packet_present_count": operator_present_count,
            "redrive_receipt_performed_count": receipt_performed_count,
            "forbidden_action_count": forbidden_count + write_performed_count,
            "report_only_no_source_created_count": sum(
                1 for item in records if item.get("report_only_no_source_created")
            ),
            "source_authoring_surface_ready": bool(surface_ready or noop_ready),
            "source_authoring_surface_matrix_hash": matrix_hash,
            "failed_check_count": len(failed),
        },
        "target_scope": target_scope,
        "source_authoring_surface_records": records,
        "upstream_refs": upstream_refs,
        "checks": checks,
        "failed_checks": failed,
        "boundary": [
            "This matrix emits source packet and operator intake authoring contracts for target-scoped actionable referee repair work items.",
            "PASS means the local authoring surface is ready; it does not mean source packets, operator intake packets, receipts, release evidence, or closure evidence exist.",
            "The command never writes source packets, operator intake packets, receipts, release evidence, closure evidence, manuscripts, packages, uploads, emails, portal submissions, or external actions.",
        ],
    }


def markdown(report: dict) -> str:
    lines = [
        "# paper_factory Referee Repair Source Authoring Surface Matrix",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_source_authoring_surface_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
