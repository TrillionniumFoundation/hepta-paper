"""Actionability matrix for referee repair source materialization."""

from __future__ import annotations

import datetime as dt
import hashlib
import json


COMMAND = "paper-production-referee-repair-source-materialization-actionability-matrix"
SCHEMA_ID = (
    "paper_factory.paper_production."
    "referee_repair_source_materialization_actionability_matrix.v1"
)

PASS = "PASS"
FAIL = "FAIL"

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "referee_repair_source_materialization_actionability_state",
    "report_schema",
    "summary",
    "actionability_matrix",
    "upstream_refs",
    "checks",
    "failed_checks",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "target_scope_status",
    "target_scope_state",
    "target_paper_count",
    "target_scope_slug_count",
    "target_slug_set_hash",
    "typed_evidence_contract_status",
    "typed_evidence_contract_state",
    "typed_evidence_contract_ready",
    "typed_evidence_contract_advisory_only",
    "materialization_intake_record_count",
    "materialized_intake_count",
    "source_materialization_backlog_count",
    "source_slot_authoring_record_count",
    "source_slot_authoring_safe_queue_ready_count",
    "source_slot_fulfillment_record_count",
    "source_slot_fulfilled_count",
    "operator_intake_record_count",
    "operator_intake_template_verified_count",
    "operator_intake_packet_present_count",
    "operator_intake_packet_valid_count",
    "actionability_work_item_count",
    "actionable_source_materialization_count",
    "blocked_actionability_work_item_count",
    "target_scope_materialization_record_count",
    "target_scope_source_materialization_backlog_count",
    "target_scope_actionable_source_materialization_count",
    "target_scope_blocked_actionability_work_item_count",
    "out_of_scope_materialization_record_count",
    "target_scope_missing_action_contract_count",
    "missing_action_contract_count",
    "missing_authoring_contract_count",
    "missing_fulfillment_contract_count",
    "missing_operator_intake_contract_count",
    "expected_packet_path_bound_count",
    "expected_intake_path_bound_count",
    "redrive_receipt_performed_count",
    "forbidden_action_count",
    "source_materialization_actionability_ready",
    "failed_check_count",
]


def _created_at() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _summary(report: dict | None) -> dict:
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _status(report: dict | None, ref: dict | None = None) -> str:
    return (
        (report or {}).get("status")
        or (ref or {}).get("report_status")
        or (ref or {}).get("status")
        or "MISSING"
    )


def _as_int(value) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _stable_hash(kind: str, payload) -> str:
    encoded = json.dumps(
        {"kind": kind, "payload": payload},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _add_check(checks: list[dict], name: str, ok: bool, detail: str) -> None:
    checks.append(
        {
            "name": name,
            "status": PASS if ok else FAIL,
            "detail": str(detail),
            "blocking": True,
        }
    )


def _key(record: dict) -> tuple:
    return (
        record.get("request_id"),
        record.get("slug") or "",
        record.get("packet_type") or "",
    )


def _flatten(records: list[dict], nested_key: str) -> list[dict]:
    flattened: list[dict] = []
    for record in records or []:
        nested = record.get(nested_key)
        if isinstance(nested, list):
            flattened.extend(dict(item or {}) for item in nested)
        elif record.get("packet_type"):
            flattened.append(dict(record or {}))
    return flattened


def _index(records: list[dict]) -> dict:
    indexed = {}
    for record in records:
        indexed.setdefault(_key(record), record)
    return indexed


def _target_slugs(report: dict) -> list[str]:
    target_scope = report.get("target_scope") if isinstance(report, dict) else {}
    target_scope = target_scope if isinstance(target_scope, dict) else {}
    slugs = target_scope.get("target_slugs")
    if not isinstance(slugs, list):
        contract = target_scope.get("core_scope_contract")
        contract = contract if isinstance(contract, dict) else {}
        slugs = contract.get("scoped_slugs")
    return [str(slug) for slug in (slugs or []) if str(slug)]


def _target_scope_ready(
    report: dict,
    ref: dict | None = None,
) -> tuple[bool, str, str, int, str, list[str]]:
    summary = _summary(report)
    status = _status(report, ref)
    state = report.get("target_scope_state") or ""
    target_count = _as_int(summary.get("target_paper_count"))
    slug_hash = summary.get("target_slug_set_hash") or ""
    slugs = _target_slugs(report)
    ready = bool(
        status == PASS
        and state == "TARGET_SCOPE_RESOLVED"
        and target_count > 0
        and len(slug_hash) == 64
        and len(slugs) == target_count
    )
    return ready, status, state, target_count, slug_hash, slugs


def _report_present(report: dict, ref: dict | None = None) -> bool:
    return bool(report and (_status(report, ref) in {PASS, FAIL}))


def _forbidden_action_count(*records: list[dict], summaries: list[dict] | None = None) -> int:
    keys = [
        "redrive_receipt_creation_performed",
        "redrive_receipt_creation_performed_count",
        "redrive_receipt_authoring_authorization_performed",
        "redrive_receipt_authoring_authorization_performed_count",
        "evidence_release_performed",
        "evidence_release_performed_count",
        "repair_evidence_promoted",
        "repair_evidence_promoted_count",
        "request_closure_performed",
        "request_closure_performed_count",
        "consumable_as_repair_evidence",
        "consumable_as_release_evidence",
        "consumable_as_request_closure",
        "consumable_as_release_or_closure_evidence_count",
    ]
    count = 0
    for summary in summaries or []:
        for key in keys:
            count += _as_int(summary.get(key))
    for record_set in records:
        for record in record_set:
            for key in keys:
                if isinstance(record.get(key), bool):
                    count += int(record.get(key))
                else:
                    count += _as_int(record.get(key))
    return count


def _path_matches(*paths: str) -> bool:
    present = [path for path in paths if path]
    return bool(present) and len(set(present)) == 1


def _work_item(materialization: dict, authoring: dict, fulfillment: dict, operator: dict) -> dict:
    expected_packet_path = (
        authoring.get("expected_packet_path")
        or fulfillment.get("expected_packet_path")
        or operator.get("expected_packet_path")
        or ""
    )
    expected_intake_path = operator.get("expected_operator_real_source_intake_path") or ""
    expected_receipt_path = (
        fulfillment.get("expected_redrive_execution_receipt_path")
        or operator.get("expected_redrive_execution_receipt_path")
        or ""
    )
    packet_paths_match = _path_matches(
        authoring.get("expected_packet_path") or "",
        fulfillment.get("expected_packet_path") or "",
        operator.get("expected_packet_path") or "",
    )
    schema_ids = [
        value
        for value in [
            authoring.get("required_packet_schema_id") or "",
            fulfillment.get("required_packet_schema_id") or "",
            operator.get("required_packet_schema_id") or "",
        ]
        if value
    ]
    schema_matches = bool(schema_ids and len(set(schema_ids)) == 1)
    materialized = bool(materialization.get("materialization_intake_materialized"))
    authoring_ready = bool(
        authoring
        and authoring.get("source_slot_authoring_manifest_hash_bound")
        and authoring.get("source_slot_authoring_manifest_lint_ready")
        and authoring.get("safe_local_draft_queue_ready")
    )
    fulfillment_contract_ready = bool(
        fulfillment
        and fulfillment.get("source_slot_fulfillment_intake_hash_bound")
        and fulfillment.get("source_slot_fulfillment_intake_lint_ready")
    )
    operator_contract_ready = bool(
        operator
        and operator.get("operator_real_source_intake_acceptance_preflight_hash_bound")
        and operator.get("operator_real_source_intake_acceptance_preflight_lint_ready")
        and operator.get("operator_real_source_intake_packet_template_spec_verified")
    )
    forbidden = _forbidden_action_count([authoring], [fulfillment], [operator])
    blocked_reasons = []
    if not materialization.get("materialization_intake_lint_ready"):
        blocked_reasons.append("materialization_intake_lint_not_ready")
    if not authoring:
        blocked_reasons.append("source_slot_authoring_contract_missing")
    elif not authoring_ready:
        blocked_reasons.append("source_slot_authoring_contract_not_actionable")
    if not fulfillment:
        blocked_reasons.append("source_slot_fulfillment_contract_missing")
    elif not fulfillment_contract_ready:
        blocked_reasons.append("source_slot_fulfillment_contract_not_hash_bound")
    if not operator:
        blocked_reasons.append("operator_real_source_intake_contract_missing")
    elif not operator_contract_ready:
        blocked_reasons.append("operator_real_source_intake_contract_not_template_ready")
    if not expected_packet_path:
        blocked_reasons.append("expected_packet_path_missing")
    if not expected_intake_path:
        blocked_reasons.append("expected_operator_intake_path_missing")
    if not expected_receipt_path:
        blocked_reasons.append("expected_redrive_receipt_path_missing")
    if not packet_paths_match:
        blocked_reasons.append("expected_packet_path_mismatch")
    if not schema_matches:
        blocked_reasons.append("required_packet_schema_mismatch")
    if forbidden:
        blocked_reasons.append("forbidden_action_observed")
    actionable = bool(
        not materialized
        and materialization.get("materialization_intake_lint_ready")
        and authoring_ready
        and fulfillment_contract_ready
        and operator_contract_ready
        and expected_packet_path
        and expected_intake_path
        and expected_receipt_path
        and packet_paths_match
        and schema_matches
        and forbidden == 0
    )
    return {
        "request_id": materialization.get("request_id"),
        "slug": materialization.get("slug") or "",
        "packet_type": materialization.get("packet_type") or "",
        "materialization_intake_type": materialization.get("materialization_intake_type") or "",
        "fulfillment_gate_type": materialization.get("fulfillment_gate_type") or "",
        "materialization_intake_payload_sha256": (
            materialization.get("materialization_intake_payload_sha256") or ""
        ),
        "source_gap_state": materialization.get("source_gap_state") or "",
        "materialization_intake_lint_ready": bool(
            materialization.get("materialization_intake_lint_ready")
        ),
        "materialization_intake_materialized": materialized,
        "expected_packet_path": expected_packet_path,
        "expected_operator_real_source_intake_path": expected_intake_path,
        "expected_redrive_execution_receipt_path": expected_receipt_path,
        "required_packet_schema_id": schema_ids[0] if schema_matches else "",
        "expected_packet_path_bound": bool(packet_paths_match and expected_packet_path),
        "expected_operator_intake_path_bound": bool(expected_intake_path and operator),
        "source_slot_authoring_contract_present": bool(authoring),
        "source_slot_authoring_safe_queue_ready": bool(
            authoring.get("safe_local_draft_queue_ready")
        ),
        "source_slot_authoring_action": authoring.get("authoring_action") or "",
        "source_slot_fulfillment_contract_present": bool(fulfillment),
        "source_slot_present": bool(fulfillment.get("source_slot_present")),
        "source_slot_fulfilled": bool(fulfillment.get("source_slot_fulfilled")),
        "redrive_execution_receipt_present": bool(
            fulfillment.get("redrive_execution_receipt_present")
        ),
        "redrive_execution_receipt_performed": bool(
            fulfillment.get("redrive_execution_receipt_performed")
        ),
        "operator_real_source_intake_contract_present": bool(operator),
        "operator_intake_template_verified": bool(
            operator.get("operator_real_source_intake_packet_template_spec_verified")
        ),
        "operator_intake_packet_present": bool(
            operator.get("operator_real_source_intake_packet_present")
        ),
        "operator_intake_packet_valid": bool(
            operator.get("operator_real_source_intake_packet_valid")
        ),
        "source_material_reference_hash_binding_ready": bool(
            operator.get("source_material_reference_hash_binding_ready")
        ),
        "redrive_receipt_authoring_authorization_ready": bool(
            operator.get("redrive_receipt_authoring_authorization_ready")
        ),
        "forbidden_action_count": forbidden,
        "ready_for_real_source_materialization": actionable,
        "blocked_reasons": blocked_reasons,
        "next_required_action": (
            "real_source_already_materialized"
            if materialized
            else (
                "author real request-specific source packet and operator intake, then rerun fulfillment/intake"
                if actionable
                else "repair source materialization action contract before authoring source"
            )
        ),
        "report_only_no_source_created": True,
        "external_action_authorized": False,
        "external_action_performed": False,
        "request_closure_performed": False,
    }


def build_referee_repair_source_materialization_actionability_matrix(
    target_scope_report: dict | None = None,
    typed_evidence_contract_report: dict | None = None,
    materialization_intake_report: dict | None = None,
    source_slot_authoring_manifest_report: dict | None = None,
    source_slot_fulfillment_intake_report: dict | None = None,
    operator_source_intake_acceptance_report: dict | None = None,
    upstream_refs: dict | None = None,
    label: str = "",
    created_at: str | None = None,
) -> dict:
    target_scope_report = dict(target_scope_report or {})
    typed_evidence_contract_report = dict(typed_evidence_contract_report or {})
    materialization_intake_report = dict(materialization_intake_report or {})
    source_slot_authoring_manifest_report = dict(
        source_slot_authoring_manifest_report or {}
    )
    source_slot_fulfillment_intake_report = dict(
        source_slot_fulfillment_intake_report or {}
    )
    operator_source_intake_acceptance_report = dict(
        operator_source_intake_acceptance_report or {}
    )
    upstream_refs = dict(upstream_refs or {})

    target_ready, target_status, target_state, target_count, target_hash, target_slugs = (
        _target_scope_ready(
            target_scope_report,
            upstream_refs.get("paper_production_target_scope_audit") or {},
        )
    )
    target_slug_set = set(target_slugs)
    typed_summary = _summary(typed_evidence_contract_report)
    typed_status = _status(
        typed_evidence_contract_report,
        upstream_refs.get("paper_production_referee_repair_typed_evidence_contract_matrix"),
    )
    typed_state = (
        typed_evidence_contract_report.get("referee_repair_typed_evidence_contract_state")
        or ""
    )
    typed_ready = bool(
        typed_status == PASS and typed_summary.get("typed_evidence_contract_ready")
    )
    materialization_summary = _summary(materialization_intake_report)
    authoring_summary = _summary(source_slot_authoring_manifest_report)
    fulfillment_summary = _summary(source_slot_fulfillment_intake_report)
    operator_summary = _summary(operator_source_intake_acceptance_report)

    materialization_records = [
        dict(item or {})
        for item in materialization_intake_report.get("materialization_intake_records")
        or []
        if item.get("packet_type")
    ]
    authoring_records = _flatten(
        source_slot_authoring_manifest_report.get("source_slot_authoring_manifest_records")
        or [],
        "source_slot_authoring_manifests",
    )
    fulfillment_records = _flatten(
        source_slot_fulfillment_intake_report.get("source_slot_fulfillment_intake_records")
        or [],
        "source_slot_fulfillment_records",
    )
    operator_records = _flatten(
        operator_source_intake_acceptance_report.get(
            "operator_real_source_intake_acceptance_preflight_records"
        )
        or [],
        "operator_real_source_intake_acceptance_preflight_records",
    )
    authoring_by_key = _index(authoring_records)
    fulfillment_by_key = _index(fulfillment_records)
    operator_by_key = _index(operator_records)

    work_items = [
        _work_item(
            materialization,
            authoring_by_key.get(_key(materialization), {}),
            fulfillment_by_key.get(_key(materialization), {}),
            operator_by_key.get(_key(materialization), {}),
        )
        for materialization in materialization_records
    ]
    for item in work_items:
        item["in_target_scope"] = bool(
            not target_slug_set or item.get("slug") in target_slug_set
        )
    target_work_items = [
        item for item in work_items if item.get("in_target_scope")
    ]
    out_of_scope_count = len(work_items) - len(target_work_items)
    materialized_count = sum(
        1 for item in work_items if item.get("materialization_intake_materialized")
    )
    backlog_count = len(work_items) - materialized_count
    actionable_count = sum(
        1 for item in work_items if item.get("ready_for_real_source_materialization")
    )
    blocked_count = sum(
        1
        for item in work_items
        if not item.get("materialization_intake_materialized")
        and not item.get("ready_for_real_source_materialization")
    )
    target_materialized_count = sum(
        1
        for item in target_work_items
        if item.get("materialization_intake_materialized")
    )
    target_backlog_count = len(target_work_items) - target_materialized_count
    target_actionable_count = sum(
        1
        for item in target_work_items
        if item.get("ready_for_real_source_materialization")
    )
    target_blocked_count = sum(
        1
        for item in target_work_items
        if not item.get("materialization_intake_materialized")
        and not item.get("ready_for_real_source_materialization")
    )
    missing_authoring = sum(
        1
        for item in work_items
        if not item.get("materialization_intake_materialized")
        and not item.get("source_slot_authoring_contract_present")
    )
    missing_fulfillment = sum(
        1
        for item in work_items
        if not item.get("materialization_intake_materialized")
        and not item.get("source_slot_fulfillment_contract_present")
    )
    missing_operator = sum(
        1
        for item in work_items
        if not item.get("materialization_intake_materialized")
        and not item.get("operator_real_source_intake_contract_present")
    )
    missing_action_contract = sum(
        1
        for item in work_items
        if not item.get("materialization_intake_materialized")
        and (
            not item.get("source_slot_authoring_contract_present")
            or not item.get("source_slot_fulfillment_contract_present")
            or not item.get("operator_real_source_intake_contract_present")
            or not item.get("expected_packet_path_bound")
            or not item.get("expected_operator_intake_path_bound")
        )
    )
    target_missing_action_contract = sum(
        1
        for item in target_work_items
        if not item.get("materialization_intake_materialized")
        and (
            not item.get("source_slot_authoring_contract_present")
            or not item.get("source_slot_fulfillment_contract_present")
            or not item.get("operator_real_source_intake_contract_present")
            or not item.get("expected_packet_path_bound")
            or not item.get("expected_operator_intake_path_bound")
        )
    )
    forbidden_count = sum(_as_int(item.get("forbidden_action_count")) for item in work_items)
    materialization_present = _report_present(
        materialization_intake_report,
        upstream_refs.get("paper_production_referee_repair_packet_materialization_intake_capstone"),
    )
    typed_present = _report_present(
        typed_evidence_contract_report,
        upstream_refs.get("paper_production_referee_repair_typed_evidence_contract_matrix"),
    )
    authoring_present = _report_present(
        source_slot_authoring_manifest_report,
        upstream_refs.get("paper_production_referee_repair_packet_source_slot_authoring_manifest_capstone"),
    )
    fulfillment_present = _report_present(
        source_slot_fulfillment_intake_report,
        upstream_refs.get("paper_production_referee_repair_packet_source_slot_fulfillment_intake_capstone"),
    )
    operator_present = _report_present(
        operator_source_intake_acceptance_report,
        upstream_refs.get("paper_production_referee_repair_packet_operator_real_source_intake_acceptance_preflight_capstone"),
    )
    actionability_ready = bool(
        target_ready
        and materialization_present
        and authoring_present
        and fulfillment_present
        and operator_present
        and len(work_items) > 0
        and out_of_scope_count == 0
        and target_missing_action_contract == 0
        and target_blocked_count == 0
        and forbidden_count == 0
    )
    checks = []
    _add_check(
        checks,
        "target_scope_resolved",
        target_ready,
        f"status={target_status} state={target_state} target_count={target_count}",
    )
    checks.append(
        {
            "name": "typed_evidence_contract_report_available_advisory",
            "status": PASS if typed_present else FAIL,
            "detail": typed_state or typed_status,
            "blocking": False,
        }
    )
    _add_check(
        checks,
        "materialization_intake_report_available",
        materialization_present,
        f"records={len(materialization_records)}",
    )
    _add_check(
        checks,
        "source_slot_authoring_manifest_available",
        authoring_present,
        f"records={len(authoring_records)}",
    )
    _add_check(
        checks,
        "source_slot_fulfillment_intake_available",
        fulfillment_present,
        f"records={len(fulfillment_records)}",
    )
    _add_check(
        checks,
        "operator_source_intake_acceptance_preflight_available",
        operator_present,
        f"records={len(operator_records)}",
    )
    _add_check(
        checks,
        "all_materialization_records_within_target_scope",
        out_of_scope_count == 0,
        f"out_of_scope={out_of_scope_count} target_slugs={','.join(target_slugs)}",
    )
    _add_check(
        checks,
        "target_scope_materialization_records_have_action_contracts",
        target_missing_action_contract == 0,
        f"target_missing_action_contract={target_missing_action_contract}",
    )
    _add_check(
        checks,
        "target_scope_backlog_items_are_actionable_or_materialized",
        target_blocked_count == 0,
        f"target_blocked={target_blocked_count} target_actionable={target_actionable_count} target_materialized={target_materialized_count}",
    )
    _add_check(
        checks,
        "no_receipt_release_or_closure_action_performed",
        forbidden_count == 0,
        f"forbidden_action={forbidden_count}",
    )
    failed = [
        check for check in checks if check.get("blocking") and check.get("status") != PASS
    ]
    if not target_ready:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_TARGET_SCOPE"
    elif not materialization_present:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_INTAKE_MISSING"
    elif not (authoring_present and fulfillment_present and operator_present):
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_UPSTREAM_ACTION_SURFACE_MISSING"
    elif out_of_scope_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_SCOPE_LEAK"
    elif target_missing_action_contract:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_ACTION_CONTRACT_MISSING"
    elif target_blocked_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_ACTIONABILITY"
    elif forbidden_count:
        state = "BLOCKED_REFEREE_REPAIR_SOURCE_MATERIALIZATION_ACTION_LEAK"
    else:
        state = "REFEREE_REPAIR_SOURCE_MATERIALIZATION_ACTIONABILITY_READY_REPORT_ONLY"
    matrix_hash = _stable_hash("referee_repair_source_materialization_actionability", work_items)
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": PASS if not failed else FAIL,
        "label": label or materialization_intake_report.get("label") or "",
        "created_at": created_at or _created_at(),
        "referee_repair_source_materialization_actionability_state": state,
        "summary": {
            "target_scope_status": target_status,
            "target_scope_state": target_state,
            "target_paper_count": target_count,
            "target_scope_slug_count": len(target_slugs),
            "target_slug_set_hash": target_hash,
            "typed_evidence_contract_status": typed_status,
            "typed_evidence_contract_state": typed_state,
            "typed_evidence_contract_ready": typed_ready,
            "typed_evidence_contract_advisory_only": True,
            "materialization_intake_record_count": len(materialization_records),
            "materialized_intake_count": materialized_count,
            "source_materialization_backlog_count": backlog_count,
            "source_slot_authoring_record_count": len(authoring_records),
            "source_slot_authoring_safe_queue_ready_count": _as_int(
                authoring_summary.get("safe_draft_queue_ready_count")
            ),
            "source_slot_fulfillment_record_count": len(fulfillment_records),
            "source_slot_fulfilled_count": _as_int(
                fulfillment_summary.get("source_slot_fulfilled_count")
            ),
            "operator_intake_record_count": len(operator_records),
            "operator_intake_template_verified_count": sum(
                1
                for item in operator_records
                if item.get("operator_real_source_intake_packet_template_spec_verified")
            ),
            "operator_intake_packet_present_count": _as_int(
                operator_summary.get("operator_real_source_intake_packet_present_count")
            ),
            "operator_intake_packet_valid_count": _as_int(
                operator_summary.get("operator_real_source_intake_packet_valid_count")
            ),
            "actionability_work_item_count": len(work_items),
            "actionable_source_materialization_count": actionable_count,
            "blocked_actionability_work_item_count": blocked_count,
            "target_scope_materialization_record_count": len(target_work_items),
            "target_scope_source_materialization_backlog_count": target_backlog_count,
            "target_scope_actionable_source_materialization_count": (
                target_actionable_count
            ),
            "target_scope_blocked_actionability_work_item_count": (
                target_blocked_count
            ),
            "out_of_scope_materialization_record_count": out_of_scope_count,
            "target_scope_missing_action_contract_count": (
                target_missing_action_contract
            ),
            "missing_action_contract_count": missing_action_contract,
            "missing_authoring_contract_count": missing_authoring,
            "missing_fulfillment_contract_count": missing_fulfillment,
            "missing_operator_intake_contract_count": missing_operator,
            "expected_packet_path_bound_count": sum(
                1 for item in work_items if item.get("expected_packet_path_bound")
            ),
            "expected_intake_path_bound_count": sum(
                1 for item in work_items if item.get("expected_operator_intake_path_bound")
            ),
            "redrive_receipt_performed_count": sum(
                1 for item in work_items if item.get("redrive_execution_receipt_performed")
            ),
            "forbidden_action_count": forbidden_count,
            "source_materialization_actionability_ready": actionability_ready,
            "failed_check_count": len(failed),
            "source_materialization_actionability_matrix_hash": matrix_hash,
        },
        "actionability_matrix": work_items,
        "upstream_refs": upstream_refs,
        "checks": checks,
        "failed_checks": failed,
        "boundary": [
            "This matrix joins materialization intake with existing source-slot authoring, fulfillment, and operator-intake contracts.",
            "PASS means the local actionability surface is ready; it does not mean real source material has been authored, accepted, released, or closed.",
            "The command never creates source packets, operator intake packets, receipts, release evidence, closure evidence, uploads, emails, portal submissions, or external actions.",
        ],
    }


def markdown(report: dict) -> str:
    lines = [
        "# paper_factory Referee Repair Source Materialization Actionability Matrix",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('referee_repair_source_materialization_actionability_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(
        [
            "",
            "## Actionability",
            "",
            "| request | packet | materialized | actionable | expected packet | operator intake | blockers |",
            "| ---: | --- | --- | --- | --- | --- | --- |",
        ]
    )
    for item in report.get("actionability_matrix") or []:
        blockers = ", ".join(item.get("blocked_reasons") or [])
        lines.append(
            f"| {item.get('request_id', '')} | {item.get('packet_type', '')} | "
            f"{item.get('materialization_intake_materialized')} | "
            f"{item.get('ready_for_real_source_materialization')} | "
            f"{item.get('expected_packet_path', '')} | "
            f"{item.get('expected_operator_real_source_intake_path', '')} | "
            f"{blockers} |"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
