"""Runner execution contract artifact queue.

This report materializes and validates local runner contract files from the
authoring-surface matrix. A valid contract file is still not runner readiness:
delegated routes remain blocked until the external lifecycle is ready.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path


COMMAND = "paper-production-runner-execution-contract-artifact-queue"
SCHEMA_ID = (
    "paper_factory.paper_production.runner_execution_contract_artifact_queue.v1"
)
CONTRACT_SCHEMA_ID = (
    "paper_factory.paper_production.runner_execution_contract_artifact.v1"
)

PASS = "PASS"
FAIL = "FAIL"

READY_STATE = "RUNNER_EXECUTION_CONTRACT_ARTIFACT_QUEUE_READY"
TARGET_SCOPE_STATE = "BLOCKED_RUNNER_EXECUTION_CONTRACT_ARTIFACT_TARGET_SCOPE"
AUTHORING_STATE = "BLOCKED_RUNNER_EXECUTION_CONTRACT_ARTIFACT_AUTHORING_SURFACE"
MISSING_STATE = "BLOCKED_RUNNER_EXECUTION_CONTRACT_ARTIFACT_FILES_MISSING"
INVALID_STATE = "BLOCKED_RUNNER_EXECUTION_CONTRACT_ARTIFACT_FILES_INVALID"
ACTION_LEAK_STATE = "BLOCKED_RUNNER_EXECUTION_CONTRACT_ARTIFACT_ACTION_LEAK"

CONTRACT_ROOT = Path("logs/paperctl/_contracts/runner_execution")
STALE_REWRITABLE_CONTRACT_ISSUES = {
    "contract_payload_sha256_mismatch",
    "external_lifecycle_readiness_report_mismatch",
}

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "runner_execution_contract_artifact_queue_state",
    "external_action_authorized",
    "external_action_performed",
    "report_schema",
    "summary",
    "contract_artifact_queue",
    "upstream_refs",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "target_scope_status",
    "target_scope_state",
    "target_paper_count",
    "target_slug_set_hash",
    "authoring_surface_status",
    "authoring_surface_state",
    "authoring_surface_ready",
    "expected_contract_count",
    "materialized_contract_count",
    "contract_artifact_present_count",
    "contract_artifact_valid_count",
    "missing_contract_artifact_count",
    "invalid_contract_artifact_count",
    "first_missing_contract_path",
    "first_invalid_contract_path",
    "runner_execution_contract_artifact_queue_ready",
    "dry_run_handoff_only",
    "local_contract_writer_only",
    "runner_ready_claim_allowed",
    "external_lifecycle_required",
    "forbidden_action_count",
    "failed_check_count",
    "contract_artifact_queue_hash",
]


def _created_at() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def _summary(report: dict | None) -> dict:
    summary = (report or {}).get("summary")
    return summary if isinstance(summary, dict) else {}


def _as_int(value) -> int:
    try:
        return int(value or 0)
    except Exception:
        return 0


def _stable_hash(kind: str, payload) -> str:
    encoded = json.dumps(
        {"kind": kind, "payload": payload},
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=True,
    )
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def _sha256_path(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _add_check(checks: list[dict], name: str, ok: bool, detail: str) -> None:
    checks.append(
        {
            "name": name,
            "status": PASS if ok else FAIL,
            "detail": str(detail),
            "blocking": True,
        }
    )


def _target_scope_ready(report: dict | None) -> tuple[bool, str, str, int, str]:
    report = report or {}
    summary = _summary(report)
    status = report.get("status") or "MISSING"
    state = report.get("target_scope_state") or ""
    count = _as_int(summary.get("target_paper_count"))
    target_hash = str(summary.get("target_slug_set_hash") or "")
    ready = status == PASS and state == "TARGET_SCOPE_RESOLVED" and count > 0 and len(target_hash) == 64
    return ready, status, state, count, target_hash


def _inside_contract_root(root: Path, path: Path) -> bool:
    try:
        path.resolve().relative_to((root / CONTRACT_ROOT).resolve())
        return True
    except Exception:
        return False


def _contract_payload(record: dict, *, label: str, target_hash: str) -> dict:
    contract_kind = record.get("contract_kind") or ""
    is_live = contract_kind == "live_entrypoint_adapter"
    contract_id = record.get("expected_contract_id") or ""
    payload = {
        "schema_id": CONTRACT_SCHEMA_ID,
        "contract_id": contract_id,
        "route_id": record.get("route_id") or "",
        "command": record.get("command") or "",
        "runner_lane": record.get("runner_lane") or "",
        "contract_kind": contract_kind,
        "target_label": label,
        "target_slug_set_hash": target_hash,
        "external_lifecycle_stage": record.get("external_lifecycle_stage") or "",
        "external_lifecycle_readiness_report": (
            record.get("external_lifecycle_readiness_report") or ""
        ),
        "required_contract_fields": list(record.get("required_contract_fields") or []),
        "validation_sequence": list(record.get("validation_sequence") or []),
        "source_authoring_record_hash": record.get("matrix_hash") or "",
        "no_external_action_authorized": True,
        "no_external_action_performed": True,
        "external_action_authorized": False,
        "external_action_performed": False,
        "report_only_boundary": True,
        "contract_artifact_only": True,
        "does_not_make_runner_executable": True,
        "does_not_create_outbox": True,
        "does_not_create_receipt_or_closure": True,
        "execution_blocked_until_external_lifecycle_ready": not is_live,
    }
    if is_live:
        payload["adapter_contract_id"] = contract_id
        payload["entrypoint"] = record.get("entrypoint") or ""
        payload["execution_mode"] = "live"
    else:
        payload["delegated_contract_id"] = contract_id
    payload["contract_payload_sha256"] = _stable_hash(
        "runner_execution_contract_artifact_payload",
        {key: value for key, value in payload.items() if key != "contract_payload_sha256"},
    )
    return payload


def _validate_contract(payload: dict, record: dict, *, label: str, target_hash: str) -> list[str]:
    issues: list[str] = []
    expected_payload = _contract_payload(record, label=label, target_hash=target_hash)
    if payload.get("schema_id") != CONTRACT_SCHEMA_ID:
        issues.append("schema_id_mismatch")
    for key in [
        "contract_id",
        "route_id",
        "command",
        "runner_lane",
        "contract_kind",
        "target_label",
        "target_slug_set_hash",
        "external_lifecycle_stage",
        "external_lifecycle_readiness_report",
    ]:
        if payload.get(key) != expected_payload.get(key):
            issues.append(f"{key}_mismatch")
    for key in record.get("required_contract_fields") or []:
        if key not in payload:
            issues.append(f"required_field_missing:{key}")
    if payload.get("no_external_action_authorized") is not True:
        issues.append("no_external_action_authorized_not_true")
    if payload.get("no_external_action_performed") is not True:
        issues.append("no_external_action_performed_not_true")
    if payload.get("external_action_authorized") is not False:
        issues.append("external_action_authorized_not_false")
    if payload.get("external_action_performed") is not False:
        issues.append("external_action_performed_not_false")
    if payload.get("report_only_boundary") is not True:
        issues.append("report_only_boundary_not_true")
    if payload.get("contract_artifact_only") is not True:
        issues.append("contract_artifact_only_not_true")
    if payload.get("does_not_make_runner_executable") is not True:
        issues.append("does_not_make_runner_executable_not_true")
    expected_hash = expected_payload.get("contract_payload_sha256")
    if payload.get("contract_payload_sha256") != expected_hash:
        issues.append("contract_payload_sha256_mismatch")
    return issues


def _artifact_record(record: dict, *, root: Path, label: str, target_hash: str, materialize: bool) -> dict:
    rel_path = str(record.get("expected_contract_path") or "")
    path = root / rel_path
    issues: list[str] = []
    materialized = False
    if not rel_path:
        issues.append("expected_contract_path_missing")
    elif Path(rel_path).is_absolute():
        issues.append("expected_contract_path_absolute")
    elif not _inside_contract_root(root, path):
        issues.append("expected_contract_path_outside_contract_root")

    expected_payload = _contract_payload(record, label=label, target_hash=target_hash)
    if materialize and not issues and not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(expected_payload, indent=2, sort_keys=True) + "\n")
        materialized = True

    present = bool(path.exists() and path.is_file())
    is_symlink = path.is_symlink()
    byte_count = path.stat().st_size if present and not is_symlink else 0
    sha = ""
    payload = {}
    if present and is_symlink:
        issues.append("contract_path_is_symlink")
    elif present:
        try:
            payload = json.loads(path.read_text())
        except Exception:
            issues.append("contract_json_unreadable")
            payload = {}
        if isinstance(payload, dict):
            validation_issues = _validate_contract(
                payload,
                record,
                label=label,
                target_hash=target_hash,
            )
            issues.extend(validation_issues)
            if (
                materialize
                and validation_issues
                and set(issues).issubset(STALE_REWRITABLE_CONTRACT_ISSUES)
            ):
                path.write_text(json.dumps(expected_payload, indent=2, sort_keys=True) + "\n")
                materialized = True
                byte_count = path.stat().st_size
                issues = []
                payload = expected_payload
        else:
            issues.append("contract_json_not_object")
        if not issues:
            sha = _sha256_path(path)
    valid = bool(present and not issues)
    return {
        "route_id": record.get("route_id") or "",
        "command": record.get("command") or "",
        "contract_kind": record.get("contract_kind") or "",
        "contract_id": record.get("expected_contract_id") or "",
        "contract_path": rel_path,
        "external_lifecycle_stage": record.get("external_lifecycle_stage") or "",
        "authoring_surface_ready": bool(record.get("authoring_surface_ready")),
        "materialized_by_command": materialized,
        "contract_artifact_present": present,
        "contract_artifact_valid": valid,
        "contract_artifact_sha256": sha,
        "byte_count": byte_count,
        "identity_ready": bool(present and not is_symlink and _inside_contract_root(root, path)),
        "validation_issues": sorted(set(issues)),
        "expected_contract_payload_sha256": expected_payload.get("contract_payload_sha256"),
        "artifact_record_hash": _stable_hash(
            "runner_execution_contract_artifact_record",
            {
                "route_id": record.get("route_id") or "",
                "contract_id": record.get("expected_contract_id") or "",
                "path": rel_path,
                "valid": valid,
            },
        ),
    }


def build_runner_execution_contract_artifact_queue(
    target_scope_report: dict | None = None,
    authoring_surface_report: dict | None = None,
    upstream_refs: dict | None = None,
    label: str = "",
    root: str | Path = ".",
    materialize: bool = False,
    created_at: str | None = None,
) -> dict:
    root_path = Path(root)
    target_ready, target_status, target_state, target_count, target_hash = (
        _target_scope_ready(target_scope_report)
    )
    authoring_surface_report = dict(authoring_surface_report or {})
    upstream_refs = dict(upstream_refs or {})
    authoring_summary = _summary(authoring_surface_report)
    authoring_status = authoring_surface_report.get("status") or "MISSING"
    authoring_state = (
        authoring_surface_report.get("runner_execution_contract_authoring_surface_state")
        or ""
    )
    authoring_ready = bool(authoring_summary.get("authoring_surface_ready"))
    rows = [
        row
        for row in authoring_surface_report.get("authoring_surface_matrix") or []
        if isinstance(row, dict)
    ]
    records = [
        _artifact_record(
            row,
            root=root_path,
            label=label or authoring_surface_report.get("label") or "",
            target_hash=target_hash,
            materialize=bool(materialize and target_ready and authoring_ready),
        )
        for row in rows
        if row.get("authoring_surface_ready")
    ]
    present = [row for row in records if row.get("contract_artifact_present")]
    valid = [row for row in records if row.get("contract_artifact_valid")]
    materialized = [row for row in records if row.get("materialized_by_command")]
    missing = [row for row in records if not row.get("contract_artifact_present")]
    invalid = [
        row
        for row in records
        if row.get("contract_artifact_present") and not row.get("contract_artifact_valid")
    ]
    forbidden = sum(
        1
        for row in records
        if row.get("external_action_authorized") is True
        or row.get("external_action_performed") is True
    )
    queue_ready = bool(
        target_ready
        and authoring_status == PASS
        and authoring_ready
        and records
        and len(valid) == len(records)
        and forbidden == 0
    )
    checks: list[dict] = []
    _add_check(
        checks,
        "target_scope_resolved",
        target_ready,
        f"status={target_status} state={target_state or '-'} papers={target_count}",
    )
    _add_check(
        checks,
        "authoring_surface_ready",
        authoring_status == PASS and authoring_ready,
        f"status={authoring_status} state={authoring_state or '-'} ready={authoring_ready}",
    )
    _add_check(
        checks,
        "contract_artifacts_present",
        bool(records) and not missing,
        f"present={len(present)}/{len(records)}",
    )
    _add_check(
        checks,
        "contract_artifacts_valid",
        bool(records) and not invalid and len(valid) == len(records),
        f"valid={len(valid)}/{len(records)} invalid={len(invalid)}",
    )
    _add_check(
        checks,
        "no_external_action_or_dispatch_leak",
        forbidden == 0,
        f"forbidden={forbidden}",
    )
    failed = [check for check in checks if check.get("status") != PASS]
    if forbidden:
        state = ACTION_LEAK_STATE
    elif not target_ready:
        state = TARGET_SCOPE_STATE
    elif authoring_status != PASS or not authoring_ready or not records:
        state = AUTHORING_STATE
    elif missing:
        state = MISSING_STATE
    elif invalid:
        state = INVALID_STATE
    else:
        state = READY_STATE
    queue_hash = _stable_hash(
        "runner_execution_contract_artifact_queue",
        [
            {
                "route_id": row.get("route_id"),
                "contract_id": row.get("contract_id"),
                "valid": row.get("contract_artifact_valid"),
                "sha": row.get("contract_artifact_sha256"),
            }
            for row in records
        ],
    )
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": PASS if queue_ready and not failed else FAIL,
        "label": label or authoring_surface_report.get("label") or "",
        "created_at": created_at or _created_at(),
        "runner_execution_contract_artifact_queue_state": state,
        "external_action_authorized": False,
        "external_action_performed": False,
        "summary": {
            "target_scope_status": target_status,
            "target_scope_state": target_state,
            "target_paper_count": target_count,
            "target_slug_set_hash": target_hash,
            "authoring_surface_status": authoring_status,
            "authoring_surface_state": authoring_state,
            "authoring_surface_ready": authoring_ready,
            "expected_contract_count": len(records),
            "materialized_contract_count": len(materialized),
            "contract_artifact_present_count": len(present),
            "contract_artifact_valid_count": len(valid),
            "missing_contract_artifact_count": len(missing),
            "invalid_contract_artifact_count": len(invalid),
            "first_missing_contract_path": (
                missing[0].get("contract_path") if missing else ""
            ),
            "first_invalid_contract_path": (
                invalid[0].get("contract_path") if invalid else ""
            ),
            "runner_execution_contract_artifact_queue_ready": queue_ready,
            "dry_run_handoff_only": True,
            "local_contract_writer_only": True,
            "runner_ready_claim_allowed": False,
            "external_lifecycle_required": True,
            "forbidden_action_count": forbidden,
            "failed_check_count": len(failed),
            "contract_artifact_queue_hash": queue_hash,
        },
        "contract_artifact_queue": records,
        "upstream_refs": upstream_refs,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This queue materializes and validates local runner contract files only.",
            "A valid delegated runner contract file does not authorize dispatch and does not make the runner executable; external lifecycle readiness is still required by the runner execution contract matrix.",
            "This command never creates approval/fresh evidence, source packets, action manifests, outbox entries, receipts, archives, reconciliation records, settlement, uploads, emails, portal submissions, or external actions.",
        ],
    }


def markdown(report: dict) -> str:
    summary = report.get("summary") or {}
    lines = [
        "# paper_factory Runner Execution Contract Artifact Queue",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('runner_execution_contract_artifact_queue_state', '')}",
        f"- Valid: {summary.get('contract_artifact_valid_count', 0)}/{summary.get('expected_contract_count', 0)}",
        "",
        "## Contracts",
        "",
        "| route | command | contract | present | valid | path | issues |",
        "| --- | --- | --- | ---: | ---: | --- | --- |",
    ]
    for row in report.get("contract_artifact_queue") or []:
        lines.append(
            f"| {row.get('route_id', '')} | `{row.get('command', '')}` | "
            f"`{row.get('contract_id', '')}` | "
            f"{row.get('contract_artifact_present', False)} | "
            f"{row.get('contract_artifact_valid', False)} | "
            f"`{row.get('contract_path', '')}` | "
            f"{','.join(row.get('validation_issues') or []) or '-'} |"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
