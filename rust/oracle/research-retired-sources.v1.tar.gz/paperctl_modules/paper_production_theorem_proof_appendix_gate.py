"""Theorem/proof/appendix hard gate for paper production readiness."""

import re


COMMAND = "paper-production-theorem-proof-appendix-gate"
SCHEMA_ID = "paper_factory.paper_production.theorem_proof_appendix_gate.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "schema_id",
    "command",
    "status",
    "label",
    "created_at",
    "theorem_proof_appendix_state",
    "slugs",
    "report_schema",
    "summary",
    "paper_reports",
    "checks",
    "failed_checks",
    "manual_boundary",
]

STABLE_SUMMARY_FIELDS = [
    "paper_count",
    "theorem_surface_count",
    "theorem_statement_count",
    "proof_environment_count",
    "proof_skeleton_marker_count",
    "open_proof_obligation_count",
    "missing_appendix_supplement_count",
    "evidence_manifest_negative_boundary_count",
    "missing_required_file_count",
    "missing_proof_status_count",
    "missing_evidence_manifest_count",
    "failed_check_count",
    "theorem_proof_appendix_ready",
]

THEOREM_ENV_RE = re.compile(r"\\begin\{(theorem|lemma|proposition|corollary|inputcondition)\}", re.I)
PROOF_ENV_RE = re.compile(r"\\begin\{proof\}(?:\[[^\]]*\])?", re.I)
PROOF_SKELETON_RE = re.compile(
    r"proof\s+sketch|proof\s+skeleton|sketched|remaining\s+work|still\s+open|conditional\s+proof",
    re.I,
)
APPENDIX_RE = re.compile(r"\\appendix|\\begin\{appendices\}", re.I)
WAIVER_RE = re.compile(
    r"appendix\s+waiv|supplement\s+waiv|appendix/supplement\s+waiv|appendix\s+or\s+supplement\s+waiv",
    re.I,
)
EVIDENCE_NEGATIVE_TOKENS = [
    "does not prove",
    "does not establish",
    "does not claim",
    "not claim final",
    "supports only",
    "cannot replace",
    "current status: `blocked`",
    "current status: blocked",
]


def _text(value):
    return str(value or "")


def _count(pattern, text):
    return len(pattern.findall(_text(text)))


def _has_text(value):
    return bool(_text(value).strip())


def _still_open_rows(proof_status_text):
    lines = _text(proof_status_text).splitlines()
    in_section = False
    rows = []
    for line in lines:
        stripped = line.strip()
        if stripped.lower().startswith("## still open"):
            in_section = True
            continue
        if in_section and stripped.startswith("## "):
            break
        if not in_section:
            continue
        if not stripped.startswith("|") or "---" in stripped.lower():
            continue
        cells = [cell.strip() for cell in stripped.strip("|").split("|")]
        if not cells or cells[0].lower() in {"item", ""}:
            continue
        rows.append({"item": cells[0], "detail": cells[1] if len(cells) > 1 else ""})
    return rows


def _negative_evidence_lines(evidence_manifest_text):
    lines = []
    for line in _text(evidence_manifest_text).splitlines():
        lowered = line.lower()
        if any(token in lowered for token in EVIDENCE_NEGATIVE_TOKENS):
            lines.append(line.strip())
    return lines


def _appendix_or_supplement_present(document):
    main_text = _text(document.get("main_tex_text"))
    return bool(
        document.get("appendix_paths")
        or document.get("supplement_paths")
        or APPENDIX_RE.search(main_text)
    )


def _appendix_or_supplement_waived(document):
    corpus = "\n".join(
        [
            _text(document.get("main_tex_text")),
            _text(document.get("proof_status_text")),
            _text(document.get("evidence_manifest_text")),
        ]
    )
    return bool(WAIVER_RE.search(corpus))


def _theorem_surface_required(document):
    corpus = "\n".join(
        [
            _text(document.get("main_tex_text")),
            _text(document.get("proof_status_text")),
            _text(document.get("evidence_manifest_text")),
        ]
    ).lower()
    return bool(
        THEOREM_ENV_RE.search(_text(document.get("main_tex_text")))
        or "theorem" in corpus
        or "proof" in corpus
    )


def _add_check(checks, name, ok, detail="", blocking=True, slug=""):
    checks.append(
        {
            "name": name,
            "slug": slug,
            "status": "PASS" if ok else "FAIL",
            "detail": str(detail),
            "blocking": bool(blocking),
        }
    )


def _paper_report(slug, document):
    main_text = _text(document.get("main_tex_text"))
    proof_status_text = _text(document.get("proof_status_text"))
    evidence_manifest_text = _text(document.get("evidence_manifest_text"))
    theorem_statement_count = _count(THEOREM_ENV_RE, main_text)
    proof_environment_count = _count(PROOF_ENV_RE, main_text)
    proof_skeleton_marker_count = _count(PROOF_SKELETON_RE, main_text + "\n" + proof_status_text)
    open_rows = _still_open_rows(proof_status_text)
    negative_lines = _negative_evidence_lines(evidence_manifest_text)
    theorem_required = _theorem_surface_required(document)
    appendix_present = _appendix_or_supplement_present(document)
    appendix_waived = _appendix_or_supplement_waived(document)
    missing_required_files = []
    if not _has_text(main_text):
        missing_required_files.append("main.tex")
    if theorem_required and not _has_text(proof_status_text):
        missing_required_files.append("proof_status.md")
    if theorem_required and not _has_text(evidence_manifest_text):
        missing_required_files.append("evidence_manifest.md")
    missing_appendix = bool(theorem_required and not appendix_present and not appendix_waived)
    report = {
        "slug": slug,
        "source_dir": document.get("source_dir") or "",
        "main_tex_path": document.get("main_tex_path") or "",
        "proof_status_path": document.get("proof_status_path") or "",
        "evidence_manifest_path": document.get("evidence_manifest_path") or "",
        "appendix_paths": list(document.get("appendix_paths") or []),
        "supplement_paths": list(document.get("supplement_paths") or []),
        "theorem_surface_required": theorem_required,
        "theorem_statement_count": theorem_statement_count,
        "proof_environment_count": proof_environment_count,
        "proof_skeleton_marker_count": proof_skeleton_marker_count,
        "open_proof_obligation_count": len(open_rows),
        "open_proof_obligations": open_rows,
        "appendix_or_supplement_present": appendix_present,
        "appendix_or_supplement_waived": appendix_waived,
        "missing_appendix_supplement": missing_appendix,
        "evidence_manifest_negative_boundary_count": len(negative_lines),
        "evidence_manifest_negative_boundary_lines": negative_lines[:20],
        "missing_required_files": missing_required_files,
    }
    ready = bool(
        (not theorem_required)
        or (
            not missing_required_files
            and theorem_statement_count > 0
            and proof_environment_count > 0
            and proof_skeleton_marker_count == 0
            and not open_rows
            and not missing_appendix
            and not negative_lines
        )
    )
    report["theorem_proof_appendix_ready"] = ready
    return report


def build_theorem_proof_appendix_gate(slug_documents, label="", created_at=""):
    slug_documents = dict(slug_documents or {})
    checks = []
    paper_reports = []
    for slug in sorted(slug_documents):
        document = slug_documents.get(slug) or {}
        item = _paper_report(slug, document)
        paper_reports.append(item)
        theorem_required = bool(item["theorem_surface_required"])
        _add_check(
            checks,
            f"{slug}_main_tex_present",
            bool(item["main_tex_path"] and _has_text(document.get("main_tex_text"))),
            item["main_tex_path"] or "missing",
            slug=slug,
        )
        if not theorem_required:
            _add_check(
                checks,
                f"{slug}_theorem_surface_not_required",
                True,
                "no theorem/proof surface detected",
                slug=slug,
            )
            continue
        _add_check(
            checks,
            f"{slug}_proof_status_present",
            bool(item["proof_status_path"] and _has_text(document.get("proof_status_text"))),
            item["proof_status_path"] or "missing",
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_evidence_manifest_present",
            bool(item["evidence_manifest_path"] and _has_text(document.get("evidence_manifest_text"))),
            item["evidence_manifest_path"] or "missing",
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_theorem_statements_present",
            item["theorem_statement_count"] > 0,
            f"theorem_statement_count={item['theorem_statement_count']}",
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_proof_environments_present",
            item["proof_environment_count"] > 0,
            f"proof_environment_count={item['proof_environment_count']}",
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_no_proof_skeleton_markers",
            item["proof_skeleton_marker_count"] == 0,
            f"proof_skeleton_marker_count={item['proof_skeleton_marker_count']}",
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_no_open_proof_obligations",
            item["open_proof_obligation_count"] == 0,
            f"open_proof_obligation_count={item['open_proof_obligation_count']}",
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_appendix_or_supplement_present_or_waived",
            not item["missing_appendix_supplement"],
            (
                f"appendix_present={item['appendix_or_supplement_present']} "
                f"waived={item['appendix_or_supplement_waived']}"
            ),
            slug=slug,
        )
        _add_check(
            checks,
            f"{slug}_evidence_manifest_entails_theorem_claims",
            item["evidence_manifest_negative_boundary_count"] == 0,
            f"negative_boundary_count={item['evidence_manifest_negative_boundary_count']}",
            slug=slug,
        )

    failed = [check for check in checks if check.get("blocking") and check.get("status") != "PASS"]
    summary = {
        "paper_count": len(paper_reports),
        "theorem_surface_count": sum(1 for item in paper_reports if item["theorem_surface_required"]),
        "theorem_statement_count": sum(item["theorem_statement_count"] for item in paper_reports),
        "proof_environment_count": sum(item["proof_environment_count"] for item in paper_reports),
        "proof_skeleton_marker_count": sum(item["proof_skeleton_marker_count"] for item in paper_reports),
        "open_proof_obligation_count": sum(item["open_proof_obligation_count"] for item in paper_reports),
        "missing_appendix_supplement_count": sum(1 for item in paper_reports if item["missing_appendix_supplement"]),
        "evidence_manifest_negative_boundary_count": sum(item["evidence_manifest_negative_boundary_count"] for item in paper_reports),
        "missing_required_file_count": sum(len(item["missing_required_files"]) for item in paper_reports),
        "missing_proof_status_count": sum(
            1 for item in paper_reports if "proof_status.md" in item["missing_required_files"]
        ),
        "missing_evidence_manifest_count": sum(
            1 for item in paper_reports if "evidence_manifest.md" in item["missing_required_files"]
        ),
        "failed_check_count": len(failed),
    }
    summary["theorem_proof_appendix_ready"] = bool(not failed)
    if summary["missing_required_file_count"]:
        state = "BLOCKED_THEOREM_REQUIRED_FILES_MISSING"
    elif summary["open_proof_obligation_count"]:
        state = "BLOCKED_OPEN_PROOF_OBLIGATIONS"
    elif summary["proof_skeleton_marker_count"]:
        state = "BLOCKED_PROOF_SKELETONS"
    elif summary["missing_appendix_supplement_count"]:
        state = "BLOCKED_APPENDIX_SUPPLEMENT_MISSING"
    elif summary["evidence_manifest_negative_boundary_count"]:
        state = "BLOCKED_EVIDENCE_MANIFEST_CLAIM_BOUNDARY"
    elif failed:
        state = "BLOCKED_THEOREM_PROOF_APPENDIX_GATE"
    else:
        state = "THEOREM_PROOF_APPENDIX_GATE_PASS"
    return {
        "schema_id": SCHEMA_ID,
        "command": COMMAND,
        "status": "FAIL" if failed else "PASS",
        "label": label,
        "created_at": created_at,
        "theorem_proof_appendix_state": state,
        "slugs": sorted(slug_documents),
        "summary": summary,
        "paper_reports": paper_reports,
        "checks": checks,
        "failed_checks": failed,
        "manual_boundary": [
            "This gate reads manuscript/proof/evidence files and reports theorem readiness only.",
            "It never edits manuscripts, creates proof evidence, applies patches, rebuilds packages, uploads, emails, submits, or fabricates venue/proof/receipt evidence.",
            "Proof sketches, open obligations, missing appendix/supplement coverage, or evidence manifests that disclaim theorem support block referee_submission_ready.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Theorem Proof Appendix Gate",
        "",
        f"- Label: {report.get('label', '')}",
        f"- Status: {report.get('status', '')}",
        f"- State: {report.get('theorem_proof_appendix_state', '')}",
        f"- Created at: {report.get('created_at', '')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Papers", "", "| slug | ready | theorem envs | proof envs | skeletons | open obligations | appendix missing | evidence negative |", "| --- | --- | ---: | ---: | ---: | ---: | --- | ---: |"])
    for item in report.get("paper_reports") or []:
        lines.append(
            f"| {item.get('slug', '')} | {item.get('theorem_proof_appendix_ready')} | "
            f"{item.get('theorem_statement_count', 0)} | {item.get('proof_environment_count', 0)} | "
            f"{item.get('proof_skeleton_marker_count', 0)} | {item.get('open_proof_obligation_count', 0)} | "
            f"{item.get('missing_appendix_supplement')} | {item.get('evidence_manifest_negative_boundary_count', 0)} |"
        )
    lines.extend(["", "## Checks", "", "| check | status | detail |", "| --- | --- | --- |"])
    for check in report.get("checks") or []:
        detail = str(check.get("detail", "")).replace("|", "/")
        lines.append(f"| {check.get('name', '')} | {check.get('status', '')} | {detail} |")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("manual_boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
