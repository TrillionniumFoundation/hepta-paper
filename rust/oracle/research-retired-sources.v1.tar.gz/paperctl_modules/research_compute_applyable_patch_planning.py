"""Plan whether a review-only research-compute queue artifact can become an applyable patch."""

import re


COMMAND = "research-compute-applyable-patch-planning"
NO_PATCH_STATE = "RESEARCH_COMPUTE_APPLYABLE_PATCH_PLANNING_NO_APPLYABLE_PATCH_MATERIAL"
READY_STATE = "RESEARCH_COMPUTE_APPLYABLE_PATCH_PLANNING_READY_FOR_SOURCE_AUTHORIZATION"
ATTENTION_STATE = "RESEARCH_COMPUTE_APPLYABLE_PATCH_PLANNING_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
PROVIDER_READINESS_COMMAND = "llm-node-automation-provider-adapter-readiness-dry-run"
PROVIDER_READINESS_VERIFICATION_KEYS = [
    "goal_progress_latest_events_verified",
    "source_package_archive_boundary_latest_event_verified",
]


def _safe_relative_path(path):
    text = str(path or "")
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _candidate_note_patch_signals(candidate_note_text):
    text = candidate_note_text or ""
    diff_signal = "diff --git " in text or bool(re.search(r"(?m)^---\\s+\\S+\\n\\+\\+\\+\\s+\\S+", text))
    fenced_diff_signal = "```diff" in text.lower()
    source_path_signal = bool(re.search(r"(?i)(drafts/|manuscript|source\\s+file|\\.tex\\b|\\.bib\\b)", text))
    return {
        "candidate_note_bytes": len(text.encode("utf-8")),
        "contains_unified_diff": bool(diff_signal or fenced_diff_signal),
        "contains_source_target_hint": source_path_signal,
        "contains_applyable_patch_material": bool((diff_signal or fenced_diff_signal) and source_path_signal),
    }


def validate_queue_artifact(queue_artifact):
    issues = []
    artifact = queue_artifact or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if not _safe_relative_path(artifact.get("candidate_note_path") or ""):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": artifact.get("candidate_note_path") or ""})
    if not _valid_sha256(artifact.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_expected_review_only_not_applyable"})
    if artifact.get("source_mutation_performed") or artifact.get("package_mutation_performed") or artifact.get("archive_mutation_performed"):
        issues.append({"issue": "forbidden_queue_artifact_source_package_archive_mutation"})
    if artifact.get("provider_model_call_performed") or artifact.get("external_action_performed") or artifact.get("commit_performed"):
        issues.append({"issue": "forbidden_queue_artifact_external_or_commit_action"})
    return issues


def validate_patch_queue_row(patch_queue_row, queue_artifact, queue_artifact_path="", queue_artifact_sha256=""):
    issues = []
    row = patch_queue_row or {}
    artifact = queue_artifact or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if row.get("slug") != artifact.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if queue_artifact_path and row.get("patch_path") != queue_artifact_path:
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if queue_artifact_sha256 and row.get("patch_sha256") != queue_artifact_sha256:
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if artifact.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    return issues


def validate_provider_readiness(provider_readiness_report):
    issues = []
    if not provider_readiness_report:
        return issues
    report = provider_readiness_report or {}
    if report.get("command") != PROVIDER_READINESS_COMMAND:
        issues.append({"issue": "provider_readiness_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "provider_readiness_not_pass", "detail": report.get("status") or ""})
    if not report.get("provider_adapter_shape_ready"):
        issues.append({"issue": "provider_adapter_shape_not_ready"})
    for key in PROVIDER_READINESS_VERIFICATION_KEYS:
        if not isinstance(report.get(key), bool):
            issues.append({"issue": f"invalid_provider_readiness_boolean:{key}", "detail": repr(report.get(key))})
        if report.get(key) is not True:
            issues.append({"issue": f"provider_readiness_{key}_not_verified"})
    for key in [
        "real_provider_model_call_performed",
        "credential_lookup_performed",
        "network_call_performed",
        "external_action_performed",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_provider_readiness_boundary_crossed:{key}"})
    return issues


def research_compute_applyable_patch_planning(
    queue_artifact,
    candidate_note_text="",
    patch_queue_row=None,
    queue_artifact_path="",
    queue_artifact_sha256="",
    provider_readiness_report=None,
    label="",
):
    queue_artifact = queue_artifact or {}
    patch_queue_row = patch_queue_row or {}
    provider_readiness_report = provider_readiness_report or {}
    signals = _candidate_note_patch_signals(candidate_note_text)
    provider_readiness_present = bool(provider_readiness_report)
    provider_goal_progress_latest_events_verified = (
        provider_readiness_report.get("goal_progress_latest_events_verified") is True
    )
    provider_source_package_archive_boundary_latest_event_verified = (
        provider_readiness_report.get("source_package_archive_boundary_latest_event_verified") is True
    )
    provider_readiness_current = (
        provider_readiness_present
        and provider_goal_progress_latest_events_verified
        and provider_source_package_archive_boundary_latest_event_verified
    )

    issues = []
    issues.extend(validate_queue_artifact(queue_artifact))
    issues.extend(validate_patch_queue_row(patch_queue_row, queue_artifact, queue_artifact_path, queue_artifact_sha256))
    issues.extend(validate_provider_readiness(provider_readiness_report))

    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_queue_artifact")
        or str(item.get("issue") or "").startswith("forbidden_provider_readiness")
        for item in issues
    )
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif signals["contains_applyable_patch_material"]:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = NO_PATCH_STATE

    ready_for_source_authorization = state == READY_STATE
    blocked_reason = ""
    if not ready_for_source_authorization:
        blocked_reason = "validation_issues_present" if issues else "candidate_note_contains_evidence_only_no_applyable_diff"

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "applyable_patch_planning_state": state,
        "applyable_patch_planning_created": status == "PASS",
        "candidate_note_reviewed": status == "PASS",
        "queue_artifact_reviewed": status == "PASS",
        "applyable_patch_material_present": bool(signals["contains_applyable_patch_material"]) and status == "PASS",
        "applyable_patch_plan_ready": ready_for_source_authorization,
        "source_authorization_ready": ready_for_source_authorization,
        "provider_readiness_present": provider_readiness_present,
        "provider_readiness_goal_progress_latest_events_verified": (
            provider_goal_progress_latest_events_verified and status == "PASS"
        ),
        "provider_readiness_source_package_archive_boundary_latest_event_verified": (
            provider_source_package_archive_boundary_latest_event_verified and status == "PASS"
        ),
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "candidate_note_bytes": signals["candidate_note_bytes"],
            "contains_unified_diff_count": 1 if signals["contains_unified_diff"] else 0,
            "contains_source_target_hint_count": 1 if signals["contains_source_target_hint"] else 0,
            "applyable_patch_material_count": 1 if signals["contains_applyable_patch_material"] else 0,
            "applyable_patch_plan_ready_count": 1 if ready_for_source_authorization else 0,
            "provider_readiness_goal_progress_latest_events_verified": provider_goal_progress_latest_events_verified,
            "provider_readiness_source_package_archive_boundary_latest_event_verified": provider_source_package_archive_boundary_latest_event_verified,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "candidate_note_patch_signals": signals,
        "queue_artifact": queue_artifact,
        "patch_queue_row": patch_queue_row,
        "provider_readiness_reference": {
            "report_path": provider_readiness_report.get("report_path") or "",
            "status": provider_readiness_report.get("status") or "",
            "state": provider_readiness_report.get("provider_adapter_readiness_state") or "",
            "goal_progress_latest_events_verified": provider_readiness_report.get("goal_progress_latest_events_verified"),
            "source_package_archive_boundary_latest_event_verified": provider_readiness_report.get("source_package_archive_boundary_latest_event_verified"),
        },
        "applyable_patch_planning_packet": {
            "planning_ready": status == "PASS",
            "applyable_patch_plan_ready": ready_for_source_authorization,
            "provider_readiness_present": provider_readiness_present,
            "provider_readiness_goal_progress_latest_events_verified": (
                provider_goal_progress_latest_events_verified and status == "PASS"
            ),
            "provider_readiness_source_package_archive_boundary_latest_event_verified": (
                provider_source_package_archive_boundary_latest_event_verified and status == "PASS"
            ),
            "patch_id": int(patch_queue_row.get("patch_id") or 0),
            "slug": queue_artifact.get("slug") or patch_queue_row.get("slug") or "",
            "candidate_note_path": queue_artifact.get("candidate_note_path") or "",
            "candidate_note_sha256": queue_artifact.get("candidate_note_sha256") or "",
            "queue_artifact_path": queue_artifact_path or "",
            "queue_artifact_sha256": queue_artifact_sha256 or "",
            "blocked_reason": blocked_reason,
            "automatic_next_gate": "",
            "manual_next_gate": "source-mutation-authorization-intake" if ready_for_source_authorization else "provide-independent-applyable-patch-draft",
            "parallel_next_gate": "real-provider-model-call-authorization-intake" if provider_readiness_current and status == "PASS" else "",
        },
        "boundary": [
            "This planning report inspects a review-only candidate-note queue artifact and records whether it contains applyable patch material.",
            "It does not generate a source patch, mutate source/package/archive state, call providers/models, perform external actions, merge, dequeue, supersede, or commit.",
            "Source mutation remains a separate authorization gate after an actual applyable patch exists.",
        ],
    }


def research_compute_applyable_patch_planning_markdown(report):
    packet = report.get("applyable_patch_planning_packet") or {}
    lines = [
        "# paper_factory Research Compute Applyable Patch Planning",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('applyable_patch_planning_state') or ''}",
        f"- Applyable patch material present: {report.get('applyable_patch_material_present')}",
        f"- Applyable patch plan ready: {report.get('applyable_patch_plan_ready')}",
        f"- Provider readiness latest events verified: {report.get('provider_readiness_goal_progress_latest_events_verified')}",
        f"- Source/package/archive latest event verified: {report.get('provider_readiness_source_package_archive_boundary_latest_event_verified')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Planning Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Blocked reason: `{packet.get('blocked_reason') or ''}`",
        f"- Manual next gate: `{packet.get('manual_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
