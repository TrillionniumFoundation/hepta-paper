"""Pure research-compute bridge helpers for paperctl.

The bridge is intentionally spec-only. It translates research gaps into local
compute job specifications without executing commands, calling models, or
mutating manuscript/package/archive state.
"""


COMMAND = "research-compute-bridge-plan"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "plan_state",
    "report_schema",
    "plan_only",
    "execute_allowed",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "slugs",
    "gaps",
    "jobs",
    "validation_issues",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "slug_count",
    "gap_count",
    "job_count",
    "experiment_job_count",
    "proof_job_count",
    "reproducibility_job_count",
    "artifact_job_count",
    "classification_required_count",
    "execute_allowed_count",
]
REPORT_SCHEMA_NOTES = [
    "Spec-only local research-compute bridge.",
    "The command may write a local report/event, but it never executes compute jobs or mutates source/package/archive state.",
]

GAP_KIND_ALIASES = {
    "artifact": "artifact",
    "artifacts": "artifact",
    "benchmark": "experiment",
    "benchmarks": "experiment",
    "empirical": "experiment",
    "experiment": "experiment",
    "experimental": "experiment",
    "proof": "proof",
    "repro": "reproducibility",
    "reproducibility": "reproducibility",
    "simulation": "experiment",
    "theorem": "proof",
    "theory": "proof",
    "theory-boundary": "proof",
}

RESOURCE_PROFILES = {
    "artifact": {"cpu_cores": 2, "memory_gb": 8, "timeout_seconds": 1800, "max_workers": 1},
    "experiment": {"cpu_cores": 4, "memory_gb": 16, "timeout_seconds": 7200, "max_workers": 1},
    "proof": {"cpu_cores": 2, "memory_gb": 8, "timeout_seconds": 3600, "max_workers": 1},
    "reproducibility": {"cpu_cores": 2, "memory_gb": 8, "timeout_seconds": 1800, "max_workers": 1},
    "unknown": {"cpu_cores": 1, "memory_gb": 4, "timeout_seconds": 900, "max_workers": 1},
}

RISK_CLASSES = {
    "artifact": "artifact-refresh-spec",
    "experiment": "empirical-compute-spec",
    "proof": "theory-proof-spec",
    "reproducibility": "reproducibility-compute-spec",
    "unknown": "manual-gap-classification-required",
}

FORBIDDEN_ACTIONS = [
    "source_tree_mutation",
    "package_mutation",
    "archive_mutation",
    "external_network_action",
    "provider_model_call",
    "decision_report_consumption",
    "patch_queue_mutation",
    "automatic_manuscript_merge",
]


def safe_slug(value):
    allowed = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789._-"
    text = "".join(ch if ch in allowed else "_" for ch in str(value or "UNSPECIFIED")).strip("_")
    return (text or "UNSPECIFIED")[:120]


def normalize_gap_kind(raw_kind):
    key = str(raw_kind or "").strip().lower().replace("_", "-")
    return GAP_KIND_ALIASES.get(key, "unknown")


def parse_gap_spec(raw_spec, default_slug="", index=1):
    raw = str(raw_spec or "").strip()
    parts = [part.strip() for part in raw.split(":", 2)]
    slug = default_slug or ""
    raw_kind = ""
    detail = ""
    if len(parts) == 3:
        slug, raw_kind, detail = parts
    elif len(parts) == 2:
        first_kind = normalize_gap_kind(parts[0])
        if first_kind != "unknown":
            raw_kind, detail = parts
        else:
            slug, raw_kind = parts
    elif parts:
        raw_kind = parts[0]
    slug = safe_slug(slug or default_slug or "UNSPECIFIED")
    gap_kind = normalize_gap_kind(raw_kind)
    return {
        "gap_id": f"GAP-{index:03d}",
        "raw_spec": raw,
        "slug": slug,
        "raw_gap_kind": raw_kind,
        "gap_kind": gap_kind,
        "detail": detail,
        "classification_required": gap_kind == "unknown",
    }


def resource_profile_for(gap_kind, max_workers=0, timeout_seconds=0):
    profile = dict(RESOURCE_PROFILES.get(gap_kind) or RESOURCE_PROFILES["unknown"])
    if max_workers:
        profile["max_workers"] = max(1, int(max_workers))
    if timeout_seconds:
        profile["timeout_seconds"] = max(1, int(timeout_seconds))
    return profile


def expected_outputs_for(gap_kind):
    common = [
        "manifest.json",
        "stdout.log",
        "stderr.log",
        "output-hashes.json",
        "candidate-patch-plan.json",
    ]
    if gap_kind == "experiment":
        return common + ["metrics.json", "figures/", "tables/"]
    if gap_kind == "proof":
        return common + ["proof-notes.md", "lemma-checklist.json", "formal-verifier-slot.json", "proof-check-result.json"]
    if gap_kind == "reproducibility":
        return common + ["reproduction-log.json", "artifact-diff.json"]
    if gap_kind == "artifact":
        return common + ["artifact-index.json", "artifact-integrity.json"]
    return common


def success_criteria_for(gap_kind):
    common = [
        "job command exits zero when an operator later supplies and runs it",
        "all declared outputs are present under the job workspace",
        "output-hashes.json records sha256 for every promoted output",
        "candidate-patch-plan.json is candidate-only and requires a later gate",
    ]
    if gap_kind == "experiment":
        return common + ["metrics/tables/figures are reproducible from local inputs"]
    if gap_kind == "proof":
        return common + [
            "proof-notes.md states theorem assumptions and checked obligations",
            "formal-verifier-slot.json separates local proof notes from future machine-checked certificates",
        ]
    if gap_kind == "reproducibility":
        return common + ["reproduction-log.json links every regenerated artifact to inputs"]
    if gap_kind == "artifact":
        return common + ["artifact-integrity.json records provenance and retention decision"]
    return common + ["gap kind is manually classified before execution"]


def build_job_spec(gap, index, label="", max_workers=0, timeout_seconds=0):
    gap_kind = gap.get("gap_kind") or "unknown"
    slug = safe_slug(gap.get("slug") or "UNSPECIFIED")
    job_id = f"RCB-{index:03d}"
    label_part = safe_slug(label or "plan")
    workspace_dir = f"logs/paperctl/research_compute/{label_part}/{slug}/{job_id}"
    return {
        "job_id": job_id,
        "gap_id": gap.get("gap_id") or f"GAP-{index:03d}",
        "slug": slug,
        "gap_kind": gap_kind,
        "raw_gap_kind": gap.get("raw_gap_kind") or "",
        "detail": gap.get("detail") or "",
        "risk_class": RISK_CLASSES.get(gap_kind) or RISK_CLASSES["unknown"],
        "runner": "local",
        "execution_state": "SPEC_ONLY_NOT_EXECUTED",
        "execute_allowed": False,
        "requires_operator_command": True,
        "argv_template": ["<operator-supplied-local-command>"],
        "resource_limits": resource_profile_for(gap_kind, max_workers=max_workers, timeout_seconds=timeout_seconds),
        "workspace_dir": workspace_dir,
        "allowed_write_sets": [workspace_dir],
        "expected_outputs": expected_outputs_for(gap_kind),
        "success_criteria": success_criteria_for(gap_kind),
        "forbidden_actions": list(FORBIDDEN_ACTIONS),
        "patch_policy": "candidate_patch_only_after_output_hashes_and_gate",
        "classification_required": bool(gap.get("classification_required")),
    }


def validate_bridge_plan(report):
    issues = []
    for job in report.get("jobs") or []:
        if job.get("execute_allowed"):
            issues.append({"job_id": job.get("job_id"), "issue": "execute_allowed_must_remain_false"})
        for path in job.get("allowed_write_sets") or []:
            if not str(path).startswith("logs/paperctl/research_compute/"):
                issues.append({"job_id": job.get("job_id"), "issue": f"write_set_outside_research_compute_logs:{path}"})
        missing_forbidden = [item for item in FORBIDDEN_ACTIONS if item not in (job.get("forbidden_actions") or [])]
        if missing_forbidden:
            issues.append({"job_id": job.get("job_id"), "issue": f"missing_forbidden_actions:{','.join(missing_forbidden)}"})
    if report.get("execution_performed"):
        issues.append({"issue": "execution_performed_must_remain_false"})
    if report.get("provider_model_call_performed"):
        issues.append({"issue": "provider_model_call_performed_must_remain_false"})
    if report.get("external_action_performed"):
        issues.append({"issue": "external_action_performed_must_remain_false"})
    return issues


def research_compute_bridge_plan(slugs=None, gap_specs=None, label="", max_workers=0, timeout_seconds=0):
    slugs = [safe_slug(slug) for slug in (slugs or []) if str(slug or "").strip()]
    gap_specs = list(gap_specs or [])
    default_slug = slugs[0] if len(slugs) == 1 else ""
    gaps = [parse_gap_spec(spec, default_slug=default_slug, index=index) for index, spec in enumerate(gap_specs, 1)]
    jobs = [
        build_job_spec(gap, index, label=label, max_workers=max_workers, timeout_seconds=timeout_seconds)
        for index, gap in enumerate(gaps, 1)
    ]
    manual_intake = []
    if not gaps:
        for slug in slugs:
            manual_intake.append({
                "slug": slug,
                "state": "RESEARCH_GAP_SPEC_REQUIRED",
                "accepted_gap_forms": ["experiment:<detail>", "proof:<detail>", "slug:experiment:<detail>", "slug:proof:<detail>"],
            })
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": "PASS" if jobs and not any(job.get("classification_required") for job in jobs) else "ATTENTION",
        "plan_state": "SPEC_READY_NOT_EXECUTED" if jobs else "RESEARCH_GAP_SPEC_REQUIRED",
        "plan_only": True,
        "execute_allowed": False,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "summary": {
            "slug_count": len(slugs),
            "gap_count": len(gaps),
            "job_count": len(jobs),
            "experiment_job_count": sum(1 for job in jobs if job.get("gap_kind") == "experiment"),
            "proof_job_count": sum(1 for job in jobs if job.get("gap_kind") == "proof"),
            "reproducibility_job_count": sum(1 for job in jobs if job.get("gap_kind") == "reproducibility"),
            "artifact_job_count": sum(1 for job in jobs if job.get("gap_kind") == "artifact"),
            "classification_required_count": sum(1 for job in jobs if job.get("classification_required")),
            "execute_allowed_count": sum(1 for job in jobs if job.get("execute_allowed")),
        },
        "slugs": slugs,
        "gaps": gaps,
        "jobs": jobs,
        "manual_intake": manual_intake,
        "boundary": [
            "This bridge only creates local compute job specifications.",
            "No experiment/proof command is executed by this command.",
            "No provider/model call, external action, source mutation, package mutation, archive mutation, or patch queue mutation is performed.",
            "Future execution requires a separate explicit operator command, output hashes, and candidate gate.",
        ],
    }
    issues = validate_bridge_plan(report)
    report["validation_issues"] = issues
    if issues:
        report["status"] = "FAIL"
        report["plan_state"] = "BRIDGE_SPEC_INVALID"
    return report


def research_compute_bridge_markdown(report):
    lines = [
        "# paper_factory Research Compute Bridge Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Plan state: {report.get('plan_state') or ''}",
        f"- Plan only: {report.get('plan_only')}",
        f"- Execution performed: {report.get('execution_performed')}",
        f"- Provider/model call performed: {report.get('provider_model_call_performed')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Jobs", ""])
    if not report.get("jobs"):
        lines.append("- No jobs yet; supply explicit research gap specs.")
    for job in report.get("jobs") or []:
        lines.append(f"- `{job.get('job_id')}` `{job.get('slug')}` {job.get('gap_kind')} {job.get('execution_state')} workspace=`{job.get('workspace_dir')}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
