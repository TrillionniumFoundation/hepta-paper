"""Review verified research-compute candidate notes before patch-queue enqueue."""

import datetime as dt

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-candidate-note-integration-review"
PREVIOUS_COMMAND = "research-compute-source-post-apply-verify"
PREVIOUS_READY_STATE = "SOURCE_POST_APPLY_VERIFIED_INTEGRATION_STATUS_READY"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "integration_review_state",
    "report_schema",
    "candidate_note_integration_reviewed",
    "patch_queue_enqueue_preflight_created",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_enqueue_authorized",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_enqueue_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "post_apply_verify_reference",
    "target_snapshot",
    "patch_queue_snapshot",
    "enqueue_preflight_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "candidate_note_reviewed_count",
    "patch_queue_enqueue_preflight_count",
    "active_patch_queue_count",
    "candidate_note_queue_row_count",
    "agent_generated_evidence_material_count",
    "patch_queue_enqueue_authorized_count",
    "patch_queue_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Reviews a verified research-compute candidate note and creates an enqueue preflight packet only.",
    "No patch_queue row, patch application, package/archive mutation, commit, merge, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def _safe_component(value):
    text = str(value or "")
    return bool(text) and all(ch.isalnum() or ch in "._-" for ch in text)


def validate_post_apply_verify_report(post_apply_verify_report):
    issues = []
    report = post_apply_verify_report or {}
    status = report.get("integration_status") or {}
    policy = agent_autonomy_policy.normalize_policy(status.get("autonomy_policy") or report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "post_apply_verify_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "post_apply_verify_not_pass", "detail": report.get("status") or ""})
    if report.get("post_apply_verify_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "post_apply_verify_state_not_ready", "detail": report.get("post_apply_verify_state") or ""})
    if not _literal_bool_or_missing(report.get("source_post_apply_verified")):
        issues.append({"issue": "invalid_post_apply_boolean:source_post_apply_verified", "detail": repr(report.get("source_post_apply_verified"))})
    if not _literal_true(report.get("source_post_apply_verified")):
        issues.append({"issue": "source_post_apply_verified_required"})
    if not _literal_bool_or_missing(report.get("candidate_note_integrated")):
        issues.append({"issue": "invalid_post_apply_boolean:candidate_note_integrated", "detail": repr(report.get("candidate_note_integrated"))})
    if not _literal_true(report.get("candidate_note_integrated")):
        issues.append({"issue": "candidate_note_integrated_required"})
    if report.get("validation_issues"):
        issues.append({"issue": "post_apply_verify_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    target = str(status.get("target_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_candidate_note_target_path", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_target_outside_allowlist", "detail": target})
    if not _valid_sha256(status.get("target_sha256")):
        issues.append({"issue": "candidate_note_target_sha256_required"})
    if not _safe_component(status.get("slug") or ""):
        issues.append({"issue": "candidate_note_slug_missing_or_unsafe", "detail": status.get("slug") or ""})
    if not _safe_component(status.get("job_id") or ""):
        issues.append({"issue": "candidate_note_job_id_missing_or_unsafe", "detail": status.get("job_id") or ""})
    if not _literal_bool_or_missing(status.get("candidate_note_integrated")):
        issues.append({"issue": "invalid_integration_status_boolean:candidate_note_integrated", "detail": repr(status.get("candidate_note_integrated"))})
    if not _literal_true(status.get("candidate_note_integrated")):
        issues.append({"issue": "integration_status_candidate_note_integrated_required"})
    if not _literal_bool_or_missing(status.get("artifact_hashes_verified")):
        issues.append({"issue": "invalid_integration_status_boolean:artifact_hashes_verified", "detail": repr(status.get("artifact_hashes_verified"))})
    if not _literal_true(status.get("artifact_hashes_verified")):
        issues.append({"issue": "artifact_hashes_verified_required"})
    if not _literal_bool_or_missing(status.get("rollback_patch_verified")):
        issues.append({"issue": "invalid_integration_status_boolean:rollback_patch_verified", "detail": repr(status.get("rollback_patch_verified"))})
    if not _literal_true(status.get("rollback_patch_verified")):
        issues.append({"issue": "rollback_patch_verified_required"})
    if not _literal_bool_or_missing(status.get("patch_queue_enqueue_allowed")):
        issues.append({"issue": "invalid_integration_status_boolean:patch_queue_enqueue_allowed", "detail": repr(status.get("patch_queue_enqueue_allowed"))})
    elif _literal_true(status.get("patch_queue_enqueue_allowed")):
        issues.append({"issue": "post_apply_verify_must_not_allow_patch_queue_enqueue"})
    if not _literal_bool_or_missing(status.get("commit_allowed")):
        issues.append({"issue": "invalid_integration_status_boolean:commit_allowed", "detail": repr(status.get("commit_allowed"))})
    elif _literal_true(status.get("commit_allowed")):
        issues.append({"issue": "post_apply_verify_must_not_allow_commit"})
    if status.get("required_next_gate") != "research_compute_candidate_note_integration_review":
        issues.append({"issue": "required_next_gate_mismatch", "detail": status.get("required_next_gate") or ""})

    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_enqueue_authorized",
        "candidate_patch_queue_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        authorization_allowed_by_policy = full_autonomy and key in {
            "provider_model_call_authorized",
            "external_action_authorized",
        }
        if not _literal_bool_or_missing(report.get(key)):
            issues.append({"issue": f"invalid_post_apply_boolean:{key}", "detail": repr(report.get(key))})
        elif _literal_true(report.get(key)) and not authorization_allowed_by_policy:
            issues.append({"issue": f"forbidden_post_apply_boundary_crossed:{key}"})
    return issues


def validate_target_snapshot(target_snapshot, post_apply_verify_report):
    issues = []
    snapshot = target_snapshot or {}
    status = (post_apply_verify_report or {}).get("integration_status") or {}
    if str(snapshot.get("path") or "") != str(status.get("target_path") or ""):
        issues.append({"issue": "candidate_note_target_path_mismatch"})
    if not _literal_bool_or_missing(snapshot.get("exists")):
        issues.append({"issue": "invalid_target_snapshot_boolean:exists", "detail": repr(snapshot.get("exists"))})
    if not _literal_true(snapshot.get("exists")):
        issues.append({"issue": "candidate_note_target_missing", "detail": snapshot.get("path") or ""})
    if not _literal_bool_or_missing(snapshot.get("is_file")):
        issues.append({"issue": "invalid_target_snapshot_boolean:is_file", "detail": repr(snapshot.get("is_file"))})
    elif snapshot.get("is_file") is False:
        issues.append({"issue": "candidate_note_target_not_file", "detail": snapshot.get("path") or ""})
    if not _valid_sha256(snapshot.get("sha256")):
        issues.append({"issue": "candidate_note_target_sha256_required"})
    if snapshot.get("sha256") != status.get("target_sha256"):
        issues.append({"issue": "candidate_note_target_sha256_mismatch"})
    return issues


def validate_patch_queue_snapshot(patch_queue_snapshot):
    issues = []
    snapshot = patch_queue_snapshot or {}
    if not _literal_bool_or_missing(snapshot.get("db_checked")):
        issues.append({"issue": "invalid_patch_queue_snapshot_boolean:db_checked", "detail": repr(snapshot.get("db_checked"))})
    if not _literal_true(snapshot.get("db_checked")):
        issues.append({"issue": "patch_queue_snapshot_unavailable"})
    if int(snapshot.get("active_patch_queue_count") or 0) > 0:
        issues.append({"issue": "active_patch_queue_rows_for_slug", "detail": int(snapshot.get("active_patch_queue_count") or 0)})
    if int(snapshot.get("candidate_note_queue_row_count") or 0) > 0:
        issues.append({"issue": "candidate_note_already_has_patch_queue_rows", "detail": int(snapshot.get("candidate_note_queue_row_count") or 0)})
    return issues


def research_compute_candidate_note_integration_review(post_apply_verify_report, target_snapshot=None, patch_queue_snapshot=None, label=""):
    post_apply_verify_report = post_apply_verify_report or {}
    target_snapshot = target_snapshot or {}
    patch_queue_snapshot = patch_queue_snapshot or {}
    issues = validate_post_apply_verify_report(post_apply_verify_report)
    issues.extend(validate_target_snapshot(target_snapshot, post_apply_verify_report))
    issues.extend(validate_patch_queue_snapshot(patch_queue_snapshot))
    if issues and any(str(item.get("issue") or "").startswith("forbidden_post_apply_boundary_crossed") for item in issues):
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "CANDIDATE_NOTE_INTEGRATION_REVIEW_BLOCKED"
    else:
        status = "PASS"
        state = "CANDIDATE_NOTE_INTEGRATION_REVIEW_READY_NOT_ENQUEUED"
    ready = status == "PASS"
    integration_status = post_apply_verify_report.get("integration_status") or {}
    policy = agent_autonomy_policy.normalize_policy(integration_status.get("autonomy_policy") or post_apply_verify_report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = (
        _literal_true(integration_status.get("agent_generated_evidence_material"))
        or _literal_true(post_apply_verify_report.get("agent_generated_evidence_material"))
    )
    enqueue_preflight_packet = {
        "enqueue_preflight_ready": ready,
        "candidate_note_integration_reviewed": ready,
        "slug": integration_status.get("slug") or "",
        "job_id": integration_status.get("job_id") or "",
        "candidate_note_path": target_snapshot.get("path") or "",
        "candidate_note_sha256": target_snapshot.get("sha256") or "",
        "artifact_count": int(integration_status.get("artifact_count") or 0),
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "patch_queue_enqueue_allowed": False,
        "patch_queue_enqueue_authorized": False,
        "patch_queue_mutation_performed": False,
        "commit_allowed": False,
        "commit_performed": False,
        "manual_review_required": True,
        "required_next_gate": "research_compute_candidate_note_patch_queue_enqueue_gate",
    }
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "integration_review_state": state,
        "candidate_note_integration_reviewed": ready,
        "patch_queue_enqueue_preflight_created": ready,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_mutation_performed": False,
        "patch_queue_enqueue_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "candidate_note_reviewed_count": 1 if ready else 0,
            "patch_queue_enqueue_preflight_count": 1 if ready else 0,
            "active_patch_queue_count": int(patch_queue_snapshot.get("active_patch_queue_count") or 0),
            "candidate_note_queue_row_count": int(patch_queue_snapshot.get("candidate_note_queue_row_count") or 0),
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
            "patch_queue_enqueue_authorized_count": 0,
            "patch_queue_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "post_apply_verify_reference": {
            "report_path": post_apply_verify_report.get("report_path") or "",
            "status": post_apply_verify_report.get("status") or "",
            "post_apply_verify_state": post_apply_verify_report.get("post_apply_verify_state") or "",
        },
        "target_snapshot": target_snapshot,
        "patch_queue_snapshot": patch_queue_snapshot,
        "enqueue_preflight_packet": enqueue_preflight_packet,
        "boundary": [
            "This command reviews a verified research-compute candidate note and creates an enqueue preflight packet only.",
            "It does not write patch_queue rows, mutate source/package/archive state, call providers/models, commit, merge, upload, email, or perform external actions.",
            "A separate explicit patch-queue enqueue gate is required before any patch_queue row can be created.",
        ],
    }


def research_compute_candidate_note_integration_review_markdown(report):
    packet = report.get("enqueue_preflight_packet") or {}
    lines = [
        "# paper_factory Research Compute Candidate Note Integration Review",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('integration_review_state') or ''}",
        f"- Enqueue preflight created: {report.get('patch_queue_enqueue_preflight_created')}",
        f"- Patch queue mutation performed: {report.get('candidate_patch_queue_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Enqueue Preflight Packet",
        "",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Job: `{packet.get('job_id') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Candidate note SHA256: `{packet.get('candidate_note_sha256') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
