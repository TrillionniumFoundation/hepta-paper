"""Gate research-compute candidate notes before patch_queue enqueue."""

import datetime as dt

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-candidate-note-patch-queue-enqueue"
PREVIOUS_COMMAND = "research-compute-candidate-note-integration-review"
PREVIOUS_READY_STATE = "CANDIDATE_NOTE_INTEGRATION_REVIEW_READY_NOT_ENQUEUED"
TARGET_PREFIX = "research_compute_candidate_notes/"
QUEUE_ARTIFACT_PREFIXES = (
    "logs/paperctl/_batches/research_compute_candidate_note_patch_queue_enqueue/",
    "logs/paperctl/_batches/research_compute_candidate_note_queue_artifact_gate/",
)

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "enqueue_state",
    "report_schema",
    "candidate_note_enqueue_gate_checked",
    "patch_queue_enqueue_authorized",
    "candidate_patch_queue_enqueue_authorized",
    "patch_queue_enqueue_performed",
    "candidate_patch_queue_mutation_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "integration_review_reference",
    "candidate_note_snapshot",
    "patch_queue_snapshot",
    "queue_artifact",
    "enqueue_result",
    "enqueue_gate_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "enqueue_requested_count",
    "patch_queue_enqueue_authorized_count",
    "patch_queue_mutation_count",
    "active_patch_queue_count",
    "candidate_note_queue_row_count",
    "agent_generated_evidence_material_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Explicit gate for research-compute candidate-note patch_queue enqueue.",
    "Dry-run reports do not mutate patch_queue; enqueue requires explicit enqueue/write intent and an allowlisted queue artifact.",
    "No source/package/archive mutation, commit, merge, provider/model call, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def _safe_component(value):
    text = str(value or "")
    return bool(text) and all(ch.isalnum() or ch in "._-" for ch in text)


def validate_integration_review_report(integration_review_report):
    issues = []
    report = integration_review_report or {}
    packet = report.get("enqueue_preflight_packet") or {}
    policy = agent_autonomy_policy.normalize_policy(packet.get("autonomy_policy") or report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "integration_review_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "integration_review_not_pass", "detail": report.get("status") or ""})
    if report.get("integration_review_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "integration_review_state_not_ready", "detail": report.get("integration_review_state") or ""})
    if not _literal_bool_or_missing(report.get("candidate_note_integration_reviewed")):
        issues.append({"issue": "invalid_integration_review_boolean:candidate_note_integration_reviewed", "detail": repr(report.get("candidate_note_integration_reviewed"))})
    if not _literal_true(report.get("candidate_note_integration_reviewed")):
        issues.append({"issue": "candidate_note_integration_reviewed_required"})
    if not _literal_bool_or_missing(report.get("patch_queue_enqueue_preflight_created")):
        issues.append({"issue": "invalid_integration_review_boolean:patch_queue_enqueue_preflight_created", "detail": repr(report.get("patch_queue_enqueue_preflight_created"))})
    if not _literal_true(report.get("patch_queue_enqueue_preflight_created")):
        issues.append({"issue": "patch_queue_enqueue_preflight_required"})
    if report.get("validation_issues"):
        issues.append({"issue": "integration_review_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    target = str(packet.get("candidate_note_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": target})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_component(packet.get("slug") or ""):
        issues.append({"issue": "candidate_note_slug_missing_or_unsafe", "detail": packet.get("slug") or ""})
    if not _safe_component(packet.get("job_id") or ""):
        issues.append({"issue": "candidate_note_job_id_missing_or_unsafe", "detail": packet.get("job_id") or ""})
    for key in [
        "enqueue_preflight_ready",
        "candidate_note_integration_reviewed",
    ]:
        if not _literal_bool_or_missing(packet.get(key)):
            issues.append({"issue": f"invalid_enqueue_preflight_packet_boolean:{key}", "detail": repr(packet.get(key))})
        if not _literal_true(packet.get(key)):
            issues.append({"issue": f"enqueue_preflight_packet_requires_true:{key}"})
    if packet.get("required_next_gate") != "research_compute_candidate_note_patch_queue_enqueue_gate":
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    for key, issue in [
        ("patch_queue_enqueue_allowed", "preflight_must_not_allow_patch_queue_enqueue"),
        ("patch_queue_enqueue_authorized", "preflight_must_not_authorize_patch_queue_enqueue"),
        ("patch_queue_mutation_performed", "preflight_must_not_mutate_patch_queue"),
        ("commit_performed", "preflight_must_not_commit"),
    ]:
        if not _literal_bool_or_missing(packet.get(key)):
            issues.append({"issue": f"invalid_enqueue_preflight_packet_boolean:{key}", "detail": repr(packet.get(key))})
        elif _literal_true(packet.get(key)):
            issues.append({"issue": issue})

    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_enqueue_authorized",
        "candidate_patch_queue_mutation_performed",
        "patch_queue_enqueue_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        authorization_allowed_by_policy = full_autonomy and key in {
            "provider_model_call_authorized",
            "external_action_authorized",
        }
        if not _literal_bool_or_missing(report.get(key)):
            issues.append({"issue": f"invalid_integration_review_boolean:{key}", "detail": repr(report.get(key))})
        elif _literal_true(report.get(key)) and not authorization_allowed_by_policy:
            issues.append({"issue": f"forbidden_integration_review_boundary_crossed:{key}"})
    return issues


def validate_candidate_note_snapshot(candidate_note_snapshot, integration_review_report):
    issues = []
    snapshot = candidate_note_snapshot or {}
    packet = (integration_review_report or {}).get("enqueue_preflight_packet") or {}
    if str(snapshot.get("path") or "") != str(packet.get("candidate_note_path") or ""):
        issues.append({"issue": "candidate_note_path_mismatch"})
    if not _literal_bool_or_missing(snapshot.get("exists")):
        issues.append({"issue": "invalid_candidate_note_snapshot_boolean:exists", "detail": repr(snapshot.get("exists"))})
    if not _literal_true(snapshot.get("exists")):
        issues.append({"issue": "candidate_note_missing", "detail": snapshot.get("path") or ""})
    if not _literal_bool_or_missing(snapshot.get("is_file")):
        issues.append({"issue": "invalid_candidate_note_snapshot_boolean:is_file", "detail": repr(snapshot.get("is_file"))})
    elif snapshot.get("is_file") is False:
        issues.append({"issue": "candidate_note_not_file", "detail": snapshot.get("path") or ""})
    if not _valid_sha256(snapshot.get("sha256")):
        issues.append({"issue": "candidate_note_snapshot_sha256_required"})
    if snapshot.get("sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "candidate_note_sha256_mismatch"})
    return issues


def validate_patch_queue_snapshot(patch_queue_snapshot, enqueue_requested=False):
    issues = []
    snapshot = patch_queue_snapshot or {}
    if not _literal_bool_or_missing(snapshot.get("db_checked")):
        issues.append({"issue": "invalid_patch_queue_snapshot_boolean:db_checked", "detail": repr(snapshot.get("db_checked"))})
    if not _literal_true(snapshot.get("db_checked")):
        issues.append({"issue": "patch_queue_snapshot_unavailable"})
    if not _literal_bool_or_missing(snapshot.get("paper_slug_registered")):
        issues.append({"issue": "invalid_patch_queue_snapshot_boolean:paper_slug_registered", "detail": repr(snapshot.get("paper_slug_registered"))})
    if enqueue_requested and snapshot.get("paper_slug_registered") is False:
        issues.append({"issue": "paper_slug_not_registered_for_patch_queue_enqueue", "detail": snapshot.get("slug") or ""})
    if int(snapshot.get("active_patch_queue_count") or 0) > 0:
        issues.append({"issue": "active_patch_queue_rows_for_slug", "detail": int(snapshot.get("active_patch_queue_count") or 0)})
    if int(snapshot.get("candidate_note_queue_row_count") or 0) > 0:
        issues.append({"issue": "candidate_note_already_has_patch_queue_rows", "detail": int(snapshot.get("candidate_note_queue_row_count") or 0)})
    return issues


def validate_queue_artifact(queue_artifact, enqueue_requested):
    issues = []
    artifact = queue_artifact or {}
    if not enqueue_requested:
        return issues
    if not _literal_bool_or_missing(artifact.get("exists")):
        issues.append({"issue": "invalid_queue_artifact_boolean:exists", "detail": repr(artifact.get("exists"))})
    if not _literal_true(artifact.get("exists")):
        issues.append({"issue": "queue_artifact_required_for_enqueue"})
        return issues
    if not _literal_bool_or_missing(artifact.get("is_file")):
        issues.append({"issue": "invalid_queue_artifact_boolean:is_file", "detail": repr(artifact.get("is_file"))})
    elif artifact.get("is_file") is False:
        issues.append({"issue": "queue_artifact_not_file", "detail": artifact.get("path") or ""})
    path = str(artifact.get("path") or "")
    if not _safe_relative_path(path):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": path})
    if path and not any(path.startswith(prefix) for prefix in QUEUE_ARTIFACT_PREFIXES):
        issues.append({"issue": "queue_artifact_outside_allowlist", "detail": path})
    if path and not (path.endswith(".patch") or path.endswith(".json")):
        issues.append({"issue": "queue_artifact_extension_not_allowed", "detail": path})
    if not _valid_sha256(artifact.get("sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if int(artifact.get("bytes") or 0) <= 0:
        issues.append({"issue": "queue_artifact_empty"})
    return issues


def validate_enqueue_result(enqueue_result, enqueue_requested, write_requested, queue_artifact, base_issues):
    issues = []
    result = enqueue_result or {}
    if not enqueue_requested:
        return issues
    if not write_requested:
        issues.append({"issue": "enqueue_requires_write"})
        return issues
    if base_issues:
        return issues
    if not _literal_bool_or_missing(result.get("patch_queue_enqueue_performed")):
        issues.append({"issue": "invalid_enqueue_result_boolean:patch_queue_enqueue_performed", "detail": repr(result.get("patch_queue_enqueue_performed"))})
    if not _literal_true(result.get("patch_queue_enqueue_performed")):
        issues.append({"issue": "patch_queue_enqueue_result_required"})
        return issues
    if int(result.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_queue_patch_id_required"})
    if result.get("status") != "queued":
        issues.append({"issue": "patch_queue_row_status_not_queued", "detail": result.get("status") or ""})
    if not _valid_sha256(result.get("patch_sha256")):
        issues.append({"issue": "patch_queue_patch_sha256_required"})
    if queue_artifact and result.get("patch_sha256") != queue_artifact.get("sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    return issues


def research_compute_candidate_note_patch_queue_enqueue(
    integration_review_report,
    candidate_note_snapshot=None,
    patch_queue_snapshot=None,
    queue_artifact=None,
    enqueue_requested=False,
    write_requested=False,
    enqueue_result=None,
    label="",
):
    integration_review_report = integration_review_report or {}
    candidate_note_snapshot = candidate_note_snapshot or {}
    patch_queue_snapshot = patch_queue_snapshot or {}
    queue_artifact = queue_artifact or {}
    enqueue_result = enqueue_result or {}
    base_issues = validate_integration_review_report(integration_review_report)
    base_issues.extend(validate_candidate_note_snapshot(candidate_note_snapshot, integration_review_report))
    base_issues.extend(validate_patch_queue_snapshot(patch_queue_snapshot, enqueue_requested=enqueue_requested))
    base_issues.extend(validate_queue_artifact(queue_artifact, enqueue_requested))
    issues = list(base_issues)
    issues.extend(validate_enqueue_result(enqueue_result, enqueue_requested, write_requested, queue_artifact, base_issues))
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_integration_review_boundary_crossed") for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "CANDIDATE_NOTE_PATCH_QUEUE_ENQUEUE_BLOCKED"
    elif enqueue_requested and write_requested:
        status = "PASS"
        state = "CANDIDATE_NOTE_PATCH_QUEUE_ENQUEUED"
    else:
        status = "PASS"
        state = "CANDIDATE_NOTE_PATCH_QUEUE_ENQUEUE_READY_DRY_RUN_NOT_ENQUEUED"

    packet = integration_review_report.get("enqueue_preflight_packet") or {}
    policy = agent_autonomy_policy.normalize_policy(packet.get("autonomy_policy") or integration_review_report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = (
        _literal_true(packet.get("agent_generated_evidence_material"))
        or _literal_true(integration_review_report.get("agent_generated_evidence_material"))
    )
    enqueued = state == "CANDIDATE_NOTE_PATCH_QUEUE_ENQUEUED"
    enqueue_gate_packet = {
        "enqueue_gate_ready": status == "PASS",
        "enqueue_requested": bool(enqueue_requested),
        "write_requested": bool(write_requested),
        "slug": packet.get("slug") or "",
        "job_id": packet.get("job_id") or "",
        "candidate_note_path": candidate_note_snapshot.get("path") or "",
        "candidate_note_sha256": candidate_note_snapshot.get("sha256") or "",
        "queue_artifact_path": queue_artifact.get("path") or "",
        "queue_artifact_sha256": queue_artifact.get("sha256") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "patch_queue_enqueue_authorized": enqueued,
        "patch_queue_enqueue_performed": enqueued,
        "patch_queue_patch_id": int(enqueue_result.get("patch_id") or 0) if enqueued else 0,
        "commit_allowed": False,
        "commit_performed": False,
        "required_next_gate": "research_compute_patch_queue_post_enqueue_verify" if enqueued else "research_compute_candidate_note_queue_artifact_gate",
    }
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "enqueue_state": state,
        "candidate_note_enqueue_gate_checked": status == "PASS",
        "patch_queue_enqueue_authorized": enqueued,
        "candidate_patch_queue_enqueue_authorized": enqueued,
        "patch_queue_enqueue_performed": enqueued,
        "candidate_patch_queue_mutation_performed": enqueued,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "enqueue_requested_count": 1 if enqueue_requested else 0,
            "patch_queue_enqueue_authorized_count": 1 if enqueued else 0,
            "patch_queue_mutation_count": 1 if enqueued else 0,
            "active_patch_queue_count": int(patch_queue_snapshot.get("active_patch_queue_count") or 0),
            "candidate_note_queue_row_count": int(patch_queue_snapshot.get("candidate_note_queue_row_count") or 0),
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "integration_review_reference": {
            "report_path": integration_review_report.get("report_path") or "",
            "status": integration_review_report.get("status") or "",
            "integration_review_state": integration_review_report.get("integration_review_state") or "",
        },
        "candidate_note_snapshot": candidate_note_snapshot,
        "patch_queue_snapshot": patch_queue_snapshot,
        "queue_artifact": queue_artifact,
        "enqueue_result": enqueue_result,
        "enqueue_gate_packet": enqueue_gate_packet,
        "boundary": [
            "This command is the explicit candidate-note patch_queue enqueue gate.",
            "Dry-run mode creates an enqueue gate report only and does not mutate patch_queue.",
            "A patch_queue row may be created only with explicit enqueue/write intent and an allowlisted queue artifact.",
            "It does not mutate source/package/archive state, call providers/models, commit, merge, upload, email, or perform external actions.",
        ],
    }


def research_compute_candidate_note_patch_queue_enqueue_markdown(report):
    packet = report.get("enqueue_gate_packet") or {}
    lines = [
        "# paper_factory Research Compute Candidate Note Patch Queue Enqueue",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('enqueue_state') or ''}",
        f"- Enqueue requested: {packet.get('enqueue_requested')}",
        f"- Patch queue enqueue performed: {report.get('patch_queue_enqueue_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Enqueue Gate Packet",
        "",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Job: `{packet.get('job_id') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Queue artifact: `{packet.get('queue_artifact_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
