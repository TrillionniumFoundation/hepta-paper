"""Create a queue artifact from a verified research-compute candidate note."""

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-candidate-note-queue-artifact-gate"
PREVIOUS_COMMAND = "research-compute-candidate-note-patch-queue-enqueue"
PREVIOUS_READY_STATE = "CANDIDATE_NOTE_PATCH_QUEUE_ENQUEUE_READY_DRY_RUN_NOT_ENQUEUED"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "queue_artifact_state",
    "report_schema",
    "candidate_note_queue_artifact_gate_checked",
    "queue_artifact_created",
    "patch_queue_enqueue_authorized",
    "candidate_patch_queue_enqueue_authorized",
    "patch_queue_enqueue_performed",
    "candidate_patch_queue_mutation_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "enqueue_gate_reference",
    "candidate_note_snapshot",
    "patch_queue_snapshot",
    "queue_artifact",
    "queue_artifact_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "queue_artifact_created_count",
    "patch_queue_enqueue_authorized_count",
    "patch_queue_mutation_count",
    "active_patch_queue_count",
    "candidate_note_queue_row_count",
    "agent_generated_evidence_material_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Creates/verifies a local candidate-note queue artifact for a later explicit enqueue gate.",
    "No patch_queue row, source/package/archive mutation, commit, merge, provider/model call, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _safe_component(value):
    text = str(value or "")
    return bool(text) and all(ch.isalnum() or ch in "._-" for ch in text)


def validate_enqueue_gate_report(enqueue_gate_report):
    issues = []
    report = enqueue_gate_report or {}
    packet = report.get("enqueue_gate_packet") or {}
    policy = agent_autonomy_policy.normalize_policy(packet.get("autonomy_policy") or report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "enqueue_gate_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "enqueue_gate_not_pass", "detail": report.get("status") or ""})
    if report.get("enqueue_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "enqueue_gate_state_not_dry_run_ready", "detail": report.get("enqueue_state") or ""})
    if not report.get("candidate_note_enqueue_gate_checked"):
        issues.append({"issue": "candidate_note_enqueue_gate_checked_required"})
    if report.get("validation_issues"):
        issues.append({"issue": "enqueue_gate_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    target = str(packet.get("candidate_note_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": target})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_component(packet.get("slug") or ""):
        issues.append({"issue": "candidate_note_slug_missing_or_unsafe", "detail": packet.get("slug") or ""})
    if not _safe_component(packet.get("job_id") or ""):
        issues.append({"issue": "candidate_note_job_id_missing_or_unsafe", "detail": packet.get("job_id") or ""})
    if packet.get("patch_queue_enqueue_authorized"):
        issues.append({"issue": "dry_run_gate_must_not_authorize_enqueue"})
    if packet.get("patch_queue_enqueue_performed"):
        issues.append({"issue": "dry_run_gate_must_not_enqueue"})
    if packet.get("patch_queue_patch_id"):
        issues.append({"issue": "dry_run_gate_must_not_have_patch_id"})
    if packet.get("commit_performed"):
        issues.append({"issue": "dry_run_gate_must_not_commit"})
    if packet.get("required_next_gate") != "research_compute_candidate_note_queue_artifact_gate":
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "patch_queue_enqueue_authorized",
        "candidate_patch_queue_enqueue_authorized",
        "patch_queue_enqueue_performed",
        "candidate_patch_queue_mutation_performed",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        authorization_allowed_by_policy = full_autonomy and key in {
            "provider_model_call_authorized",
            "external_action_authorized",
        }
        if report.get(key) and not authorization_allowed_by_policy:
            issues.append({"issue": f"forbidden_enqueue_gate_boundary_crossed:{key}"})
    return issues


def validate_candidate_note_snapshot(candidate_note_snapshot, enqueue_gate_report):
    issues = []
    snapshot = candidate_note_snapshot or {}
    packet = (enqueue_gate_report or {}).get("enqueue_gate_packet") or {}
    if str(snapshot.get("path") or "") != str(packet.get("candidate_note_path") or ""):
        issues.append({"issue": "candidate_note_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "candidate_note_missing", "detail": snapshot.get("path") or ""})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "candidate_note_not_file", "detail": snapshot.get("path") or ""})
    if not _valid_sha256(snapshot.get("sha256")):
        issues.append({"issue": "candidate_note_snapshot_sha256_required"})
    if snapshot.get("sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "candidate_note_sha256_mismatch"})
    if int(snapshot.get("bytes") or 0) <= 0:
        issues.append({"issue": "candidate_note_empty"})
    return issues


def validate_patch_queue_snapshot(patch_queue_snapshot):
    issues = []
    snapshot = patch_queue_snapshot or {}
    if not snapshot.get("db_checked"):
        issues.append({"issue": "patch_queue_snapshot_unavailable"})
    if int(snapshot.get("active_patch_queue_count") or 0) > 0:
        issues.append({"issue": "active_patch_queue_rows_for_slug", "detail": int(snapshot.get("active_patch_queue_count") or 0)})
    if int(snapshot.get("candidate_note_queue_row_count") or 0) > 0:
        issues.append({"issue": "candidate_note_already_has_patch_queue_rows", "detail": int(snapshot.get("candidate_note_queue_row_count") or 0)})
    return issues


def build_candidate_note_queue_artifact(enqueue_gate_report, candidate_note_snapshot, label=""):
    packet = (enqueue_gate_report or {}).get("enqueue_gate_packet") or {}
    policy = agent_autonomy_policy.normalize_policy(packet.get("autonomy_policy") or (enqueue_gate_report or {}).get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = bool(
        packet.get("agent_generated_evidence_material")
        or (enqueue_gate_report or {}).get("agent_generated_evidence_material")
    )
    return {
        "artifact_type": "research_compute_candidate_note_queue_artifact.v1",
        "label": label or "",
        "slug": packet.get("slug") or "",
        "job_id": packet.get("job_id") or "",
        "candidate_note_path": candidate_note_snapshot.get("path") or "",
        "candidate_note_sha256": candidate_note_snapshot.get("sha256") or "",
        "candidate_note_bytes": int(candidate_note_snapshot.get("bytes") or 0),
        "source_enqueue_gate_report_path": (enqueue_gate_report or {}).get("report_path") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "queue_scope": "candidate_note_review_queue_only",
        "queue_artifact_applyable_patch": False,
        "manual_review_required": True,
        "patch_queue_enqueue_allowed_after_artifact_verification": True,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "required_next_gate": "research_compute_candidate_note_patch_queue_enqueue_gate",
    }


def research_compute_candidate_note_queue_artifact_gate(
    enqueue_gate_report,
    candidate_note_snapshot=None,
    patch_queue_snapshot=None,
    queue_artifact=None,
    label="",
):
    enqueue_gate_report = enqueue_gate_report or {}
    candidate_note_snapshot = candidate_note_snapshot or {}
    patch_queue_snapshot = patch_queue_snapshot or {}
    queue_artifact = queue_artifact or {}
    issues = validate_enqueue_gate_report(enqueue_gate_report)
    issues.extend(validate_candidate_note_snapshot(candidate_note_snapshot, enqueue_gate_report))
    issues.extend(validate_patch_queue_snapshot(patch_queue_snapshot))
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_enqueue_gate_boundary_crossed") for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "CANDIDATE_NOTE_QUEUE_ARTIFACT_GATE_BLOCKED"
    else:
        status = "PASS"
        state = "CANDIDATE_NOTE_QUEUE_ARTIFACT_READY_NOT_ENQUEUED"
    ready = status == "PASS"
    artifact_ready = ready and bool(queue_artifact.get("path")) and _valid_sha256(queue_artifact.get("sha256"))
    packet = (enqueue_gate_report.get("enqueue_gate_packet") or {})
    policy = agent_autonomy_policy.normalize_policy(packet.get("autonomy_policy") or enqueue_gate_report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = bool(
        packet.get("agent_generated_evidence_material")
        or enqueue_gate_report.get("agent_generated_evidence_material")
    )
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "queue_artifact_state": state,
        "candidate_note_queue_artifact_gate_checked": ready,
        "queue_artifact_created": artifact_ready,
        "patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "patch_queue_enqueue_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "queue_artifact_created_count": 1 if artifact_ready else 0,
            "patch_queue_enqueue_authorized_count": 0,
            "patch_queue_mutation_count": 0,
            "active_patch_queue_count": int(patch_queue_snapshot.get("active_patch_queue_count") or 0),
            "candidate_note_queue_row_count": int(patch_queue_snapshot.get("candidate_note_queue_row_count") or 0),
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "enqueue_gate_reference": {
            "report_path": enqueue_gate_report.get("report_path") or "",
            "status": enqueue_gate_report.get("status") or "",
            "enqueue_state": enqueue_gate_report.get("enqueue_state") or "",
        },
        "candidate_note_snapshot": candidate_note_snapshot,
        "patch_queue_snapshot": patch_queue_snapshot,
        "queue_artifact": queue_artifact,
        "queue_artifact_packet": {
            "queue_artifact_ready": artifact_ready,
            "slug": packet.get("slug") or "",
            "job_id": packet.get("job_id") or "",
            "candidate_note_path": candidate_note_snapshot.get("path") or "",
            "candidate_note_sha256": candidate_note_snapshot.get("sha256") or "",
            "queue_artifact_path": queue_artifact.get("path") or "",
            "queue_artifact_sha256": queue_artifact.get("sha256") or "",
            "full_agent_autonomy_authorized": full_autonomy,
            "autonomy_policy": policy,
            "agent_generated_evidence_material": agent_generated,
            "patch_queue_enqueue_allowed": False,
            "patch_queue_enqueue_authorized": False,
            "patch_queue_enqueue_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": "research_compute_candidate_note_patch_queue_enqueue_gate",
        },
        "boundary": [
            "This command creates/verifies a candidate-note queue artifact for a later enqueue gate.",
            "It does not create patch_queue rows, mutate source/package/archive state, call providers/models, commit, merge, upload, email, or perform external actions.",
            "The next enqueue gate must still be explicit and must re-check the artifact and patch_queue state.",
        ],
    }


def research_compute_candidate_note_queue_artifact_gate_markdown(report):
    packet = report.get("queue_artifact_packet") or {}
    lines = [
        "# paper_factory Research Compute Candidate Note Queue Artifact Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('queue_artifact_state') or ''}",
        f"- Queue artifact created: {report.get('queue_artifact_created')}",
        f"- Patch queue enqueue performed: {report.get('patch_queue_enqueue_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Queue Artifact Packet",
        "",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Job: `{packet.get('job_id') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Queue artifact: `{packet.get('queue_artifact_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
