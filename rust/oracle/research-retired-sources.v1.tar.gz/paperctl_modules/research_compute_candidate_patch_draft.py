"""Draft candidate patch text from gated research-compute evidence.

This layer creates a local candidate patch draft under logs only. It does not
apply, enqueue, merge, or mutate manuscript/package/archive state.
"""

import hashlib
import re

from paperctl_modules import agent_autonomy_policy


_SAFE_COMPONENT_RE = re.compile(r"^[A-Za-z0-9._-]+$")

COMMAND = "research-compute-candidate-patch-draft"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "draft_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_generated",
    "candidate_patch_applied",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "validation_issues",
    "candidate_patch",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "output_hash_count",
    "candidate_patch_generated_count",
    "candidate_patch_applied_count",
    "agent_generated_evidence_material_count",
    "patch_queue_mutation_count",
]

REPORT_SCHEMA_NOTES = [
    "Drafts candidate patch text under logs only.",
    "No manuscript patch is applied or enqueued by this command.",
]


def _safe_component(value, fallback):
    text = str(value or "")
    if text and _SAFE_COMPONENT_RE.match(text) and text not in {".", ".."}:
        return text
    return fallback


def validate_gate_report(gate_report):
    issues = []
    if gate_report.get("command") != "research-compute-evidence-gate":
        issues.append({"issue": "gate_report_command_mismatch", "detail": gate_report.get("command") or ""})
    if gate_report.get("status") != "PASS":
        issues.append({"issue": "gate_report_not_pass", "detail": gate_report.get("status") or ""})
    if not gate_report.get("patch_generation_request_created"):
        issues.append({"issue": "patch_generation_request_required"})
    request = gate_report.get("patch_generation_request") or {}
    if not request.get("patch_generation_request_ready"):
        issues.append({"issue": "patch_generation_request_not_ready"})
    if not request.get("output_hashes"):
        issues.append({"issue": "output_hashes_required"})
    for key in ["slug", "job_id"]:
        value = str(request.get(key) or "")
        if not value or not _SAFE_COMPONENT_RE.match(value) or value in {".", ".."}:
            issues.append({"issue": f"unsafe_request_component:{key}", "detail": value})
    for item in request.get("output_hashes") or []:
        sha = str(item.get("sha256") or "")
        path = str(item.get("path") or "")
        if len(sha) != 64:
            issues.append({"issue": "invalid_output_sha256", "detail": path})
        if path.startswith("/") or ".." in path.split("/"):
            issues.append({"issue": "unsafe_output_hash_path", "detail": path})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if gate_report.get(key):
            issues.append({"issue": f"forbidden_boundary_crossed:{key}"})
    return issues


def _candidate_note_id(request):
    job_id = _safe_component(request.get("job_id"), "RCB-UNKNOWN")
    digest_material = {
        "workspace_dir": request.get("workspace_dir") or "",
        "evidence_report_path": request.get("evidence_report_path") or "",
        "output_hashes": [
            {
                "path": item.get("path") or "",
                "sha256": item.get("sha256") or "",
            }
            for item in request.get("output_hashes") or []
        ],
    }
    digest = hashlib.sha256(repr(digest_material).encode("utf-8")).hexdigest()[:12]
    return f"{job_id}-{digest}"


def _patch_text(request):
    slug = _safe_component(request.get("slug"), "UNSPECIFIED")
    job_id = _safe_component(request.get("job_id"), "RCB-UNKNOWN")
    note_id = _candidate_note_id(request)
    target = f"research_compute_candidate_notes/{slug}/{note_id}.md"
    added_lines = [
        "# Research Compute Candidate Evidence",
        "",
        f"- Slug: {slug}",
        f"- Job: {job_id}",
        f"- Candidate note id: {note_id}",
        f"- Workspace: `{request.get('workspace_dir') or ''}`",
        "- Policy: candidate evidence note only; not applied automatically",
        "",
        "## Output Hashes",
        "",
    ]
    for item in request.get("output_hashes") or []:
        added_lines.append(f"- `{item.get('path') or ''}` `{item.get('sha256') or ''}`")
    added_lines.extend([
        "",
        "## Next Gate",
        "",
        "A manuscript owner or later local gate must review this evidence before any source patch is applied.",
    ])
    lines = [
        f"diff --git a/{target} b/{target}",
        "new file mode 100644",
        "index 0000000..0000000",
        "--- /dev/null",
        f"+++ b/{target}",
        f"@@ -0,0 +1,{len(added_lines)} @@",
    ]
    lines.extend(f"+{line}" for line in added_lines)
    lines.append("")
    return target, "\n".join(lines)


def research_compute_candidate_patch_draft(gate_report, label=""):
    issues = validate_gate_report(gate_report or {})
    request = (gate_report or {}).get("patch_generation_request") or {}
    policy = agent_autonomy_policy.normalize_policy(
        request.get("autonomy_policy") or (gate_report or {}).get("autonomy_policy")
    )
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    note_id = _candidate_note_id(request) if not issues else ""
    target, patch_text = _patch_text(request) if not issues else ("", "")
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": "PASS" if not issues else "ATTENTION",
        "draft_state": "CANDIDATE_PATCH_DRAFT_READY_NOT_APPLIED" if not issues else "CANDIDATE_PATCH_DRAFT_BLOCKED",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_generated": not issues,
        "candidate_patch_applied": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": bool(request.get("agent_command_material_generated")),
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "output_hash_count": len(request.get("output_hashes") or []),
            "candidate_patch_generated_count": 1 if not issues else 0,
            "candidate_patch_applied_count": 0,
            "agent_generated_evidence_material_count": 1 if request.get("agent_command_material_generated") else 0,
            "patch_queue_mutation_count": 0,
        },
        "validation_issues": issues,
        "candidate_patch": {
            "target_path": target,
            "candidate_note_id": note_id,
            "patch_text": patch_text,
            "full_agent_autonomy_authorized": full_autonomy,
            "agent_generated_evidence_material": bool(request.get("agent_command_material_generated")),
            "apply_allowed": False,
            "enqueue_allowed": False,
            "source_mutation_allowed": False,
            "source_gate_required_before_apply": True,
            "from_gate_report_path": (gate_report or {}).get("report_path") or "",
        },
        "boundary": [
            "This command drafts candidate patch text under logs only.",
            "It does not apply a patch, enqueue a patch, mutate source/package/archive state, call a provider/model, or perform external actions.",
            "A later explicit source gate is required before any candidate patch can touch a manuscript tree.",
        ],
    }
    if any(str(item.get("issue") or "").startswith("forbidden_boundary_crossed") for item in issues):
        report["status"] = "FAIL"
        report["draft_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
    return report


def research_compute_candidate_patch_draft_markdown(report):
    lines = [
        "# paper_factory Research Compute Candidate Patch Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Draft state: {report.get('draft_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Agent generated evidence material: {report.get('agent_generated_evidence_material')}",
        f"- Candidate patch generated: {report.get('candidate_patch_generated')}",
        f"- Candidate patch applied: {report.get('candidate_patch_applied')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    patch = report.get("candidate_patch") or {}
    lines.extend(["", "## Candidate Patch", ""])
    lines.append(f"- Target: `{patch.get('target_path') or ''}`")
    lines.append(f"- Apply allowed: {patch.get('apply_allowed')}")
    lines.append(f"- Enqueue allowed: {patch.get('enqueue_allowed')}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
