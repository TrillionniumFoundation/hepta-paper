"""Plan unattended candidate iteration for referee research-compute gaps.

This module deliberately distinguishes candidate iteration from final academic
authority. It can plan repeated proof/experiment repair attempts, but it never
marks an unverified theorem/proof/experiment as final, edits manuscript source,
merges patches, or submits externally.
"""

from paperctl_modules import agent_autonomy_policy
from paperctl_modules import research_compute_capability_matrix
from paperctl_modules import research_compute_gap_mapper


COMMAND = "research-compute-candidate-referee-loop-plan"
READY_STATE = "CANDIDATE_REFEREE_LOOP_READY"
IDLE_STATE = "CANDIDATE_REFEREE_LOOP_IDLE_NO_ACTIVE_COMPUTE_GAPS"
CLASSIFICATION_STATE = "CANDIDATE_REFEREE_LOOP_CLASSIFICATION_REQUIRED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "loop_plan_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_supplied_compute_command_allowed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "unattended_candidate_iteration_allowed",
    "automatic_theorem_finalization_allowed",
    "automatic_proof_finalization_allowed",
    "automatic_experiment_finalization_allowed",
    "automatic_source_apply_allowed",
    "automatic_merge_allowed",
    "automatic_submission_allowed",
    "summary",
    "loop_items",
    "candidate_packets",
    "global_loop_policy",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "request_count",
    "active_compute_request_count",
    "skipped_request_count",
    "loop_item_count",
    "candidate_theorem_proof_count",
    "candidate_experiment_count",
    "candidate_evidence_anchor_count",
    "classification_required_count",
    "iteration_budget",
    "candidate_obligation_packet_count",
    "candidate_evidence_gate_packet_count",
    "candidate_patch_draft_request_count",
    "candidate_no_write_check_count",
    "agent_supplied_compute_command_allowed_count",
    "final_theorem_or_proof_claim_allowed_count",
    "final_experiment_claim_allowed_count",
    "source_apply_allowed_count",
    "merge_allowed_count",
    "submission_allowed_count",
]
REPORT_SCHEMA_NOTES = [
    "Plans unattended candidate theorem/proof/experiment repair loops for active referee gaps.",
    "This is candidate-only: it does not finalize academic claims, mutate sources, merge, submit, call providers/models, or perform external actions.",
]


def _active_compute_requests(requests):
    selected = []
    skipped = []
    for request in requests or []:
        status = str(request.get("status") or "")
        domain = research_compute_capability_matrix.domain_for_request(request)
        if (
            status in research_compute_capability_matrix.ACTIVE_STATUSES
            and domain in {"theorem_proof", "experiment_evidence"}
        ):
            selected.append(dict(request))
        else:
            skipped.append(
                {
                    "request_id": request.get("request_id"),
                    "slug": request.get("slug") or "",
                    "status": status,
                    "domain": domain,
                    "reason": "not_active_compute_gap",
                }
            )
    return selected, skipped


def _candidate_track_for(request):
    domain = research_compute_capability_matrix.domain_for_request(request)
    gap_kind = research_compute_gap_mapper.gap_kind_for_request(request)
    if domain == "theorem_proof":
        return "candidate_theorem_proof"
    if gap_kind in {"experiment", "reproducibility"}:
        return "candidate_experiment"
    return "candidate_evidence_anchor"


def _allowed_loop_steps(track, full_autonomy=False):
    common = [
        "extract_referee_gap",
        "draft_candidate_obligations",
        "materialize_local_evidence_plan",
        "run_deterministic_verification",
        "draft_candidate_patch",
        "run_no_write_referee_check",
        "iterate_until_budget_or_gate",
    ]
    if track == "candidate_theorem_proof":
        return [
            "extract_referee_gap",
            "draft_candidate_theorem_or_claim_boundary",
            "draft_proof_obligations",
            "cross_reference_existing_lemmas",
            "run_deterministic_verification",
            "draft_candidate_patch",
            "run_no_write_referee_check",
            "iterate_until_budget_or_gate",
        ]
    if track == "candidate_experiment":
        steps = [
            "extract_referee_gap",
            "draft_experiment_spec",
            "require_operator_supplied_local_command",
            "run_allowlisted_no_network_command_if_available",
            "hash_outputs_and_manifest",
            "draft_candidate_patch",
            "run_no_write_referee_check",
            "iterate_until_budget_or_gate",
        ]
        if full_autonomy:
            steps[2] = "agent_select_allowlisted_local_command"
        return steps
    return common


def _finalization_blockers(track, full_autonomy=False):
    if full_autonomy:
        blockers = [
            "finalization_requires_verified_evidence_gate",
            "source_apply_requires_rollback_and_post_apply_verify",
            "merge_requires_serial_preflight_and_report_event",
            "external_submit_upload_email_requires_external_action_execution_gate",
        ]
        if track == "candidate_theorem_proof":
            blockers.insert(0, "theorem_or_proof_claim_requires_machine_checkable_obligations")
        if track == "candidate_experiment":
            blockers.insert(0, "experiment_claim_requires_reproducible_output_hashes")
        return blockers
    blockers = [
        "source_apply_requires_source_gate_and_reviewed_authorization",
        "merge_requires_patch_queue_review_and_explicit_apply_gate",
        "external_submit_upload_email_requires_explicit_user_authorization",
    ]
    if track == "candidate_theorem_proof":
        blockers.insert(0, "theorem_or_proof_claim_requires_verified_proof_evidence")
    if track == "candidate_experiment":
        blockers.insert(0, "experiment_claim_requires_reproducible_output_hashes")
    return blockers


def _compact_text(request):
    parts = []
    for field in ["objection", "proposed_fix", "evidence_needed", "verification"]:
        text = str(request.get(field) or "").strip()
        if text:
            parts.append(f"{field}: {text}")
    return " | ".join(parts)


def _candidate_obligations(request, track):
    source_locator = request.get("source_locator") or ""
    common = [
        {
            "name": "referee_gap_statement",
            "required": True,
            "source_locator": source_locator,
            "description": _compact_text(request) or "extract explicit referee gap",
        },
        {
            "name": "claim_scope_boundary",
            "required": True,
            "source_locator": source_locator,
            "description": "record assumptions, scope, and what the candidate material does not prove",
        },
        {
            "name": "no_write_referee_check",
            "required": True,
            "source_locator": source_locator,
            "description": "run a local no-write check before any source gate",
        },
    ]
    if track == "candidate_theorem_proof":
        return [
            {
                "name": "candidate_theorem_or_lemma_statement",
                "required": True,
                "source_locator": source_locator,
                "description": "draft only a candidate theorem/lemma statement tied to existing assumptions",
            },
            {
                "name": "proof_obligation_checklist",
                "required": True,
                "source_locator": source_locator,
                "description": "list lemmas, citations, local derivation steps, and missing verification evidence",
            },
            {
                "name": "claim_downgrade_path",
                "required": True,
                "source_locator": source_locator,
                "description": "if proof evidence is incomplete, downgrade to a limitation or conjectural note",
            },
        ] + common
    if track == "candidate_experiment":
        return [
            {
                "name": "candidate_experiment_spec",
                "required": True,
                "source_locator": source_locator,
                "description": "define local command material, seed policy, resource limits, expected outputs, and success criteria",
            },
            {
                "name": "reproducible_output_hashes",
                "required": True,
                "source_locator": source_locator,
                "description": "capture stdout, stderr, manifests, and output hashes before any claim is drafted",
            },
            {
                "name": "negative_or_inconclusive_result_policy",
                "required": True,
                "source_locator": source_locator,
                "description": "report negative or inconclusive results without overclaiming",
            },
        ] + common
    return [
        {
            "name": "candidate_evidence_anchor",
            "required": True,
            "source_locator": source_locator,
            "description": "locate and hash local evidence before drafting candidate text",
        },
    ] + common


def _bridge_gap_spec(request, track):
    slug = request.get("slug") or "UNKNOWN"
    request_key = request.get("request_key") or request.get("request_id") or "request"
    if track == "candidate_theorem_proof":
        kind = "proof"
    elif track == "candidate_experiment":
        kind = "experiment"
    else:
        kind = "artifact"
    return f"{slug}:{kind}:referee-{request_key}"


def _candidate_packet(request, track, iteration_budget, autonomy_policy=None):
    autonomy_policy = agent_autonomy_policy.normalize_policy(autonomy_policy)
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(autonomy_policy)
    packet_id = f"candidate-referee-loop-request-{request.get('request_id') or 'unknown'}"
    gap_kind = research_compute_gap_mapper.gap_kind_for_request(request)
    return {
        "packet_id": packet_id,
        "request_id": request.get("request_id"),
        "request_key": request.get("request_key") or "",
        "slug": request.get("slug") or "",
        "candidate_track": track,
        "gap_kind": gap_kind,
        "iteration_budget": iteration_budget,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": autonomy_policy,
        "bridge_gap_spec": _bridge_gap_spec(request, track),
        "candidate_obligations": _candidate_obligations(request, track),
        "evidence_gate_packet": {
            "packet_type": "planned_research_compute_evidence_gate",
            "ready": True,
            "required_prior_outputs": [
                "research_compute_bridge_plan",
                "research_compute_execute_report_with_hashes",
                "research_compute_evidence_ingest_report",
            ],
            "output_hashes_required": track == "candidate_experiment",
            "source_mutation_allowed": False,
            "patch_queue_enqueue_allowed": False,
            "automatic_finalization_allowed_after_gate": bool(
                full_autonomy
                and (
                    (track == "candidate_theorem_proof" and autonomy_policy.get("automatic_theorem_finalization_allowed"))
                    or (track == "candidate_experiment" and autonomy_policy.get("automatic_experiment_finalization_allowed"))
                    or track == "candidate_evidence_anchor"
                )
            ),
        },
        "candidate_patch_draft_request": {
            "packet_type": "planned_candidate_patch_draft_request",
            "ready_after_evidence_gate": True,
            "candidate_patch_may_be_drafted_under_logs": True,
            "source_apply_allowed": bool(full_autonomy and autonomy_policy.get("automatic_source_apply_allowed")),
            "merge_allowed": bool(full_autonomy and autonomy_policy.get("automatic_merge_allowed")),
            "submission_allowed": bool(full_autonomy and autonomy_policy.get("automatic_submission_allowed")),
            "required_next_gate": "research_compute_candidate_patch_draft",
        },
        "no_write_referee_check": {
            "required": True,
            "source_mutation_allowed": False,
            "external_action_allowed": False,
        },
    }


def _loop_item(request, iteration_budget, autonomy_policy=None):
    autonomy_policy = agent_autonomy_policy.normalize_policy(autonomy_policy)
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(autonomy_policy)
    track = _candidate_track_for(request)
    gap_kind = research_compute_gap_mapper.gap_kind_for_request(request)
    source_locator = request.get("source_locator") or ""
    packet = _candidate_packet(request, track, iteration_budget, autonomy_policy=autonomy_policy)
    return {
        "request_id": request.get("request_id"),
        "request_key": request.get("request_key") or "",
        "slug": request.get("slug") or "",
        "status": request.get("status") or "",
        "risk_class": request.get("risk_class") or "",
        "domain": research_compute_capability_matrix.domain_for_request(request),
        "gap_kind": gap_kind,
        "candidate_track": track,
        "iteration_budget": iteration_budget,
        "source_locator": source_locator,
        "loop_state": "FULL_AGENT_AUTONOMY_PLANNED_NOT_EXECUTED" if full_autonomy else "CANDIDATE_ITERATION_PLANNED_NOT_EXECUTED",
        "unattended_candidate_iteration_allowed": True,
        "candidate_material_may_be_generated": True,
        "candidate_patch_may_be_drafted": True,
        "full_agent_autonomy_authorized": full_autonomy,
        "agent_supplied_compute_command_allowed": bool(
            full_autonomy and autonomy_policy.get("agent_supplied_compute_command_allowed")
        ),
        "final_theorem_or_proof_claim_allowed": bool(
            full_autonomy
            and track == "candidate_theorem_proof"
            and autonomy_policy.get("automatic_theorem_finalization_allowed")
            and autonomy_policy.get("automatic_proof_finalization_allowed")
        ),
        "final_experiment_claim_allowed": bool(
            full_autonomy
            and track == "candidate_experiment"
            and autonomy_policy.get("automatic_experiment_finalization_allowed")
        ),
        "source_apply_allowed": bool(full_autonomy and autonomy_policy.get("automatic_source_apply_allowed")),
        "merge_allowed": bool(full_autonomy and autonomy_policy.get("automatic_merge_allowed")),
        "external_submission_allowed": bool(full_autonomy and autonomy_policy.get("automatic_submission_allowed")),
        "candidate_obligation_packet_created": True,
        "candidate_packet_id": packet["packet_id"],
        "candidate_bridge_gap_spec": packet["bridge_gap_spec"],
        "allowed_loop_steps": _allowed_loop_steps(track, full_autonomy=full_autonomy),
        "finalization_blockers": _finalization_blockers(track, full_autonomy=full_autonomy),
        "candidate_packet": packet,
        "recommended_next_local_step": (
            "run full-autonomy evidence-gated referee iteration; later gates must record hashes, source rollback, merge, and external-action evidence"
            if full_autonomy
            else "run candidate-only referee iteration; stop at source/apply/submit gates"
        ),
    }


def research_compute_candidate_referee_loop_plan(requests=None, label="", iteration_budget=3, autonomy_policy=None):
    requests = list(requests or [])
    iteration_budget = max(1, int(iteration_budget or 1))
    autonomy_policy = agent_autonomy_policy.normalize_policy(autonomy_policy)
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(autonomy_policy)
    active, skipped = _active_compute_requests(requests)
    loop_items = [_loop_item(request, iteration_budget, autonomy_policy=autonomy_policy) for request in active]
    needs_classification = [
        item
        for item in loop_items
        if item["gap_kind"] == "unknown" or item["candidate_track"] == "candidate_evidence_anchor"
    ]
    if needs_classification:
        status = "ATTENTION"
        state = CLASSIFICATION_STATE
    elif loop_items:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = IDLE_STATE

    proof_count = sum(1 for item in loop_items if item["candidate_track"] == "candidate_theorem_proof")
    experiment_count = sum(1 for item in loop_items if item["candidate_track"] == "candidate_experiment")
    evidence_count = sum(1 for item in loop_items if item["candidate_track"] == "candidate_evidence_anchor")
    candidate_packets = [item["candidate_packet"] for item in loop_items]
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "loop_plan_state": state,
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": autonomy_policy,
        "agent_supplied_compute_command_allowed": bool(autonomy_policy.get("agent_supplied_compute_command_allowed")),
        "provider_model_call_authorized": bool(autonomy_policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(autonomy_policy.get("external_action_authorized")),
        "external_action_performed": False,
        "unattended_candidate_iteration_allowed": True,
        "automatic_theorem_finalization_allowed": bool(autonomy_policy.get("automatic_theorem_finalization_allowed")),
        "automatic_proof_finalization_allowed": bool(autonomy_policy.get("automatic_proof_finalization_allowed")),
        "automatic_experiment_finalization_allowed": bool(autonomy_policy.get("automatic_experiment_finalization_allowed")),
        "automatic_source_apply_allowed": bool(autonomy_policy.get("automatic_source_apply_allowed")),
        "automatic_merge_allowed": bool(autonomy_policy.get("automatic_merge_allowed")),
        "automatic_submission_allowed": bool(autonomy_policy.get("automatic_submission_allowed")),
        "summary": {
            "request_count": len(requests),
            "active_compute_request_count": len(active),
            "skipped_request_count": len(skipped),
            "loop_item_count": len(loop_items),
            "candidate_theorem_proof_count": proof_count,
            "candidate_experiment_count": experiment_count,
            "candidate_evidence_anchor_count": evidence_count,
            "classification_required_count": len(needs_classification),
            "iteration_budget": iteration_budget,
            "candidate_obligation_packet_count": len(candidate_packets),
            "candidate_evidence_gate_packet_count": len(candidate_packets),
            "candidate_patch_draft_request_count": len(candidate_packets),
            "candidate_no_write_check_count": len(candidate_packets),
            "agent_supplied_compute_command_allowed_count": sum(
                1 for item in loop_items if item.get("agent_supplied_compute_command_allowed")
            ),
            "final_theorem_or_proof_claim_allowed_count": sum(
                1 for item in loop_items if item.get("final_theorem_or_proof_claim_allowed")
            ),
            "final_experiment_claim_allowed_count": sum(
                1 for item in loop_items if item.get("final_experiment_claim_allowed")
            ),
            "source_apply_allowed_count": sum(1 for item in loop_items if item.get("source_apply_allowed")),
            "merge_allowed_count": sum(1 for item in loop_items if item.get("merge_allowed")),
            "submission_allowed_count": sum(1 for item in loop_items if item.get("external_submission_allowed")),
        },
        "loop_items": loop_items,
        "candidate_packets": candidate_packets,
        "skipped_requests": skipped[:200],
        "global_loop_policy": {
            "default_mode": "full_agent_autonomy" if full_autonomy else "unattended_candidate_iteration",
            "candidate_material_can_iterate_without_human": True,
            "agent_supplied_compute_command_allowed": bool(autonomy_policy.get("agent_supplied_compute_command_allowed")),
            "final_academic_claims_require_verification": True,
            "source_apply_requires_reviewed_authorization": not full_autonomy,
            "external_submission_requires_explicit_authorization": not full_autonomy,
            "full_agent_autonomy_authorized": full_autonomy,
        },
        "boundary": [
            "This command plans the referee research-compute loop and performs no action by itself.",
            "It may plan candidate theorem/proof/experiment repairs and candidate patches.",
            "When full-agent-autonomy is authorized, finalization/source/merge/submission permissions become policy-ready for later evidence-gated commands.",
            "This planner still does not execute provider/model calls, run shell commands, mutate source/package/archive state, enqueue or merge patches, upload, email, or submit.",
        ],
    }


def research_compute_candidate_referee_loop_plan_markdown(report):
    lines = [
        "# paper_factory Candidate Referee Loop Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('loop_plan_state') or ''}",
        f"- Unattended candidate iteration allowed: {report.get('unattended_candidate_iteration_allowed')}",
        f"- Full agent autonomy authorized: {report.get('full_agent_autonomy_authorized')}",
        f"- Automatic source apply allowed: {report.get('automatic_source_apply_allowed')}",
        f"- Automatic submission allowed: {report.get('automatic_submission_allowed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Loop Items", ""])
    for item in report.get("loop_items") or []:
        lines.append(
            f"- `{item.get('slug')}` request `{item.get('request_id')}` "
            f"{item.get('candidate_track')} budget={item.get('iteration_budget')}"
        )
    if not report.get("loop_items"):
        lines.append("- No active theorem/proof/experiment compute gaps selected.")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
