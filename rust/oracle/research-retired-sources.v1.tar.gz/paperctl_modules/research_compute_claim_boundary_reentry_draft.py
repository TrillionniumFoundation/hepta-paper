"""Draft a local claim packet from a landed claim-boundary re-entry seed."""

import datetime as dt

from paperctl_modules import agent_autonomy_policy
from paperctl_modules import research_compute_claim_draft


COMMAND = "research-compute-claim-boundary-reentry-draft"
READY_STATE = "RESEARCH_COMPUTE_CLAIM_BOUNDARY_REENTRY_DRAFT_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_BOUNDARY_REENTRY_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_CLAIM_BOUNDARY_REENTRY_DRAFT_FAILED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_boundary_reentry_draft_state",
    "report_schema",
    "label",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "seed_selected",
    "seed_id",
    "claim_packet_generated",
    "selected_claim_kind",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "recommended_next_command",
    "production_candidate_seed_plan_report_path",
    "summary",
    "selected_seed",
    "synthetic_reentry_request",
    "claim_draft_report",
    "claim_packets",
    "checks",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "seed_candidate_count",
    "claim_packet_count",
    "theorem_proof_claim_packet_count",
    "experiment_claim_packet_count",
    "validation_issue_count",
    "automatic_final_claim_allowed_count",
    "automatic_source_apply_allowed_count",
    "automatic_merge_allowed_count",
    "automatic_submission_allowed_count",
    "source_mutation_performed_count",
    "external_action_performed_count",
    "secret_material_read_count",
    "commit_performed_count",
    "failed_check_count",
    "attention_check_count",
]
REPORT_SCHEMA_NOTES = [
    "Turns one production-candidate re-entry seed into a local claim-draft packet.",
    "This command is report-only: it does not run proof/experiment evidence, mutate source, enqueue patches, submit, email, upload, or commit.",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _check(name, status, detail="", severity="blocking"):
    return {
        "name": name,
        "status": status,
        "passed": status == "PASS",
        "severity": "" if status == "PASS" else severity,
        "detail": "" if status == "PASS" else detail,
    }


def _select_seed(seed_plan_report, seed_id=""):
    candidates = list((seed_plan_report or {}).get("seed_candidates") or [])
    if seed_id:
        for item in candidates:
            if item.get("seed_id") == seed_id:
                return dict(item)
        return {}
    return dict(candidates[0]) if candidates else {}


def _risk_class_for_seed(seed):
    kind = seed.get("claim_kind") or ""
    if kind == "theorem_or_proof":
        return "theory-boundary"
    if kind == "experiment":
        return "experiment"
    return "artifact-boundary"


def _request_from_seed(seed):
    seed_id = seed.get("seed_id") or "claim-boundary-reentry"
    claim_kind = seed.get("claim_kind") or "evidence_anchor"
    source_locator = seed.get("source_locator") or seed.get("source_path") or ""
    request_id_text = "".join(ch for ch in seed_id if ch.isdigit()) or seed.get("request_id") or seed.get("original_request_id") or "0"
    request_id = 910000000 + int(request_id_text[-6:] or 0)
    if claim_kind == "theorem_or_proof":
        proposed = "re-enter the landed theorem/proof claim boundary for local proof-obligation evidence dry-run"
        evidence = "proof notes, lemma checklist, proof-check-result, and optional machine-checked formal certificate"
        verification = "claim quality gate, evidence execution, evidence quality gate, and formal certificate intake"
    elif claim_kind == "experiment":
        proposed = "re-enter the landed experiment claim boundary for reproducible local evidence dry-run"
        evidence = "allowlisted command manifest, metrics, output hashes, and reproducibility manifest"
        verification = "claim quality gate, local experiment execution, evidence quality gate, and source-apply dry-run"
    else:
        proposed = "re-enter the landed evidence claim boundary for local evidence dry-run"
        evidence = "local artifact hashes and evidence gate packet"
        verification = "claim quality gate and evidence quality gate"
    return {
        "request_id": request_id,
        "request_key": seed_id,
        "slug": seed.get("slug") or "",
        "status": "requested",
        "risk_class": _risk_class_for_seed(seed),
        "objection": (
            "Production-candidate re-entry seed from an already-landed Research compute claim boundary; "
            f"original_request={seed.get('original_request_id') or seed.get('request_id') or ''}."
        ),
        "proposed_fix": proposed,
        "evidence_needed": evidence,
        "verification": verification,
        "source_locator": source_locator,
        "patch_scope": "claim-boundary-reentry",
        "production_candidate_reentry": True,
        "production_candidate_seed_id": seed_id,
        "original_request_id": seed.get("original_request_id") or seed.get("request_id") or "",
        "original_gap_kind": seed.get("original_gap_kind") or "",
        "original_domain": seed.get("original_domain") or "",
        "original_risk_class": seed.get("original_risk_class") or "",
    }


def _forbidden_count(report):
    count = 0
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "candidate_patch_queue_mutation_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]:
        if (report or {}).get(key):
            count += 1
    return count


def claim_boundary_reentry_draft(seed_plan_report=None, seed_id="", label="", iteration_budget=1, autonomy_policy=None):
    policy = agent_autonomy_policy.normalize_policy(autonomy_policy)
    seed_plan_report = dict(seed_plan_report or {})
    selected_seed = _select_seed(seed_plan_report, seed_id=seed_id)
    synthetic_request = _request_from_seed(selected_seed) if selected_seed else {}
    claim_report = (
        research_compute_claim_draft.research_compute_claim_draft(
            requests=[synthetic_request],
            label=label or "",
            iteration_budget=iteration_budget,
            autonomy_policy=policy,
        )
        if synthetic_request
        else {}
    )
    packets = list(claim_report.get("claim_packets") or [])
    summary = claim_report.get("summary") or {}
    forbidden_count = _forbidden_count(claim_report)
    checks = [
        _check(
            "production_candidate_seed_plan_present",
            "PASS" if seed_plan_report else "ATTENTION",
            "missing production-candidate seed plan report",
            severity="readiness",
        ),
        _check(
            "seed_selected",
            "PASS" if selected_seed else "ATTENTION",
            f"seed_id={seed_id or '<first>'} not found",
            severity="readiness",
        ),
        _check(
            "claim_packet_generated",
            "PASS" if packets else "ATTENTION",
            "claim draft did not generate a claim packet",
            severity="readiness",
        ),
        _check(
            "no_forbidden_boundary_actions",
            "FAIL" if forbidden_count else "PASS",
            f"forbidden_action_count={forbidden_count}",
        ),
    ]
    failed_check_count = sum(1 for item in checks if item["status"] == "FAIL")
    attention_check_count = sum(1 for item in checks if item["status"] == "ATTENTION")
    if failed_check_count:
        status = "FAIL"
        state = FAILED_STATE
    elif attention_check_count:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE
    selected_claim_kind = packets[0].get("claim_kind") if packets else ""
    recommended_next = (
        "research-compute-claim-quality-gate "
        "--claim-draft-report <claim-boundary-reentry-draft-report> "
        f"--claim-packet-id {packets[0].get('claim_packet_id')}"
        if packets
        else ""
    )
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "status": status,
        "claim_boundary_reentry_draft_state": state,
        "label": label or "",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "seed_selected": bool(selected_seed),
        "seed_id": selected_seed.get("seed_id") or seed_id or "",
        "claim_packet_generated": bool(packets),
        "selected_claim_kind": selected_claim_kind,
        "full_agent_autonomy_authorized": bool(policy.get("full_agent_autonomy_authorized")),
        "autonomy_policy": policy,
        "recommended_next_command": recommended_next,
        "production_candidate_seed_plan_report_path": seed_plan_report.get("report_path") or "",
        "summary": {
            "seed_candidate_count": len(seed_plan_report.get("seed_candidates") or []),
            "claim_packet_count": len(packets),
            "theorem_proof_claim_packet_count": int(summary.get("theorem_proof_claim_packet_count") or 0),
            "experiment_claim_packet_count": int(summary.get("experiment_claim_packet_count") or 0),
            "validation_issue_count": int(summary.get("validation_issue_count") or 0),
            "automatic_final_claim_allowed_count": int(summary.get("automatic_final_claim_allowed_count") or 0),
            "automatic_source_apply_allowed_count": int(summary.get("automatic_source_apply_allowed_count") or 0),
            "automatic_merge_allowed_count": int(summary.get("automatic_merge_allowed_count") or 0),
            "automatic_submission_allowed_count": int(summary.get("automatic_submission_allowed_count") or 0),
            "source_mutation_performed_count": 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
            "failed_check_count": failed_check_count,
            "attention_check_count": attention_check_count,
        },
        "selected_seed": selected_seed,
        "synthetic_reentry_request": synthetic_request,
        "claim_draft_report": claim_report,
        "claim_packets": packets,
        "checks": checks,
        "boundary": [
            "This command converts an existing landed claim-boundary seed into a local claim packet for another dry-run pass.",
            "It does not execute proof or experiment evidence, edit manuscript source, enqueue or merge patches, read secrets, submit externally, send Telegram, or commit.",
            "The resulting claim packet must still pass claim-quality, evidence execution, evidence quality, source-readiness, and external-boundary gates before any later action.",
        ],
    }


def claim_boundary_reentry_draft_markdown(report):
    lines = [
        "# paper_factory Claim Boundary Re-entry Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_boundary_reentry_draft_state') or ''}",
        f"- Seed: {report.get('seed_id') or ''}",
        f"- Claim kind: {report.get('selected_claim_kind') or ''}",
        f"- Claim packet generated: {report.get('claim_packet_generated')}",
        f"- Recommended next command: `{report.get('recommended_next_command') or ''}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
