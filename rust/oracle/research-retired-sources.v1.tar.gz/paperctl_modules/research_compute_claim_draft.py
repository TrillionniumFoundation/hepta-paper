"""Draft machine-auditable theorem/proof/experiment claim packets.

This layer turns active research-compute gaps into explicit claim packets for
later evidence/source gates. It does not edit manuscript source, run compute,
call providers, enqueue/merge patches, or submit externally.
"""

import datetime as dt

from paperctl_modules import agent_autonomy_policy
from paperctl_modules import research_compute_candidate_referee_loop
from paperctl_modules import research_compute_experiment_registry


COMMAND = "research-compute-claim-draft"
READY_STATE = "CLAIM_DRAFT_READY"
IDLE_STATE = "CLAIM_DRAFT_IDLE_NO_ACTIVE_COMPUTE_GAPS"
CLASSIFICATION_STATE = "CLAIM_DRAFT_CLASSIFICATION_REQUIRED"


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _claim_kind(track):
    if track == "candidate_theorem_proof":
        return "theorem_or_proof"
    if track == "candidate_experiment":
        return "experiment"
    return "evidence_anchor"


def _short_field(item, key, default="", limit=220):
    text = " ".join(str((item or {}).get(key) or default).split())
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def _candidate_obligation_text(candidate_packet, name):
    for obligation in (candidate_packet or {}).get("candidate_obligations") or []:
        if obligation.get("name") == name:
            return " ".join(str(obligation.get("description") or "").split())
    return ""


def _gap_statement_field(gap_text, prefix):
    prefix_text = prefix.lower() + ":"
    for part in str(gap_text or "").split("|"):
        text = part.strip()
        if text.lower().startswith(prefix_text):
            return text.split(":", 1)[1].strip()
    return ""


def _claim_fragment(text):
    return " ".join(str(text or "").split()).strip(" .;")


def _claim_text(item, kind, candidate_packet=None):
    slug = item.get("slug") or "UNKNOWN"
    request_key = item.get("request_key") or item.get("request_id") or "request"
    source_locator = item.get("source_locator") or "unspecified source"
    gap_statement = _candidate_obligation_text(candidate_packet, "referee_gap_statement")
    proposed_fix = _short_field(item, "proposed_fix") or _gap_statement_field(gap_statement, "proposed_fix") or "the recorded referee repair"
    objection = _short_field(item, "objection") or _gap_statement_field(gap_statement, "objection") or "the recorded referee objection"
    evidence_needed = _short_field(item, "evidence_needed") or _gap_statement_field(gap_statement, "evidence_needed") or "local evidence"
    verification = _short_field(item, "verification") or _gap_statement_field(gap_statement, "verification") or "local verification"
    proposed_fix = _claim_fragment(proposed_fix[:220])
    objection = _claim_fragment(objection[:220])
    evidence_needed = _claim_fragment(evidence_needed[:220])
    verification = _claim_fragment(verification[:220])
    if kind == "theorem_or_proof":
        return (
            f"Proposition-style theorem/proof claim for {slug} request {request_key}: "
            f"at {source_locator}, the manuscript may add a bounded proof-support statement for "
            f"{proposed_fix}. The statement is limited to the referee gap \"{objection}\", "
            f"requires evidence trace \"{evidence_needed}\", and must satisfy verification \"{verification}\" "
            "before source landing or submission readiness can consume it."
        )
    if kind == "experiment":
        return (
            f"Experiment claim for {slug} request {request_key}: the local reproducibility run for "
            f"{proposed_fix} may be reported at {source_locator} only with the expected manifest, metrics, "
            f"summary hashes, and the recorded negative-result policy. The claim addresses \"{objection}\" "
            f"and uses verification \"{verification}\"."
        )
    return (
        f"Evidence-anchor claim for {slug} request {request_key}: text at {source_locator} may cite "
        f"the local evidence requirement \"{evidence_needed}\" for the referee gap \"{objection}\" "
        "only after hash recording and evidence-gate acceptance."
    )


def _verification_plan(kind):
    common = [
        "research_compute_evidence_gate",
        "no_write_referee_check",
        "candidate_patch_draft",
        "source_gate",
        "source_apply_preflight",
        "rollback_plan_and_post_apply_hash_verify",
        "merge_preflight_packet",
        "external_submission_readiness_capstone",
    ]
    if kind == "theorem_or_proof":
        return ["proof_obligation_checklist", "claim_scope_boundary", "lemma_or_assumption_cross_reference"] + common
    if kind == "experiment":
        return [
            "allowlisted_local_command_material",
            "no_network_execution",
            "stdout_stderr_manifest_capture",
            "output_hash_reproducibility_check",
            "negative_result_policy_check",
        ] + common
    return ["local_evidence_locator", "artifact_hash_manifest"] + common


def _experiment_spec(item):
    profile_id = research_compute_experiment_registry.infer_experiment_profile(item)
    profile = research_compute_experiment_registry.experiment_profile(profile_id)
    return {
        "allowlisted_experiment_id": profile_id,
        "experiment_profile": profile_id,
        "experiment_profile_domain": profile.get("domain") or "generic",
        "local_command_required": True,
        "agent_selected_allowlisted_command_allowed": bool(item.get("agent_supplied_compute_command_allowed")),
        "no_network_required": True,
        "cwd_override_allowed": False,
        "shell_allowed": False,
        "expected_outputs": [
            "agent-compute-manifest.json",
            "metrics.json",
            "experiment-summary.md",
            "experiment-reproducibility.json",
        ],
        "output_hashes_required": True,
        "data_dependencies": [
            {
                "name": "claim_packet_metadata",
                "kind": "recorded_claim_metadata",
                "source": "claim_packet",
                "available": True,
                "network_required": False,
            }
        ],
        "metric_acceptance": research_compute_experiment_registry.experiment_metric_acceptance(profile_id),
        "deterministic_seed": 0,
        "negative_or_inconclusive_result_policy": "report_without_overclaiming",
        "rollback_policy": "discard_research_compute_workspace_only",
    }


def _bridge_plan_request(item, kind, policy):
    bridge_gap_spec = (
        ((item.get("candidate_packet") or {}).get("bridge_gap_spec"))
        or item.get("candidate_bridge_gap_spec")
        or ""
    )
    return {
        "command": "research-compute-bridge-plan",
        "ready": bool(bridge_gap_spec),
        "gap": bridge_gap_spec,
        "label": f"claim-draft-request-{item.get('request_id') or 'unknown'}",
        "claim_kind": kind,
        "expected_job_kind": "proof" if kind == "theorem_or_proof" else ("experiment" if kind == "experiment" else "artifact"),
        "write_allowed": True,
        "execute_performed_by_bridge_plan": False,
        "source_mutation_allowed": False,
        "external_action_allowed": False,
        "full_agent_autonomy_authorized": bool(policy.get("full_agent_autonomy_authorized")),
    }


def _local_execution_request(item, kind, policy):
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_command_allowed = bool(full_autonomy and policy.get("agent_supplied_compute_command_allowed"))
    return {
        "command": "research-compute-execute",
        "ready_after_bridge_plan": True,
        "job_id_policy": "select_job_from_claim_bridge_plan",
        "claim_kind": kind,
        "proof_evidence_execution_required": kind == "theorem_or_proof",
        "experiment_execution_required": kind == "experiment",
        "agent_command_material_allowed": agent_command_allowed,
        "execute_allowed_after_bridge_plan": agent_command_allowed,
        "execute_flag_required": True,
        "allow_network": False,
        "shell_allowed": False,
        "cwd_override_allowed": False,
        "expected_outputs_required": True,
        "output_hashes_required": True,
        "source_mutation_allowed": False,
        "package_mutation_allowed": False,
        "archive_mutation_allowed": False,
        "patch_queue_mutation_allowed": False,
        "external_action_allowed": False,
    }


def _claim_packet(item, policy):
    track = item.get("candidate_track") or ""
    kind = _claim_kind(track)
    candidate_packet = item.get("candidate_packet") or {}
    patch_request = candidate_packet.get("candidate_patch_draft_request") or {}
    final_allowed = bool(
        (kind == "theorem_or_proof" and item.get("final_theorem_or_proof_claim_allowed"))
        or (kind == "experiment" and item.get("final_experiment_claim_allowed"))
    )
    packet = {
        "claim_packet_id": f"claim-draft-request-{item.get('request_id') or 'unknown'}",
        "request_id": item.get("request_id"),
        "request_key": item.get("request_key") or "",
        "slug": item.get("slug") or "",
        "risk_class": item.get("risk_class") or "",
        "domain": item.get("domain") or "",
        "gap_kind": item.get("gap_kind") or "",
        "source_locator": item.get("source_locator") or "",
        "candidate_track": track,
        "claim_kind": kind,
        "claim_text": _claim_text(item, kind, candidate_packet),
        "proof_obligations": candidate_packet.get("candidate_obligations") or [],
        "experiment_spec": _experiment_spec(item) if kind == "experiment" else {},
        "verification_plan": _verification_plan(kind),
        "bridge_gap_spec": candidate_packet.get("bridge_gap_spec") or item.get("candidate_bridge_gap_spec") or "",
        "candidate_packet_id": candidate_packet.get("packet_id") or item.get("candidate_packet_id") or "",
        "bridge_plan_request": _bridge_plan_request(item, kind, policy),
        "local_execution_request": _local_execution_request(item, kind, policy),
        "evidence_gate_packet": candidate_packet.get("evidence_gate_packet") or {},
        "source_gate_required": True,
        "manuscript_patch_ready": False,
        "automatic_final_claim_allowed": final_allowed,
        "automatic_source_apply_allowed": bool(patch_request.get("source_apply_allowed") or item.get("source_apply_allowed")),
        "automatic_merge_allowed": bool(patch_request.get("merge_allowed") or item.get("merge_allowed")),
        "automatic_submission_allowed": bool(patch_request.get("submission_allowed") or item.get("external_submission_allowed")),
        "full_agent_autonomy_authorized": bool(item.get("full_agent_autonomy_authorized")),
        "autonomy_policy": policy,
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "confidence_class": (
            "full_autonomy_policy_ready_requires_evidence_gate"
            if final_allowed
            else "agent_drafted_requires_evidence_gate"
        ),
    }
    if kind != "theorem_or_proof":
        packet["proof_obligations"] = [
            obligation
            for obligation in packet["proof_obligations"]
            if obligation.get("name") in {"referee_gap_statement", "claim_scope_boundary", "no_write_referee_check"}
        ]
    return packet


def research_compute_claim_draft(requests=None, label="", iteration_budget=3, autonomy_policy=None):
    policy = agent_autonomy_policy.normalize_policy(autonomy_policy)
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    loop_report = research_compute_candidate_referee_loop.research_compute_candidate_referee_loop_plan(
        requests=requests or [],
        label=label or "",
        iteration_budget=iteration_budget,
        autonomy_policy=policy,
    )
    loop_items = list(loop_report.get("loop_items") or [])
    claim_packets = [_claim_packet(item, policy) for item in loop_items]
    theorem_count = sum(1 for item in claim_packets if item.get("claim_kind") == "theorem_or_proof")
    experiment_count = sum(1 for item in claim_packets if item.get("claim_kind") == "experiment")
    evidence_count = sum(1 for item in claim_packets if item.get("claim_kind") == "evidence_anchor")
    validation_issues = []
    for packet in claim_packets:
        if packet.get("claim_kind") == "evidence_anchor":
            validation_issues.append(
                {
                    "issue": "claim_gap_classification_required",
                    "request_id": packet.get("request_id"),
                    "slug": packet.get("slug") or "",
                    "detail": packet.get("gap_kind") or "",
                }
            )

    if validation_issues:
        status = "ATTENTION"
        state = CLASSIFICATION_STATE
    elif claim_packets:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = IDLE_STATE

    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_draft_state": state,
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_claim_generated": bool(claim_packets),
        "manuscript_patch_ready": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_supplied_compute_command_allowed": bool(policy.get("agent_supplied_compute_command_allowed")),
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "automatic_theorem_finalization_allowed": bool(policy.get("automatic_theorem_finalization_allowed")),
        "automatic_proof_finalization_allowed": bool(policy.get("automatic_proof_finalization_allowed")),
        "automatic_experiment_finalization_allowed": bool(policy.get("automatic_experiment_finalization_allowed")),
        "automatic_source_apply_allowed": bool(policy.get("automatic_source_apply_allowed")),
        "automatic_merge_allowed": bool(policy.get("automatic_merge_allowed")),
        "automatic_submission_allowed": bool(policy.get("automatic_submission_allowed")),
        "summary": {
            "request_count": (loop_report.get("summary") or {}).get("request_count", 0),
            "active_compute_request_count": (loop_report.get("summary") or {}).get("active_compute_request_count", 0),
            "skipped_request_count": (loop_report.get("summary") or {}).get("skipped_request_count", 0),
            "claim_packet_count": len(claim_packets),
            "theorem_proof_claim_packet_count": theorem_count,
            "experiment_claim_packet_count": experiment_count,
            "evidence_anchor_claim_packet_count": evidence_count,
            "automatic_final_claim_allowed_count": sum(
                1 for packet in claim_packets if packet.get("automatic_final_claim_allowed")
            ),
            "automatic_source_apply_allowed_count": sum(
                1 for packet in claim_packets if packet.get("automatic_source_apply_allowed")
            ),
            "automatic_merge_allowed_count": sum(
                1 for packet in claim_packets if packet.get("automatic_merge_allowed")
            ),
            "automatic_submission_allowed_count": sum(
                1 for packet in claim_packets if packet.get("automatic_submission_allowed")
            ),
            "provider_model_call_authorized_count": sum(
                1 for packet in claim_packets if packet.get("provider_model_call_authorized")
            ),
            "external_action_authorized_count": sum(
                1 for packet in claim_packets if packet.get("external_action_authorized")
            ),
            "validation_issue_count": len(validation_issues),
        },
        "claim_packets": claim_packets,
        "validation_issues": validation_issues,
        "skipped_requests": loop_report.get("skipped_requests") or [],
        "source_loop_report_state": loop_report.get("loop_plan_state") or "",
        "boundary": [
            "This command drafts machine-auditable claim packets for theorem/proof/experiment gaps.",
            "It may mark final claim/source/merge/submission readiness under full-agent-autonomy policy for later gates.",
            "It does not run compute, edit manuscript source, apply patches, enqueue or merge patches, call providers/models, upload, email, or submit.",
            "Final manuscript text still requires evidence-gated source materialization and post-apply verification before any merge or submission readiness command may consume it.",
        ],
    }


def research_compute_claim_draft_markdown(report):
    lines = [
        "# paper_factory Research Compute Claim Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_draft_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Candidate claim generated: {report.get('candidate_claim_generated')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Claim Packets", ""])
    for packet in report.get("claim_packets") or []:
        lines.append(
            f"- `{packet.get('slug')}` request `{packet.get('request_id')}` "
            f"{packet.get('claim_kind')} final_allowed={packet.get('automatic_final_claim_allowed')}"
        )
    if not report.get("claim_packets"):
        lines.append("- No active theorem/proof/experiment claim packets selected.")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
