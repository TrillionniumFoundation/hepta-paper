"""Execute local proof/experiment evidence for quality-gated claim packets.

This wrapper bridges a passed claim quality gate into the existing
research-compute execute -> evidence ingest -> evidence gate path. It may run
only the controlled local executor; it does not mutate manuscripts or perform
external actions.
"""

import datetime as dt

from paperctl_modules import (
    agent_autonomy_policy,
    report_ref_health,
    research_compute_evidence_gate,
    research_compute_evidence_ingestor,
    research_compute_executor,
)


COMMAND = "research-compute-claim-evidence-execution"
QUALITY_GATE_COMMAND = "research-compute-claim-quality-gate"

IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_EXECUTION_IDLE_NO_CLAIM_PACKET"
READY_NOT_EXECUTED_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_EXECUTION_READY_NOT_EXECUTED"
EVIDENCE_GATE_READY_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_EXECUTION_EVIDENCE_GATE_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_EXECUTION_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _safe_token(value, fallback="claim"):
    text = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in str(value or ""))
    text = text.strip(".-_")
    return (text or fallback)[:120]


def _claim_kind(packet, quality_report):
    return str(
        (packet or {}).get("claim_kind")
        or (quality_report or {}).get("selected_claim_kind")
        or ""
    )


def _job_kind(packet, quality_report):
    kind = _claim_kind(packet, quality_report)
    if kind == "theorem_or_proof":
        return "proof"
    if kind == "experiment":
        return "experiment"
    return "artifact"


def _selected_packet(quality_report):
    packet = dict((quality_report or {}).get("selected_claim_packet") or {})
    if packet:
        return packet
    improvement = (quality_report or {}).get("quality_improvement_packet") or {}
    if not improvement:
        return {}
    return {
        "claim_packet_id": improvement.get("claim_packet_id") or "",
        "request_id": improvement.get("request_id"),
        "slug": improvement.get("slug") or "",
        "claim_kind": improvement.get("claim_kind") or "",
        "source_locator": improvement.get("source_locator") or "",
        "bridge_plan_request": improvement.get("bridge_plan_request") or {},
        "local_execution_request": improvement.get("local_execution_request") or {},
        "autonomy_policy": (quality_report or {}).get("autonomy_policy") or {},
        "full_agent_autonomy_authorized": bool((quality_report or {}).get("full_agent_autonomy_authorized")),
    }


def _validate_quality_report(quality_report):
    report = quality_report or {}
    issues = []
    _add_report_ref_health_issues(issues, "claim_quality_gate", report, QUALITY_GATE_COMMAND)
    if report.get("command") != QUALITY_GATE_COMMAND:
        issues.append({"issue": "claim_quality_gate_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "claim_quality_gate_not_pass", "detail": report.get("status") or ""})
    if not report.get("claim_quality_gate_ready"):
        issues.append({"issue": "claim_quality_gate_not_ready"})
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            issues.append({"issue": f"forbidden_quality_gate_boundary:{key}"})
    return issues


def _autonomy_policy(packet, quality_report):
    return agent_autonomy_policy.normalize_policy(
        (packet or {}).get("autonomy_policy")
        or (quality_report or {}).get("autonomy_policy")
        or {}
    )


def _claim_evidence_plan(packet, quality_report):
    packet = packet or {}
    quality_report = quality_report or {}
    bridge_request = packet.get("bridge_plan_request") or quality_report.get("bridge_plan_request") or {}
    local_request = packet.get("local_execution_request") or quality_report.get("local_execution_request") or {}
    claim_packet_id = packet.get("claim_packet_id") or quality_report.get("claim_packet_id") or "claim"
    job_id = f"claim-evidence-{_safe_token(claim_packet_id)}"
    slug = packet.get("slug") or quality_report.get("slug") or "unregistered-claim"
    gap = (
        packet.get("claim_text")
        or packet.get("bridge_gap_spec")
        or bridge_request.get("gap")
        or packet.get("claim_text")
        or quality_report.get("selected_source_locator")
        or ""
    )
    job_kind = _job_kind(packet, quality_report)
    plan = {
        "command": "research-compute-bridge-plan",
        "label": bridge_request.get("label") or quality_report.get("label") or "",
        "status": "PASS",
        "plan_state": "CLAIM_EVIDENCE_BRIDGE_PLAN_READY",
        "plan_only": True,
        "claim_evidence_bridge_plan_created": True,
        "job_id": job_id,
        "slug": slug,
        "claim_packet_id": claim_packet_id,
        "claim_kind": _claim_kind(packet, quality_report),
        "local_execution_request": local_request,
        "summary": {
            "job_count": 1,
            "proof_job_count": 1 if job_kind == "proof" else 0,
            "experiment_job_count": 1 if job_kind == "experiment" else 0,
        },
        "jobs": [
            {
                "job_id": job_id,
                "slug": slug,
                "kind": job_kind,
                "gap": gap,
                "gap_spec": gap,
                "claim_text": packet.get("claim_text") or gap,
                "claim_packet_id": claim_packet_id,
                "source_locator": packet.get("source_locator") or quality_report.get("selected_source_locator") or "",
                "proof_obligations": list(packet.get("proof_obligations") or []),
                "experiment_spec": dict(packet.get("experiment_spec") or {}),
                "verification_plan": list(packet.get("verification_plan") or []),
                "safety_boundary": {
                    "allow_network": False,
                    "source_mutation_allowed": False,
                    "package_mutation_allowed": False,
                    "archive_mutation_allowed": False,
                    "external_action_allowed": False,
                    "provider_model_call_allowed": False,
                    "secret_material_read_allowed": False,
                },
                "workspace_dir": f"logs/paperctl/research_compute/{_safe_token(slug)}/{job_id}",
                "resource_limits": {"timeout_seconds": 300},
            }
        ],
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "commit_performed": False,
    }
    return plan


def _empty_report(label, status, state, issues, quality_report, packet=None, plan=None):
    packet = packet or {}
    plan = plan or {}
    local_request = packet.get("local_execution_request") or (quality_report or {}).get("local_execution_request") or {}
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_evidence_execution_state": state,
        "claim_evidence_execution_created": status != "FAIL",
        "claim_evidence_execution_ready": False,
        "ready_for_manuscript_patch_materialization": False,
        "slug": packet.get("slug") or (quality_report or {}).get("slug") or "",
        "claim_quality_gate_report_path": (quality_report or {}).get("report_path") or "",
        "claim_quality_gate_report_sha256": (quality_report or {}).get("report_sha256") or "",
        "claim_packet_id": packet.get("claim_packet_id") or (quality_report or {}).get("claim_packet_id") or "",
        "selected_request_id": str(packet.get("request_id") or (quality_report or {}).get("selected_request_id") or ""),
        "selected_claim_kind": _claim_kind(packet, quality_report),
        "job_id": plan.get("job_id") or "",
        "workspace_dir": ((plan.get("jobs") or [{}])[0]).get("workspace_dir") if plan.get("jobs") else "",
        "proof_evidence_execution_required": bool(local_request.get("proof_evidence_execution_required")),
        "experiment_execution_required": bool(local_request.get("experiment_execution_required")),
        "agent_command_material_allowed": bool(local_request.get("agent_command_material_allowed")),
        "execute_requested": False,
        "execution_performed": False,
        "bridge_plan_created": bool(plan),
        "execute_report_created": False,
        "evidence_ingest_report_created": False,
        "evidence_gate_report_created": False,
        "evidence_gate_ready": False,
        "output_hashes": [],
        "bridge_plan_report_path": "",
        "bridge_plan_report_sha256": "",
        "execute_report_path": "",
        "execute_report_sha256": "",
        "evidence_ingest_report_path": "",
        "evidence_ingest_report_sha256": "",
        "evidence_gate_report_path": "",
        "evidence_gate_report_sha256": "",
        "full_agent_autonomy_authorized": bool((quality_report or {}).get("full_agent_autonomy_authorized")),
        "autonomy_policy": _autonomy_policy(packet, quality_report),
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues or []),
            "bridge_plan_created_count": 1 if plan else 0,
            "execute_report_created_count": 0,
            "evidence_ingest_report_created_count": 0,
            "evidence_gate_report_created_count": 0,
            "output_hash_count": 0,
            "evidence_gate_ready_count": 0,
            "source_mutation_count": 0,
            "external_action_performed_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": list(issues or []),
        "claim_evidence_bridge_plan": plan,
        "execute_report": {},
        "evidence_ingest_report": {},
        "evidence_gate_report": {},
        "selected_claim_packet": packet,
        "boundary": [
            "This command connects a passed claim quality gate to controlled local proof/experiment evidence execution.",
            "It may run only the existing research-compute local executor with agent-generated command material when full-agent-autonomy policy allows it.",
            "It does not edit source, enqueue or merge patches, commit, read secrets, call providers/models, upload, email, final submit, or perform external actions.",
        ],
    }


def research_compute_claim_evidence_execution(quality_report, root=".", execute=False, label=""):
    quality_report = quality_report or {}
    issues = _validate_quality_report(quality_report)
    packet = _selected_packet(quality_report)
    if not packet and not issues:
        return _empty_report(label, "PASS", IDLE_STATE, [], quality_report)
    if not packet:
        return _empty_report(label, "ATTENTION", ATTENTION_STATE, issues, quality_report)

    plan = _claim_evidence_plan(packet, quality_report)
    local_request = packet.get("local_execution_request") or quality_report.get("local_execution_request") or {}
    if execute and not local_request.get("agent_command_material_allowed"):
        issues.append({"issue": "agent_command_material_not_allowed_by_claim_execution_request"})
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if issues:
        status = "FAIL" if forbidden else "ATTENTION"
        state = FORBIDDEN_STATE if forbidden else ATTENTION_STATE
        report = _empty_report(label, status, state, issues, quality_report, packet=packet, plan=plan)
        report["execute_requested"] = bool(execute)
        return report

    if not execute:
        return _empty_report(label, "PASS", READY_NOT_EXECUTED_STATE, [], quality_report, packet=packet, plan=plan)

    policy = _autonomy_policy(packet, quality_report)
    job_id = plan["job_id"]
    execute_report = research_compute_executor.execute_research_compute_job(
        plan,
        job_id,
        {},
        root,
        execute=True,
        label=label or "",
        agent_command_material=True,
        autonomy_policy=policy,
    )
    ingest_report = {}
    gate_report = {}
    evidence_gate_ready = False
    if execute_report.get("status") == "PASS":
        ingest_report = research_compute_evidence_ingestor.research_compute_evidence_ingest(
            execute_report,
            label=label or "",
        )
    if ingest_report.get("status") == "PASS":
        gate_report = research_compute_evidence_gate.research_compute_evidence_gate(
            ingest_report,
            label=label or "",
        )
        evidence_gate_ready = gate_report.get("status") == "PASS" and gate_report.get("patch_generation_request_created")

    if evidence_gate_ready:
        status = "PASS"
        state = EVIDENCE_GATE_READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE

    report = _empty_report(label, status, state, [], quality_report, packet=packet, plan=plan)
    report["claim_evidence_execution_ready"] = bool(evidence_gate_ready)
    report["ready_for_manuscript_patch_materialization"] = bool(evidence_gate_ready)
    report["execute_requested"] = True
    report["execution_performed"] = bool(execute_report.get("execution_performed"))
    report["execute_report_created"] = bool(execute_report)
    report["evidence_ingest_report_created"] = bool(ingest_report)
    report["evidence_gate_report_created"] = bool(gate_report)
    report["evidence_gate_ready"] = bool(evidence_gate_ready)
    report["output_hashes"] = list(execute_report.get("output_hashes") or [])
    report["summary"]["execute_report_created_count"] = 1 if execute_report else 0
    report["summary"]["evidence_ingest_report_created_count"] = 1 if ingest_report else 0
    report["summary"]["evidence_gate_report_created_count"] = 1 if gate_report else 0
    report["summary"]["output_hash_count"] = len(report["output_hashes"])
    report["summary"]["evidence_gate_ready_count"] = 1 if evidence_gate_ready else 0
    report["execute_report"] = execute_report
    report["evidence_ingest_report"] = ingest_report
    report["evidence_gate_report"] = gate_report
    if not evidence_gate_ready:
        report["validation_issues"] = (
            list(execute_report.get("validation", {}).get("issues") or [])
            + list(ingest_report.get("validation_issues") or [])
            + list(gate_report.get("validation_issues") or [])
        )
        report["summary"]["validation_issue_count"] = len(report["validation_issues"])
    return report


def research_compute_claim_evidence_execution_markdown(report):
    lines = [
        "# paper_factory Claim Evidence Execution",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_evidence_execution_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Claim kind: `{report.get('selected_claim_kind') or ''}`",
        f"- Job: `{report.get('job_id') or ''}`",
        f"- Workspace: `{report.get('workspace_dir') or ''}`",
        f"- Execute requested: {report.get('execute_requested')}",
        f"- Execution performed: {report.get('execution_performed')}",
        f"- Evidence gate ready: {report.get('evidence_gate_ready')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("output_hashes"):
        lines.extend(["", "## Output Hashes", ""])
        for item in report.get("output_hashes") or []:
            lines.append(f"- `{item.get('path')}` {item.get('sha256')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
