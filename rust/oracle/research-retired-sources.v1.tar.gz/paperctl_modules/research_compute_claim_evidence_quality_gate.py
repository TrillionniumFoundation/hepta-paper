"""Quality gate for locally generated claim proof/experiment evidence."""

import datetime as dt
import json
import pathlib
import re

from paperctl_modules import report_ref_health
from paperctl_modules import research_compute_formal_verifier_adapter
from paperctl_modules import research_compute_experiment_registry


COMMAND = "research-compute-claim-evidence-quality-gate"
EVIDENCE_EXECUTION_COMMAND = "research-compute-claim-evidence-execution"

IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_QUALITY_GATE_IDLE_NO_EVIDENCE"
READY_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_QUALITY_GATE_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_EVIDENCE_QUALITY_GATE_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


GENERIC_PROOF_PHRASES = [
    "candidate proof evidence generated locally",
    "boundary: no source mutation or external action performed",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _read_text(root, workspace_dir, relative_path):
    if not workspace_dir or not relative_path:
        return ""
    path = pathlib.Path(root) / workspace_dir / relative_path
    if not path.exists() or not path.is_file():
        return ""
    try:
        return path.read_text(errors="ignore")
    except Exception:
        return ""


def _read_json(root, workspace_dir, relative_path):
    text = _read_text(root, workspace_dir, relative_path)
    if not text:
        return {}
    try:
        return json.loads(text)
    except Exception:
        return {}


def _output_paths(report):
    return {str(item.get("path") or "") for item in (report or {}).get("output_hashes") or []}


def _claim_tokens(packet):
    text = str((packet or {}).get("claim_text") or "")
    tokens = []
    for token in re.findall(r"[A-Za-z][A-Za-z0-9_-]{5,}", text):
        lowered = token.lower()
        if lowered in {"candidate", "request", "referee", "source", "claim", "statement"}:
            continue
        tokens.append(lowered)
    return tokens[:24]


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _validate_execution_report(report):
    issues = []
    item = report or {}
    if not item:
        return issues
    _add_report_ref_health_issues(issues, "claim_evidence_execution", item, EVIDENCE_EXECUTION_COMMAND)
    if item.get("command") != EVIDENCE_EXECUTION_COMMAND:
        issues.append({"issue": "claim_evidence_execution_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_evidence_execution_not_pass", "detail": item.get("status") or ""})
    if not item.get("evidence_gate_ready"):
        issues.append({"issue": "claim_evidence_gate_not_ready"})
    for key in FORBIDDEN_KEYS:
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_evidence_execution_boundary:{key}"})
    return issues


def _proof_checks(report, packet, root):
    workspace_dir = report.get("workspace_dir") or ""
    outputs = _output_paths(report)
    proof_notes = _read_text(root, workspace_dir, "proof-notes.md")
    checklist = _read_json(root, workspace_dir, "lemma-checklist.json")
    formal_slot = _read_json(root, workspace_dir, "formal-verifier-slot.json")
    proof_check = _read_json(root, workspace_dir, "proof-check-result.json")
    claim_tokens = _claim_tokens(packet)
    proof_lower = proof_notes.lower()
    source_locator = str((packet or {}).get("source_locator") or report.get("selected_source_locator") or "")
    proof_obligations = list((packet or {}).get("proof_obligations") or [])
    lemma_names = {
        str(item.get("name") or "")
        for item in checklist.get("lemmas") or []
        if isinstance(item, dict)
    }
    overlap = [token for token in claim_tokens if token in proof_lower]
    generic_only = (
        bool(proof_notes)
        and all(phrase in proof_lower for phrase in GENERIC_PROOF_PHRASES)
        and "claim text" not in proof_lower
        and "proof obligations" not in proof_lower
    )
    proof_check_formal = bool(proof_check.get("formal_verifier_used") or proof_check.get("formal_certificate_present"))
    adapter_contract = research_compute_formal_verifier_adapter.formal_verifier_adapter_contract(
        formal_slot=formal_slot,
        proof_check=proof_check,
    )
    formal_certificate = research_compute_formal_verifier_adapter.validate_formal_verifier_certificate(
        report,
        packet,
        root,
        formal_slot=formal_slot,
        proof_check=proof_check,
    )
    formal_slot_consistent = bool(formal_slot) and (
        (
            not proof_check_formal
            and formal_slot.get("formal_verifier_used") is False
            and formal_slot.get("formal_certificate_present") is False
            and formal_slot.get("proof_notes_are_formal_certificate") is False
        )
        or (
            proof_check_formal
            and formal_slot.get("formal_certificate_present") is True
            and formal_slot.get("proof_notes_are_formal_certificate") is False
        )
    )
    return [
        _check(
            "proof_outputs_present",
            {"proof-notes.md", "lemma-checklist.json", "formal-verifier-slot.json", "proof-check-result.json"}.issubset(outputs),
            "proof_outputs_missing",
        ),
        _check("proof_notes_readable", bool(proof_notes), "proof_notes_missing_or_unreadable"),
        _check("proof_notes_claim_specific", bool(overlap), "proof_notes_lack_claim_specific_terms"),
        _check("proof_notes_claim_text_section", "claim text" in proof_lower, "proof_notes_claim_text_section_missing"),
        _check("proof_notes_source_locator", bool(source_locator and source_locator.lower() in proof_lower), "proof_notes_source_locator_missing"),
        _check("proof_notes_obligation_trace", bool(proof_obligations and "proof obligations" in proof_lower), "proof_notes_obligation_trace_missing"),
        _check("proof_notes_safety_boundary", "source mutation performed: false" in proof_lower and "external action performed: false" in proof_lower, "proof_notes_safety_boundary_missing"),
        _check("proof_notes_not_generic_only", not generic_only, "proof_notes_generic_only"),
        _check("lemma_checklist_readable", bool(checklist), "lemma_checklist_missing_or_unreadable"),
        _check("lemma_checklist_claim_text", bool(checklist.get("claim_text")), "lemma_checklist_claim_text_missing"),
        _check("lemma_checklist_source_locator", bool(checklist.get("source_locator")), "lemma_checklist_source_locator_missing"),
        _check("lemma_checklist_obligations", bool(checklist.get("proof_obligations")), "lemma_checklist_obligations_missing"),
        _check("lemma_checklist_claim_alignment", "claim_alignment" in lemma_names, "claim_alignment_lemma_missing"),
        _check("lemma_checklist_obligation_trace", "proof_obligation_trace" in lemma_names, "proof_obligation_trace_lemma_missing"),
        _check("lemma_checklist_gate_ready", checklist.get("ready_for_evidence_gate") is True, "lemma_checklist_not_gate_ready"),
        _check("formal_verifier_slot_present", "formal-verifier-slot.json" in outputs, "formal_verifier_slot_output_missing"),
        _check("formal_verifier_slot_readable", bool(formal_slot), "formal_verifier_slot_missing_or_unreadable"),
        _check(
            "formal_verifier_slot_kind",
            formal_slot.get("slot_kind") == "formal_verifier_certificate_slot",
            "formal_verifier_slot_kind_unsupported",
        ),
        _check(
            "formal_verifier_slot_requirement",
            formal_slot.get("formal_verifier_required_before_formal_claim") is True,
            "formal_verifier_slot_requirement_missing",
        ),
        _check(
            "formal_verifier_slot_consistent_with_checker",
            formal_slot_consistent,
            "formal_verifier_slot_checker_consistency_failed",
        ),
        _check(
            "formal_verifier_slot_safety_boundary",
            not any(
                formal_slot.get(key)
                for key in [
                    "source_mutation_performed",
                    "external_action_performed",
                    "secret_material_read_performed",
                    "network_performed",
                ]
            ),
            "formal_verifier_slot_safety_boundary_failed",
        ),
        _check("proof_check_result_readable", bool(proof_check), "proof_check_result_missing_or_unreadable"),
        _check(
            "proof_check_result_kind",
            proof_check.get("checker_kind") in {"local_proof_obligation_checker", "formal_theorem_prover"},
            "proof_check_result_kind_unsupported",
        ),
        _check(
            "proof_check_result_finalization_ready",
            proof_check.get("automated_claim_finalization_ready") is True,
            "proof_check_result_finalization_not_ready",
        ),
        _check(
            "proof_check_result_obligation_count",
            int(proof_check.get("machine_checked_obligation_count") or 0) > 0,
            "proof_check_result_obligation_count_missing",
        ),
        _check(
            "proof_check_result_references_formal_slot",
            proof_check.get("formal_verifier_slot_path") == "formal-verifier-slot.json",
            "proof_check_result_formal_slot_reference_missing",
        ),
        _check(
            "proof_check_result_safety_boundary",
            not any(
                proof_check.get(key)
                for key in [
                    "source_mutation_performed",
                    "external_action_performed",
                    "secret_material_read_performed",
                    "network_performed",
                ]
            ),
            "proof_check_result_safety_boundary_failed",
        ),
    ] + list(adapter_contract.get("checks") or []) + list(formal_certificate.get("checks") or [])


def _experiment_checks(report, packet, root):
    workspace_dir = report.get("workspace_dir") or ""
    outputs = _output_paths(report)
    metrics = _read_json(root, workspace_dir, "metrics.json")
    summary = _read_text(root, workspace_dir, "experiment-summary.md")
    reproducibility = _read_json(root, workspace_dir, "experiment-reproducibility.json")
    experiment_spec = dict((packet or {}).get("experiment_spec") or metrics.get("experiment_spec") or {})
    registry = research_compute_experiment_registry.validate_experiment_spec(
        experiment_spec,
        metrics=metrics,
        reproducibility=reproducibility,
        output_paths=outputs,
    )
    summary_lower = summary.lower()
    source_locator = str((packet or {}).get("source_locator") or report.get("selected_source_locator") or "")
    claim_tokens = _claim_tokens(packet)
    overlap = [token for token in claim_tokens if token in summary_lower]
    return [
        _check(
            "experiment_outputs_present",
            {"metrics.json", "experiment-summary.md", "experiment-reproducibility.json"}.issubset(outputs),
            "experiment_outputs_missing",
        ),
        _check("metrics_readable", bool(metrics), "metrics_missing_or_unreadable"),
        _check("metrics_claim_text", bool(metrics.get("claim_text")), "metrics_claim_text_missing"),
        _check("metrics_source_locator", bool(metrics.get("source_locator")), "metrics_source_locator_missing"),
        _check("experiment_summary_readable", bool(summary), "experiment_summary_missing_or_unreadable"),
        _check("experiment_summary_claim_specific", bool(overlap), "experiment_summary_lack_claim_specific_terms"),
        _check("experiment_summary_source_locator", bool(source_locator and source_locator.lower() in summary_lower), "experiment_summary_source_locator_missing"),
        _check("experiment_summary_boundary_present", "boundary" in summary_lower and "no external action performed" in summary_lower, "experiment_summary_boundary_missing"),
        _check("experiment_reproducibility_readable", bool(reproducibility), "experiment_reproducibility_missing_or_unreadable"),
        _check(
            "experiment_reproducibility_kind",
            reproducibility.get("checker_kind") == "local_experiment_reproducibility_checker",
            "experiment_reproducibility_kind_unsupported",
        ),
        _check(
            "experiment_reproducibility_finalization_ready",
            reproducibility.get("automated_claim_finalization_ready") is True,
            "experiment_reproducibility_finalization_not_ready",
        ),
        _check(
            "experiment_reproducibility_negative_policy",
            bool(reproducibility.get("negative_or_inconclusive_result_policy")),
            "experiment_reproducibility_negative_policy_missing",
        ),
        _check(
            "experiment_reproducibility_safety_boundary",
            not any(
                reproducibility.get(key)
                for key in [
                    "source_mutation_performed",
                    "external_action_performed",
                    "secret_material_read_performed",
                    "network_performed",
                ]
            ),
            "experiment_reproducibility_safety_boundary_failed",
        ),
    ] + list(registry.get("checks") or [])


def _academic_finalization_packet(report, packet, root, ready, issue_names):
    workspace_dir = report.get("workspace_dir") or ""
    kind = str((packet or {}).get("claim_kind") or report.get("selected_claim_kind") or "")
    proof_check = _read_json(root, workspace_dir, "proof-check-result.json") if kind == "theorem_or_proof" else {}
    formal_slot = _read_json(root, workspace_dir, "formal-verifier-slot.json") if kind == "theorem_or_proof" else {}
    formal_certificate = (
        research_compute_formal_verifier_adapter.validate_formal_verifier_certificate(
            report,
            packet,
            root,
            formal_slot=formal_slot,
            proof_check=proof_check,
        )
        if kind == "theorem_or_proof"
        else {}
    )
    formal_certificate_verified = bool(formal_certificate.get("formal_certificate_verified"))
    adapter_contract = (
        research_compute_formal_verifier_adapter.formal_verifier_adapter_contract(
            formal_slot=formal_slot,
            proof_check=proof_check,
        )
        if kind == "theorem_or_proof"
        else {}
    )
    reproducibility = _read_json(root, workspace_dir, "experiment-reproducibility.json") if kind == "experiment" else {}
    metrics = _read_json(root, workspace_dir, "metrics.json") if kind == "experiment" else {}
    experiment_spec = dict((packet or {}).get("experiment_spec") or metrics.get("experiment_spec") or {})
    outputs = _output_paths(report)
    experiment_registry = (
        research_compute_experiment_registry.validate_experiment_spec(
            experiment_spec,
            metrics=metrics,
            reproducibility=reproducibility,
            output_paths=outputs,
        )
        if kind == "experiment" else {}
    )
    metric_names = sorted(
        str(item.get("name") or "")
        for item in metrics.get("rows") or []
        if isinstance(item, dict) and item.get("name")
    )
    checker = proof_check or reproducibility
    return {
        "packet_type": "research_compute_academic_claim_agent_finalization_packet",
        "schema": "paper_factory.research_compute.academic_claim_agent_finalization.v1",
        "ready": bool(ready),
        "claim_packet_id": (packet or {}).get("claim_packet_id") or report.get("claim_packet_id") or "",
        "slug": report.get("slug") or (packet or {}).get("slug") or "",
        "claim_kind": kind,
        "checker_kind": checker.get("checker_kind") or "",
        "checker_version": checker.get("checker_version") or "",
        "formal_verifier_used": formal_certificate_verified,
        "formal_certificate_present": formal_certificate_verified,
        "formal_certificate_kind": formal_certificate.get("certificate_kind") or "",
        "formal_certificate_artifact_path": formal_certificate.get("certificate_artifact_path") or "",
        "formal_certificate_sha256": formal_certificate.get("certificate_sha256") or "",
        "formal_certificate_validation_state": "verified" if formal_certificate_verified else "not_verified",
        "formal_certificate_validation_check_count": len(formal_certificate.get("checks") or []),
        "formal_verifier_adapter_contract_version": adapter_contract.get("adapter_contract_version") or "",
        "formal_verifier_adapter_ready": bool(adapter_contract.get("formal_verifier_adapter_ready")),
        "formal_verifier_adapter_supported_certificate_kinds": list(adapter_contract.get("supported_certificate_kinds") or []),
        "formal_verifier_adapter_available_certificate_kinds": list(adapter_contract.get("available_certificate_kinds") or []),
        "formal_verifier_slot_path": checker.get("formal_verifier_slot_path") or formal_slot.get("slot_path") or "",
        "formal_verifier_required_before_formal_claim": bool(formal_slot.get("formal_verifier_required_before_formal_claim")),
        "proof_notes_are_formal_certificate": bool(checker.get("proof_notes_are_formal_certificate") or formal_slot.get("proof_notes_are_formal_certificate")),
        "local_proof_obligation_checker_used": checker.get("checker_kind") == "local_proof_obligation_checker",
        "experiment_reproducibility_checker_used": checker.get("checker_kind") == "local_experiment_reproducibility_checker",
        "allowlisted_experiment_id": checker.get("allowlisted_experiment_id") or "",
        "experiment_profile_domain": research_compute_experiment_registry.experiment_profile(
            checker.get("allowlisted_experiment_id") or ""
        ).get("domain") or "",
        "registered_experiment_profile_count": len(research_compute_experiment_registry.EXPERIMENT_PROFILE_REGISTRY),
        "experiment_metric_names": metric_names,
        "experiment_required_domain_metric_names": list(
            experiment_registry.get("required_domain_metric_names") or []
        ),
        "experiment_profile_metric_count": int(metrics.get("profile_metric_count") or len(metric_names) or 0),
        "experiment_registry_ready": bool(experiment_registry.get("experiment_spec_ready")) if kind == "experiment" else False,
        "experiment_evidence_maturity": metrics.get("evidence_maturity") or reproducibility.get("evidence_maturity") or "",
        "experiment_paper_constant_finalization_state": (
            metrics.get("paper_constant_finalization_state")
            or reproducibility.get("paper_constant_finalization_state")
            or ""
        ),
        "experiment_promotion_eligible": bool(metrics.get("promotion_eligible") or reproducibility.get("promotion_eligible")),
        "experiment_named_input_promotion_allowed": bool(
            metrics.get("named_input_promotion_allowed")
            or reproducibility.get("named_input_promotion_allowed")
        ),
        "experiment_final_signature_present": bool(
            metrics.get("final_signature_present")
            or reproducibility.get("final_signature_present")
        ),
        "experiment_final_signature_kind": metrics.get("final_signature_kind") or reproducibility.get("final_signature_kind") or "",
        "experiment_result_usage_policy": metrics.get("result_usage_policy") or reproducibility.get("metrics_result_usage_policy") or "",
        "automated_claim_finalization_ready": bool(checker.get("automated_claim_finalization_ready")) and bool(ready),
        "finalization_decision": "ready_for_manuscript_materialization" if ready else "attention",
        "required_revisions": list(issue_names or []),
        "limitations": list(checker.get("limitations") or []),
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
    }


def _quality_checks(report, packet, root):
    kind = str((packet or {}).get("claim_kind") or report.get("selected_claim_kind") or "")
    common = [
        _check("output_hashes_present", bool(report.get("output_hashes")), "output_hashes_missing"),
        _check("agent_command_material_generated", bool((report.get("execute_report") or {}).get("agent_command_material_generated")), "agent_command_material_not_generated"),
        _check("evidence_gate_ready", bool(report.get("evidence_gate_ready")), "evidence_gate_not_ready"),
    ]
    if kind == "theorem_or_proof":
        return common + _proof_checks(report, packet, root)
    if kind == "experiment":
        return common + _experiment_checks(report, packet, root)
    return common + [_check("claim_kind_supported", False, "unsupported_claim_kind")]


def _issue_names(checks, validation_issues=None):
    names = []
    for item in validation_issues or []:
        names.append(item.get("issue") or "")
    for item in checks or []:
        if item.get("status") != "PASS":
            names.append(item.get("detail") or item.get("name") or "")
    return [item for item in names if item]


def research_compute_claim_evidence_quality_gate(evidence_execution_report, root=".", label=""):
    evidence_execution_report = evidence_execution_report or {}
    validation_issues = _validate_execution_report(evidence_execution_report)
    packet = evidence_execution_report.get("selected_claim_packet") or {}
    if not evidence_execution_report:
        return {
            "created_at": _created_at(),
            "command": COMMAND,
            "label": label or "",
            "status": "PASS",
            "claim_evidence_quality_gate_state": IDLE_STATE,
            "claim_evidence_quality_gate_created": True,
            "claim_evidence_quality_gate_ready": False,
            "ready_for_manuscript_patch_materialization": False,
            "slug": "",
            "claim_packet_id": "",
            "selected_claim_kind": "",
            "workspace_dir": "",
            "claim_evidence_execution_report_path": "",
            "claim_evidence_execution_report_sha256": "",
            "output_hashes": [],
            "academic_claim_agent_finalization_ready": False,
            "formal_verifier_used": False,
            "formal_verifier_adapter_ready": False,
            "local_proof_obligation_checker_used": False,
            "experiment_reproducibility_checker_used": False,
            "source_mutation_performed": False,
            "package_mutation_performed": False,
            "archive_mutation_performed": False,
            "provider_model_call_performed": False,
            "external_action_performed": False,
            "secret_material_read_performed": False,
            "candidate_patch_queue_mutation_performed": False,
            "patch_queue_merge_performed": False,
            "commit_performed": False,
            "report_write_performed": False,
            "db_mutation_performed": False,
            "summary": {
                "validation_issue_count": 0,
                "quality_check_count": 0,
                "quality_issue_count": 0,
                "output_hash_count": 0,
                "academic_claim_agent_finalization_ready_count": 0,
                "formal_verifier_used_count": 0,
                "formal_verifier_adapter_ready_count": 0,
                "formal_verifier_adapter_available_certificate_kind_count": 0,
                "local_proof_obligation_checker_used_count": 0,
                "experiment_reproducibility_checker_used_count": 0,
                "experiment_nonpromotional_candidate_count": 0,
                "experiment_promotion_eligible_count": 0,
                "experiment_named_input_promotion_allowed_count": 0,
                "experiment_final_signature_present_count": 0,
                "claim_evidence_quality_gate_ready_count": 0,
                "source_mutation_count": 0,
                "external_action_performed_count": 0,
                "commit_performed_count": 0,
            },
            "validation_issues": [],
            "quality_checks": [],
            "quality_packet": {},
            "academic_claim_finalization_packet": {},
            "selected_claim_packet": {},
            "boundary": [
                "No claim evidence execution report was supplied, so no workspace evidence was inspected.",
            ],
        }

    checks = _quality_checks(evidence_execution_report, packet, root)
    issue_names = _issue_names(checks, validation_issues)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    ready = bool(evidence_execution_report) and not issue_names and not forbidden
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif ready:
        status = "PASS"
        state = READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE

    academic_packet = _academic_finalization_packet(
        evidence_execution_report,
        packet,
        root,
        ready,
        issue_names,
    )
    quality_packet = {
        "packet_type": "research_compute_claim_evidence_quality_packet",
        "schema": "paper_factory.research_compute.claim_evidence_quality_gate.packet.v1",
        "ready": ready,
        "claim_packet_id": evidence_execution_report.get("claim_packet_id") or "",
        "slug": evidence_execution_report.get("slug") or "",
        "claim_kind": evidence_execution_report.get("selected_claim_kind") or "",
        "workspace_dir": evidence_execution_report.get("workspace_dir") or "",
        "output_hashes": list(evidence_execution_report.get("output_hashes") or []),
        "required_revisions": issue_names,
        "academic_claim_finalization_packet": academic_packet,
        "next_agent_command": (
            "research-compute-claim-manuscript-patch-materialization"
            if ready
            else "research-compute-claim-evidence-execution"
        ),
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
    }
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_evidence_quality_gate_state": state,
        "claim_evidence_quality_gate_created": status != "FAIL",
        "claim_evidence_quality_gate_ready": ready,
        "ready_for_manuscript_patch_materialization": ready,
        "slug": evidence_execution_report.get("slug") or "",
        "claim_packet_id": evidence_execution_report.get("claim_packet_id") or "",
        "selected_claim_kind": evidence_execution_report.get("selected_claim_kind") or "",
        "workspace_dir": evidence_execution_report.get("workspace_dir") or "",
        "claim_evidence_execution_report_path": evidence_execution_report.get("report_path") or "",
        "claim_evidence_execution_report_sha256": evidence_execution_report.get("report_sha256") or "",
        "output_hashes": list(evidence_execution_report.get("output_hashes") or []),
        "academic_claim_agent_finalization_ready": bool(academic_packet.get("automated_claim_finalization_ready")),
        "formal_verifier_used": bool(academic_packet.get("formal_verifier_used")),
        "formal_verifier_adapter_ready": bool(academic_packet.get("formal_verifier_adapter_ready")),
        "local_proof_obligation_checker_used": bool(academic_packet.get("local_proof_obligation_checker_used")),
        "experiment_reproducibility_checker_used": bool(academic_packet.get("experiment_reproducibility_checker_used")),
        "experiment_evidence_maturity": academic_packet.get("experiment_evidence_maturity") or "",
        "experiment_paper_constant_finalization_state": academic_packet.get("experiment_paper_constant_finalization_state") or "",
        "experiment_promotion_eligible": bool(academic_packet.get("experiment_promotion_eligible")),
        "experiment_named_input_promotion_allowed": bool(academic_packet.get("experiment_named_input_promotion_allowed")),
        "experiment_final_signature_present": bool(academic_packet.get("experiment_final_signature_present")),
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "quality_check_count": len(checks),
            "quality_issue_count": len(issue_names),
            "output_hash_count": len(evidence_execution_report.get("output_hashes") or []),
            "academic_claim_agent_finalization_ready_count": 1 if academic_packet.get("automated_claim_finalization_ready") else 0,
            "formal_verifier_used_count": 1 if academic_packet.get("formal_verifier_used") else 0,
            "formal_verifier_adapter_ready_count": 1 if academic_packet.get("formal_verifier_adapter_ready") else 0,
            "formal_verifier_adapter_available_certificate_kind_count": len(academic_packet.get("formal_verifier_adapter_available_certificate_kinds") or []),
            "local_proof_obligation_checker_used_count": 1 if academic_packet.get("local_proof_obligation_checker_used") else 0,
            "experiment_reproducibility_checker_used_count": 1 if academic_packet.get("experiment_reproducibility_checker_used") else 0,
            "experiment_nonpromotional_candidate_count": 1 if academic_packet.get("experiment_evidence_maturity") == "local_smoke_candidate" else 0,
            "experiment_promotion_eligible_count": 1 if academic_packet.get("experiment_promotion_eligible") else 0,
            "experiment_named_input_promotion_allowed_count": 1 if academic_packet.get("experiment_named_input_promotion_allowed") else 0,
            "experiment_final_signature_present_count": 1 if academic_packet.get("experiment_final_signature_present") else 0,
            "claim_evidence_quality_gate_ready_count": 1 if ready else 0,
            "source_mutation_count": 0,
            "external_action_performed_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": validation_issues,
        "quality_checks": checks,
        "quality_packet": quality_packet,
        "academic_claim_finalization_packet": academic_packet,
        "selected_claim_packet": packet,
        "boundary": [
            "This command checks local proof/experiment evidence quality before manuscript materialization.",
            "It reads only the recorded local research-compute workspace outputs and report metadata.",
            "It requires an automated local finalization/checker artifact before the claim can feed source materialization; local proof-obligation checks are not represented as formal theorem-prover certificates.",
            "It performs no compute execution, source/package/archive mutation, provider/model call, secret read, patch queue mutation, merge, commit, upload, email, or external submission.",
        ],
    }


def research_compute_claim_evidence_quality_gate_markdown(report):
    lines = [
        "# paper_factory Claim Evidence Quality Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_evidence_quality_gate_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Claim kind: `{report.get('selected_claim_kind') or ''}`",
        f"- Workspace: `{report.get('workspace_dir') or ''}`",
        f"- Ready for manuscript patch materialization: {report.get('ready_for_manuscript_patch_materialization')}",
        f"- Academic claim agent finalization ready: {report.get('academic_claim_agent_finalization_ready')}",
        f"- Formal verifier used: {report.get('formal_verifier_used')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Quality Checks", ""])
    for item in report.get("quality_checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
