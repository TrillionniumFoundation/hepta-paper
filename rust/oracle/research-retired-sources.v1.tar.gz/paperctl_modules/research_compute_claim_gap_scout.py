"""Scout active claim-gap inputs when the live queue is idle."""

import pathlib
import re

from paperctl_modules import research_compute_capability_matrix
from paperctl_modules import research_compute_gap_mapper


COMMAND = "research-compute-claim-gap-scout"
READY_STATE = "RESEARCH_COMPUTE_CLAIM_GAP_SCOUT_READY"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_GAP_SCOUT_IDLE_NO_CANDIDATE"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_GAP_SCOUT_ATTENTION"
CLAIM_BOUNDARY_TEXT = "Research compute claim boundary"
PREFERRED_CLAIM_KIND_TO_DOMAIN = {
    "theorem_or_proof": "theorem_proof",
    "theorem": "theorem_proof",
    "proof": "theorem_proof",
    "experiment": "experiment_evidence",
}

SOURCE_LOCATOR_RE = re.compile(r"^(?P<path>[^:]+?)(?::(?P<line>.*))?$")


def _source_path(source_locator):
    text = str(source_locator or "").strip()
    match = SOURCE_LOCATOR_RE.match(text)
    return (match.group("path") if match else text).strip()


def _normalized_source_locator(source_locator):
    text = str(source_locator or "").strip()
    match = SOURCE_LOCATOR_RE.match(text)
    if not match:
        return text
    path = (match.group("path") or "").strip()
    line_text = (match.group("line") or "").strip()
    line_match = re.search(r"\d+", line_text)
    return f"{path}:{line_match.group(0)}" if path and line_match else path


def _file_exists(root, source_locator):
    path_text = _source_path(source_locator)
    if not path_text:
        return False
    path = pathlib.Path(path_text)
    if not path.is_absolute():
        path = pathlib.Path(root or ".") / path
    return path.exists() and path.is_file()


def _source_text(root, source_locator):
    path_text = _source_path(source_locator)
    if not path_text:
        return ""
    path = pathlib.Path(path_text)
    if not path.is_absolute():
        path = pathlib.Path(root or ".") / path
    if not (path.exists() and path.is_file()):
        return ""
    try:
        return path.read_text(errors="replace")
    except OSError:
        return ""


def _source_already_has_claim_boundary(root, source_locator):
    return CLAIM_BOUNDARY_TEXT in _source_text(root, source_locator)


def _normalized_preferred_claim_kind(preferred_claim_kind):
    value = str(preferred_claim_kind or "").strip().lower().replace("-", "_")
    if value in {"", "any", "auto"}:
        return ""
    if value in {"theorem", "proof"}:
        return "theorem_or_proof"
    if value in {"theorem_or_proof", "experiment"}:
        return value
    return ""


def _candidate_score(request, root=None):
    domain = research_compute_capability_matrix.domain_for_request(request)
    gap_kind = research_compute_gap_mapper.gap_kind_for_request(request)
    status = str(request.get("status") or "")
    if domain not in {"theorem_proof", "experiment_evidence"}:
        return -1
    if _source_already_has_claim_boundary(root, request.get("source_locator") or ""):
        return -1
    score = 0
    if status == "closed":
        score += 10
    if gap_kind == "proof":
        score += 8
    elif gap_kind in {"experiment", "reproducibility"}:
        score += 7
    if _file_exists(root, request.get("source_locator") or ""):
        score += 5
    if request.get("verification"):
        score += 2
    return score


def _coverage_selected_claim_kind(candidates):
    theorem_count = sum(1 for item in candidates if item.get("_domain") == "theorem_proof")
    experiment_count = sum(1 for item in candidates if item.get("_domain") == "experiment_evidence")
    if not theorem_count and not experiment_count:
        return ""
    if experiment_count > theorem_count:
        return "experiment"
    if theorem_count > experiment_count:
        return "theorem_or_proof"
    return ""


def _scouted_request(request, index=0):
    original_id = request.get("request_id")
    gap_kind = research_compute_gap_mapper.gap_kind_for_request(request)
    domain = research_compute_capability_matrix.domain_for_request(request)
    risk_class = request.get("risk_class") or ""
    if domain == "theorem_proof":
        risk_class = "theory-boundary"
        claim_lane_text = "theorem/proof"
    elif domain == "experiment_evidence":
        risk_class = "experiment"
        claim_lane_text = "experiment"
    else:
        claim_lane_text = "evidence"
    request_id = 900000000 + int(original_id or index or 0)
    request_key = f"agent-scout-{original_id or index or 'unknown'}"
    return {
        "request_id": request_id,
        "request_key": request_key,
        "slug": request.get("slug") or "",
        "status": "requested",
        "risk_class": risk_class,
        "objection": (
            f"Agent-scouted {domain} {gap_kind} gap from closed referee request "
            f"{original_id or ''}: {request.get('objection') or ''}"
        ).strip(),
        "source_locator": _normalized_source_locator(request.get("source_locator") or ""),
        "evidence_locator": request.get("evidence_locator") or "",
        "proposed_fix": (
            f"Draft a bounded full-autonomy {claim_lane_text} claim with "
            f"machine-checkable obligations. Source request fix: {request.get('proposed_fix') or ''}"
        ).strip(),
        "evidence_needed": (
            "Agent-selected local evidence command material, output hashes, and proof/experiment "
            f"obligation trace. Prior request evidence: {request.get('evidence_needed') or ''}"
        ).strip(),
        "verification": (
            "Run claim-draft, evidence gate, source apply readiness, post-apply verify, and lifecycle "
            f"orchestrator before any final academic claim. Prior verification: {request.get('verification') or ''}"
        ).strip(),
        "patch_scope": request.get("patch_scope") or "claim-boundary",
        "agent_scouted": True,
        "original_request_id": original_id,
        "original_request_status": request.get("status") or "",
        "original_risk_class": request.get("risk_class") or "",
        "original_gap_kind": gap_kind,
        "original_domain": domain,
    }


def research_compute_claim_gap_scout(requests=None, root=None, limit=1, label="", preferred_claim_kind=""):
    requests = list(requests or [])
    preferred_claim_kind = _normalized_preferred_claim_kind(preferred_claim_kind)
    candidates = []
    already_landed = []
    for request in requests:
        source_has_boundary = _source_already_has_claim_boundary(root, request.get("source_locator") or "")
        if source_has_boundary:
            item = dict(request)
            item["_source_target_exists"] = _file_exists(root, request.get("source_locator") or "")
            item["_source_already_has_claim_boundary"] = True
            item["_gap_kind"] = research_compute_gap_mapper.gap_kind_for_request(request)
            item["_domain"] = research_compute_capability_matrix.domain_for_request(request)
            if item["_domain"] in {"theorem_proof", "experiment_evidence"}:
                already_landed.append(item)
            continue
        score = _candidate_score(request, root=root)
        if score >= 0:
            item = dict(request)
            item["_agent_scout_score"] = score
            item["_source_target_exists"] = _file_exists(root, request.get("source_locator") or "")
            item["_source_already_has_claim_boundary"] = False
            item["_gap_kind"] = research_compute_gap_mapper.gap_kind_for_request(request)
            item["_domain"] = research_compute_capability_matrix.domain_for_request(request)
            candidates.append(item)
    agent_selected_claim_kind = preferred_claim_kind or _coverage_selected_claim_kind(candidates)
    selected_domain = PREFERRED_CLAIM_KIND_TO_DOMAIN.get(agent_selected_claim_kind or "")
    if selected_domain:
        for item in candidates:
            if item.get("_domain") == selected_domain:
                item["_agent_scout_score"] = int(item.get("_agent_scout_score") or 0) + 100
    candidates.sort(
        key=lambda item: (
            item.get("_agent_scout_score", 0),
            int(item.get("request_id") or 0),
        ),
        reverse=True,
    )
    selected = candidates[: max(0, int(limit or 1))]
    scouted = [_scouted_request(item, index=i + 1) for i, item in enumerate(selected)]
    preferred_domain = PREFERRED_CLAIM_KIND_TO_DOMAIN.get(preferred_claim_kind or "")
    preferred_candidate_count = sum(1 for item in candidates if item.get("_domain") == preferred_domain) if preferred_domain else 0
    preferred_selected_count = sum(1 for item in selected if item.get("_domain") == preferred_domain) if preferred_domain else 0
    selected_candidate_count = sum(1 for item in candidates if item.get("_domain") == selected_domain) if selected_domain else 0
    selected_selected_count = sum(1 for item in selected if item.get("_domain") == selected_domain) if selected_domain else 0
    status = "PASS"
    state = READY_STATE if scouted else IDLE_STATE
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_gap_scout_state": state,
        "preferred_claim_kind": preferred_claim_kind,
        "preferred_claim_kind_satisfied": bool(not preferred_claim_kind or preferred_selected_count),
        "agent_selected_claim_kind": agent_selected_claim_kind,
        "claim_gap_scout_created": True,
        "agent_scout_request_generated": bool(scouted),
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "input_request_count": len(requests),
            "candidate_request_count": len(candidates),
            "already_landed_candidate_count": len(already_landed),
            "scouted_request_count": len(scouted),
            "source_target_exists_count": sum(1 for item in selected if item.get("_source_target_exists")),
            "theorem_proof_candidate_count": sum(1 for item in candidates if item.get("_domain") == "theorem_proof"),
            "experiment_candidate_count": sum(1 for item in candidates if item.get("_domain") == "experiment_evidence"),
            "preferred_claim_kind_candidate_count": preferred_candidate_count,
            "preferred_claim_kind_selected_count": preferred_selected_count,
            "agent_selected_claim_kind_candidate_count": selected_candidate_count,
            "agent_selected_claim_kind_selected_count": selected_selected_count,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "scouted_requests": scouted,
        "selected_source_requests": selected,
        "already_landed_source_requests": already_landed,
        "boundary": [
            "This command creates transient active claim-gap inputs for later claim drafting.",
            "It does not change referee request status, mutate source/package/archive state, call providers/models, read secrets, merge, commit, upload, email, or submit externally.",
            "Requests whose source already contains a research-compute claim boundary are skipped so the idle loop selects unlanded work.",
            "Scouted requests must still pass claim, evidence, source, post-apply, merge, and submission gates before any final academic claim advances.",
        ],
    }


def research_compute_claim_gap_scout_markdown(report):
    lines = [
        "# paper_factory Research Compute Claim Gap Scout",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_gap_scout_state') or ''}",
        f"- Preferred claim kind: {report.get('preferred_claim_kind') or 'any'}",
        f"- Agent selected claim kind: {report.get('agent_selected_claim_kind') or 'any'}",
        f"- Scouted requests: {(report.get('summary') or {}).get('scouted_request_count', 0)}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Requests",
        "",
    ]
    for item in report.get("scouted_requests") or []:
        lines.append(
            f"- `{item.get('request_key')}` `{item.get('slug')}` "
            f"{item.get('risk_class')}: {item.get('source_locator') or ''}"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
