"""Summarize one-key idle claim-loop orchestration results."""


COMMAND = "research-compute-claim-idle-loop-orchestrator"

READY_STATE = "RESEARCH_COMPUTE_CLAIM_IDLE_LOOP_ORCHESTRATOR_READY"
IDLE_NO_CANDIDATE_STATE = "RESEARCH_COMPUTE_CLAIM_IDLE_LOOP_ORCHESTRATOR_IDLE_NO_CANDIDATE"
PLAN_ONLY_STATE = "RESEARCH_COMPUTE_CLAIM_IDLE_LOOP_ORCHESTRATOR_PLAN_ONLY"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_IDLE_LOOP_ORCHESTRATOR_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_CLAIM_IDLE_LOOP_ORCHESTRATOR_FAILED"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_idle_loop_orchestrator_state",
    "report_schema",
    "child_execution_performed",
    "execute_evidence_requested",
    "apply_source_requested",
    "production_candidate_reentry_requested",
    "auto_portal_capability_attestation_requested",
    "external_submission_execution_gate_requested",
    "preferred_claim_kind",
    "agent_selected_claim_kind",
    "executed_claim_kind",
    "autonomy_policy",
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "report_write_performed",
    "db_mutation_performed",
    "next_agent_stage",
    "next_agent_command",
    "next_agent_report_path",
    "executor_task_ready",
    "executor_response_contract_waiting",
    "executor_response_backlog_pending",
    "executor_response_work_item_ready",
    "executor_response_inbox_index_ready",
    "executor_response_inbox_cursor_ready",
    "executor_response_packet_discovery_ready",
    "executor_response_work_item_dispatch_ready",
    "executor_response_waiting_status_ready",
    "executor_response_waiting_escalation_ready",
    "executor_response_waiting_scheduler_ready",
    "executor_response_waiting_redrive_plan_ready",
    "idle_no_candidate",
    "production_candidate_seed_plan_ready",
    "claim_boundary_reentry_draft_ready",
    "claim_boundary_reentry_already_landed_noop",
    "summary",
    "planned_steps",
    "step_results",
    "failed_steps",
    "attention_steps",
    "unresolved_attention_steps",
    "idle_no_candidate_ignored_steps",
    "forbidden_steps",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "planned_step_count",
    "child_step_count",
    "failed_step_count",
    "attention_step_count",
    "unresolved_attention_step_count",
    "external_boundary_step_count",
    "idle_no_candidate_ignored_step_count",
    "production_candidate_seed_count",
    "claim_boundary_reentry_claim_packet_count",
    "claim_boundary_reentry_already_landed_noop_count",
    "source_mutation_step_count",
    "external_submission_executor_task_ready_count",
    "executor_response_contract_waiting_count",
    "executor_response_backlog_pending_count",
    "executor_response_backlog_ready_for_intake_count",
    "executor_response_backlog_ready_for_gate_count",
    "executor_response_work_item_selected_count",
    "executor_response_work_item_ready_count",
    "executor_response_inbox_index_ready_count",
    "executor_response_inbox_index_ready_packet_count",
    "executor_response_inbox_index_duplicate_packet_count",
    "executor_response_inbox_index_consumed_packet_count",
    "executor_response_inbox_cursor_ready_count",
    "executor_response_inbox_cursor_eligible_packet_count",
    "executor_response_inbox_cursor_selected_count",
    "executor_response_inbox_cursor_skipped_consumed_packet_count",
    "executor_response_inbox_cursor_skipped_anchor_mismatch_packet_count",
    "executor_response_packet_discovery_selected_count",
    "executor_response_packet_discovery_matching_count",
    "executor_response_work_item_dispatch_ready_count",
    "executor_response_work_item_dispatch_waiting_count",
    "executor_response_work_item_dispatch_ready_for_contract_count",
    "executor_response_work_item_dispatch_ready_for_intake_count",
    "executor_response_work_item_dispatch_ready_for_gate_count",
    "executor_response_waiting_status_ready_count",
    "executor_response_waiting_status_retry_due_count",
    "executor_response_waiting_status_stale_count",
    "executor_response_waiting_status_waiting_age_minutes",
    "executor_response_waiting_escalation_ready_count",
    "executor_response_waiting_escalation_retry_due_count",
    "executor_response_waiting_escalation_stale_count",
    "executor_response_waiting_escalation_local_retry_scan_count",
    "executor_response_waiting_escalation_waiting_age_minutes",
    "executor_response_waiting_scheduler_ready_count",
    "executor_response_waiting_scheduler_local_redrive_due_count",
    "executor_response_waiting_scheduler_stale_count",
    "executor_response_waiting_scheduler_local_inbox_refresh_count",
    "executor_response_waiting_scheduler_waiting_age_minutes",
    "executor_response_waiting_redrive_plan_ready_count",
    "executor_response_waiting_redrive_plan_local_redrive_due_count",
    "executor_response_waiting_redrive_plan_stale_redrive_planned_count",
    "executor_response_waiting_redrive_plan_local_inbox_refresh_count",
    "executor_response_waiting_redrive_plan_attempt_count",
    "executor_response_contract_ready_count",
    "performed_evidence_intake_ready_count",
    "performed_evidence_recorded_count",
    "terminal_performed_evidence_accepted_count",
    "observed_external_action_evidence_count",
    "auto_portal_capability_attestation_requested",
    "external_submission_execution_gate_requested",
    "preferred_claim_kind_requested",
    "agent_selected_claim_kind",
    "executed_claim_kind",
    "external_action_performed_count",
    "secret_material_read_count",
    "commit_performed_count",
    "forbidden_step_count",
]
REPORT_SCHEMA_NOTES = [
    "Runs the idle claim loop by invoking existing paperctl gates in sequence.",
    "This command adds no new source, merge, commit, secret, or external-action bypass.",
]


FORBIDDEN_PERFORMED_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
    "patch_queue_merge_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
]


def _bool(report, key):
    return bool((report or {}).get(key))


def _int(value):
    try:
        return int(value or 0)
    except Exception:
        return 0


def summarize_step(name, argv, run):
    run = run or {}
    report = run.get("json") or {}
    summary = report.get("summary") or {}
    validation_issue_names = [
        str(issue.get("issue") or "")
        for issue in report.get("validation_issues") or []
        if issue.get("issue")
    ]
    validation_issue_count = max(_int(summary.get("validation_issue_count")), len(validation_issue_names))
    clean_status_pass = bool(report.get("status") == "PASS" and validation_issue_count == 0)
    terminal_ready_count = _int(summary.get("terminal_ready_count"))
    if terminal_ready_count <= 0 and clean_status_pass and report.get("terminal_status_created"):
        terminal_ready_count = 1
    if not clean_status_pass:
        terminal_ready_count = 0
    item = {
        "step": name,
        "argv": list(argv or []),
        "returncode": run.get("returncode"),
        "status": report.get("status") or "",
        "command": report.get("command") or "",
        "state": (
            report.get("claim_gap_scout_state")
            or report.get("claim_draft_state")
            or report.get("production_candidate_seed_plan_state")
            or report.get("claim_boundary_reentry_draft_state")
            or report.get("claim_quality_gate_state")
            or report.get("claim_evidence_execution_state")
            or report.get("claim_evidence_quality_gate_state")
            or report.get("claim_manuscript_patch_materialization_state")
            or report.get("claim_manuscript_source_apply_readiness_state")
            or report.get("claim_manuscript_source_apply_execution_state")
            or report.get("claim_manuscript_source_landing_finalization_state")
            or report.get("claim_manuscript_merge_submission_readiness_state")
            or report.get("claim_manuscript_external_submission_readiness_state")
            or report.get("claim_manuscript_external_submission_execution_preflight_state")
            or report.get("portal_capability_attestation_state")
            or report.get("portal_capability_attestation_intake_state")
            or report.get("claim_manuscript_external_submission_execution_intent_state")
            or report.get("executor_task_state")
            or report.get("executor_response_contract_state")
            or report.get("executor_response_backlog_state")
            or report.get("executor_response_work_item_state")
            or report.get("executor_response_inbox_index_state")
            or report.get("executor_response_inbox_cursor_state")
            or report.get("executor_response_packet_discovery_state")
            or report.get("executor_response_work_item_dispatch_state")
            or report.get("executor_response_waiting_status_state")
            or report.get("executor_response_waiting_escalation_state")
            or report.get("executor_response_waiting_scheduler_state")
            or report.get("executor_response_waiting_redrive_plan_state")
            or report.get("claim_manuscript_external_submission_execution_gate_state")
            or report.get("claim_manuscript_external_submission_execution_terminal_status_state")
            or report.get("claim_manuscript_external_submission_record_only_fixture_harness_state")
            or report.get("handoff_state")
            or report.get("readiness_state")
            or report.get("claim_manuscript_lifecycle_orchestrator_state")
            or ""
        ),
        "report_path": report.get("report_path") or "",
        "report_sha256": report.get("report_sha256") or "",
        "next_agent_stage": report.get("next_agent_stage") or "",
        "next_agent_command": report.get("next_agent_command") or "",
        "agent_selected_claim_kind": report.get("agent_selected_claim_kind") or "",
        "selected_claim_kind": report.get("selected_claim_kind") or "",
        "claim_packet_generated": _bool(report, "claim_packet_generated"),
        "seed_candidate_count": int(summary.get("seed_candidate_count") or 0),
        "claim_packet_count": int(summary.get("claim_packet_count") or 0),
        "source_mutation_performed": _bool(report, "source_mutation_performed")
        or _bool(report, "source_mutation_performed_by_this_command"),
        "external_action_performed": _bool(report, "external_action_performed"),
        "secret_material_read_performed": _bool(report, "secret_material_read_performed"),
        "commit_performed": _bool(report, "commit_performed"),
        "validation_issue_count": validation_issue_count,
        "validation_issue_names": validation_issue_names,
        "pending_executor_response_count": int(
            report.get("pending_executor_response_count")
            or summary.get("pending_executor_response_count")
            or 0
        ),
        "ready_for_intake_count": int(
            report.get("ready_for_intake_count") or summary.get("ready_for_intake_count") or 0
        ),
        "ready_for_gate_count": int(
            report.get("ready_for_gate_count") or summary.get("ready_for_gate_count") or 0
        ),
        "selected_work_item_count": int(
            report.get("selected_work_item_count") or summary.get("selected_work_item_count") or 0
        ),
        "ready_response_packet_count": int(
            report.get("ready_response_packet_count") or summary.get("ready_response_packet_count") or 0
        ),
        "duplicate_response_packet_count": int(
            report.get("duplicate_response_packet_count") or summary.get("duplicate_response_packet_count") or 0
        ),
        "consumed_response_packet_count": int(
            report.get("consumed_response_packet_count") or summary.get("consumed_response_packet_count") or 0
        ),
        "selected_executor_response_packet_count": int(
            report.get("selected_executor_response_packet_count")
            or summary.get("selected_executor_response_packet_count")
            or 0
        ),
        "matching_executor_response_packet_count": int(
            report.get("matching_executor_response_packet_count")
            or summary.get("matching_executor_response_packet_count")
            or 0
        ),
        "eligible_response_packet_count": int(
            report.get("eligible_response_packet_count") or summary.get("eligible_response_packet_count") or 0
        ),
        "skipped_consumed_response_packet_count": int(
            report.get("skipped_consumed_response_packet_count")
            or summary.get("skipped_consumed_response_packet_count")
            or 0
        ),
        "skipped_anchor_mismatch_response_packet_count": int(
            report.get("skipped_anchor_mismatch_response_packet_count")
            or summary.get("skipped_anchor_mismatch_response_packet_count")
            or 0
        ),
        "waiting_for_executor_response_count": int(
            summary.get("waiting_for_executor_response_count") or 0
        ),
        "dispatch_ready_count": int(summary.get("dispatch_ready_count") or 0),
        "ready_for_contract_count": int(summary.get("ready_for_contract_count") or 0),
        "closed_executor_response_count": int(summary.get("closed_executor_response_count") or 0),
        "waiting_status_ready_count": int(summary.get("waiting_status_ready_count") or 0),
        "retry_due_count": int(summary.get("retry_due_count") or 0),
        "stale_waiting_count": int(summary.get("stale_waiting_count") or 0),
        "waiting_age_minutes": int(summary.get("waiting_age_minutes") or report.get("waiting_age_minutes") or 0),
        "waiting_escalation_ready_count": int(summary.get("waiting_escalation_ready_count") or 0),
        "waiting_escalation_retry_due_count": int(summary.get("waiting_escalation_retry_due_count") or 0),
        "waiting_escalation_stale_count": int(summary.get("waiting_escalation_stale_count") or 0),
        "waiting_escalation_local_retry_scan_count": int(summary.get("waiting_escalation_local_retry_scan_count") or 0),
        "waiting_scheduler_ready_count": int(summary.get("waiting_scheduler_ready_count") or 0),
        "waiting_scheduler_local_redrive_due_count": int(
            summary.get("waiting_scheduler_local_redrive_due_count") or 0
        ),
        "waiting_scheduler_stale_count": int(summary.get("waiting_scheduler_stale_count") or 0),
        "waiting_scheduler_local_inbox_refresh_count": int(
            summary.get("waiting_scheduler_local_inbox_refresh_count") or 0
        ),
        "waiting_scheduler_minutes_until_retry": int(summary.get("minutes_until_retry") or 0),
        "waiting_scheduler_minutes_until_stale": int(summary.get("minutes_until_stale") or 0),
        "waiting_redrive_plan_ready_count": int(summary.get("waiting_redrive_plan_ready_count") or 0),
        "waiting_redrive_plan_local_redrive_due_count": int(
            summary.get("waiting_redrive_plan_local_redrive_due_count") or 0
        ),
        "waiting_redrive_plan_stale_redrive_planned_count": int(
            summary.get("waiting_redrive_plan_stale_redrive_planned_count") or 0
        ),
        "waiting_redrive_plan_local_inbox_refresh_count": int(
            summary.get("waiting_redrive_plan_local_inbox_refresh_count") or 0
        ),
        "waiting_redrive_plan_attempt_count": int(summary.get("waiting_redrive_plan_attempt_count") or 0),
        "executor_response_contract_ready_count": int(
            summary.get("executor_response_contract_ready_count")
            or (1 if report.get("executor_response_contract_ready") else 0)
        ),
        "performed_evidence_intake_ready_count": int(
            summary.get("performed_evidence_intake_ready_count")
            or (1 if report.get("performed_evidence_intake_ready") else 0)
        ),
        "performed_evidence_recorded_count": int(
            summary.get("performed_evidence_recorded_count")
            or (1 if report.get("performed_evidence_recorded") else 0)
        ),
        "terminal_ready_count": terminal_ready_count,
        "performed_evidence_recorded": _bool(report, "performed_evidence_recorded"),
        "record_only_fixture": _bool(report, "record_only_fixture"),
        "terminal_status": report.get("terminal_status") or "",
        "stdout_tail": run.get("stdout") or "",
        "error": run.get("error") or "",
    }
    for key in FORBIDDEN_PERFORMED_KEYS:
        item[key] = _bool(report, key)
    return item


def _forbidden_step_keys(step):
    keys = []
    for key in FORBIDDEN_PERFORMED_KEYS:
        if not step.get(key):
            continue
        if key == "external_action_performed" and _external_action_is_observed_evidence(step):
            continue
        keys.append(key)
    return keys


def _step_has_validation_issue(step):
    return bool(
        _int((step or {}).get("validation_issue_count")) > 0
        or (step or {}).get("validation_issue_names")
    )


def _external_action_is_observed_evidence(step):
    state = step.get("state") or ""
    return bool(
        step
        and step.get("returncode") in (0, None)
        and step.get("status") == "PASS"
        and not step.get("error")
        and not _step_has_validation_issue(step)
        and (
            (
                state == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
                and step.get("performed_evidence_recorded")
                and not step.get("record_only_fixture")
            )
            or (
                state == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_PERFORMED_EVIDENCE_ACCEPTED"
                and step.get("terminal_status") == "PERFORMED_EVIDENCE_ACCEPTED"
                and not step.get("record_only_fixture")
            )
        )
    )


def _latest_step(step_results, name):
    return next((step for step in reversed(step_results) if step.get("step") == name), {})


def _step_passed(step):
    return bool(
        step
        and step.get("returncode") in (0, None)
        and step.get("status") == "PASS"
        and not step.get("error")
        and not _step_has_validation_issue(step)
    )


def _lifecycle_waiting_for_external_authorization(step_results):
    lifecycle = _latest_step(step_results, "lifecycle_orchestrator")
    return bool(
        _step_passed(lifecycle)
        and lifecycle.get("state")
        == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_LIFECYCLE_WAITING_FOR_NEXT_GATE"
        and lifecycle.get("next_agent_stage") == "external_submission_readiness_capstone"
    )


def _attention_resolved(step, step_results):
    name = step.get("step") or ""
    if _lifecycle_waiting_for_external_authorization(step_results) and name in {
        "claim_evidence_quality_gate",
        "patch_materialization",
        "source_apply_readiness",
        "source_apply_execution",
        "source_landing_finalization",
        "merge_submission_readiness",
        "external_submission_readiness",
        "external_submission_execution_preflight",
        "portal_capability_attestation",
        "portal_capability_attestation_intake",
        "portal_capability_attestation_ready",
        "external_submission_execution_preflight_ready",
        "external_submission_execution_intent",
        "external_submission_execution_record_only_fixture_harness",
        "external_submission_execution_gate",
        "external_submission_execution_terminal_status",
        "external_submission_execution_executor_task",
        "external_submission_execution_executor_response_contract",
    }:
        return True
    if _already_landed_noop(step_results) and name in {
        "source_apply_readiness",
        "source_apply_execution",
        "source_landing_finalization",
        "merge_submission_readiness",
        "external_submission_readiness",
        "external_submission_execution_preflight",
        "portal_capability_attestation",
        "portal_capability_attestation_intake",
        "portal_capability_attestation_ready",
        "external_submission_execution_preflight_ready",
        "external_submission_execution_intent",
        "external_submission_execution_record_only_fixture_harness",
        "external_submission_execution_gate",
        "external_submission_execution_terminal_status",
        "external_submission_execution_executor_task",
        "external_submission_execution_executor_response_contract",
    }:
        return True
    if name == "external_submission_execution_preflight":
        return _step_passed(_latest_step(step_results, "external_submission_execution_preflight_ready"))
    if name == "portal_capability_attestation":
        return _step_passed(_latest_step(step_results, "portal_capability_attestation_ready"))
    if name == "external_submission_execution_gate":
        latest_gate = _latest_step(step_results, "external_submission_execution_gate")
        return latest_gate is not step and _step_passed(latest_gate)
    if name == "external_submission_execution_terminal_status":
        latest_terminal = _latest_step(step_results, "external_submission_execution_terminal_status")
        return latest_terminal is not step and _step_passed(latest_terminal)
    return False


def _already_landed_noop(step_results):
    reentry_step = _latest_step(step_results, "claim_boundary_reentry_draft")
    source_readiness = _latest_step(step_results, "source_apply_readiness")
    issue_names = set(source_readiness.get("validation_issue_names") or [])
    return bool(
        reentry_step
        and reentry_step.get("status") == "PASS"
        and int(reentry_step.get("claim_packet_count") or 0) > 0
        and "patch_text_already_present_in_source" in issue_names
    )


def research_compute_claim_idle_loop_orchestrator_report(
    label="",
    planned_steps=None,
    step_results=None,
    child_execution_performed=False,
    execute_evidence=False,
    apply_source=False,
    auto_portal_capability_attestation=False,
    execution_gate_requested=False,
    preferred_claim_kind="",
    autonomy_policy=None,
):
    planned_steps = list(planned_steps or [])
    step_results = list(step_results or [])
    scout_step = _latest_step(step_results, "claim_gap_scout")
    draft_step = _latest_step(step_results, "claim_draft")
    seed_plan_step = _latest_step(step_results, "production_candidate_seed_plan")
    reentry_step = _latest_step(step_results, "claim_boundary_reentry_draft")
    reentry_ready = bool(
        reentry_step
        and _step_passed(reentry_step)
        and reentry_step.get("state") == "RESEARCH_COMPUTE_CLAIM_BOUNDARY_REENTRY_DRAFT_READY"
        and int(reentry_step.get("claim_packet_count") or 0) > 0
    )
    idle_no_candidate = bool(
        child_execution_performed
        and not reentry_ready
        and (
            (
                _step_passed(scout_step)
                and scout_step.get("state") == "RESEARCH_COMPUTE_CLAIM_GAP_SCOUT_IDLE_NO_CANDIDATE"
            )
            or (
                _step_passed(draft_step)
                and draft_step.get("state") == "CLAIM_DRAFT_IDLE_NO_ACTIVE_COMPUTE_GAPS"
            )
        )
    )
    idle_no_candidate_ignored_steps = [
        step
        for step in step_results
        if idle_no_candidate
        and step.get("step")
        not in {
            "claim_gap_scout",
            "claim_draft",
            "production_candidate_seed_plan",
            "claim_boundary_reentry_draft",
            "external_submission_execution_executor_response_backlog",
            "external_submission_execution_executor_response_work_item",
            "external_submission_execution_executor_response_inbox_index",
            "external_submission_execution_executor_response_inbox_cursor",
            "external_submission_execution_executor_response_packet_discovery",
            "external_submission_execution_executor_response_contract_redrive",
            "external_submission_execution_performed_evidence_intake_redrive",
            "external_submission_execution_gate_redrive",
            "external_submission_execution_terminal_status_redrive",
            "external_submission_execution_executor_response_work_item_dispatch",
            "external_submission_execution_executor_response_waiting_status",
            "external_submission_execution_executor_response_waiting_escalation",
            "external_submission_execution_executor_response_waiting_scheduler",
            "external_submission_execution_executor_response_waiting_redrive_plan",
        }
    ]
    effective_step_results = [
        step for step in step_results if step not in idle_no_candidate_ignored_steps
    ]
    failed_steps = [
        step
        for step in effective_step_results
        if step.get("returncode") not in (0, None)
        or step.get("error")
        or step.get("status") == "FAIL"
    ]
    attention_steps = [
        step
        for step in effective_step_results
        if step.get("status") == "ATTENTION" or _step_has_validation_issue(step)
    ]
    unresolved_attention_steps = [
        step for step in attention_steps if not _attention_resolved(step, step_results)
    ]
    forbidden_steps = [
        {"step": step.get("step") or "", "forbidden_keys": _forbidden_step_keys(step)}
        for step in effective_step_results
        if _forbidden_step_keys(step)
    ]
    external_boundary_steps = [
        step
        for step in step_results
        if step.get("step")
        in {
            "external_submission_execution_preflight",
            "portal_capability_attestation",
            "portal_capability_attestation_intake",
            "external_submission_handoff_bundle_pre_capability",
            "portal_capability_attestation_ready",
            "external_submission_execution_preflight_ready",
            "external_submission_execution_intent",
            "external_submission_execution_record_only_fixture_harness",
            "external_submission_execution_executor_task",
            "external_submission_execution_executor_response_contract",
            "external_submission_execution_executor_response_backlog",
            "external_submission_execution_executor_response_work_item",
            "external_submission_execution_executor_response_inbox_index",
            "external_submission_execution_executor_response_inbox_cursor",
            "external_submission_execution_executor_response_packet_discovery",
            "external_submission_execution_executor_response_contract_redrive",
            "external_submission_execution_performed_evidence_intake_redrive",
            "external_submission_execution_gate_redrive",
            "external_submission_execution_terminal_status_redrive",
            "external_submission_execution_executor_response_work_item_dispatch",
            "external_submission_execution_executor_response_waiting_status",
            "external_submission_execution_executor_response_waiting_escalation",
            "external_submission_execution_executor_response_waiting_scheduler",
            "external_submission_execution_executor_response_waiting_redrive_plan",
            "external_submission_execution_gate",
            "external_submission_execution_terminal_status",
            "external_submission_handoff_bundle",
            "external_submission_readiness_capstone",
            "lifecycle_orchestrator",
        }
    ]
    lifecycle = next(
        (step for step in reversed(step_results) if step.get("step") == "lifecycle_orchestrator"),
        {},
    )
    backlog = _latest_step(step_results, "external_submission_execution_executor_response_backlog")
    work_item = _latest_step(step_results, "external_submission_execution_executor_response_work_item")
    inbox_index = _latest_step(step_results, "external_submission_execution_executor_response_inbox_index")
    inbox_cursor = _latest_step(step_results, "external_submission_execution_executor_response_inbox_cursor")
    discovery = _latest_step(step_results, "external_submission_execution_executor_response_packet_discovery")
    dispatch = _latest_step(step_results, "external_submission_execution_executor_response_work_item_dispatch")
    waiting_status = _latest_step(step_results, "external_submission_execution_executor_response_waiting_status")
    waiting_escalation = _latest_step(step_results, "external_submission_execution_executor_response_waiting_escalation")
    waiting_scheduler = _latest_step(step_results, "external_submission_execution_executor_response_waiting_scheduler")
    waiting_redrive_plan = _latest_step(step_results, "external_submission_execution_executor_response_waiting_redrive_plan")
    waiting_redrive_plan_clean = _step_passed(waiting_redrive_plan)
    waiting_scheduler_clean = _step_passed(waiting_scheduler)
    waiting_escalation_clean = _step_passed(waiting_escalation)
    waiting_status_clean = _step_passed(waiting_status)
    dispatch_clean = _step_passed(dispatch)
    work_item_clean = _step_passed(work_item)
    backlog_clean = _step_passed(backlog)
    waiting_redrive_plan_next_stage = waiting_redrive_plan.get("next_agent_stage") if waiting_redrive_plan_clean else ""
    waiting_scheduler_next_stage = waiting_scheduler.get("next_agent_stage") if waiting_scheduler_clean else ""
    waiting_escalation_next_stage = waiting_escalation.get("next_agent_stage") if waiting_escalation_clean else ""
    waiting_status_next_stage = waiting_status.get("next_agent_stage") if waiting_status_clean else ""
    dispatch_next_stage = dispatch.get("next_agent_stage") if dispatch_clean else ""
    work_item_next_stage = work_item.get("next_agent_stage") if work_item_clean else ""
    backlog_next_stage = backlog.get("next_agent_stage") if backlog_clean else ""
    dispatch_closed = bool(dispatch_clean and int(dispatch.get("closed_executor_response_count") or 0) > 0)
    if idle_no_candidate and waiting_redrive_plan_next_stage and waiting_redrive_plan_next_stage != "claim_draft":
        next_agent_stage = waiting_redrive_plan_next_stage
        next_agent_command = waiting_redrive_plan.get("next_agent_command") or ""
        next_agent_report_path = waiting_redrive_plan.get("report_path") or ""
    elif idle_no_candidate and waiting_scheduler_next_stage and waiting_scheduler_next_stage != "claim_draft":
        next_agent_stage = waiting_scheduler_next_stage
        next_agent_command = waiting_scheduler.get("next_agent_command") or ""
        next_agent_report_path = waiting_scheduler.get("report_path") or ""
    elif idle_no_candidate and waiting_escalation_next_stage and waiting_escalation_next_stage != "claim_draft":
        next_agent_stage = waiting_escalation_next_stage
        next_agent_command = waiting_escalation.get("next_agent_command") or ""
        next_agent_report_path = waiting_escalation.get("report_path") or ""
    elif idle_no_candidate and waiting_status_next_stage and waiting_status_next_stage != "claim_draft":
        next_agent_stage = waiting_status_next_stage
        next_agent_command = waiting_status.get("next_agent_command") or ""
        next_agent_report_path = waiting_status.get("report_path") or ""
    elif idle_no_candidate and dispatch_closed:
        next_agent_stage = dispatch_next_stage or "claim_draft"
        next_agent_command = dispatch.get("next_agent_command") or ""
        next_agent_report_path = dispatch.get("report_path") or ""
    elif idle_no_candidate and dispatch_next_stage and dispatch_next_stage != "claim_draft":
        next_agent_stage = dispatch_next_stage
        next_agent_command = dispatch.get("next_agent_command") or ""
        next_agent_report_path = dispatch.get("report_path") or ""
    elif idle_no_candidate and work_item_next_stage and work_item_next_stage != "claim_draft":
        next_agent_stage = work_item_next_stage
        next_agent_command = work_item.get("next_agent_command") or ""
        next_agent_report_path = work_item.get("report_path") or ""
    elif idle_no_candidate and backlog_next_stage and backlog_next_stage != "claim_draft":
        next_agent_stage = backlog_next_stage
        next_agent_command = backlog.get("next_agent_command") or ""
        next_agent_report_path = backlog.get("report_path") or ""
    elif idle_no_candidate:
        next_agent_stage = "idle_no_candidate"
        next_agent_command = ""
        next_agent_report_path = ""
    else:
        next_agent_stage = lifecycle.get("next_agent_stage") or ""
        next_agent_command = lifecycle.get("next_agent_command") or ""
        next_agent_report_path = lifecycle.get("report_path") or ""
    evidence_step = _latest_step(step_results, "claim_evidence_execution")
    already_landed_noop = _already_landed_noop(step_results)
    if forbidden_steps:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif failed_steps:
        status = "FAIL"
        state = FAILED_STATE
    elif idle_no_candidate:
        status = "PASS"
        state = IDLE_NO_CANDIDATE_STATE
    elif not child_execution_performed:
        status = "PASS"
        state = PLAN_ONLY_STATE
    elif unresolved_attention_steps:
        status = "PASS"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    source_mutation_steps = [
        step for step in step_results if step.get("source_mutation_performed")
    ]
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_idle_loop_orchestrator_state": state,
        "child_execution_performed": bool(child_execution_performed),
        "execute_evidence_requested": bool(execute_evidence),
        "apply_source_requested": bool(apply_source),
        "production_candidate_reentry_requested": bool(seed_plan_step or reentry_step),
        "auto_portal_capability_attestation_requested": bool(auto_portal_capability_attestation),
        "external_submission_execution_gate_requested": bool(execution_gate_requested),
        "preferred_claim_kind": str(preferred_claim_kind or ""),
        "agent_selected_claim_kind": scout_step.get("agent_selected_claim_kind") or reentry_step.get("selected_claim_kind") or "",
        "executed_claim_kind": evidence_step.get("selected_claim_kind") or "",
        "autonomy_policy": autonomy_policy or {},
        "source_mutation_performed": bool(source_mutation_steps),
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "next_agent_report_path": next_agent_report_path,
        "idle_no_candidate": idle_no_candidate,
        "production_candidate_seed_plan_ready": bool(
            seed_plan_step
            and _step_passed(seed_plan_step)
            and int(seed_plan_step.get("seed_candidate_count") or 0) > 0
        ),
        "claim_boundary_reentry_draft_ready": bool(reentry_ready),
        "claim_boundary_reentry_already_landed_noop": bool(already_landed_noop),
        "executor_task_ready": bool(
            any(
                step.get("step") == "external_submission_execution_executor_task" and _step_passed(step)
                for step in step_results
            )
        ),
        "executor_response_contract_waiting": bool(
            any(
                step.get("step") == "external_submission_execution_executor_response_contract"
                and _step_passed(step)
                and step.get("state")
                == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_WAITING_FOR_EXECUTOR_RESPONSE"
                for step in step_results
            )
        ),
        "executor_response_backlog_pending": bool(
            backlog_clean and int(backlog.get("pending_executor_response_count") or 0) > 0
        ),
        "executor_response_work_item_ready": bool(
            work_item_clean
            and int(work_item.get("selected_work_item_count") or 0) > 0
        ),
        "executor_response_inbox_index_ready": bool(
            _step_passed(inbox_index)
        ),
        "executor_response_inbox_cursor_ready": bool(
            _step_passed(inbox_cursor)
        ),
        "executor_response_packet_discovery_ready": bool(
            _step_passed(discovery)
            and int(discovery.get("selected_executor_response_packet_count") or 0) > 0
        ),
        "executor_response_work_item_dispatch_ready": bool(
            dispatch_clean
            and int(dispatch.get("dispatch_ready_count") or 0) > 0
        ),
        "executor_response_waiting_status_ready": bool(
            waiting_status_clean
            and int(waiting_status.get("waiting_status_ready_count") or 0) > 0
        ),
        "executor_response_waiting_escalation_ready": bool(
            waiting_escalation_clean
            and int(waiting_escalation.get("waiting_escalation_ready_count") or 0) > 0
        ),
        "executor_response_waiting_scheduler_ready": bool(
            waiting_scheduler_clean
            and int(waiting_scheduler.get("waiting_scheduler_ready_count") or 0) > 0
        ),
        "executor_response_waiting_redrive_plan_ready": bool(
            waiting_redrive_plan_clean
            and int(waiting_redrive_plan.get("waiting_redrive_plan_ready_count") or 0) > 0
        ),
        "summary": {
            "planned_step_count": len(planned_steps),
            "child_step_count": len(step_results),
            "failed_step_count": len(failed_steps),
            "attention_step_count": len(attention_steps),
            "unresolved_attention_step_count": len(unresolved_attention_steps),
            "external_boundary_step_count": len(external_boundary_steps),
            "idle_no_candidate_ignored_step_count": len(idle_no_candidate_ignored_steps),
            "production_candidate_seed_count": int(seed_plan_step.get("seed_candidate_count") or 0),
            "claim_boundary_reentry_claim_packet_count": int(reentry_step.get("claim_packet_count") or 0),
            "claim_boundary_reentry_already_landed_noop_count": 1 if already_landed_noop else 0,
            "source_mutation_step_count": len(source_mutation_steps),
            "external_submission_executor_task_ready_count": sum(
                1 for step in step_results
                if step.get("step") == "external_submission_execution_executor_task" and _step_passed(step)
            ),
            "executor_response_contract_waiting_count": sum(
                1 for step in step_results
                if step.get("step") == "external_submission_execution_executor_response_contract"
                and _step_passed(step)
                and step.get("state") == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_WAITING_FOR_EXECUTOR_RESPONSE"
            ),
            "executor_response_backlog_pending_count": int(backlog.get("pending_executor_response_count") or 0)
            if backlog_clean else 0,
            "executor_response_backlog_ready_for_intake_count": int(backlog.get("ready_for_intake_count") or 0)
            if backlog_clean else 0,
            "executor_response_backlog_ready_for_gate_count": int(backlog.get("ready_for_gate_count") or 0)
            if backlog_clean else 0,
            "executor_response_work_item_selected_count": int(work_item.get("selected_work_item_count") or 0)
            if work_item_clean else 0,
            "executor_response_work_item_ready_count": (
                1
                if work_item_clean and int(work_item.get("selected_work_item_count") or 0) > 0
                else 0
            ),
            "executor_response_inbox_index_ready_count": (
                1 if _step_passed(inbox_index) else 0
            ),
            "executor_response_inbox_index_ready_packet_count": int(
                inbox_index.get("ready_response_packet_count") or 0
            ) if _step_passed(inbox_index) else 0,
            "executor_response_inbox_index_duplicate_packet_count": int(
                inbox_index.get("duplicate_response_packet_count") or 0
            ) if _step_passed(inbox_index) else 0,
            "executor_response_inbox_index_consumed_packet_count": int(
                inbox_index.get("consumed_response_packet_count") or 0
            ) if _step_passed(inbox_index) else 0,
            "executor_response_inbox_cursor_ready_count": (
                1 if _step_passed(inbox_cursor) else 0
            ),
            "executor_response_inbox_cursor_eligible_packet_count": int(
                inbox_cursor.get("eligible_response_packet_count") or 0
            ) if _step_passed(inbox_cursor) else 0,
            "executor_response_inbox_cursor_selected_count": int(
                inbox_cursor.get("selected_executor_response_packet_count") or 0
            ) if _step_passed(inbox_cursor) else 0,
            "executor_response_inbox_cursor_skipped_consumed_packet_count": int(
                inbox_cursor.get("skipped_consumed_response_packet_count") or 0
            ) if _step_passed(inbox_cursor) else 0,
            "executor_response_inbox_cursor_skipped_anchor_mismatch_packet_count": int(
                inbox_cursor.get("skipped_anchor_mismatch_response_packet_count") or 0
            ) if _step_passed(inbox_cursor) else 0,
            "executor_response_packet_discovery_selected_count": int(
                discovery.get("selected_executor_response_packet_count") or 0
            ) if _step_passed(discovery) else 0,
            "executor_response_packet_discovery_matching_count": int(
                discovery.get("matching_executor_response_packet_count") or 0
            ) if _step_passed(discovery) else 0,
            "executor_response_work_item_dispatch_ready_count": (
                int(dispatch.get("dispatch_ready_count") or 0)
            ) if dispatch_clean else 0,
            "executor_response_work_item_dispatch_waiting_count": int(
                dispatch.get("waiting_for_executor_response_count") or 0
            ) if dispatch_clean else 0,
            "executor_response_work_item_dispatch_ready_for_contract_count": int(
                dispatch.get("ready_for_contract_count") or 0
            ) if dispatch_clean else 0,
            "executor_response_work_item_dispatch_ready_for_intake_count": int(
                dispatch.get("ready_for_intake_count") or 0
            ) if dispatch_clean else 0,
            "executor_response_work_item_dispatch_ready_for_gate_count": int(
                dispatch.get("ready_for_gate_count") or 0
            ) if dispatch_clean else 0,
            "executor_response_waiting_status_ready_count": int(
                waiting_status.get("waiting_status_ready_count") or 0
            ) if waiting_status_clean else 0,
            "executor_response_waiting_status_retry_due_count": int(
                waiting_status.get("retry_due_count") or 0
            ) if waiting_status_clean else 0,
            "executor_response_waiting_status_stale_count": int(
                waiting_status.get("stale_waiting_count") or 0
            ) if waiting_status_clean else 0,
            "executor_response_waiting_status_waiting_age_minutes": int(
                waiting_status.get("waiting_age_minutes") or 0
            ) if waiting_status_clean else 0,
            "executor_response_waiting_escalation_ready_count": int(
                waiting_escalation.get("waiting_escalation_ready_count") or 0
            ) if waiting_escalation_clean else 0,
            "executor_response_waiting_escalation_retry_due_count": int(
                waiting_escalation.get("waiting_escalation_retry_due_count") or 0
            ) if waiting_escalation_clean else 0,
            "executor_response_waiting_escalation_stale_count": int(
                waiting_escalation.get("waiting_escalation_stale_count") or 0
            ) if waiting_escalation_clean else 0,
            "executor_response_waiting_escalation_local_retry_scan_count": int(
                waiting_escalation.get("waiting_escalation_local_retry_scan_count") or 0
            ) if waiting_escalation_clean else 0,
            "executor_response_waiting_escalation_waiting_age_minutes": int(
                waiting_escalation.get("waiting_age_minutes") or 0
            ) if waiting_escalation_clean else 0,
            "executor_response_waiting_scheduler_ready_count": int(
                waiting_scheduler.get("waiting_scheduler_ready_count") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_scheduler_local_redrive_due_count": int(
                waiting_scheduler.get("waiting_scheduler_local_redrive_due_count") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_scheduler_stale_count": int(
                waiting_scheduler.get("waiting_scheduler_stale_count") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_scheduler_local_inbox_refresh_count": int(
                waiting_scheduler.get("waiting_scheduler_local_inbox_refresh_count") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_scheduler_waiting_age_minutes": int(
                waiting_scheduler.get("waiting_age_minutes") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_scheduler_minutes_until_retry": int(
                waiting_scheduler.get("waiting_scheduler_minutes_until_retry") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_scheduler_minutes_until_stale": int(
                waiting_scheduler.get("waiting_scheduler_minutes_until_stale") or 0
            ) if waiting_scheduler_clean else 0,
            "executor_response_waiting_redrive_plan_ready_count": int(
                waiting_redrive_plan.get("waiting_redrive_plan_ready_count") or 0
            ) if waiting_redrive_plan_clean else 0,
            "executor_response_waiting_redrive_plan_local_redrive_due_count": int(
                waiting_redrive_plan.get("waiting_redrive_plan_local_redrive_due_count") or 0
            ) if waiting_redrive_plan_clean else 0,
            "executor_response_waiting_redrive_plan_stale_redrive_planned_count": int(
                waiting_redrive_plan.get("waiting_redrive_plan_stale_redrive_planned_count") or 0
            ) if waiting_redrive_plan_clean else 0,
            "executor_response_waiting_redrive_plan_local_inbox_refresh_count": int(
                waiting_redrive_plan.get("waiting_redrive_plan_local_inbox_refresh_count") or 0
            ) if waiting_redrive_plan_clean else 0,
            "executor_response_waiting_redrive_plan_attempt_count": int(
                waiting_redrive_plan.get("waiting_redrive_plan_attempt_count") or 0
            ) if waiting_redrive_plan_clean else 0,
            "executor_response_contract_ready_count": sum(
                int(step.get("executor_response_contract_ready_count") or 0)
                for step in step_results
                if step.get("step")
                in {
                    "external_submission_execution_executor_response_contract",
                    "external_submission_execution_executor_response_contract_redrive",
                }
                and _step_passed(step)
            ),
            "performed_evidence_intake_ready_count": sum(
                int(step.get("performed_evidence_intake_ready_count") or 0)
                for step in step_results
                if step.get("step") == "external_submission_execution_performed_evidence_intake_redrive"
                and _step_passed(step)
            ),
            "performed_evidence_recorded_count": sum(
                int(step.get("performed_evidence_recorded_count") or 0)
                for step in step_results
                if step.get("step") == "external_submission_execution_gate_redrive"
                and _step_passed(step)
            ),
            "terminal_performed_evidence_accepted_count": sum(
                1
                for step in step_results
                if step.get("step") == "external_submission_execution_terminal_status_redrive"
                and _step_passed(step)
                and step.get("terminal_status") == "PERFORMED_EVIDENCE_ACCEPTED"
            ),
            "observed_external_action_evidence_count": sum(
                1 for step in step_results if _external_action_is_observed_evidence(step)
            ),
            "auto_portal_capability_attestation_requested": bool(auto_portal_capability_attestation),
            "external_submission_execution_gate_requested": bool(execution_gate_requested),
            "preferred_claim_kind_requested": str(preferred_claim_kind or ""),
            "agent_selected_claim_kind": scout_step.get("agent_selected_claim_kind") or "",
            "executed_claim_kind": evidence_step.get("selected_claim_kind") or "",
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
            "forbidden_step_count": len(forbidden_steps),
        },
        "planned_steps": planned_steps,
        "step_results": step_results,
        "failed_steps": failed_steps,
        "attention_steps": attention_steps,
        "unresolved_attention_steps": unresolved_attention_steps,
        "idle_no_candidate_ignored_steps": idle_no_candidate_ignored_steps,
        "forbidden_steps": forbidden_steps,
        "boundary": [
            "This command orchestrates existing claim-loop paperctl gates in sequence.",
            "It does not bypass child readiness, source-apply, post-apply verify, merge, or external-submission gates.",
            "When source apply is requested, it routes through the existing rollback and post-apply verification path.",
            "It may write local reports and a local handoff zip through child report commands.",
            "In full-autonomy mode it can fill non-secret portal capability intake fields and advance to execution intent.",
            "External-submission execution still requires a later performed-evidence gate; record-only fixture evidence is not treated as real submission.",
            "It never reads secrets, logs into portals, uploads, emails, final-submits, merges, commits, or mutates release packages.",
        ],
    }
    return report


def research_compute_claim_idle_loop_orchestrator_markdown(report):
    lines = [
        "# paper_factory Claim Idle Loop Orchestrator",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_idle_loop_orchestrator_state') or ''}",
        f"- Child execution performed: {report.get('child_execution_performed')}",
        f"- Auto portal capability attestation: {report.get('auto_portal_capability_attestation_requested')}",
        f"- External execution gate requested: {report.get('external_submission_execution_gate_requested')}",
        f"- Preferred claim kind: {report.get('preferred_claim_kind') or 'any'}",
        f"- Agent selected claim kind: {report.get('agent_selected_claim_kind') or 'any'}",
        f"- Executed claim kind: {report.get('executed_claim_kind') or 'unknown'}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- External action performed: {report.get('external_action_performed')}",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- Next agent command: `{report.get('next_agent_command') or ''}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Steps", ""])
    for step in report.get("step_results") or report.get("planned_steps") or []:
        lines.append(
            f"- `{step.get('step') or ''}` status={step.get('status') or ''} "
            f"state={step.get('state') or ''} report=`{step.get('report_path') or ''}`"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
