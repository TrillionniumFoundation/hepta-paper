"""Local theorem/proof and experiment claim-to-manuscript smoke test.

This module productizes a synthetic, local-only end-to-end check for the
research-compute claim pipeline. It executes local proof/experiment evidence
and source-apply dry-runs, but never mutates production source or performs
external actions.
"""

import datetime as dt
import hashlib
import json
import os
import pathlib
import shutil
import subprocess

from paperctl_modules import agent_autonomy_policy
from paperctl_modules import research_compute_claim_draft
from paperctl_modules import research_compute_claim_evidence_execution
from paperctl_modules import research_compute_claim_evidence_quality_gate
from paperctl_modules import research_compute_claim_manuscript_merge_submission_readiness
from paperctl_modules import research_compute_claim_manuscript_patch_materialization
from paperctl_modules import research_compute_claim_manuscript_source_apply_execution
from paperctl_modules import research_compute_claim_manuscript_source_apply_readiness
from paperctl_modules import research_compute_claim_manuscript_source_landing_finalization
from paperctl_modules import research_compute_claim_quality_gate
from paperctl_modules import research_compute_manuscript_source_apply_gate
from paperctl_modules import research_compute_manuscript_source_post_apply_verify
from paperctl_modules import report_io


COMMAND = "research-compute-claim-local-e2e-smoke"
PASS_STATE = "RESEARCH_COMPUTE_CLAIM_LOCAL_E2E_SMOKE_PASS"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_LOCAL_E2E_SMOKE_ATTENTION"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_local_e2e_smoke_state",
    "report_schema",
    "label",
    "local_only_note",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "isolated_source_apply_requested",
    "claim_draft_report_path",
    "summary",
    "lanes",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "lane_count",
    "pre_merge_pass_lane_count",
    "theorem_lane_count",
    "experiment_lane_count",
    "executed_evidence_lane_count",
    "source_apply_ready_not_executed_count",
    "source_apply_applied_verified_count",
    "experiment_nonpromotional_candidate_count",
    "experiment_promotion_eligible_count",
    "experiment_named_input_promotion_allowed_count",
    "experiment_final_signature_present_count",
    "isolated_source_apply_performed_count",
    "isolated_source_apply_verified_count",
    "source_mutation_performed_count",
    "isolated_source_mutation_performed_count",
    "external_action_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Synthetic theorem/proof and experiment lanes only.",
    "Executes local evidence and source-apply dry-runs by default; optional isolated source apply mutates only per-lane log worktrees.",
    "Never mutates production source or performs external actions.",
]


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _sha256_file(path):
    return report_io.sha256_file(path)


def _rel(root, path):
    return report_io.rel_path(root, path)


def _write_report(root, out_dir, name, report):
    path = pathlib.Path(out_dir) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    report["report_path"] = _rel(root, path)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False))
    report["report_sha256"] = _sha256_file(path)
    path.write_text(json.dumps(report, indent=2, ensure_ascii=False))
    report["report_sha256"] = _sha256_file(path)
    return report


def _write_sidecar(root, out_dir, name, payload):
    path = pathlib.Path(out_dir) / name
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload or {}, indent=2, ensure_ascii=False))
    return {
        "path": _rel(root, path),
        "sha256": _sha256_file(path),
    }


def _source_snapshot(path, text):
    text = str(text or "")
    return {
        "path": path,
        "exists": True,
        "is_file": True,
        "sha256": _sha256_text(text),
        "size_bytes": len(text.encode()),
        "line_count": len(text.splitlines()),
    }


def _snapshot_path(root, path):
    path = pathlib.Path(path)
    exists = path.exists()
    text = path.read_text(errors="ignore") if exists and path.is_file() else ""
    return (
        {
            "path": _rel(root, path) if exists else str(path),
            "exists": exists,
            "is_file": path.is_file() if exists else False,
            "sha256": _sha256_file(path) if exists and path.is_file() else "",
            "size_bytes": path.stat().st_size if exists and path.is_file() else 0,
            "line_count": len(text.splitlines()) if text else 0,
        },
        text,
    )


def _isolated_source_apply(root, out_dir, lane_dir, lane_label, readiness, patch_path, patch_snapshot, patch_text):
    worktree = pathlib.Path(lane_dir) / "worktree"
    source_path = worktree / "paper.tex"
    isolated_git_env = dict(os.environ)
    isolated_git_env["GIT_CEILING_DIRECTORIES"] = str(pathlib.Path(lane_dir).resolve())
    preflight = readiness.get("preflight_report") or {}
    source_before_snapshot, _source_before_text = _snapshot_path(root, source_path)
    rollback_path = pathlib.Path(out_dir) / f"{pathlib.Path(lane_dir).name}-source-before-claim-apply.rollback"
    apply_result = {}
    pre_apply_issues = research_compute_manuscript_source_apply_gate.validate_apply_inputs(
        preflight,
        patch_snapshot,
        source_before_snapshot,
        patch_text,
    )
    if not pre_apply_issues and patch_path.exists() and source_path.exists():
        shutil.copy2(source_path, rollback_path)
        proc = subprocess.run(
            ["git", "apply", str(patch_path.resolve())],
            cwd=worktree,
            env=isolated_git_env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        source_after_snapshot, source_after_text = _snapshot_path(root, source_path)
        expected_boundary_text = research_compute_manuscript_source_apply_gate.expected_boundary_text(preflight)
        apply_result = {
            "performed": True,
            "returncode": proc.returncode,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "source_before_sha256": source_before_snapshot.get("sha256") or "",
            "source_after_sha256": source_after_snapshot.get("sha256") or "",
            "source_after_contains_expected_boundary_text": expected_boundary_text in source_after_text,
            "rollback_snapshot_created": rollback_path.exists(),
            "rollback_snapshot_path": _rel(root, rollback_path) if rollback_path.exists() else "",
            "rollback_snapshot_sha256": _sha256_file(rollback_path) if rollback_path.exists() else "",
        }
    apply_report = research_compute_manuscript_source_apply_gate.research_compute_manuscript_source_apply_gate(
        preflight,
        patch_snapshot,
        source_before_snapshot,
        patch_text,
        apply_requested=True,
        write_requested=True,
        apply_result=apply_result,
        label=lane_label,
    )
    apply_report = _write_report(root, out_dir, f"{pathlib.Path(lane_dir).name}-source-apply-gate-applied.json", apply_report)
    post_apply_report = {}
    if (
        apply_report.get("status") == "PASS"
        and apply_report.get("manuscript_source_apply_gate_state")
        == "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_APPLIED"
    ):
        rollback_snapshot, rollback_text = _snapshot_path(root, rollback_path)
        source_after_snapshot, source_after_text = _snapshot_path(root, source_path)
        patch_snapshot_after, _patch_text_after = _snapshot_path(root, patch_path)
        diff_proc = subprocess.run(
            ["git", "diff", "--check", "--no-index", str(rollback_path), str(source_path)],
            cwd=worktree,
            env=isolated_git_env,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
        )
        post_apply_report = research_compute_manuscript_source_post_apply_verify.research_compute_manuscript_source_post_apply_verify(
            apply_report,
            source_after_snapshot,
            rollback_snapshot,
            patch_snapshot_after,
            source_after_text,
            rollback_text,
            {
                "performed": True,
                "returncode": diff_proc.returncode,
                "passed": diff_proc.returncode in (0, 1) and not diff_proc.stderr,
                "stdout": diff_proc.stdout,
                "stderr": diff_proc.stderr,
            },
            label=lane_label,
        )
        post_apply_report = _write_report(
            root,
            out_dir,
            f"{pathlib.Path(lane_dir).name}-source-post-apply-verify.json",
            post_apply_report,
        )
    execution_applied = research_compute_claim_manuscript_source_apply_execution.research_compute_claim_manuscript_source_apply_execution(
        readiness,
        apply_report=apply_report,
        post_apply_verify_report=post_apply_report,
        apply_requested=True,
        write_requested=True,
        label=lane_label,
    )
    execution_applied = _write_report(
        root,
        out_dir,
        f"{pathlib.Path(lane_dir).name}-claim-source-apply-execution-applied-verified.json",
        execution_applied,
    )
    return apply_report, post_apply_report, execution_applied


def _synthetic_requests():
    return [
        {
            "request_id": 940001,
            "request_key": "p4-theorem",
            "slug": "P4_Local_Theorem_Smoke",
            "status": "requested",
            "risk_class": "theory-boundary",
            "objection": "local fixture asks for a theorem/proof boundary",
            "proposed_fix": "state a profiled estimator consistency lemma with an O(n^{-1/2}) bound",
            "evidence_needed": "proof notes and machine-check placeholder certificate boundary",
            "verification": "lemma checklist and proof-check result",
            "source_locator": "paper.tex:2",
        },
        {
            "request_id": 940002,
            "request_key": "p4-experiment",
            "slug": "P4_Local_Experiment_Smoke",
            "status": "requested",
            "risk_class": "benchmark-boundary",
            "objection": "local fixture asks for a reproducibility experiment",
            "proposed_fix": "run allowlisted local reproducibility smoke with deterministic metrics",
            "evidence_needed": "manifest, metrics, summary, output hashes, and negative-result policy",
            "verification": "reproducible no-network command and metric acceptance checks",
            "source_locator": "paper.tex:2",
        },
        {
            "request_id": 940003,
            "request_key": "p4-dql-experiment",
            "slug": "DQL_NeurIPS_work",
            "status": "requested",
            "risk_class": "benchmark-boundary",
            "objection": "local fixture asks for a DQL Bellman value policy experiment profile",
            "proposed_fix": "run allowlisted DQL value-policy local smoke with deterministic metrics",
            "evidence_needed": "manifest, metrics, summary, output hashes, and negative-result policy",
            "verification": "DQL value-policy no-network command and metric acceptance checks",
            "source_locator": "paper.tex:2",
        },
        {
            "request_id": 940004,
            "request_key": "p4-fbsde-experiment",
            "slug": "DQN_FBSDE_NeurIPS_work",
            "status": "requested",
            "risk_class": "benchmark-boundary",
            "objection": "local fixture asks for an FBSDE solver residual experiment profile",
            "proposed_fix": "run allowlisted FBSDE solver residual local smoke with deterministic metrics",
            "evidence_needed": "manifest, residual metrics, summary, output hashes, and negative-result policy",
            "verification": "FBSDE no-network residual command and metric acceptance checks",
            "source_locator": "paper.tex:2",
        },
        {
            "request_id": 940005,
            "request_key": "p4-contracting-experiment",
            "slug": "Dynamic_Contracting_AI_work",
            "status": "requested",
            "risk_class": "benchmark-boundary",
            "objection": "local fixture asks for a dynamic contracting counterfactual experiment profile",
            "proposed_fix": "run allowlisted dynamic contracting counterfactual local smoke with deterministic metrics",
            "evidence_needed": "manifest, incentive metrics, summary, output hashes, and negative-result policy",
            "verification": "dynamic contracting no-network counterfactual command and metric acceptance checks",
            "source_locator": "paper.tex:2",
        },
        {
            "request_id": 940006,
            "request_key": "p4-robust-control-experiment",
            "slug": "Deep_Robust_Control_OR",
            "status": "requested",
            "risk_class": "benchmark-boundary",
            "objection": "local fixture asks for a robust control stability experiment profile",
            "proposed_fix": "run allowlisted robust control stability local smoke with deterministic metrics",
            "evidence_needed": "manifest, Lyapunov metrics, summary, output hashes, and negative-result policy",
            "verification": "robust control no-network stability command and metric acceptance checks",
            "source_locator": "paper.tex:2",
        },
    ]


def _stage_ok(lane, fields):
    return all(lane.get(field) == "PASS" for field in fields)


def _lane_report(root, out_dir, request, claim_report, source_text, label, apply_isolated_source=False):
    key = request["request_key"]
    lane_label = f"{label}-{key}" if label else key
    lane_dir = pathlib.Path(out_dir) / key
    lane_dir.mkdir(parents=True, exist_ok=True)
    request_id = str(request["request_id"])
    quality = research_compute_claim_quality_gate.research_compute_claim_quality_gate(
        claim_report,
        request_id=request_id,
        label=lane_label,
    )
    quality = _write_report(root, out_dir, f"{key}-claim-quality-gate.json", quality)
    evidence = research_compute_claim_evidence_execution.research_compute_claim_evidence_execution(
        quality,
        root=str(lane_dir),
        execute=True,
        label=lane_label,
    )
    evidence = _write_report(root, out_dir, f"{key}-claim-evidence-execution.json", evidence)
    evidence_quality = research_compute_claim_evidence_quality_gate.research_compute_claim_evidence_quality_gate(
        evidence,
        root=str(lane_dir),
        label=lane_label,
    )
    evidence_quality = _write_report(
        root,
        out_dir,
        f"{key}-claim-evidence-quality-gate.json",
        evidence_quality,
    )
    materialization = research_compute_claim_manuscript_patch_materialization.research_compute_claim_manuscript_patch_materialization(
        claim_report,
        source_text,
        source_snapshot=_source_snapshot("paper.tex", source_text),
        claim_quality_gate_report=quality,
        claim_evidence_execution_report=evidence,
        claim_evidence_quality_gate_report=evidence_quality,
        request_id=request_id,
        label=lane_label,
    )
    patch_text = (materialization.get("patch_draft") or {}).get("patch_text") or ""
    patch_path = lane_dir / "claim.patch"
    patch_path.write_text(patch_text)
    patch_snapshot = {
        "path": _rel(root, patch_path),
        "exists": True,
        "is_file": True,
        "sha256": _sha256_file(patch_path),
        "size_bytes": len(patch_text.encode()),
    }
    materialization.setdefault("patch_draft", {})["patch_file_path"] = patch_snapshot["path"]
    materialization["patch_draft"]["patch_file_sha256"] = patch_snapshot["sha256"]
    materialization["patch_draft"]["patch_file_bytes"] = patch_snapshot["size_bytes"]
    materialization = _write_report(
        root,
        out_dir,
        f"{key}-claim-manuscript-patch-materialization.json",
        materialization,
    )
    worktree = lane_dir / "worktree"
    worktree.mkdir(parents=True, exist_ok=True)
    (worktree / "paper.tex").write_text(source_text)
    apply_check = subprocess.run(
        ["git", "apply", "--check", str(patch_path.resolve())],
        cwd=worktree,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    )
    readiness = research_compute_claim_manuscript_source_apply_readiness.research_compute_claim_manuscript_source_apply_readiness(
        materialization,
        patch_snapshot,
        _source_snapshot("paper.tex", source_text),
        {
            "performed": True,
            "returncode": apply_check.returncode,
            "passed": apply_check.returncode == 0,
            "stdout": apply_check.stdout,
            "stderr": apply_check.stderr,
        },
        patch_text,
        source_text,
        label=lane_label,
    )
    preflight_sidecar = _write_sidecar(root, out_dir, f"{key}-preflight-sidecar.json", readiness.get("preflight_report") or {})
    apply_sidecar = _write_sidecar(root, out_dir, f"{key}-source-apply-dry-run-sidecar.json", readiness.get("source_apply_dry_run_packet") or {})
    readiness["preflight_sidecar_path"] = preflight_sidecar["path"]
    readiness["preflight_sidecar_sha256"] = preflight_sidecar["sha256"]
    readiness["source_apply_dry_run_packet_path"] = apply_sidecar["path"]
    readiness["source_apply_dry_run_packet_sha256"] = apply_sidecar["sha256"]
    readiness = _write_report(root, out_dir, f"{key}-claim-source-apply-readiness.json", readiness)
    execution_ready = research_compute_claim_manuscript_source_apply_execution.research_compute_claim_manuscript_source_apply_execution(
        readiness,
        apply_requested=False,
        write_requested=False,
        label=lane_label,
    )
    execution_ready = _write_report(
        root,
        out_dir,
        f"{key}-claim-source-apply-execution-ready-not-executed.json",
        execution_ready,
    )
    apply_report = {}
    post_apply_report = {}
    execution_final = execution_ready
    if apply_isolated_source:
        apply_report, post_apply_report, execution_final = _isolated_source_apply(
            root,
            out_dir,
            lane_dir,
            lane_label,
            readiness,
            patch_path,
            patch_snapshot,
            patch_text,
        )
    finalization = research_compute_claim_manuscript_source_landing_finalization.research_compute_claim_manuscript_source_landing_finalization(
        execution_final,
        label=lane_label,
    )
    finalization = _write_report(root, out_dir, f"{key}-claim-source-landing-finalization.json", finalization)
    merge = research_compute_claim_manuscript_merge_submission_readiness.research_compute_claim_manuscript_merge_submission_readiness(
        finalization,
        label=lane_label,
    )
    merge = _write_report(root, out_dir, f"{key}-claim-merge-submission-readiness.json", merge)
    academic_packet = evidence_quality.get("academic_claim_finalization_packet") or {}
    production_boundary_reports = [quality, evidence, evidence_quality, materialization, readiness, finalization, merge]
    isolated_apply_verified = bool(
        apply_isolated_source
        and execution_final.get("status") == "PASS"
        and execution_final.get("claim_manuscript_source_apply_execution_state")
        == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_APPLIED_AND_VERIFIED"
        and post_apply_report.get("status") == "PASS"
    )
    isolated_source_mutation = bool(apply_isolated_source and execution_final.get("source_mutation_performed"))
    report_paths = {
        "quality": quality["report_path"],
        "evidence_execution": evidence["report_path"],
        "evidence_quality": evidence_quality["report_path"],
        "materialization": materialization["report_path"],
        "readiness": readiness["report_path"],
        "execution_ready": execution_ready["report_path"],
        "finalization": finalization["report_path"],
        "merge_submission": merge["report_path"],
    }
    if apply_report:
        report_paths["isolated_apply_gate"] = apply_report["report_path"]
    if post_apply_report:
        report_paths["isolated_post_apply_verify"] = post_apply_report["report_path"]
    if execution_final is not execution_ready:
        report_paths["execution_applied"] = execution_final["report_path"]
    return {
        "request_id": request["request_id"],
        "request_key": key,
        "claim_kind": quality.get("selected_claim_kind") or "",
        "quality_status": quality.get("status") or "",
        "evidence_execution_status": evidence.get("status") or "",
        "evidence_execution_state": evidence.get("claim_evidence_execution_state") or "",
        "evidence_quality_status": evidence_quality.get("status") or "",
        "local_proof_obligation_checker_used": bool(evidence_quality.get("local_proof_obligation_checker_used")),
        "experiment_reproducibility_checker_used": bool(evidence_quality.get("experiment_reproducibility_checker_used")),
        "allowlisted_experiment_id": academic_packet.get("allowlisted_experiment_id") or "",
        "experiment_profile_domain": academic_packet.get("experiment_profile_domain") or "",
        "experiment_metric_names": list(academic_packet.get("experiment_metric_names") or []),
        "experiment_required_domain_metric_names": list(
            academic_packet.get("experiment_required_domain_metric_names") or []
        ),
        "experiment_evidence_maturity": academic_packet.get("experiment_evidence_maturity") or "",
        "experiment_paper_constant_finalization_state": (
            academic_packet.get("experiment_paper_constant_finalization_state") or ""
        ),
        "experiment_promotion_eligible": bool(academic_packet.get("experiment_promotion_eligible")),
        "experiment_named_input_promotion_allowed": bool(
            academic_packet.get("experiment_named_input_promotion_allowed")
        ),
        "experiment_final_signature_present": bool(academic_packet.get("experiment_final_signature_present")),
        "formal_verifier_used": bool(evidence_quality.get("formal_verifier_used")),
        "formal_verifier_adapter_ready": bool(evidence_quality.get("formal_verifier_adapter_ready")),
        "formal_verifier_adapter_available_certificate_kind_count": int(
            (evidence_quality.get("summary") or {}).get("formal_verifier_adapter_available_certificate_kind_count")
            or 0
        ),
        "academic_claim_agent_finalization_ready": bool(evidence_quality.get("academic_claim_agent_finalization_ready")),
        "patch_materialization_status": materialization.get("status") or "",
        "source_apply_readiness_status": readiness.get("status") or "",
        "source_apply_readiness_state": readiness.get("claim_manuscript_source_apply_readiness_state") or "",
        "source_apply_execution_status": execution_final.get("status") or "",
        "source_apply_execution_state": execution_final.get("claim_manuscript_source_apply_execution_state") or "",
        "isolated_source_apply_requested": bool(apply_isolated_source),
        "isolated_source_apply_performed": bool(execution_final.get("apply_requested")) if apply_isolated_source else False,
        "isolated_source_apply_verified": isolated_apply_verified,
        "isolated_source_mutation_performed": isolated_source_mutation,
        "merge_submission_status": merge.get("status") or "",
        "merge_submission_state": merge.get("claim_manuscript_merge_submission_readiness_state") or "",
        "output_hash_count": len(evidence.get("output_hashes") or []),
        "source_mutation_performed": any(bool(report.get("source_mutation_performed")) for report in production_boundary_reports),
        "external_action_performed": any(bool(report.get("external_action_performed")) for report in production_boundary_reports),
        "report_paths": report_paths,
    }


def research_compute_claim_local_e2e_smoke(
    root=".",
    label="",
    autonomy_policy=None,
    source_text=None,
    apply_isolated_source=False,
):
    root = pathlib.Path(root)
    label = label or COMMAND
    out_dir = report_io.batch_dir(root, "research_compute_claim_local_e2e_smoke", label)
    out_dir.mkdir(parents=True, exist_ok=True)
    source_text = source_text or "\\section{Intro}\nOriginal manuscript sentence.\n"
    policy = agent_autonomy_policy.normalize_policy(autonomy_policy or {})
    claim_report = research_compute_claim_draft.research_compute_claim_draft(
        requests=_synthetic_requests(),
        label=label,
        iteration_budget=2,
        autonomy_policy=policy,
    )
    claim_report = _write_report(root, out_dir, "research-compute-claim-draft.json", claim_report)
    lanes = [
        _lane_report(root, out_dir, request, claim_report, source_text, label, apply_isolated_source=apply_isolated_source)
        for request in _synthetic_requests()
    ]
    pre_merge_fields = [
        "quality_status",
        "evidence_execution_status",
        "evidence_quality_status",
        "patch_materialization_status",
        "source_apply_readiness_status",
        "source_apply_execution_status",
    ]
    pre_merge_pass_count = sum(1 for lane in lanes if _stage_ok(lane, pre_merge_fields))
    summary = {
        "lane_count": len(lanes),
        "pre_merge_pass_lane_count": pre_merge_pass_count,
        "theorem_lane_count": sum(1 for lane in lanes if lane.get("claim_kind") == "theorem_or_proof"),
        "experiment_lane_count": sum(1 for lane in lanes if lane.get("claim_kind") == "experiment"),
        "executed_evidence_lane_count": sum(
            1
            for lane in lanes
            if lane.get("evidence_execution_state")
            == "RESEARCH_COMPUTE_CLAIM_EVIDENCE_EXECUTION_EVIDENCE_GATE_READY"
        ),
        "source_apply_ready_not_executed_count": sum(
            1
            for lane in lanes
            if lane.get("source_apply_execution_state")
            == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_READY_NOT_EXECUTED"
        ),
        "source_apply_applied_verified_count": sum(
            1
            for lane in lanes
            if lane.get("source_apply_execution_state")
            == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_APPLIED_AND_VERIFIED"
        ),
        "experiment_nonpromotional_candidate_count": sum(
            1 for lane in lanes if lane.get("experiment_evidence_maturity") == "local_smoke_candidate"
        ),
        "experiment_promotion_eligible_count": sum(1 for lane in lanes if lane.get("experiment_promotion_eligible")),
        "experiment_named_input_promotion_allowed_count": sum(
            1 for lane in lanes if lane.get("experiment_named_input_promotion_allowed")
        ),
        "experiment_final_signature_present_count": sum(1 for lane in lanes if lane.get("experiment_final_signature_present")),
        "isolated_source_apply_performed_count": sum(1 for lane in lanes if lane.get("isolated_source_apply_performed")),
        "isolated_source_apply_verified_count": sum(1 for lane in lanes if lane.get("isolated_source_apply_verified")),
        "source_mutation_performed_count": sum(1 for lane in lanes if lane.get("source_mutation_performed")),
        "isolated_source_mutation_performed_count": sum(1 for lane in lanes if lane.get("isolated_source_mutation_performed")),
        "external_action_performed_count": sum(1 for lane in lanes if lane.get("external_action_performed")),
    }
    source_apply_complete = (
        summary["source_apply_applied_verified_count"] == len(lanes)
        if apply_isolated_source
        else summary["source_apply_ready_not_executed_count"] == len(lanes)
    )
    status = (
        "PASS"
        if (
            pre_merge_pass_count == len(lanes)
            and source_apply_complete
            and summary["source_mutation_performed_count"] == 0
            and summary["external_action_performed_count"] == 0
        )
        else "ATTENTION"
    )
    return {
        "command": COMMAND,
        "created_at": dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "status": status,
        "claim_local_e2e_smoke_state": PASS_STATE if status == "PASS" else ATTENTION_STATE,
        "label": label,
        "local_only_note": (
            "Synthetic theorem/proof and experiment lanes execute local evidence and "
            "source-apply dry-runs by default. When isolated source apply is enabled, "
            "only per-lane log worktrees are changed; production manuscript source, "
            "package/archive state, commit, upload, email, submission, secrets, and "
            "external actions are untouched."
        ),
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "full_agent_autonomy_authorized": bool(policy.get("full_agent_autonomy_authorized")),
        "autonomy_policy": policy,
        "isolated_source_apply_requested": bool(apply_isolated_source),
        "claim_draft_report_path": claim_report["report_path"],
        "summary": summary,
        "lanes": lanes,
        "boundary": [
            "This smoke command uses synthetic requests and temporary logs/worktrees.",
            "It validates claim drafting, theorem/proof evidence, experiment evidence, manuscript patch materialization, and source-apply readiness.",
            "By default it intentionally stops before source mutation; with isolated source apply it mutates only synthetic per-lane log worktrees and records rollback/post-apply verification.",
            "It never mutates production source, merge state, external submission, secret access, or performed external evidence intake.",
        ],
    }


def research_compute_claim_local_e2e_smoke_markdown(report):
    lines = [
        "# paper_factory Claim Local E2E Smoke",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_local_e2e_smoke_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Lanes", ""])
    for lane in report.get("lanes") or []:
        lines.append(
            f"- request `{lane.get('request_id')}` {lane.get('claim_kind')} "
            f"quality={lane.get('quality_status')} evidence={lane.get('evidence_execution_status')} "
            f"source_apply={lane.get('source_apply_execution_state')}"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
