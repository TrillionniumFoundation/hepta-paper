"""Summarize pending external executor responses for claim submission tasks."""

import datetime as dt

from paperctl_modules import report_ref_health

COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-backlog"

CLEAR_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_BACKLOG_CLEAR"
PENDING_RESPONSE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_BACKLOG_WAITING_FOR_EXECUTOR_RESPONSE"
)
READY_FOR_INTAKE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_BACKLOG_READY_FOR_INTAKE"
)
READY_FOR_GATE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_BACKLOG_READY_FOR_GATE"
)
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_BACKLOG_ATTENTION"

WAITING_CONTRACT_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_WAITING_FOR_EXECUTOR_RESPONSE"
)
READY_CONTRACT_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_READY_FOR_INTAKE"
)
TASK_REQUIRED_CONTRACT_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_TASK_REQUIRED"
)
TASK_REQUIRED_IDLE_ISSUES = {
    "executor_task_summary_not_clean",
    "executor_task_not_pass",
    "executor_task_validation_issues_present",
    "executor_task_not_ready",
    "executor_task_ready_flag_missing",
    "executor_task_packet_missing",
    "executor_task_required_response_schema_mismatch",
}
READY_INTAKE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_READY"
PERFORMED_GATE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
CONTRACT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"
INTAKE_COMMAND = "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake"
GATE_COMMAND = "research-compute-claim-manuscript-external-submission-execution-gate"
TERMINAL_COMMAND = "research-compute-claim-manuscript-external-submission-execution-terminal-status"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _report_ref_health_issues(name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    return ref_issues


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _clean_pass(report):
    report = report or {}
    return bool(report.get("status") == "PASS" and _validation_issue_count(report) == 0)


def _fresh_clean_pass(report, name, expected_command):
    return bool(_clean_pass(report) and not _report_ref_health_issues(name, report, expected_command))


def _anchor(report):
    report = report or {}
    claim = report.get("claim_packet_id") or ""
    source = report.get("source_target_path") or ""
    source_hash = report.get("source_after_sha256") or ""
    manifest = report.get("upload_manifest_csv_sha256") or ""
    if not claim or not source_hash:
        return ()
    return (claim, source, source_hash, manifest)


def _ref(ref):
    return dict(ref or {})


def _report_ref(item):
    report = (item or {}).get("report") or {}
    ref = _ref((item or {}).get("ref") or {})
    if not ref and report.get("report_path"):
        ref = {
            "event_type": report.get("command") or "",
            "status": report.get("status") or "",
            "path": report.get("report_path") or "",
            "sha256": report.get("report_sha256") or "",
            "sha256_match": bool(report.get("report_path")),
            "created_at": report.get("created_at") or "",
            "summary": "",
        }
    return ref


def _contract_item(item):
    report = (item or {}).get("report") or {}
    summary = _summary(report)
    return {
        "claim_packet_id": report.get("claim_packet_id") or "",
        "slug": report.get("slug") or "",
        "source_target_path": report.get("source_target_path") or "",
        "source_after_sha256": report.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": report.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": report.get("executor_task_report_path") or "",
        "executor_task_report_sha256": report.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": report.get("executor_response_packet_path") or "",
        "executor_response_packet_sha256": report.get("executor_response_packet_sha256") or "",
        "executor_response_contract_state": report.get("executor_response_contract_state") or "",
        "executor_response_contract_ready": bool(report.get("executor_response_contract_ready")),
        "waiting_for_executor_response": bool(report.get("waiting_for_executor_response")),
        "response_packet_present": bool(report.get("response_packet_present")),
        "response_ready_for_intake": bool(report.get("response_ready_for_intake")),
        "validation_issue_count": int(summary.get("validation_issue_count") or 0),
        "next_intake_command": report.get("next_intake_command") or "",
        "next_gate_command_after_intake": report.get("next_gate_command_after_intake") or "",
        "report_ref": _report_ref(item),
    }


def _task_required_idle_contract(report):
    report = report or {}
    issue_names = {str(issue.get("issue") or "") for issue in report.get("validation_issues") or []}
    issue_shape_ok = not issue_names or issue_names <= TASK_REQUIRED_IDLE_ISSUES
    return bool(
        report.get("command") == CONTRACT_COMMAND
        and report.get("executor_response_contract_state") == TASK_REQUIRED_CONTRACT_STATE
        and not report.get("executor_response_contract_ready")
        and not report.get("waiting_for_executor_response")
        and not report.get("response_packet_present")
        and not report.get("response_ready_for_intake")
        and not report.get("external_action_performed")
        and not report.get("secret_material_read_performed")
        and not report.get("commit_performed")
        and issue_shape_ok
        and not _anchor(report)
    )


def _intake_ready_item(item):
    report = (item or {}).get("report") or {}
    return {
        "performed_evidence_intake_report_ref": _report_ref(item),
        "performed_evidence_path": report.get("performed_evidence_path") or "",
        "performed_evidence_sha256": report.get("performed_evidence_sha256") or "",
    }


def _intake_ready_by_anchor(items):
    out = {}
    for item in items or []:
        report = (item or {}).get("report") or {}
        if not _intake_ready(report):
            continue
        anchor = _anchor(report)
        if anchor and anchor not in out:
            out[anchor] = _intake_ready_item(item)
    return out


def _gate_command_with_evidence(command, performed_evidence_path):
    command = command or (
        "research-compute-claim-manuscript-external-submission-execution-gate"
        " --performed-evidence <external-submission-performed-evidence.json>"
    )
    if performed_evidence_path:
        command = command.replace("<external-submission-performed-evidence.json>", performed_evidence_path)
        command = command.replace("<sidecar>", performed_evidence_path)
    return command


def _intake_ready(report):
    return bool(
        _fresh_clean_pass(report, "performed_evidence_intake", INTAKE_COMMAND)
        and (report or {}).get("performed_evidence_intake_state") == READY_INTAKE_STATE
        and (report or {}).get("performed_evidence_intake_ready")
    )


def _gate_accepted(report):
    return bool(
        _fresh_clean_pass(report, "execution_gate", GATE_COMMAND)
        and (report or {}).get("claim_manuscript_external_submission_execution_gate_state") == PERFORMED_GATE_STATE
        and (report or {}).get("external_submission_execution_gate_ready")
        and (report or {}).get("performed_evidence_recorded")
        and not (report or {}).get("record_only_fixture")
    )


def _terminal_accepted(report):
    return bool(
        _fresh_clean_pass(report, "terminal_status", TERMINAL_COMMAND)
        and (report or {}).get("terminal_status") == "PERFORMED_EVIDENCE_ACCEPTED"
        and (report or {}).get("external_submission_execution_gate_ready")
        and (report or {}).get("performed_evidence_recorded")
        and not (report or {}).get("record_only_fixture")
    )


def _anchors(items, predicate):
    out = set()
    for item in items or []:
        report = (item or {}).get("report") or {}
        if predicate(report):
            anchor = _anchor(report)
            if anchor:
                out.add(anchor)
    return out


def build_executor_response_backlog(
    contract_items=None,
    performed_evidence_intake_items=None,
    execution_gate_items=None,
    terminal_status_items=None,
    label="",
    limit=20,
):
    contract_items = list(contract_items or [])
    limit = max(int(limit or 0), 0)
    intake_ready_items = _intake_ready_by_anchor(performed_evidence_intake_items)
    intake_ready_anchors = set(intake_ready_items)
    gate_accepted_anchors = _anchors(execution_gate_items, _gate_accepted)
    terminal_accepted_anchors = _anchors(terminal_status_items, _terminal_accepted)
    closed_anchors = gate_accepted_anchors | terminal_accepted_anchors
    ready_for_gate = []
    ready_for_intake = []
    pending = []
    invalid_anchor = []
    seen = set()

    for item in contract_items:
        report = (item or {}).get("report") or {}
        if report and _task_required_idle_contract(report):
            continue
        contract_ref_issues = _report_ref_health_issues("executor_response_contract", report, CONTRACT_COMMAND) if report else []
        anchor = _anchor(report)
        if not anchor or not _clean_pass(report) or contract_ref_issues:
            if report:
                invalid = _contract_item(item)
                invalid["validation_issue_count"] = int(invalid.get("validation_issue_count") or 0) + len(contract_ref_issues)
                invalid["report_ref_health_issues"] = contract_ref_issues
                invalid_anchor.append(invalid)
            continue
        if anchor in seen:
            continue
        seen.add(anchor)
        if anchor in closed_anchors:
            continue
        contract = _contract_item(item)
        state = report.get("executor_response_contract_state") or ""
        if anchor in intake_ready_anchors:
            intake_item = intake_ready_items.get(anchor) or {}
            contract.update(intake_item)
            contract["next_gate_command_after_intake"] = _gate_command_with_evidence(
                contract.get("next_gate_command_after_intake") or "",
                contract.get("performed_evidence_path") or "",
            )
            ready_for_gate.append(contract)
        elif state == READY_CONTRACT_STATE or report.get("executor_response_contract_ready"):
            ready_for_intake.append(contract)
        elif state == WAITING_CONTRACT_STATE or report.get("waiting_for_executor_response"):
            pending.append(contract)

    if limit:
        pending = pending[:limit]
        ready_for_intake = ready_for_intake[:limit]
        ready_for_gate = ready_for_gate[:limit]
        invalid_anchor = invalid_anchor[:limit]

    validation_issue_count = 0
    if ready_for_gate:
        state = READY_FOR_GATE_STATE
        status = "PASS"
        next_stage = "external_submission_execution_gate"
        next_command = ready_for_gate[0].get("next_gate_command_after_intake") or ""
    elif ready_for_intake:
        state = READY_FOR_INTAKE_STATE
        status = "PASS"
        next_stage = "external_submission_execution_performed_evidence_intake"
        next_command = ready_for_intake[0].get("next_intake_command") or ""
    elif pending:
        state = PENDING_RESPONSE_STATE
        status = "PASS"
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = pending[0].get("next_intake_command") or ""
    elif invalid_anchor:
        state = ATTENTION_STATE
        status = "ATTENTION"
        validation_issue_count = len(invalid_anchor)
        next_stage = "external_submission_execution_executor_response_contract"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"
            " --executor-task-report <executor-task-report>"
            " --executor-response-packet <executor-response-packet>"
        )
    else:
        state = CLEAR_STATE
        status = "PASS"
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"

    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_backlog_state": state,
        "executor_response_backlog_created": status in {"PASS", "ATTENTION"},
        "pending_executor_response_count": len(pending),
        "ready_for_intake_count": len(ready_for_intake),
        "ready_for_gate_count": len(ready_for_gate),
        "closed_executor_response_count": len(closed_anchors),
        "invalid_anchor_contract_count": len(invalid_anchor),
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "contract_report_count": len(contract_items),
            "pending_executor_response_count": len(pending),
            "ready_for_intake_count": len(ready_for_intake),
            "ready_for_gate_count": len(ready_for_gate),
            "closed_executor_response_count": len(closed_anchors),
            "invalid_anchor_contract_count": len(invalid_anchor),
            "validation_issue_count": validation_issue_count,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "pending_executor_responses": pending,
        "ready_for_intake_contracts": ready_for_intake,
        "ready_for_gate_contracts": ready_for_gate,
        "invalid_anchor_contracts": invalid_anchor,
        "boundary": [
            "This command summarizes recorded executor-response contracts and performed-evidence closure reports.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "Pending executor-response items are waiting for a separate real external executor response packet; they are not performed evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Backlog",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_backlog_state') or ''}",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Pending Executor Responses", ""])
    for item in report.get("pending_executor_responses") or []:
        lines.append(
            f"- `{item.get('claim_packet_id') or ''}` "
            f"`{item.get('source_target_path') or ''}` "
            f"state={item.get('executor_response_contract_state') or ''}"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
