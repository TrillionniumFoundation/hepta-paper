"""Classify a real executor response before performed-evidence intake."""

import datetime as dt

from paperctl_modules import research_compute_claim_manuscript_external_submission_execution_executor_task as task_core
from paperctl_modules import research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake as intake
from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_READY_FOR_INTAKE"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_WAITING_FOR_EXECUTOR_RESPONSE"
TASK_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_TASK_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

CONTRACT_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_contract.v1"
)
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _task_packet(report):
    return (report or {}).get("external_submission_executor_task_packet") or {}


def _intent_report(report):
    item = report or {}
    return item.get("execution_intent_report") or {}


def _validate_executor_task(report):
    issues = []
    item = report or {}
    packet = _task_packet(item)
    if not item:
        _add_issue(issues, "executor_task_report_missing")
        return issues
    _add_report_ref_health_issues(issues, "executor_task", item, task_core.COMMAND)
    if item.get("command") != task_core.COMMAND:
        _add_issue(issues, "executor_task_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "executor_task_not_pass", item.get("status") or "")
    if _validation_issue_count(item):
        _add_issue(issues, "executor_task_validation_issues_present")
    if item.get("executor_task_state") != task_core.READY_STATE:
        _add_issue(issues, "executor_task_not_ready", item.get("executor_task_state") or "")
    if not item.get("executor_task_ready"):
        _add_issue(issues, "executor_task_ready_flag_missing")
    if not packet:
        _add_issue(issues, "executor_task_packet_missing")
    if packet.get("required_executor_response_schema") != intake.EXECUTOR_RESPONSE_PACKET_SCHEMA:
        _add_issue(
            issues,
            "executor_task_required_response_schema_mismatch",
            packet.get("required_executor_response_schema") or "",
        )
    if not (item.get("execution_intent_report_sha256") or packet.get("execution_intent_report_sha256")):
        _add_issue(issues, "executor_task_missing:execution_intent_report_sha256")
    if not (item.get("upload_manifest_csv_sha256") or packet.get("upload_manifest_csv_sha256")):
        _add_issue(issues, "executor_task_missing:upload_manifest_csv_sha256")
    for key in _forbidden_keys():
        if item.get(key):
            _add_issue(issues, f"forbidden_executor_task_boundary:{key}")
        if packet.get(key):
            _add_issue(issues, f"forbidden_executor_task_packet_boundary:{key}")
    return issues


def _task_report_waiting_for_intent(report, response_present=False):
    report = report or {}
    if response_present:
        return False
    if report.get("command") != task_core.COMMAND:
        return False
    if report.get("executor_task_state") != task_core.WAITING_STATE:
        return False
    if report.get("external_action_performed") is True:
        return False
    if report.get("secret_material_read_performed") is True:
        return False
    if report.get("commit_performed") is True:
        return False
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        "executor_task",
        report,
        expected_command=task_core.COMMAND,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    blocking_issues = [
        item
        for item in ref_issues
        if item.get("issue") != "executor_task_summary_not_clean"
    ]
    return not blocking_issues


def _response_present(response):
    return bool(intake._normalize_executor_response_packet(response or {}))


def _next_intake_command(task_report, response_path=""):
    packet = _task_packet(task_report)
    command = packet.get("next_intake_command_template") or (
        "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake"
        " --execution-intent-report <execution-intent-report>"
        " --executor-task-report <executor-task-report>"
        " --executor-response-packet <executor-response-packet>"
    )
    if response_path:
        command = command.replace("<executor-response-packet>", response_path)
    return command


def _next_gate_command(task_report, intake_report=None):
    packet = _task_packet(task_report)
    command = packet.get("next_gate_command_template") or (
        "research-compute-claim-manuscript-external-submission-execution-gate"
        " --execution-intent-report <execution-intent-report>"
        " --performed-evidence <external-submission-performed-evidence.json>"
    )
    performed_evidence_path = (intake_report or {}).get("performed_evidence_path") or ""
    if performed_evidence_path:
        command = command.replace("<external-submission-performed-evidence.json>", performed_evidence_path)
    return command


def _contract_packet(task_report, response, intake_preview, state, response_path=""):
    packet = _task_packet(task_report)
    normalized_response = intake._normalize_executor_response_packet(response or {})
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_contract",
        "packet_schema": CONTRACT_PACKET_SCHEMA,
        "executor_response_contract_state": state,
        "claim_packet_id": task_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": task_report.get("slug") or packet.get("slug") or "",
        "source_target_path": task_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": task_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "execution_intent_report_path": task_report.get("execution_intent_report_path") or packet.get("execution_intent_report_path") or "",
        "execution_intent_report_sha256": task_report.get("execution_intent_report_sha256") or packet.get("execution_intent_report_sha256") or "",
        "executor_task_report_path": task_report.get("report_path") or "",
        "executor_task_report_sha256": task_report.get("report_sha256") or "",
        "executor_response_packet_path": response_path or "",
        "required_executor_response_schema": intake.EXECUTOR_RESPONSE_PACKET_SCHEMA,
        "upload_manifest_csv_sha256": task_report.get("upload_manifest_csv_sha256") or packet.get("upload_manifest_csv_sha256") or "",
        "response_packet_present": bool(normalized_response),
        "response_ready_for_intake": bool((intake_preview or {}).get("performed_evidence_intake_ready")),
        "next_intake_command": _next_intake_command(task_report, response_path=response_path),
        "next_gate_command_after_intake": _next_gate_command(task_report, intake_preview),
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
    }


def research_compute_claim_manuscript_external_submission_execution_executor_response_contract(
    executor_task_report,
    executor_response_packet=None,
    executor_response_packet_path="",
    label="",
):
    task_report = executor_task_report or {}
    response = executor_response_packet or {}
    response_present = _response_present(response)
    task_waiting_for_intent = _task_report_waiting_for_intent(
        task_report,
        response_present=response_present,
    )
    task_issues = [] if task_waiting_for_intent else _validate_executor_task(task_report)
    intent_report = _intent_report(task_report)
    intake_preview = {}
    if not task_issues and response_present:
        intake_preview = intake.research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake(
            intent_report,
            executor_response_packet=response,
            executor_task_report=task_report,
            label=label,
        )
    intake_issues = list((intake_preview or {}).get("validation_issues") or [])
    issues = task_issues + intake_issues
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif task_waiting_for_intent:
        status = "PASS"
        state = TASK_REQUIRED_STATE
    elif task_issues:
        status = "ATTENTION"
        state = TASK_REQUIRED_STATE
    elif not response_present:
        status = "PASS"
        state = WAITING_STATE
    elif (intake_preview or {}).get("performed_evidence_intake_ready"):
        status = "PASS"
        state = READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE

    contract = _contract_packet(task_report, response, intake_preview, state, response_path=executor_response_packet_path)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_contract_state": state,
        "executor_response_contract_created": status in {"PASS", "ATTENTION"},
        "executor_response_contract_ready": state == READY_STATE,
        "waiting_for_executor_response": state == WAITING_STATE,
        "slug": contract.get("slug") or "",
        "claim_packet_id": contract.get("claim_packet_id") or "",
        "source_target_path": contract.get("source_target_path") or "",
        "source_after_sha256": contract.get("source_after_sha256") or "",
        "execution_intent_report_path": contract.get("execution_intent_report_path") or "",
        "execution_intent_report_sha256": contract.get("execution_intent_report_sha256") or "",
        "executor_task_report_path": contract.get("executor_task_report_path") or "",
        "executor_task_report_sha256": contract.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": executor_response_packet_path or "",
        "upload_manifest_csv_sha256": contract.get("upload_manifest_csv_sha256") or "",
        "response_packet_present": response_present,
        "response_ready_for_intake": bool((intake_preview or {}).get("performed_evidence_intake_ready")),
        "observed_external_action_reported": bool((intake_preview or {}).get("observed_external_action_performed")),
        "next_intake_command": contract.get("next_intake_command") or "",
        "next_gate_command_after_intake": contract.get("next_gate_command_after_intake") or "",
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "executor_task_ready_count": (
                1 if (not task_issues and task_report and not task_waiting_for_intent) else 0
            ),
            "executor_task_waiting_for_intent_count": 1 if task_waiting_for_intent else 0,
            "executor_response_packet_present_count": 1 if response_present else 0,
            "waiting_for_executor_response_count": 1 if state == WAITING_STATE else 0,
            "executor_response_contract_ready_count": 1 if state == READY_STATE else 0,
            "response_ready_for_intake_count": 1 if (intake_preview or {}).get("performed_evidence_intake_ready") else 0,
            "observed_external_action_reported_count": 1 if (intake_preview or {}).get("observed_external_action_performed") else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "executor_response_contract_packet": contract,
        "executor_response_packet": intake._normalize_executor_response_packet(response or {}),
        "performed_evidence_intake_preview": intake_preview,
        "executor_task_report": task_report,
        "boundary": [
            "This command classifies a separate external executor response before performed-evidence intake.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "A READY contract only means the response is ready to feed into performed-evidence intake; it is not itself performed evidence and does not close the execution gate.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_executor_response_contract_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Executor Response Contract",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_contract_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Contract ready: {report.get('executor_response_contract_ready')}",
        f"- Waiting for response: {report.get('waiting_for_executor_response')}",
        f"- External action performed by this command: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("executor_response_contract_packet") or {}
    if packet:
        lines.extend(["", "## Contract", ""])
        for key in [
            "packet_schema",
            "claim_packet_id",
            "source_target_path",
            "upload_manifest_csv_sha256",
            "response_packet_present",
            "response_ready_for_intake",
            "next_intake_command",
        ]:
            lines.append(f"- {key}: {packet.get(key) or ''}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
