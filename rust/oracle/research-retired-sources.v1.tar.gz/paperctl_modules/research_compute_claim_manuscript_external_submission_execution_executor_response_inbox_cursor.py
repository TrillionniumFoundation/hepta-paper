"""Select the next unconsumed executor response packet from an inbox index."""

import datetime as dt

from paperctl_modules import (
    research_compute_claim_manuscript_external_submission_execution_executor_response_inbox_index
    as inbox_index_core,
)
from paperctl_modules import (
    research_compute_claim_manuscript_external_submission_execution_executor_response_work_item
    as work_item_core,
)
from paperctl_modules import report_ref_health


COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-inbox-cursor"
)

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_CURSOR_CLEAR"
)
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_CURSOR_WAITING_FOR_RESPONSE_PACKET"
)
READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_CURSOR_READY_FOR_DISCOVERY"
)
ATTENTION_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_CURSOR_ATTENTION"
)
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

INBOX_CURSOR_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_inbox_cursor.v1"
)

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    if not report:
        return
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _selected_target(report):
    report = report or {}
    packet = report.get("executor_response_work_item_packet") or {}
    target = report.get("selected_executor_response_target") or {}
    out = {}
    for source in [target, packet, report]:
        for key in [
            "claim_packet_id",
            "slug",
            "source_target_path",
            "source_after_sha256",
            "upload_manifest_csv_sha256",
            "executor_task_report_path",
            "executor_task_report_sha256",
            "next_contract_command",
        ]:
            if not out.get(key) and source.get(key):
                out[key] = source.get(key)
    return out


def _anchor_from_target(target):
    target = target or {}
    return {
        "claim_packet_id": target.get("claim_packet_id") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
    }


def _anchor_complete(anchor):
    anchor = anchor or {}
    return bool(anchor.get("claim_packet_id") and anchor.get("source_after_sha256"))


def _anchor_matches(expected, observed):
    expected = expected or {}
    observed = observed or {}
    if not _anchor_complete(expected):
        return False
    for key in [
        "claim_packet_id",
        "source_target_path",
        "source_after_sha256",
        "upload_manifest_csv_sha256",
    ]:
        expected_value = expected.get(key) or ""
        observed_value = observed.get(key) or ""
        if expected_value and observed_value and expected_value != observed_value:
            return False
    return True


def _next_discovery_command(work_item_path, selected_path=""):
    command = (
        "research-compute-claim-manuscript-external-submission-execution-executor-response-packet-discovery"
        f" --executor-response-work-item-report {work_item_path or '<executor-response-work-item-report>'}"
        " --no-default-response-inbox"
    )
    if selected_path:
        command += f" --candidate-response-packet {selected_path}"
    return command


def _cursor_packet(target, selected, position, work_item_path):
    if not selected:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_inbox_cursor",
        "packet_schema": INBOX_CURSOR_PACKET_SCHEMA,
        "claim_packet_id": target.get("claim_packet_id") or "",
        "slug": target.get("slug") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": target.get("executor_task_report_path") or "",
        "executor_task_report_sha256": target.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": selected.get("path") or "",
        "executor_response_packet_sha256": selected.get("candidate_sha256") or "",
        "cursor_checkpoint_key": selected.get("candidate_sha256") or selected.get("path") or "",
        "cursor_position": int(position),
        "next_discovery_command": _next_discovery_command(work_item_path, selected.get("path") or ""),
    }


def build_executor_response_inbox_cursor(
    executor_response_inbox_index_report=None,
    executor_response_work_item_report=None,
    previous_inbox_cursor_report=None,
    label="",
):
    index_report = executor_response_inbox_index_report or {}
    work_item_report = executor_response_work_item_report or {}
    previous_report = previous_inbox_cursor_report or {}
    issues = []
    work_item_clear = bool(
        work_item_report.get("executor_response_work_item_state") == work_item_core.CLEAR_STATE
        and work_item_report.get("status") == "PASS"
        and _validation_issue_count(work_item_report) == 0
    )

    _add_report_ref_health_issues(
        issues,
        "executor_response_inbox_index",
        index_report,
        inbox_index_core.COMMAND,
    )
    if not index_report:
        _add_issue(issues, "executor_response_inbox_index_report_required")
    elif index_report.get("command") != inbox_index_core.COMMAND:
        _add_issue(issues, "executor_response_inbox_index_command_mismatch", index_report.get("command") or "")
    elif index_report.get("status") != "PASS":
        _add_issue(issues, "executor_response_inbox_index_not_pass", index_report.get("status") or "")
    elif not index_report.get("executor_response_inbox_index_ready"):
        _add_issue(issues, "executor_response_inbox_index_not_ready")
    if _validation_issue_count(index_report):
        _add_issue(issues, "executor_response_inbox_index_validation_issues_present")

    _add_report_ref_health_issues(
        issues,
        "executor_response_work_item",
        work_item_report,
        work_item_core.COMMAND,
    )
    if not work_item_report:
        _add_issue(issues, "executor_response_work_item_report_required")
    elif work_item_report.get("command") != work_item_core.COMMAND:
        _add_issue(issues, "executor_response_work_item_command_mismatch", work_item_report.get("command") or "")
    elif work_item_report.get("status") != "PASS":
        _add_issue(issues, "executor_response_work_item_not_pass", work_item_report.get("status") or "")
    elif not work_item_report.get("executor_response_work_item_ready") and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_not_ready")
    if _validation_issue_count(work_item_report):
        _add_issue(issues, "executor_response_work_item_validation_issues_present")

    for key in FORBIDDEN_KEYS:
        if index_report.get(key) or work_item_report.get(key):
            _add_issue(issues, f"forbidden_boundary:{key}")

    forbidden_count = int(index_report.get("forbidden_response_packet_count") or 0)
    target = {} if work_item_clear else _selected_target(work_item_report)
    expected_anchor = _anchor_from_target(target)
    if work_item_report and not target and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_target_missing")
    elif target and not _anchor_complete(expected_anchor):
        _add_issue(issues, "executor_response_work_item_anchor_incomplete")

    records = list(index_report.get("response_packet_records") or [])
    cursor_records = []
    selected = {}
    selected_position = -1
    counts = {
        "skipped_anchor_mismatch_response_packet_count": 0,
        "skipped_consumed_response_packet_count": 0,
        "skipped_in_progress_response_packet_count": 0,
        "skipped_duplicate_response_packet_count": 0,
        "skipped_rejected_response_packet_count": 0,
        "skipped_forbidden_response_packet_count": 0,
    }
    if not issues and not forbidden_count:
        for position, record in enumerate(records):
            candidate_status = record.get("candidate_status") or ""
            consumption_status = record.get("consumption_status") or "UNCONSUMED"
            anchor_match = _anchor_matches(expected_anchor, record.get("anchor") or {})
            eligible = candidate_status == "READY" and consumption_status == "UNCONSUMED" and anchor_match
            reason = ""
            if candidate_status == "DUPLICATE":
                reason = "duplicate"
                counts["skipped_duplicate_response_packet_count"] += 1
            elif candidate_status == "REJECTED":
                reason = "rejected"
                counts["skipped_rejected_response_packet_count"] += 1
            elif candidate_status == "FORBIDDEN":
                reason = "forbidden"
                counts["skipped_forbidden_response_packet_count"] += 1
            elif consumption_status == "CONSUMED":
                reason = "consumed"
                counts["skipped_consumed_response_packet_count"] += 1
            elif consumption_status == "IN_PROGRESS":
                reason = "in_progress"
                counts["skipped_in_progress_response_packet_count"] += 1
            elif not anchor_match:
                reason = "anchor_mismatch"
                counts["skipped_anchor_mismatch_response_packet_count"] += 1
            elif eligible:
                reason = "selected" if not selected else "eligible_waiting"
            cursor_record = {
                "cursor_position": position,
                "path": record.get("path") or "",
                "candidate_sha256": record.get("candidate_sha256") or "",
                "candidate_status": candidate_status,
                "consumption_status": consumption_status,
                "anchor_match": anchor_match,
                "eligible_for_discovery": eligible,
                "cursor_decision": reason,
                "anchor": record.get("anchor") or {},
                "consumed_by": list(record.get("consumed_by") or []),
            }
            cursor_records.append(cursor_record)
            if eligible and not selected:
                selected = record
                selected_position = position

    if forbidden_count or counts["skipped_forbidden_response_packet_count"]:
        status = "FAIL"
        state = FORBIDDEN_STATE
        ready = False
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = target.get("next_contract_command") or ""
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        ready = False
        next_stage = "external_submission_execution_executor_response_inbox_index"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-inbox-index --write"
        )
    elif work_item_clear:
        status = "PASS"
        state = CLEAR_STATE
        ready = False
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
    elif selected:
        status = "PASS"
        state = READY_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_packet_discovery"
        next_command = _next_discovery_command(
            work_item_report.get("report_path") or "<executor-response-work-item-report>",
            selected.get("path") or "",
        )
    elif records:
        status = "PASS"
        state = WAITING_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = target.get("next_contract_command") or ""
    else:
        status = "PASS"
        state = CLEAR_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = target.get("next_contract_command") or ""

    selected_count = 1 if selected else 0
    eligible_count = len([record for record in cursor_records if record.get("eligible_for_discovery")])
    packet = _cursor_packet(
        target,
        selected,
        selected_position if selected_position >= 0 else 0,
        work_item_report.get("report_path") or "<executor-response-work-item-report>",
    )
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_inbox_cursor_state": state,
        "executor_response_inbox_cursor_created": status in {"PASS", "ATTENTION"},
        "executor_response_inbox_cursor_ready": ready,
        "selected_claim_packet_id": target.get("claim_packet_id") or "",
        "selected_source_target_path": target.get("source_target_path") or "",
        "selected_source_after_sha256": target.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "selected_executor_response_packet_path": selected.get("path") or "",
        "selected_executor_response_packet_sha256": selected.get("candidate_sha256") or "",
        "cursor_checkpoint_key": selected.get("candidate_sha256") or selected.get("path") or "",
        "cursor_position": selected_position,
        "candidate_response_packet_count": len(records),
        "ready_response_packet_count": int(index_report.get("ready_response_packet_count") or 0),
        "eligible_response_packet_count": eligible_count,
        "selected_executor_response_packet_count": selected_count,
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "candidate_response_packet_count": len(records),
            "ready_response_packet_count": int(index_report.get("ready_response_packet_count") or 0),
            "eligible_response_packet_count": eligible_count,
            "selected_executor_response_packet_count": selected_count,
            "skipped_anchor_mismatch_response_packet_count": counts[
                "skipped_anchor_mismatch_response_packet_count"
            ],
            "skipped_consumed_response_packet_count": counts["skipped_consumed_response_packet_count"],
            "skipped_in_progress_response_packet_count": counts[
                "skipped_in_progress_response_packet_count"
            ],
            "skipped_duplicate_response_packet_count": counts["skipped_duplicate_response_packet_count"],
            "skipped_rejected_response_packet_count": counts["skipped_rejected_response_packet_count"],
            "skipped_forbidden_response_packet_count": counts["skipped_forbidden_response_packet_count"],
            "validation_issue_count": len(issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "expected_anchor": expected_anchor,
        "cursor_records": cursor_records,
        "previous_cursor_checkpoint_key": previous_report.get("cursor_checkpoint_key") or "",
        "selected_executor_response_packet_safe_preview": selected.get("safe_preview") or {},
        "executor_response_inbox_cursor_packet": packet,
        "executor_response_inbox_index_report": index_report,
        "executor_response_work_item_report": work_item_report,
        "boundary": [
            "This command selects one unconsumed local executor response packet from an existing inbox index.",
            "It only advances packets whose claim/source/upload anchors match the selected work item and skips duplicate, consumed, in-progress, rejected, forbidden, or stale-anchor records.",
            "It writes local cursor/checkpoint reports only; it does not read secrets, log into portals, upload, email, final-submit, mutate source/package/archive state, merge, commit, or call providers/models.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Inbox Cursor",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_inbox_cursor_state') or ''}",
        f"- Selected claim: `{report.get('selected_claim_packet_id') or ''}`",
        f"- Selected response: `{report.get('selected_executor_response_packet_path') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
