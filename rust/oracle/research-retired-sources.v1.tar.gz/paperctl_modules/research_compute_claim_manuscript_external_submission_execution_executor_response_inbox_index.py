"""Index local executor response packets without consuming them."""

import datetime as dt

from paperctl_modules import (
    research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake
    as intake,
)


COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-inbox-index"

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_INDEX_CLEAR"
)
READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_INDEX_READY"
)
NO_READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_INBOX_INDEX_NO_READY_PACKETS"
)
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

INBOX_INDEX_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_inbox_index.v1"
)

DISCOVERY_READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_PACKET_DISCOVERY_READY_FOR_CONTRACT"
)
CONTRACT_READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_READY_FOR_INTAKE"
)
INTAKE_READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_READY"
)
GATE_PERFORMED_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
)
TERMINAL_PERFORMED_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_PERFORMED_EVIDENCE_ACCEPTED"
)

FORBIDDEN_RESPONSE_KEYS = [
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _anchor_from_response(response):
    response = intake._normalize_executor_response_packet(response or {})
    return {
        "claim_packet_id": response.get("claim_packet_id") or "",
        "source_target_path": response.get("source_target_path") or "",
        "source_after_sha256": response.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": response.get("upload_artifact_manifest_sha256") or "",
    }


def _anchor_key(anchor):
    anchor = anchor or {}
    return "|".join(
        [
            anchor.get("claim_packet_id") or "",
            anchor.get("source_target_path") or "",
            anchor.get("source_after_sha256") or "",
            anchor.get("upload_manifest_csv_sha256") or "",
        ]
    )


def _safe_preview(response):
    response = intake._normalize_executor_response_packet(response or {})
    if not response:
        return {}
    return {
        "packet_type": response.get("packet_type") or "",
        "packet_schema": response.get("packet_schema") or "",
        "executor_response_state": response.get("executor_response_state") or "",
        "executor_response_completed": bool(response.get("executor_response_completed")),
        "template_is_response": bool(response.get("template_is_response")),
        "record_only_fixture": bool(response.get("record_only_fixture")),
        "claim_packet_id": response.get("claim_packet_id") or "",
        "slug": response.get("slug") or "",
        "source_target_path": response.get("source_target_path") or "",
        "source_after_sha256": response.get("source_after_sha256") or "",
        "upload_artifact_manifest_sha256": response.get("upload_artifact_manifest_sha256") or "",
        "external_action_performed": bool(response.get("external_action_performed")),
        "portal_login_performed": bool(response.get("portal_login_performed")),
        "upload_performed": bool(response.get("upload_performed")),
        "email_performed": bool(response.get("email_performed")),
        "final_submit_performed": bool(response.get("final_submit_performed")),
    }


def _candidate_record(path, sha256_value, raw):
    issues = []
    response = intake._normalize_executor_response_packet(raw or {})
    if not response:
        _add_issue(issues, "executor_response_packet_missing_or_unrecognized")
    else:
        if response.get("packet_type") != "claim_manuscript_external_submission_execution_performed_evidence_executor_response":
            _add_issue(issues, "executor_response_packet_type_mismatch", response.get("packet_type") or "")
        if response.get("packet_schema") != intake.EXECUTOR_RESPONSE_PACKET_SCHEMA:
            _add_issue(issues, "executor_response_packet_schema_mismatch", response.get("packet_schema") or "")
        if response.get("executor_response_completed") is not True:
            _add_issue(issues, "executor_response_not_marked_complete")
        if response.get("template_is_response") is True:
            _add_issue(issues, "executor_response_template_marker_must_remain_false")
        if response.get("record_only_fixture"):
            _add_issue(issues, "record_only_fixture_not_allowed_for_inbox_index")
        for key in FORBIDDEN_RESPONSE_KEYS:
            if response.get(key):
                _add_issue(issues, f"forbidden_executor_response_boundary:{key}")
        if intake._secret_like_value(response):
            _add_issue(issues, "forbidden_secret_like_executor_response_material")
        anchor = _anchor_from_response(response)
        if not anchor.get("claim_packet_id"):
            _add_issue(issues, "executor_response_anchor_missing:claim_packet_id")
        if not anchor.get("source_after_sha256"):
            _add_issue(issues, "executor_response_anchor_missing:source_after_sha256")

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    return {
        "path": path or "",
        "candidate_sha256": sha256_value or "",
        "candidate_status": "READY" if response and not issues else ("FORBIDDEN" if forbidden else "REJECTED"),
        "anchor": _anchor_from_response(response),
        "anchor_key": _anchor_key(_anchor_from_response(response)),
        "executor_response_completed": bool(response.get("executor_response_completed")) if response else False,
        "safe_preview": _safe_preview(response),
        "consumed_by": [],
        "validation_issues": issues,
    }


def _dedupe_key(record):
    return record.get("candidate_sha256") or record.get("path") or record.get("anchor_key") or ""


def _report_sha_or_path(report, sha_key, path_key):
    report = report or {}
    return report.get(sha_key) or report.get(path_key) or ""


def _consumption_markers(consuming_reports):
    markers = {}
    performed_evidence_to_response = {}
    for report in consuming_reports or []:
        report = report or {}
        command = report.get("command") or ""
        if command.endswith("executor-response-packet-discovery"):
            if report.get("executor_response_packet_discovery_state") == DISCOVERY_READY_STATE:
                key = _report_sha_or_path(
                    report,
                    "selected_executor_response_packet_sha256",
                    "selected_executor_response_packet_path",
                )
                if key:
                    markers.setdefault(key, []).append("selected_by_discovery")
        elif command.endswith("executor-response-contract"):
            key = _report_sha_or_path(report, "executor_response_packet_sha256", "executor_response_packet_path")
            if key:
                marker = "contract_ready" if report.get("executor_response_contract_state") == CONTRACT_READY_STATE else "contract_seen"
                markers.setdefault(key, []).append(marker)
        elif command.endswith("performed-evidence-intake"):
            key = _report_sha_or_path(report, "executor_response_packet_sha256", "executor_response_packet_path")
            if key:
                marker = "intake_ready" if report.get("performed_evidence_intake_state") == INTAKE_READY_STATE else "intake_seen"
                markers.setdefault(key, []).append(marker)
                evidence_sha = report.get("performed_evidence_sha256") or ""
                if evidence_sha:
                    performed_evidence_to_response[evidence_sha] = key
        elif command.endswith("execution-gate"):
            evidence_sha = report.get("performed_evidence_sha256") or ""
            key = performed_evidence_to_response.get(evidence_sha) or ""
            if key and report.get("claim_manuscript_external_submission_execution_gate_state") == GATE_PERFORMED_STATE:
                markers.setdefault(key, []).append("gate_recorded")
        elif command.endswith("terminal-status"):
            evidence_sha = report.get("performed_evidence_sha256") or ""
            key = performed_evidence_to_response.get(evidence_sha) or ""
            if key and report.get("claim_manuscript_external_submission_execution_terminal_status_state") == TERMINAL_PERFORMED_STATE:
                markers.setdefault(key, []).append("terminal_accepted")
    return markers


def _index_packet(records):
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_inbox_index",
        "packet_schema": INBOX_INDEX_PACKET_SCHEMA,
        "indexed_response_packet_count": len(records),
        "ready_response_packet_count": len([record for record in records if record.get("candidate_status") == "READY"]),
        "response_packet_records": [
            {
                "path": record.get("path") or "",
                "candidate_sha256": record.get("candidate_sha256") or "",
                "candidate_status": record.get("candidate_status") or "",
                "anchor": record.get("anchor") or {},
                "consumed_by": list(record.get("consumed_by") or []),
            }
            for record in records
        ],
    }


def build_executor_response_inbox_index(candidate_packets=None, consuming_reports=None, label=""):
    records = []
    for item in candidate_packets or []:
        records.append(
            _candidate_record(
                item.get("path") or "",
                item.get("sha256") or "",
                item.get("packet") or {},
            )
        )

    seen = {}
    for record in records:
        key = _dedupe_key(record)
        if not key:
            continue
        if key in seen and record.get("candidate_status") == "READY":
            record["candidate_status"] = "DUPLICATE"
            record["duplicate_of_path"] = seen[key].get("path") or ""
            record["duplicate_of_sha256"] = seen[key].get("candidate_sha256") or ""
        else:
            seen[key] = record

    markers = _consumption_markers(consuming_reports or [])
    for record in records:
        keys = [
            record.get("candidate_sha256") or "",
            record.get("path") or "",
        ]
        consumed = []
        for key in keys:
            for marker in markers.get(key, []):
                if marker not in consumed:
                    consumed.append(marker)
        record["consumed_by"] = consumed
        if any(marker in consumed for marker in ["intake_ready", "gate_recorded", "terminal_accepted"]):
            record["consumption_status"] = "CONSUMED"
        elif consumed:
            record["consumption_status"] = "IN_PROGRESS"
        else:
            record["consumption_status"] = "UNCONSUMED"

    ready_records = [record for record in records if record.get("candidate_status") == "READY"]
    duplicate_records = [record for record in records if record.get("candidate_status") == "DUPLICATE"]
    rejected_records = [record for record in records if record.get("candidate_status") == "REJECTED"]
    forbidden_records = [record for record in records if record.get("candidate_status") == "FORBIDDEN"]
    consumed_records = [record for record in records if record.get("consumption_status") == "CONSUMED"]

    if forbidden_records:
        status = "FAIL"
        state = FORBIDDEN_STATE
        next_stage = "external_submission_execution_executor_response_waiting"
    elif ready_records:
        status = "PASS"
        state = READY_STATE
        next_stage = "external_submission_execution_executor_response_packet_discovery"
    elif records:
        status = "PASS"
        state = NO_READY_STATE
        next_stage = "external_submission_execution_executor_response_waiting"
    else:
        status = "PASS"
        state = CLEAR_STATE
        next_stage = "external_submission_execution_executor_response_waiting"

    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_inbox_index_state": state,
        "executor_response_inbox_index_created": True,
        "executor_response_inbox_index_ready": status == "PASS",
        "candidate_response_packet_count": len(records),
        "unique_response_packet_count": len(records) - len(duplicate_records),
        "ready_response_packet_count": len(ready_records),
        "duplicate_response_packet_count": len(duplicate_records),
        "rejected_response_packet_count": len(rejected_records),
        "forbidden_response_packet_count": len(forbidden_records),
        "consumed_response_packet_count": len(consumed_records),
        "next_agent_stage": next_stage,
        "next_agent_command": (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-packet-discovery --write"
            if next_stage == "external_submission_execution_executor_response_packet_discovery"
            else "research-compute-claim-manuscript-external-submission-execution-executor-response-contract --executor-task-report <executor-task-report> --executor-response-packet <executor-response-packet>"
        ),
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "candidate_response_packet_count": len(records),
            "unique_response_packet_count": len(records) - len(duplicate_records),
            "ready_response_packet_count": len(ready_records),
            "duplicate_response_packet_count": len(duplicate_records),
            "rejected_response_packet_count": len(rejected_records),
            "forbidden_response_packet_count": len(forbidden_records),
            "consumed_response_packet_count": len(consumed_records),
            "validation_issue_count": sum(len(record.get("validation_issues") or []) for record in records),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "response_packet_records": records,
        "executor_response_inbox_index_packet": _index_packet(records),
        "boundary": [
            "This command indexes local executor response packets only; it does not consume them or run any external action.",
            "It rejects secret-like, fixture, incomplete, or boundary-mutating response packets and marks duplicate packets by sha/path.",
            "Consumption markers are derived from existing local discovery/contract/intake/gate/terminal reports; no portal login, upload, email, final-submit, source/package/archive mutation, merge, commit, or provider/model call is performed.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Inbox Index",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_inbox_index_state') or ''}",
        f"- Candidate packets: {report.get('candidate_response_packet_count') or 0}",
        f"- Ready packets: {report.get('ready_response_packet_count') or 0}",
        f"- Consumed packets: {report.get('consumed_response_packet_count') or 0}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
