"""Discover safe local executor response packets for a selected work item."""

import datetime as dt
import json

from paperctl_modules import report_ref_health
from paperctl_modules import (
    research_compute_claim_manuscript_external_submission_execution_executor_response_work_item
    as work_item_core,
)
from paperctl_modules import (
    research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake
    as intake,
)


COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-packet-discovery"
)

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_PACKET_DISCOVERY_CLEAR"
)
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_PACKET_DISCOVERY_WAITING_FOR_RESPONSE_PACKET"
)
READY_FOR_CONTRACT_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_PACKET_DISCOVERY_READY_FOR_CONTRACT"
)
ATTENTION_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_PACKET_DISCOVERY_ATTENTION"
)
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

DISCOVERY_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_packet_discovery.v1"
)

FORBIDDEN_RESPONSE_KEYS = [
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    if not report:
        return
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _selected_target(report):
    report = report or {}
    packet = report.get("executor_response_work_item_packet") or {}
    target = report.get("selected_executor_response_target") or {}
    out = {}
    for source in [target, packet, report]:
        for key in [
            "claim_packet_id",
            "slug",
            "source_target_path",
            "source_after_sha256",
            "upload_manifest_csv_sha256",
            "executor_task_report_path",
            "executor_task_report_sha256",
            "next_contract_command",
        ]:
            if not out.get(key) and source.get(key):
                out[key] = source.get(key)
    return out


def _anchor_from_target(target):
    target = target or {}
    return {
        "claim_packet_id": target.get("claim_packet_id") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
    }


def _anchor_from_response(response):
    response = intake._normalize_executor_response_packet(response or {})
    return {
        "claim_packet_id": response.get("claim_packet_id") or "",
        "source_target_path": response.get("source_target_path") or "",
        "source_after_sha256": response.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": response.get("upload_artifact_manifest_sha256") or "",
    }


def _anchor_complete(anchor):
    anchor = anchor or {}
    return bool(anchor.get("claim_packet_id") and anchor.get("source_after_sha256"))


def _anchor_matches(expected, observed):
    expected = expected or {}
    observed = observed or {}
    if not _anchor_complete(expected):
        return False
    for key in [
        "claim_packet_id",
        "source_target_path",
        "source_after_sha256",
        "upload_manifest_csv_sha256",
    ]:
        expected_value = expected.get(key) or ""
        observed_value = observed.get(key) or ""
        if expected_value and observed_value and expected_value != observed_value:
            return False
    return True


def _safe_preview(response):
    response = intake._normalize_executor_response_packet(response or {})
    if not response:
        return {}
    return {
        "packet_type": response.get("packet_type") or "",
        "packet_schema": response.get("packet_schema") or "",
        "executor_response_state": response.get("executor_response_state") or "",
        "executor_response_completed": bool(response.get("executor_response_completed")),
        "template_is_response": bool(response.get("template_is_response")),
        "record_only_fixture": bool(response.get("record_only_fixture")),
        "claim_packet_id": response.get("claim_packet_id") or "",
        "slug": response.get("slug") or "",
        "source_target_path": response.get("source_target_path") or "",
        "source_after_sha256": response.get("source_after_sha256") or "",
        "upload_artifact_manifest_sha256": response.get("upload_artifact_manifest_sha256") or "",
        "external_action_performed": bool(response.get("external_action_performed")),
        "portal_login_performed": bool(response.get("portal_login_performed")),
        "upload_performed": bool(response.get("upload_performed")),
        "email_performed": bool(response.get("email_performed")),
        "final_submit_performed": bool(response.get("final_submit_performed")),
    }


def _candidate_record(path, raw, expected_anchor):
    issues = []
    response = intake._normalize_executor_response_packet(raw or {})
    if not response:
        _add_issue(issues, "executor_response_packet_missing_or_unrecognized")
    else:
        if response.get("packet_type") != "claim_manuscript_external_submission_execution_performed_evidence_executor_response":
            _add_issue(issues, "executor_response_packet_type_mismatch", response.get("packet_type") or "")
        if response.get("packet_schema") != intake.EXECUTOR_RESPONSE_PACKET_SCHEMA:
            _add_issue(issues, "executor_response_packet_schema_mismatch", response.get("packet_schema") or "")
        if response.get("executor_response_completed") is not True:
            _add_issue(issues, "executor_response_not_marked_complete")
        if response.get("template_is_response") is True:
            _add_issue(issues, "executor_response_template_marker_must_remain_false")
        if response.get("record_only_fixture"):
            _add_issue(issues, "record_only_fixture_not_allowed_for_response_discovery")
        for key in FORBIDDEN_RESPONSE_KEYS:
            if response.get(key):
                _add_issue(issues, f"forbidden_executor_response_boundary:{key}")
        if intake._secret_like_value(response):
            _add_issue(issues, "forbidden_secret_like_executor_response_material")
        if not _anchor_matches(expected_anchor, _anchor_from_response(response)):
            _add_issue(issues, "executor_response_anchor_mismatch")
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    return {
        "path": path or "",
        "candidate_sha256": "",
        "candidate_status": "READY" if response and not issues else ("FORBIDDEN" if forbidden else "REJECTED"),
        "anchor_match": bool(response and _anchor_matches(expected_anchor, _anchor_from_response(response))),
        "executor_response_completed": bool(response.get("executor_response_completed")) if response else False,
        "safe_preview": _safe_preview(response),
        "validation_issues": issues,
    }


def _discovery_packet(target, selected):
    if not selected:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_packet_discovery",
        "packet_schema": DISCOVERY_PACKET_SCHEMA,
        "claim_packet_id": target.get("claim_packet_id") or "",
        "slug": target.get("slug") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": target.get("executor_task_report_path") or "",
        "executor_task_report_sha256": target.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": selected.get("path") or "",
        "executor_response_packet_sha256": selected.get("candidate_sha256") or "",
        "next_dispatch_command": (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item-dispatch"
            " --executor-response-work-item-report <executor-response-work-item-report>"
            f" --executor-response-packet {selected.get('path') or '<executor-response-packet>'}"
        ),
        "next_contract_command": (target.get("next_contract_command") or "").replace(
            "<executor-response-packet>",
            selected.get("path") or "<executor-response-packet>",
        ),
    }


def build_executor_response_packet_discovery(
    executor_response_work_item_report=None,
    candidate_packets=None,
    label="",
):
    work_item = executor_response_work_item_report or {}
    candidate_packets = list(candidate_packets or [])
    issues = []
    work_item_clear = bool(
        work_item.get("executor_response_work_item_state")
        == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_CLEAR"
        and work_item.get("status") == "PASS"
        and _validation_issue_count(work_item) == 0
    )
    _add_report_ref_health_issues(
        issues,
        "executor_response_work_item",
        work_item,
        work_item_core.COMMAND,
    )
    if not work_item:
        _add_issue(issues, "executor_response_work_item_report_required")
    elif work_item.get("command") != work_item_core.COMMAND:
        _add_issue(issues, "executor_response_work_item_command_mismatch", work_item.get("command") or "")
    elif work_item.get("status") != "PASS":
        _add_issue(issues, "executor_response_work_item_not_pass", work_item.get("status") or "")
    elif not work_item.get("executor_response_work_item_ready") and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_not_ready")
    if _validation_issue_count(work_item):
        _add_issue(issues, "executor_response_work_item_validation_issues_present")

    target = {} if work_item_clear else _selected_target(work_item)
    expected_anchor = _anchor_from_target(target)
    if work_item and not target and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_target_missing")
    elif target and not _anchor_complete(expected_anchor):
        _add_issue(issues, "executor_response_work_item_anchor_incomplete")

    records = []
    if not issues:
        for item in candidate_packets:
            record = _candidate_record(item.get("path") or "", item.get("packet") or {}, expected_anchor)
            record["candidate_sha256"] = item.get("sha256") or ""
            records.append(record)

    matching_ready = [record for record in records if record.get("candidate_status") == "READY"]
    forbidden_records = [record for record in records if record.get("candidate_status") == "FORBIDDEN"]
    selected = matching_ready[0] if matching_ready else {}
    if forbidden_records:
        state = FORBIDDEN_STATE
        status = "FAIL"
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = target.get("next_contract_command") or ""
        ready = False
    elif issues:
        state = ATTENTION_STATE
        status = "ATTENTION"
        next_stage = "external_submission_execution_executor_response_work_item"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item --write"
        )
        ready = False
    elif work_item_clear:
        state = CLEAR_STATE
        status = "PASS"
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
        ready = False
    elif not target:
        state = CLEAR_STATE
        status = "PASS"
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
        ready = False
    elif selected:
        state = READY_FOR_CONTRACT_STATE
        status = "PASS"
        next_stage = "external_submission_execution_executor_response_contract"
        next_command = (target.get("next_contract_command") or "").replace(
            "<executor-response-packet>",
            selected.get("path") or "<executor-response-packet>",
        )
        ready = True
    else:
        state = WAITING_STATE
        status = "PASS"
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = target.get("next_contract_command") or ""
        ready = True

    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_packet_discovery_state": state,
        "executor_response_packet_discovery_created": status in {"PASS", "ATTENTION"},
        "executor_response_packet_discovery_ready": ready,
        "selected_claim_packet_id": target.get("claim_packet_id") or "",
        "selected_source_target_path": target.get("source_target_path") or "",
        "selected_source_after_sha256": target.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "selected_executor_response_packet_path": selected.get("path") or "",
        "selected_executor_response_packet_sha256": selected.get("candidate_sha256") or "",
        "matching_executor_response_packet_count": len(matching_ready),
        "candidate_response_packet_count": len(records),
        "rejected_response_packet_count": len([record for record in records if record.get("candidate_status") == "REJECTED"]),
        "forbidden_response_packet_count": len(forbidden_records),
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "candidate_response_packet_count": len(records),
            "matching_executor_response_packet_count": len(matching_ready),
            "selected_executor_response_packet_count": 1 if selected else 0,
            "rejected_response_packet_count": len([record for record in records if record.get("candidate_status") == "REJECTED"]),
            "forbidden_response_packet_count": len(forbidden_records),
            "validation_issue_count": len(issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "expected_anchor": expected_anchor,
        "candidate_response_packets": records,
        "selected_executor_response_packet_safe_preview": selected.get("safe_preview") or {},
        "executor_response_packet_discovery_packet": _discovery_packet(target, selected),
        "executor_response_work_item_report": work_item,
        "boundary": [
            "This command discovers local executor response packets only; it does not execute external actions.",
            "It accepts only completed, non-secret, non-fixture response packets whose claim/source/upload anchors match the selected work item.",
            "A discovered packet is only routed to executor-response-contract; performed-evidence intake and gate acceptance remain separate checks.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Packet Discovery",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_packet_discovery_state') or ''}",
        f"- Selected claim: `{report.get('selected_claim_packet_id') or ''}`",
        f"- Selected response: `{report.get('selected_executor_response_packet_path') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
