"""Turn executor-response waiting status into a local retry/escalation action."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-escalation"
)

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_CLEAR"
)
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_WAITING"
)
RETRY_DUE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_RETRY_DUE"
)
STALE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_STALE"
)
READY_FOR_DISCOVERY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_READY_FOR_DISCOVERY"
)
FOLLOW_DISPATCH_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_FOLLOW_DISPATCH"
)
ATTENTION_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_ESCALATION_ATTENTION"
)
WAITING_STATUS_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-status"
)

WAITING_ESCALATION_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_waiting_escalation.v1"
)

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    if not report:
        return
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)

LOCAL_RETRY_SCAN_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-inbox-index --write"
)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _compact_mapping(mapping):
    out = {}
    for key, value in (mapping or {}).items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[key] = value
    return out


def _compact_report(report):
    out = {}
    for key, value in (report or {}).items():
        if key.endswith("_report") or key.endswith("_reports"):
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[key] = value
        elif key in {"summary", "selected_executor_response_target"} and isinstance(value, dict):
            out[key] = _compact_mapping(value)
        elif key.endswith("_ref") and isinstance(value, dict):
            out[key] = _compact_mapping(value)
    return out


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _anchor(report):
    report = report or {}
    return {
        "claim_packet_id": report.get("claim_packet_id") or report.get("selected_claim_packet_id") or "",
        "source_target_path": report.get("source_target_path") or report.get("selected_source_target_path") or "",
        "source_after_sha256": report.get("source_after_sha256") or report.get("selected_source_after_sha256") or "",
        "upload_manifest_csv_sha256": (
            report.get("upload_manifest_csv_sha256")
            or report.get("selected_upload_manifest_csv_sha256")
            or report.get("upload_artifact_manifest_sha256")
            or ""
        ),
    }


def _anchor_complete(anchor):
    anchor = anchor or {}
    return bool(anchor.get("claim_packet_id") and anchor.get("source_after_sha256"))


def _anchor_matches(expected, observed):
    expected = expected or {}
    observed = observed or {}
    if not _anchor_complete(expected):
        return False
    for key in [
        "claim_packet_id",
        "source_target_path",
        "source_after_sha256",
        "upload_manifest_csv_sha256",
    ]:
        expected_value = expected.get(key) or ""
        observed_value = observed.get(key) or ""
        if expected_value and observed_value and expected_value != observed_value:
            return False
    return True


def _same_anchor(left, right):
    return _anchor_matches(left, right) and _anchor_matches(right, left)


def _refresh_count(waiting_status, previous):
    expected = _anchor(waiting_status)
    previous_anchor = _anchor(previous)
    if previous and _same_anchor(expected, previous_anchor):
        return int(previous.get("waiting_escalation_refresh_count") or 0) + 1
    return 1 if _anchor_complete(expected) else 0


def _packet(waiting_status, state, action, next_stage, next_command, refresh_count):
    anchor = _anchor(waiting_status)
    if not _anchor_complete(anchor):
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_waiting_escalation",
        "packet_schema": WAITING_ESCALATION_PACKET_SCHEMA,
        "claim_packet_id": anchor.get("claim_packet_id") or "",
        "slug": waiting_status.get("slug") or "",
        "source_target_path": anchor.get("source_target_path") or "",
        "source_after_sha256": anchor.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": anchor.get("upload_manifest_csv_sha256") or "",
        "waiting_status_state": waiting_status.get("executor_response_waiting_status_state") or "",
        "waiting_age_minutes": int(waiting_status.get("waiting_age_minutes") or 0),
        "retry_due": bool(waiting_status.get("retry_due")),
        "stale_waiting": bool(waiting_status.get("stale_waiting")),
        "blocked_reason": waiting_status.get("blocked_reason") or "",
        "waiting_escalation_state": state or "",
        "waiting_escalation_action": action or "",
        "waiting_escalation_refresh_count": int(refresh_count or 0),
        "next_agent_stage": next_stage or "",
        "next_agent_command": next_command or "",
    }


def build_executor_response_waiting_escalation(
    executor_response_waiting_status_report=None,
    previous_waiting_escalation_report=None,
    label="",
):
    waiting_status = executor_response_waiting_status_report or {}
    previous = previous_waiting_escalation_report or {}
    waiting_summary = _summary(waiting_status)
    issues = []

    _add_report_ref_health_issues(
        issues,
        "executor_response_waiting_status",
        waiting_status,
        WAITING_STATUS_COMMAND,
    )
    if not waiting_status:
        _add_issue(issues, "executor_response_waiting_status_report_required")
    elif waiting_status.get("status") != "PASS":
        _add_issue(issues, "executor_response_waiting_status_not_pass", waiting_status.get("status") or "")
    if _validation_issue_count(waiting_status):
        _add_issue(issues, "executor_response_waiting_status_validation_issues_present")

    for key in FORBIDDEN_KEYS:
        if waiting_status.get(key):
            _add_issue(issues, f"forbidden_waiting_status_boundary:{key}")
        if previous.get(key):
            _add_issue(issues, f"forbidden_previous_waiting_escalation_boundary:{key}")

    anchor = _anchor(waiting_status)
    waiting_ready = bool(waiting_status.get("executor_response_waiting_status_ready"))
    if waiting_status and waiting_ready and not _anchor_complete(anchor):
        _add_issue(issues, "executor_response_waiting_status_anchor_incomplete")

    retry_due = bool(waiting_status.get("retry_due"))
    stale = bool(waiting_status.get("stale_waiting"))
    waiting_age_minutes = int(
        waiting_status.get("waiting_age_minutes")
        or waiting_summary.get("waiting_age_minutes")
        or 0
    )
    retry_after_minutes = int(waiting_status.get("retry_after_minutes") or 0)
    stale_after_minutes = int(waiting_status.get("stale_after_minutes") or 0)
    cursor_selected_count = int(
        waiting_status.get("cursor_selected_count")
        or waiting_summary.get("cursor_selected_count")
        or 0
    )
    ready_for_discovery_count = int(waiting_summary.get("ready_for_discovery_count") or 0)
    dispatch_route = waiting_status.get("dispatch_route") or ""
    waiting_next_stage = waiting_status.get("next_agent_stage") or ""
    waiting_next_command = waiting_status.get("next_agent_command") or ""
    blocked_reason = waiting_status.get("blocked_reason") or ""
    refresh_count = _refresh_count(waiting_status, previous)

    if issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        ready = False
        action = "repair_waiting_status"
        escalation_level = "attention"
        next_stage = "external_submission_execution_executor_response_waiting_status"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-status --write"
        )
        route_reason = "validation_issue"
    elif not waiting_ready or not _anchor_complete(anchor):
        status = "PASS"
        state = CLEAR_STATE
        ready = False
        action = "clear"
        escalation_level = "none"
        next_stage = waiting_next_stage or "claim_draft"
        next_command = waiting_next_command
        route_reason = "no_waiting_target"
    elif ready_for_discovery_count or cursor_selected_count or waiting_next_stage == "external_submission_execution_executor_response_packet_discovery":
        status = "PASS"
        state = READY_FOR_DISCOVERY_STATE
        ready = True
        action = "process_selected_packet"
        escalation_level = "none"
        next_stage = waiting_next_stage or "external_submission_execution_executor_response_packet_discovery"
        next_command = waiting_next_command
        route_reason = "cursor_selected_packet"
    elif waiting_next_stage and waiting_next_stage != "external_submission_execution_executor_response_waiting":
        status = "PASS"
        state = FOLLOW_DISPATCH_STATE
        ready = True
        action = "follow_dispatch_route"
        escalation_level = "none"
        next_stage = waiting_next_stage
        next_command = waiting_next_command
        route_reason = blocked_reason or f"dispatch_route:{dispatch_route}"
    elif stale:
        status = "PASS"
        state = STALE_STATE
        ready = True
        action = "stale_external_executor_response"
        escalation_level = "stale"
        next_stage = "external_submission_execution_executor_response_waiting_stale"
        next_command = LOCAL_RETRY_SCAN_COMMAND
        route_reason = "waiting_for_external_executor_response_stale"
    elif retry_due:
        status = "PASS"
        state = RETRY_DUE_STATE
        ready = True
        action = "retry_local_inbox_scan"
        escalation_level = "retry"
        next_stage = "external_submission_execution_executor_response_retry_due"
        next_command = LOCAL_RETRY_SCAN_COMMAND
        route_reason = "waiting_for_external_executor_response_retry_due"
    else:
        status = "PASS"
        state = WAITING_STATE
        ready = True
        action = "wait_for_external_executor_response"
        escalation_level = "none"
        next_stage = waiting_next_stage or "external_submission_execution_executor_response_waiting"
        next_command = waiting_next_command
        route_reason = blocked_reason or "waiting_for_external_executor_response"

    packet = _packet(waiting_status, state, action, next_stage, next_command, refresh_count)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_waiting_escalation_state": state,
        "executor_response_waiting_escalation_created": status in {"PASS", "ATTENTION"},
        "executor_response_waiting_escalation_ready": ready,
        "selected_claim_packet_id": anchor.get("claim_packet_id") or "",
        "selected_source_target_path": anchor.get("source_target_path") or "",
        "selected_source_after_sha256": anchor.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": anchor.get("upload_manifest_csv_sha256") or "",
        "waiting_status_state": waiting_status.get("executor_response_waiting_status_state") or "",
        "waiting_status_ready": waiting_ready,
        "waiting_age_minutes": waiting_age_minutes,
        "retry_after_minutes": retry_after_minutes,
        "stale_after_minutes": stale_after_minutes,
        "retry_due": retry_due,
        "stale_waiting": stale,
        "blocked_reason": blocked_reason,
        "waiting_escalation_action": action,
        "waiting_escalation_level": escalation_level,
        "waiting_escalation_route_reason": route_reason,
        "waiting_escalation_refresh_count": refresh_count,
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "waiting_escalation_ready_count": 1 if ready else 0,
            "waiting_escalation_waiting_count": 1 if state == WAITING_STATE else 0,
            "waiting_escalation_retry_due_count": 1 if state == RETRY_DUE_STATE else 0,
            "waiting_escalation_stale_count": 1 if state == STALE_STATE else 0,
            "waiting_escalation_ready_for_discovery_count": 1 if state == READY_FOR_DISCOVERY_STATE else 0,
            "waiting_escalation_follow_dispatch_count": 1 if state == FOLLOW_DISPATCH_STATE else 0,
            "waiting_escalation_local_retry_scan_count": 1 if action == "retry_local_inbox_scan" else 0,
            "waiting_escalation_stale_external_response_count": 1 if action == "stale_external_executor_response" else 0,
            "waiting_age_minutes": waiting_age_minutes,
            "waiting_escalation_refresh_count": refresh_count,
            "validation_issue_count": len(issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "executor_response_waiting_escalation_packet": packet,
        "executor_response_waiting_status_report": _compact_report(waiting_status),
        "previous_waiting_escalation_report": _compact_report(previous),
        "boundary": [
            "This command converts one executor-response waiting-status report into a local retry/escalation work item.",
            "Retry and stale routes only point to local report refresh or waiting states.",
            "It does not contact an external executor, read secrets, log into portals, upload, email, final-submit, mutate source/package/archive state, merge, commit, or call providers/models.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Waiting Escalation",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_waiting_escalation_state') or ''}",
        f"- Action: `{report.get('waiting_escalation_action') or ''}`",
        f"- Waiting age minutes: {report.get('waiting_age_minutes') or 0}",
        f"- Route reason: `{report.get('waiting_escalation_route_reason') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
