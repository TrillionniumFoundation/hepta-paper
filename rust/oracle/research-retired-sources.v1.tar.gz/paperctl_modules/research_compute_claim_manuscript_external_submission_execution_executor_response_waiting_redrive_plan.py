"""Plan local executor-response waiting redrive attempts without external action."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-redrive-plan"
)

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_CLEAR"
)
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_WAITING"
)
LOCAL_REDRIVE_PLANNED_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_LOCAL_REDRIVE_PLANNED"
)
STALE_REDRIVE_PLANNED_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_STALE_REDRIVE_PLANNED"
)
READY_FOR_DISCOVERY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_READY_FOR_DISCOVERY"
)
FOLLOW_DISPATCH_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_FOLLOW_DISPATCH"
)
ATTENTION_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_REDRIVE_PLAN_ATTENTION"
)
WAITING_SCHEDULER_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-scheduler"
)
WAITING_SCHEDULER_CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_SCHEDULER_CLEAR"
)

WAITING_REDRIVE_PLAN_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_waiting_redrive_plan.v1"
)

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    if not report:
        return
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)

LOCAL_INBOX_REDRIVE_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-inbox-index --write"
)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _compact_mapping(mapping):
    out = {}
    for key, value in (mapping or {}).items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[key] = value
    return out


def _compact_report(report):
    out = {}
    for key, value in (report or {}).items():
        if key.endswith("_report") or key.endswith("_reports"):
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[key] = value
        elif key in {"summary", "selected_executor_response_target"} and isinstance(value, dict):
            out[key] = _compact_mapping(value)
        elif key.endswith("_ref") and isinstance(value, dict):
            out[key] = _compact_mapping(value)
    return out


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _waiting_scheduler_clear(report):
    report = report or {}
    return bool(
        report.get("status") == "PASS"
        and report.get("executor_response_waiting_scheduler_state") == WAITING_SCHEDULER_CLEAR_STATE
        and not report.get("executor_response_waiting_scheduler_ready")
        and _validation_issue_count(report) == 0
    )


def _int(value):
    try:
        return int(value or 0)
    except (TypeError, ValueError):
        return 0


def _anchor(report):
    report = report or {}
    return {
        "claim_packet_id": report.get("claim_packet_id") or report.get("selected_claim_packet_id") or "",
        "source_target_path": report.get("source_target_path") or report.get("selected_source_target_path") or "",
        "source_after_sha256": report.get("source_after_sha256") or report.get("selected_source_after_sha256") or "",
        "upload_manifest_csv_sha256": (
            report.get("upload_manifest_csv_sha256")
            or report.get("selected_upload_manifest_csv_sha256")
            or report.get("upload_artifact_manifest_sha256")
            or ""
        ),
    }


def _anchor_complete(anchor):
    anchor = anchor or {}
    return bool(anchor.get("claim_packet_id") and anchor.get("source_after_sha256"))


def _anchor_matches(expected, observed):
    expected = expected or {}
    observed = observed or {}
    if not _anchor_complete(expected):
        return False
    for key in [
        "claim_packet_id",
        "source_target_path",
        "source_after_sha256",
        "upload_manifest_csv_sha256",
    ]:
        expected_value = expected.get(key) or ""
        observed_value = observed.get(key) or ""
        if expected_value and observed_value and expected_value != observed_value:
            return False
    return True


def _same_anchor(left, right):
    return _anchor_matches(left, right) and _anchor_matches(right, left)


def _previous_attempt_count(waiting_scheduler, previous):
    if previous and _same_anchor(_anchor(waiting_scheduler), _anchor(previous)):
        return _int(previous.get("waiting_redrive_plan_attempt_count"))
    return 0


def _packet(
    waiting_scheduler,
    state,
    plan_action,
    route_reason,
    attempt_count,
    local_redrive_due,
    next_stage,
    next_command,
):
    anchor = _anchor(waiting_scheduler)
    if not _anchor_complete(anchor):
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_waiting_redrive_plan",
        "packet_schema": WAITING_REDRIVE_PLAN_PACKET_SCHEMA,
        "claim_packet_id": anchor.get("claim_packet_id") or "",
        "slug": waiting_scheduler.get("slug") or "",
        "source_target_path": anchor.get("source_target_path") or "",
        "source_after_sha256": anchor.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": anchor.get("upload_manifest_csv_sha256") or "",
        "waiting_scheduler_state": waiting_scheduler.get("executor_response_waiting_scheduler_state") or "",
        "waiting_scheduler_action": waiting_scheduler.get("waiting_scheduler_action") or "",
        "waiting_redrive_plan_state": state or "",
        "waiting_redrive_plan_action": plan_action or "",
        "waiting_redrive_plan_route_reason": route_reason or "",
        "waiting_redrive_plan_attempt_count": _int(attempt_count),
        "local_redrive_due": bool(local_redrive_due),
        "waiting_age_minutes": _int(waiting_scheduler.get("waiting_age_minutes")),
        "minutes_until_retry": _int(waiting_scheduler.get("minutes_until_retry")),
        "minutes_until_stale": _int(waiting_scheduler.get("minutes_until_stale")),
        "next_agent_stage": next_stage or "",
        "next_agent_command": next_command or "",
    }


def build_executor_response_waiting_redrive_plan(
    executor_response_waiting_scheduler_report=None,
    previous_waiting_redrive_plan_report=None,
    label="",
):
    waiting_scheduler = executor_response_waiting_scheduler_report or {}
    previous = previous_waiting_redrive_plan_report or {}
    scheduler_summary = _summary(waiting_scheduler)
    issues = []

    _add_report_ref_health_issues(
        issues,
        "executor_response_waiting_scheduler",
        waiting_scheduler,
        WAITING_SCHEDULER_COMMAND,
    )
    if not waiting_scheduler:
        _add_issue(issues, "executor_response_waiting_scheduler_report_required")
    elif waiting_scheduler.get("status") != "PASS":
        _add_issue(
            issues,
            "executor_response_waiting_scheduler_not_pass",
            waiting_scheduler.get("status") or "",
        )
    elif not waiting_scheduler.get("executor_response_waiting_scheduler_ready") and not _waiting_scheduler_clear(
        waiting_scheduler
    ):
        _add_issue(issues, "executor_response_waiting_scheduler_not_ready")
    if _validation_issue_count(waiting_scheduler):
        _add_issue(issues, "executor_response_waiting_scheduler_validation_issues_present")

    for key in FORBIDDEN_KEYS:
        if waiting_scheduler.get(key):
            _add_issue(issues, f"forbidden_waiting_scheduler_boundary:{key}")
        if previous.get(key):
            _add_issue(issues, f"forbidden_previous_waiting_redrive_plan_boundary:{key}")

    anchor = _anchor(waiting_scheduler)
    if waiting_scheduler and waiting_scheduler.get("executor_response_waiting_scheduler_ready") and not _anchor_complete(anchor):
        _add_issue(issues, "executor_response_waiting_scheduler_anchor_incomplete")

    waiting_age_minutes = _int(
        waiting_scheduler.get("waiting_age_minutes")
        or scheduler_summary.get("waiting_age_minutes")
    )
    minutes_until_retry = _int(
        waiting_scheduler.get("minutes_until_retry")
        or scheduler_summary.get("minutes_until_retry")
    )
    minutes_until_stale = _int(
        waiting_scheduler.get("minutes_until_stale")
        or scheduler_summary.get("minutes_until_stale")
    )
    scheduler_action = waiting_scheduler.get("waiting_scheduler_action") or ""
    scheduler_next_stage = waiting_scheduler.get("next_agent_stage") or ""
    scheduler_next_command = waiting_scheduler.get("next_agent_command") or ""
    previous_attempt_count = _previous_attempt_count(waiting_scheduler, previous)

    if issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        ready = False
        plan_action = "repair_waiting_scheduler"
        next_stage = "external_submission_execution_executor_response_waiting_scheduler"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-scheduler --write"
        )
        route_reason = "validation_issue"
        local_redrive_due = False
        attempt_count = previous_attempt_count
    elif scheduler_action == "process_selected_packet":
        status = "PASS"
        state = READY_FOR_DISCOVERY_STATE
        ready = True
        plan_action = "process_selected_packet"
        next_stage = scheduler_next_stage or "external_submission_execution_executor_response_packet_discovery"
        next_command = scheduler_next_command
        route_reason = "cursor_selected_packet"
        local_redrive_due = False
        attempt_count = previous_attempt_count
    elif scheduler_action == "follow_dispatch_route":
        status = "PASS"
        state = FOLLOW_DISPATCH_STATE
        ready = True
        plan_action = "follow_dispatch_route"
        next_stage = scheduler_next_stage or "claim_draft"
        next_command = scheduler_next_command
        route_reason = waiting_scheduler.get("waiting_scheduler_route_reason") or "follow_dispatch_route"
        local_redrive_due = False
        attempt_count = previous_attempt_count
    elif scheduler_action == "mark_stale_waiting_and_refresh_inbox":
        status = "PASS"
        state = STALE_REDRIVE_PLANNED_STATE
        ready = True
        plan_action = "mark_stale_and_run_bounded_local_inbox_redrive"
        next_stage = "external_submission_execution_executor_response_stale_redrive"
        next_command = scheduler_next_command or LOCAL_INBOX_REDRIVE_COMMAND
        route_reason = "waiting_for_external_executor_response_stale"
        local_redrive_due = True
        attempt_count = previous_attempt_count + 1
    elif scheduler_action == "run_local_inbox_refresh":
        status = "PASS"
        state = LOCAL_REDRIVE_PLANNED_STATE
        ready = True
        plan_action = "run_bounded_local_inbox_redrive"
        next_stage = "external_submission_execution_executor_response_local_inbox_redrive"
        next_command = scheduler_next_command or LOCAL_INBOX_REDRIVE_COMMAND
        route_reason = "waiting_for_external_executor_response_retry_due"
        local_redrive_due = True
        attempt_count = previous_attempt_count + 1
    elif not _anchor_complete(anchor):
        status = "PASS"
        state = CLEAR_STATE
        ready = False
        plan_action = "clear"
        next_stage = scheduler_next_stage or "claim_draft"
        next_command = scheduler_next_command
        route_reason = "no_waiting_scheduler_target"
        local_redrive_due = False
        attempt_count = 0
    else:
        status = "PASS"
        state = WAITING_STATE
        ready = True
        plan_action = "wait_until_retry_window"
        next_stage = scheduler_next_stage or "external_submission_execution_executor_response_waiting"
        next_command = scheduler_next_command
        route_reason = waiting_scheduler.get("waiting_scheduler_route_reason") or "waiting_for_external_executor_response"
        local_redrive_due = False
        attempt_count = previous_attempt_count

    packet = _packet(
        waiting_scheduler,
        state,
        plan_action,
        route_reason,
        attempt_count,
        local_redrive_due,
        next_stage,
        next_command,
    )
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_waiting_redrive_plan_state": state,
        "executor_response_waiting_redrive_plan_created": status in {"PASS", "ATTENTION"},
        "executor_response_waiting_redrive_plan_ready": ready,
        "selected_claim_packet_id": anchor.get("claim_packet_id") or "",
        "selected_source_target_path": anchor.get("source_target_path") or "",
        "selected_source_after_sha256": anchor.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": anchor.get("upload_manifest_csv_sha256") or "",
        "waiting_scheduler_state": waiting_scheduler.get("executor_response_waiting_scheduler_state") or "",
        "waiting_scheduler_ready": bool(waiting_scheduler.get("executor_response_waiting_scheduler_ready")),
        "waiting_scheduler_action": scheduler_action,
        "waiting_scheduler_route_reason": waiting_scheduler.get("waiting_scheduler_route_reason") or "",
        "waiting_age_minutes": waiting_age_minutes,
        "minutes_until_retry": minutes_until_retry,
        "minutes_until_stale": minutes_until_stale,
        "waiting_redrive_plan_action": plan_action,
        "waiting_redrive_plan_route_reason": route_reason,
        "waiting_redrive_plan_attempt_count": attempt_count,
        "previous_waiting_redrive_plan_attempt_count": previous_attempt_count,
        "local_redrive_due": local_redrive_due,
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "waiting_redrive_plan_ready_count": 1 if ready else 0,
            "waiting_redrive_plan_waiting_count": 1 if state == WAITING_STATE else 0,
            "waiting_redrive_plan_local_redrive_planned_count": (
                1 if state == LOCAL_REDRIVE_PLANNED_STATE else 0
            ),
            "waiting_redrive_plan_stale_redrive_planned_count": (
                1 if state == STALE_REDRIVE_PLANNED_STATE else 0
            ),
            "waiting_redrive_plan_ready_for_discovery_count": (
                1 if state == READY_FOR_DISCOVERY_STATE else 0
            ),
            "waiting_redrive_plan_follow_dispatch_count": 1 if state == FOLLOW_DISPATCH_STATE else 0,
            "waiting_redrive_plan_local_redrive_due_count": 1 if local_redrive_due else 0,
            "waiting_redrive_plan_local_inbox_refresh_count": 1 if local_redrive_due else 0,
            "waiting_redrive_plan_attempt_count": attempt_count,
            "waiting_redrive_plan_previous_attempt_count": previous_attempt_count,
            "waiting_age_minutes": waiting_age_minutes,
            "minutes_until_retry": minutes_until_retry,
            "minutes_until_stale": minutes_until_stale,
            "validation_issue_count": len(issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "executor_response_waiting_redrive_plan_packet": packet,
        "executor_response_waiting_scheduler_report": _compact_report(waiting_scheduler),
        "previous_waiting_redrive_plan_report": _compact_report(previous),
        "boundary": [
            "This command turns one waiting-scheduler report into a local redrive plan and attempt ledger.",
            "Redrive and stale actions only plan local inbox refresh/report routes.",
            "It does not contact an external executor, read secrets, log into portals, upload, email, final-submit, mutate source/package/archive state, merge, commit, or call providers/models.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Waiting Redrive Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_waiting_redrive_plan_state') or ''}",
        f"- Action: `{report.get('waiting_redrive_plan_action') or ''}`",
        f"- Attempt count: {report.get('waiting_redrive_plan_attempt_count') or 0}",
        f"- Local redrive due: {report.get('local_redrive_due')}",
        f"- Waiting age minutes: {report.get('waiting_age_minutes') or 0}",
        f"- Minutes until retry: {report.get('minutes_until_retry') or 0}",
        f"- Minutes until stale: {report.get('minutes_until_stale') or 0}",
        f"- Route reason: `{report.get('waiting_redrive_plan_route_reason') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
