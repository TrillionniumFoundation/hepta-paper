"""Audit the selected executor-response waiting item without external action."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-waiting-status"
)

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_STATUS_CLEAR"
)
WORK_ITEM_CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_CLEAR"
)
DISPATCH_CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_CLEAR"
)
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_STATUS_WAITING"
)
RETRY_DUE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_STATUS_RETRY_DUE"
)
STALE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_STATUS_STALE"
)
READY_FOR_DISCOVERY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_STATUS_READY_FOR_DISCOVERY"
)
ATTENTION_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WAITING_STATUS_ATTENTION"
)
WORK_ITEM_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item"
)
DISPATCH_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item-dispatch"
)
INBOX_CURSOR_COMMAND = (
    "research-compute-claim-manuscript-external-submission-execution-executor-response-inbox-cursor"
)

WAITING_STATUS_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_waiting_status.v1"
)

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    if not report:
        return
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _compact_mapping(mapping):
    out = {}
    for key, value in (mapping or {}).items():
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[key] = value
    return out


def _compact_report(report):
    out = {}
    for key, value in (report or {}).items():
        if key.endswith("_report") or key.endswith("_reports"):
            continue
        if isinstance(value, (str, int, float, bool)) or value is None:
            out[key] = value
        elif key in {"summary", "selected_executor_response_target"} and isinstance(value, dict):
            out[key] = _compact_mapping(value)
        elif key.endswith("_ref") and isinstance(value, dict):
            out[key] = _compact_mapping(value)
    return out


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _parse_time(value):
    value = str(value or "").strip()
    if not value:
        return None
    normalized = value.replace("Z", "+00:00")
    try:
        parsed = dt.datetime.fromisoformat(normalized)
    except ValueError:
        return None
    if parsed.tzinfo is not None:
        parsed = parsed.astimezone(dt.timezone.utc).replace(tzinfo=None)
    return parsed


def _minutes_between(start, end):
    start_dt = _parse_time(start)
    end_dt = _parse_time(end)
    if not start_dt or not end_dt:
        return 0
    return max(int((end_dt - start_dt).total_seconds() // 60), 0)


def _target(report):
    report = report or {}
    packet = report.get("executor_response_work_item_packet") or {}
    target = report.get("selected_executor_response_target") or {}
    out = {}
    for source in [target, packet, report]:
        for key in [
            "claim_packet_id",
            "slug",
            "source_target_path",
            "source_after_sha256",
            "upload_manifest_csv_sha256",
            "executor_task_report_path",
            "executor_task_report_sha256",
            "next_contract_command",
        ]:
            if not out.get(key) and source.get(key):
                out[key] = source.get(key)
    ref = target.get("report_ref") or packet.get("executor_response_contract_report_ref") or {}
    out["executor_response_contract_report_ref"] = dict(ref or {})
    return out


def _anchor(report):
    report = report or {}
    return {
        "claim_packet_id": report.get("claim_packet_id") or report.get("selected_claim_packet_id") or "",
        "source_target_path": report.get("source_target_path") or report.get("selected_source_target_path") or "",
        "source_after_sha256": report.get("source_after_sha256") or report.get("selected_source_after_sha256") or "",
        "upload_manifest_csv_sha256": (
            report.get("upload_manifest_csv_sha256")
            or report.get("selected_upload_manifest_csv_sha256")
            or report.get("upload_artifact_manifest_sha256")
            or ""
        ),
    }


def _anchor_complete(anchor):
    anchor = anchor or {}
    return bool(anchor.get("claim_packet_id") and anchor.get("source_after_sha256"))


def _anchor_matches(expected, observed):
    expected = expected or {}
    observed = observed or {}
    if not _anchor_complete(expected):
        return False
    for key in [
        "claim_packet_id",
        "source_target_path",
        "source_after_sha256",
        "upload_manifest_csv_sha256",
    ]:
        expected_value = expected.get(key) or ""
        observed_value = observed.get(key) or ""
        if expected_value and observed_value and expected_value != observed_value:
            return False
    return True


def _same_anchor(left, right):
    return _anchor_matches(left, right) and _anchor_matches(right, left)


def _first_waiting_at(target, work_item_report, dispatch_report, previous_report):
    if not target:
        return ""
    expected = _anchor(target)
    previous_anchor = _anchor(previous_report)
    if previous_report and _same_anchor(expected, previous_anchor):
        prior = previous_report.get("first_waiting_at") or ""
        if prior:
            return prior
    ref = target.get("executor_response_contract_report_ref") or {}
    for value in [
        ref.get("created_at"),
        work_item_report.get("created_at"),
        dispatch_report.get("created_at"),
    ]:
        if value:
            return value
    return ""


def _refresh_count(target, previous_report):
    expected = _anchor(target)
    previous_anchor = _anchor(previous_report)
    if previous_report and _same_anchor(expected, previous_anchor):
        return int(previous_report.get("waiting_status_refresh_count") or 0) + 1
    return 1 if target else 0


def _packet(target, state, next_stage, next_command, first_waiting_at, age_minutes, retry_due, stale):
    if not target:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_waiting_status",
        "packet_schema": WAITING_STATUS_PACKET_SCHEMA,
        "claim_packet_id": target.get("claim_packet_id") or "",
        "slug": target.get("slug") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": target.get("executor_task_report_path") or "",
        "executor_task_report_sha256": target.get("executor_task_report_sha256") or "",
        "waiting_status_state": state or "",
        "first_waiting_at": first_waiting_at or "",
        "waiting_age_minutes": int(age_minutes or 0),
        "retry_due": bool(retry_due),
        "stale_waiting": bool(stale),
        "next_agent_stage": next_stage or "",
        "next_agent_command": next_command or "",
    }


def build_executor_response_waiting_status(
    executor_response_work_item_report=None,
    executor_response_work_item_dispatch_report=None,
    executor_response_inbox_cursor_report=None,
    previous_waiting_status_report=None,
    label="",
    now="",
    retry_after_minutes=1440,
    stale_after_minutes=4320,
):
    work_item = executor_response_work_item_report or {}
    dispatch = executor_response_work_item_dispatch_report or {}
    cursor = executor_response_inbox_cursor_report or {}
    previous = previous_waiting_status_report or {}
    issues = []
    _add_report_ref_health_issues(
        issues,
        "executor_response_work_item",
        work_item,
        WORK_ITEM_COMMAND,
    )
    _add_report_ref_health_issues(
        issues,
        "executor_response_work_item_dispatch",
        dispatch,
        DISPATCH_COMMAND,
    )
    _add_report_ref_health_issues(
        issues,
        "executor_response_inbox_cursor",
        cursor,
        INBOX_CURSOR_COMMAND,
    )
    work_item_clear = bool(
        work_item.get("executor_response_work_item_state") == WORK_ITEM_CLEAR_STATE
        and work_item.get("status") == "PASS"
        and _validation_issue_count(work_item) == 0
    )
    dispatch_clear = bool(
        dispatch.get("executor_response_work_item_dispatch_state") == DISPATCH_CLEAR_STATE
        and dispatch.get("status") == "PASS"
        and _validation_issue_count(dispatch) == 0
    )

    if not work_item:
        _add_issue(issues, "executor_response_work_item_report_required")
    elif work_item.get("status") != "PASS":
        _add_issue(issues, "executor_response_work_item_not_pass", work_item.get("status") or "")
    elif not work_item.get("executor_response_work_item_ready") and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_not_ready")
    if _validation_issue_count(work_item):
        _add_issue(issues, "executor_response_work_item_validation_issues_present")

    if dispatch:
        if dispatch.get("status") != "PASS":
            _add_issue(issues, "executor_response_work_item_dispatch_not_pass", dispatch.get("status") or "")
        elif not dispatch.get("executor_response_work_item_dispatch_ready") and not dispatch_clear:
            _add_issue(issues, "executor_response_work_item_dispatch_not_ready")
        if _validation_issue_count(dispatch):
            _add_issue(issues, "executor_response_work_item_dispatch_validation_issues_present")

    if cursor and cursor.get("status") != "PASS":
        _add_issue(issues, "executor_response_inbox_cursor_not_pass", cursor.get("status") or "")
    if cursor and _validation_issue_count(cursor):
        _add_issue(issues, "executor_response_inbox_cursor_validation_issues_present")

    for key in FORBIDDEN_KEYS:
        if work_item.get(key):
            _add_issue(issues, f"forbidden_work_item_boundary:{key}")
        if dispatch.get(key):
            _add_issue(issues, f"forbidden_dispatch_boundary:{key}")
        if cursor.get(key):
            _add_issue(issues, f"forbidden_cursor_boundary:{key}")
        if previous.get(key):
            _add_issue(issues, f"forbidden_previous_waiting_status_boundary:{key}")

    target = {} if work_item_clear else _target(work_item)
    expected_anchor = _anchor(target)
    if work_item and not target and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_target_missing")
    elif target and not _anchor_complete(expected_anchor):
        _add_issue(issues, "executor_response_work_item_anchor_incomplete")

    dispatch_anchor_match = bool(dispatch and _anchor_matches(expected_anchor, _anchor(dispatch)))
    cursor_anchor_match = bool(cursor and _anchor_matches(expected_anchor, _anchor(cursor)))
    cursor_selected_count = int(
        cursor.get("selected_executor_response_packet_count")
        or _summary(cursor).get("selected_executor_response_packet_count")
        or (1 if cursor.get("selected_executor_response_packet_path") else 0)
    )
    cursor_selected = bool(cursor_selected_count and cursor_anchor_match)
    dispatch_route = dispatch.get("dispatch_route") or ""

    if dispatch and not dispatch_anchor_match and not (work_item_clear and dispatch_clear):
        _add_issue(issues, "executor_response_work_item_dispatch_anchor_mismatch")
    if cursor and cursor_selected_count and not cursor_anchor_match:
        _add_issue(issues, "executor_response_inbox_cursor_selected_anchor_mismatch")

    first_waiting_at = _first_waiting_at(target, work_item, dispatch, previous)
    observed_now = now or ""
    age_minutes = _minutes_between(first_waiting_at, observed_now)
    retry_after_minutes = max(int(retry_after_minutes or 0), 0)
    stale_after_minutes = max(int(stale_after_minutes or 0), 0)
    retry_due = bool(retry_after_minutes and age_minutes >= retry_after_minutes)
    stale = bool(stale_after_minutes and age_minutes >= stale_after_minutes)
    refresh_count = _refresh_count(target, previous)

    if issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        ready = False
        next_stage = "external_submission_execution_executor_response_work_item"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item --write"
        )
        blocked_reason = "validation_issue"
    elif not target:
        status = "PASS"
        state = CLEAR_STATE
        ready = False
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
        blocked_reason = "no_selected_work_item"
    elif cursor_selected:
        status = "PASS"
        state = READY_FOR_DISCOVERY_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_packet_discovery"
        next_command = cursor.get("next_agent_command") or ""
        blocked_reason = ""
    elif dispatch_route and dispatch_route != "waiting":
        status = "PASS"
        state = CLEAR_STATE
        ready = True
        next_stage = dispatch.get("next_agent_stage") or work_item.get("next_agent_stage") or ""
        next_command = dispatch.get("next_agent_command") or work_item.get("next_agent_command") or ""
        blocked_reason = f"dispatch_route:{dispatch_route}"
    elif stale:
        status = "PASS"
        state = STALE_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = dispatch.get("next_agent_command") or work_item.get("next_agent_command") or ""
        blocked_reason = "waiting_for_external_executor_response_stale"
    elif retry_due:
        status = "PASS"
        state = RETRY_DUE_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = dispatch.get("next_agent_command") or work_item.get("next_agent_command") or ""
        blocked_reason = "waiting_for_external_executor_response_retry_due"
    else:
        status = "PASS"
        state = WAITING_STATE
        ready = True
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = dispatch.get("next_agent_command") or work_item.get("next_agent_command") or ""
        blocked_reason = "waiting_for_external_executor_response"

    packet = _packet(target, state, next_stage, next_command, first_waiting_at, age_minutes, retry_due, stale)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_waiting_status_state": state,
        "executor_response_waiting_status_created": status in {"PASS", "ATTENTION"},
        "executor_response_waiting_status_ready": ready,
        "selected_claim_packet_id": target.get("claim_packet_id") or "",
        "selected_source_target_path": target.get("source_target_path") or "",
        "selected_source_after_sha256": target.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "dispatch_route": dispatch_route,
        "dispatch_anchor_match": dispatch_anchor_match,
        "cursor_anchor_match": cursor_anchor_match,
        "cursor_selected_count": cursor_selected_count,
        "first_waiting_at": first_waiting_at,
        "observed_at": observed_now,
        "waiting_age_minutes": age_minutes,
        "retry_after_minutes": retry_after_minutes,
        "stale_after_minutes": stale_after_minutes,
        "retry_due": retry_due,
        "stale_waiting": stale,
        "waiting_status_refresh_count": refresh_count,
        "blocked_reason": blocked_reason,
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "waiting_status_ready_count": 1 if ready else 0,
            "waiting_for_executor_response_count": 1 if state in {WAITING_STATE, RETRY_DUE_STATE, STALE_STATE} else 0,
            "retry_due_count": 1 if state == RETRY_DUE_STATE else 0,
            "stale_waiting_count": 1 if state == STALE_STATE else 0,
            "ready_for_discovery_count": 1 if state == READY_FOR_DISCOVERY_STATE else 0,
            "cursor_selected_count": cursor_selected_count if cursor_anchor_match else 0,
            "waiting_age_minutes": age_minutes,
            "waiting_status_refresh_count": refresh_count,
            "validation_issue_count": len(issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "selected_executor_response_target": target,
        "executor_response_waiting_status_packet": packet,
        "executor_response_work_item_report": _compact_report(work_item),
        "executor_response_work_item_dispatch_report": _compact_report(dispatch),
        "executor_response_inbox_cursor_report": _compact_report(cursor),
        "previous_waiting_status_report": _compact_report(previous),
        "boundary": [
            "This command audits one selected executor-response waiting item and chooses the next local route.",
            "It records waiting age, retry due, stale status, blocked reason, and refresh count only.",
            "It does not contact an external executor, read secrets, log into portals, upload, email, final-submit, mutate source/package/archive state, merge, commit, or call providers/models.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Waiting Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_waiting_status_state') or ''}",
        f"- Selected claim: `{report.get('selected_claim_packet_id') or ''}`",
        f"- Waiting age minutes: {report.get('waiting_age_minutes') or 0}",
        f"- Blocked reason: `{report.get('blocked_reason') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
