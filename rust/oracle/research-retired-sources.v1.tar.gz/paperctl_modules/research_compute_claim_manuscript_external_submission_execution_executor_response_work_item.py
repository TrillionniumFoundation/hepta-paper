"""Select one executor-response backlog item for the next agent step."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item"

CLEAR_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_CLEAR"
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_WAITING_FOR_EXECUTOR_RESPONSE"
)
READY_FOR_INTAKE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_READY_FOR_INTAKE"
)
READY_FOR_GATE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_READY_FOR_GATE"
)
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_ATTENTION"
BACKLOG_COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-backlog"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _count(report, key):
    return int((report or {}).get(key) or _summary(report).get(key) or 0)


def _select(items, preferred_claim_packet_id=""):
    items = list(items or [])
    if preferred_claim_packet_id:
        for item in items:
            if item.get("claim_packet_id") == preferred_claim_packet_id:
                return item
        return {}
    return items[0] if items else {}


def _target(item, category):
    item = dict(item or {})
    return {
        "category": category,
        "claim_packet_id": item.get("claim_packet_id") or "",
        "slug": item.get("slug") or "",
        "source_target_path": item.get("source_target_path") or "",
        "source_after_sha256": item.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": item.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": item.get("executor_task_report_path") or "",
        "executor_task_report_sha256": item.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": item.get("executor_response_packet_path") or "",
        "executor_response_packet_sha256": item.get("executor_response_packet_sha256") or "",
        "performed_evidence_path": item.get("performed_evidence_path") or "",
        "performed_evidence_sha256": item.get("performed_evidence_sha256") or "",
        "executor_response_contract_state": item.get("executor_response_contract_state") or "",
        "executor_response_contract_ready": bool(item.get("executor_response_contract_ready")),
        "waiting_for_executor_response": bool(item.get("waiting_for_executor_response")),
        "response_packet_present": bool(item.get("response_packet_present")),
        "response_ready_for_intake": bool(item.get("response_ready_for_intake")),
        "validation_issue_count": int(item.get("validation_issue_count") or 0),
        "next_intake_command": item.get("next_intake_command") or "",
        "next_gate_command_after_intake": item.get("next_gate_command_after_intake") or "",
        "report_ref": item.get("report_ref") or {},
        "performed_evidence_intake_report_ref": item.get("performed_evidence_intake_report_ref") or {},
    }


def _next_contract_command(target):
    task_path = (target or {}).get("executor_task_report_path") or "<executor-task-report>"
    return (
        "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"
        f" --executor-task-report {task_path}"
        " --executor-response-packet <executor-response-packet>"
    )


def _work_item_packet(target, next_stage, next_command):
    if not target:
        return {}
    return {
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_work_item.v1",
        "work_item_type": target.get("category") or "",
        "claim_packet_id": target.get("claim_packet_id") or "",
        "slug": target.get("slug") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": target.get("executor_task_report_path") or "",
        "executor_task_report_sha256": target.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": target.get("executor_response_packet_path") or "",
        "executor_response_packet_sha256": target.get("executor_response_packet_sha256") or "",
        "performed_evidence_path": target.get("performed_evidence_path") or "",
        "performed_evidence_sha256": target.get("performed_evidence_sha256") or "",
        "executor_response_contract_report_ref": target.get("report_ref") or {},
        "performed_evidence_intake_report_ref": target.get("performed_evidence_intake_report_ref") or {},
        "next_contract_command": _next_contract_command(target),
        "next_intake_command": target.get("next_intake_command") or "",
        "next_gate_command_after_intake": target.get("next_gate_command_after_intake") or "",
        "next_agent_stage": next_stage or "",
        "next_agent_command": next_command or "",
        "expected_safe_response_fields": [
            "portal_session_ref_or_safe_attestation",
            "upload_artifact_manifest_sha256",
            "submission_confirmation_id_or_terminal_status",
            "external_action_started_at",
            "external_action_finished_at",
            "external_action_performed",
        ],
        "forbidden_response_material": [
            "secrets",
            "tokens",
            "cookies",
            "credentials",
            "source mutations",
            "commits",
            "provider/model calls performed by paperctl",
        ],
    }


def build_executor_response_work_item(backlog_report=None, label="", preferred_claim_packet_id=""):
    backlog_report = backlog_report or {}
    preferred_claim_packet_id = preferred_claim_packet_id or ""
    validation_issues = []
    if not backlog_report:
        validation_issues.append({"issue": "executor_response_backlog_report_required"})
    elif (backlog_report.get("command") or "") not in {
        "",
        "research-compute-claim-manuscript-external-submission-execution-executor-response-backlog",
    }:
        validation_issues.append({"issue": "executor_response_backlog_command_mismatch"})
    elif backlog_report.get("status") != "PASS":
        validation_issues.append({"issue": "executor_response_backlog_not_pass", "detail": backlog_report.get("status") or ""})
    if backlog_report:
        _add_report_ref_health_issues(validation_issues, "executor_response_backlog", backlog_report, BACKLOG_COMMAND)
    if _validation_issue_count(backlog_report):
        validation_issues.append({"issue": "executor_response_backlog_validation_issues_present"})
    for key in FORBIDDEN_KEYS:
        if backlog_report.get(key):
            validation_issues.append({"issue": f"forbidden_boundary:{key}"})
    count_lists = [
        ("pending_executor_response_count", "pending_executor_responses"),
        ("ready_for_intake_count", "ready_for_intake_contracts"),
        ("ready_for_gate_count", "ready_for_gate_contracts"),
    ]
    for count_key, list_key in count_lists:
        declared = _count(backlog_report, count_key)
        actual = len(backlog_report.get(list_key) or [])
        if declared > actual:
            validation_issues.append(
                {
                    "issue": f"executor_response_backlog_count_exceeds_items:{count_key}",
                    "detail": f"{declared}>{actual}",
                }
            )
    for list_key in [
        "pending_executor_responses",
        "ready_for_intake_contracts",
        "ready_for_gate_contracts",
    ]:
        for item in backlog_report.get(list_key) or []:
            if _validation_issue_count(item):
                validation_issues.append(
                    {
                        "issue": f"executor_response_backlog_item_validation_issues_present:{list_key}",
                        "detail": item.get("claim_packet_id") or "",
                    }
                )

    selected = {}
    if not validation_issues:
        selected = _select(backlog_report.get("ready_for_gate_contracts") or [], preferred_claim_packet_id)
        category = "ready_for_gate" if selected else ""
        if not selected:
            selected = _select(backlog_report.get("ready_for_intake_contracts") or [], preferred_claim_packet_id)
            category = "ready_for_intake" if selected else ""
        if not selected:
            selected = _select(backlog_report.get("pending_executor_responses") or [], preferred_claim_packet_id)
            category = "pending_executor_response" if selected else ""
    else:
        category = ""

    target = _target(selected, category) if selected else {}
    if category == "ready_for_gate":
        state = READY_FOR_GATE_STATE
        next_stage = "external_submission_execution_gate"
        next_command = target.get("next_gate_command_after_intake") or backlog_report.get("next_agent_command") or ""
        ready = True
    elif category == "ready_for_intake":
        state = READY_FOR_INTAKE_STATE
        next_stage = "external_submission_execution_performed_evidence_intake"
        next_command = target.get("next_intake_command") or backlog_report.get("next_agent_command") or ""
        ready = True
    elif category == "pending_executor_response":
        state = WAITING_STATE
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = _next_contract_command(target)
        ready = True
    elif validation_issues:
        state = ATTENTION_STATE
        next_stage = "external_submission_execution_executor_response_backlog"
        next_command = "research-compute-claim-manuscript-external-submission-execution-executor-response-backlog --write"
        ready = False
    else:
        state = CLEAR_STATE
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
        ready = False

    packet = _work_item_packet(target, next_stage, next_command)
    status = "ATTENTION" if validation_issues else "PASS"
    preferred_claim_packet_id_matched = bool(
        preferred_claim_packet_id
        and target
        and target.get("claim_packet_id") == preferred_claim_packet_id
    )
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_work_item_state": state,
        "executor_response_work_item_created": bool(not validation_issues),
        "executor_response_work_item_ready": ready,
        "preferred_claim_packet_id": preferred_claim_packet_id,
        "preferred_claim_packet_id_matched": preferred_claim_packet_id_matched,
        "selected_category": category,
        "selected_claim_packet_id": target.get("claim_packet_id") or "",
        "selected_source_target_path": target.get("source_target_path") or "",
        "selected_source_after_sha256": target.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "pending_executor_response_count": _count(backlog_report, "pending_executor_response_count"),
            "ready_for_intake_count": _count(backlog_report, "ready_for_intake_count"),
            "ready_for_gate_count": _count(backlog_report, "ready_for_gate_count"),
            "selected_work_item_count": 1 if target else 0,
            "validation_issue_count": len(validation_issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": validation_issues,
        "selected_executor_response_target": target,
        "executor_response_work_item_packet": packet,
        "executor_response_backlog_report": backlog_report,
        "boundary": [
            "This command selects one local executor-response backlog item for the next agent step.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "A pending work item is a non-secret waiting target for a separate real external executor response; it is not performed evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Work Item",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_work_item_state') or ''}",
        f"- Preferred claim: `{report.get('preferred_claim_packet_id') or ''}`",
        f"- Selected claim: `{report.get('selected_claim_packet_id') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
