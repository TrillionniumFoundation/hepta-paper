"""Route a selected executor-response work item to the next local gate."""

import datetime as dt

from paperctl_modules import research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake as intake
from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item-dispatch"

CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_CLEAR"
)
WORK_ITEM_CLEAR_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_CLEAR"
)
WAITING_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_WAITING_FOR_EXECUTOR_RESPONSE"
)
READY_FOR_CONTRACT_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_READY_FOR_CONTRACT"
)
READY_FOR_INTAKE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_READY_FOR_INTAKE"
)
READY_FOR_GATE_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_READY_FOR_GATE"
)
CLOSED_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_CLOSED"
)
ATTENTION_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_WORK_ITEM_DISPATCH_ATTENTION"
)

CONTRACT_READY_STATE = (
    "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_READY_FOR_INTAKE"
)
INTAKE_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_READY"
GATE_PERFORMED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
WORK_ITEM_COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item"
CONTRACT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"
INTAKE_COMMAND = "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake"
GATE_COMMAND = "research-compute-claim-manuscript-external-submission-execution-gate"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

DISPATCH_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_response_work_item_dispatch.v1"
)

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _clean_pass(report):
    report = report or {}
    return bool(report.get("status") == "PASS" and _validation_issue_count(report) == 0)


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    if not report:
        return
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [item for item in ref_issues if not str(item.get("issue") or "").endswith("_summary_not_clean")]
    issues.extend(ref_issues)


def _selected_target(report):
    report = report or {}
    packet = report.get("executor_response_work_item_packet") or {}
    target = report.get("selected_executor_response_target") or {}
    out = {}
    for source in [target, packet, report]:
        for key in [
            "claim_packet_id",
            "slug",
            "source_target_path",
            "source_after_sha256",
            "upload_manifest_csv_sha256",
            "executor_task_report_path",
            "executor_task_report_sha256",
            "executor_response_packet_path",
            "executor_response_packet_sha256",
            "performed_evidence_path",
            "performed_evidence_sha256",
            "next_contract_command",
            "next_intake_command",
            "next_gate_command_after_intake",
        ]:
            if not out.get(key) and source.get(key):
                out[key] = source.get(key)
    return out


def _anchor(report):
    report = report or {}
    return {
        "claim_packet_id": report.get("claim_packet_id") or "",
        "source_target_path": report.get("source_target_path") or "",
        "source_after_sha256": report.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": (
            report.get("upload_manifest_csv_sha256")
            or report.get("upload_artifact_manifest_sha256")
            or ""
        ),
    }


def _anchor_matches(expected, observed):
    expected = expected or {}
    observed = observed or {}
    required_keys = ["claim_packet_id", "source_after_sha256"]
    if not all(expected.get(key) for key in required_keys):
        return False
    for key in ["claim_packet_id", "source_target_path", "source_after_sha256", "upload_manifest_csv_sha256"]:
        expected_value = expected.get(key) or ""
        observed_value = observed.get(key) or ""
        if expected_value and observed_value and expected_value != observed_value:
            return False
    return True


def _command_with_response(command, response_packet_path):
    command = command or (
        "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"
        " --executor-task-report <executor-task-report>"
        " --executor-response-packet <executor-response-packet>"
    )
    if response_packet_path:
        command = command.replace("<executor-response-packet>", response_packet_path)
    return command


def _command_with_evidence(command, performed_evidence_path):
    command = command or (
        "research-compute-claim-manuscript-external-submission-execution-gate"
        " --performed-evidence <external-submission-performed-evidence.json>"
    )
    if performed_evidence_path:
        command = command.replace("<external-submission-performed-evidence.json>", performed_evidence_path)
        command = command.replace("<sidecar>", performed_evidence_path)
    return command


def _response_anchor(response_packet):
    response = intake._normalize_executor_response_packet(response_packet or {})
    return {
        "claim_packet_id": response.get("claim_packet_id") or "",
        "source_target_path": response.get("source_target_path") or "",
        "source_after_sha256": response.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": response.get("upload_artifact_manifest_sha256") or "",
    }


def _validate_response_packet(response_packet, expected_anchor, issues):
    response = intake._normalize_executor_response_packet(response_packet or {})
    if not response:
        return {}
    if response.get("packet_type") != "claim_manuscript_external_submission_execution_performed_evidence_executor_response":
        _add_issue(issues, "executor_response_packet_type_mismatch", response.get("packet_type") or "")
    if response.get("packet_schema") != intake.EXECUTOR_RESPONSE_PACKET_SCHEMA:
        _add_issue(issues, "executor_response_packet_schema_mismatch", response.get("packet_schema") or "")
    if response.get("executor_response_completed") is not True:
        _add_issue(issues, "executor_response_not_marked_complete")
    if response.get("template_is_response") is True:
        _add_issue(issues, "executor_response_template_marker_must_remain_false")
    if response.get("record_only_fixture"):
        _add_issue(issues, "record_only_fixture_not_allowed_for_dispatch")
    for key in FORBIDDEN_KEYS:
        if key != "external_action_performed" and response.get(key):
            _add_issue(issues, f"forbidden_executor_response_boundary:{key}")
    if intake._secret_like_value(response):
        _add_issue(issues, "forbidden_secret_like_executor_response_material")
    if not _anchor_matches(expected_anchor, _response_anchor(response)):
        _add_issue(issues, "executor_response_anchor_mismatch")
    return response


def _report_ready_for_intake(report, expected_anchor):
    report = report or {}
    return bool(
        _clean_pass(report)
        and report.get("executor_response_contract_state") == CONTRACT_READY_STATE
        and report.get("executor_response_contract_ready")
        and _anchor_matches(expected_anchor, _anchor(report))
    )


def _report_ready_for_gate(report, expected_anchor):
    report = report or {}
    return bool(
        _clean_pass(report)
        and report.get("performed_evidence_intake_state") == INTAKE_READY_STATE
        and report.get("performed_evidence_intake_ready")
        and _anchor_matches(expected_anchor, _anchor(report))
    )


def _gate_closed(report, expected_anchor):
    report = report or {}
    return bool(
        _clean_pass(report)
        and report.get("claim_manuscript_external_submission_execution_gate_state") == GATE_PERFORMED_STATE
        and report.get("external_submission_execution_gate_ready")
        and report.get("performed_evidence_recorded")
        and not report.get("record_only_fixture")
        and _anchor_matches(expected_anchor, _anchor(report))
    )


def _dispatch_packet(target, route, next_stage, next_command, response_path, contract_report, intake_report, gate_report):
    if not target:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_response_work_item_dispatch",
        "packet_schema": DISPATCH_PACKET_SCHEMA,
        "dispatch_route": route or "",
        "claim_packet_id": target.get("claim_packet_id") or "",
        "slug": target.get("slug") or "",
        "source_target_path": target.get("source_target_path") or "",
        "source_after_sha256": target.get("source_after_sha256") or "",
        "upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "executor_task_report_path": target.get("executor_task_report_path") or "",
        "executor_task_report_sha256": target.get("executor_task_report_sha256") or "",
        "executor_response_packet_path": response_path or target.get("executor_response_packet_path") or "",
        "executor_response_packet_sha256": target.get("executor_response_packet_sha256") or "",
        "executor_response_contract_report_path": (contract_report or {}).get("report_path") or "",
        "performed_evidence_intake_report_path": (intake_report or {}).get("report_path") or "",
        "performed_evidence_path": (intake_report or {}).get("performed_evidence_path") or target.get("performed_evidence_path") or "",
        "execution_gate_report_path": (gate_report or {}).get("report_path") or "",
        "next_agent_stage": next_stage or "",
        "next_agent_command": next_command or "",
    }


def build_executor_response_work_item_dispatch(
    executor_response_work_item_report=None,
    executor_response_packet=None,
    executor_response_packet_path="",
    executor_response_contract_report=None,
    performed_evidence_intake_report=None,
    execution_gate_report=None,
    label="",
):
    work_item = executor_response_work_item_report or {}
    contract_report = executor_response_contract_report or {}
    intake_report = performed_evidence_intake_report or {}
    gate_report = execution_gate_report or {}
    issues = []
    work_item_clear = bool(
        work_item.get("executor_response_work_item_state") == WORK_ITEM_CLEAR_STATE
        and work_item.get("status") == "PASS"
        and _validation_issue_count(work_item) == 0
    )
    if not work_item:
        _add_issue(issues, "executor_response_work_item_report_required")
    elif work_item.get("status") != "PASS":
        _add_issue(issues, "executor_response_work_item_not_pass", work_item.get("status") or "")
    elif not work_item.get("executor_response_work_item_ready") and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_not_ready")
    _add_report_ref_health_issues(issues, "executor_response_work_item", work_item, WORK_ITEM_COMMAND)
    if _validation_issue_count(work_item):
        _add_issue(issues, "executor_response_work_item_validation_issues_present")
    for key in FORBIDDEN_KEYS:
        if work_item.get(key):
            _add_issue(issues, f"forbidden_work_item_boundary:{key}")
        if contract_report.get(key):
            _add_issue(issues, f"forbidden_contract_boundary:{key}")
        if intake_report.get(key):
            _add_issue(issues, f"forbidden_intake_boundary:{key}")
        if key == "external_action_performed":
            continue
        if gate_report.get(key):
            _add_issue(issues, f"forbidden_gate_boundary:{key}")

    target = _selected_target(work_item)
    expected_anchor = _anchor(target)
    if work_item and not target and not work_item_clear:
        _add_issue(issues, "executor_response_work_item_target_missing")
    elif target and not _anchor_matches(expected_anchor, expected_anchor):
        _add_issue(issues, "executor_response_work_item_anchor_incomplete")

    normalized_response = _validate_response_packet(executor_response_packet or {}, expected_anchor, issues)
    response_present = bool(normalized_response)
    contract_ready = _report_ready_for_intake(contract_report, expected_anchor)
    intake_ready = _report_ready_for_gate(intake_report, expected_anchor)
    gate_closed = _gate_closed(gate_report, expected_anchor)
    contract_anchor_match = bool(contract_report and _anchor_matches(expected_anchor, _anchor(contract_report)))
    intake_anchor_match = bool(intake_report and _anchor_matches(expected_anchor, _anchor(intake_report)))
    gate_anchor_match = bool(gate_report and _anchor_matches(expected_anchor, _anchor(gate_report)))
    if contract_anchor_match:
        _add_report_ref_health_issues(issues, "executor_response_contract", contract_report, CONTRACT_COMMAND)
    if intake_anchor_match:
        _add_report_ref_health_issues(issues, "performed_evidence_intake", intake_report, INTAKE_COMMAND)
    if gate_anchor_match:
        _add_report_ref_health_issues(issues, "execution_gate", gate_report, GATE_COMMAND)
    if contract_anchor_match and not _clean_pass(contract_report):
        _add_issue(issues, "executor_response_contract_not_clean_pass")
    if intake_anchor_match and not _clean_pass(intake_report):
        _add_issue(issues, "performed_evidence_intake_not_clean_pass")
    if gate_anchor_match and not _clean_pass(gate_report):
        _add_issue(issues, "execution_gate_not_clean_pass")

    if issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        route = "attention"
        next_stage = "external_submission_execution_executor_response_work_item"
        next_command = (
            "research-compute-claim-manuscript-external-submission-execution-executor-response-work-item --write"
        )
        ready = False
    elif not target:
        status = "PASS"
        state = CLEAR_STATE
        route = "clear"
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
        ready = False
    elif gate_closed:
        status = "PASS"
        state = CLOSED_STATE
        route = "closed"
        next_stage = "claim_draft"
        next_command = "research-compute-claim-idle-loop-orchestrator --execute-evidence --apply-source"
        ready = True
    elif intake_ready or work_item.get("selected_category") == "ready_for_gate":
        status = "PASS"
        state = READY_FOR_GATE_STATE
        route = "gate"
        next_stage = "external_submission_execution_gate"
        evidence_path = intake_report.get("performed_evidence_path") or target.get("performed_evidence_path") or ""
        next_command = _command_with_evidence(
            target.get("next_gate_command_after_intake") or work_item.get("next_agent_command") or "",
            evidence_path,
        )
        ready = True
    elif contract_ready or work_item.get("selected_category") == "ready_for_intake":
        status = "PASS"
        state = READY_FOR_INTAKE_STATE
        route = "intake"
        next_stage = "external_submission_execution_performed_evidence_intake"
        next_command = (
            contract_report.get("next_intake_command")
            or target.get("next_intake_command")
            or work_item.get("next_agent_command")
            or ""
        )
        ready = True
    elif response_present:
        status = "PASS"
        state = READY_FOR_CONTRACT_STATE
        route = "contract"
        next_stage = "external_submission_execution_executor_response_contract"
        next_command = _command_with_response(
            target.get("next_contract_command") or work_item.get("next_agent_command") or "",
            executor_response_packet_path,
        )
        ready = True
    else:
        status = "PASS"
        state = WAITING_STATE
        route = "waiting"
        next_stage = "external_submission_execution_executor_response_waiting"
        next_command = target.get("next_contract_command") or work_item.get("next_agent_command") or ""
        ready = True

    packet = _dispatch_packet(
        target,
        route,
        next_stage,
        next_command,
        executor_response_packet_path,
        contract_report,
        intake_report,
        gate_report,
    )
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_response_work_item_dispatch_state": state,
        "executor_response_work_item_dispatch_created": status in {"PASS", "ATTENTION"},
        "executor_response_work_item_dispatch_ready": ready,
        "dispatch_route": route,
        "selected_claim_packet_id": target.get("claim_packet_id") or "",
        "selected_source_target_path": target.get("source_target_path") or "",
        "selected_source_after_sha256": target.get("source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": target.get("upload_manifest_csv_sha256") or "",
        "executor_response_packet_present": response_present,
        "executor_response_contract_anchor_match": contract_anchor_match,
        "executor_response_contract_ready": contract_ready,
        "performed_evidence_intake_anchor_match": intake_anchor_match,
        "performed_evidence_intake_ready": intake_ready,
        "execution_gate_anchor_match": gate_anchor_match,
        "execution_gate_performed_evidence_closed": gate_closed,
        "next_agent_stage": next_stage,
        "next_agent_command": next_command,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "dispatch_ready_count": 1 if ready else 0,
            "waiting_for_executor_response_count": 1 if state == WAITING_STATE else 0,
            "ready_for_contract_count": 1 if state == READY_FOR_CONTRACT_STATE else 0,
            "ready_for_intake_count": 1 if state == READY_FOR_INTAKE_STATE else 0,
            "ready_for_gate_count": 1 if state == READY_FOR_GATE_STATE else 0,
            "closed_executor_response_count": 1 if state == CLOSED_STATE else 0,
            "executor_response_packet_present_count": 1 if response_present else 0,
            "contract_anchor_match_count": 1 if contract_anchor_match else 0,
            "intake_anchor_match_count": 1 if intake_anchor_match else 0,
            "gate_anchor_match_count": 1 if gate_anchor_match else 0,
            "validation_issue_count": len(issues),
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "selected_executor_response_target": target,
        "executor_response_work_item_dispatch_packet": packet,
        "executor_response_work_item_report": work_item,
        "executor_response_contract_report": contract_report,
        "performed_evidence_intake_report": intake_report,
        "execution_gate_report": gate_report,
        "external_submission_performed_evidence_executor_response_packet": normalized_response,
        "boundary": [
            "This command routes one selected executor-response work item to the next local agent command.",
            "It does not execute contract, performed-evidence intake, execution gate, portal login, upload, email, final submit, merge, commit, or source/package/archive mutation.",
            "A waiting or ready route is command selection only; the downstream gate remains responsible for accepting performed evidence.",
        ],
    }


def markdown(report):
    lines = [
        "# paper_factory Claim External Submission Executor Response Work Item Dispatch",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_response_work_item_dispatch_state') or ''}",
        f"- Route: `{report.get('dispatch_route') or ''}`",
        f"- Selected claim: `{report.get('selected_claim_packet_id') or ''}`",
        f"- Next agent stage: `{report.get('next_agent_stage') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
