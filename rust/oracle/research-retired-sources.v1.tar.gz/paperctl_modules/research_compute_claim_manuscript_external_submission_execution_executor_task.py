"""Create a non-secret task packet for a real external submission executor."""

import datetime as dt

from paperctl_modules import (
    report_ref_health,
    research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake as intake,
)


COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-task"
INTENT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-intent"
HANDOFF_COMMAND = "external-submission-handoff-bundle"
CAPSTONE_COMMAND = "external-submission-readiness-capstone"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_READY"
HANDOFF_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_HANDOFF_REQUIRED"
CAPSTONE_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_CAPSTONE_REQUIRED"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_WAITING_FOR_INTENT"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

INTENT_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_READY"
EXECUTOR_TASK_PACKET_SCHEMA = "paper_factory.research_compute.claim_manuscript_external_submission_execution_executor_task.v1"


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _intent_packet(report):
    return (report or {}).get("external_submission_execution_intent_packet") or {}


def _handoff_packet(report):
    return (report or {}).get("claim_external_submission_handoff_packet") or {}


def _validate_intent(report):
    issues = []
    item = report or {}
    packet = _intent_packet(item)
    _add_report_ref_health_issues(
        issues,
        "execution_intent",
        item,
        INTENT_COMMAND,
    )
    if item.get("command") != INTENT_COMMAND:
        _add_issue(issues, "execution_intent_command_mismatch", item.get("command") or "")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_intent_boundary",
            "invalid_execution_intent_boolean",
        )
        _check_forbidden_boundary(
            issues,
            packet,
            key,
            "forbidden_execution_intent_packet_boundary",
            "invalid_execution_intent_packet_boolean",
        )
    if item.get("claim_manuscript_external_submission_execution_intent_state") != INTENT_READY_STATE:
        _add_issue(
            issues,
            "execution_intent_not_ready",
            item.get("claim_manuscript_external_submission_execution_intent_state") or "",
        )
    if item.get("status") != "PASS":
        _add_issue(issues, "execution_intent_not_pass", item.get("status") or "")
    _require_literal_true(
        issues,
        item,
        "external_submission_execution_intent_ready",
        "execution_intent_ready_flag_missing",
        "invalid_execution_intent_boolean",
    )
    if not packet:
        _add_issue(issues, "execution_intent_packet_missing")
    _require_literal_true(
        issues,
        item,
        "external_action_authorized",
        "external_action_not_authorized_for_executor_task",
        "invalid_execution_intent_boolean",
    )
    _require_literal_true(
        issues,
        packet,
        "external_action_authorized",
        "intent_packet_external_action_not_authorized_for_executor_task",
        "invalid_execution_intent_packet_boolean",
    )
    _require_literal_true(
        issues,
        packet,
        "requires_performed_evidence_before_submit",
        "intent_packet_missing_performed_evidence_requirement",
        "invalid_execution_intent_packet_boolean",
    )
    for key in [
        "claim_packet_id",
        "source_target_path",
        "source_after_sha256",
        "post_apply_verify_report_path",
        "post_apply_verify_report_sha256",
        "execution_preflight_report_path",
        "execution_preflight_report_sha256",
        "portal_capability_label",
    ]:
        if not packet.get(key):
            _add_issue(issues, f"execution_intent_packet_missing:{key}")
    return issues


def _validate_handoff(report, intent_report, packet):
    issues = []
    item = report or {}
    handoff = _handoff_packet(item)
    if not item:
        _add_issue(issues, "external_submission_handoff_bundle_missing")
        return issues
    _add_report_ref_health_issues(
        issues,
        "external_submission_handoff_bundle",
        item,
        HANDOFF_COMMAND,
    )
    if item.get("command") != HANDOFF_COMMAND:
        _add_issue(issues, "external_submission_handoff_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "external_submission_handoff_not_pass", item.get("status") or "")
    _require_literal_true(
        issues,
        item,
        "agent_external_submission_decision_ready",
        "external_submission_handoff_agent_decision_not_ready",
        "invalid_external_submission_handoff_boolean",
    )
    _require_literal_true(
        issues,
        item,
        "external_action_authorized",
        "external_submission_handoff_external_action_not_authorized",
        "invalid_external_submission_handoff_boolean",
    )
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_external_submission_handoff_boundary",
            "invalid_external_submission_handoff_boolean",
        )
    if not handoff:
        _add_issue(issues, "claim_external_submission_handoff_packet_missing")
    for field in ["claim_packet_id", "source_target_path", "source_after_sha256"]:
        expected = intent_report.get(field) or packet.get(field) or ""
        actual = handoff.get(field) or ""
        if expected and actual and actual != expected:
            _add_issue(issues, f"claim_external_handoff_anchor_mismatch:{field}", actual)
    if not item.get("upload_manifest_csv_path"):
        _add_issue(issues, "external_submission_handoff_missing:upload_manifest_csv_path")
    if not item.get("upload_manifest_csv_sha256"):
        _add_issue(issues, "external_submission_handoff_missing:upload_manifest_csv_sha256")
    if not item.get("bundle_zip_path"):
        _add_issue(issues, "external_submission_handoff_missing:bundle_zip_path")
    if not item.get("bundle_zip_sha256"):
        _add_issue(issues, "external_submission_handoff_missing:bundle_zip_sha256")
    return issues


def _validate_capstone(report):
    issues = []
    item = report or {}
    if not item:
        _add_issue(issues, "external_submission_readiness_capstone_missing")
        return issues
    _add_report_ref_health_issues(
        issues,
        "external_submission_readiness_capstone",
        item,
        CAPSTONE_COMMAND,
    )
    if item.get("command") != CAPSTONE_COMMAND:
        _add_issue(issues, "external_submission_capstone_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "external_submission_capstone_not_pass", item.get("status") or "")
    _require_literal_true(
        issues,
        item,
        "agent_external_submission_decision_ready",
        "external_submission_capstone_agent_decision_not_ready",
        "invalid_external_submission_capstone_boolean",
    )
    _require_literal_true(
        issues,
        item,
        "external_action_authorized",
        "external_submission_capstone_external_action_not_authorized",
        "invalid_external_submission_capstone_boolean",
    )
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_external_submission_capstone_boundary",
            "invalid_external_submission_capstone_boolean",
        )
    return issues


def _executor_response_template(intent_report, packet, handoff_report):
    return {
        "packet_type": "claim_manuscript_external_submission_execution_performed_evidence_executor_response",
        "packet_schema": intake.EXECUTOR_RESPONSE_PACKET_SCHEMA,
        "executor_response_state": "EXECUTOR_RESPONSE_TEMPLATE_UNFILLED",
        "executor_response_completed": False,
        "template_is_response": False,
        "record_only_fixture": False,
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "upload_artifact_manifest_sha256": handoff_report.get("upload_manifest_csv_sha256") or "",
        "portal_session_ref_or_safe_attestation": "",
        "submission_confirmation_id_or_terminal_status": "",
        "external_action_started_at": "",
        "external_action_finished_at": "",
        "portal_login_performed": False,
        "upload_performed": False,
        "email_performed": False,
        "final_submit_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
    }


def _executor_task_packet(intent_report, handoff_report, capstone_report, ready):
    if not ready:
        return {}
    packet = _intent_packet(intent_report)
    response_template = _executor_response_template(intent_report, packet, handoff_report)
    intent_path = intent_report.get("report_path") or ""
    return {
        "packet_type": "claim_manuscript_external_submission_execution_executor_task",
        "packet_schema": EXECUTOR_TASK_PACKET_SCHEMA,
        "executor_task_state": READY_STATE,
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "execution_intent_report_path": intent_path,
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "execution_preflight_report_path": packet.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or "",
        "post_apply_verify_report_path": packet.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": packet.get("post_apply_verify_report_sha256") or "",
        "portal_capability_label": packet.get("portal_capability_label") or "",
        "external_submission_handoff_bundle_report_path": handoff_report.get("report_path") or "",
        "external_submission_handoff_bundle_report_sha256": handoff_report.get("report_sha256") or "",
        "external_submission_readiness_capstone_report_path": capstone_report.get("report_path") or "",
        "external_submission_readiness_capstone_report_sha256": capstone_report.get("report_sha256") or "",
        "upload_manifest_csv_path": handoff_report.get("upload_manifest_csv_path") or "",
        "upload_manifest_csv_sha256": handoff_report.get("upload_manifest_csv_sha256") or "",
        "bundle_zip_path": handoff_report.get("bundle_zip_path") or "",
        "bundle_zip_sha256": handoff_report.get("bundle_zip_sha256") or "",
        "required_executor_response_schema": intake.EXECUTOR_RESPONSE_PACKET_SCHEMA,
        "required_performed_evidence_fields": list(intake.REQUIRED_EVIDENCE_FIELDS),
        "executor_response_packet_template": response_template,
        "next_intake_command_template": (
            "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake"
            + (f" --execution-intent-report {intent_path}" if intent_path else " --execution-intent-report <execution-intent-report>")
            + " --executor-task-report <executor-task-report>"
            + " --executor-response-packet <executor-response-packet>"
        ),
        "next_gate_command_template": (
            "research-compute-claim-manuscript-external-submission-execution-gate"
            + (f" --execution-intent-report {intent_path}" if intent_path else " --execution-intent-report <execution-intent-report>")
            + " --performed-evidence <external-submission-performed-evidence.json>"
        ),
        "external_action_authorized": True,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
    }


def research_compute_claim_manuscript_external_submission_execution_executor_task(
    execution_intent_report,
    external_submission_handoff_bundle_report=None,
    external_submission_readiness_capstone_report=None,
    label="",
):
    intent_report = execution_intent_report or {}
    handoff_report = external_submission_handoff_bundle_report or {}
    capstone_report = external_submission_readiness_capstone_report or {}
    packet = _intent_packet(intent_report)
    intent_issues = _validate_intent(intent_report)
    handoff_issues = _validate_handoff(handoff_report, intent_report, packet)
    capstone_issues = _validate_capstone(capstone_report)
    issues = intent_issues + handoff_issues + capstone_issues
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    missing_handoff = any(item.get("issue") == "external_submission_handoff_bundle_missing" for item in handoff_issues)
    missing_capstone = any(item.get("issue") == "external_submission_readiness_capstone_missing" for item in capstone_issues)
    ready = not issues

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif intent_issues:
        status = "ATTENTION"
        state = WAITING_STATE
    elif missing_handoff:
        status = "ATTENTION"
        state = HANDOFF_REQUIRED_STATE
    elif missing_capstone:
        status = "ATTENTION"
        state = CAPSTONE_REQUIRED_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    executor_task = _executor_task_packet(intent_report, handoff_report, capstone_report, ready and status == "PASS")
    response_template = (executor_task.get("executor_response_packet_template") or {}) if executor_task else {}
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "executor_task_state": state,
        "executor_task_created": status in {"PASS", "ATTENTION"},
        "executor_task_ready": bool(executor_task),
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "execution_intent_report_path": intent_report.get("report_path") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "external_submission_handoff_bundle_report_path": handoff_report.get("report_path") or "",
        "external_submission_handoff_bundle_report_sha256": handoff_report.get("report_sha256") or "",
        "external_submission_readiness_capstone_report_path": capstone_report.get("report_path") or "",
        "external_submission_readiness_capstone_report_sha256": capstone_report.get("report_sha256") or "",
        "upload_manifest_csv_path": handoff_report.get("upload_manifest_csv_path") or "",
        "upload_manifest_csv_sha256": handoff_report.get("upload_manifest_csv_sha256") or "",
        "bundle_zip_path": handoff_report.get("bundle_zip_path") or "",
        "bundle_zip_sha256": handoff_report.get("bundle_zip_sha256") or "",
        "external_action_authorized": bool(
            _literal_true(intent_report.get("external_action_authorized"))
            and _literal_true(packet.get("external_action_authorized"))
            and _literal_true(handoff_report.get("external_action_authorized"))
            and _literal_true(capstone_report.get("external_action_authorized"))
        ),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "executor_task_ready_count": 1 if executor_task else 0,
            "executor_response_template_count": 1 if response_template else 0,
            "handoff_required_count": 1 if missing_handoff else 0,
            "capstone_required_count": 1 if missing_capstone else 0,
            "external_action_authorized_count": 1 if (
                _literal_true(intent_report.get("external_action_authorized"))
                and _literal_true(packet.get("external_action_authorized"))
                and _literal_true(handoff_report.get("external_action_authorized"))
                and _literal_true(capstone_report.get("external_action_authorized"))
            ) else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "external_submission_executor_task_packet": executor_task,
        "external_submission_performed_evidence_executor_response_template_packet": response_template,
        "execution_intent_report": intent_report,
        "external_submission_handoff_bundle_report": handoff_report,
        "external_submission_readiness_capstone_report": capstone_report,
        "boundary": [
            "This command prepares a non-secret task packet for a separate real external submission executor.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "The executor task is not performed evidence; the executor must return a response packet that the performed-evidence intake verifies before the gate can accept real external evidence.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_executor_task_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Executor Task",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('executor_task_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Executor task ready: {report.get('executor_task_ready')}",
        f"- External action performed by this command: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("external_submission_executor_task_packet") or {}
    if packet:
        lines.extend(["", "## Executor Task", ""])
        for key in [
            "packet_schema",
            "claim_packet_id",
            "source_target_path",
            "upload_manifest_csv_path",
            "bundle_zip_path",
            "required_executor_response_schema",
            "next_intake_command_template",
        ]:
            lines.append(f"- {key}: {packet.get(key) or ''}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
