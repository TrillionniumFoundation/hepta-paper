"""Gate claim-derived external submission execution evidence intake."""

import datetime as dt
import re

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-gate"
INTENT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-intent"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_RECORD_ONLY_FIXTURE_ACCEPTED"
PERFORMED_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_IDLE_NO_INTENT"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_WAITING_FOR_INTENT"
EVIDENCE_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_EVIDENCE_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

INTENT_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_READY"
INTENT_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_IDLE_NO_PACKET"
INTENT_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_WAITING_FOR_PREFLIGHT"
INTENT_ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_ATTENTION"

REQUIRED_EVIDENCE_FIELDS = [
    "portal_session_ref_or_safe_attestation",
    "upload_artifact_manifest_sha256",
    "submission_confirmation_id_or_terminal_status",
    "external_action_started_at",
    "external_action_finished_at",
]

SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SECRET_LIKE_RE = re.compile(
    r"((password|passwd|token|secret|cookie|api[_-]?key)\s*[:=]|bearer\s+)",
    re.IGNORECASE,
)


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _forbidden_evidence_keys(record_only_fixture):
    keys = [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]
    if not record_only_fixture:
        return keys
    return keys + [
        "external_action_performed",
        "portal_login_performed",
        "upload_performed",
        "email_performed",
        "final_submit_performed",
    ]


def _required_evidence_fields():
    return list(REQUIRED_EVIDENCE_FIELDS)


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _check_boolean_field(issues, item, key, invalid_prefix):
    if key in item and not isinstance(item.get(key), bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(item.get(key)))


def _intent_packet(report):
    return (report or {}).get("external_submission_execution_intent_packet") or {}


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _field(raw):
    return str(raw or "").strip()


def _secret_like_value(raw):
    if isinstance(raw, dict):
        return any(_secret_like_value(value) for value in raw.values())
    if isinstance(raw, (list, tuple, set)):
        return any(_secret_like_value(value) for value in raw)
    return bool(SECRET_LIKE_RE.search(str(raw or "")))


def _missing_evidence_fields(evidence):
    return [key for key in _required_evidence_fields() if not (evidence or {}).get(key)]


def _validate_intent(report):
    issues = []
    item = report or {}
    packet = _intent_packet(item)
    _add_report_ref_health_issues(
        issues,
        "execution_intent",
        item,
        INTENT_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != INTENT_COMMAND:
        _add_issue(issues, "execution_intent_command_mismatch", item.get("command") or "")
    if _validation_issue_count(item):
        _add_issue(issues, "execution_intent_validation_issues_present")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_intent_boundary",
            "invalid_execution_intent_boolean",
        )
        _check_forbidden_boundary(
            issues,
            packet,
            key,
            "forbidden_execution_intent_packet_boundary",
            "invalid_execution_intent_packet_boolean",
        )
    state = item.get("claim_manuscript_external_submission_execution_intent_state") or ""
    if state not in {INTENT_READY_STATE, INTENT_IDLE_STATE, INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
        _add_issue(issues, "execution_intent_state_not_consumable", state)
    if state == INTENT_READY_STATE:
        if item.get("status") != "PASS":
            _add_issue(issues, "execution_intent_ready_not_pass", item.get("status") or "")
        _require_literal_true(
            issues,
            item,
            "external_submission_execution_intent_ready",
            "execution_intent_ready_flag_missing",
            "invalid_execution_intent_boolean",
        )
        if not packet:
            _add_issue(issues, "execution_intent_packet_missing")
        _require_literal_true(
            issues,
            item,
            "external_action_authorized",
            "external_action_not_authorized_for_execution_gate",
            "invalid_execution_intent_boolean",
        )
        _require_literal_true(
            issues,
            packet,
            "external_action_authorized",
            "intent_packet_external_action_not_authorized_for_execution_gate",
            "invalid_execution_intent_packet_boolean",
        )
        _require_literal_true(
            issues,
            packet,
            "requires_performed_evidence_before_submit",
            "intent_packet_missing_performed_evidence_requirement",
            "invalid_execution_intent_packet_boolean",
        )
        for key in [
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "post_apply_verify_report_path",
            "post_apply_verify_report_sha256",
            "execution_preflight_report_path",
            "execution_preflight_report_sha256",
            "portal_capability_label",
        ]:
            if not packet.get(key):
                _add_issue(issues, f"execution_intent_packet_missing:{key}")
    elif item.get("status") not in {"PASS", "ATTENTION"}:
        _add_issue(issues, "execution_intent_not_pass_or_attention", item.get("status") or "")
    return issues


def _validate_performed_evidence(evidence, record_only_fixture, intent_ready, intent_report=None, packet=None):
    issues = []
    if not intent_ready:
        return issues
    if not evidence:
        _add_issue(issues, "performed_evidence_missing")
        return issues
    if record_only_fixture and evidence.get("record_only_fixture") is not True:
        _check_boolean_field(issues, evidence, "record_only_fixture", "invalid_performed_evidence_boolean")
        _add_issue(issues, "record_only_fixture_evidence_flag_required")
    if not record_only_fixture and _literal_true(evidence.get("record_only_fixture")):
        _add_issue(issues, "record_only_fixture_evidence_not_allowed_for_real_performed_evidence")
    elif not record_only_fixture:
        _check_boolean_field(issues, evidence, "record_only_fixture", "invalid_performed_evidence_boolean")
    if _validation_issue_count(evidence):
        _add_issue(issues, "performed_evidence_validation_issues_present")
    for key in [
        "portal_login_performed",
        "upload_performed",
        "email_performed",
        "final_submit_performed",
        "external_action_performed",
    ]:
        _check_boolean_field(issues, evidence, key, "invalid_performed_evidence_boolean")
    if not record_only_fixture and not _literal_true(evidence.get("external_action_performed")):
        _add_issue(issues, "real_performed_evidence_external_action_flag_required")
    for key in _forbidden_evidence_keys(record_only_fixture):
        _check_forbidden_boundary(
            issues,
            evidence,
            key,
            "forbidden_performed_evidence_boundary",
            "invalid_performed_evidence_boolean",
        )
    for key in _missing_evidence_fields(evidence):
        _add_issue(issues, f"performed_evidence_missing:{key}")
    upload_hash = _field(evidence.get("upload_artifact_manifest_sha256"))
    if upload_hash and not SHA256_RE.match(upload_hash):
        _add_issue(issues, "upload_artifact_manifest_sha256_not_sha256", upload_hash)
    if _secret_like_value(evidence):
        _add_issue(issues, "forbidden_secret_like_performed_evidence_material")
    if evidence.get("command") not in {"", None, COMMAND}:
        _add_issue(issues, "performed_evidence_command_mismatch", evidence.get("command") or "")
    intent_report = intent_report or {}
    packet = packet or {}
    expected = {
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "post_apply_verify_report_sha256": (
            intent_report.get("post_apply_verify_report_sha256")
            or packet.get("post_apply_verify_report_sha256")
            or ""
        ),
        "execution_preflight_report_sha256": (
            intent_report.get("execution_preflight_report_sha256")
            or packet.get("execution_preflight_report_sha256")
            or ""
        ),
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
    }
    for key, expected_value in expected.items():
        actual = evidence.get(key) or ""
        if actual and expected_value and actual != expected_value:
            _add_issue(issues, f"performed_evidence_anchor_mismatch:{key}", actual)
    return issues


def _evidence_record(evidence, packet, accepted, intent_report=None):
    if not accepted:
        return {}
    intent_report = intent_report or {}
    record_only = _literal_true(evidence.get("record_only_fixture"))
    return {
        "record_type": (
            "claim_manuscript_external_submission_execution_record_only_fixture"
            if record_only
            else "claim_manuscript_external_submission_execution_performed_evidence"
        ),
        "record_schema": (
            "paper_factory.research_compute.claim_manuscript_external_submission_execution_gate_record_only_fixture.v1"
            if record_only
            else "paper_factory.research_compute.claim_manuscript_external_submission_execution_gate_performed_evidence.v1"
        ),
        "record_only_fixture": record_only,
        "claim_packet_id": packet.get("claim_packet_id") or "",
        "slug": packet.get("slug") or "",
        "source_target_path": packet.get("source_target_path") or "",
        "source_after_sha256": packet.get("source_after_sha256") or "",
        "execution_preflight_report_path": packet.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_sha256": evidence.get("execution_intent_report_sha256") or intent_report.get("report_sha256") or "",
        "portal_session_ref_or_safe_attestation": evidence.get("portal_session_ref_or_safe_attestation") or "",
        "upload_artifact_manifest_sha256": evidence.get("upload_artifact_manifest_sha256") or "",
        "submission_confirmation_id_or_terminal_status": evidence.get("submission_confirmation_id_or_terminal_status") or "",
        "external_action_started_at": evidence.get("external_action_started_at") or "",
        "external_action_finished_at": evidence.get("external_action_finished_at") or "",
        "portal_login_performed": _literal_true(evidence.get("portal_login_performed")),
        "upload_performed": _literal_true(evidence.get("upload_performed")),
        "email_performed": _literal_true(evidence.get("email_performed")),
        "final_submit_performed": _literal_true(evidence.get("final_submit_performed")),
        "external_action_performed": _literal_true(evidence.get("external_action_performed")) and not record_only,
        "secret_material_read_performed": False,
        "evidence_is_not_external_performed_evidence": record_only,
    }


def _performed_evidence_template_packet(intent_report, packet, evidence, state, accepted):
    missing_fields = _missing_evidence_fields(evidence)
    if accepted or state != EVIDENCE_REQUIRED_STATE or not missing_fields:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_performed_evidence_template",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_performed_evidence_template.v1",
        "gate_state": EVIDENCE_REQUIRED_STATE,
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "source_target_path": packet.get("source_target_path") or intent_report.get("source_target_path") or "",
        "source_after_sha256": packet.get("source_after_sha256") or intent_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": packet.get("post_apply_verify_report_path") or intent_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": packet.get("post_apply_verify_report_sha256") or intent_report.get("post_apply_verify_report_sha256") or "",
        "execution_preflight_report_path": packet.get("execution_preflight_report_path") or intent_report.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or intent_report.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_path": intent_report.get("report_path") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "portal_capability_label": packet.get("portal_capability_label") or intent_report.get("portal_capability_label") or "",
        "required_fields": _required_evidence_fields(),
        "missing_fields": missing_fields,
        "supplied_field_presence": {key: bool((evidence or {}).get(key)) for key in _required_evidence_fields()},
        "safe_field_notes": {
            "portal_session_ref_or_safe_attestation": "Use a non-secret local reference or operator attestation. Do not record cookies, passwords, bearer tokens, or session ids.",
            "upload_artifact_manifest_sha256": "Use the sha256 of the local upload artifact manifest actually used by the external operator.",
            "submission_confirmation_id_or_terminal_status": "Use a non-secret portal confirmation id or terminal status label.",
            "external_action_started_at": "Use an ISO-8601 timestamp or local event timestamp for when the external operator started.",
            "external_action_finished_at": "Use an ISO-8601 timestamp or local event timestamp for when the external operator finished.",
        },
        "forbidden_material": [
            "passwords",
            "tokens",
            "cookies",
            "bearer credentials",
            "api keys",
            "portal session secrets",
        ],
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "template_is_not_performed_evidence": True,
    }


def research_compute_claim_manuscript_external_submission_execution_gate(
    execution_intent_report,
    performed_evidence=None,
    record_only_fixture=False,
    label="",
):
    intent_report = execution_intent_report or {}
    evidence = performed_evidence or {}
    record_only_mode = _literal_true(record_only_fixture)
    packet = _intent_packet(intent_report)
    intent_issues = _validate_intent(intent_report)
    intent_state = intent_report.get("claim_manuscript_external_submission_execution_intent_state") or ""
    intent_ready = bool(
        intent_state == INTENT_READY_STATE
        and intent_report.get("status") == "PASS"
        and _literal_true(intent_report.get("external_submission_execution_intent_ready"))
        and packet
    )
    evidence_issues = _validate_performed_evidence(
        evidence,
        record_only_mode,
        intent_ready,
        intent_report=intent_report,
        packet=packet,
    )
    issues = intent_issues + evidence_issues
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif intent_issues:
        status = "ATTENTION"
        if intent_state == INTENT_IDLE_STATE:
            state = IDLE_STATE
        elif intent_state in {INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
            state = WAITING_STATE
        else:
            state = ATTENTION_STATE
    elif intent_state == INTENT_IDLE_STATE:
        status = "ATTENTION" if issues else "PASS"
        state = IDLE_STATE
    elif intent_state in {INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
        status = "ATTENTION" if issues else "PASS"
        state = WAITING_STATE
    elif not intent_ready:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif evidence_issues:
        status = "ATTENTION"
        state = (
            EVIDENCE_REQUIRED_STATE
            if any(str(item.get("issue") or "").startswith("performed_evidence_missing") for item in evidence_issues)
            else ATTENTION_STATE
        )
    else:
        status = "PASS"
        state = READY_STATE

    accepted = bool(status == "PASS" and state == READY_STATE)
    evidence_record = _evidence_record(evidence, packet, accepted, intent_report=intent_report)
    real_performed = bool(accepted and not evidence_record.get("record_only_fixture"))
    if accepted and real_performed:
        state = PERFORMED_READY_STATE
        evidence_record["record_type"] = "claim_manuscript_external_submission_execution_performed_evidence"
        evidence_record["record_schema"] = "paper_factory.research_compute.claim_manuscript_external_submission_execution_gate_performed_evidence.v1"
        evidence_record["external_action_performed"] = True
    template_packet = _performed_evidence_template_packet(intent_report, packet, evidence, state, accepted)
    checks = [
        {"name": "execution_intent_consumable", "status": "PASS" if not intent_issues else "FAIL"},
        {"name": "evidence_mode_selected", "status": "PASS" if (not intent_ready or not evidence or record_only_fixture or real_performed) else "ATTENTION"},
        {"name": "performed_evidence_present", "status": "PASS" if (not intent_ready or evidence) else "ATTENTION"},
        {"name": "performed_evidence_template_available", "status": "PASS" if (not intent_ready or accepted or template_packet) else "ATTENTION"},
        {"name": "external_action_observed_only_with_real_evidence", "status": "PASS" if (not _literal_true(evidence.get("external_action_performed")) or real_performed) else "FAIL"},
        {"name": "secret_material_not_read", "status": "PASS" if not _literal_true(evidence.get("secret_material_read_performed")) else "FAIL"},
    ]
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_external_submission_execution_gate_state": state,
        "external_submission_execution_gate_created": status in {"PASS", "ATTENTION"},
        "external_submission_execution_gate_ready": accepted,
        "performed_evidence_recorded": accepted,
        "record_only_fixture": record_only_mode,
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "execution_intent_report_path": intent_report.get("report_path") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "source_target_path": packet.get("source_target_path") or intent_report.get("source_target_path") or "",
        "source_after_sha256": packet.get("source_after_sha256") or intent_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": packet.get("post_apply_verify_report_path") or intent_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": packet.get("post_apply_verify_report_sha256") or intent_report.get("post_apply_verify_report_sha256") or "",
        "portal_capability_label": packet.get("portal_capability_label") or intent_report.get("portal_capability_label") or "",
        "external_action_authorized": bool(
            _literal_true(intent_report.get("external_action_authorized"))
            and _literal_true(packet.get("external_action_authorized"))
        ),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": real_performed,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "execution_intent_ready_count": 1 if intent_ready else 0,
            "performed_evidence_supplied_count": 1 if evidence else 0,
            "record_only_fixture_count": 1 if record_only_mode else 0,
            "performed_evidence_recorded_count": 1 if accepted else 0,
            "performed_evidence_template_count": 1 if template_packet else 0,
            "performed_evidence_missing_field_count": len(template_packet.get("missing_fields") or []),
            "external_action_authorized_count": 1 if (
                _literal_true(intent_report.get("external_action_authorized"))
                and _literal_true(packet.get("external_action_authorized"))
            ) else 0,
            "external_action_performed_count": 1 if real_performed else 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "execution_gate_checks": checks,
        "external_submission_execution_gate_packet": {
            "packet_type": "claim_manuscript_external_submission_execution_gate",
            "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_execution_gate.v1",
            "state": state,
            "record_only_fixture": record_only_mode,
            "performed_evidence_recorded": accepted,
            "external_action_performed": real_performed,
            "secret_material_read_performed": False,
        },
        "performed_evidence_record": evidence_record,
        "performed_evidence_template_packet": template_packet,
        "performed_evidence": evidence,
        "execution_intent_report": intent_report,
        "boundary": [
            "This command gates external-submission execution evidence intake.",
            "It can accept either record-only fixture evidence or real performed evidence supplied by a separate external executor.",
            "This gate records evidence but does not itself log into portals, upload, email, final-submit, read secrets, merge, commit, or mutate source/package/archive state.",
            "Real performed evidence may set external_action_performed=true only when non-secret required evidence fields are present.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_gate_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Execution Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_external_submission_execution_gate_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Gate ready: {report.get('external_submission_execution_gate_ready')}",
        f"- Record-only fixture: {report.get('record_only_fixture')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for check in report.get("execution_gate_checks") or []:
        lines.append(f"- {check.get('status')}: {check.get('name')}")
    record = report.get("performed_evidence_record") or {}
    if record:
        lines.extend(["", "## Record-Only Evidence", ""])
        for key in [
            "record_schema",
            "claim_packet_id",
            "source_target_path",
            "portal_session_ref_or_safe_attestation",
            "submission_confirmation_id_or_terminal_status",
        ]:
            lines.append(f"- {key}: {record.get(key) or ''}")
    template = report.get("performed_evidence_template_packet") or {}
    if template:
        lines.extend(["", "## Performed Evidence Template", ""])
        lines.append(f"- packet_schema: {template.get('packet_schema') or ''}")
        lines.append(f"- claim_packet_id: {template.get('claim_packet_id') or ''}")
        lines.append(f"- source_target_path: {template.get('source_target_path') or ''}")
        lines.append(f"- execution_intent_report_sha256: {template.get('execution_intent_report_sha256') or ''}")
        lines.append(f"- missing_fields: {', '.join(template.get('missing_fields') or [])}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
