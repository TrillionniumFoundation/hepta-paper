"""Prepare claim-derived external submission execution intent packets."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-intent"
PREFLIGHT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-preflight"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_READY"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_IDLE_NO_PACKET"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_WAITING_FOR_PREFLIGHT"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_READY"
PREFLIGHT_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_IDLE_NO_PACKET"
PREFLIGHT_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_WAITING"
PREFLIGHT_CAPABILITY_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_CAPABILITY_REQUIRED"


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _validate_preflight(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(
        issues,
        "execution_preflight",
        item,
        PREFLIGHT_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != PREFLIGHT_COMMAND:
        _add_issue(issues, "execution_preflight_command_mismatch", item.get("command") or "")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_preflight_boundary",
            "invalid_execution_preflight_boolean",
        )
    state = item.get("claim_manuscript_external_submission_execution_preflight_state") or ""
    if state not in {PREFLIGHT_READY_STATE, PREFLIGHT_IDLE_STATE, PREFLIGHT_WAITING_STATE, PREFLIGHT_CAPABILITY_REQUIRED_STATE}:
        _add_issue(issues, "execution_preflight_state_not_consumable", state)
    if state == PREFLIGHT_READY_STATE:
        if item.get("status") != "PASS":
            _add_issue(issues, "execution_preflight_ready_not_pass", item.get("status") or "")
        _require_literal_true(
            issues,
            item,
            "external_submission_execution_preflight_ready",
            "execution_preflight_ready_flag_missing",
            "invalid_execution_preflight_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "portal_capability_ready",
            "portal_capability_not_ready_for_intent",
            "invalid_execution_preflight_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "agent_submission_execution_packet_present",
            "agent_submission_execution_packet_missing",
            "invalid_execution_preflight_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "external_action_authorized",
            "external_action_not_authorized_for_intent",
            "invalid_execution_preflight_boolean",
        )
        for key in ["source_target_path", "source_after_sha256", "post_apply_verify_report_path", "post_apply_verify_report_sha256"]:
            if not item.get(key):
                _add_issue(issues, f"execution_preflight_missing:{key}")
    elif item.get("status") not in {"PASS", "ATTENTION"}:
        _add_issue(issues, "execution_preflight_not_pass_or_attention", item.get("status") or "")
    return issues


def _intent_packet(preflight_report, preflight_ready):
    if not preflight_ready:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_intent",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_execution_intent_packet.v1",
        "intent_state": READY_STATE,
        "claim_packet_id": preflight_report.get("claim_packet_id") or "",
        "slug": preflight_report.get("slug") or "",
        "source_target_path": preflight_report.get("source_target_path") or "",
        "source_after_sha256": preflight_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": preflight_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": preflight_report.get("post_apply_verify_report_sha256") or "",
        "execution_preflight_report_path": preflight_report.get("report_path") or "",
        "execution_preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "portal_capability_label": preflight_report.get("portal_capability_label") or "",
        "external_action_authorized": _literal_true(preflight_report.get("external_action_authorized")),
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "requires_external_action_execution_gate": True,
        "requires_performed_evidence_before_submit": True,
        "required_performed_evidence_fields": [
            "portal_session_ref_or_safe_attestation",
            "upload_artifact_manifest_sha256",
            "submission_confirmation_id_or_terminal_status",
            "external_action_started_at",
            "external_action_finished_at",
        ],
        "actions_not_performed_by_this_command": [
            "secret read",
            "portal login",
            "portal upload",
            "email",
            "final submit",
            "remote action",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_intent(
    execution_preflight_report,
    label="",
):
    preflight_report = execution_preflight_report or {}
    issues = _validate_preflight(preflight_report)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    preflight_state = preflight_report.get("claim_manuscript_external_submission_execution_preflight_state") or ""
    preflight_ready = bool(
        preflight_state == PREFLIGHT_READY_STATE
        and preflight_report.get("status") == "PASS"
        and _literal_true(preflight_report.get("external_submission_execution_preflight_ready"))
        and _literal_true(preflight_report.get("portal_capability_ready"))
    )

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif preflight_state == PREFLIGHT_IDLE_STATE:
        status = "ATTENTION" if issues else "PASS"
        state = IDLE_STATE
    elif preflight_state in {PREFLIGHT_WAITING_STATE, PREFLIGHT_CAPABILITY_REQUIRED_STATE}:
        status = "ATTENTION" if issues else "PASS"
        state = WAITING_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    packet = _intent_packet(preflight_report, preflight_ready and status == "PASS")
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_external_submission_execution_intent_state": state,
        "external_submission_execution_intent_created": status == "PASS",
        "external_submission_execution_intent_ready": bool(packet),
        "slug": preflight_report.get("slug") or "",
        "execution_preflight_report_path": preflight_report.get("report_path") or "",
        "execution_preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "claim_packet_id": preflight_report.get("claim_packet_id") or "",
        "source_target_path": preflight_report.get("source_target_path") or "",
        "source_after_sha256": preflight_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": preflight_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": preflight_report.get("post_apply_verify_report_sha256") or "",
        "portal_capability_ready": _literal_true(preflight_report.get("portal_capability_ready")),
        "portal_capability_label": preflight_report.get("portal_capability_label") or "",
        "external_action_authorized": _literal_true(preflight_report.get("external_action_authorized")),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "execution_intent_ready_count": 1 if packet else 0,
            "portal_capability_ready_count": 1 if _literal_true(preflight_report.get("portal_capability_ready")) else 0,
            "external_action_authorized_count": 1 if _literal_true(preflight_report.get("external_action_authorized")) else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "external_submission_execution_intent_packet": packet,
        "execution_preflight_report": preflight_report,
        "boundary": [
            "This command prepares a local intent packet for a later external-action execution gate.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "The intent packet is not performed evidence; a later execution command must record performed evidence before external_action_performed can become true.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_intent_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Execution Intent",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_external_submission_execution_intent_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Intent ready: {report.get('external_submission_execution_intent_ready')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("external_submission_execution_intent_packet") or {}
    if packet:
        lines.extend(["", "## Intent Packet", ""])
        for key in [
            "packet_schema",
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "execution_preflight_report_path",
            "portal_capability_label",
        ]:
            lines.append(f"- {key}: {packet.get(key) or ''}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
