"""Verify non-secret performed evidence from an external submission executor."""

import datetime as dt
import re

from paperctl_modules import (
    report_ref_health,
    research_compute_claim_manuscript_external_submission_execution_gate as gate,
)


COMMAND = "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake"
INTENT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-intent"
EXECUTOR_TASK_COMMAND = "research-compute-claim-manuscript-external-submission-execution-executor-task"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_READY"
TEMPLATE_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_TEMPLATE_REQUIRED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_IDLE_NO_INTENT"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_WAITING_FOR_INTENT"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

INTENT_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_READY"
INTENT_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_IDLE_NO_PACKET"
INTENT_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_WAITING_FOR_PREFLIGHT"
INTENT_ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_ATTENTION"
EXECUTOR_TASK_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_READY"

EXECUTOR_RESPONSE_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_performed_evidence_executor_response.v1"
)
PERFORMED_EVIDENCE_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_execution_performed_evidence.v1"
)

REQUIRED_EVIDENCE_FIELDS = list(gate.REQUIRED_EVIDENCE_FIELDS)
SECRET_LIKE_RE = gate.SECRET_LIKE_RE
SHA256_RE = gate.SHA256_RE


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_boolean_field(issues, item, key, invalid_prefix):
    if key in item and not isinstance(item.get(key), bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(item.get(key)))


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _intent_packet(report):
    return (report or {}).get("external_submission_execution_intent_packet") or {}


def _executor_task_packet(report):
    return (report or {}).get("external_submission_executor_task_packet") or {}


def _executor_task_upload_manifest_sha(report):
    task = _executor_task_packet(report)
    return (report or {}).get("upload_manifest_csv_sha256") or task.get("upload_manifest_csv_sha256") or ""


def _field(raw):
    return str(raw or "").strip()


def _secret_like_value(raw):
    if isinstance(raw, dict):
        return any(_secret_like_value(value) for value in raw.values())
    if isinstance(raw, (list, tuple, set)):
        return any(_secret_like_value(value) for value in raw)
    return bool(SECRET_LIKE_RE.search(str(raw or "")))


def _normalize_executor_response_packet(raw):
    item = raw or {}
    for key in [
        "external_submission_performed_evidence_executor_response_packet",
        "executor_response_packet",
        "performed_evidence_executor_response_packet",
    ]:
        nested = item.get(key)
        if isinstance(nested, dict):
            return nested
    return item if isinstance(item, dict) else {}


def _validate_intent(report):
    issues = []
    item = report or {}
    packet = _intent_packet(item)
    _add_report_ref_health_issues(
        issues,
        "execution_intent",
        item,
        INTENT_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != INTENT_COMMAND:
        _add_issue(issues, "execution_intent_command_mismatch", item.get("command") or "")
    if _validation_issue_count(item):
        _add_issue(issues, "execution_intent_validation_issues_present")
    for key in _forbidden_keys() + ["external_action_performed"]:
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_intent_boundary",
            "invalid_execution_intent_boolean",
        )
        _check_forbidden_boundary(
            issues,
            packet,
            key,
            "forbidden_execution_intent_packet_boundary",
            "invalid_execution_intent_packet_boolean",
        )
    state = item.get("claim_manuscript_external_submission_execution_intent_state") or ""
    if state not in {INTENT_READY_STATE, INTENT_IDLE_STATE, INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
        _add_issue(issues, "execution_intent_state_not_consumable", state)
    if state == INTENT_READY_STATE:
        if item.get("status") != "PASS":
            _add_issue(issues, "execution_intent_ready_not_pass", item.get("status") or "")
        _require_literal_true(
            issues,
            item,
            "external_submission_execution_intent_ready",
            "execution_intent_ready_flag_missing",
            "invalid_execution_intent_boolean",
        )
        if not packet:
            _add_issue(issues, "execution_intent_packet_missing")
        _require_literal_true(
            issues,
            item,
            "external_action_authorized",
            "external_action_not_authorized_for_performed_evidence_intake",
            "invalid_execution_intent_boolean",
        )
        _require_literal_true(
            issues,
            packet,
            "external_action_authorized",
            "intent_packet_external_action_not_authorized_for_performed_evidence_intake",
            "invalid_execution_intent_packet_boolean",
        )
        _require_literal_true(
            issues,
            packet,
            "requires_performed_evidence_before_submit",
            "intent_packet_missing_performed_evidence_requirement",
            "invalid_execution_intent_packet_boolean",
        )
        for key in [
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "post_apply_verify_report_path",
            "post_apply_verify_report_sha256",
            "execution_preflight_report_path",
            "execution_preflight_report_sha256",
            "portal_capability_label",
        ]:
            if not packet.get(key):
                _add_issue(issues, f"execution_intent_packet_missing:{key}")
    elif item.get("status") not in {"PASS", "ATTENTION"}:
        _add_issue(issues, "execution_intent_not_pass_or_attention", item.get("status") or "")
    return issues


def _response_field_map(response_packet, direct_fields=None):
    response = response_packet or {}
    direct_fields = direct_fields or {}
    fields = {
        "portal_session_ref_or_safe_attestation": _field(response.get("portal_session_ref_or_safe_attestation")),
        "upload_artifact_manifest_sha256": _field(response.get("upload_artifact_manifest_sha256")),
        "submission_confirmation_id_or_terminal_status": _field(response.get("submission_confirmation_id_or_terminal_status")),
        "external_action_started_at": _field(response.get("external_action_started_at")),
        "external_action_finished_at": _field(response.get("external_action_finished_at")),
        "portal_login_performed": _literal_true(response.get("portal_login_performed")),
        "upload_performed": _literal_true(response.get("upload_performed")),
        "email_performed": _literal_true(response.get("email_performed")),
        "final_submit_performed": _literal_true(response.get("final_submit_performed")),
        "external_action_performed": _literal_true(response.get("external_action_performed")),
    }
    for key in REQUIRED_EVIDENCE_FIELDS:
        direct = _field(direct_fields.get(key))
        if direct:
            fields[key] = direct
    for key in [
        "portal_login_performed",
        "upload_performed",
        "email_performed",
        "final_submit_performed",
        "external_action_performed",
    ]:
        if key in direct_fields and _literal_true(direct_fields.get(key)):
            fields[key] = True
    return fields


def _response_boolean_issues(response, direct_fields):
    issues = []
    for key in [
        "portal_login_performed",
        "upload_performed",
        "email_performed",
        "final_submit_performed",
        "external_action_performed",
    ]:
        _check_boolean_field(issues, response or {}, key, "invalid_executor_response_boolean")
        _check_boolean_field(issues, direct_fields or {}, key, "invalid_direct_performed_evidence_boolean")
    return issues


def _validate_executor_response_packet(response, intent_report, packet):
    issues = []
    if not response:
        return issues
    if response.get("packet_type") != "claim_manuscript_external_submission_execution_performed_evidence_executor_response":
        _add_issue(issues, "executor_response_packet_type_mismatch", response.get("packet_type") or "")
    if response.get("packet_schema") != EXECUTOR_RESPONSE_PACKET_SCHEMA:
        _add_issue(issues, "executor_response_packet_schema_mismatch", response.get("packet_schema") or "")
    _require_literal_true(
        issues,
        response,
        "executor_response_completed",
        "executor_response_not_marked_complete",
        "invalid_executor_response_boolean",
    )
    if response.get("template_is_response") is True:
        _add_issue(issues, "executor_response_template_marker_must_remain_false")
    else:
        _check_boolean_field(issues, response, "template_is_response", "invalid_executor_response_boolean")
    if _literal_true(response.get("record_only_fixture")):
        _add_issue(issues, "record_only_fixture_not_allowed_for_performed_evidence_intake")
    else:
        _check_boolean_field(issues, response, "record_only_fixture", "invalid_executor_response_boolean")
    expected = {
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "execution_preflight_report_sha256": (
            intent_report.get("execution_preflight_report_sha256")
            or packet.get("execution_preflight_report_sha256")
            or ""
        ),
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
    }
    for key, expected_value in expected.items():
        actual = response.get(key) or ""
        if expected_value and not actual:
            _add_issue(issues, f"executor_response_missing_anchor:{key}")
        elif expected_value and actual != expected_value:
            _add_issue(issues, f"executor_response_anchor_mismatch:{key}", actual)
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            response,
            key,
            "forbidden_executor_response_boundary",
            "invalid_executor_response_boolean",
        )
    return issues


def _validate_executor_task_report(report, intent_report, intent_packet, fields):
    if not report:
        return []
    issues = []
    item = report or {}
    task = _executor_task_packet(item)
    _add_report_ref_health_issues(
        issues,
        "executor_task",
        item,
        EXECUTOR_TASK_COMMAND,
    )
    if item.get("command") != EXECUTOR_TASK_COMMAND:
        _add_issue(issues, "executor_task_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "executor_task_not_pass", item.get("status") or "")
    if _validation_issue_count(item):
        _add_issue(issues, "executor_task_validation_issues_present")
    if item.get("executor_task_state") != EXECUTOR_TASK_READY_STATE:
        _add_issue(issues, "executor_task_not_ready", item.get("executor_task_state") or "")
    _require_literal_true(
        issues,
        item,
        "executor_task_ready",
        "executor_task_ready_flag_missing",
        "invalid_executor_task_boolean",
    )
    if not task:
        _add_issue(issues, "executor_task_packet_missing")
    if task.get("required_executor_response_schema") and task.get("required_executor_response_schema") != EXECUTOR_RESPONSE_PACKET_SCHEMA:
        _add_issue(issues, "executor_task_required_response_schema_mismatch", task.get("required_executor_response_schema") or "")
    for key in _forbidden_keys() + ["external_action_performed"]:
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_executor_task_boundary",
            "invalid_executor_task_boolean",
        )
        _check_forbidden_boundary(
            issues,
            task,
            key,
            "forbidden_executor_task_packet_boundary",
            "invalid_executor_task_packet_boolean",
        )
    expected = {
        "claim_packet_id": intent_report.get("claim_packet_id") or intent_packet.get("claim_packet_id") or "",
        "source_target_path": intent_report.get("source_target_path") or intent_packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or intent_packet.get("source_after_sha256") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
    }
    for key, expected_value in expected.items():
        actual = item.get(key) or task.get(key) or ""
        if expected_value and not actual:
            _add_issue(issues, f"executor_task_missing_anchor:{key}")
        elif expected_value and actual != expected_value:
            _add_issue(issues, f"executor_task_anchor_mismatch:{key}", actual)
    task_upload_sha = item.get("upload_manifest_csv_sha256") or task.get("upload_manifest_csv_sha256") or ""
    if not task_upload_sha:
        _add_issue(issues, "executor_task_upload_manifest_sha256_missing")
    elif not SHA256_RE.match(task_upload_sha):
        _add_issue(issues, "executor_task_upload_manifest_sha256_not_sha256", task_upload_sha)
    response_upload_sha = fields.get("upload_artifact_manifest_sha256") or ""
    if task_upload_sha and response_upload_sha and response_upload_sha != task_upload_sha:
        _add_issue(issues, "executor_response_upload_manifest_mismatch", response_upload_sha)
    return issues


def _validate_fields(fields, response_present):
    issues = []
    for key in REQUIRED_EVIDENCE_FIELDS:
        if not fields.get(key):
            _add_issue(issues, f"performed_evidence_intake_missing:{key}")
    upload_hash = fields.get("upload_artifact_manifest_sha256") or ""
    if upload_hash and not SHA256_RE.match(upload_hash):
        _add_issue(issues, "upload_artifact_manifest_sha256_not_sha256", upload_hash)
    if fields.get("external_action_performed") is not True:
        _add_issue(issues, "performed_evidence_intake_external_action_flag_required")
    if response_present and not (
        fields.get("upload_performed")
        or fields.get("final_submit_performed")
        or fields.get("portal_login_performed")
    ):
        _add_issue(issues, "performed_evidence_intake_missing_external_action_detail")
    if _secret_like_value({key: fields.get(key) for key in REQUIRED_EVIDENCE_FIELDS}):
        _add_issue(issues, "forbidden_secret_like_performed_evidence_intake_material")
    return issues


def _performed_evidence_packet(intent_report, packet, fields, ready):
    if not ready:
        return {}
    return {
        "command": gate.COMMAND,
        "evidence_type": "claim_manuscript_external_submission_execution_performed_evidence",
        "evidence_schema": PERFORMED_EVIDENCE_SCHEMA,
        "record_only_fixture": False,
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "post_apply_verify_report_path": packet.get("post_apply_verify_report_path") or intent_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": packet.get("post_apply_verify_report_sha256") or intent_report.get("post_apply_verify_report_sha256") or "",
        "execution_preflight_report_path": packet.get("execution_preflight_report_path") or intent_report.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or intent_report.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_path": intent_report.get("report_path") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "portal_capability_label": packet.get("portal_capability_label") or intent_report.get("portal_capability_label") or "",
        "portal_session_ref_or_safe_attestation": fields["portal_session_ref_or_safe_attestation"],
        "upload_artifact_manifest_sha256": fields["upload_artifact_manifest_sha256"],
        "submission_confirmation_id_or_terminal_status": fields["submission_confirmation_id_or_terminal_status"],
        "external_action_started_at": fields["external_action_started_at"],
        "external_action_finished_at": fields["external_action_finished_at"],
        "portal_login_performed": _literal_true(fields.get("portal_login_performed")),
        "upload_performed": _literal_true(fields.get("upload_performed")),
        "email_performed": _literal_true(fields.get("email_performed")),
        "final_submit_performed": _literal_true(fields.get("final_submit_performed")),
        "external_action_performed": True,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
    }


def _executor_response_template(intent_report, packet, fields, ready):
    if ready:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_performed_evidence_executor_response",
        "packet_schema": EXECUTOR_RESPONSE_PACKET_SCHEMA,
        "executor_response_state": "EXECUTOR_RESPONSE_TEMPLATE_UNFILLED",
        "executor_response_completed": False,
        "template_is_response": False,
        "record_only_fixture": False,
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or intent_report.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "required_fields": list(REQUIRED_EVIDENCE_FIELDS),
        "portal_session_ref_or_safe_attestation": fields.get("portal_session_ref_or_safe_attestation") or "",
        "upload_artifact_manifest_sha256": fields.get("upload_artifact_manifest_sha256") or "",
        "submission_confirmation_id_or_terminal_status": fields.get("submission_confirmation_id_or_terminal_status") or "",
        "external_action_started_at": fields.get("external_action_started_at") or "",
        "external_action_finished_at": fields.get("external_action_finished_at") or "",
        "portal_login_performed": _literal_true(fields.get("portal_login_performed")),
        "upload_performed": _literal_true(fields.get("upload_performed")),
        "email_performed": _literal_true(fields.get("email_performed")),
        "final_submit_performed": _literal_true(fields.get("final_submit_performed")),
        "external_action_performed": _literal_true(fields.get("external_action_performed")),
        "safe_field_notes": {
            "portal_session_ref_or_safe_attestation": "Record only a non-secret executor/session attestation. Do not record cookies, passwords, bearer tokens, API keys, or session ids.",
            "upload_artifact_manifest_sha256": "SHA-256 of the local upload artifact manifest actually used by the external executor.",
            "submission_confirmation_id_or_terminal_status": "Non-secret portal confirmation id or terminal status label.",
            "external_action_started_at": "External executor start timestamp.",
            "external_action_finished_at": "External executor finish timestamp.",
        },
        "forbidden_material": [
            "passwords",
            "tokens",
            "cookies",
            "bearer credentials",
            "api keys",
            "portal session secrets",
        ],
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
    }


def research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake(
    execution_intent_report,
    executor_response_packet=None,
    executor_task_report=None,
    direct_fields=None,
    label="",
):
    intent_report = execution_intent_report or {}
    packet = _intent_packet(intent_report)
    response = _normalize_executor_response_packet(executor_response_packet or {})
    fields = _response_field_map(response, direct_fields=direct_fields)
    task_upload_sha = _executor_task_upload_manifest_sha(executor_task_report or {})
    if task_upload_sha and not fields.get("upload_artifact_manifest_sha256"):
        fields["upload_artifact_manifest_sha256"] = task_upload_sha
    intent_issues = _validate_intent(intent_report)
    response_boolean_issues = _response_boolean_issues(response, direct_fields or {})
    response_issues = _validate_executor_response_packet(response, intent_report, packet)
    executor_task_issues = _validate_executor_task_report(executor_task_report or {}, intent_report, packet, fields)
    intent_state = intent_report.get("claim_manuscript_external_submission_execution_intent_state") or ""
    intent_ready = bool(
        intent_state == INTENT_READY_STATE
        and intent_report.get("status") == "PASS"
        and _literal_true(intent_report.get("external_submission_execution_intent_ready"))
        and packet
    )
    field_issues = _validate_fields(fields, response_present=bool(response)) if intent_ready else []
    issues = intent_issues + response_boolean_issues + response_issues + executor_task_issues + field_issues
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif intent_issues:
        status = "ATTENTION"
        state = WAITING_STATE if intent_state in {INTENT_WAITING_STATE, INTENT_ATTENTION_STATE} else ATTENTION_STATE
    elif intent_state == INTENT_IDLE_STATE:
        status = "PASS"
        state = IDLE_STATE
    elif intent_state in {INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
        status = "ATTENTION"
        state = WAITING_STATE
    elif not intent_ready:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif field_issues or response_issues or executor_task_issues:
        status = "ATTENTION"
        state = TEMPLATE_REQUIRED_STATE
    else:
        status = "PASS"
        state = READY_STATE

    ready = bool(status == "PASS" and state == READY_STATE)
    performed_evidence = _performed_evidence_packet(intent_report, packet, fields, ready)
    template = _executor_response_template(intent_report, packet, fields, ready)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "performed_evidence_intake_state": state,
        "performed_evidence_intake_created": status in {"PASS", "ATTENTION"},
        "performed_evidence_intake_ready": ready,
        "observed_external_action_performed": bool(
            ready and _literal_true(performed_evidence.get("external_action_performed"))
        ),
        "slug": intent_report.get("slug") or packet.get("slug") or "",
        "execution_intent_report_path": intent_report.get("report_path") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "executor_task_report_path": (executor_task_report or {}).get("report_path") or "",
        "executor_task_report_sha256": (executor_task_report or {}).get("report_sha256") or "",
        "executor_task_bound": bool(executor_task_report and not executor_task_issues),
        "claim_packet_id": intent_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "source_target_path": intent_report.get("source_target_path") or packet.get("source_target_path") or "",
        "source_after_sha256": intent_report.get("source_after_sha256") or packet.get("source_after_sha256") or "",
        "portal_capability_label": packet.get("portal_capability_label") or intent_report.get("portal_capability_label") or "",
        "portal_session_ref_or_safe_attestation": fields.get("portal_session_ref_or_safe_attestation") or "",
        "upload_artifact_manifest_sha256": fields.get("upload_artifact_manifest_sha256") or "",
        "submission_confirmation_id_or_terminal_status": fields.get("submission_confirmation_id_or_terminal_status") or "",
        "external_action_started_at": fields.get("external_action_started_at") or "",
        "external_action_finished_at": fields.get("external_action_finished_at") or "",
        "portal_login_performed": _literal_true(fields.get("portal_login_performed")),
        "upload_performed": _literal_true(fields.get("upload_performed")),
        "email_performed": _literal_true(fields.get("email_performed")),
        "final_submit_performed": _literal_true(fields.get("final_submit_performed")),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "performed_evidence_intake_ready_count": 1 if ready else 0,
            "performed_evidence_packet_count": 1 if performed_evidence else 0,
            "executor_response_template_count": 1 if template else 0,
            "executor_response_packet_present_count": 1 if response else 0,
            "executor_task_report_present_count": 1 if executor_task_report else 0,
            "executor_task_bound_count": 1 if (executor_task_report and not executor_task_issues) else 0,
            "observed_external_action_performed_count": 1 if (
                ready and _literal_true(performed_evidence.get("external_action_performed"))
            ) else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "external_submission_performed_evidence": performed_evidence,
        "external_submission_performed_evidence_executor_response_template_packet": template,
        "external_submission_performed_evidence_executor_response_packet": response,
        "execution_intent_report": intent_report,
        "executor_task_report": executor_task_report or {},
        "boundary": [
            "This command verifies non-secret performed evidence reported by a separate external submission executor.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "When ready, it writes a gate-consumable performed-evidence packet; the execution gate remains the only command that records PERFORMED_EVIDENCE_ACCEPTED.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_performed_evidence_intake_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Performed Evidence Intake",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('performed_evidence_intake_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Intake ready: {report.get('performed_evidence_intake_ready')}",
        f"- Observed external action performed: {report.get('observed_external_action_performed')}",
        f"- External action performed by this command: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            detail = f" ({item.get('detail')})" if item.get("detail") else ""
            lines.append(f"- {item.get('issue') or ''}{detail}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
