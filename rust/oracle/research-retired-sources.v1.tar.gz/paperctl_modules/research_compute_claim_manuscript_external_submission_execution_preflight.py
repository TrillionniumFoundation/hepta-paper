"""Preflight claim-derived external submission execution packets."""

import datetime as dt
import pathlib

from paperctl_modules import report_io, report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-preflight"
READINESS_COMMAND = "research-compute-claim-manuscript-external-submission-readiness"
PORTAL_CAPABILITY_ATTESTATION_COMMAND = "research-compute-claim-manuscript-external-submission-portal-capability-attestation"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_READY"
CAPABILITY_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_CAPABILITY_REQUIRED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_IDLE_NO_PACKET"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_WAITING"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

READINESS_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_READY"
READINESS_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_IDLE_NO_PATCH_DRAFT"
READINESS_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_WAITING_FOR_SOURCE_LANDING"
READINESS_AUTH_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_READY_EXTERNAL_AUTH_REQUIRED"


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _abs_path(root, raw_path):
    path = pathlib.Path(raw_path or "")
    if not raw_path:
        return path
    if not path.is_absolute():
        path = pathlib.Path(root or ".") / path
    return path


def _file_snapshot(root, raw_path, expected_sha=""):
    path = _abs_path(root, raw_path)
    exists = bool(raw_path) and path.exists() and path.is_file()
    actual_sha = report_io.sha256_file(path) if exists else ""
    return {
        "path": report_io.rel_path(root or ".", path) if raw_path else "",
        "exists": exists,
        "sha256": actual_sha,
        "expected_sha256": expected_sha or actual_sha,
        "sha256_match": bool(exists and actual_sha and (not expected_sha or actual_sha == expected_sha)),
    }


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _packet(report):
    return (report or {}).get("agent_submission_execution_packet") or {}


def _validate_readiness(report):
    issues = []
    item = report or {}
    packet = _packet(item)
    _add_report_ref_health_issues(
        issues,
        "external_submission_readiness",
        item,
        READINESS_COMMAND,
    )
    if item.get("command") != READINESS_COMMAND:
        _add_issue(issues, "external_submission_readiness_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "external_submission_readiness_not_pass", item.get("status") or "")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_external_submission_readiness_boundary",
            "invalid_external_submission_readiness_boolean",
        )
    state = item.get("claim_manuscript_external_submission_readiness_state") or ""
    if state not in {READINESS_READY_STATE, READINESS_IDLE_STATE, READINESS_WAITING_STATE, READINESS_AUTH_REQUIRED_STATE}:
        _add_issue(issues, "external_submission_readiness_state_not_consumable", state)
    if state == READINESS_READY_STATE:
        _require_literal_true(
            issues,
            item,
            "agent_submission_execution_packet_created",
            "agent_submission_execution_packet_missing",
            "invalid_external_submission_readiness_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "agent_external_submission_decision_ready",
            "agent_external_submission_decision_not_ready",
            "invalid_external_submission_readiness_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "external_action_authorized",
            "external_action_not_authorized_for_preflight",
            "invalid_external_submission_readiness_boolean",
        )
        if not packet:
            _add_issue(issues, "agent_submission_execution_packet_empty")
        for key in _forbidden_keys():
            _check_forbidden_boundary(
                issues,
                packet,
                key,
                "forbidden_agent_submission_packet_boundary",
                "invalid_agent_submission_packet_boolean",
            )
        _require_literal_true(
            issues,
            packet,
            "external_action_authorized",
            "agent_submission_packet_external_action_not_authorized",
            "invalid_agent_submission_packet_boolean",
        )
        for key in ["source_target_path", "source_after_sha256", "post_apply_verify_report_path", "post_apply_verify_report_sha256"]:
            if not packet.get(key):
                _add_issue(issues, f"agent_submission_packet_missing:{key}")
    return issues


def _check_snapshot(issues, name, snapshot):
    if snapshot.get("path") and not snapshot.get("exists"):
        _add_issue(issues, f"{name}_missing", snapshot.get("path") or "")
    elif snapshot.get("path") and not snapshot.get("sha256_match"):
        _add_issue(issues, f"{name}_sha256_mismatch", snapshot.get("path") or "")


def _portal_capability_handoff_packet(
    readiness_report,
    packet,
    readiness_snapshot,
    source_snapshot,
    post_apply_snapshot,
    finalization_snapshot,
    merge_submission_snapshot,
    portal_capability_label,
):
    return {
        "packet_type": "claim_manuscript_external_submission_portal_capability_handoff",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_handoff.v1",
        "handoff_state": CAPABILITY_REQUIRED_STATE,
        "claim_packet_id": readiness_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "slug": readiness_report.get("slug") or packet.get("slug") or "",
        "source_target_path": packet.get("source_target_path") or "",
        "source_after_sha256": packet.get("source_after_sha256") or "",
        "external_submission_readiness_report_path": readiness_report.get("report_path") or "",
        "external_submission_readiness_report_sha256": readiness_report.get("report_sha256") or "",
        "post_apply_verify_report_path": packet.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": packet.get("post_apply_verify_report_sha256") or "",
        "portal_capability_ready": False,
        "portal_capability_label": portal_capability_label or "",
        "blocking_reasons": [
            "external_execution_capability_not_ready",
            "portal_capability_ready flag was not supplied for this preflight",
        ],
        "local_evidence_snapshots": {
            "external_submission_readiness_report": readiness_snapshot,
            "source_target": source_snapshot,
            "post_apply_verify_report": post_apply_snapshot,
            "source_landing_finalization_report": finalization_snapshot,
            "merge_submission_readiness_report": merge_submission_snapshot,
        },
        "required_portal_capability_attestations": [
            "portal_session_ref_or_safe_attestation",
            "target venue portal route or equivalent safe external submission channel",
            "upload artifact manifest sha256",
            "submission confirmation id or explicit terminal status",
            "external action started and finished timestamps",
        ],
        "allowed_local_next_steps": [
            "re-run this preflight with --portal-capability-ready and a portal capability label only after explicit external capability evidence exists",
            "re-run research-compute-claim-manuscript-lifecycle-orchestrator after the preflight report is refreshed",
        ],
        "actions_not_performed_by_this_packet": [
            "secret read",
            "portal login",
            "portal upload",
            "email",
            "final submit",
            "merge",
            "commit",
            "source/package/archive mutation",
        ],
        "external_action_performed": False,
        "secret_material_read_performed": False,
    }


def _validate_portal_capability_attestation(report, readiness_report, packet):
    issues = []
    item = report or {}
    attestation_packet = item.get("portal_capability_attestation_packet") or {}
    if not item:
        return issues, False, ""
    _add_report_ref_health_issues(
        issues,
        "portal_capability_attestation",
        item,
        PORTAL_CAPABILITY_ATTESTATION_COMMAND,
    )
    if item.get("command") != PORTAL_CAPABILITY_ATTESTATION_COMMAND:
        _add_issue(issues, "portal_capability_attestation_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "portal_capability_attestation_not_pass", item.get("status") or "")
    if item.get("portal_capability_attestation_state") != "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_READY":
        _add_issue(issues, "portal_capability_attestation_not_ready", item.get("portal_capability_attestation_state") or "")
    if not attestation_packet:
        _add_issue(issues, "portal_capability_attestation_packet_missing")
    for key in _forbidden_keys() + ["secret_material_read_performed"]:
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_portal_capability_attestation_boundary",
            "invalid_portal_capability_attestation_boolean",
        )
        _check_forbidden_boundary(
            issues,
            attestation_packet,
            key,
            "forbidden_portal_capability_attestation_packet_boundary",
            "invalid_portal_capability_attestation_packet_boolean",
        )
    _require_literal_true(
        issues,
        item,
        "portal_capability_ready",
        "portal_capability_attestation_ready_flag_missing",
        "invalid_portal_capability_attestation_boolean",
    )
    expected_claim = readiness_report.get("claim_packet_id") or packet.get("claim_packet_id") or ""
    expected_source = packet.get("source_after_sha256") or readiness_report.get("source_after_sha256") or ""
    expected_source_path = packet.get("source_target_path") or readiness_report.get("source_target_path") or ""
    expected_readiness_sha = readiness_report.get("report_sha256") or ""
    if expected_claim and item.get("claim_packet_id") and item.get("claim_packet_id") != expected_claim:
        _add_issue(issues, "portal_capability_attestation_claim_packet_mismatch", item.get("claim_packet_id") or "")
    if expected_source_path and item.get("source_target_path") and item.get("source_target_path") != expected_source_path:
        _add_issue(issues, "portal_capability_attestation_source_target_mismatch", item.get("source_target_path") or "")
    if expected_source and item.get("source_after_sha256") and item.get("source_after_sha256") != expected_source:
        _add_issue(issues, "portal_capability_attestation_source_sha_mismatch", item.get("source_after_sha256") or "")
    if expected_readiness_sha and item.get("external_submission_readiness_report_sha256") and item.get("external_submission_readiness_report_sha256") != expected_readiness_sha:
        _add_issue(issues, "portal_capability_attestation_readiness_sha_mismatch", item.get("external_submission_readiness_report_sha256") or "")
    ready = bool(not issues and _literal_true(item.get("portal_capability_ready")))
    return issues, ready, item.get("portal_capability_label") or item.get("capability_attestation_id") or ""


def research_compute_claim_manuscript_external_submission_execution_preflight(
    external_submission_readiness_report,
    root=None,
    portal_capability_ready=False,
    portal_capability_label="",
    portal_capability_attestation_report=None,
    label="",
):
    readiness_report = external_submission_readiness_report or {}
    packet = _packet(readiness_report)
    issues = _validate_readiness(readiness_report)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    readiness_state = readiness_report.get("claim_manuscript_external_submission_readiness_state") or ""
    readiness_ready = readiness_state == READINESS_READY_STATE
    readiness_idle = readiness_state == READINESS_IDLE_STATE
    readiness_waiting = readiness_state in {READINESS_WAITING_STATE, READINESS_AUTH_REQUIRED_STATE}

    readiness_snapshot = _file_snapshot(
        root,
        readiness_report.get("report_path") or "",
        readiness_report.get("report_sha256") or "",
    )
    source_snapshot = _file_snapshot(root, packet.get("source_target_path") or "", packet.get("source_after_sha256") or "")
    post_apply_snapshot = _file_snapshot(
        root,
        packet.get("post_apply_verify_report_path") or "",
        packet.get("post_apply_verify_report_sha256") or "",
    )
    finalization_snapshot = _file_snapshot(
        root,
        packet.get("finalization_report_path") or "",
        packet.get("finalization_report_sha256") or "",
    )
    merge_submission_snapshot = _file_snapshot(
        root,
        packet.get("merge_submission_readiness_report_path") or "",
        packet.get("merge_submission_readiness_report_sha256") or "",
    )
    attestation_issues, attestation_ready, attestation_label = _validate_portal_capability_attestation(
        portal_capability_attestation_report,
        readiness_report,
        packet,
    )
    issues.extend(attestation_issues)
    capability_ready = bool(_literal_true(portal_capability_ready) or attestation_ready)
    capability_label = portal_capability_label or attestation_label
    if readiness_ready:
        _check_snapshot(issues, "readiness_report", readiness_snapshot)
        _check_snapshot(issues, "source_target", source_snapshot)
        _check_snapshot(issues, "post_apply_verify_report", post_apply_snapshot)
        _check_snapshot(issues, "finalization_report", finalization_snapshot)
        _check_snapshot(issues, "merge_submission_readiness_report", merge_submission_snapshot)
        if not capability_ready:
            _add_issue(issues, "external_execution_capability_not_ready", capability_label or "portal capability not supplied")
    portal_capability_handoff_packet = {}
    if readiness_ready and not capability_ready:
        portal_capability_handoff_packet = _portal_capability_handoff_packet(
            readiness_report,
            packet,
            readiness_snapshot,
            source_snapshot,
            post_apply_snapshot,
            finalization_snapshot,
            merge_submission_snapshot,
            capability_label,
        )

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif readiness_idle:
        status = "ATTENTION" if issues else "PASS"
        state = IDLE_STATE
    elif readiness_waiting:
        status = "ATTENTION" if issues else "PASS"
        state = WAITING_STATE
    elif issues:
        status = "ATTENTION"
        state = CAPABILITY_REQUIRED_STATE if any(item.get("issue") == "external_execution_capability_not_ready" for item in issues) else ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    preflight_ready = bool(status == "PASS" and state == READY_STATE)
    checks = [
        {"name": "readiness_report_consumable", "status": "PASS" if not _validate_readiness(readiness_report) else "FAIL"},
        {"name": "readiness_report_hash_match", "status": "PASS" if not readiness_ready or readiness_snapshot.get("sha256_match") else "FAIL"},
        {"name": "source_target_hash_match", "status": "PASS" if not readiness_ready or source_snapshot.get("sha256_match") else "FAIL"},
        {"name": "post_apply_verify_hash_match", "status": "PASS" if not readiness_ready or post_apply_snapshot.get("sha256_match") else "FAIL"},
        {"name": "portal_capability_attestation_ready", "status": "PASS" if (not portal_capability_attestation_report or attestation_ready) else "FAIL"},
        {"name": "external_execution_capability_ready", "status": "PASS" if (not readiness_ready or capability_ready) else "ATTENTION"},
        {"name": "portal_capability_handoff_packet_created", "status": "PASS" if (not readiness_ready or capability_ready or portal_capability_handoff_packet) else "ATTENTION"},
        {"name": "external_action_not_performed", "status": "PASS"},
    ]
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_external_submission_execution_preflight_state": state,
        "external_submission_execution_preflight_created": status in {"PASS", "ATTENTION"},
        "external_submission_execution_preflight_ready": preflight_ready,
        "slug": readiness_report.get("slug") or packet.get("slug") or "",
        "external_submission_readiness_report_path": readiness_report.get("report_path") or "",
        "external_submission_readiness_report_sha256": readiness_report.get("report_sha256") or "",
        "claim_packet_id": readiness_report.get("claim_packet_id") or packet.get("claim_packet_id") or "",
        "source_target_path": packet.get("source_target_path") or "",
        "source_after_sha256": packet.get("source_after_sha256") or "",
        "post_apply_verify_report_path": packet.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": packet.get("post_apply_verify_report_sha256") or "",
        "portal_capability_ready": bool(capability_ready),
        "portal_capability_label": capability_label or "",
        "portal_capability_attestation_report_path": (portal_capability_attestation_report or {}).get("report_path") or "",
        "portal_capability_attestation_report_sha256": (portal_capability_attestation_report or {}).get("report_sha256") or "",
        "portal_capability_attestation_ready": bool(attestation_ready),
        "portal_capability_handoff_packet_created": bool(portal_capability_handoff_packet),
        "portal_capability_handoff_packet": portal_capability_handoff_packet,
        "agent_submission_execution_packet_present": bool(packet),
        "agent_external_submission_decision_ready": _literal_true(
            readiness_report.get("agent_external_submission_decision_ready")
        ),
        "external_action_authorized": _literal_true(readiness_report.get("external_action_authorized")),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "preflight_ready_count": 1 if preflight_ready else 0,
            "agent_submission_execution_packet_present_count": 1 if packet else 0,
            "readiness_report_hash_match_count": 1 if readiness_snapshot.get("sha256_match") else 0,
            "source_target_hash_match_count": 1 if source_snapshot.get("sha256_match") else 0,
            "post_apply_verify_hash_match_count": 1 if post_apply_snapshot.get("sha256_match") else 0,
            "portal_capability_attestation_ready_count": 1 if attestation_ready else 0,
            "external_execution_capability_ready_count": 1 if capability_ready else 0,
            "external_execution_capability_gap_count": 0 if (capability_ready or not readiness_ready) else 1,
            "portal_capability_handoff_packet_count": 1 if portal_capability_handoff_packet else 0,
            "external_action_authorized_count": 1 if _literal_true(readiness_report.get("external_action_authorized")) else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "preflight_checks": checks,
        "readiness_report_snapshot": readiness_snapshot,
        "source_target_snapshot": source_snapshot,
        "post_apply_verify_report_snapshot": post_apply_snapshot,
        "finalization_report_snapshot": finalization_snapshot,
        "merge_submission_readiness_report_snapshot": merge_submission_snapshot,
        "agent_submission_execution_packet": packet,
        "portal_capability_attestation_report": portal_capability_attestation_report or {},
        "external_submission_readiness_report": readiness_report,
        "boundary": [
            "This command only preflights a local claim-derived external submission execution packet.",
            "It verifies local report/source hashes and explicit portal capability readiness, but does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "A later external-action execution command must record performed evidence before external_action_performed can become true.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_preflight_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Execution Preflight",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_external_submission_execution_preflight_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Preflight ready: {report.get('external_submission_execution_preflight_ready')}",
        f"- Portal capability ready: {report.get('portal_capability_ready')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for check in report.get("preflight_checks") or []:
        lines.append(f"- {check.get('status')}: {check.get('name')}")
    attestation = report.get("portal_capability_attestation_report") or {}
    if attestation:
        lines.extend(["", "## Portal Capability Attestation", ""])
        for key in [
            "portal_capability_attestation_state",
            "portal_capability_ready",
            "portal_capability_label",
            "claim_packet_id",
            "source_after_sha256",
            "external_submission_readiness_report_sha256",
        ]:
            lines.append(f"- {key}: {attestation.get(key) or ''}")
    handoff = report.get("portal_capability_handoff_packet") or {}
    if handoff:
        lines.extend(["", "## Portal Capability Handoff", ""])
        for key in [
            "packet_schema",
            "handoff_state",
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "external_submission_readiness_report_path",
        ]:
            lines.append(f"- {key}: {handoff.get(key) or ''}")
        lines.append("")
        lines.append("### Required Attestations")
        lines.append("")
        for item in handoff.get("required_portal_capability_attestations") or []:
            lines.append(f"- {item}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
