"""Run the claim external-submission record-only fixture execution harness."""

import datetime as dt
import hashlib

from paperctl_modules import (
    report_ref_health,
    research_compute_claim_manuscript_external_submission_execution_gate,
    research_compute_claim_manuscript_external_submission_execution_terminal_status,
)


COMMAND = "research-compute-claim-manuscript-external-submission-execution-record-only-fixture-harness"
INTENT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-intent"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_RECORD_ONLY_FIXTURE_HARNESS_READY"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_RECORD_ONLY_FIXTURE_HARNESS_IDLE_NO_INTENT"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_RECORD_ONLY_FIXTURE_HARNESS_WAITING_FOR_READY_INTENT"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_RECORD_ONLY_FIXTURE_HARNESS_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

INTENT_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_READY"
INTENT_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_IDLE_NO_PACKET"
INTENT_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_WAITING_FOR_PREFLIGHT"
INTENT_ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_INTENT_ATTENTION"


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _intent_packet(report):
    return (report or {}).get("external_submission_execution_intent_packet") or {}


def _validate_intent(report):
    issues = []
    item = report or {}
    packet = _intent_packet(item)
    _add_report_ref_health_issues(
        issues,
        "execution_intent",
        item,
        INTENT_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != INTENT_COMMAND:
        _add_issue(issues, "execution_intent_command_mismatch", item.get("command") or "")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_intent_boundary",
            "invalid_execution_intent_boolean",
        )
        _check_forbidden_boundary(
            issues,
            packet,
            key,
            "forbidden_execution_intent_packet_boundary",
            "invalid_execution_intent_packet_boolean",
        )
    state = item.get("claim_manuscript_external_submission_execution_intent_state") or ""
    if state not in {INTENT_READY_STATE, INTENT_IDLE_STATE, INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
        _add_issue(issues, "execution_intent_state_not_consumable", state)
    if state == INTENT_READY_STATE:
        if item.get("status") != "PASS":
            _add_issue(issues, "execution_intent_ready_not_pass", item.get("status") or "")
        _require_literal_true(
            issues,
            item,
            "external_submission_execution_intent_ready",
            "execution_intent_ready_flag_missing",
            "invalid_execution_intent_boolean",
        )
        if not packet:
            _add_issue(issues, "execution_intent_packet_missing")
        _require_literal_true(
            issues,
            item,
            "external_action_authorized",
            "external_action_not_authorized_for_fixture_harness",
            "invalid_execution_intent_boolean",
        )
        _require_literal_true(
            issues,
            packet,
            "external_action_authorized",
            "intent_packet_external_action_not_authorized_for_fixture_harness",
            "invalid_execution_intent_packet_boolean",
        )
        for key in [
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "post_apply_verify_report_path",
            "post_apply_verify_report_sha256",
            "execution_preflight_report_path",
            "execution_preflight_report_sha256",
            "portal_capability_label",
        ]:
            if not packet.get(key):
                _add_issue(issues, f"execution_intent_packet_missing:{key}")
    return issues


def _fixture_sha(packet):
    text = "|".join(
        [
            packet.get("claim_packet_id") or "",
            packet.get("source_target_path") or "",
            packet.get("source_after_sha256") or "",
            packet.get("execution_preflight_report_sha256") or "",
        ]
    )
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _record_only_fixture_evidence(intent_report, created_at=""):
    packet = _intent_packet(intent_report)
    return {
        "command": research_compute_claim_manuscript_external_submission_execution_gate.COMMAND,
        "evidence_type": "claim_manuscript_external_submission_execution_record_only_fixture",
        "evidence_schema": "paper_factory.research_compute.claim_manuscript_external_submission_record_only_fixture_evidence.v1",
        "record_only_fixture": True,
        "claim_packet_id": packet.get("claim_packet_id") or "",
        "slug": packet.get("slug") or "",
        "source_target_path": packet.get("source_target_path") or "",
        "source_after_sha256": packet.get("source_after_sha256") or "",
        "execution_preflight_report_path": packet.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": packet.get("execution_preflight_report_sha256") or "",
        "portal_session_ref_or_safe_attestation": "record-only-fixture:no-portal-session",
        "upload_artifact_manifest_sha256": _fixture_sha(packet),
        "submission_confirmation_id_or_terminal_status": "record-only-fixture:terminal-status-only",
        "external_action_started_at": created_at or "record-only-fixture",
        "external_action_finished_at": created_at or "record-only-fixture",
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
    }


def research_compute_claim_manuscript_external_submission_execution_record_only_fixture_harness(
    execution_intent_report,
    label="",
    created_at="",
):
    intent_report = execution_intent_report or {}
    issues = _validate_intent(intent_report)
    intent_state = intent_report.get("claim_manuscript_external_submission_execution_intent_state") or ""
    intent_ready = bool(
        intent_state == INTENT_READY_STATE
        and intent_report.get("status") == "PASS"
        and _literal_true(intent_report.get("external_submission_execution_intent_ready"))
        and _intent_packet(intent_report)
    )
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)

    fixture_evidence = {}
    gate_report = {}
    terminal_report = {}
    if not forbidden and intent_ready and not issues:
        fixture_evidence = _record_only_fixture_evidence(intent_report, created_at=created_at)
        gate_report = research_compute_claim_manuscript_external_submission_execution_gate.research_compute_claim_manuscript_external_submission_execution_gate(
            intent_report,
            performed_evidence=fixture_evidence,
            record_only_fixture=True,
            label=label or "",
        )
        terminal_report = research_compute_claim_manuscript_external_submission_execution_terminal_status.research_compute_claim_manuscript_external_submission_execution_terminal_status(
            gate_report,
            label=label or "",
        )
        if gate_report.get("status") == "FAIL" or terminal_report.get("status") == "FAIL":
            _add_issue(issues, "forbidden_fixture_harness_downstream_failure")
            forbidden = True
        elif gate_report.get("status") != "PASS" or terminal_report.get("status") != "PASS":
            _add_issue(issues, "fixture_harness_downstream_not_pass")

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif intent_state == INTENT_IDLE_STATE:
        status = "PASS"
        state = IDLE_STATE
    elif intent_state in {INTENT_WAITING_STATE, INTENT_ATTENTION_STATE}:
        status = "ATTENTION"
        state = WAITING_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif intent_ready:
        status = "PASS"
        state = READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE

    terminal_status = terminal_report.get("terminal_status") or ("IDLE_NO_INTENT" if state == IDLE_STATE else "")
    harness_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_external_submission_record_only_fixture_harness_state": state,
        "record_only_fixture_harness_created": status in {"PASS", "ATTENTION"},
        "record_only_fixture_generated": bool(fixture_evidence),
        "execution_gate_report_created": bool(gate_report),
        "terminal_status_report_created": bool(terminal_report),
        "terminal_status": terminal_status,
        "slug": intent_report.get("slug") or (_intent_packet(intent_report).get("slug") or ""),
        "execution_intent_report_path": intent_report.get("report_path") or "",
        "execution_intent_report_sha256": intent_report.get("report_sha256") or "",
        "claim_packet_id": intent_report.get("claim_packet_id") or (_intent_packet(intent_report).get("claim_packet_id") or ""),
        "source_target_path": _intent_packet(intent_report).get("source_target_path") or intent_report.get("source_target_path") or "",
        "source_after_sha256": _intent_packet(intent_report).get("source_after_sha256") or intent_report.get("source_after_sha256") or "",
        "external_action_authorized": bool(
            _literal_true(intent_report.get("external_action_authorized"))
            and _literal_true(_intent_packet(intent_report).get("external_action_authorized"))
        ),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "harness_ready_count": 1 if harness_ready else 0,
            "execution_intent_ready_count": 1 if intent_ready else 0,
            "record_only_fixture_generated_count": 1 if fixture_evidence else 0,
            "execution_gate_ready_count": 1 if _literal_true(gate_report.get("external_submission_execution_gate_ready")) else 0,
            "terminal_ready_count": int((terminal_report.get("summary") or {}).get("terminal_ready_count") or 0),
            "external_action_authorized_count": 1 if (
                _literal_true(intent_report.get("external_action_authorized"))
                and _literal_true(_intent_packet(intent_report).get("external_action_authorized"))
            ) else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "record_only_fixture_evidence": fixture_evidence,
        "execution_gate_report": gate_report,
        "terminal_status_report": terminal_report,
        "execution_intent_report": intent_report,
        "boundary": [
            "This command runs a local record-only fixture harness for a READY external-submission execution intent.",
            "It generates fixture evidence and consumes the existing execution gate and terminal-status modules; it does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "Record-only fixture evidence proves the machine path shape only and keeps external_action_performed=false.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_record_only_fixture_harness_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Record-Only Fixture Harness",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_external_submission_record_only_fixture_harness_state') or ''}",
        f"- Terminal status: {report.get('terminal_status') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Fixture generated: {report.get('record_only_fixture_generated')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
