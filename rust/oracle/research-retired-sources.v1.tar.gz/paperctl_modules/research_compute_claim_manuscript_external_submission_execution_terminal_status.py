"""Summarize claim external-submission execution gate terminal status."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-execution-terminal-status"
GATE_COMMAND = "research-compute-claim-manuscript-external-submission-execution-gate"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_RECORD_ONLY_FIXTURE_ACCEPTED"
PERFORMED_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
IDLE_GATE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_IDLE_NO_INTENT"
WAITING_GATE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_WAITING_FOR_INTENT"
EVIDENCE_REQUIRED_GATE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_EVIDENCE_REQUIRED"
ATTENTION_GATE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

TERMINAL_RECORD_ONLY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_RECORD_ONLY_FIXTURE_ACCEPTED"
TERMINAL_PERFORMED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_PERFORMED_EVIDENCE_ACCEPTED"
TERMINAL_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_IDLE_NO_INTENT"
TERMINAL_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_WAITING"
TERMINAL_ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_TERMINAL_ATTENTION"


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _require_literal_false(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _summary(report):
    return (report or {}).get("summary") or {}


def _validation_issue_count(report):
    report = report or {}
    try:
        summary_count = int(_summary(report).get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _validate_evidence_record(issues, item, record, performed):
    expected = {
        "claim_packet_id": item.get("claim_packet_id") or "",
        "source_target_path": item.get("source_target_path") or "",
        "source_after_sha256": item.get("source_after_sha256") or "",
        "execution_preflight_report_sha256": item.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_sha256": item.get("execution_intent_report_sha256") or "",
    }
    for key, expected_value in expected.items():
        if not expected_value:
            continue
        actual = record.get(key) or ""
        if not actual:
            _add_issue(issues, f"performed_evidence_record_missing_anchor:{key}")
        elif actual != expected_value:
            _add_issue(issues, f"performed_evidence_record_anchor_mismatch:{key}", actual)
    expected_type = (
        "claim_manuscript_external_submission_execution_performed_evidence"
        if performed
        else "claim_manuscript_external_submission_execution_record_only_fixture"
    )
    if record.get("record_type") and record.get("record_type") != expected_type:
        _add_issue(issues, "performed_evidence_record_type_mismatch", record.get("record_type") or "")
    if performed:
        _require_literal_false(
            issues,
            record,
            "record_only_fixture",
            "record_only_fixture_not_allowed_for_performed_terminal_record",
            "invalid_performed_evidence_record_boolean",
        )
    else:
        _require_literal_true(
            issues,
            record,
            "record_only_fixture",
            "record_only_fixture_required_for_terminal_record",
            "invalid_performed_evidence_record_boolean",
        )


def _validate_gate(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(
        issues,
        "execution_gate",
        item,
        GATE_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != GATE_COMMAND:
        _add_issue(issues, "execution_gate_command_mismatch", item.get("command") or "")
    state = item.get("claim_manuscript_external_submission_execution_gate_state") or ""
    if state not in {READY_STATE, PERFORMED_READY_STATE, IDLE_GATE_STATE, WAITING_GATE_STATE, EVIDENCE_REQUIRED_GATE_STATE, ATTENTION_GATE_STATE, FORBIDDEN_STATE}:
        _add_issue(issues, "execution_gate_state_not_consumable", state)
    if state == FORBIDDEN_STATE or item.get("status") == "FAIL":
        _add_issue(issues, "forbidden_execution_gate_report_failed", item.get("status") or "")
    if item.get("status") not in {"PASS", "ATTENTION", "FAIL"}:
        _add_issue(issues, "execution_gate_status_not_consumable", item.get("status") or "")
    if _validation_issue_count(item):
        _add_issue(issues, "execution_gate_validation_issues_present")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_gate_boundary",
            "invalid_execution_gate_boolean",
        )
    if state == READY_STATE:
        if item.get("status") != "PASS":
            _add_issue(issues, "execution_gate_ready_not_pass", item.get("status") or "")
        _require_literal_true(
            issues,
            item,
            "external_submission_execution_gate_ready",
            "execution_gate_ready_flag_missing",
            "invalid_execution_gate_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "performed_evidence_recorded",
            "performed_evidence_recorded_required",
            "invalid_execution_gate_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "record_only_fixture",
            "record_only_fixture_required_for_terminal_record",
            "invalid_execution_gate_boolean",
        )
        if not item.get("performed_evidence_record"):
            _add_issue(issues, "performed_evidence_record_required")
        _require_literal_false(
            issues,
            item,
            "external_action_performed",
            "forbidden_record_only_terminal_external_action_must_be_false",
            "invalid_execution_gate_boolean",
        )
        record = item.get("performed_evidence_record") or {}
        if record:
            _validate_evidence_record(issues, item, record, performed=False)
    if state == PERFORMED_READY_STATE:
        if item.get("status") != "PASS":
            _add_issue(issues, "execution_gate_ready_not_pass", item.get("status") or "")
        _require_literal_true(
            issues,
            item,
            "external_submission_execution_gate_ready",
            "execution_gate_ready_flag_missing",
            "invalid_execution_gate_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "performed_evidence_recorded",
            "performed_evidence_recorded_required",
            "invalid_execution_gate_boolean",
        )
        _require_literal_false(
            issues,
            item,
            "record_only_fixture",
            "record_only_fixture_not_allowed_for_performed_terminal",
            "invalid_execution_gate_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "external_action_performed",
            "performed_terminal_external_action_required",
            "invalid_execution_gate_boolean",
        )
        record = item.get("performed_evidence_record") or {}
        if not record:
            _add_issue(issues, "performed_evidence_record_required")
        else:
            _require_literal_true(
                issues,
                record,
                "external_action_performed",
                "performed_evidence_record_external_action_required",
                "invalid_performed_evidence_record_boolean",
            )
            _validate_evidence_record(issues, item, record, performed=True)
    return issues


def research_compute_claim_manuscript_external_submission_execution_terminal_status(
    execution_gate_report,
    label="",
):
    gate_report = execution_gate_report or {}
    gate_summary = gate_report.get("summary") or {}
    issues = _validate_gate(gate_report)
    gate_state = gate_report.get("claim_manuscript_external_submission_execution_gate_state") or ""
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    template_count = int(gate_summary.get("performed_evidence_template_count") or 0)
    missing_field_count = int(gate_summary.get("performed_evidence_missing_field_count") or 0)

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
        terminal_status = ""
    elif issues:
        status = "ATTENTION"
        if gate_state in {WAITING_GATE_STATE, EVIDENCE_REQUIRED_GATE_STATE, ATTENTION_GATE_STATE}:
            state = TERMINAL_WAITING_STATE
            terminal_status = "WAITING_FOR_PERFORMED_EVIDENCE_OR_INTENT"
        else:
            state = TERMINAL_ATTENTION_STATE
            terminal_status = ""
    elif gate_state == READY_STATE:
        status = "PASS"
        state = TERMINAL_RECORD_ONLY_STATE
        terminal_status = "RECORD_ONLY_FIXTURE_ACCEPTED"
    elif gate_state == PERFORMED_READY_STATE:
        status = "PASS"
        state = TERMINAL_PERFORMED_STATE
        terminal_status = "PERFORMED_EVIDENCE_ACCEPTED"
    elif gate_state == IDLE_GATE_STATE:
        status = "PASS"
        state = TERMINAL_IDLE_STATE
        terminal_status = "IDLE_NO_INTENT"
    elif gate_state in {WAITING_GATE_STATE, EVIDENCE_REQUIRED_GATE_STATE, ATTENTION_GATE_STATE}:
        status = "ATTENTION"
        state = TERMINAL_WAITING_STATE
        terminal_status = "WAITING_FOR_PERFORMED_EVIDENCE_OR_INTENT"
    else:
        status = "ATTENTION"
        state = TERMINAL_ATTENTION_STATE
        terminal_status = ""

    terminal_packet = {
        "packet_type": "claim_manuscript_external_submission_execution_terminal_status",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_execution_terminal_status_packet.v1",
        "terminal_status": terminal_status,
        "terminal_ready": status == "PASS",
        "record_only_fixture": _literal_true(gate_report.get("record_only_fixture")),
        "performed_evidence_recorded": _literal_true(gate_report.get("performed_evidence_recorded")),
        "performed_evidence_template_count": template_count,
        "performed_evidence_missing_field_count": missing_field_count,
        "external_action_performed": _literal_true(gate_report.get("external_action_performed")) and terminal_status == "PERFORMED_EVIDENCE_ACCEPTED",
        "secret_material_read_performed": False,
        "real_external_executor_required_for_performed_action": terminal_status not in {"RECORD_ONLY_FIXTURE_ACCEPTED", "PERFORMED_EVIDENCE_ACCEPTED"},
    }
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_external_submission_execution_terminal_status_state": state,
        "terminal_status_created": status in {"PASS", "ATTENTION"},
        "terminal_status": terminal_status,
        "execution_gate_report_path": gate_report.get("report_path") or "",
        "execution_gate_report_sha256": gate_report.get("report_sha256") or "",
        "claim_packet_id": gate_report.get("claim_packet_id") or "",
        "source_target_path": gate_report.get("source_target_path") or "",
        "source_after_sha256": gate_report.get("source_after_sha256") or "",
        "external_submission_execution_gate_ready": _literal_true(gate_report.get("external_submission_execution_gate_ready")),
        "performed_evidence_recorded": _literal_true(gate_report.get("performed_evidence_recorded")),
        "performed_evidence_template_count": template_count,
        "performed_evidence_missing_field_count": missing_field_count,
        "record_only_fixture": _literal_true(gate_report.get("record_only_fixture")),
        "external_action_authorized": _literal_true(gate_report.get("external_action_authorized")),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": _literal_true(gate_report.get("external_action_performed")) and terminal_status == "PERFORMED_EVIDENCE_ACCEPTED",
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "terminal_status_created_count": 1 if status in {"PASS", "ATTENTION"} else 0,
            "terminal_ready_count": 1 if status == "PASS" else 0,
            "record_only_fixture_count": 1 if _literal_true(gate_report.get("record_only_fixture")) else 0,
            "performed_evidence_recorded_count": 1 if _literal_true(gate_report.get("performed_evidence_recorded")) else 0,
            "performed_evidence_template_count": template_count,
            "performed_evidence_missing_field_count": missing_field_count,
            "external_action_authorized_count": 1 if _literal_true(gate_report.get("external_action_authorized")) else 0,
            "external_action_performed_count": 1 if (
                _literal_true(gate_report.get("external_action_performed"))
                and terminal_status == "PERFORMED_EVIDENCE_ACCEPTED"
            ) else 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "terminal_status_packet": terminal_packet,
        "execution_gate_report": gate_report,
        "boundary": [
            "This command summarizes external-submission execution gate terminal status only.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
            "Record-only fixture acceptance is not real external performed evidence; real performed-evidence records may carry external_action_performed=true.",
        ],
    }


def research_compute_claim_manuscript_external_submission_execution_terminal_status_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Execution Terminal Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_external_submission_execution_terminal_status_state') or ''}",
        f"- Terminal status: {report.get('terminal_status') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Gate ready: {report.get('external_submission_execution_gate_ready')}",
        f"- Performed evidence recorded: {report.get('performed_evidence_recorded')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
