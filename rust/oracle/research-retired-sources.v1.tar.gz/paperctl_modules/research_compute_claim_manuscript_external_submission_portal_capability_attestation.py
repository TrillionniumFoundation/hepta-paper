"""Validate local portal-capability attestations for claim submission preflight."""

import datetime as dt
import re

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-portal-capability-attestation"
PREFLIGHT_COMMAND = "research-compute-claim-manuscript-external-submission-execution-preflight"
INTAKE_COMMAND = "research-compute-claim-manuscript-external-submission-portal-capability-attestation-intake"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_READY"
TEMPLATE_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_TEMPLATE_REQUIRED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_IDLE_NO_PACKET"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_WAITING_FOR_PREFLIGHT"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_READY"
PREFLIGHT_CAPABILITY_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_CAPABILITY_REQUIRED"
PREFLIGHT_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_IDLE_NO_PACKET"
PREFLIGHT_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_WAITING"

REQUIRED_ATTESTATION_FIELDS = [
    "portal_session_ref_or_safe_attestation",
    "target_portal_route",
    "upload_artifact_manifest_sha256",
    "authorization_ref",
    "attestation_operator_id",
]

SHA256_RE = re.compile(r"^[0-9a-f]{64}$")
SECRET_LIKE_RE = re.compile(r"(password|passwd|token|secret|cookie|bearer\s+|api[_-]?key)\s*[:=]", re.IGNORECASE)


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _require_literal_true(issues, item, key, issue, invalid_prefix):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key, forbidden_prefix, invalid_prefix):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"{forbidden_prefix}:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"{invalid_prefix}:{key}", repr(value))


def _handoff_packet(report):
    return (report or {}).get("portal_capability_handoff_packet") or {}


def _intake_packet(report):
    return (report or {}).get("portal_capability_attestation_intake_packet") or {}


def _field(raw):
    return str(raw or "").strip()


def _secret_like(*values):
    return any(SECRET_LIKE_RE.search(str(value or "")) for value in values)


def _validate_preflight(report):
    issues = []
    item = report or {}
    handoff = _handoff_packet(item)
    _add_report_ref_health_issues(
        issues,
        "execution_preflight",
        item,
        PREFLIGHT_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != PREFLIGHT_COMMAND:
        _add_issue(issues, "execution_preflight_command_mismatch", item.get("command") or "")
    if item.get("status") not in {"PASS", "ATTENTION"}:
        _add_issue(issues, "execution_preflight_status_not_consumable", item.get("status") or "")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_execution_preflight_boundary",
            "invalid_execution_preflight_boolean",
        )
        _check_forbidden_boundary(
            issues,
            handoff,
            key,
            "forbidden_portal_capability_handoff_boundary",
            "invalid_portal_capability_handoff_boolean",
        )
    state = item.get("claim_manuscript_external_submission_execution_preflight_state") or ""
    if state not in {PREFLIGHT_READY_STATE, PREFLIGHT_CAPABILITY_REQUIRED_STATE, PREFLIGHT_IDLE_STATE, PREFLIGHT_WAITING_STATE}:
        _add_issue(issues, "execution_preflight_state_not_consumable", state)
    if state == PREFLIGHT_CAPABILITY_REQUIRED_STATE:
        _require_literal_true(
            issues,
            item,
            "portal_capability_handoff_packet_created",
            "portal_capability_handoff_packet_missing",
            "invalid_execution_preflight_boolean",
        )
        if not handoff:
            _add_issue(issues, "portal_capability_handoff_packet_empty")
        _require_literal_true(
            issues,
            item,
            "agent_submission_execution_packet_present",
            "agent_submission_execution_packet_missing",
            "invalid_execution_preflight_boolean",
        )
        _require_literal_true(
            issues,
            item,
            "external_action_authorized",
            "external_action_not_authorized_for_capability_attestation",
            "invalid_execution_preflight_boolean",
        )
        for key in ["claim_packet_id", "source_target_path", "source_after_sha256", "external_submission_readiness_report_sha256"]:
            if not item.get(key) and not handoff.get(key):
                _add_issue(issues, f"portal_capability_handoff_missing:{key}")
    return issues


def _required_field_issues(
    portal_session_ref_or_safe_attestation,
    target_portal_route,
    upload_artifact_manifest_sha256,
    authorization_ref,
    attestation_operator_id,
):
    issues = []
    required = {
        "portal_session_ref_or_safe_attestation": portal_session_ref_or_safe_attestation,
        "target_portal_route": target_portal_route,
        "upload_artifact_manifest_sha256": upload_artifact_manifest_sha256,
        "authorization_ref": authorization_ref,
        "attestation_operator_id": attestation_operator_id,
    }
    for key in REQUIRED_ATTESTATION_FIELDS:
        value = required.get(key)
        if not _field(value):
            _add_issue(issues, f"capability_attestation_missing:{key}")
    if upload_artifact_manifest_sha256 and not SHA256_RE.match(_field(upload_artifact_manifest_sha256)):
        _add_issue(issues, "upload_artifact_manifest_sha256_not_sha256", _field(upload_artifact_manifest_sha256))
    if _secret_like(portal_session_ref_or_safe_attestation, target_portal_route, authorization_ref, attestation_operator_id):
        _add_issue(issues, "forbidden_secret_like_capability_attestation_material")
    return issues


def _fields_from_intake(report):
    packet = _intake_packet(report)
    return {
        "portal_session_ref_or_safe_attestation": _field(packet.get("portal_session_ref_or_safe_attestation")),
        "target_portal_route": _field(packet.get("target_portal_route")),
        "upload_artifact_manifest_sha256": _field(packet.get("upload_artifact_manifest_sha256")),
        "authorization_ref": _field(packet.get("authorization_ref")),
        "attestation_operator_id": _field(packet.get("attestation_operator_id")),
        "capability_attestation_id": _field(packet.get("capability_attestation_id")),
        "portal_capability_label": _field(packet.get("portal_capability_label"))
        or _field(packet.get("capability_attestation_id")),
    }


def _validate_intake(report, preflight_report, handoff):
    issues = []
    item = report or {}
    packet = _intake_packet(item)
    if not item:
        return issues, {}, False
    _add_report_ref_health_issues(
        issues,
        "portal_capability_attestation_intake",
        item,
        INTAKE_COMMAND,
    )
    if item.get("command") != INTAKE_COMMAND:
        _add_issue(issues, "portal_capability_attestation_intake_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "portal_capability_attestation_intake_not_pass", item.get("status") or "")
    if item.get("portal_capability_attestation_intake_state") != "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_INTAKE_READY":
        _add_issue(
            issues,
            "portal_capability_attestation_intake_not_ready",
            item.get("portal_capability_attestation_intake_state") or "",
        )
    _require_literal_true(
        issues,
        item,
        "portal_capability_attestation_intake_ready",
        "portal_capability_attestation_intake_ready_flag_missing",
        "invalid_portal_capability_attestation_intake_boolean",
    )
    if not packet:
        _add_issue(issues, "portal_capability_attestation_intake_packet_missing")
    for key in _forbidden_keys():
        _check_forbidden_boundary(
            issues,
            item,
            key,
            "forbidden_portal_capability_attestation_intake_boundary",
            "invalid_portal_capability_attestation_intake_boolean",
        )
        _check_forbidden_boundary(
            issues,
            packet,
            key,
            "forbidden_portal_capability_attestation_intake_packet_boundary",
            "invalid_portal_capability_attestation_intake_packet_boolean",
        )
    fields = _fields_from_intake(item)
    issues.extend(
        _required_field_issues(
            fields["portal_session_ref_or_safe_attestation"],
            fields["target_portal_route"],
            fields["upload_artifact_manifest_sha256"],
            fields["authorization_ref"],
            fields["attestation_operator_id"],
        )
    )
    expected_claim = preflight_report.get("claim_packet_id") or handoff.get("claim_packet_id") or ""
    expected_source_path = preflight_report.get("source_target_path") or handoff.get("source_target_path") or ""
    expected_source = preflight_report.get("source_after_sha256") or handoff.get("source_after_sha256") or ""
    expected_readiness_sha = (
        preflight_report.get("external_submission_readiness_report_sha256")
        or handoff.get("external_submission_readiness_report_sha256")
        or ""
    )
    expected_preflight_sha = preflight_report.get("report_sha256") or ""
    if expected_claim and packet.get("claim_packet_id") and packet.get("claim_packet_id") != expected_claim:
        _add_issue(issues, "portal_capability_attestation_intake_claim_packet_mismatch", packet.get("claim_packet_id") or "")
    if expected_source_path and packet.get("source_target_path") and packet.get("source_target_path") != expected_source_path:
        _add_issue(issues, "portal_capability_attestation_intake_source_target_mismatch", packet.get("source_target_path") or "")
    if expected_source and packet.get("source_after_sha256") and packet.get("source_after_sha256") != expected_source:
        _add_issue(issues, "portal_capability_attestation_intake_source_sha_mismatch", packet.get("source_after_sha256") or "")
    if (
        expected_readiness_sha
        and packet.get("external_submission_readiness_report_sha256")
        and packet.get("external_submission_readiness_report_sha256") != expected_readiness_sha
    ):
        _add_issue(
            issues,
            "portal_capability_attestation_intake_readiness_sha_mismatch",
            packet.get("external_submission_readiness_report_sha256") or "",
        )
    if (
        expected_preflight_sha
        and packet.get("execution_preflight_report_sha256")
        and packet.get("execution_preflight_report_sha256") != expected_preflight_sha
    ):
        _add_issue(
            issues,
            "portal_capability_attestation_intake_preflight_sha_mismatch",
            packet.get("execution_preflight_report_sha256") or "",
        )
    ready = bool(not issues and _literal_true(item.get("portal_capability_attestation_intake_ready")))
    return issues, fields, ready


def _attestation_packet(preflight_report, handoff, ready, fields):
    if not ready:
        return {}
    claim_packet_id = preflight_report.get("claim_packet_id") or handoff.get("claim_packet_id") or ""
    source_target_path = preflight_report.get("source_target_path") or handoff.get("source_target_path") or ""
    source_after_sha256 = preflight_report.get("source_after_sha256") or handoff.get("source_after_sha256") or ""
    readiness_report_path = (
        preflight_report.get("external_submission_readiness_report_path")
        or handoff.get("external_submission_readiness_report_path")
        or ""
    )
    readiness_report_sha256 = (
        preflight_report.get("external_submission_readiness_report_sha256")
        or handoff.get("external_submission_readiness_report_sha256")
        or ""
    )
    return {
        "packet_type": "claim_manuscript_external_submission_portal_capability_attestation",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_attestation.v1",
        "attestation_state": READY_STATE,
        "claim_packet_id": claim_packet_id,
        "slug": preflight_report.get("slug") or handoff.get("slug") or "",
        "source_target_path": source_target_path,
        "source_after_sha256": source_after_sha256,
        "external_submission_readiness_report_path": readiness_report_path,
        "external_submission_readiness_report_sha256": readiness_report_sha256,
        "execution_preflight_report_path": preflight_report.get("report_path") or "",
        "execution_preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "portal_capability_attestation_intake_report_path": fields.get("portal_capability_attestation_intake_report_path", ""),
        "portal_capability_attestation_intake_report_sha256": fields.get("portal_capability_attestation_intake_report_sha256", ""),
        "portal_capability_label": fields["portal_capability_label"],
        "portal_session_ref_or_safe_attestation": fields["portal_session_ref_or_safe_attestation"],
        "target_portal_route": fields["target_portal_route"],
        "upload_artifact_manifest_sha256": fields["upload_artifact_manifest_sha256"],
        "authorization_ref": fields["authorization_ref"],
        "attestation_operator_id": fields["attestation_operator_id"],
        "capability_attestation_id": fields["capability_attestation_id"],
        "attestation_is_not_performed_evidence": True,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "actions_not_performed_by_this_attestation": [
            "secret read",
            "portal login",
            "portal upload",
            "email",
            "final submit",
            "merge",
            "commit",
            "source/package/archive mutation",
        ],
    }


def _template_packet(preflight_report, handoff, state, fields, issues):
    if state != TEMPLATE_REQUIRED_STATE:
        return {}
    missing_fields = [
        str(item.get("issue") or "").split("capability_attestation_missing:", 1)[1]
        for item in issues
        if str(item.get("issue") or "").startswith("capability_attestation_missing:")
    ]
    return {
        "packet_type": "claim_manuscript_external_submission_portal_capability_attestation_template",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_attestation_template.v1",
        "attestation_state": TEMPLATE_REQUIRED_STATE,
        "claim_packet_id": preflight_report.get("claim_packet_id") or handoff.get("claim_packet_id") or "",
        "slug": preflight_report.get("slug") or handoff.get("slug") or "",
        "source_target_path": preflight_report.get("source_target_path") or handoff.get("source_target_path") or "",
        "source_after_sha256": preflight_report.get("source_after_sha256") or handoff.get("source_after_sha256") or "",
        "external_submission_readiness_report_path": preflight_report.get("external_submission_readiness_report_path") or handoff.get("external_submission_readiness_report_path") or "",
        "external_submission_readiness_report_sha256": preflight_report.get("external_submission_readiness_report_sha256") or handoff.get("external_submission_readiness_report_sha256") or "",
        "execution_preflight_report_path": preflight_report.get("report_path") or "",
        "execution_preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "required_fields": list(REQUIRED_ATTESTATION_FIELDS),
        "missing_fields": missing_fields,
        "supplied_field_presence": {key: bool(fields.get(key)) for key in REQUIRED_ATTESTATION_FIELDS},
        "safe_field_notes": {
            "portal_session_ref_or_safe_attestation": "Use a non-secret local reference or statement that the operator has a portal session/capability ready. Do not record cookies, passwords, bearer tokens, or session ids.",
            "target_portal_route": "Name the venue portal route or local operator-facing destination.",
            "upload_artifact_manifest_sha256": "Use the sha256 of the local upload artifact manifest intended for the portal.",
            "authorization_ref": "Use a non-secret local authorization reference, for example a Telegram/message/event id.",
            "attestation_operator_id": "Use a non-secret operator identifier.",
        },
        "forbidden_material": [
            "passwords",
            "tokens",
            "cookies",
            "bearer credentials",
            "api keys",
            "portal session secrets",
        ],
        "external_action_performed": False,
        "secret_material_read_performed": False,
    }


def research_compute_claim_manuscript_external_submission_portal_capability_attestation(
    execution_preflight_report,
    portal_session_ref_or_safe_attestation="",
    target_portal_route="",
    upload_artifact_manifest_sha256="",
    authorization_ref="",
    attestation_operator_id="",
    capability_attestation_id="",
    portal_capability_label="",
    label="",
    portal_capability_attestation_intake_report=None,
):
    preflight_report = execution_preflight_report or {}
    handoff = _handoff_packet(preflight_report)
    fields = {
        "portal_session_ref_or_safe_attestation": _field(portal_session_ref_or_safe_attestation),
        "target_portal_route": _field(target_portal_route),
        "upload_artifact_manifest_sha256": _field(upload_artifact_manifest_sha256),
        "authorization_ref": _field(authorization_ref),
        "attestation_operator_id": _field(attestation_operator_id),
        "capability_attestation_id": _field(capability_attestation_id),
        "portal_capability_label": _field(portal_capability_label) or _field(capability_attestation_id),
    }
    intake_issues, intake_fields, intake_ready = _validate_intake(
        portal_capability_attestation_intake_report,
        preflight_report,
        handoff,
    )
    if intake_ready:
        fields.update(intake_fields)
        fields["portal_capability_attestation_intake_report_path"] = (
            portal_capability_attestation_intake_report or {}
        ).get("report_path") or ""
        fields["portal_capability_attestation_intake_report_sha256"] = (
            portal_capability_attestation_intake_report or {}
        ).get("report_sha256") or ""
    issues = _validate_preflight(preflight_report) + _required_field_issues(
        fields["portal_session_ref_or_safe_attestation"],
        fields["target_portal_route"],
        fields["upload_artifact_manifest_sha256"],
        fields["authorization_ref"],
        fields["attestation_operator_id"],
    ) + intake_issues
    preflight_state = preflight_report.get("claim_manuscript_external_submission_execution_preflight_state") or ""
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif preflight_state == PREFLIGHT_IDLE_STATE:
        status = "PASS"
        state = IDLE_STATE
    elif preflight_state == PREFLIGHT_WAITING_STATE:
        status = "PASS"
        state = WAITING_STATE
    elif issues:
        status = "ATTENTION"
        state = TEMPLATE_REQUIRED_STATE if any(str(item.get("issue") or "").startswith("capability_attestation_missing:") for item in issues) else ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    ready = bool(status == "PASS" and state == READY_STATE)
    attestation_packet = _attestation_packet(preflight_report, handoff, ready, fields)
    template_packet = _template_packet(preflight_report, handoff, state, fields, issues)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "portal_capability_attestation_state": state,
        "portal_capability_attestation_created": status in {"PASS", "ATTENTION"},
        "portal_capability_ready": ready,
        "portal_capability_label": fields["portal_capability_label"],
        "slug": preflight_report.get("slug") or handoff.get("slug") or "",
        "execution_preflight_report_path": preflight_report.get("report_path") or "",
        "execution_preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "portal_capability_attestation_intake_report_path": (
            portal_capability_attestation_intake_report or {}
        ).get("report_path") or "",
        "portal_capability_attestation_intake_report_sha256": (
            portal_capability_attestation_intake_report or {}
        ).get("report_sha256") or "",
        "portal_capability_attestation_intake_consumed": bool(intake_ready),
        "claim_packet_id": preflight_report.get("claim_packet_id") or handoff.get("claim_packet_id") or "",
        "source_target_path": preflight_report.get("source_target_path") or handoff.get("source_target_path") or "",
        "source_after_sha256": preflight_report.get("source_after_sha256") or handoff.get("source_after_sha256") or "",
        "external_submission_readiness_report_path": preflight_report.get("external_submission_readiness_report_path") or handoff.get("external_submission_readiness_report_path") or "",
        "external_submission_readiness_report_sha256": preflight_report.get("external_submission_readiness_report_sha256") or handoff.get("external_submission_readiness_report_sha256") or "",
        "portal_session_ref_or_safe_attestation": fields["portal_session_ref_or_safe_attestation"],
        "target_portal_route": fields["target_portal_route"],
        "upload_artifact_manifest_sha256": fields["upload_artifact_manifest_sha256"],
        "authorization_ref": fields["authorization_ref"],
        "attestation_operator_id": fields["attestation_operator_id"],
        "capability_attestation_id": fields["capability_attestation_id"],
        "attestation_is_not_performed_evidence": bool(attestation_packet),
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "portal_capability_ready_count": 1 if ready else 0,
            "portal_capability_attestation_packet_count": 1 if attestation_packet else 0,
            "portal_capability_attestation_template_count": 1 if template_packet else 0,
            "portal_capability_attestation_intake_consumed_count": 1 if intake_ready else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "portal_capability_attestation_packet": attestation_packet,
        "portal_capability_attestation_template_packet": template_packet,
        "portal_capability_attestation_intake_report": portal_capability_attestation_intake_report or {},
        "execution_preflight_report": preflight_report,
        "boundary": [
            "This command records a local portal-capability attestation for a claim external-submission preflight.",
            "The attestation is capability evidence only; it is not performed external-action evidence.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
        ],
    }


def research_compute_claim_manuscript_external_submission_portal_capability_attestation_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Portal Capability Attestation",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('portal_capability_attestation_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Portal capability ready: {report.get('portal_capability_ready')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("portal_capability_attestation_packet") or {}
    if packet:
        lines.extend(["", "## Attestation Packet", ""])
        for key in [
            "packet_schema",
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "external_submission_readiness_report_sha256",
            "execution_preflight_report_sha256",
            "portal_capability_attestation_intake_report_sha256",
            "portal_capability_label",
            "target_portal_route",
            "upload_artifact_manifest_sha256",
            "authorization_ref",
            "attestation_operator_id",
        ]:
            lines.append(f"- {key}: {packet.get(key) or ''}")
    intake = report.get("portal_capability_attestation_intake_report") or {}
    if intake:
        lines.extend(["", "## Intake Report", ""])
        for key in [
            "portal_capability_attestation_intake_state",
            "portal_capability_attestation_intake_ready",
            "report_sha256",
            "claim_packet_id",
            "source_target_path",
            "execution_preflight_report_sha256",
        ]:
            lines.append(f"- {key}: {intake.get(key) or ''}")
    template = report.get("portal_capability_attestation_template_packet") or {}
    if template:
        lines.extend(["", "## Attestation Template", ""])
        lines.append(f"- packet_schema: {template.get('packet_schema') or ''}")
        lines.append(f"- claim_packet_id: {template.get('claim_packet_id') or ''}")
        lines.append(f"- source_target_path: {template.get('source_target_path') or ''}")
        lines.append(f"- execution_preflight_report_sha256: {template.get('execution_preflight_report_sha256') or ''}")
        lines.append(f"- missing_fields: {', '.join(template.get('missing_fields') or [])}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
