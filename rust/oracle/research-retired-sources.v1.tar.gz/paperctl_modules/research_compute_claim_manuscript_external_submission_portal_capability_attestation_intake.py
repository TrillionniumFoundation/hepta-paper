"""Verify operator safe-field intake for portal-capability attestation."""

import datetime as dt
import re

from paperctl_modules import (
    report_ref_health,
    research_compute_claim_manuscript_external_submission_portal_capability_attestation as attestation,
)


COMMAND = "research-compute-claim-manuscript-external-submission-portal-capability-attestation-intake"
TEMPLATE_COMMAND = attestation.COMMAND
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_INTAKE_READY"
TEMPLATE_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_INTAKE_TEMPLATE_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_PORTAL_CAPABILITY_ATTESTATION_INTAKE_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

REQUIRED_FIELDS = list(attestation.REQUIRED_ATTESTATION_FIELDS)
OPTIONAL_RESPONSE_FIELDS = [
    "capability_attestation_id",
    "portal_capability_label",
]
RESPONSE_FIELDS = REQUIRED_FIELDS + OPTIONAL_RESPONSE_FIELDS
SHA256_RE = attestation.SHA256_RE
OPERATOR_RESPONSE_PACKET_SCHEMA = (
    "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_attestation_operator_response.v1"
)
SECRET_LIKE_RE = re.compile(
    r"((password|passwd|token|secret|cookie|api[_-]?key)\s*[:=]|bearer\s+)",
    re.IGNORECASE,
)


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "secret_material_read_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _field(raw):
    return str(raw or "").strip()


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _secret_like_value(raw):
    if isinstance(raw, dict):
        return any(_secret_like_value(value) for value in raw.values())
    if isinstance(raw, (list, tuple, set)):
        return any(_secret_like_value(value) for value in raw)
    return bool(SECRET_LIKE_RE.search(str(raw or "")))


def _template_packet(report):
    return (report or {}).get("portal_capability_attestation_template_packet") or {}


def _normalize_operator_response_packet(raw):
    item = raw or {}
    for key in [
        "portal_capability_attestation_operator_response_packet",
        "operator_response_packet",
        "portal_capability_attestation_operator_response_packet_template",
        "operator_response_packet_template",
    ]:
        nested = item.get(key)
        if isinstance(nested, dict):
            return nested
    return item if isinstance(item, dict) else {}


def _field_map(
    portal_session_ref_or_safe_attestation="",
    target_portal_route="",
    upload_artifact_manifest_sha256="",
    authorization_ref="",
    attestation_operator_id="",
    capability_attestation_id="",
    portal_capability_label="",
):
    return {
        "portal_session_ref_or_safe_attestation": _field(portal_session_ref_or_safe_attestation),
        "target_portal_route": _field(target_portal_route),
        "upload_artifact_manifest_sha256": _field(upload_artifact_manifest_sha256),
        "authorization_ref": _field(authorization_ref),
        "attestation_operator_id": _field(attestation_operator_id),
        "capability_attestation_id": _field(capability_attestation_id),
        "portal_capability_label": _field(portal_capability_label) or _field(capability_attestation_id),
    }


def _response_fields(response_packet):
    packet = response_packet or {}
    return _field_map(
        portal_session_ref_or_safe_attestation=packet.get("portal_session_ref_or_safe_attestation"),
        target_portal_route=packet.get("target_portal_route"),
        upload_artifact_manifest_sha256=packet.get("upload_artifact_manifest_sha256"),
        authorization_ref=packet.get("authorization_ref"),
        attestation_operator_id=packet.get("attestation_operator_id"),
        capability_attestation_id=packet.get("capability_attestation_id"),
        portal_capability_label=packet.get("portal_capability_label"),
    )


def _template_anchor_map(template_report):
    template = _template_packet(template_report)
    return {
        "claim_packet_id": template.get("claim_packet_id") or template_report.get("claim_packet_id") or "",
        "slug": template.get("slug") or template_report.get("slug") or "",
        "source_target_path": template.get("source_target_path") or template_report.get("source_target_path") or "",
        "source_after_sha256": template.get("source_after_sha256") or template_report.get("source_after_sha256") or "",
        "external_submission_readiness_report_sha256": (
            template.get("external_submission_readiness_report_sha256")
            or template_report.get("external_submission_readiness_report_sha256")
            or ""
        ),
        "execution_preflight_report_sha256": (
            template.get("execution_preflight_report_sha256")
            or template_report.get("execution_preflight_report_sha256")
            or ""
        ),
    }


def _validate_template_report(report):
    issues = []
    item = report or {}
    packet = _template_packet(item)
    _add_report_ref_health_issues(
        issues,
        "portal_capability_attestation_template",
        item,
        TEMPLATE_COMMAND,
        require_clean_summary=item.get("status") != "ATTENTION",
    )
    if item.get("command") != TEMPLATE_COMMAND:
        _add_issue(issues, "portal_capability_attestation_template_command_mismatch", item.get("command") or "")
    if item.get("status") not in {"ATTENTION", "PASS"}:
        _add_issue(issues, "portal_capability_attestation_template_status_not_consumable", item.get("status") or "")
    if not packet:
        _add_issue(issues, "portal_capability_attestation_template_packet_missing")
    if packet and packet.get("packet_schema") != "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_attestation_template.v1":
        _add_issue(issues, "portal_capability_attestation_template_schema_mismatch", packet.get("packet_schema") or "")
    for key in _forbidden_keys():
        if item.get(key):
            _add_issue(issues, f"forbidden_portal_capability_attestation_template_boundary:{key}")
        if packet.get(key):
            _add_issue(issues, f"forbidden_portal_capability_attestation_template_packet_boundary:{key}")
    return issues


def _validate_operator_response_packet(operator_response_packet, template_report):
    response = _normalize_operator_response_packet(operator_response_packet)
    if not response:
        return [], {}, {}
    issues = []
    if response.get("packet_type") != "claim_manuscript_external_submission_portal_capability_attestation_operator_response":
        _add_issue(issues, "portal_capability_attestation_operator_response_packet_type_mismatch", response.get("packet_type") or "")
    if response.get("packet_schema") != OPERATOR_RESPONSE_PACKET_SCHEMA:
        _add_issue(issues, "portal_capability_attestation_operator_response_schema_mismatch", response.get("packet_schema") or "")
    if response.get("operator_response_completed") is not True:
        _add_issue(issues, "portal_capability_attestation_operator_response_not_marked_complete")
    if response.get("template_is_response") is True:
        _add_issue(issues, "portal_capability_attestation_operator_response_template_marker_must_remain_false")
    for key in _forbidden_keys():
        if response.get(key):
            _add_issue(issues, f"forbidden_portal_capability_attestation_operator_response_boundary:{key}")
    anchors = _template_anchor_map(template_report)
    for key, expected in anchors.items():
        actual = response.get(key) or ""
        if expected and not actual:
            _add_issue(issues, f"portal_capability_attestation_operator_response_missing_anchor:{key}")
        elif expected and actual != expected:
            _add_issue(issues, f"portal_capability_attestation_operator_response_anchor_mismatch:{key}", actual)
    return issues, _response_fields(response), response


def _merge_response_fields(response_fields, direct_fields, issues):
    fields = dict(response_fields or {})
    for key in RESPONSE_FIELDS:
        direct = _field((direct_fields or {}).get(key))
        existing = _field(fields.get(key))
        if direct and existing and direct != existing:
            _add_issue(issues, f"portal_capability_attestation_operator_response_cli_field_conflict:{key}")
        if direct:
            fields[key] = direct
        else:
            fields[key] = existing
    if not fields.get("portal_capability_label"):
        fields["portal_capability_label"] = fields.get("capability_attestation_id", "")
    return fields


def _validate_fields(fields):
    issues = []
    for key in REQUIRED_FIELDS:
        if not fields.get(key):
            _add_issue(issues, f"portal_capability_attestation_intake_missing:{key}")
    upload_hash = fields.get("upload_artifact_manifest_sha256") or ""
    if upload_hash and not SHA256_RE.match(upload_hash):
        _add_issue(issues, "upload_artifact_manifest_sha256_not_sha256", upload_hash)
    if _secret_like_value({key: fields.get(key) for key in REQUIRED_FIELDS}):
        _add_issue(issues, "forbidden_secret_like_portal_capability_attestation_intake_material")
    return issues


def _intake_packet(template_report, fields, ready):
    if not ready:
        return {}
    template = _template_packet(template_report)
    return {
        "packet_type": "claim_manuscript_external_submission_portal_capability_attestation_intake",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_attestation_intake.v1",
        "intake_state": READY_STATE,
        "claim_packet_id": template.get("claim_packet_id") or template_report.get("claim_packet_id") or "",
        "slug": template.get("slug") or template_report.get("slug") or "",
        "source_target_path": template.get("source_target_path") or template_report.get("source_target_path") or "",
        "source_after_sha256": template.get("source_after_sha256") or template_report.get("source_after_sha256") or "",
        "external_submission_readiness_report_path": template.get("external_submission_readiness_report_path") or template_report.get("external_submission_readiness_report_path") or "",
        "external_submission_readiness_report_sha256": template.get("external_submission_readiness_report_sha256") or template_report.get("external_submission_readiness_report_sha256") or "",
        "execution_preflight_report_path": template.get("execution_preflight_report_path") or template_report.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": template.get("execution_preflight_report_sha256") or template_report.get("execution_preflight_report_sha256") or "",
        "portal_capability_attestation_template_report_path": template_report.get("report_path") or "",
        "portal_capability_attestation_template_report_sha256": template_report.get("report_sha256") or "",
        "portal_session_ref_or_safe_attestation": fields["portal_session_ref_or_safe_attestation"],
        "target_portal_route": fields["target_portal_route"],
        "upload_artifact_manifest_sha256": fields["upload_artifact_manifest_sha256"],
        "authorization_ref": fields["authorization_ref"],
        "attestation_operator_id": fields["attestation_operator_id"],
        "capability_attestation_id": fields["capability_attestation_id"],
        "portal_capability_label": fields["portal_capability_label"],
        "intake_is_not_performed_evidence": True,
        "external_action_performed": False,
        "secret_material_read_performed": False,
    }


def _operator_response_packet_template(template_report, fields):
    template = _template_packet(template_report)
    return {
        "packet_type": "claim_manuscript_external_submission_portal_capability_attestation_operator_response",
        "packet_schema": OPERATOR_RESPONSE_PACKET_SCHEMA,
        "operator_response_state": "OPERATOR_RESPONSE_TEMPLATE_UNFILLED",
        "operator_response_completed": False,
        "template_is_response": False,
        "claim_packet_id": template.get("claim_packet_id") or template_report.get("claim_packet_id") or "",
        "slug": template.get("slug") or template_report.get("slug") or "",
        "source_target_path": template.get("source_target_path") or template_report.get("source_target_path") or "",
        "source_after_sha256": template.get("source_after_sha256") or template_report.get("source_after_sha256") or "",
        "external_submission_readiness_report_sha256": template.get("external_submission_readiness_report_sha256")
        or template_report.get("external_submission_readiness_report_sha256")
        or "",
        "execution_preflight_report_sha256": template.get("execution_preflight_report_sha256")
        or template_report.get("execution_preflight_report_sha256")
        or "",
        "required_fields": list(REQUIRED_FIELDS),
        "portal_session_ref_or_safe_attestation": fields.get("portal_session_ref_or_safe_attestation") or "",
        "target_portal_route": fields.get("target_portal_route") or "",
        "upload_artifact_manifest_sha256": fields.get("upload_artifact_manifest_sha256") or "",
        "authorization_ref": fields.get("authorization_ref") or "",
        "attestation_operator_id": fields.get("attestation_operator_id") or "",
        "capability_attestation_id": fields.get("capability_attestation_id") or "",
        "portal_capability_label": fields.get("portal_capability_label") or "",
        "safe_field_notes": template.get("safe_field_notes") or {},
        "forbidden_material": template.get("forbidden_material") or [
            "passwords",
            "tokens",
            "cookies",
            "bearer credentials",
            "api keys",
            "portal session secrets",
        ],
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "required_next_gate": COMMAND,
    }


def _operator_intake_template_packet(template_report, fields, state, issues):
    if state != TEMPLATE_REQUIRED_STATE:
        return {}
    missing = [
        str(item.get("issue") or "").split("portal_capability_attestation_intake_missing:", 1)[1]
        for item in issues
        if str(item.get("issue") or "").startswith("portal_capability_attestation_intake_missing:")
    ]
    template = _template_packet(template_report)
    return {
        "packet_type": "claim_manuscript_external_submission_portal_capability_attestation_operator_intake_template",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_portal_capability_attestation_operator_intake_template.v1",
        "intake_state": TEMPLATE_REQUIRED_STATE,
        "claim_packet_id": template.get("claim_packet_id") or template_report.get("claim_packet_id") or "",
        "source_target_path": template.get("source_target_path") or template_report.get("source_target_path") or "",
        "execution_preflight_report_sha256": template.get("execution_preflight_report_sha256") or template_report.get("execution_preflight_report_sha256") or "",
        "required_fields": list(REQUIRED_FIELDS),
        "missing_fields": missing,
        "supplied_field_presence": {key: bool(fields.get(key)) for key in REQUIRED_FIELDS},
        "safe_field_notes": template.get("safe_field_notes") or {},
        "forbidden_material": template.get("forbidden_material") or [
            "passwords",
            "tokens",
            "cookies",
            "bearer credentials",
            "api keys",
            "portal session secrets",
        ],
        "operator_response_packet_template": _operator_response_packet_template(template_report, fields),
        "required_next_gate": COMMAND,
        "external_action_performed": False,
        "secret_material_read_performed": False,
    }


def research_compute_claim_manuscript_external_submission_portal_capability_attestation_intake(
    portal_capability_attestation_template_report,
    portal_session_ref_or_safe_attestation="",
    target_portal_route="",
    upload_artifact_manifest_sha256="",
    authorization_ref="",
    attestation_operator_id="",
    capability_attestation_id="",
    portal_capability_label="",
    operator_response_packet=None,
    label="",
):
    template_report = portal_capability_attestation_template_report or {}
    direct_fields = _field_map(
        portal_session_ref_or_safe_attestation=portal_session_ref_or_safe_attestation,
        target_portal_route=target_portal_route,
        upload_artifact_manifest_sha256=upload_artifact_manifest_sha256,
        authorization_ref=authorization_ref,
        attestation_operator_id=attestation_operator_id,
        capability_attestation_id=capability_attestation_id,
        portal_capability_label=portal_capability_label,
    )
    response_issues, response_fields, normalized_response_packet = _validate_operator_response_packet(
        operator_response_packet,
        template_report,
    )
    merge_issues = []
    fields = _merge_response_fields(response_fields, direct_fields, merge_issues)
    issues = _validate_template_report(template_report) + response_issues + merge_issues + _validate_fields(fields)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif any(str(item.get("issue") or "").startswith("portal_capability_attestation_intake_missing:") for item in issues):
        status = "ATTENTION"
        state = TEMPLATE_REQUIRED_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    ready = bool(status == "PASS" and state == READY_STATE)
    intake_packet = _intake_packet(template_report, fields, ready)
    operator_template = _operator_intake_template_packet(template_report, fields, state, issues)
    operator_response_template = (
        operator_template.get("operator_response_packet_template") if operator_template else {}
    ) or {}
    template = _template_packet(template_report)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "portal_capability_attestation_intake_state": state,
        "portal_capability_attestation_intake_created": status in {"PASS", "ATTENTION"},
        "portal_capability_attestation_intake_ready": ready,
        "portal_capability_attestation_template_report_path": template_report.get("report_path") or "",
        "portal_capability_attestation_template_report_sha256": template_report.get("report_sha256") or "",
        "claim_packet_id": template.get("claim_packet_id") or template_report.get("claim_packet_id") or "",
        "slug": template.get("slug") or template_report.get("slug") or "",
        "source_target_path": template.get("source_target_path") or template_report.get("source_target_path") or "",
        "source_after_sha256": template.get("source_after_sha256") or template_report.get("source_after_sha256") or "",
        "external_submission_readiness_report_path": template.get("external_submission_readiness_report_path") or template_report.get("external_submission_readiness_report_path") or "",
        "external_submission_readiness_report_sha256": template.get("external_submission_readiness_report_sha256") or template_report.get("external_submission_readiness_report_sha256") or "",
        "execution_preflight_report_path": template.get("execution_preflight_report_path") or template_report.get("execution_preflight_report_path") or "",
        "execution_preflight_report_sha256": template.get("execution_preflight_report_sha256") or template_report.get("execution_preflight_report_sha256") or "",
        "portal_session_ref_or_safe_attestation": fields["portal_session_ref_or_safe_attestation"],
        "target_portal_route": fields["target_portal_route"],
        "upload_artifact_manifest_sha256": fields["upload_artifact_manifest_sha256"],
        "authorization_ref": fields["authorization_ref"],
        "attestation_operator_id": fields["attestation_operator_id"],
        "capability_attestation_id": fields["capability_attestation_id"],
        "portal_capability_label": fields["portal_capability_label"],
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "portal_capability_attestation_intake_ready_count": 1 if ready else 0,
            "portal_capability_attestation_intake_packet_count": 1 if intake_packet else 0,
            "portal_capability_attestation_operator_intake_template_count": 1 if operator_template else 0,
            "portal_capability_attestation_operator_response_packet_present_count": 1 if normalized_response_packet else 0,
            "portal_capability_attestation_operator_response_template_count": 1 if operator_response_template else 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "portal_capability_attestation_intake_packet": intake_packet,
        "portal_capability_attestation_operator_intake_template_packet": operator_template,
        "portal_capability_attestation_operator_response_packet": normalized_response_packet,
        "portal_capability_attestation_operator_response_packet_template": operator_response_template,
        "portal_capability_attestation_operator_response_packet_path": "",
        "portal_capability_attestation_operator_response_packet_sha256": "",
        "portal_capability_attestation_operator_response_template_written": False,
        "portal_capability_attestation_operator_response_template_path": "",
        "portal_capability_attestation_operator_response_template_sha256": "",
        "portal_capability_attestation_template_report": template_report,
        "boundary": [
            "This command verifies safe operator-provided portal capability attestation fields.",
            "It can parse a filled operator response packet generated from its intake template.",
            "It records non-secret references only and is not performed external-action evidence.",
            "It does not read secrets, log into portals, upload, email, final-submit, merge, commit, or mutate source/package/archive state.",
        ],
    }


def research_compute_claim_manuscript_external_submission_portal_capability_attestation_intake_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Portal Capability Attestation Intake",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('portal_capability_attestation_intake_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Intake ready: {report.get('portal_capability_attestation_intake_ready')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("portal_capability_attestation_intake_packet") or {}
    if packet:
        lines.extend(["", "## Intake Packet", ""])
        for key in [
            "packet_schema",
            "claim_packet_id",
            "source_target_path",
            "execution_preflight_report_sha256",
            "portal_capability_label",
            "target_portal_route",
            "upload_artifact_manifest_sha256",
            "authorization_ref",
            "attestation_operator_id",
        ]:
            lines.append(f"- {key}: {packet.get(key) or ''}")
    template = report.get("portal_capability_attestation_operator_intake_template_packet") or {}
    if template:
        lines.extend(["", "## Operator Intake Template", ""])
        lines.append(f"- packet_schema: {template.get('packet_schema') or ''}")
        lines.append(f"- missing_fields: {', '.join(template.get('missing_fields') or [])}")
        lines.append(f"- response_template_path: {report.get('portal_capability_attestation_operator_response_template_path') or ''}")
    response = report.get("portal_capability_attestation_operator_response_packet") or {}
    if response:
        lines.extend(["", "## Operator Response Packet", ""])
        lines.append(f"- packet_schema: {response.get('packet_schema') or ''}")
        lines.append(f"- operator_response_completed: {response.get('operator_response_completed')}")
        lines.append(f"- source_target_path: {response.get('source_target_path') or ''}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
