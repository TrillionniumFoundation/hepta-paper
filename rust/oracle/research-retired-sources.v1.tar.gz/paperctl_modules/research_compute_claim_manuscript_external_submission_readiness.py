"""Prepare claim-derived local external-submission readiness packets."""

import datetime as dt

from paperctl_modules import agent_autonomy_policy, report_ref_health


COMMAND = "research-compute-claim-manuscript-external-submission-readiness"
MERGE_SUBMISSION_COMMAND = "research-compute-claim-manuscript-merge-submission-readiness"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_READY"
AUTH_REQUIRED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_READY_EXTERNAL_AUTH_REQUIRED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_IDLE_NO_PATCH_DRAFT"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_WAITING_FOR_SOURCE_LANDING"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_READINESS_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

MERGE_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_READY"
MERGE_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_IDLE_NO_PATCH_DRAFT"
MERGE_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_WAITING_FOR_SOURCE_LANDING"


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _literal_true(value):
    return value is True


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _add_report_ref_health_issues(issues, name, report, expected_command, require_clean_summary=True):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report or {},
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    if not require_clean_summary:
        ref_issues = [
            item for item in ref_issues
            if item.get("issue") != f"{name}_summary_not_clean"
        ]
    issues.extend(ref_issues)


def _require_literal_true(issues, item, key, issue):
    value = item.get(key)
    if key in item and not isinstance(value, bool):
        _add_issue(issues, f"invalid_merge_submission_readiness_boolean:{key}", repr(value))
    if value is not True:
        _add_issue(issues, issue)


def _check_forbidden_boundary(issues, item, key):
    if key not in item:
        return
    value = item.get(key)
    if value is True:
        _add_issue(issues, f"forbidden_merge_submission_boundary:{key}")
    elif not isinstance(value, bool):
        _add_issue(issues, f"invalid_merge_submission_readiness_boolean:{key}", repr(value))


def _validate_merge_submission_readiness(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(
        issues,
        "merge_submission_readiness",
        item,
        MERGE_SUBMISSION_COMMAND,
    )
    if item.get("command") != MERGE_SUBMISSION_COMMAND:
        _add_issue(issues, "merge_submission_readiness_command_mismatch", item.get("command") or "")
    if item.get("status") != "PASS":
        _add_issue(issues, "merge_submission_readiness_not_pass", item.get("status") or "")
    for key in _forbidden_keys():
        _check_forbidden_boundary(issues, item, key)
    state = item.get("claim_manuscript_merge_submission_readiness_state") or ""
    if state not in {MERGE_READY_STATE, MERGE_IDLE_STATE, MERGE_WAITING_STATE}:
        _add_issue(issues, "merge_submission_readiness_state_not_consumable", state)
    if state == MERGE_READY_STATE:
        _require_literal_true(issues, item, "ready_for_claim_submission_readiness", "claim_submission_readiness_flag_missing")
        _require_literal_true(issues, item, "agent_external_submission_decision_ready", "agent_external_submission_decision_not_ready")
        _require_literal_true(issues, item, "automatic_submission_allowed", "automatic_submission_not_allowed")
        if not item.get("source_target_path"):
            _add_issue(issues, "source_target_path_missing")
        if not item.get("source_after_sha256"):
            _add_issue(issues, "source_after_sha256_missing")
        if not item.get("post_apply_verify_report_path"):
            _add_issue(issues, "post_apply_verify_report_path_missing")
    return issues


def _submission_execution_packet(readiness_report, autonomy_policy, agent_ready):
    if not agent_ready:
        return {}
    return {
        "packet_type": "claim_manuscript_external_submission_execution_packet",
        "packet_schema": "paper_factory.research_compute.claim_manuscript_external_submission_execution_packet.v1",
        "packet_state": READY_STATE,
        "claim_packet_id": readiness_report.get("claim_packet_id") or "",
        "slug": readiness_report.get("slug") or "",
        "selected_request_id": readiness_report.get("selected_request_id") or "",
        "selected_risk_class": readiness_report.get("selected_risk_class") or "",
        "source_target_path": readiness_report.get("source_target_path") or "",
        "source_after_sha256": readiness_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": readiness_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": readiness_report.get("post_apply_verify_report_sha256") or "",
        "finalization_report_path": readiness_report.get("finalization_report_path") or "",
        "finalization_report_sha256": readiness_report.get("finalization_report_sha256") or "",
        "merge_submission_readiness_report_path": readiness_report.get("report_path") or "",
        "merge_submission_readiness_report_sha256": readiness_report.get("report_sha256") or "",
        "full_agent_autonomy_authorized": agent_autonomy_policy.policy_bool(
            autonomy_policy.get("full_agent_autonomy_authorized")
        ),
        "automatic_submission_allowed": agent_autonomy_policy.policy_bool(
            autonomy_policy.get("automatic_submission_allowed")
        ),
        "external_action_authorized": agent_autonomy_policy.policy_bool(
            autonomy_policy.get("external_action_authorized")
        ),
        "external_action_performed": False,
        "future_external_execution_gate_required": True,
        "required_pre_execution_checks": [
            "verify this packet hash matches the event record",
            "verify source_after_sha256 still matches the manuscript source target",
            "verify post_apply_verify_report_sha256 matches the referenced post-apply report",
            "record portal login/upload/email/final-submit evidence before setting external_action_performed=true",
        ],
        "external_actions_not_performed_by_this_command": [
            "portal login",
            "portal upload",
            "email",
            "final submit",
            "remote action",
        ],
    }


def research_compute_claim_manuscript_external_submission_readiness(
    merge_submission_readiness_report,
    label="",
    autonomy_policy=None,
):
    merge_submission_readiness_report = merge_submission_readiness_report or {}
    policy = agent_autonomy_policy.normalize_policy(
        autonomy_policy
        or merge_submission_readiness_report.get("autonomy_policy")
        or {}
    )
    issues = _validate_merge_submission_readiness(merge_submission_readiness_report)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    merge_state = merge_submission_readiness_report.get("claim_manuscript_merge_submission_readiness_state") or ""
    merge_ready = merge_state == MERGE_READY_STATE
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    automatic_submission_allowed = bool(
        full_autonomy and agent_autonomy_policy.policy_bool(policy.get("automatic_submission_allowed")) and merge_ready
    )
    external_action_authorized = bool(
        automatic_submission_allowed and agent_autonomy_policy.policy_bool(policy.get("external_action_authorized"))
    )

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif merge_state == MERGE_IDLE_STATE:
        status = "PASS"
        state = IDLE_STATE
    elif merge_state == MERGE_WAITING_STATE:
        status = "PASS"
        state = WAITING_STATE
    elif external_action_authorized:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = AUTH_REQUIRED_STATE

    agent_ready = bool(status == "PASS" and state == READY_STATE and external_action_authorized)
    packet = _submission_execution_packet(merge_submission_readiness_report, policy, agent_ready)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_external_submission_readiness_state": state,
        "claim_external_submission_readiness_created": status == "PASS",
        "agent_submission_execution_packet_created": bool(packet),
        "slug": merge_submission_readiness_report.get("slug") or "",
        "merge_submission_readiness_report_path": merge_submission_readiness_report.get("report_path") or "",
        "merge_submission_readiness_report_sha256": merge_submission_readiness_report.get("report_sha256") or "",
        "claim_packet_id": merge_submission_readiness_report.get("claim_packet_id") or "",
        "selected_request_id": merge_submission_readiness_report.get("selected_request_id") or "",
        "selected_risk_class": merge_submission_readiness_report.get("selected_risk_class") or "",
        "source_target_path": merge_submission_readiness_report.get("source_target_path") or "",
        "source_after_sha256": merge_submission_readiness_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": merge_submission_readiness_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": merge_submission_readiness_report.get("post_apply_verify_report_sha256") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "automatic_submission_allowed": automatic_submission_allowed,
        "agent_external_submission_decision_ready": agent_ready,
        "external_action_authorized": external_action_authorized,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "merge_submission_ready_count": 1 if merge_ready else 0,
            "agent_submission_execution_packet_created_count": 1 if packet else 0,
            "full_agent_autonomy_authorized_count": 1 if full_autonomy else 0,
            "automatic_submission_allowed_count": 1 if automatic_submission_allowed else 0,
            "agent_external_submission_decision_ready_count": 1 if agent_ready else 0,
            "external_action_authorized_count": 1 if external_action_authorized else 0,
            "external_action_performed_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "agent_submission_execution_packet": packet,
        "merge_submission_readiness_report": merge_submission_readiness_report,
        "boundary": [
            "This command prepares a local claim-derived external-submission readiness packet.",
            "Full-agent-autonomy may authorize the agent decision to submit, but this command does not perform portal login, upload, email, final submit, merge, commit, or remote action.",
            "A future external-action execution gate must record performed evidence before external_action_performed can become true.",
        ],
    }


def research_compute_claim_manuscript_external_submission_readiness_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript External Submission Readiness",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_external_submission_readiness_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Agent submission execution packet created: {report.get('agent_submission_execution_packet_created')}",
        f"- Agent external submission decision ready: {report.get('agent_external_submission_decision_ready')}",
        f"- External action authorized: {report.get('external_action_authorized')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("agent_submission_execution_packet") or {}
    if packet:
        lines.extend(["", "## Agent Submission Execution Packet", ""])
        for key in [
            "packet_schema",
            "packet_state",
            "claim_packet_id",
            "source_target_path",
            "source_after_sha256",
            "post_apply_verify_report_path",
            "merge_submission_readiness_report_path",
        ]:
            lines.append(f"- {key}: {packet.get(key) or ''}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
