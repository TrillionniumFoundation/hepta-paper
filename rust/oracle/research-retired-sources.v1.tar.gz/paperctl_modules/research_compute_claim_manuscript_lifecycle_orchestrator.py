"""Summarize the claim manuscript autonomy lifecycle into one agent step."""


COMMAND = "research-compute-claim-manuscript-lifecycle-orchestrator"

IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_LIFECYCLE_IDLE_NO_REPORTS"
READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_LIFECYCLE_AGENT_READY"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_LIFECYCLE_WAITING_FOR_NEXT_GATE"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_LIFECYCLE_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"


STAGES = [
    {
        "stage": "claim_draft",
        "report_key": "claim_draft",
        "command": "research-compute-claim-draft",
        "accepted_commands": [
            "research-compute-claim-draft",
            "research-compute-claim-boundary-reentry-draft",
        ],
        "state_field": "claim_draft_state",
        "state_fields": [
            "claim_draft_state",
            "claim_boundary_reentry_draft_state",
        ],
        "ready_field": "candidate_claim_generated",
        "next_command": "research-compute-claim-quality-gate",
    },
    {
        "stage": "claim_quality_gate",
        "report_key": "claim_quality_gate",
        "command": "research-compute-claim-quality-gate",
        "state_field": "claim_quality_gate_state",
        "ready_field": "claim_quality_gate_ready",
        "next_command": "research-compute-claim-evidence-execution --execute --write",
    },
    {
        "stage": "claim_evidence_execution",
        "report_key": "claim_evidence_execution",
        "command": "research-compute-claim-evidence-execution",
        "state_field": "claim_evidence_execution_state",
        "ready_field": "evidence_gate_ready",
        "next_command": "research-compute-claim-evidence-quality-gate",
    },
    {
        "stage": "claim_evidence_quality_gate",
        "report_key": "claim_evidence_quality_gate",
        "command": "research-compute-claim-evidence-quality-gate",
        "state_field": "claim_evidence_quality_gate_state",
        "ready_field": "claim_evidence_quality_gate_ready",
        "next_command": "research-compute-claim-manuscript-patch-materialization",
    },
    {
        "stage": "patch_materialization",
        "report_key": "patch_materialization",
        "command": "research-compute-claim-manuscript-patch-materialization",
        "state_field": "claim_manuscript_patch_materialization_state",
        "ready_field": "patch_draft_generated",
        "next_command": "research-compute-claim-manuscript-source-apply-readiness",
    },
    {
        "stage": "source_apply_readiness",
        "report_key": "source_apply_readiness",
        "command": "research-compute-claim-manuscript-source-apply-readiness",
        "state_field": "claim_manuscript_source_apply_readiness_state",
        "ready_field": "source_apply_dry_run_ready",
        "next_command": "research-compute-claim-manuscript-source-apply-execution --apply --write",
    },
    {
        "stage": "source_apply_execution",
        "report_key": "source_apply_execution",
        "command": "research-compute-claim-manuscript-source-apply-execution",
        "state_field": "claim_manuscript_source_apply_execution_state",
        "ready_field": "post_apply_verify_performed",
        "next_command": "research-compute-claim-manuscript-source-landing-finalization",
    },
    {
        "stage": "source_landing_finalization",
        "report_key": "source_landing_finalization",
        "command": "research-compute-claim-manuscript-source-landing-finalization",
        "state_field": "claim_manuscript_source_landing_finalization_state",
        "ready_field": "claim_source_landing_finalized",
        "next_command": "research-compute-claim-manuscript-merge-submission-readiness",
    },
    {
        "stage": "merge_submission_readiness",
        "report_key": "merge_submission_readiness",
        "command": "research-compute-claim-manuscript-merge-submission-readiness",
        "state_field": "claim_manuscript_merge_submission_readiness_state",
        "ready_field": "agent_external_submission_decision_ready",
        "next_command": "research-compute-claim-manuscript-external-submission-readiness",
    },
    {
        "stage": "external_submission_readiness",
        "report_key": "external_submission_readiness",
        "command": "research-compute-claim-manuscript-external-submission-readiness",
        "state_field": "claim_manuscript_external_submission_readiness_state",
        "ready_field": "agent_submission_execution_packet_created",
        "next_command": "research-compute-claim-manuscript-external-submission-execution-preflight",
    },
    {
        "stage": "external_submission_execution_preflight",
        "report_key": "external_submission_execution_preflight",
        "command": "research-compute-claim-manuscript-external-submission-execution-preflight",
        "state_field": "claim_manuscript_external_submission_execution_preflight_state",
        "ready_field": "external_submission_execution_preflight_ready",
        "next_command": "research-compute-claim-manuscript-external-submission-execution-intent",
    },
    {
        "stage": "external_submission_portal_capability_attestation",
        "report_key": "external_submission_portal_capability_attestation",
        "command": "research-compute-claim-manuscript-external-submission-portal-capability-attestation",
        "state_field": "portal_capability_attestation_state",
        "ready_field": "portal_capability_ready",
        "next_command": "research-compute-claim-manuscript-external-submission-execution-preflight",
    },
    {
        "stage": "external_submission_portal_capability_attestation_intake",
        "report_key": "external_submission_portal_capability_attestation_intake",
        "command": "research-compute-claim-manuscript-external-submission-portal-capability-attestation-intake",
        "state_field": "portal_capability_attestation_intake_state",
        "ready_field": "portal_capability_attestation_intake_ready",
        "next_command": "research-compute-claim-manuscript-external-submission-portal-capability-attestation",
    },
    {
        "stage": "external_submission_execution_intent",
        "report_key": "external_submission_execution_intent",
        "command": "research-compute-claim-manuscript-external-submission-execution-intent",
        "state_field": "claim_manuscript_external_submission_execution_intent_state",
        "ready_field": "external_submission_execution_intent_ready",
        "next_command": "research-compute-claim-manuscript-external-submission-execution-gate",
    },
    {
        "stage": "external_submission_execution_gate",
        "report_key": "external_submission_execution_gate",
        "command": "research-compute-claim-manuscript-external-submission-execution-gate",
        "state_field": "claim_manuscript_external_submission_execution_gate_state",
        "ready_field": "external_submission_execution_gate_ready",
        "next_command": "research-compute-claim-manuscript-external-submission-execution-terminal-status",
    },
    {
        "stage": "external_submission_execution_terminal_status",
        "report_key": "external_submission_execution_terminal_status",
        "command": "research-compute-claim-manuscript-external-submission-execution-terminal-status",
        "state_field": "claim_manuscript_external_submission_execution_terminal_status_state",
        "ready_field": "terminal_status_created",
        "next_command": "external-submission-readiness-capstone",
    },
    {
        "stage": "external_submission_execution_record_only_fixture_harness",
        "report_key": "external_submission_execution_record_only_fixture_harness",
        "command": "research-compute-claim-manuscript-external-submission-execution-record-only-fixture-harness",
        "state_field": "claim_manuscript_external_submission_record_only_fixture_harness_state",
        "ready_field": "record_only_fixture_generated",
        "next_command": "external-submission-readiness-capstone",
    },
    {
        "stage": "external_submission_readiness_capstone",
        "report_key": "external_submission_readiness_capstone",
        "command": "external-submission-readiness-capstone",
        "state_field": "capstone_state",
        "ready_field": "agent_external_submission_decision_ready",
        "next_command": "",
    },
]


FORBIDDEN_KEYS = [
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


EXTERNAL_AUTH_REQUIRED_NONBLOCKING_STAGES = {
    "claim_evidence_quality_gate",
    "patch_materialization",
    "source_apply_readiness",
    "source_apply_execution",
    "source_landing_finalization",
    "merge_submission_readiness",
    "external_submission_readiness",
    "external_submission_portal_capability_attestation",
    "external_submission_execution_gate",
    "external_submission_execution_terminal_status",
    "external_submission_execution_record_only_fixture_harness",
}


def _validation_issue_count(report):
    report = report or {}
    summary = report.get("summary") or {}
    try:
        summary_count = int(summary.get("validation_issue_count") or 0)
    except (TypeError, ValueError):
        summary_count = 0
    return summary_count + len(report.get("validation_issues") or [])


def _clean_pass(report):
    return bool((report or {}).get("status") == "PASS" and _validation_issue_count(report) == 0)


def _external_action_allowed_for_stage(stage_name, report):
    if not (report or {}).get("external_action_performed"):
        return False
    if stage_name == "external_submission_execution_gate":
        return bool(
            report.get("claim_manuscript_external_submission_execution_gate_state")
            == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_GATE_PERFORMED_EVIDENCE_ACCEPTED"
            and report.get("external_submission_execution_gate_ready")
            and report.get("performed_evidence_recorded")
            and not report.get("record_only_fixture")
        )
    if stage_name == "external_submission_execution_terminal_status":
        return bool(
            report.get("terminal_status") == "PERFORMED_EVIDENCE_ACCEPTED"
            and report.get("external_submission_execution_gate_ready")
            and report.get("performed_evidence_recorded")
            and not report.get("record_only_fixture")
        )
    return False


def _summary_value(report, key):
    summary = (report or {}).get("summary") or {}
    return summary.get(key)


def _ready(stage, report):
    if not report:
        return False
    if not _clean_pass(report):
        return False
    ready_field = stage.get("ready_field") or ""
    if ready_field and report.get(ready_field):
        return True
    if ready_field and _summary_value(report, f"{ready_field}_count"):
        return True
    if stage["stage"] == "claim_draft" and (report.get("claim_packets") or []):
        return True
    if stage["stage"] == "external_submission_execution_terminal_status":
        return bool((report.get("summary") or {}).get("terminal_ready_count"))
    if stage["stage"] == "external_submission_readiness_capstone":
        return bool(report.get("agent_external_submission_decision_ready"))
    return False


def _stage_item(stage, report):
    report = report or {}
    summary = report.get("summary") or {}
    attestation_template = report.get("portal_capability_attestation_template_packet") or {}
    intake_template = report.get("portal_capability_attestation_operator_intake_template_packet") or {}
    operator_response_template = (
        report.get("portal_capability_attestation_operator_response_packet_template")
        or intake_template.get("operator_response_packet_template")
        or {}
    )
    performed_evidence_template = report.get("performed_evidence_template_packet") or {}
    issues = []
    accepted_commands = set(stage.get("accepted_commands") or [stage["command"]])
    if report and report.get("command") not in accepted_commands:
        issues.append({"issue": "command_mismatch", "expected": stage["command"], "observed": report.get("command") or ""})
    if report and report.get("status") not in {"PASS", "ATTENTION"}:
        issues.append({"issue": "stage_status_not_pass_or_attention", "status": report.get("status") or ""})
    validation_issue_count = _validation_issue_count(report)
    if report and validation_issue_count:
        issues.append({"issue": "stage_validation_issues_present", "count": validation_issue_count})
    for key in FORBIDDEN_KEYS:
        if key == "external_action_performed" and _external_action_allowed_for_stage(stage["stage"], report):
            continue
        if report.get(key):
            issues.append({"issue": f"forbidden_boundary:{key}"})
    return {
        "stage": stage["stage"],
        "command": stage["command"],
        "present": bool(report),
        "status": report.get("status") or "",
        "state": next(
            (
                report.get(field)
                for field in (stage.get("state_fields") or [stage["state_field"]])
                if report.get(field)
            ),
            "",
        ),
        "ready": _ready(stage, report),
        "report_path": report.get("report_path") or "",
        "report_sha256": report.get("report_sha256") or "",
        "claim_packet_id": report.get("claim_packet_id") or "",
        "source_target_path": report.get("source_target_path") or "",
        "source_after_sha256": report.get("source_after_sha256") or "",
        "external_submission_readiness_report_path": report.get("external_submission_readiness_report_path") or "",
        "patch_file_sha256": report.get("patch_file_sha256") or (report.get("patch_draft") or {}).get("patch_file_sha256") or "",
        "patch_draft_has_changes": bool(
            report.get("patch_file_sha256")
            or (report.get("patch_draft") or {}).get("patch_file_sha256")
            or (report.get("patch_draft") or {}).get("patch_text")
        ),
        "claim_materialization_report_sha256": report.get("claim_materialization_report_sha256") or report.get("materialization_report_sha256") or "",
        "readiness_report_sha256": report.get("readiness_report_sha256") or "",
        "execution_report_sha256": report.get("execution_report_sha256") or "",
        "execution_preflight_report_sha256": report.get("execution_preflight_report_sha256") or "",
        "execution_intent_report_sha256": report.get("execution_intent_report_sha256") or "",
        "execution_gate_report_sha256": report.get("execution_gate_report_sha256") or "",
        "claim_quality_gate_ready": bool(report.get("claim_quality_gate_ready")),
        "claim_evidence_execution_ready": bool(report.get("claim_evidence_execution_ready") or report.get("evidence_gate_ready")),
        "claim_evidence_quality_gate_ready": bool(report.get("claim_evidence_quality_gate_ready")),
        "portal_capability_ready": bool(report.get("portal_capability_ready")),
        "portal_capability_attestation_ready": bool(report.get("portal_capability_ready") or report.get("portal_capability_attestation_ready")),
        "portal_capability_attestation_packet_present": bool(report.get("portal_capability_attestation_packet")),
        "portal_capability_attestation_template_present": bool(attestation_template),
        "portal_capability_attestation_template_count": int(summary.get("portal_capability_attestation_template_count") or 0),
        "portal_capability_attestation_missing_fields": list(attestation_template.get("missing_fields") or []),
        "portal_capability_attestation_report_sha256": report.get("portal_capability_attestation_report_sha256") or "",
        "portal_capability_attestation_intake_ready": bool(report.get("portal_capability_attestation_intake_ready")),
        "portal_capability_attestation_intake_packet_present": bool(report.get("portal_capability_attestation_intake_packet")),
        "portal_capability_attestation_intake_packet_count": int(summary.get("portal_capability_attestation_intake_packet_count") or 0),
        "portal_capability_attestation_operator_intake_template_present": bool(intake_template),
        "portal_capability_attestation_operator_intake_template_count": int(summary.get("portal_capability_attestation_operator_intake_template_count") or 0),
        "portal_capability_attestation_intake_missing_fields": list(intake_template.get("missing_fields") or []),
        "portal_capability_attestation_operator_response_template_present": bool(operator_response_template),
        "portal_capability_attestation_operator_response_template_count": int(
            summary.get("portal_capability_attestation_operator_response_template_count") or 0
        ),
        "portal_capability_attestation_operator_response_template_path": report.get(
            "portal_capability_attestation_operator_response_template_path"
        )
        or "",
        "portal_capability_attestation_operator_response_template_sha256": report.get(
            "portal_capability_attestation_operator_response_template_sha256"
        )
        or "",
        "portal_capability_attestation_intake_report_sha256": report.get("portal_capability_attestation_intake_report_sha256") or "",
        "portal_capability_attestation_template_report_sha256": report.get("portal_capability_attestation_template_report_sha256") or "",
        "portal_capability_handoff_packet_created": bool(report.get("portal_capability_handoff_packet_created")),
        "portal_capability_handoff_packet_schema": (report.get("portal_capability_handoff_packet") or {}).get("packet_schema") or "",
        "portal_capability_handoff_packet_count": int(summary.get("portal_capability_handoff_packet_count") or 0),
        "external_execution_capability_gap_count": int(summary.get("external_execution_capability_gap_count") or 0),
        "performed_evidence_template_present": bool(performed_evidence_template),
        "performed_evidence_template_count": int(summary.get("performed_evidence_template_count") or 0),
        "performed_evidence_missing_field_count": int(summary.get("performed_evidence_missing_field_count") or 0),
        "performed_evidence_missing_fields": list(performed_evidence_template.get("missing_fields") or []),
        "capstone_readiness_semantics_source_evidence_ready": bool(
            summary.get("paper_production_readiness_semantics_source_evidence_ready")
        ),
        "capstone_readiness_semantics_local_closeout_source_evidence_ready": bool(
            summary.get("paper_production_readiness_semantics_local_closeout_source_evidence_ready")
        ),
        "capstone_readiness_semantics_external_auth_boundary_source_evidence_ready": bool(
            summary.get(
                "paper_production_readiness_semantics_external_auth_boundary_source_evidence_ready"
            )
        ),
        "capstone_readiness_semantics_release_lock_source_evidence_ready": bool(
            summary.get("paper_production_readiness_semantics_release_lock_source_evidence_ready")
        ),
        "capstone_external_lifecycle_source_evidence_gate_pass": bool(
            summary.get("paper_production_external_lifecycle_source_evidence_gate_pass")
        ),
        "validation_issue_count": validation_issue_count,
        "external_action_performed": bool(report.get("external_action_performed")),
        "secret_material_read_performed": bool(report.get("secret_material_read_performed")),
        "commit_performed": bool(report.get("commit_performed")),
        "next_command": stage.get("next_command") or "",
        "issues": issues,
}


ANCHOR_FIELDS = [
    "claim_packet_id",
    "source_target_path",
    "source_after_sha256",
    "upload_manifest_csv_sha256",
]


def _anchor_from_mapping(mapping):
    mapping = mapping or {}
    anchor = {
        "claim_packet_id": (
            mapping.get("claim_packet_id")
            or mapping.get("selected_claim_packet_id")
            or mapping.get("preferred_claim_packet_id")
            or ""
        ),
        "source_target_path": mapping.get("source_target_path") or mapping.get("selected_source_target_path") or "",
        "source_after_sha256": mapping.get("source_after_sha256") or mapping.get("selected_source_after_sha256") or "",
        "upload_manifest_csv_sha256": (
            mapping.get("upload_manifest_csv_sha256")
            or mapping.get("selected_upload_manifest_csv_sha256")
            or mapping.get("upload_artifact_manifest_sha256")
            or ""
        ),
    }
    if any(anchor.values()):
        return anchor
    for nested_key in [
        "selected_executor_response_target",
        "executor_response_work_item_packet",
        "executor_response_waiting_redrive_plan_packet",
        "executor_response_inbox_cursor_packet",
    ]:
        nested = mapping.get(nested_key) or {}
        if isinstance(nested, dict) and nested:
            nested_anchor = _anchor_from_mapping(nested)
            if any(nested_anchor.values()):
                return nested_anchor
    for list_key in [
        "pending_executor_responses",
        "ready_for_intake_contracts",
        "ready_for_gate_contracts",
        "response_packet_records",
        "cursor_records",
    ]:
        records = mapping.get(list_key) or []
        if records and isinstance(records[0], dict):
            nested_anchor = _anchor_from_mapping(records[0])
            if any(nested_anchor.values()):
                return nested_anchor
    return anchor


def _anchor_present(anchor):
    return any((anchor or {}).get(key) for key in ANCHOR_FIELDS)


def _anchors_compatible(expected, observed):
    expected = expected or {}
    observed = observed or {}
    if not _anchor_present(expected) or not _anchor_present(observed):
        return True
    for key in ANCHOR_FIELDS:
        left = expected.get(key) or ""
        right = observed.get(key) or ""
        if left and right and left != right:
            return False
    return True


def _primary_claim_anchor(handoff_view, by_stage):
    handoff_anchor = _anchor_from_mapping(handoff_view)
    if _anchor_present(handoff_anchor):
        return handoff_anchor
    for stage_name in [
        "external_submission_readiness",
        "merge_submission_readiness",
        "source_landing_finalization",
        "source_apply_execution",
        "source_apply_readiness",
        "patch_materialization",
        "claim_draft",
    ]:
        anchor = _anchor_from_mapping(by_stage.get(stage_name) or {})
        if _anchor_present(anchor):
            return anchor
    return {}


ANCHOR_BOUND_REPORT_KEYS = [
    "external_submission_execution_executor_task",
    "external_submission_execution_executor_response_contract",
    "external_submission_execution_executor_response_backlog",
    "external_submission_execution_executor_response_work_item",
    "external_submission_execution_executor_response_inbox_index",
    "external_submission_execution_executor_response_inbox_cursor",
    "external_submission_execution_executor_response_packet_discovery",
    "external_submission_execution_executor_response_work_item_dispatch",
    "external_submission_execution_executor_response_waiting_status",
    "external_submission_execution_executor_response_waiting_escalation",
    "external_submission_execution_executor_response_waiting_scheduler",
    "external_submission_execution_executor_response_waiting_redrive_plan",
    "external_submission_execution_performed_evidence_intake",
    "external_submission_execution_gate",
    "external_submission_execution_terminal_status",
    "external_submission_execution_record_only_fixture_harness",
]


def _anchor_validation_issues(reports, handoff_view, by_stage):
    primary_anchor = _primary_claim_anchor(handoff_view, by_stage)
    if not _anchor_present(primary_anchor):
        return []
    issues = []
    for report_key in ANCHOR_BOUND_REPORT_KEYS:
        report = reports.get(report_key) or {}
        if not report:
            continue
        observed = _anchor_from_mapping(report)
        if _anchor_present(observed) and not _anchors_compatible(primary_anchor, observed):
            issues.append(
                {
                    "issue": f"claim_anchor_mismatch:{report_key}",
                    "expected_claim_packet_id": primary_anchor.get("claim_packet_id") or "",
                    "observed_claim_packet_id": observed.get("claim_packet_id") or "",
                    "expected_source_target_path": primary_anchor.get("source_target_path") or "",
                    "observed_source_target_path": observed.get("source_target_path") or "",
                }
            )
    return issues


def _stage_command(stage_name):
    for stage in STAGES:
        if stage["stage"] == stage_name:
            return stage["command"]
    return ""


def _preflight_requires_portal_capability_attestation(preflight):
    state = preflight.get("state") or ""
    return bool(
        preflight.get("present")
        and not preflight.get("ready")
        and (
            state == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PREFLIGHT_CAPABILITY_REQUIRED"
            or preflight.get("portal_capability_handoff_packet_created")
        )
    )


def _portal_capability_attestation_skippable(item, by_stage):
    if item.get("stage") != "external_submission_portal_capability_attestation":
        return False
    preflight = by_stage.get("external_submission_execution_preflight") or {}
    return bool(preflight.get("present") and preflight.get("ready") and not item.get("ready"))


def _portal_capability_attestation_intake_skippable(item, by_stage):
    if item.get("stage") != "external_submission_portal_capability_attestation_intake":
        return False
    preflight = by_stage.get("external_submission_execution_preflight") or {}
    attestation = by_stage.get("external_submission_portal_capability_attestation") or {}
    return bool(
        (preflight.get("present") and preflight.get("ready") and not item.get("ready"))
        or (attestation.get("present") and attestation.get("ready") and not item.get("ready"))
        or (attestation.get("present") and not attestation.get("portal_capability_attestation_template_count") and not item.get("ready"))
    )


def _record_only_fixture_harness_skippable(item, by_stage):
    if item.get("stage") != "external_submission_execution_record_only_fixture_harness":
        return False
    gate = by_stage.get("external_submission_execution_gate") or {}
    terminal = by_stage.get("external_submission_execution_terminal_status") or {}
    return bool(gate.get("present") or terminal.get("present"))


def _portal_capability_attestation_command(preflight):
    command = _stage_command("external_submission_portal_capability_attestation")
    if preflight.get("report_path"):
        command = f"{command} --execution-preflight-report {preflight.get('report_path')}"
    return command


def _portal_capability_attestation_intake_command(attestation, intake=None):
    command = _stage_command("external_submission_portal_capability_attestation_intake")
    if attestation.get("report_path"):
        command = f"{command} --portal-capability-attestation-template-report {attestation.get('report_path')}"
    response_template_path = (intake or {}).get("portal_capability_attestation_operator_response_template_path") or ""
    if response_template_path:
        command = f"{command} --operator-response-packet {response_template_path}"
    return command


def _portal_capability_attestation_command_with_intake(preflight, intake):
    command = _portal_capability_attestation_command(preflight)
    if intake.get("report_path"):
        command = f"{command} --portal-capability-attestation-intake-report {intake.get('report_path')}"
    return command


def _preflight_command_with_attestation(preflight, attestation):
    command = _stage_command("external_submission_execution_preflight")
    if preflight.get("external_submission_readiness_report_path"):
        command = f"{command} --external-submission-readiness-report {preflight.get('external_submission_readiness_report_path')}"
    if attestation.get("report_path"):
        command = f"{command} --portal-capability-attestation-report {attestation.get('report_path')}"
    return command


def _executor_task_command(intent, handoff_view=None, capstone=None):
    command = "research-compute-claim-manuscript-external-submission-execution-executor-task"
    if intent.get("report_path"):
        command = f"{command} --execution-intent-report {intent.get('report_path')}"
    else:
        command = f"{command} --execution-intent-report <execution-intent-report>"
    if (handoff_view or {}).get("report_path"):
        command = f"{command} --external-submission-handoff-bundle-report {(handoff_view or {}).get('report_path')}"
    else:
        command = f"{command} --external-submission-handoff-bundle-report <external-submission-handoff-bundle-report>"
    if (capstone or {}).get("report_path"):
        command = f"{command} --external-submission-readiness-capstone-report {(capstone or {}).get('report_path')}"
    else:
        command = f"{command} --external-submission-readiness-capstone-report <external-submission-readiness-capstone-report>"
    return command


def _executor_response_contract_command(executor_task, response_path=""):
    command = "research-compute-claim-manuscript-external-submission-execution-executor-response-contract"
    if (executor_task or {}).get("report_path"):
        command = f"{command} --executor-task-report {(executor_task or {}).get('report_path')}"
    else:
        command = f"{command} --executor-task-report <executor-task-report>"
    if response_path:
        command = f"{command} --executor-response-packet {response_path}"
    else:
        command = f"{command} --executor-response-packet <executor-response-packet>"
    return command


def _performed_evidence_intake_command(intent, executor_task=None, response_path=""):
    command = "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake"
    if intent.get("report_path"):
        command = f"{command} --execution-intent-report {intent.get('report_path')}"
    else:
        command = f"{command} --execution-intent-report <execution-intent-report>"
    if (executor_task or {}).get("report_path"):
        command = f"{command} --executor-task-report {(executor_task or {}).get('report_path')}"
    else:
        command = f"{command} --executor-task-report <executor-task-report>"
    return f"{command} --executor-response-packet {response_path or '<executor-response-packet>'}"


def _execution_gate_with_performed_evidence_command(intent, intake):
    command = "research-compute-claim-manuscript-external-submission-execution-gate"
    if intent.get("report_path"):
        command = f"{command} --execution-intent-report {intent.get('report_path')}"
    else:
        command = f"{command} --execution-intent-report <execution-intent-report>"
    performed_evidence_path = (intake or {}).get("performed_evidence_path") or ""
    if performed_evidence_path:
        command = f"{command} --performed-evidence {performed_evidence_path}"
    else:
        command = f"{command} --performed-evidence <external-submission-performed-evidence.json>"
    return command


def _executor_task_ready(report, intent=None):
    item = report or {}
    if not (
        _clean_pass(item)
        and item.get("executor_task_ready")
        and item.get("executor_task_state") == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_TASK_READY"
    ):
        return False
    intent_sha = (intent or {}).get("report_sha256") or ""
    if intent_sha and item.get("execution_intent_report_sha256") and item.get("execution_intent_report_sha256") != intent_sha:
        return False
    return not any(item.get(key) for key in FORBIDDEN_KEYS)


def _executor_response_contract_ready(report, executor_task=None):
    item = report or {}
    if not (
        _clean_pass(item)
        and item.get("executor_response_contract_ready")
        and item.get("executor_response_contract_state")
        == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_EXECUTOR_RESPONSE_CONTRACT_READY_FOR_INTAKE"
    ):
        return False
    task_sha = (executor_task or {}).get("report_sha256") or ""
    if task_sha and item.get("executor_task_report_sha256") and item.get("executor_task_report_sha256") != task_sha:
        return False
    return not any(item.get(key) for key in FORBIDDEN_KEYS)


def _performed_evidence_intake_ready(report, intent=None, executor_task=None):
    item = report or {}
    if not (
        _clean_pass(item)
        and item.get("performed_evidence_intake_ready")
        and item.get("performed_evidence_intake_state")
        == "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_EXTERNAL_SUBMISSION_EXECUTION_PERFORMED_EVIDENCE_INTAKE_READY"
    ):
        return False
    intent_sha = (intent or {}).get("report_sha256") or ""
    if intent_sha and item.get("execution_intent_report_sha256") and item.get("execution_intent_report_sha256") != intent_sha:
        return False
    task_sha = (executor_task or {}).get("report_sha256") or ""
    if task_sha and item.get("executor_task_report_sha256") and item.get("executor_task_report_sha256") != task_sha:
        return False
    return not any(item.get(key) for key in ["secret_material_read_performed", "source_mutation_performed", "package_mutation_performed", "archive_mutation_performed", "provider_model_call_performed", "patch_queue_merge_performed", "commit_performed"])


def _executor_response_backlog_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_backlog_state") or "",
        "pending_executor_response_count": int(
            item.get("pending_executor_response_count")
            or summary.get("pending_executor_response_count")
            or 0
        ),
        "ready_for_intake_count": int(item.get("ready_for_intake_count") or summary.get("ready_for_intake_count") or 0),
        "ready_for_gate_count": int(item.get("ready_for_gate_count") or summary.get("ready_for_gate_count") or 0),
        "invalid_anchor_contract_count": int(
            item.get("invalid_anchor_contract_count")
            or summary.get("invalid_anchor_contract_count")
            or 0
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_backlog_next(report):
    view = _executor_response_backlog_view(report)
    if not view.get("present") or not view.get("safe"):
        return {}
    if view.get("ready_for_gate_count"):
        return {
            "next_stage": view.get("next_agent_stage") or "external_submission_execution_gate",
            "next_command": view.get("next_agent_command") or "research-compute-claim-manuscript-external-submission-execution-gate --performed-evidence <external-submission-performed-evidence.json>",
            "reason": "executor response backlog has performed-evidence intake ready for execution gate",
        }
    if view.get("ready_for_intake_count"):
        return {
            "next_stage": view.get("next_agent_stage") or "external_submission_execution_performed_evidence_intake",
            "next_command": view.get("next_agent_command") or "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake --executor-response-packet <executor-response-packet>",
            "reason": "executor response backlog has response ready for performed-evidence intake",
        }
    if view.get("pending_executor_response_count"):
        return {
            "next_stage": view.get("next_agent_stage") or "external_submission_execution_executor_response_waiting",
            "next_command": view.get("next_agent_command") or "research-compute-claim-manuscript-external-submission-execution-performed-evidence-intake --executor-response-packet <executor-response-packet>",
            "reason": "executor response backlog is waiting for real external executor response",
        }
    return {}


def _executor_response_inbox_index_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_inbox_index_state") or "",
        "ready": bool(item.get("executor_response_inbox_index_ready")),
        "candidate_response_packet_count": int(
            item.get("candidate_response_packet_count")
            or summary.get("candidate_response_packet_count")
            or 0
        ),
        "unique_response_packet_count": int(
            item.get("unique_response_packet_count")
            or summary.get("unique_response_packet_count")
            or 0
        ),
        "ready_response_packet_count": int(
            item.get("ready_response_packet_count")
            or summary.get("ready_response_packet_count")
            or 0
        ),
        "duplicate_response_packet_count": int(
            item.get("duplicate_response_packet_count")
            or summary.get("duplicate_response_packet_count")
            or 0
        ),
        "rejected_response_packet_count": int(
            item.get("rejected_response_packet_count")
            or summary.get("rejected_response_packet_count")
            or 0
        ),
        "forbidden_response_packet_count": int(
            item.get("forbidden_response_packet_count")
            or summary.get("forbidden_response_packet_count")
            or 0
        ),
        "consumed_response_packet_count": int(
            item.get("consumed_response_packet_count")
            or summary.get("consumed_response_packet_count")
            or 0
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_inbox_index_next(report):
    view = _executor_response_inbox_index_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready_response_packet_count"):
        return {}
    return {
        "next_stage": view.get("next_agent_stage") or "external_submission_execution_executor_response_packet_discovery",
        "next_command": (
            view.get("next_agent_command")
            or "research-compute-claim-manuscript-external-submission-execution-executor-response-packet-discovery --write"
        ),
        "reason": "executor response inbox index found ready local response packets",
    }


def _executor_response_inbox_cursor_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_inbox_cursor_state") or "",
        "ready": bool(item.get("executor_response_inbox_cursor_ready")),
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "selected_executor_response_packet_path": item.get("selected_executor_response_packet_path") or "",
        "selected_executor_response_packet_sha256": item.get("selected_executor_response_packet_sha256") or "",
        "cursor_checkpoint_key": item.get("cursor_checkpoint_key") or "",
        "cursor_position": int(item.get("cursor_position") or -1),
        "candidate_response_packet_count": int(
            item.get("candidate_response_packet_count")
            or summary.get("candidate_response_packet_count")
            or 0
        ),
        "ready_response_packet_count": int(
            item.get("ready_response_packet_count")
            or summary.get("ready_response_packet_count")
            or 0
        ),
        "eligible_response_packet_count": int(
            item.get("eligible_response_packet_count")
            or summary.get("eligible_response_packet_count")
            or 0
        ),
        "selected_executor_response_packet_count": int(
            item.get("selected_executor_response_packet_count")
            or summary.get("selected_executor_response_packet_count")
            or (1 if item.get("selected_executor_response_packet_path") else 0)
        ),
        "skipped_consumed_response_packet_count": int(
            item.get("skipped_consumed_response_packet_count")
            or summary.get("skipped_consumed_response_packet_count")
            or 0
        ),
        "skipped_anchor_mismatch_response_packet_count": int(
            item.get("skipped_anchor_mismatch_response_packet_count")
            or summary.get("skipped_anchor_mismatch_response_packet_count")
            or 0
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_inbox_cursor_next(report):
    view = _executor_response_inbox_cursor_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    if not view.get("selected_executor_response_packet_count"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": "executor response inbox cursor selected bounded packet discovery target",
    }


def _executor_response_work_item_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_work_item_state") or "",
        "ready": bool(item.get("executor_response_work_item_ready")),
        "selected_category": item.get("selected_category") or "",
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "selected_work_item_count": int(
            summary.get("selected_work_item_count")
            or (1 if item.get("selected_claim_packet_id") else 0)
        ),
        "pending_executor_response_count": int(summary.get("pending_executor_response_count") or 0),
        "ready_for_intake_count": int(summary.get("ready_for_intake_count") or 0),
        "ready_for_gate_count": int(summary.get("ready_for_gate_count") or 0),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_work_item_next(report):
    view = _executor_response_work_item_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("selected_work_item_count"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": f"executor response work item selected {view.get('selected_category')}",
    }


def _executor_response_work_item_dispatch_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_work_item_dispatch_state") or "",
        "ready": bool(item.get("executor_response_work_item_dispatch_ready")),
        "dispatch_route": item.get("dispatch_route") or "",
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "executor_response_packet_present": bool(item.get("executor_response_packet_present")),
        "waiting_for_executor_response_count": int(summary.get("waiting_for_executor_response_count") or 0),
        "ready_for_contract_count": int(summary.get("ready_for_contract_count") or 0),
        "ready_for_intake_count": int(summary.get("ready_for_intake_count") or 0),
        "ready_for_gate_count": int(summary.get("ready_for_gate_count") or 0),
        "closed_executor_response_count": int(summary.get("closed_executor_response_count") or 0),
        "validation_issue_count": int(summary.get("validation_issue_count") or 0),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_work_item_dispatch_next(report):
    view = _executor_response_work_item_dispatch_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": f"executor response work item dispatch route {view.get('dispatch_route')}",
    }


def _executor_response_waiting_status_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_waiting_status_state") or "",
        "ready": bool(item.get("executor_response_waiting_status_ready")),
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "dispatch_route": item.get("dispatch_route") or "",
        "blocked_reason": item.get("blocked_reason") or "",
        "waiting_age_minutes": int(item.get("waiting_age_minutes") or summary.get("waiting_age_minutes") or 0),
        "retry_due": bool(item.get("retry_due")),
        "stale_waiting": bool(item.get("stale_waiting")),
        "waiting_status_ready_count": int(summary.get("waiting_status_ready_count") or 0),
        "waiting_for_executor_response_count": int(summary.get("waiting_for_executor_response_count") or 0),
        "retry_due_count": int(summary.get("retry_due_count") or 0),
        "stale_waiting_count": int(summary.get("stale_waiting_count") or 0),
        "ready_for_discovery_count": int(summary.get("ready_for_discovery_count") or 0),
        "cursor_selected_count": int(summary.get("cursor_selected_count") or 0),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_waiting_status_next(report):
    view = _executor_response_waiting_status_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": f"executor response waiting status {view.get('blocked_reason') or view.get('state')}",
    }


def _executor_response_waiting_escalation_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_waiting_escalation_state") or "",
        "ready": bool(item.get("executor_response_waiting_escalation_ready")),
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "waiting_escalation_action": item.get("waiting_escalation_action") or "",
        "waiting_escalation_level": item.get("waiting_escalation_level") or "",
        "waiting_escalation_route_reason": item.get("waiting_escalation_route_reason") or "",
        "waiting_age_minutes": int(item.get("waiting_age_minutes") or summary.get("waiting_age_minutes") or 0),
        "retry_due": bool(item.get("retry_due")),
        "stale_waiting": bool(item.get("stale_waiting")),
        "waiting_escalation_ready_count": int(summary.get("waiting_escalation_ready_count") or 0),
        "waiting_escalation_waiting_count": int(summary.get("waiting_escalation_waiting_count") or 0),
        "waiting_escalation_retry_due_count": int(summary.get("waiting_escalation_retry_due_count") or 0),
        "waiting_escalation_stale_count": int(summary.get("waiting_escalation_stale_count") or 0),
        "waiting_escalation_local_retry_scan_count": int(summary.get("waiting_escalation_local_retry_scan_count") or 0),
        "waiting_escalation_stale_external_response_count": int(
            summary.get("waiting_escalation_stale_external_response_count") or 0
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_waiting_escalation_next(report):
    view = _executor_response_waiting_escalation_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": f"executor response waiting escalation {view.get('waiting_escalation_route_reason') or view.get('state')}",
    }


def _executor_response_waiting_scheduler_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_waiting_scheduler_state") or "",
        "ready": bool(item.get("executor_response_waiting_scheduler_ready")),
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "waiting_scheduler_action": item.get("waiting_scheduler_action") or "",
        "waiting_scheduler_route_reason": item.get("waiting_scheduler_route_reason") or "",
        "waiting_age_minutes": int(item.get("waiting_age_minutes") or summary.get("waiting_age_minutes") or 0),
        "minutes_until_retry": int(item.get("minutes_until_retry") or summary.get("minutes_until_retry") or 0),
        "minutes_until_stale": int(item.get("minutes_until_stale") or summary.get("minutes_until_stale") or 0),
        "retry_due": bool(item.get("retry_due")),
        "stale_waiting": bool(item.get("stale_waiting")),
        "waiting_scheduler_ready_count": int(summary.get("waiting_scheduler_ready_count") or 0),
        "waiting_scheduler_waiting_count": int(summary.get("waiting_scheduler_waiting_count") or 0),
        "waiting_scheduler_local_redrive_due_count": int(
            summary.get("waiting_scheduler_local_redrive_due_count") or 0
        ),
        "waiting_scheduler_stale_count": int(summary.get("waiting_scheduler_stale_count") or 0),
        "waiting_scheduler_local_inbox_refresh_count": int(
            summary.get("waiting_scheduler_local_inbox_refresh_count") or 0
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_waiting_scheduler_next(report):
    view = _executor_response_waiting_scheduler_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": f"executor response waiting scheduler {view.get('waiting_scheduler_route_reason') or view.get('state')}",
    }


def _executor_response_waiting_redrive_plan_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_waiting_redrive_plan_state") or "",
        "ready": bool(item.get("executor_response_waiting_redrive_plan_ready")),
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "waiting_redrive_plan_action": item.get("waiting_redrive_plan_action") or "",
        "waiting_redrive_plan_route_reason": item.get("waiting_redrive_plan_route_reason") or "",
        "waiting_redrive_plan_attempt_count": int(
            item.get("waiting_redrive_plan_attempt_count")
            or summary.get("waiting_redrive_plan_attempt_count")
            or 0
        ),
        "local_redrive_due": bool(item.get("local_redrive_due")),
        "waiting_age_minutes": int(item.get("waiting_age_minutes") or summary.get("waiting_age_minutes") or 0),
        "minutes_until_retry": int(item.get("minutes_until_retry") or summary.get("minutes_until_retry") or 0),
        "minutes_until_stale": int(item.get("minutes_until_stale") or summary.get("minutes_until_stale") or 0),
        "waiting_redrive_plan_ready_count": int(summary.get("waiting_redrive_plan_ready_count") or 0),
        "waiting_redrive_plan_waiting_count": int(summary.get("waiting_redrive_plan_waiting_count") or 0),
        "waiting_redrive_plan_local_redrive_due_count": int(
            summary.get("waiting_redrive_plan_local_redrive_due_count") or 0
        ),
        "waiting_redrive_plan_stale_redrive_planned_count": int(
            summary.get("waiting_redrive_plan_stale_redrive_planned_count") or 0
        ),
        "waiting_redrive_plan_local_inbox_refresh_count": int(
            summary.get("waiting_redrive_plan_local_inbox_refresh_count") or 0
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_waiting_redrive_plan_next(report):
    view = _executor_response_waiting_redrive_plan_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": f"executor response waiting redrive plan {view.get('waiting_redrive_plan_route_reason') or view.get('state')}",
    }


def _executor_response_packet_discovery_view(report):
    item = report or {}
    summary = item.get("summary") or {}
    return {
        "present": bool(item),
        "state": item.get("executor_response_packet_discovery_state") or "",
        "ready": bool(item.get("executor_response_packet_discovery_ready")),
        "selected_executor_response_packet_path": item.get("selected_executor_response_packet_path") or "",
        "selected_executor_response_packet_sha256": item.get("selected_executor_response_packet_sha256") or "",
        "selected_claim_packet_id": item.get("selected_claim_packet_id") or "",
        "selected_source_target_path": item.get("selected_source_target_path") or "",
        "selected_source_after_sha256": item.get("selected_source_after_sha256") or "",
        "selected_upload_manifest_csv_sha256": item.get("selected_upload_manifest_csv_sha256") or "",
        "candidate_response_packet_count": int(
            item.get("candidate_response_packet_count")
            or summary.get("candidate_response_packet_count")
            or 0
        ),
        "matching_executor_response_packet_count": int(
            item.get("matching_executor_response_packet_count")
            or summary.get("matching_executor_response_packet_count")
            or 0
        ),
        "selected_executor_response_packet_count": int(
            item.get("selected_executor_response_packet_count")
            or summary.get("selected_executor_response_packet_count")
            or (1 if item.get("selected_executor_response_packet_path") else 0)
        ),
        "next_agent_stage": item.get("next_agent_stage") or "",
        "next_agent_command": item.get("next_agent_command") or "",
        "safe": bool(
            _clean_pass(item)
            and not any(item.get(key) for key in FORBIDDEN_KEYS)
        ),
    }


def _executor_response_packet_discovery_next(report):
    view = _executor_response_packet_discovery_view(report)
    if not view.get("present") or not view.get("safe") or not view.get("ready"):
        return {}
    if not view.get("selected_executor_response_packet_count"):
        return {}
    next_stage = view.get("next_agent_stage") or ""
    if not next_stage or next_stage == "claim_draft":
        return {}
    return {
        "next_stage": next_stage,
        "next_command": view.get("next_agent_command") or "",
        "reason": "executor response packet discovery selected response packet for contract",
    }


def _claim_pipeline_idle(by_stage):
    draft = by_stage.get("claim_draft") or {}
    if not draft.get("present"):
        return True
    return bool(
        draft.get("state") == "CLAIM_DRAFT_IDLE_NO_ACTIVE_COMPUTE_GAPS"
        or (draft.get("status") == "PASS" and not draft.get("ready"))
    )


def _external_auth_boundary_ready(by_stage):
    capstone = by_stage.get("external_submission_readiness_capstone") or {}
    return bool(
        capstone.get("present")
        and capstone.get("status") == "PASS"
        and capstone.get("state") == "LOCAL_READY_EXTERNAL_AUTH_REQUIRED"
        and capstone.get("capstone_readiness_semantics_source_evidence_ready")
        and capstone.get("capstone_readiness_semantics_local_closeout_source_evidence_ready")
        and capstone.get(
            "capstone_readiness_semantics_external_auth_boundary_source_evidence_ready"
        )
        and capstone.get("capstone_readiness_semantics_release_lock_source_evidence_ready")
        and capstone.get("capstone_external_lifecycle_source_evidence_gate_pass")
        and not capstone.get("issues")
    )


def _blocking_stage_issues(item, by_stage):
    issues = list((item or {}).get("issues") or [])
    if not _external_auth_boundary_ready(by_stage):
        return issues
    if item.get("stage") not in EXTERNAL_AUTH_REQUIRED_NONBLOCKING_STAGES:
        return issues
    return [
        issue
        for issue in issues
        if (issue.get("issue") or "") != "stage_validation_issues_present"
    ]


def _external_submission_handoff_view(reports, by_stage):
    bundle = reports.get("external_submission_handoff_bundle") or {}
    packet = bundle.get("claim_external_submission_handoff_packet") or {}
    auth_boundary_ready = _external_auth_boundary_ready(by_stage)
    if not bundle and not packet:
        return {
            "present": False,
            "packet_created": False,
            "stale_ref_count": 0,
            "ref_freshness": [],
        }
    ref_bindings = [
        ("external_submission_readiness", "readiness_report_ref"),
        ("external_submission_execution_preflight", "preflight_report_ref"),
        ("external_submission_portal_capability_attestation", "portal_capability_attestation_report_ref"),
        ("external_submission_portal_capability_attestation_intake", "portal_capability_attestation_intake_report_ref"),
        ("external_submission_execution_gate", "execution_gate_report_ref"),
        ("external_submission_execution_terminal_status", "execution_terminal_status_report_ref"),
    ]
    freshness = []
    for stage_name, ref_key in ref_bindings:
        ref = packet.get(ref_key) or {}
        stage_item = by_stage.get(stage_name) or {}
        handoff_sha = ref.get("sha256") or ""
        latest_sha = stage_item.get("report_sha256") or ""
        present = bool(ref.get("path"))
        fresh = bool(not present or not latest_sha or handoff_sha == latest_sha)
        if (
            not fresh
            and auth_boundary_ready
            and stage_name in EXTERNAL_AUTH_REQUIRED_NONBLOCKING_STAGES
            and stage_item.get("issues")
        ):
            fresh = True
        freshness.append(
            {
                "stage": stage_name,
                "handoff_report_path": ref.get("path") or "",
                "handoff_report_sha256": handoff_sha,
                "latest_stage_report_sha256": latest_sha,
                "fresh": fresh,
            }
        )
    stale_refs = [item for item in freshness if not item.get("fresh")]
    attestation_missing = []
    if packet.get("portal_capability_attestation_template_packet"):
        attestation_missing = list((packet.get("portal_capability_attestation_template_packet") or {}).get("missing_fields") or [])
    if not attestation_missing:
        attestation_stage = by_stage.get("external_submission_portal_capability_attestation") or {}
        attestation_missing = list(attestation_stage.get("portal_capability_attestation_missing_fields") or [])
    evidence_missing = []
    if packet.get("performed_evidence_template_packet"):
        evidence_missing = list((packet.get("performed_evidence_template_packet") or {}).get("missing_fields") or [])
    if not evidence_missing:
        gate_stage = by_stage.get("external_submission_execution_gate") or {}
        evidence_missing = list(gate_stage.get("performed_evidence_missing_fields") or [])
    return {
        "present": bool(bundle),
        "packet_created": bool(packet),
        "report_path": bundle.get("report_path") or "",
        "report_sha256": bundle.get("report_sha256") or "",
        "claim_packet_id": packet.get("claim_packet_id") or "",
        "source_target_path": packet.get("source_target_path") or "",
        "portal_capability_handoff_packet_count": int(packet.get("portal_capability_handoff_packet_count") or 0),
        "portal_capability_attestation_template_count": int(packet.get("portal_capability_attestation_template_count") or 0),
        "portal_capability_attestation_missing_fields": attestation_missing,
        "portal_capability_attestation_intake_state": packet.get("portal_capability_attestation_intake_state") or "",
        "portal_capability_attestation_intake_packet_count": int(packet.get("portal_capability_attestation_intake_packet_count") or 0),
        "portal_capability_attestation_operator_intake_template_count": int(
            packet.get("portal_capability_attestation_operator_intake_template_count") or 0
        ),
        "portal_capability_attestation_intake_consumed_by_attestation": bool(
            packet.get("portal_capability_attestation_intake_consumed_by_attestation")
        ),
        "performed_evidence_template_count": int(packet.get("performed_evidence_template_count") or 0),
        "performed_evidence_missing_field_count": int(packet.get("performed_evidence_missing_field_count") or 0),
        "performed_evidence_missing_fields": evidence_missing,
        "terminal_performed_evidence_template_count": int(packet.get("terminal_performed_evidence_template_count") or 0),
        "terminal_performed_evidence_missing_field_count": int(packet.get("terminal_performed_evidence_missing_field_count") or 0),
        "terminal_status": packet.get("terminal_status") or "",
        "stale_ref_count": len(stale_refs),
        "ref_freshness": freshness,
    }


def _next_step(stage_items, handoff_view=None, reports=None):
    if not stage_items:
        return {
            "next_stage": "claim_draft",
            "next_command": "research-compute-claim-draft --enable-full-agent-autonomy --write",
            "reason": "no lifecycle reports supplied",
        }
    quality_gate_ready = any(item["stage"] == "claim_quality_gate" and item["present"] and item["ready"] for item in stage_items)
    evidence_gate_ready = any(item["stage"] == "claim_evidence_execution" and item["present"] and item["ready"] for item in stage_items)
    evidence_quality_gate_ready = any(item["stage"] == "claim_evidence_quality_gate" and item["present"] and item["ready"] for item in stage_items)
    by_stage = {item["stage"]: item for item in stage_items}
    reports = reports or {}
    executor_task_report = reports.get("external_submission_execution_executor_task") or {}
    executor_response_contract_report = reports.get("external_submission_execution_executor_response_contract") or {}
    performed_intake_report = reports.get("external_submission_execution_performed_evidence_intake") or {}
    executor_response_backlog_report = reports.get("external_submission_execution_executor_response_backlog") or {}
    executor_response_work_item_report = reports.get("external_submission_execution_executor_response_work_item") or {}
    executor_response_inbox_index_report = reports.get("external_submission_execution_executor_response_inbox_index") or {}
    executor_response_inbox_cursor_report = reports.get("external_submission_execution_executor_response_inbox_cursor") or {}
    executor_response_work_item_dispatch_report = reports.get("external_submission_execution_executor_response_work_item_dispatch") or {}
    executor_response_waiting_status_report = reports.get("external_submission_execution_executor_response_waiting_status") or {}
    executor_response_waiting_escalation_report = reports.get("external_submission_execution_executor_response_waiting_escalation") or {}
    executor_response_waiting_scheduler_report = reports.get("external_submission_execution_executor_response_waiting_scheduler") or {}
    executor_response_waiting_redrive_plan_report = reports.get("external_submission_execution_executor_response_waiting_redrive_plan") or {}
    executor_response_packet_discovery_report = reports.get("external_submission_execution_executor_response_packet_discovery") or {}
    dispatch_next = _executor_response_work_item_dispatch_next(executor_response_work_item_dispatch_report)
    dispatch_view = _executor_response_work_item_dispatch_view(executor_response_work_item_dispatch_report)
    waiting_status_next = _executor_response_waiting_status_next(executor_response_waiting_status_report)
    waiting_escalation_next = _executor_response_waiting_escalation_next(executor_response_waiting_escalation_report)
    waiting_scheduler_next = _executor_response_waiting_scheduler_next(executor_response_waiting_scheduler_report)
    waiting_redrive_plan_next = _executor_response_waiting_redrive_plan_next(executor_response_waiting_redrive_plan_report)
    discovery_next = _executor_response_packet_discovery_next(executor_response_packet_discovery_report)
    inbox_cursor_next = _executor_response_inbox_cursor_next(executor_response_inbox_cursor_report)
    inbox_index_next = _executor_response_inbox_index_next(executor_response_inbox_index_report)
    work_item_next = _executor_response_work_item_next(executor_response_work_item_report)
    backlog_next = _executor_response_backlog_next(executor_response_backlog_report)
    primary_anchor = _primary_claim_anchor(handoff_view or {}, by_stage)

    def anchor_allowed(report):
        if not _anchor_present(primary_anchor):
            return True
        observed = _anchor_from_mapping(report or {})
        return _anchor_present(observed) and _anchors_compatible(primary_anchor, observed)

    if (
        dispatch_next
        and _claim_pipeline_idle(by_stage)
        and anchor_allowed(executor_response_work_item_dispatch_report)
        and dispatch_view.get("next_agent_stage") != "external_submission_execution_executor_response_waiting"
    ):
        return dispatch_next
    if discovery_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_packet_discovery_report):
        return discovery_next
    if inbox_cursor_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_inbox_cursor_report):
        return inbox_cursor_next
    if (
        inbox_index_next
        and _claim_pipeline_idle(by_stage)
        and not executor_response_inbox_cursor_report
        and anchor_allowed(executor_response_inbox_index_report)
    ):
        return inbox_index_next
    if (
        waiting_redrive_plan_next
        and _claim_pipeline_idle(by_stage)
        and anchor_allowed(executor_response_waiting_redrive_plan_report)
    ):
        return waiting_redrive_plan_next
    if waiting_scheduler_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_waiting_scheduler_report):
        return waiting_scheduler_next
    if (
        waiting_escalation_next
        and _claim_pipeline_idle(by_stage)
        and anchor_allowed(executor_response_waiting_escalation_report)
    ):
        return waiting_escalation_next
    if waiting_status_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_waiting_status_report):
        return waiting_status_next
    if dispatch_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_work_item_dispatch_report):
        return dispatch_next
    if work_item_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_work_item_report):
        return work_item_next
    if backlog_next and _claim_pipeline_idle(by_stage) and anchor_allowed(executor_response_backlog_report):
        return backlog_next
    if _external_auth_boundary_ready(by_stage):
        return {
            "next_stage": "external_submission_readiness_capstone",
            "next_command": "external-submission-readiness-capstone --claim-external-auto-latest --write --json",
            "reason": "local readiness is waiting for explicit external-action authorization",
        }
    for item in stage_items:
        if _portal_capability_attestation_skippable(item, by_stage):
            continue
        if _portal_capability_attestation_intake_skippable(item, by_stage):
            continue
        if _record_only_fixture_harness_skippable(item, by_stage):
            continue
        if not item["present"]:
            if item["stage"] == "external_submission_portal_capability_attestation":
                preflight = by_stage.get("external_submission_execution_preflight") or {}
                if preflight.get("present") and preflight.get("ready"):
                    continue
                if _preflight_requires_portal_capability_attestation(preflight):
                    return {
                        "next_stage": item["stage"],
                        "next_command": _portal_capability_attestation_command(preflight),
                        "reason": "portal capability attestation required by preflight handoff",
                    }
            if item["stage"] == "external_submission_portal_capability_attestation_intake":
                attestation = by_stage.get("external_submission_portal_capability_attestation") or {}
                if attestation.get("present") and attestation.get("ready"):
                    continue
                if attestation.get("present") and attestation.get("portal_capability_attestation_template_count"):
                    return {
                        "next_stage": item["stage"],
                        "next_command": _portal_capability_attestation_intake_command(attestation),
                        "reason": "portal capability attestation intake required",
                    }
            return {
                "next_stage": item["stage"],
                "next_command": item["command"],
                "reason": "stage report missing",
            }
        if item["stage"] == "patch_materialization" and quality_gate_ready and not item.get("claim_quality_gate_ready"):
            return {
                "next_stage": item["stage"],
                "next_command": item["command"],
                "reason": "claim quality gate not consumed by materialization",
            }
        if item["stage"] == "patch_materialization" and evidence_gate_ready and not item.get("claim_evidence_execution_ready"):
            return {
                "next_stage": item["stage"],
                "next_command": item["command"],
                "reason": "claim evidence execution not consumed by materialization",
            }
        if item["stage"] == "patch_materialization" and evidence_quality_gate_ready and not item.get("claim_evidence_quality_gate_ready"):
            return {
                "next_stage": item["stage"],
                "next_command": item["command"],
                "reason": "claim evidence quality gate not consumed by materialization",
            }
        if item["stage"] == "source_apply_readiness":
            materialization = by_stage.get("patch_materialization") or {}
            if (
                materialization.get("present")
                and materialization.get("patch_draft_has_changes")
                and item["present"]
                and materialization.get("report_sha256")
                and item.get("claim_materialization_report_sha256") != materialization.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                    "reason": "latest patch materialization not consumed by source apply readiness",
                }
        if item["stage"] == "source_apply_execution":
            readiness = by_stage.get("source_apply_readiness") or {}
            if (
                readiness.get("present")
                and readiness.get("patch_file_sha256")
                and item["present"]
                and readiness.get("report_sha256")
                and item.get("readiness_report_sha256") != readiness.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                    "reason": "latest source apply readiness not consumed by source apply execution",
                }
        if item["stage"] == "source_landing_finalization":
            execution = by_stage.get("source_apply_execution") or {}
            if (
                execution.get("present")
                and execution.get("source_after_sha256")
                and item["present"]
                and execution.get("report_sha256")
                and item.get("execution_report_sha256") != execution.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                "reason": "latest source apply execution not consumed by source landing finalization",
            }
        if item["stage"] == "external_submission_execution_intent":
            preflight = by_stage.get("external_submission_execution_preflight") or {}
            if (
                preflight.get("present")
                and preflight.get("ready")
                and item["present"]
                and preflight.get("report_sha256")
                and item.get("execution_preflight_report_sha256") != preflight.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                    "reason": "latest external submission execution preflight not consumed by intent",
                }
        if item["stage"] == "external_submission_execution_preflight":
            attestation = by_stage.get("external_submission_portal_capability_attestation") or {}
            intake = by_stage.get("external_submission_portal_capability_attestation_intake") or {}
            if attestation.get("present") and attestation.get("ready") and attestation.get("report_sha256"):
                if item.get("portal_capability_attestation_report_sha256") != attestation.get("report_sha256"):
                    return {
                        "next_stage": item["stage"],
                        "next_command": _preflight_command_with_attestation(item, attestation),
                        "reason": "latest portal capability attestation not consumed by preflight",
                    }
            if intake.get("present") and intake.get("ready") and intake.get("report_sha256"):
                if not attestation.get("present") or attestation.get("portal_capability_attestation_intake_report_sha256") != intake.get("report_sha256"):
                    return {
                        "next_stage": "external_submission_portal_capability_attestation",
                        "next_command": _portal_capability_attestation_command_with_intake(item, intake),
                        "reason": "latest portal capability attestation intake not consumed by attestation",
                    }
            if _preflight_requires_portal_capability_attestation(item):
                if not attestation.get("present"):
                    return {
                        "next_stage": "external_submission_portal_capability_attestation",
                        "next_command": _portal_capability_attestation_command(item),
                        "reason": "portal capability attestation required by preflight handoff",
                    }
                if attestation.get("issues") or attestation.get("status") == "ATTENTION" or not attestation.get("ready"):
                    if attestation.get("portal_capability_attestation_template_count"):
                        if intake.get("present") and intake.get("ready"):
                            return {
                                "next_stage": "external_submission_portal_capability_attestation",
                                "next_command": _portal_capability_attestation_command_with_intake(item, intake),
                                "reason": "portal capability attestation intake ready for attestation",
                            }
                        return {
                            "next_stage": "external_submission_portal_capability_attestation_intake",
                            "next_command": _portal_capability_attestation_intake_command(attestation, intake),
                            "reason": "portal capability attestation intake required",
                        }
                    reason = "portal capability attestation template required" if attestation.get("portal_capability_attestation_template_count") else "portal capability attestation not ready"
                    return {
                        "next_stage": "external_submission_portal_capability_attestation",
                        "next_command": _portal_capability_attestation_command(item),
                        "reason": reason,
                    }
        if item["stage"] == "external_submission_execution_gate":
            intent = by_stage.get("external_submission_execution_intent") or {}
            if (
                intent.get("present")
                and intent.get("ready")
                and item["present"]
                and intent.get("report_sha256")
                and item.get("execution_intent_report_sha256") != intent.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                    "reason": "latest external submission execution intent not consumed by gate",
                }
            if item.get("performed_evidence_template_count"):
                capstone = by_stage.get("external_submission_readiness_capstone") or {}
                if _performed_evidence_intake_ready(performed_intake_report, intent=intent, executor_task=executor_task_report):
                    return {
                        "next_stage": "external_submission_execution_gate",
                        "next_command": _execution_gate_with_performed_evidence_command(intent, performed_intake_report),
                        "reason": "performed evidence intake ready for execution gate",
                    }
                if _executor_response_contract_ready(executor_response_contract_report, executor_task=executor_task_report):
                    return {
                        "next_stage": "external_submission_execution_performed_evidence_intake",
                        "next_command": _performed_evidence_intake_command(
                            intent,
                            executor_task_report,
                            response_path=executor_response_contract_report.get("executor_response_packet_path") or "",
                        ),
                        "reason": "executor response contract ready for performed evidence intake",
                    }
                if _executor_task_ready(executor_task_report, intent=intent):
                    return {
                        "next_stage": "external_submission_execution_executor_response_contract",
                        "next_command": _executor_response_contract_command(executor_task_report),
                        "reason": "external executor response contract required before performed evidence intake",
                    }
                return {
                    "next_stage": "external_submission_execution_executor_task",
                    "next_command": _executor_task_command(intent, handoff_view=handoff_view, capstone=capstone),
                    "reason": "external submission executor task required before performed evidence intake",
                }
        if item["stage"] == "external_submission_execution_terminal_status":
            gate = by_stage.get("external_submission_execution_gate") or {}
            if (
                gate.get("present")
                and gate.get("ready")
                and item["present"]
                and gate.get("report_sha256")
                and item.get("execution_gate_report_sha256") != gate.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                    "reason": "latest external submission execution gate not consumed by terminal status",
                }
            if item.get("performed_evidence_template_count"):
                intent = by_stage.get("external_submission_execution_intent") or {}
                capstone = by_stage.get("external_submission_readiness_capstone") or {}
                if _performed_evidence_intake_ready(performed_intake_report, intent=intent, executor_task=executor_task_report):
                    return {
                        "next_stage": "external_submission_execution_gate",
                        "next_command": _execution_gate_with_performed_evidence_command(intent, performed_intake_report),
                        "reason": "performed evidence intake ready for execution gate",
                    }
                if _executor_response_contract_ready(executor_response_contract_report, executor_task=executor_task_report):
                    return {
                        "next_stage": "external_submission_execution_performed_evidence_intake",
                        "next_command": _performed_evidence_intake_command(
                            intent,
                            executor_task_report,
                            response_path=executor_response_contract_report.get("executor_response_packet_path") or "",
                        ),
                        "reason": "executor response contract ready for performed evidence intake",
                    }
                if _executor_task_ready(executor_task_report, intent=intent):
                    return {
                        "next_stage": "external_submission_execution_executor_response_contract",
                        "next_command": _executor_response_contract_command(executor_task_report),
                        "reason": "external executor response contract required before performed evidence intake",
                    }
                return {
                    "next_stage": "external_submission_execution_executor_task",
                    "next_command": _executor_task_command(intent, handoff_view=handoff_view, capstone=capstone),
                    "reason": "terminal status is waiting on external submission executor task",
                }
        if item["stage"] == "external_submission_execution_record_only_fixture_harness":
            intent = by_stage.get("external_submission_execution_intent") or {}
            if (
                intent.get("present")
                and intent.get("ready")
                and item["present"]
                and intent.get("report_sha256")
                and item.get("execution_intent_report_sha256") != intent.get("report_sha256")
            ):
                return {
                    "next_stage": item["stage"],
                    "next_command": item["command"],
                    "reason": "latest external submission execution intent not consumed by record-only fixture harness",
                }
        if item["issues"]:
            return {
                "next_stage": item["stage"],
                "next_command": item["command"],
                "reason": "stage validation issue",
            }
        if item["status"] == "ATTENTION" or not item["ready"]:
            reason = "stage not ready"
            if item["stage"] == "external_submission_execution_gate" and item.get("performed_evidence_template_count"):
                reason = "external submission executor task required"
            elif item["stage"] == "external_submission_execution_terminal_status" and item.get("performed_evidence_template_count"):
                reason = "external submission executor task required"
            elif item["stage"] == "external_submission_portal_capability_attestation_intake" and item.get("portal_capability_attestation_operator_intake_template_count"):
                reason = "portal capability attestation intake template required"
            return {
                "next_stage": item["stage"],
                "next_command": item["command"],
                "reason": reason,
            }
    return {
        "next_stage": "complete",
        "next_command": "",
        "reason": "all supplied lifecycle stages are ready",
    }


def research_compute_claim_manuscript_lifecycle_orchestrator(reports=None, label=""):
    reports = reports or {}
    stage_items = [_stage_item(stage, reports.get(stage["report_key"]) or {}) for stage in STAGES]
    supplied_items = [item for item in stage_items if item["present"]]
    by_stage = {item["stage"]: item for item in stage_items}
    capstone_stage = by_stage.get("external_submission_readiness_capstone") or {}
    external_auth_boundary_ready = _external_auth_boundary_ready(by_stage)
    handoff_view = _external_submission_handoff_view(reports, by_stage)
    all_issues = [
        issue
        for item in supplied_items
        if not _portal_capability_attestation_skippable(item, by_stage)
        and not _portal_capability_attestation_intake_skippable(item, by_stage)
        and not _record_only_fixture_harness_skippable(item, by_stage)
        for issue in _blocking_stage_issues(item, by_stage)
    ]
    all_issues.extend(_anchor_validation_issues(reports, handoff_view, by_stage))
    forbidden = any(str(issue.get("issue") or "").startswith("forbidden_") for issue in all_issues)
    next_step = _next_step(stage_items, handoff_view=handoff_view, reports=reports)
    ready_count = sum(1 for item in supplied_items if item["ready"])
    performed_source_mutation_count = sum(1 for item in supplied_items if reports.get(item["stage"], {}).get("source_mutation_performed"))
    performed_external_action_count = sum(1 for item in supplied_items if item.get("external_action_performed"))
    terminal_status = (
        (reports.get("external_submission_execution_record_only_fixture_harness") or {}).get("terminal_status")
        or (reports.get("external_submission_execution_terminal_status") or {}).get("terminal_status")
        or ""
    )
    executor_task_report = reports.get("external_submission_execution_executor_task") or {}
    executor_response_contract_report = reports.get("external_submission_execution_executor_response_contract") or {}
    performed_intake_report = reports.get("external_submission_execution_performed_evidence_intake") or {}
    executor_response_backlog_report = reports.get("external_submission_execution_executor_response_backlog") or {}
    executor_response_backlog_view = _executor_response_backlog_view(executor_response_backlog_report)
    executor_response_work_item_report = reports.get("external_submission_execution_executor_response_work_item") or {}
    executor_response_work_item_view = _executor_response_work_item_view(executor_response_work_item_report)
    executor_response_inbox_index_report = reports.get("external_submission_execution_executor_response_inbox_index") or {}
    executor_response_inbox_index_view = _executor_response_inbox_index_view(executor_response_inbox_index_report)
    executor_response_inbox_cursor_report = reports.get("external_submission_execution_executor_response_inbox_cursor") or {}
    executor_response_inbox_cursor_view = _executor_response_inbox_cursor_view(executor_response_inbox_cursor_report)
    executor_response_work_item_dispatch_report = reports.get("external_submission_execution_executor_response_work_item_dispatch") or {}
    executor_response_work_item_dispatch_view = _executor_response_work_item_dispatch_view(
        executor_response_work_item_dispatch_report
    )
    executor_response_waiting_status_report = reports.get("external_submission_execution_executor_response_waiting_status") or {}
    executor_response_waiting_status_view = _executor_response_waiting_status_view(
        executor_response_waiting_status_report
    )
    executor_response_waiting_escalation_report = reports.get("external_submission_execution_executor_response_waiting_escalation") or {}
    executor_response_waiting_escalation_view = _executor_response_waiting_escalation_view(
        executor_response_waiting_escalation_report
    )
    executor_response_waiting_scheduler_report = reports.get("external_submission_execution_executor_response_waiting_scheduler") or {}
    executor_response_waiting_scheduler_view = _executor_response_waiting_scheduler_view(
        executor_response_waiting_scheduler_report
    )
    executor_response_waiting_redrive_plan_report = reports.get("external_submission_execution_executor_response_waiting_redrive_plan") or {}
    executor_response_waiting_redrive_plan_view = _executor_response_waiting_redrive_plan_view(
        executor_response_waiting_redrive_plan_report
    )
    executor_response_packet_discovery_report = reports.get("external_submission_execution_executor_response_packet_discovery") or {}
    executor_response_packet_discovery_view = _executor_response_packet_discovery_view(
        executor_response_packet_discovery_report
    )

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif not supplied_items:
        status = "PASS"
        state = IDLE_STATE
    elif all_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif next_step["next_stage"] == "complete":
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = WAITING_STATE

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_lifecycle_orchestrator_state": state,
        "lifecycle_orchestrator_created": status in {"PASS", "ATTENTION"},
        "agent_lifecycle_ready": state == READY_STATE,
        "next_agent_stage": next_step["next_stage"],
        "next_agent_command": next_step["next_command"],
        "next_agent_reason": next_step["reason"],
        "terminal_status": terminal_status,
        "external_submission_handoff_latest_view": handoff_view,
        "executor_response_backlog_latest_view": executor_response_backlog_view,
        "executor_response_work_item_latest_view": executor_response_work_item_view,
        "executor_response_inbox_index_latest_view": executor_response_inbox_index_view,
        "executor_response_inbox_cursor_latest_view": executor_response_inbox_cursor_view,
        "executor_response_work_item_dispatch_latest_view": executor_response_work_item_dispatch_view,
        "executor_response_waiting_status_latest_view": executor_response_waiting_status_view,
        "executor_response_waiting_escalation_latest_view": executor_response_waiting_escalation_view,
        "executor_response_waiting_scheduler_latest_view": executor_response_waiting_scheduler_view,
        "executor_response_waiting_redrive_plan_latest_view": executor_response_waiting_redrive_plan_view,
        "executor_response_packet_discovery_latest_view": executor_response_packet_discovery_view,
        "source_mutation_performed_by_this_command": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "stage_count": len(STAGES),
            "supplied_stage_count": len(supplied_items),
            "ready_stage_count": ready_count,
            "missing_stage_count": len(STAGES) - len(supplied_items),
            "validation_issue_count": len(all_issues),
            "external_auth_boundary_ready": external_auth_boundary_ready,
            "external_auth_boundary_readiness_semantics_source_evidence_ready": capstone_stage.get(
                "capstone_readiness_semantics_source_evidence_ready"
            ),
            "external_auth_boundary_readiness_semantics_local_closeout_source_evidence_ready": capstone_stage.get(
                "capstone_readiness_semantics_local_closeout_source_evidence_ready"
            ),
            "external_auth_boundary_readiness_semantics_external_auth_boundary_source_evidence_ready": capstone_stage.get(
                "capstone_readiness_semantics_external_auth_boundary_source_evidence_ready"
            ),
            "external_auth_boundary_readiness_semantics_release_lock_source_evidence_ready": capstone_stage.get(
                "capstone_readiness_semantics_release_lock_source_evidence_ready"
            ),
            "external_auth_boundary_external_lifecycle_source_evidence_gate_pass": capstone_stage.get(
                "capstone_external_lifecycle_source_evidence_gate_pass"
            ),
            "external_submission_handoff_view_present_count": 1 if handoff_view.get("present") else 0,
            "external_submission_handoff_packet_created_count": 1 if handoff_view.get("packet_created") else 0,
            "external_submission_handoff_stale_ref_count": int(handoff_view.get("stale_ref_count") or 0),
            "portal_capability_handoff_packet_count": sum(
                int(item.get("portal_capability_handoff_packet_count") or 0) for item in supplied_items
            ),
            "portal_capability_attestation_template_count": sum(
                int(item.get("portal_capability_attestation_template_count") or 0) for item in supplied_items
            ),
            "portal_capability_attestation_intake_packet_count": sum(
                int(item.get("portal_capability_attestation_intake_packet_count") or 0) for item in supplied_items
            ),
            "portal_capability_attestation_operator_intake_template_count": sum(
                int(item.get("portal_capability_attestation_operator_intake_template_count") or 0) for item in supplied_items
            ),
            "portal_capability_attestation_operator_response_template_count": sum(
                int(item.get("portal_capability_attestation_operator_response_template_count") or 0) for item in supplied_items
            ),
            "performed_evidence_template_count": sum(
                int(item.get("performed_evidence_template_count") or 0) for item in supplied_items
            ),
            "performed_evidence_missing_field_count": sum(
                int(item.get("performed_evidence_missing_field_count") or 0) for item in supplied_items
            ),
            "external_submission_executor_task_present_count": 1 if executor_task_report else 0,
            "external_submission_executor_task_ready_count": 1 if _executor_task_ready(executor_task_report) else 0,
            "executor_response_contract_present_count": 1 if executor_response_contract_report else 0,
            "executor_response_contract_ready_count": 1 if _executor_response_contract_ready(executor_response_contract_report) else 0,
            "executor_response_contract_waiting_count": 1 if executor_response_contract_report.get("waiting_for_executor_response") else 0,
            "executor_response_backlog_present_count": 1 if executor_response_backlog_report else 0,
            "executor_response_backlog_pending_count": int(executor_response_backlog_view.get("pending_executor_response_count") or 0),
            "executor_response_backlog_ready_for_intake_count": int(executor_response_backlog_view.get("ready_for_intake_count") or 0),
            "executor_response_backlog_ready_for_gate_count": int(executor_response_backlog_view.get("ready_for_gate_count") or 0),
            "executor_response_work_item_present_count": 1 if executor_response_work_item_report else 0,
            "executor_response_work_item_ready_count": 1 if executor_response_work_item_view.get("ready") else 0,
            "executor_response_work_item_selected_count": int(executor_response_work_item_view.get("selected_work_item_count") or 0),
            "executor_response_inbox_index_present_count": 1 if executor_response_inbox_index_report else 0,
            "executor_response_inbox_index_ready_count": 1 if executor_response_inbox_index_view.get("ready") else 0,
            "executor_response_inbox_index_candidate_count": int(
                executor_response_inbox_index_view.get("candidate_response_packet_count") or 0
            ),
            "executor_response_inbox_index_ready_packet_count": int(
                executor_response_inbox_index_view.get("ready_response_packet_count") or 0
            ),
            "executor_response_inbox_index_duplicate_packet_count": int(
                executor_response_inbox_index_view.get("duplicate_response_packet_count") or 0
            ),
            "executor_response_inbox_index_consumed_packet_count": int(
                executor_response_inbox_index_view.get("consumed_response_packet_count") or 0
            ),
            "executor_response_inbox_cursor_present_count": 1 if executor_response_inbox_cursor_report else 0,
            "executor_response_inbox_cursor_ready_count": 1 if executor_response_inbox_cursor_view.get("ready") else 0,
            "executor_response_inbox_cursor_eligible_packet_count": int(
                executor_response_inbox_cursor_view.get("eligible_response_packet_count") or 0
            ),
            "executor_response_inbox_cursor_selected_count": int(
                executor_response_inbox_cursor_view.get("selected_executor_response_packet_count") or 0
            ),
            "executor_response_inbox_cursor_skipped_consumed_packet_count": int(
                executor_response_inbox_cursor_view.get("skipped_consumed_response_packet_count") or 0
            ),
            "executor_response_inbox_cursor_skipped_anchor_mismatch_packet_count": int(
                executor_response_inbox_cursor_view.get("skipped_anchor_mismatch_response_packet_count") or 0
            ),
            "executor_response_work_item_dispatch_present_count": 1 if executor_response_work_item_dispatch_report else 0,
            "executor_response_work_item_dispatch_ready_count": 1 if executor_response_work_item_dispatch_view.get("ready") else 0,
            "executor_response_work_item_dispatch_waiting_count": int(
                executor_response_work_item_dispatch_view.get("waiting_for_executor_response_count") or 0
            ),
            "executor_response_work_item_dispatch_ready_for_contract_count": int(
                executor_response_work_item_dispatch_view.get("ready_for_contract_count") or 0
            ),
            "executor_response_work_item_dispatch_ready_for_intake_count": int(
                executor_response_work_item_dispatch_view.get("ready_for_intake_count") or 0
            ),
            "executor_response_work_item_dispatch_ready_for_gate_count": int(
                executor_response_work_item_dispatch_view.get("ready_for_gate_count") or 0
            ),
            "executor_response_waiting_status_present_count": 1 if executor_response_waiting_status_report else 0,
            "executor_response_waiting_status_ready_count": 1 if executor_response_waiting_status_view.get("ready") else 0,
            "executor_response_waiting_status_waiting_count": int(
                executor_response_waiting_status_view.get("waiting_for_executor_response_count") or 0
            ),
            "executor_response_waiting_status_retry_due_count": int(
                executor_response_waiting_status_view.get("retry_due_count") or 0
            ),
            "executor_response_waiting_status_stale_count": int(
                executor_response_waiting_status_view.get("stale_waiting_count") or 0
            ),
            "executor_response_waiting_status_waiting_age_minutes": int(
                executor_response_waiting_status_view.get("waiting_age_minutes") or 0
            ),
            "executor_response_waiting_escalation_present_count": 1 if executor_response_waiting_escalation_report else 0,
            "executor_response_waiting_escalation_ready_count": 1 if executor_response_waiting_escalation_view.get("ready") else 0,
            "executor_response_waiting_escalation_waiting_count": int(
                executor_response_waiting_escalation_view.get("waiting_escalation_waiting_count") or 0
            ),
            "executor_response_waiting_escalation_retry_due_count": int(
                executor_response_waiting_escalation_view.get("waiting_escalation_retry_due_count") or 0
            ),
            "executor_response_waiting_escalation_stale_count": int(
                executor_response_waiting_escalation_view.get("waiting_escalation_stale_count") or 0
            ),
            "executor_response_waiting_escalation_local_retry_scan_count": int(
                executor_response_waiting_escalation_view.get("waiting_escalation_local_retry_scan_count") or 0
            ),
            "executor_response_waiting_escalation_waiting_age_minutes": int(
                executor_response_waiting_escalation_view.get("waiting_age_minutes") or 0
            ),
            "executor_response_waiting_scheduler_present_count": 1 if executor_response_waiting_scheduler_report else 0,
            "executor_response_waiting_scheduler_ready_count": 1 if executor_response_waiting_scheduler_view.get("ready") else 0,
            "executor_response_waiting_scheduler_waiting_count": int(
                executor_response_waiting_scheduler_view.get("waiting_scheduler_waiting_count") or 0
            ),
            "executor_response_waiting_scheduler_local_redrive_due_count": int(
                executor_response_waiting_scheduler_view.get("waiting_scheduler_local_redrive_due_count") or 0
            ),
            "executor_response_waiting_scheduler_stale_count": int(
                executor_response_waiting_scheduler_view.get("waiting_scheduler_stale_count") or 0
            ),
            "executor_response_waiting_scheduler_local_inbox_refresh_count": int(
                executor_response_waiting_scheduler_view.get("waiting_scheduler_local_inbox_refresh_count") or 0
            ),
            "executor_response_waiting_scheduler_waiting_age_minutes": int(
                executor_response_waiting_scheduler_view.get("waiting_age_minutes") or 0
            ),
            "executor_response_waiting_scheduler_minutes_until_retry": int(
                executor_response_waiting_scheduler_view.get("minutes_until_retry") or 0
            ),
            "executor_response_waiting_scheduler_minutes_until_stale": int(
                executor_response_waiting_scheduler_view.get("minutes_until_stale") or 0
            ),
            "executor_response_waiting_redrive_plan_present_count": (
                1 if executor_response_waiting_redrive_plan_report else 0
            ),
            "executor_response_waiting_redrive_plan_ready_count": (
                1 if executor_response_waiting_redrive_plan_view.get("ready") else 0
            ),
            "executor_response_waiting_redrive_plan_waiting_count": int(
                executor_response_waiting_redrive_plan_view.get("waiting_redrive_plan_waiting_count") or 0
            ),
            "executor_response_waiting_redrive_plan_local_redrive_due_count": int(
                executor_response_waiting_redrive_plan_view.get("waiting_redrive_plan_local_redrive_due_count") or 0
            ),
            "executor_response_waiting_redrive_plan_stale_redrive_planned_count": int(
                executor_response_waiting_redrive_plan_view.get("waiting_redrive_plan_stale_redrive_planned_count") or 0
            ),
            "executor_response_waiting_redrive_plan_local_inbox_refresh_count": int(
                executor_response_waiting_redrive_plan_view.get("waiting_redrive_plan_local_inbox_refresh_count") or 0
            ),
            "executor_response_waiting_redrive_plan_attempt_count": int(
                executor_response_waiting_redrive_plan_view.get("waiting_redrive_plan_attempt_count") or 0
            ),
            "executor_response_packet_discovery_present_count": 1 if executor_response_packet_discovery_report else 0,
            "executor_response_packet_discovery_ready_count": 1 if executor_response_packet_discovery_view.get("ready") else 0,
            "executor_response_packet_discovery_candidate_count": int(
                executor_response_packet_discovery_view.get("candidate_response_packet_count") or 0
            ),
            "executor_response_packet_discovery_matching_count": int(
                executor_response_packet_discovery_view.get("matching_executor_response_packet_count") or 0
            ),
            "executor_response_packet_discovery_selected_count": int(
                executor_response_packet_discovery_view.get("selected_executor_response_packet_count") or 0
            ),
            "performed_evidence_intake_present_count": 1 if performed_intake_report else 0,
            "performed_evidence_intake_ready_count": 1 if _performed_evidence_intake_ready(performed_intake_report) else 0,
            "performed_evidence_intake_executor_task_bound_count": 1 if performed_intake_report.get("executor_task_bound") else 0,
            "agent_lifecycle_ready_count": 1 if state == READY_STATE else 0,
            "source_mutation_performed_by_this_command_count": 0,
            "observed_source_mutation_stage_count": performed_source_mutation_count,
            "external_action_performed_count": performed_external_action_count,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": all_issues,
        "stage_reports": stage_items,
        "next_agent_action": next_step,
        "boundary": [
            "This command is a report-only lifecycle orchestrator for claim-derived theorem/proof/experiment manuscript automation.",
            "It selects the next agent command from existing gates instead of bypassing them.",
            "It reads no secrets and performs no source/package/archive mutation, provider/model call, patch-queue merge, commit, portal login, upload, email, final submit, or other external action.",
        ],
    }


def research_compute_claim_manuscript_lifecycle_orchestrator_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript Lifecycle Orchestrator",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_lifecycle_orchestrator_state') or ''}",
        f"- Next stage: {report.get('next_agent_stage') or ''}",
        f"- Next command: `{report.get('next_agent_command') or ''}`",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Stages",
        "",
    ]
    for item in report.get("stage_reports") or []:
        marker = "ready" if item.get("ready") else ("present" if item.get("present") else "missing")
        lines.append(f"- {item.get('stage')}: {marker} ({item.get('state') or 'no state'})")
    view = report.get("external_submission_handoff_latest_view") or {}
    if view.get("present") or view.get("packet_created"):
        lines.extend(["", "## External Submission Handoff View", ""])
        for key in [
            "packet_created",
            "claim_packet_id",
            "portal_capability_attestation_template_count",
            "portal_capability_attestation_missing_fields",
            "portal_capability_attestation_intake_state",
            "portal_capability_attestation_intake_packet_count",
            "portal_capability_attestation_operator_intake_template_count",
            "performed_evidence_template_count",
            "performed_evidence_missing_fields",
            "stale_ref_count",
        ]:
            value = view.get(key)
            if isinstance(value, list):
                value = ", ".join(value)
            lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
