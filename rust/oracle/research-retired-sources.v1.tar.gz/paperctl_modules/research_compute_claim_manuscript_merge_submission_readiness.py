"""Prepare claim-derived merge and submission readiness from source landing."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-merge-submission-readiness"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_manuscript_merge_submission_readiness_state",
    "report_schema",
    "claim_merge_submission_readiness_created",
    "slug",
    "finalization_report_path",
    "finalization_report_sha256",
    "claim_packet_id",
    "selected_request_id",
    "selected_risk_class",
    "source_target_path",
    "source_after_sha256",
    "post_apply_verify_report_path",
    "post_apply_verify_report_sha256",
    "ready_for_post_apply_material_refresh",
    "ready_for_claim_merge_preflight",
    "ready_for_claim_submission_readiness",
    "agent_merge_decision_ready",
    "agent_external_submission_decision_ready",
    "automatic_merge_allowed",
    "automatic_submission_allowed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "report_write_performed",
    "db_mutation_performed",
    "summary",
    "validation_issues",
    "finalization_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "ready_for_post_apply_material_refresh_count",
    "ready_for_claim_merge_preflight_count",
    "ready_for_claim_submission_readiness_count",
    "agent_merge_decision_ready_count",
    "agent_external_submission_decision_ready_count",
    "external_action_authorized_count",
    "external_action_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Prepares report-only merge/submission readiness for claim-derived source landing evidence.",
    "This command performs no source/package/archive mutation, merge, commit, provider/model call, upload, email, or submit.",
]
FINALIZATION_COMMAND = "research-compute-claim-manuscript-source-landing-finalization"

READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_READY"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_IDLE_NO_PATCH_DRAFT"
WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_WAITING_FOR_SOURCE_LANDING"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_MERGE_SUBMISSION_READINESS_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

FINALIZED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_FINALIZED"
FINALIZATION_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_IDLE_NO_PATCH_DRAFT"
FINALIZATION_WAITING_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_READY_NOT_EXECUTED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _forbidden_keys():
    return [
        "source_mutation_performed",
        "source_mutation_performed_by_this_command",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _validate_finalization(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "finalization", item, FINALIZATION_COMMAND)
    if item.get("command") != FINALIZATION_COMMAND:
        issues.append({"issue": "finalization_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "finalization_not_pass", "detail": item.get("status") or ""})
    for key in _forbidden_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_finalization_boundary:{key}"})
    state = item.get("claim_manuscript_source_landing_finalization_state") or ""
    if state not in {FINALIZED_STATE, FINALIZATION_IDLE_STATE, FINALIZATION_WAITING_STATE}:
        issues.append({"issue": "finalization_state_not_consumable", "detail": state})
    if state == FINALIZED_STATE:
        if not item.get("claim_source_landing_finalized"):
            issues.append({"issue": "claim_source_landing_not_finalized"})
        if not item.get("ready_for_claim_merge_readiness"):
            issues.append({"issue": "finalization_not_ready_for_claim_merge"})
        if not item.get("ready_for_claim_submission_readiness"):
            issues.append({"issue": "finalization_not_ready_for_claim_submission"})
        if not item.get("post_apply_verify_report_path"):
            issues.append({"issue": "post_apply_verify_report_path_missing"})
        if not item.get("source_after_sha256"):
            issues.append({"issue": "source_after_sha256_missing"})
    return issues


def research_compute_claim_manuscript_merge_submission_readiness(finalization_report, label=""):
    finalization_report = finalization_report or {}
    issues = _validate_finalization(finalization_report)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    finalization_state = finalization_report.get("claim_manuscript_source_landing_finalization_state") or ""

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif finalization_state == FINALIZATION_IDLE_STATE:
        status = "PASS"
        state = IDLE_STATE
    elif finalization_state == FINALIZATION_WAITING_STATE:
        status = "PASS"
        state = WAITING_STATE
    else:
        status = "PASS"
        state = READY_STATE

    ready = state == READY_STATE
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_merge_submission_readiness_state": state,
        "claim_merge_submission_readiness_created": status == "PASS",
        "slug": finalization_report.get("slug") or "",
        "finalization_report_path": finalization_report.get("report_path") or "",
        "finalization_report_sha256": finalization_report.get("report_sha256") or "",
        "claim_packet_id": finalization_report.get("claim_packet_id") or "",
        "selected_request_id": finalization_report.get("selected_request_id") or "",
        "selected_risk_class": finalization_report.get("selected_risk_class") or "",
        "source_target_path": finalization_report.get("source_target_path") or "",
        "source_after_sha256": finalization_report.get("source_after_sha256") or "",
        "post_apply_verify_report_path": finalization_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": finalization_report.get("post_apply_verify_report_sha256") or "",
        "ready_for_post_apply_material_refresh": bool(ready),
        "ready_for_claim_merge_preflight": bool(ready),
        "ready_for_claim_submission_readiness": bool(ready),
        "agent_merge_decision_ready": bool(ready),
        "agent_external_submission_decision_ready": bool(ready),
        "automatic_merge_allowed": bool(ready),
        "automatic_submission_allowed": bool(ready),
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "ready_for_post_apply_material_refresh_count": 1 if ready else 0,
            "ready_for_claim_merge_preflight_count": 1 if ready else 0,
            "ready_for_claim_submission_readiness_count": 1 if ready else 0,
            "agent_merge_decision_ready_count": 1 if ready else 0,
            "agent_external_submission_decision_ready_count": 1 if ready else 0,
            "external_action_authorized_count": 0,
            "external_action_performed_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "finalization_report": finalization_report,
        "boundary": [
            "This command prepares local merge/submission readiness for claim-derived source landing evidence.",
            "It does not merge, commit, mutate source/package/archive state, call providers/models, upload, email, or submit externally.",
            "External submission execution remains a separate boundary; this packet only records local agent decision readiness.",
        ],
    }


def research_compute_claim_manuscript_merge_submission_readiness_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript Merge/Submission Readiness",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_merge_submission_readiness_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source after SHA256: `{report.get('source_after_sha256') or ''}`",
        f"- Agent merge decision ready: {report.get('agent_merge_decision_ready')}",
        f"- Agent external submission decision ready: {report.get('agent_external_submission_decision_ready')}",
        f"- External action performed: {report.get('external_action_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
