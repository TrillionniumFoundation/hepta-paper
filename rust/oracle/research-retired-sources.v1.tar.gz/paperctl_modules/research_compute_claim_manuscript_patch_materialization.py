"""Materialize manuscript patch drafts from research-compute claim packets.

This command is the generic claim-packet counterpart to the older narrow
manuscript patch worker. It drafts a local unified diff under logs only and
leaves source apply, rollback, post-apply verification, merge, and submission to
later gates.
"""

import difflib
import datetime as dt
import re

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-patch-materialization"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_manuscript_patch_materialization_state",
    "report_schema",
    "claim_patch_materialization_created",
    "slug",
    "claim_draft_report_path",
    "claim_draft_report_sha256",
    "claim_quality_gate_report_path",
    "claim_quality_gate_report_sha256",
    "claim_quality_gate_ready",
    "claim_evidence_execution_report_path",
    "claim_evidence_execution_report_sha256",
    "claim_evidence_execution_ready",
    "claim_evidence_quality_gate_report_path",
    "claim_evidence_quality_gate_report_sha256",
    "claim_evidence_quality_gate_ready",
    "evidence_gate_ready",
    "evidence_output_hashes",
    "claim_packet_selected",
    "claim_packet_id",
    "selected_request_id",
    "selected_request_key",
    "selected_risk_class",
    "selected_claim_kind",
    "selected_source_locator",
    "source_target_path",
    "source_target_exists",
    "source_target_sha256",
    "source_target_expected_sha256",
    "automatic_final_claim_allowed",
    "automatic_source_apply_allowed",
    "automatic_merge_allowed",
    "automatic_submission_allowed",
    "full_agent_autonomy_authorized",
    "local_execution_request",
    "bridge_plan_request",
    "patch_draft_generated",
    "patch_draft_applied",
    "ready_for_manuscript_patch_draft_preflight",
    "source_mutation_apply_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "report_write_performed",
    "db_mutation_performed",
    "summary",
    "validation_issues",
    "patch_draft",
    "selected_claim_packet",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "claim_packet_count",
    "claim_quality_gate_ready_count",
    "claim_evidence_execution_ready_count",
    "claim_evidence_quality_gate_ready_count",
    "evidence_output_hash_count",
    "patch_draft_generated_count",
    "automatic_final_claim_allowed_count",
    "automatic_source_apply_allowed_count",
    "automatic_merge_allowed_count",
    "automatic_submission_allowed_count",
    "source_mutation_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Materializes one research-compute claim packet into a local manuscript unified-diff draft.",
    "This command writes only local logs and does not apply patches, call providers/models, merge queue rows, commit, upload, email, or submit.",
]
CLAIM_DRAFT_COMMAND = "research-compute-claim-draft"
CLAIM_DRAFT_COMMANDS = {
    CLAIM_DRAFT_COMMAND,
    "research-compute-claim-boundary-reentry-draft",
}
READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_PATCH_MATERIALIZATION_DRAFT_READY_NOT_APPLIED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_PATCH_MATERIALIZATION_IDLE_NO_CLAIM_PACKETS"
ALREADY_LANDED_NOOP_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_PATCH_MATERIALIZATION_ALREADY_LANDED_NOOP"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_PATCH_MATERIALIZATION_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
BOUNDARY_TEXT = "Research compute claim boundary"
LATEX_BOUNDARY_LABEL = f"\\noindent\\textit{{{BOUNDARY_TEXT}.}}"
LEGACY_LATEX_BOUNDARY_LABEL = f"\\paragraph{{{BOUNDARY_TEXT}.}}"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

SOURCE_LOCATOR_RE = re.compile(r"^(?P<path>[^:]+?)(?::(?P<line>\d+))?$")


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command=""):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _safe_relative_path(path):
    text = str(path or "").strip()
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _source_from_locator(locator):
    text = str(locator or "").strip()
    match = SOURCE_LOCATOR_RE.match(text)
    if not match:
        return {"source_locator": text, "source_path": "", "source_line": 0}
    return {
        "source_locator": text,
        "source_path": match.group("path") or "",
        "source_line": int(match.group("line") or 0),
    }


def _select_claim_packet(claim_draft_report, claim_packet_id="", request_id=""):
    packets = list((claim_draft_report or {}).get("claim_packets") or [])
    if claim_packet_id:
        for packet in packets:
            if str(packet.get("claim_packet_id") or "") == str(claim_packet_id):
                return packet
        return {}
    if request_id:
        for packet in packets:
            if str(packet.get("request_id") or "") == str(request_id):
                return packet
        return {}
    for packet in packets:
        if packet.get("automatic_final_claim_allowed"):
            return packet
    return packets[0] if packets else {}


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "candidate_patch_queue_mutation_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _latex_escape(text):
    replacements = {
        "\\": r"\textbackslash{}",
        "&": r"\&",
        "%": r"\%",
        "$": r"\$",
        "#": r"\#",
        "_": r"\_",
        "{": r"\{",
        "}": r"\}",
        "~": r"\textasciitilde{}",
        "^": r"\textasciicircum{}",
    }
    return "".join(replacements.get(ch, ch) for ch in str(text or ""))


def _claim_kind_label(packet):
    kind = str((packet or {}).get("claim_kind") or "evidence_anchor")
    if kind == "theorem_or_proof":
        return "theorem/proof"
    if kind == "experiment":
        return "experiment"
    return "evidence"


def _selected_risk_class(packet):
    kind = str((packet or {}).get("claim_kind") or "evidence_anchor").replace("_", "-")
    return f"claim-{kind}"


def _claim_boundary_paragraph(packet, markdown=False, evidence_hashes=None):
    claim_text = str((packet or {}).get("claim_text") or "").strip()
    packet_id = str((packet or {}).get("claim_packet_id") or "")
    request_key = str((packet or {}).get("request_key") or (packet or {}).get("request_id") or "")
    kind = _claim_kind_label(packet)
    evidence_hashes = list(evidence_hashes or [])
    evidence_text = ""
    if evidence_hashes:
        names = ", ".join(str(item.get("path") or "") for item in evidence_hashes[:8] if item.get("path"))
        evidence_text = f"The local evidence gate recorded output hashes for {names}.\n"
    if markdown:
        lines = [
            f"### {BOUNDARY_TEXT}\n",
            "\n",
            f"Agent-drafted {kind} claim packet `{packet_id}` records referee request `{request_key}`.\n",
            f"The scoped claim is: {claim_text}\n",
            "The statement remains limited to the listed evidence gate, proof obligations or experiment hashes,\n",
            "local source rollback, and post-apply verification. It is not an external submission,\n",
            "venue decision, acceptance, or claim outside the recorded assumptions and reproducibility boundary.\n",
            "\n",
        ]
        if evidence_text:
            lines.insert(4, evidence_text)
        return lines
    lines = [
        f"{LATEX_BOUNDARY_LABEL}\n",
        f"Agent-drafted {_latex_escape(kind)} claim packet \\texttt{{{_latex_escape(packet_id)}}} records\n",
        f"referee request \\texttt{{{_latex_escape(request_key)}}}. The scoped claim is: {_latex_escape(claim_text)}\n",
        "The statement remains limited to the listed evidence gate, proof obligations or experiment hashes,\n",
        "local source rollback, and post-apply verification. It is not an external submission,\n",
        "venue decision, acceptance, or claim outside the recorded assumptions and reproducibility boundary.\n",
        "\n",
    ]
    if evidence_text:
        lines.insert(3, _latex_escape(evidence_text))
    return lines


def _latex_begin_document_index(lines):
    for idx, line in enumerate(lines or []):
        if "\\begin{document}" in line:
            return idx
    return -1


def _latex_safe_insert_at(lines, insert_at):
    begin_at = _latex_begin_document_index(lines)
    if begin_at >= 0 and insert_at <= begin_at:
        return begin_at + 1
    return insert_at


def _insert_claim_paragraph(source_text, source_line, packet, source_path, evidence_hashes=None):
    old_lines = (source_text or "").splitlines(keepends=True)
    if not old_lines:
        return [], False, "empty_source"
    if BOUNDARY_TEXT in "".join(old_lines):
        markdown = str(source_path or "").endswith(".md")
        paragraph = _claim_boundary_paragraph(packet, markdown=markdown, evidence_hashes=evidence_hashes)
        markers = [f"### {BOUNDARY_TEXT}"] if markdown else [LATEX_BOUNDARY_LABEL, LEGACY_LATEX_BOUNDARY_LABEL]
        start = -1
        for idx, line in enumerate(old_lines):
            if any(marker in line for marker in markers):
                start = idx
                break
        if start < 0:
            return [], False, "claim_boundary_present_but_marker_not_found"
        end = start + 1
        while end < len(old_lines) and old_lines[end].strip():
            end += 1
        while end < len(old_lines) and not old_lines[end].strip():
            end += 1
        if not markdown and start <= _latex_begin_document_index(old_lines):
            without_boundary = old_lines[:start] + old_lines[end:]
            insert_at = _latex_safe_insert_at(without_boundary, start)
            return without_boundary[:insert_at] + paragraph + without_boundary[insert_at:], True, ""
        return old_lines[:start] + paragraph + old_lines[end:], True, ""
    markdown = str(source_path or "").endswith(".md")
    paragraph = _claim_boundary_paragraph(packet, markdown=markdown, evidence_hashes=evidence_hashes)
    if source_line:
        if source_line < 1 or source_line > len(old_lines) + 1:
            return [], False, "source_locator_line_out_of_range"
        insert_at = max(0, source_line - 1)
        if not markdown:
            begin_at = -1
            end_at = -1
            for idx, line in enumerate(old_lines[: min(insert_at + 1, len(old_lines))]):
                if "\\begin{tabular}" in line:
                    begin_at = idx
                    end_at = -1
                if "\\end{tabular}" in line:
                    end_at = idx
            if begin_at >= 0 and end_at < begin_at:
                for idx in range(insert_at, len(old_lines)):
                    if "\\end{tabular}" in old_lines[idx]:
                        insert_at = idx + 1
                        break
                if insert_at < len(old_lines) and "\\end{center}" in old_lines[insert_at]:
                    insert_at += 1
            insert_at = _latex_safe_insert_at(old_lines, insert_at)
    else:
        insert_at = len(old_lines)
        if old_lines and old_lines[-1] and not old_lines[-1].endswith("\n"):
            old_lines[-1] += "\n"
    return old_lines[:insert_at] + paragraph + old_lines[insert_at:], True, ""


def _unified_patch(source_path, old_text, new_lines):
    old_lines = (old_text or "").splitlines(keepends=True)
    path = str(source_path or "")
    diff = "".join(
        difflib.unified_diff(
            old_lines,
            list(new_lines or []),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
        )
    )
    if diff:
        return f"diff --git a/{path} b/{path}\n" + diff
    return ""


def _validate_claim_draft_report(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "claim_draft", item)
    if item.get("command") not in CLAIM_DRAFT_COMMANDS:
        issues.append({"issue": "claim_draft_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_draft_not_pass", "detail": item.get("status") or ""})
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_draft_boundary:{key}"})
    return issues


def _validate_quality_gate_report(report, claim_draft_report, packet):
    if not report:
        return []
    issues = []
    item = report or {}
    _add_report_ref_health_issues(
        issues,
        "claim_quality_gate",
        item,
        "research-compute-claim-quality-gate",
    )
    if item.get("command") != "research-compute-claim-quality-gate":
        issues.append({"issue": "claim_quality_gate_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_quality_gate_not_pass", "detail": item.get("status") or ""})
    if not item.get("claim_quality_gate_ready"):
        issues.append({"issue": "claim_quality_gate_not_ready"})
    if item.get("claim_packet_id") and (packet or {}).get("claim_packet_id"):
        if str(item.get("claim_packet_id") or "") != str((packet or {}).get("claim_packet_id") or ""):
            issues.append(
                {
                    "issue": "claim_quality_gate_packet_mismatch",
                    "expected": (packet or {}).get("claim_packet_id") or "",
                    "observed": item.get("claim_packet_id") or "",
                }
            )
    quality_claim_sha = item.get("claim_draft_report_sha256") or ""
    draft_sha = claim_draft_report.get("report_sha256") or claim_draft_report.get("claim_draft_report_sha256") or ""
    if quality_claim_sha and draft_sha and quality_claim_sha != draft_sha:
        issues.append(
            {
                "issue": "claim_quality_gate_claim_draft_hash_mismatch",
                "expected": draft_sha,
                "observed": quality_claim_sha,
            }
        )
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_quality_gate_boundary:{key}"})
    return issues


def _validate_evidence_execution_report(report, quality_gate_report, packet):
    if not report:
        return []
    issues = []
    item = report or {}
    _add_report_ref_health_issues(
        issues,
        "claim_evidence_execution",
        item,
        "research-compute-claim-evidence-execution",
    )
    if item.get("command") != "research-compute-claim-evidence-execution":
        issues.append({"issue": "claim_evidence_execution_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_evidence_execution_not_pass", "detail": item.get("status") or ""})
    if not item.get("evidence_gate_ready"):
        issues.append({"issue": "claim_evidence_gate_not_ready"})
    if item.get("claim_packet_id") and (packet or {}).get("claim_packet_id"):
        if str(item.get("claim_packet_id") or "") != str((packet or {}).get("claim_packet_id") or ""):
            issues.append(
                {
                    "issue": "claim_evidence_execution_packet_mismatch",
                    "expected": (packet or {}).get("claim_packet_id") or "",
                    "observed": item.get("claim_packet_id") or "",
                }
            )
    evidence_quality_sha = item.get("claim_quality_gate_report_sha256") or ""
    quality_sha = (quality_gate_report or {}).get("report_sha256") or ""
    if evidence_quality_sha and quality_sha and evidence_quality_sha != quality_sha:
        issues.append(
            {
                "issue": "claim_evidence_execution_quality_gate_hash_mismatch",
                "expected": quality_sha,
                "observed": evidence_quality_sha,
            }
        )
    if not item.get("output_hashes"):
        issues.append({"issue": "claim_evidence_output_hashes_required"})
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_evidence_execution_boundary:{key}"})
    return issues


def _validate_evidence_quality_gate_report(report, evidence_execution_report, packet):
    if evidence_execution_report and not report:
        return [{"issue": "claim_evidence_quality_gate_report_required"}]
    if not report:
        return []
    issues = []
    item = report or {}
    _add_report_ref_health_issues(
        issues,
        "claim_evidence_quality_gate",
        item,
        "research-compute-claim-evidence-quality-gate",
    )
    if item.get("command") != "research-compute-claim-evidence-quality-gate":
        issues.append({"issue": "claim_evidence_quality_gate_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_evidence_quality_gate_not_pass", "detail": item.get("status") or ""})
    if not item.get("claim_evidence_quality_gate_ready"):
        issues.append({"issue": "claim_evidence_quality_gate_not_ready"})
    if item.get("claim_packet_id") and (packet or {}).get("claim_packet_id"):
        if str(item.get("claim_packet_id") or "") != str((packet or {}).get("claim_packet_id") or ""):
            issues.append(
                {
                    "issue": "claim_evidence_quality_gate_packet_mismatch",
                    "expected": (packet or {}).get("claim_packet_id") or "",
                    "observed": item.get("claim_packet_id") or "",
                }
            )
    quality_execution_sha = item.get("claim_evidence_execution_report_sha256") or ""
    execution_sha = (evidence_execution_report or {}).get("report_sha256") or ""
    if quality_execution_sha and execution_sha and quality_execution_sha != execution_sha:
        issues.append(
            {
                "issue": "claim_evidence_quality_gate_execution_hash_mismatch",
                "expected": execution_sha,
                "observed": quality_execution_sha,
            }
        )
    if not item.get("output_hashes"):
        issues.append({"issue": "claim_evidence_quality_gate_output_hashes_required"})
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_evidence_quality_gate_boundary:{key}"})
    return issues


def research_compute_claim_manuscript_patch_materialization(
    claim_draft_report,
    source_text,
    source_snapshot=None,
    claim_quality_gate_report=None,
    claim_evidence_execution_report=None,
    claim_evidence_quality_gate_report=None,
    claim_packet_id="",
    request_id="",
    source_target="",
    label="",
):
    claim_draft_report = claim_draft_report or {}
    source_snapshot = source_snapshot or {}
    claim_quality_gate_report = claim_quality_gate_report or {}
    claim_evidence_execution_report = claim_evidence_execution_report or {}
    claim_evidence_quality_gate_report = claim_evidence_quality_gate_report or {}
    source_text = source_text or ""
    issues = _validate_claim_draft_report(claim_draft_report)
    packet = _select_claim_packet(claim_draft_report, claim_packet_id=claim_packet_id, request_id=request_id)
    issues.extend(_validate_quality_gate_report(claim_quality_gate_report, claim_draft_report, packet))
    issues.extend(_validate_evidence_execution_report(claim_evidence_execution_report, claim_quality_gate_report, packet))
    issues.extend(_validate_evidence_quality_gate_report(claim_evidence_quality_gate_report, claim_evidence_execution_report, packet))

    if not packet and not (claim_draft_report.get("claim_packets") or []):
        return {
            "created_at": _created_at(),
            "command": COMMAND,
            "label": label or "",
            "status": "PASS" if not issues else "ATTENTION",
            "claim_manuscript_patch_materialization_state": IDLE_STATE if not issues else ATTENTION_STATE,
            "claim_patch_materialization_created": not issues,
            "slug": "",
            "claim_draft_report_path": claim_draft_report.get("report_path") or "",
            "claim_draft_report_sha256": claim_draft_report.get("report_sha256") or "",
            "claim_quality_gate_report_path": claim_quality_gate_report.get("report_path") or "",
            "claim_quality_gate_report_sha256": claim_quality_gate_report.get("report_sha256") or "",
            "claim_quality_gate_ready": bool(claim_quality_gate_report.get("claim_quality_gate_ready")),
            "claim_evidence_execution_report_path": claim_evidence_execution_report.get("report_path") or "",
            "claim_evidence_execution_report_sha256": claim_evidence_execution_report.get("report_sha256") or "",
            "claim_evidence_execution_ready": bool(claim_evidence_execution_report.get("evidence_gate_ready")),
            "claim_evidence_quality_gate_report_path": claim_evidence_quality_gate_report.get("report_path") or "",
            "claim_evidence_quality_gate_report_sha256": claim_evidence_quality_gate_report.get("report_sha256") or "",
            "claim_evidence_quality_gate_ready": bool(claim_evidence_quality_gate_report.get("claim_evidence_quality_gate_ready")),
            "evidence_gate_ready": bool(claim_evidence_execution_report.get("evidence_gate_ready")),
            "evidence_output_hashes": list((claim_evidence_quality_gate_report or claim_evidence_execution_report).get("output_hashes") or []),
            "claim_packet_selected": False,
            "claim_packet_id": "",
            "selected_request_id": "",
            "selected_request_key": "",
            "selected_risk_class": "",
            "selected_claim_kind": "",
            "selected_source_locator": "",
            "source_target_path": "",
            "source_target_exists": False,
            "source_target_sha256": "",
            "source_target_expected_sha256": "",
            "automatic_final_claim_allowed": False,
            "automatic_source_apply_allowed": False,
            "automatic_merge_allowed": False,
            "automatic_submission_allowed": False,
            "full_agent_autonomy_authorized": bool(claim_draft_report.get("full_agent_autonomy_authorized")),
            "local_execution_request": {},
            "bridge_plan_request": {},
            "patch_draft_generated": False,
            "patch_draft_applied": False,
            "ready_for_manuscript_patch_draft_preflight": False,
            "source_mutation_apply_authorized": False,
            "source_mutation_performed": False,
            "package_mutation_performed": False,
            "archive_mutation_performed": False,
            "provider_model_call_performed": False,
            "external_action_performed": False,
            "patch_queue_merge_performed": False,
            "commit_performed": False,
            "report_write_performed": False,
            "db_mutation_performed": False,
            "summary": {
                "validation_issue_count": len(issues),
                "claim_packet_count": len(claim_draft_report.get("claim_packets") or []),
                "claim_quality_gate_ready_count": 1 if claim_quality_gate_report.get("claim_quality_gate_ready") else 0,
                "claim_evidence_execution_ready_count": 1 if claim_evidence_execution_report.get("evidence_gate_ready") else 0,
                "claim_evidence_quality_gate_ready_count": 1 if claim_evidence_quality_gate_report.get("claim_evidence_quality_gate_ready") else 0,
                "evidence_output_hash_count": len((claim_evidence_quality_gate_report or claim_evidence_execution_report).get("output_hashes") or []),
                "patch_draft_generated_count": 0,
                "source_mutation_count": 0,
                "commit_performed_count": 0,
            },
            "validation_issues": issues,
            "patch_draft": {},
            "selected_claim_packet": {},
            "boundary": [
                "This command materializes manuscript patch drafts from claim packets under logs only.",
                "No claim packets were selected, so no source target was inspected or changed.",
            ],
        }
    if not packet:
        issues.append({"issue": "claim_packet_selection_not_found"})

    locator = _source_from_locator((packet or {}).get("source_locator") or "")
    target_path = str(source_target or locator.get("source_path") or "").strip()
    if not target_path:
        issues.append({"issue": "source_target_required"})
    elif not _safe_relative_path(target_path):
        issues.append({"issue": "unsafe_source_target_path", "detail": target_path})
    if locator.get("source_path") and target_path and locator.get("source_path") != target_path:
        issues.append(
            {
                "issue": "source_target_mismatch",
                "expected": locator.get("source_path") or "",
                "observed": target_path,
            }
        )
    if target_path and not source_snapshot.get("exists"):
        issues.append({"issue": "source_target_missing", "detail": target_path})

    patch_text = ""
    materialized = False
    blocked_reason = ""
    if not issues:
        new_lines, materialized, blocked_reason = _insert_claim_paragraph(
            source_text,
            int(locator.get("source_line") or 0),
            packet,
            target_path,
            evidence_hashes=(claim_evidence_quality_gate_report or claim_evidence_execution_report).get("output_hashes") or [],
        )
        if materialized:
            patch_text = _unified_patch(target_path, source_text, new_lines)
        else:
            issues.append({"issue": "claim_patch_materialization_blocked", "detail": blocked_reason})

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif materialized and not patch_text:
        status = "PASS"
        state = ALREADY_LANDED_NOOP_STATE
        blocked_reason = "patch_text_already_present_in_source"
    else:
        status = "PASS"
        state = READY_STATE
    draft_ready = state == READY_STATE
    if not blocked_reason and state == ATTENTION_STATE:
        blocked_reason = "claim_patch_materialization_requires_attention"
    elif not blocked_reason and state == FORBIDDEN_STATE:
        blocked_reason = "forbidden_boundary_crossed"

    claim_kind = str((packet or {}).get("claim_kind") or "")
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_patch_materialization_state": state,
        "claim_patch_materialization_created": status == "PASS",
        "slug": (packet or {}).get("slug") or "",
        "claim_draft_report_path": claim_draft_report.get("report_path") or "",
        "claim_draft_report_sha256": claim_draft_report.get("report_sha256") or "",
        "claim_quality_gate_report_path": claim_quality_gate_report.get("report_path") or "",
        "claim_quality_gate_report_sha256": claim_quality_gate_report.get("report_sha256") or "",
        "claim_quality_gate_ready": bool(claim_quality_gate_report.get("claim_quality_gate_ready")),
        "claim_evidence_execution_report_path": claim_evidence_execution_report.get("report_path") or "",
        "claim_evidence_execution_report_sha256": claim_evidence_execution_report.get("report_sha256") or "",
        "claim_evidence_execution_ready": bool(claim_evidence_execution_report.get("evidence_gate_ready")),
        "claim_evidence_quality_gate_report_path": claim_evidence_quality_gate_report.get("report_path") or "",
        "claim_evidence_quality_gate_report_sha256": claim_evidence_quality_gate_report.get("report_sha256") or "",
        "claim_evidence_quality_gate_ready": bool(claim_evidence_quality_gate_report.get("claim_evidence_quality_gate_ready")),
        "evidence_gate_ready": bool(claim_evidence_execution_report.get("evidence_gate_ready")),
        "evidence_output_hashes": list((claim_evidence_quality_gate_report or claim_evidence_execution_report).get("output_hashes") or []),
        "claim_packet_selected": bool(packet),
        "claim_packet_id": (packet or {}).get("claim_packet_id") or "",
        "selected_request_id": str((packet or {}).get("request_id") or ""),
        "selected_request_key": str((packet or {}).get("request_key") or ""),
        "selected_risk_class": _selected_risk_class(packet) if packet else "",
        "selected_claim_kind": claim_kind,
        "selected_source_locator": (packet or {}).get("source_locator") or "",
        "source_target_path": target_path,
        "source_target_exists": bool(source_snapshot.get("exists")),
        "source_target_sha256": source_snapshot.get("sha256") or "",
        "source_target_expected_sha256": source_snapshot.get("sha256") or "",
        "automatic_final_claim_allowed": bool((packet or {}).get("automatic_final_claim_allowed")),
        "automatic_source_apply_allowed": bool((packet or {}).get("automatic_source_apply_allowed")),
        "automatic_merge_allowed": bool((packet or {}).get("automatic_merge_allowed")),
        "automatic_submission_allowed": bool((packet or {}).get("automatic_submission_allowed")),
        "full_agent_autonomy_authorized": bool((packet or {}).get("full_agent_autonomy_authorized")),
        "local_execution_request": (packet or {}).get("local_execution_request") or {},
        "bridge_plan_request": (packet or {}).get("bridge_plan_request") or {},
        "patch_draft_generated": draft_ready,
        "patch_draft_applied": False,
        "ready_for_manuscript_patch_draft_preflight": draft_ready,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "claim_packet_count": len(claim_draft_report.get("claim_packets") or []),
            "claim_quality_gate_ready_count": 1 if claim_quality_gate_report.get("claim_quality_gate_ready") else 0,
            "claim_evidence_execution_ready_count": 1 if claim_evidence_execution_report.get("evidence_gate_ready") else 0,
            "claim_evidence_quality_gate_ready_count": 1 if claim_evidence_quality_gate_report.get("claim_evidence_quality_gate_ready") else 0,
            "evidence_output_hash_count": len((claim_evidence_quality_gate_report or claim_evidence_execution_report).get("output_hashes") or []),
            "patch_draft_generated_count": 1 if draft_ready else 0,
            "automatic_final_claim_allowed_count": 1 if (packet or {}).get("automatic_final_claim_allowed") else 0,
            "automatic_source_apply_allowed_count": 1 if (packet or {}).get("automatic_source_apply_allowed") else 0,
            "automatic_merge_allowed_count": 1 if (packet or {}).get("automatic_merge_allowed") else 0,
            "automatic_submission_allowed_count": 1 if (packet or {}).get("automatic_submission_allowed") else 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "patch_draft": {
            "target_path": target_path,
            "patch_text": patch_text,
            "boundary_text": BOUNDARY_TEXT,
            "patch_scope": "claim_packet_manuscript_boundary",
            "apply_allowed": False,
            "enqueue_allowed": False,
            "source_mutation_allowed": False,
            "source_preflight_required_before_apply": True,
            "blocked_reason": blocked_reason,
        },
        "selected_claim_packet": packet or {},
        "boundary": [
            "This command materializes a local unified-diff manuscript patch draft from one claim packet.",
            "It does not apply the patch, mutate source/package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "A manuscript patch draft preflight and explicit source apply gate are required before any manuscript source file can be changed.",
        ],
    }


def research_compute_claim_manuscript_patch_materialization_markdown(report):
    patch = report.get("patch_draft") or {}
    lines = [
        "# paper_factory Claim Manuscript Patch Materialization",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_patch_materialization_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Request: `{report.get('selected_request_id') or ''}` `{report.get('selected_risk_class') or ''}`",
        f"- Claim quality gate ready: {report.get('claim_quality_gate_ready')}",
        f"- Claim evidence execution ready: {report.get('claim_evidence_execution_ready')}",
        f"- Claim evidence quality gate ready: {report.get('claim_evidence_quality_gate_ready')}",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Patch draft generated: {report.get('patch_draft_generated')}",
        f"- Ready for preflight: {report.get('ready_for_manuscript_patch_draft_preflight')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Patch Draft", ""])
    lines.append(f"- Target: `{patch.get('target_path') or ''}`")
    lines.append(f"- Boundary text: `{patch.get('boundary_text') or ''}`")
    lines.append(f"- Apply allowed: {patch.get('apply_allowed')}")
    lines.append(f"- Source preflight required before apply: {patch.get('source_preflight_required_before_apply')}")
    lines.append(f"- Blocked reason: `{patch.get('blocked_reason') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
