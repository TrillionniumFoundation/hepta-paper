"""Execute a claim-derived manuscript source apply through existing gates."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-source-apply-execution"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_manuscript_source_apply_execution_state",
    "report_schema",
    "source_apply_execution_created",
    "slug",
    "readiness_report_path",
    "readiness_report_sha256",
    "claim_packet_id",
    "selected_request_id",
    "selected_risk_class",
    "source_target_path",
    "source_before_sha256",
    "source_after_sha256",
    "patch_file_path",
    "patch_file_sha256",
    "preflight_sidecar_path",
    "preflight_sidecar_sha256",
    "source_apply_dry_run_packet_path",
    "source_apply_dry_run_packet_sha256",
    "apply_report_path",
    "apply_report_sha256",
    "post_apply_verify_report_path",
    "post_apply_verify_report_sha256",
    "rollback_snapshot_path",
    "rollback_snapshot_sha256",
    "apply_requested",
    "write_requested",
    "source_mutation_apply_authorized",
    "source_mutation_performed",
    "post_apply_verify_performed",
    "ready_for_next_material_packet_refresh",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "report_write_performed",
    "db_mutation_performed",
    "summary",
    "validation_issues",
    "readiness_report",
    "apply_report",
    "post_apply_verify_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "readiness_validation_issue_count",
    "apply_validation_issue_count",
    "post_apply_validation_issue_count",
    "source_mutation_count",
    "post_apply_verify_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Executes claim-derived manuscript source apply through existing apply and post-apply verification gates.",
    "This command never commits, merges, mutates packages/archives, calls providers/models, uploads, emails, or submits.",
]
READINESS_COMMAND = "research-compute-claim-manuscript-source-apply-readiness"
APPLY_COMMAND = "research-compute-manuscript-source-apply-gate"
POST_APPLY_COMMAND = "research-compute-manuscript-source-post-apply-verify"

IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_IDLE_NO_PATCH_DRAFT"
READY_NOT_EXECUTED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_READY_NOT_EXECUTED"
APPLIED_VERIFIED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_APPLIED_AND_VERIFIED"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

READINESS_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_READINESS_IDLE_NO_PATCH_DRAFT"
READINESS_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_READINESS_READY_DRY_RUN_NOT_APPLIED"
APPLY_APPLIED_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_APPLIED"
POST_APPLY_VERIFIED_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_POST_APPLY_VERIFY_VERIFIED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _forbidden_readiness_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _forbidden_apply_keys():
    return [
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _validate_readiness(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "readiness", item, READINESS_COMMAND)
    if item.get("command") != READINESS_COMMAND:
        issues.append({"issue": "readiness_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "readiness_not_pass", "detail": item.get("status") or ""})
    for key in _forbidden_readiness_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_readiness_boundary:{key}"})
    state = item.get("claim_manuscript_source_apply_readiness_state") or ""
    if state not in {READINESS_IDLE_STATE, READINESS_READY_STATE}:
        issues.append({"issue": "readiness_state_not_consumable", "detail": state})
    if state == READINESS_READY_STATE:
        if not item.get("source_apply_dry_run_ready"):
            issues.append({"issue": "readiness_source_apply_dry_run_not_ready"})
        if not item.get("preflight_sidecar_path"):
            issues.append({"issue": "preflight_sidecar_missing"})
        if not item.get("source_apply_dry_run_packet_path"):
            issues.append({"issue": "source_apply_dry_run_packet_sidecar_missing"})
    return issues


def _validate_apply_report(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "apply_report", item, APPLY_COMMAND)
    if item.get("command") != APPLY_COMMAND:
        issues.append({"issue": "apply_report_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "apply_report_not_pass", "detail": item.get("status") or ""})
    if item.get("manuscript_source_apply_gate_state") != APPLY_APPLIED_STATE:
        issues.append({"issue": "apply_report_not_applied", "detail": item.get("manuscript_source_apply_gate_state") or ""})
    if not item.get("source_mutation_performed"):
        issues.append({"issue": "apply_report_source_mutation_not_recorded"})
    if not item.get("ready_for_manuscript_source_post_apply_verify"):
        issues.append({"issue": "apply_report_not_ready_for_post_apply_verify"})
    for key in _forbidden_apply_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_apply_boundary:{key}"})
    return issues


def _validate_post_apply_report(report, apply_report):
    issues = []
    item = report or {}
    apply_item = apply_report or {}
    _add_report_ref_health_issues(issues, "post_apply_report", item, POST_APPLY_COMMAND)
    if item.get("command") != POST_APPLY_COMMAND:
        issues.append({"issue": "post_apply_report_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "post_apply_report_not_pass", "detail": item.get("status") or ""})
    if item.get("manuscript_source_post_apply_verify_state") != POST_APPLY_VERIFIED_STATE:
        issues.append({"issue": "post_apply_report_not_verified", "detail": item.get("manuscript_source_post_apply_verify_state") or ""})
    if not item.get("ready_for_next_material_packet_refresh"):
        issues.append({"issue": "post_apply_not_ready_for_material_packet_refresh"})
    if item.get("source_after_sha256") != apply_item.get("source_after_sha256"):
        issues.append(
            {
                "issue": "post_apply_source_after_sha256_mismatch",
                "expected": apply_item.get("source_after_sha256") or "",
                "observed": item.get("source_after_sha256") or "",
            }
        )
    for key in _forbidden_apply_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_post_apply_boundary:{key}"})
    return issues


def research_compute_claim_manuscript_source_apply_execution(
    readiness_report,
    apply_report=None,
    post_apply_verify_report=None,
    apply_requested=False,
    write_requested=False,
    label="",
):
    readiness_report = readiness_report or {}
    apply_report = apply_report or {}
    post_apply_verify_report = post_apply_verify_report or {}
    readiness_issues = _validate_readiness(readiness_report)
    state = readiness_report.get("claim_manuscript_source_apply_readiness_state") or ""
    idle = state == READINESS_IDLE_STATE and not readiness_issues
    ready = state == READINESS_READY_STATE and not readiness_issues

    execution_issues = []
    if apply_requested and not write_requested:
        execution_issues.append({"issue": "apply_requires_write_report"})

    apply_issues = []
    post_apply_issues = []
    source_mutation_performed = False
    post_apply_verified = False
    if ready and apply_requested and write_requested and not execution_issues:
        apply_issues = _validate_apply_report(apply_report)
        if not apply_issues:
            post_apply_issues = _validate_post_apply_report(post_apply_verify_report, apply_report)
        source_mutation_performed = not apply_issues and bool(apply_report.get("source_mutation_performed"))
        post_apply_verified = source_mutation_performed and not post_apply_issues

    all_issues = readiness_issues + execution_issues + apply_issues + post_apply_issues
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in all_issues)

    if forbidden:
        status = "FAIL"
        final_state = FORBIDDEN_STATE
    elif idle:
        status = "PASS"
        final_state = IDLE_STATE
    elif ready and not apply_requested and not all_issues:
        status = "PASS"
        final_state = READY_NOT_EXECUTED_STATE
    elif ready and apply_requested and write_requested and post_apply_verified and not all_issues:
        status = "PASS"
        final_state = APPLIED_VERIFIED_STATE
    else:
        status = "ATTENTION"
        final_state = ATTENTION_STATE

    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_source_apply_execution_state": final_state,
        "source_apply_execution_created": status == "PASS",
        "slug": readiness_report.get("slug") or "",
        "readiness_report_path": readiness_report.get("report_path") or "",
        "readiness_report_sha256": readiness_report.get("report_sha256") or "",
        "claim_packet_id": readiness_report.get("claim_packet_id") or "",
        "selected_request_id": readiness_report.get("selected_request_id") or "",
        "selected_risk_class": readiness_report.get("selected_risk_class") or "",
        "source_target_path": readiness_report.get("source_target_path") or "",
        "source_before_sha256": apply_report.get("source_before_sha256") or readiness_report.get("source_target_sha256") or "",
        "source_after_sha256": apply_report.get("source_after_sha256") or "",
        "patch_file_path": readiness_report.get("patch_file_path") or "",
        "patch_file_sha256": readiness_report.get("patch_file_sha256") or "",
        "preflight_sidecar_path": readiness_report.get("preflight_sidecar_path") or "",
        "preflight_sidecar_sha256": readiness_report.get("preflight_sidecar_sha256") or "",
        "source_apply_dry_run_packet_path": readiness_report.get("source_apply_dry_run_packet_path") or "",
        "source_apply_dry_run_packet_sha256": readiness_report.get("source_apply_dry_run_packet_sha256") or "",
        "apply_report_path": apply_report.get("report_path") or "",
        "apply_report_sha256": apply_report.get("report_sha256") or "",
        "post_apply_verify_report_path": post_apply_verify_report.get("report_path") or "",
        "post_apply_verify_report_sha256": post_apply_verify_report.get("report_sha256") or "",
        "rollback_snapshot_path": apply_report.get("rollback_snapshot_path") or "",
        "rollback_snapshot_sha256": apply_report.get("rollback_snapshot_sha256") or "",
        "apply_requested": bool(apply_requested),
        "write_requested": bool(write_requested),
        "source_mutation_apply_authorized": bool(ready and apply_requested and write_requested and not readiness_issues and not execution_issues),
        "source_mutation_performed": bool(source_mutation_performed),
        "post_apply_verify_performed": bool(post_apply_verified),
        "ready_for_next_material_packet_refresh": bool(post_apply_verify_report.get("ready_for_next_material_packet_refresh")),
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(all_issues),
            "readiness_validation_issue_count": len(readiness_issues),
            "apply_validation_issue_count": len(apply_issues),
            "post_apply_validation_issue_count": len(post_apply_issues),
            "source_mutation_count": 1 if source_mutation_performed else 0,
            "post_apply_verify_count": 1 if post_apply_verified else 0,
            "commit_performed_count": 0,
        },
        "validation_issues": all_issues,
        "readiness_report": readiness_report,
        "apply_report": apply_report,
        "post_apply_verify_report": post_apply_verify_report,
        "boundary": [
            "This command executes claim-derived manuscript source apply only through the existing source apply gate and post-apply verify gate.",
            "It may mutate one preflighted manuscript source file only when readiness is PASS and --apply --write are both present.",
            "It records rollback/hash/post-apply evidence and does not mutate package/archive state, call providers/models, perform external actions, merge/dequeue/supersede queue rows, or commit.",
        ],
    }


def research_compute_claim_manuscript_source_apply_execution_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript Source Apply Execution",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_source_apply_execution_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source before SHA256: `{report.get('source_before_sha256') or ''}`",
        f"- Source after SHA256: `{report.get('source_after_sha256') or ''}`",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Post-apply verify performed: {report.get('post_apply_verify_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
