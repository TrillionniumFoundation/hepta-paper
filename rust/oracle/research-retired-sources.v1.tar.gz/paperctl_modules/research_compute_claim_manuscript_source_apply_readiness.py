"""Build source-apply readiness from a claim manuscript patch draft.

This wrapper consumes a claim-manuscript materialization report, runs the same
preflight semantics as the normal manuscript patch gate, and produces a dry-run
source-apply packet. It never applies the patch or mutates source.
"""

import datetime as dt

from paperctl_modules import research_compute_manuscript_patch_draft_preflight
from paperctl_modules import research_compute_manuscript_source_apply_gate
from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-source-apply-readiness"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_manuscript_source_apply_readiness_state",
    "report_schema",
    "source_apply_readiness_created",
    "slug",
    "materialization_report_path",
    "materialization_report_sha256",
    "claim_materialization_report_path",
    "claim_materialization_report_sha256",
    "claim_packet_id",
    "selected_request_id",
    "selected_risk_class",
    "source_target_path",
    "source_target_sha256",
    "patch_file_path",
    "patch_file_sha256",
    "patch_draft_generated",
    "preflight_ready",
    "source_apply_dry_run_ready",
    "ready_for_explicit_source_apply_gate",
    "preflight_sidecar_path",
    "preflight_sidecar_sha256",
    "source_apply_dry_run_packet_path",
    "source_apply_dry_run_packet_sha256",
    "source_mutation_apply_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "report_write_performed",
    "db_mutation_performed",
    "summary",
    "validation_issues",
    "preflight_report",
    "source_apply_dry_run_packet",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "preflight_validation_issue_count",
    "source_apply_validation_issue_count",
    "git_apply_check_passed_count",
    "source_apply_dry_run_ready_count",
    "source_mutation_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Runs claim manuscript patch preflight and source-apply dry-run readiness.",
    "This command writes only local report/event evidence and does not apply patches, mutate source/package/archive state, call providers/models, merge, commit, upload, email, or submit.",
]
CLAIM_MATERIALIZATION_COMMAND = "research-compute-claim-manuscript-patch-materialization"
READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_READINESS_READY_DRY_RUN_NOT_APPLIED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_READINESS_IDLE_NO_PATCH_DRAFT"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_READINESS_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _validate_materialization_report(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "claim_materialization", item, CLAIM_MATERIALIZATION_COMMAND)
    if item.get("command") != CLAIM_MATERIALIZATION_COMMAND:
        issues.append({"issue": "claim_materialization_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_materialization_not_pass", "detail": item.get("status") or ""})
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_materialization_boundary:{key}"})
    return issues


def research_compute_claim_manuscript_source_apply_readiness(
    materialization_report,
    patch_snapshot,
    source_snapshot,
    git_apply_check,
    patch_text,
    source_text,
    label="",
):
    materialization_report = materialization_report or {}
    patch_snapshot = patch_snapshot or {}
    source_snapshot = source_snapshot or {}
    git_apply_check = git_apply_check or {}
    patch_text = patch_text or ""
    source_text = source_text or ""

    validation_issues = _validate_materialization_report(materialization_report)
    if materialization_report.get("status") == "PASS" and not materialization_report.get("patch_draft_generated"):
        status = "PASS" if not validation_issues else "ATTENTION"
        state = IDLE_STATE if not validation_issues else ATTENTION_STATE
        return {
            "created_at": _created_at(),
            "command": COMMAND,
            "label": label or "",
            "status": status,
            "claim_manuscript_source_apply_readiness_state": state,
            "source_apply_readiness_created": status == "PASS",
            "slug": materialization_report.get("slug") or "",
            "claim_materialization_report_path": materialization_report.get("report_path") or "",
            "claim_materialization_report_sha256": materialization_report.get("report_sha256") or "",
            "claim_packet_id": materialization_report.get("claim_packet_id") or "",
            "selected_request_id": materialization_report.get("selected_request_id") or "",
            "selected_risk_class": materialization_report.get("selected_risk_class") or "",
            "source_target_path": materialization_report.get("source_target_path") or "",
            "source_target_sha256": source_snapshot.get("sha256") or "",
            "patch_file_path": patch_snapshot.get("path") or "",
            "patch_file_sha256": patch_snapshot.get("sha256") or "",
            "patch_draft_generated": False,
            "preflight_ready": False,
            "source_apply_dry_run_ready": False,
            "ready_for_explicit_source_apply_gate": False,
            "preflight_sidecar_path": "",
            "preflight_sidecar_sha256": "",
            "source_apply_dry_run_packet_path": "",
            "source_apply_dry_run_packet_sha256": "",
            "source_mutation_apply_authorized": False,
            "source_mutation_performed": False,
            "package_mutation_performed": False,
            "archive_mutation_performed": False,
            "provider_model_call_performed": False,
            "external_action_performed": False,
            "patch_queue_merge_performed": False,
            "commit_performed": False,
            "report_write_performed": False,
            "db_mutation_performed": False,
            "summary": {
                "validation_issue_count": len(validation_issues),
                "preflight_validation_issue_count": 0,
                "source_apply_validation_issue_count": 0,
                "git_apply_check_passed_count": 0,
                "source_apply_dry_run_ready_count": 0,
                "source_mutation_count": 0,
                "commit_performed_count": 0,
            },
            "validation_issues": validation_issues,
            "preflight_report": {},
            "source_apply_dry_run_packet": {},
            "boundary": [
                "This command creates source-apply readiness evidence from claim manuscript patch drafts.",
                "No patch draft was present, so no preflight or source apply dry-run was performed.",
            ],
        }

    preflight_report = {}
    apply_packet = {}
    if not validation_issues:
        preflight_report = research_compute_manuscript_patch_draft_preflight.research_compute_manuscript_patch_draft_preflight(
            materialization_report,
            patch_snapshot,
            source_snapshot,
            git_apply_check,
            patch_text,
            source_text,
            label=label or "",
        )
        if preflight_report.get("status") == "PASS":
            apply_packet = research_compute_manuscript_source_apply_gate.research_compute_manuscript_source_apply_gate(
                preflight_report,
                patch_snapshot,
                source_snapshot,
                patch_text,
                apply_requested=False,
                write_requested=False,
                apply_result={},
                label=label or "",
            )

    preflight_issues = list((preflight_report.get("validation_issues") if preflight_report else []) or [])
    apply_issues = list((apply_packet.get("validation_issues") if apply_packet else []) or [])
    all_issues = validation_issues + preflight_issues + apply_issues
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in all_issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif all_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif apply_packet.get("status") == "PASS" and apply_packet.get("manuscript_source_apply_gate_state") == "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_READY_DRY_RUN_NOT_APPLIED":
        status = "PASS"
        state = READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE

    ready = state == READY_STATE
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_source_apply_readiness_state": state,
        "source_apply_readiness_created": status == "PASS",
        "slug": materialization_report.get("slug") or "",
        "claim_materialization_report_path": materialization_report.get("report_path") or "",
        "claim_materialization_report_sha256": materialization_report.get("report_sha256") or "",
        "claim_packet_id": materialization_report.get("claim_packet_id") or "",
        "selected_request_id": materialization_report.get("selected_request_id") or "",
        "selected_risk_class": materialization_report.get("selected_risk_class") or "",
        "source_target_path": materialization_report.get("source_target_path") or "",
        "source_target_sha256": source_snapshot.get("sha256") or "",
        "patch_file_path": patch_snapshot.get("path") or "",
        "patch_file_sha256": patch_snapshot.get("sha256") or "",
        "patch_draft_generated": bool(materialization_report.get("patch_draft_generated")),
        "preflight_ready": bool(preflight_report.get("ready_for_manuscript_source_apply_gate")),
        "source_apply_dry_run_ready": bool(ready),
        "ready_for_explicit_source_apply_gate": bool(ready),
        "preflight_sidecar_path": "",
        "preflight_sidecar_sha256": "",
        "source_apply_dry_run_packet_path": "",
        "source_apply_dry_run_packet_sha256": "",
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(all_issues),
            "preflight_validation_issue_count": len(preflight_issues),
            "source_apply_validation_issue_count": len(apply_issues),
            "git_apply_check_passed_count": 1 if preflight_report.get("git_apply_check_passed") else 0,
            "source_apply_dry_run_ready_count": 1 if ready else 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": all_issues,
        "preflight_report": preflight_report,
        "source_apply_dry_run_packet": apply_packet,
        "boundary": [
            "This command runs claim manuscript patch preflight and source-apply dry-run readiness only.",
            "It does not apply the patch, mutate source/package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "The existing explicit source apply gate must be invoked separately to perform any source mutation with rollback and post-apply verification.",
        ],
    }


def research_compute_claim_manuscript_source_apply_readiness_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript Source Apply Readiness",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_source_apply_readiness_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Patch file: `{report.get('patch_file_path') or ''}`",
        f"- Preflight ready: {report.get('preflight_ready')}",
        f"- Source apply dry-run ready: {report.get('source_apply_dry_run_ready')}",
        f"- Preflight sidecar: `{report.get('preflight_sidecar_path') or ''}`",
        f"- Source apply dry-run sidecar: `{report.get('source_apply_dry_run_packet_path') or ''}`",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
