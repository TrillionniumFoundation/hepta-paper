"""Finalize claim-derived manuscript source landing evidence for later gates."""

import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-manuscript-source-landing-finalization"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "claim_manuscript_source_landing_finalization_state",
    "report_schema",
    "claim_source_landing_finalized",
    "slug",
    "execution_report_path",
    "execution_report_sha256",
    "claim_packet_id",
    "selected_request_id",
    "selected_risk_class",
    "source_target_path",
    "source_before_sha256",
    "source_after_sha256",
    "patch_file_path",
    "patch_file_sha256",
    "apply_report_path",
    "apply_report_sha256",
    "post_apply_verify_report_path",
    "post_apply_verify_report_sha256",
    "rollback_snapshot_path",
    "rollback_snapshot_sha256",
    "observed_source_mutation_performed",
    "post_apply_verify_performed",
    "ready_for_post_apply_material_refresh",
    "ready_for_claim_merge_readiness",
    "ready_for_claim_submission_readiness",
    "agent_merge_decision_ready",
    "agent_submission_decision_ready",
    "source_mutation_performed",
    "source_mutation_performed_by_this_command",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "report_write_performed",
    "db_mutation_performed",
    "summary",
    "validation_issues",
    "execution_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "claim_source_landing_finalized_count",
    "observed_source_mutation_count",
    "post_apply_verify_count",
    "ready_for_post_apply_material_refresh_count",
    "ready_for_claim_merge_readiness_count",
    "ready_for_claim_submission_readiness_count",
    "source_mutation_by_this_command_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Finalizes local claim source landing evidence after source apply execution and post-apply verification.",
    "This command is report-only: it performs no source/package/archive mutation, merge, commit, provider/model call, upload, email, or submit.",
]
EXECUTION_COMMAND = "research-compute-claim-manuscript-source-apply-execution"

FINALIZED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_FINALIZED"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_IDLE_NO_PATCH_DRAFT"
READY_NOT_EXECUTED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_READY_NOT_EXECUTED"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_LANDING_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

EXECUTION_IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_IDLE_NO_PATCH_DRAFT"
EXECUTION_READY_NOT_EXECUTED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_READY_NOT_EXECUTED"
EXECUTION_APPLIED_VERIFIED_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_SOURCE_APPLY_EXECUTION_APPLIED_AND_VERIFIED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report, expected_command):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command=expected_command,
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _forbidden_execution_keys():
    return [
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _validate_execution_report(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "execution", item, EXECUTION_COMMAND)
    if item.get("command") != EXECUTION_COMMAND:
        issues.append({"issue": "execution_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "execution_not_pass", "detail": item.get("status") or ""})
    for key in _forbidden_execution_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_execution_boundary:{key}"})
    state = item.get("claim_manuscript_source_apply_execution_state") or ""
    if state not in {EXECUTION_IDLE_STATE, EXECUTION_READY_NOT_EXECUTED_STATE, EXECUTION_APPLIED_VERIFIED_STATE}:
        issues.append({"issue": "execution_state_not_consumable", "detail": state})
    if state == EXECUTION_APPLIED_VERIFIED_STATE:
        if not item.get("source_mutation_performed"):
            issues.append({"issue": "execution_source_mutation_not_recorded"})
        if not item.get("post_apply_verify_performed"):
            issues.append({"issue": "execution_post_apply_verify_not_recorded"})
        if not item.get("ready_for_next_material_packet_refresh"):
            issues.append({"issue": "execution_not_ready_for_material_packet_refresh"})
        if not item.get("apply_report_path"):
            issues.append({"issue": "apply_report_path_missing"})
        if not item.get("post_apply_verify_report_path"):
            issues.append({"issue": "post_apply_verify_report_path_missing"})
        if not item.get("rollback_snapshot_path"):
            issues.append({"issue": "rollback_snapshot_path_missing"})
        before_sha = item.get("source_before_sha256") or ""
        after_sha = item.get("source_after_sha256") or ""
        if before_sha and after_sha and before_sha == after_sha:
            issues.append({"issue": "source_sha256_unchanged_after_execution"})
        if not after_sha:
            issues.append({"issue": "source_after_sha256_missing"})
    return issues


def research_compute_claim_manuscript_source_landing_finalization(execution_report, label=""):
    execution_report = execution_report or {}
    issues = _validate_execution_report(execution_report)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    execution_state = execution_report.get("claim_manuscript_source_apply_execution_state") or ""

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif execution_state == EXECUTION_IDLE_STATE:
        status = "PASS"
        state = IDLE_STATE
    elif execution_state == EXECUTION_READY_NOT_EXECUTED_STATE:
        status = "PASS"
        state = READY_NOT_EXECUTED_STATE
    else:
        status = "PASS"
        state = FINALIZED_STATE

    finalized = state == FINALIZED_STATE
    observed_source_mutation = bool(finalized and execution_report.get("source_mutation_performed"))
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_manuscript_source_landing_finalization_state": state,
        "claim_source_landing_finalized": finalized,
        "slug": execution_report.get("slug") or "",
        "execution_report_path": execution_report.get("report_path") or "",
        "execution_report_sha256": execution_report.get("report_sha256") or "",
        "claim_packet_id": execution_report.get("claim_packet_id") or "",
        "selected_request_id": execution_report.get("selected_request_id") or "",
        "selected_risk_class": execution_report.get("selected_risk_class") or "",
        "source_target_path": execution_report.get("source_target_path") or "",
        "source_before_sha256": execution_report.get("source_before_sha256") or "",
        "source_after_sha256": execution_report.get("source_after_sha256") or "",
        "patch_file_path": execution_report.get("patch_file_path") or "",
        "patch_file_sha256": execution_report.get("patch_file_sha256") or "",
        "apply_report_path": execution_report.get("apply_report_path") or "",
        "apply_report_sha256": execution_report.get("apply_report_sha256") or "",
        "post_apply_verify_report_path": execution_report.get("post_apply_verify_report_path") or "",
        "post_apply_verify_report_sha256": execution_report.get("post_apply_verify_report_sha256") or "",
        "rollback_snapshot_path": execution_report.get("rollback_snapshot_path") or "",
        "rollback_snapshot_sha256": execution_report.get("rollback_snapshot_sha256") or "",
        "observed_source_mutation_performed": observed_source_mutation,
        "post_apply_verify_performed": bool(finalized and execution_report.get("post_apply_verify_performed")),
        "ready_for_post_apply_material_refresh": finalized,
        "ready_for_claim_merge_readiness": finalized,
        "ready_for_claim_submission_readiness": finalized,
        "agent_merge_decision_ready": finalized,
        "agent_submission_decision_ready": finalized,
        "source_mutation_performed": False,
        "source_mutation_performed_by_this_command": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "claim_source_landing_finalized_count": 1 if finalized else 0,
            "observed_source_mutation_count": 1 if observed_source_mutation else 0,
            "post_apply_verify_count": 1 if finalized else 0,
            "ready_for_post_apply_material_refresh_count": 1 if finalized else 0,
            "ready_for_claim_merge_readiness_count": 1 if finalized else 0,
            "ready_for_claim_submission_readiness_count": 1 if finalized else 0,
            "source_mutation_by_this_command_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "execution_report": execution_report,
        "boundary": [
            "This command finalizes local evidence from a prior claim source-apply execution report.",
            "It does not apply patches or mutate source/package/archive state itself; source mutation, when present, must already be recorded by the execution report and post-apply verification.",
            "It does not enqueue or merge patch queues, commit, call providers/models, upload, email, or submit externally.",
        ],
    }


def research_compute_claim_manuscript_source_landing_finalization_markdown(report):
    lines = [
        "# paper_factory Claim Manuscript Source Landing Finalization",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_manuscript_source_landing_finalization_state') or ''}",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source after SHA256: `{report.get('source_after_sha256') or ''}`",
        f"- Claim source landing finalized: {report.get('claim_source_landing_finalized')}",
        f"- Ready for claim merge readiness: {report.get('ready_for_claim_merge_readiness')}",
        f"- Ready for claim submission readiness: {report.get('ready_for_claim_submission_readiness')}",
        f"- Source mutation by this command: {report.get('source_mutation_performed_by_this_command')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
