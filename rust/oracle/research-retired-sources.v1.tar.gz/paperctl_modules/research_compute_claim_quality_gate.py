"""Machine-audit quality gates for theorem/proof/experiment claim packets.

This layer checks whether an agent-drafted claim packet is specific enough to
feed manuscript materialization. It remains report-only: no compute execution,
source mutation, queue mutation, provider call, or external action is performed.
"""


import datetime as dt

from paperctl_modules import report_ref_health


COMMAND = "research-compute-claim-quality-gate"
CLAIM_DRAFT_COMMAND = "research-compute-claim-draft"
CLAIM_DRAFT_COMMANDS = {
    CLAIM_DRAFT_COMMAND,
    "research-compute-claim-boundary-reentry-draft",
}
READY_STATE = "RESEARCH_COMPUTE_CLAIM_QUALITY_GATE_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_CLAIM_QUALITY_GATE_ATTENTION"
IDLE_STATE = "RESEARCH_COMPUTE_CLAIM_QUALITY_GATE_IDLE_NO_CLAIM_PACKETS"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"
INPUT_REPORT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN


GENERIC_CLAIM_PHRASES = [
    "a scoped theorem, lemma, or proof repair may be finalized",
    "a reproducible local experiment result may be reported",
    "candidate text may reference only local evidence",
    "only after the listed proof obligations are discharged",
]

THEOREM_SPECIFICITY_TOKENS = [
    "theorem",
    "lemma",
    "proposition",
    "assumption",
    "bound",
    "rate",
    "convergen",
    "consistent",
    "identif",
    "asymptotic",
    "\\",
    "$",
]


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "candidate_patch_queue_mutation_performed",
        "patch_queue_merge_performed",
        "commit_performed",
        "secret_material_read_performed",
    ]


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _add_report_ref_health_issues(issues, name, report):
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        name,
        report,
        expected_command="",
        max_age_min=INPUT_REPORT_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)


def _select_claim_packet(claim_draft_report, claim_packet_id="", request_id=""):
    packets = list((claim_draft_report or {}).get("claim_packets") or [])
    if claim_packet_id:
        for packet in packets:
            if str(packet.get("claim_packet_id") or "") == str(claim_packet_id):
                return packet
        return {}
    if request_id:
        for packet in packets:
            if str(packet.get("request_id") or "") == str(request_id):
                return packet
        return {}
    for packet in packets:
        if packet.get("automatic_final_claim_allowed"):
            return packet
    return packets[0] if packets else {}


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _validate_claim_draft_report(report):
    issues = []
    item = report or {}
    _add_report_ref_health_issues(issues, "claim_draft", item)
    if item.get("command") not in CLAIM_DRAFT_COMMANDS:
        issues.append({"issue": "claim_draft_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "claim_draft_not_pass", "detail": item.get("status") or ""})
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_claim_draft_boundary:{key}"})
    return issues


def _generic_claim_issue(claim_text):
    lowered = str(claim_text or "").lower()
    return any(phrase in lowered for phrase in GENERIC_CLAIM_PHRASES)


def _claim_specificity_ready(packet):
    claim_text = str((packet or {}).get("claim_text") or "").strip()
    if not claim_text:
        return False, "claim_text_missing"
    if _generic_claim_issue(claim_text):
        return False, "claim_text_too_generic"
    kind = str((packet or {}).get("claim_kind") or "")
    lowered = claim_text.lower()
    if kind == "theorem_or_proof" and not any(token in lowered for token in THEOREM_SPECIFICITY_TOKENS):
        return False, "theorem_or_proof_claim_lacks_specificity_token"
    if kind == "experiment":
        spec = packet.get("experiment_spec") or {}
        if not (spec.get("expected_outputs") or []):
            return False, "experiment_claim_lacks_expected_outputs"
    return True, ""


def _proof_quality_ready(packet):
    if str((packet or {}).get("claim_kind") or "") != "theorem_or_proof":
        return True, ""
    obligations = list((packet or {}).get("proof_obligations") or [])
    if not obligations:
        return False, "proof_obligations_missing"
    names = {str(item.get("name") or "") for item in obligations if isinstance(item, dict)}
    if "proof_obligation_checklist" not in names:
        return False, "proof_obligation_checklist_missing"
    plan = set((packet or {}).get("verification_plan") or [])
    required = {"claim_scope_boundary", "lemma_or_assumption_cross_reference"}
    missing = sorted(required - plan)
    if missing:
        return False, "verification_plan_missing:" + ",".join(missing)
    return True, ""


def _experiment_quality_ready(packet):
    if str((packet or {}).get("claim_kind") or "") != "experiment":
        return True, ""
    spec = packet.get("experiment_spec") or {}
    local_request = packet.get("local_execution_request") or {}
    if not spec.get("output_hashes_required"):
        return False, "experiment_output_hashes_not_required"
    if not (spec.get("expected_outputs") or []):
        return False, "experiment_expected_outputs_missing"
    if not spec.get("negative_or_inconclusive_result_policy"):
        return False, "negative_or_inconclusive_result_policy_missing"
    if not local_request.get("experiment_execution_required"):
        return False, "local_execution_request_missing_experiment_execution_required"
    if local_request.get("allow_network") or local_request.get("shell_allowed") or local_request.get("cwd_override_allowed"):
        return False, "unsafe_local_execution_request"
    return True, ""


def _quality_checks(packet):
    claim_specificity_ready, claim_specificity_issue = _claim_specificity_ready(packet)
    proof_ready, proof_issue = _proof_quality_ready(packet)
    experiment_ready, experiment_issue = _experiment_quality_ready(packet)
    source_locator = str((packet or {}).get("source_locator") or "")
    bridge_plan = packet.get("bridge_plan_request") or {}
    local_execution = packet.get("local_execution_request") or {}
    verification_plan = list((packet or {}).get("verification_plan") or [])
    return [
        _check("claim_text_specific", claim_specificity_ready, claim_specificity_issue),
        _check("source_locator_present", bool(source_locator), "source_locator_missing"),
        _check("verification_plan_present", bool(verification_plan), "verification_plan_missing"),
        _check("bridge_plan_request_present", bool(bridge_plan), "bridge_plan_request_missing"),
        _check("local_execution_request_present", bool(local_execution), "local_execution_request_missing"),
        _check("proof_quality_ready", proof_ready, proof_issue),
        _check("experiment_quality_ready", experiment_ready, experiment_issue),
    ]


def _issue_names(checks, validation_issues=None):
    names = []
    for item in validation_issues or []:
        names.append(item.get("issue") or "")
    for item in checks or []:
        if item.get("status") != "PASS":
            names.append(item.get("detail") or item.get("name") or "")
    return [item for item in names if item]


def _improvement_packet(packet, ready, issues):
    claim_kind = str((packet or {}).get("claim_kind") or "")
    return {
        "packet_type": "research_compute_claim_quality_improvement_packet",
        "schema": "paper_factory.research_compute.claim_quality_gate.improvement_packet.v1",
        "ready": bool(ready),
        "claim_packet_id": (packet or {}).get("claim_packet_id") or "",
        "request_id": (packet or {}).get("request_id"),
        "slug": (packet or {}).get("slug") or "",
        "claim_kind": claim_kind,
        "required_revisions": list(issues or []),
        "next_agent_command": (
            "research-compute-claim-evidence-execution"
            if ready
            else "research-compute-claim-draft"
        ),
        "proof_quality_requirements": [
            "replace generic boundary text with a paper-specific theorem, lemma, proposition, or proof repair statement",
            "retain proof_obligation_checklist and lemma_or_assumption_cross_reference in the verification plan",
            "keep final claim bounded by the evidence gate and source post-apply hash",
        ],
        "experiment_quality_requirements": [
            "state the concrete experiment outcome, expected output files, and output hash policy",
            "preserve negative or inconclusive result reporting without overclaiming",
            "keep local execution network/shell/cwd override boundaries disabled",
        ],
        "bridge_plan_request": (packet or {}).get("bridge_plan_request") or {},
        "local_execution_request": (packet or {}).get("local_execution_request") or {},
        "source_locator": (packet or {}).get("source_locator") or "",
        "external_action_performed": False,
        "source_mutation_performed": False,
        "commit_performed": False,
    }


def research_compute_claim_quality_gate(claim_draft_report, claim_packet_id="", request_id="", label=""):
    claim_draft_report = claim_draft_report or {}
    validation_issues = _validate_claim_draft_report(claim_draft_report)
    packet = _select_claim_packet(claim_draft_report, claim_packet_id=claim_packet_id, request_id=request_id)
    packets = list(claim_draft_report.get("claim_packets") or [])
    if not packet and packets:
        validation_issues.append({"issue": "claim_packet_selection_not_found"})

    if not packet and not packets:
        forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
        status = "FAIL" if forbidden else ("ATTENTION" if validation_issues else "PASS")
        state = FORBIDDEN_STATE if forbidden else (ATTENTION_STATE if validation_issues else IDLE_STATE)
        return {
            "created_at": _created_at(),
            "command": COMMAND,
            "label": label or "",
            "status": status,
            "claim_quality_gate_state": state,
            "claim_quality_gate_created": not forbidden,
            "claim_quality_gate_ready": False,
            "slug": "",
            "claim_draft_report_path": claim_draft_report.get("report_path") or "",
            "claim_draft_report_sha256": claim_draft_report.get("report_sha256") or "",
            "claim_packet_selected": False,
            "claim_packet_id": "",
            "selected_request_id": "",
            "selected_request_key": "",
            "selected_claim_kind": "",
            "selected_source_locator": "",
            "claim_specificity_ready": False,
            "proof_quality_ready": False,
            "experiment_quality_ready": False,
            "ready_for_manuscript_patch_materialization": False,
            "full_agent_autonomy_authorized": bool(claim_draft_report.get("full_agent_autonomy_authorized")),
            "automatic_final_claim_allowed": False,
            "automatic_source_apply_allowed": False,
            "automatic_merge_allowed": False,
            "automatic_submission_allowed": False,
            "local_execution_request": {},
            "bridge_plan_request": {},
            "source_mutation_performed": False,
            "package_mutation_performed": False,
            "archive_mutation_performed": False,
            "provider_model_call_performed": False,
            "external_action_performed": False,
            "secret_material_read_performed": False,
            "patch_queue_merge_performed": False,
            "commit_performed": False,
            "report_write_performed": False,
            "db_mutation_performed": False,
            "summary": {
                "claim_packet_count": len(packets),
                "claim_quality_gate_ready_count": 0,
                "quality_check_count": 0,
                "quality_issue_count": len(validation_issues),
                "validation_issue_count": len(validation_issues),
                "source_mutation_count": 0,
                "external_action_performed_count": 0,
                "commit_performed_count": 0,
            },
            "quality_checks": [],
            "validation_issues": validation_issues,
            "quality_improvement_packet": _improvement_packet({}, False, _issue_names([], validation_issues)),
            "selected_claim_packet": {},
            "boundary": [
                "This command checks claim-packet quality before manuscript materialization.",
                "No claim packets were selected, so no source target was inspected or changed.",
            ],
        }

    checks = _quality_checks(packet)
    issue_names = _issue_names(checks, validation_issues)
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    ready = bool(packet) and not issue_names and not forbidden
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif ready:
        status = "PASS"
        state = READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE

    proof_ready = next((item.get("passed") for item in checks if item.get("name") == "proof_quality_ready"), False)
    experiment_ready = next((item.get("passed") for item in checks if item.get("name") == "experiment_quality_ready"), False)
    specificity_ready = next((item.get("passed") for item in checks if item.get("name") == "claim_text_specific"), False)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "claim_quality_gate_state": state,
        "claim_quality_gate_created": status != "FAIL",
        "claim_quality_gate_ready": ready,
        "slug": packet.get("slug") or "",
        "claim_draft_report_path": claim_draft_report.get("report_path") or "",
        "claim_draft_report_sha256": claim_draft_report.get("report_sha256") or "",
        "claim_packet_selected": bool(packet),
        "claim_packet_id": packet.get("claim_packet_id") or "",
        "selected_request_id": str(packet.get("request_id") or ""),
        "selected_request_key": str(packet.get("request_key") or ""),
        "selected_claim_kind": packet.get("claim_kind") or "",
        "selected_source_locator": packet.get("source_locator") or "",
        "claim_specificity_ready": bool(specificity_ready),
        "proof_quality_ready": bool(proof_ready),
        "experiment_quality_ready": bool(experiment_ready),
        "ready_for_manuscript_patch_materialization": ready,
        "full_agent_autonomy_authorized": bool(packet.get("full_agent_autonomy_authorized")),
        "automatic_final_claim_allowed": bool(packet.get("automatic_final_claim_allowed")),
        "automatic_source_apply_allowed": bool(packet.get("automatic_source_apply_allowed")),
        "automatic_merge_allowed": bool(packet.get("automatic_merge_allowed")),
        "automatic_submission_allowed": bool(packet.get("automatic_submission_allowed")),
        "local_execution_request": packet.get("local_execution_request") or {},
        "bridge_plan_request": packet.get("bridge_plan_request") or {},
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "claim_packet_count": len(packets),
            "claim_quality_gate_ready_count": 1 if ready else 0,
            "quality_check_count": len(checks),
            "quality_issue_count": len(issue_names),
            "validation_issue_count": len(validation_issues),
            "source_mutation_count": 0,
            "external_action_performed_count": 0,
            "commit_performed_count": 0,
        },
        "quality_checks": checks,
        "validation_issues": validation_issues,
        "quality_improvement_packet": _improvement_packet(packet, ready, issue_names),
        "selected_claim_packet": packet,
        "boundary": [
            "This command checks theorem/proof/experiment claim quality before manuscript patch materialization.",
            "It may mark a claim packet ready for later manuscript materialization, but it does not run compute or edit source.",
            "It performs no provider/model call, secret read, patch queue mutation, merge, commit, upload, email, or external submission.",
        ],
    }


def research_compute_claim_quality_gate_markdown(report):
    lines = [
        "# paper_factory Claim Quality Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('claim_quality_gate_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Claim packet: `{report.get('claim_packet_id') or ''}`",
        f"- Request: `{report.get('selected_request_id') or ''}`",
        f"- Claim kind: `{report.get('selected_claim_kind') or ''}`",
        f"- Ready for manuscript patch materialization: {report.get('ready_for_manuscript_patch_materialization')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- External action performed: {report.get('external_action_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Quality Checks", ""])
    for item in report.get("quality_checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if not report.get("quality_checks"):
        lines.append("- No claim packet selected.")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
