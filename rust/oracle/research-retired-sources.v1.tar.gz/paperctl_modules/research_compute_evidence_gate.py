"""Gate candidate evidence before patch generation.

This layer validates ingested research-compute evidence and prepares a local
patch-generation request packet. It still does not generate/enqueue/apply a
patch or mutate manuscript state.
"""

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-evidence-gate"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "gate_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_generated",
    "patch_generation_request_created",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "validation_issues",
    "patch_generation_request",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "output_hash_count",
    "patch_generation_request_ready_count",
    "candidate_patch_generated_count",
    "agent_generated_evidence_material_count",
    "patch_queue_mutation_count",
]
REPORT_SCHEMA_NOTES = [
    "Validates candidate evidence and creates a patch-generation request packet only.",
    "No manuscript patch is generated or enqueued by this command.",
]


def validate_ingest_report(ingest_report):
    issues = []
    if ingest_report.get("command") != "research-compute-evidence-ingest":
        issues.append({"issue": "ingest_report_command_mismatch", "detail": ingest_report.get("command") or ""})
    if ingest_report.get("status") != "PASS":
        issues.append({"issue": "ingest_report_not_pass", "detail": ingest_report.get("status") or ""})
    evidence = ingest_report.get("candidate_evidence") or {}
    if not evidence.get("candidate_evidence_ready"):
        issues.append({"issue": "candidate_evidence_not_ready"})
    outputs = evidence.get("outputs") or []
    if not outputs:
        issues.append({"issue": "candidate_evidence_outputs_required"})
    for item in outputs:
        sha = str(item.get("sha256") or "")
        if len(sha) != 64:
            issues.append({"issue": "invalid_output_sha256", "detail": item.get("path") or ""})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_mutation_performed",
        "candidate_patch_generated",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if ingest_report.get(key):
            issues.append({"issue": f"forbidden_boundary_crossed:{key}"})
    return issues


def research_compute_evidence_gate(ingest_report, label=""):
    issues = validate_ingest_report(ingest_report or {})
    evidence = (ingest_report or {}).get("candidate_evidence") or {}
    policy = agent_autonomy_policy.normalize_policy(
        evidence.get("autonomy_policy") or (ingest_report or {}).get("autonomy_policy")
    )
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    patch_request = {
        "patch_generation_request_ready": not issues,
        "request_type": "research_compute_evidence_candidate_patch_request",
        "job_id": evidence.get("job_id") or "",
        "slug": evidence.get("slug") or "",
        "workspace_dir": evidence.get("workspace_dir") or "",
        "evidence_report_path": (ingest_report or {}).get("report_path") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_command_material_generated": bool(evidence.get("agent_command_material_generated")),
        "output_hashes": evidence.get("outputs") or [],
        "required_next_gate": "candidate_patch_generation_gate",
        "patch_queue_enqueue_allowed": False,
        "source_mutation_allowed": False,
    }
    status = "PASS" if not issues else "ATTENTION"
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "gate_state": "PATCH_GENERATION_REQUEST_PACKET_READY" if not issues else "PATCH_GENERATION_REQUEST_PACKET_BLOCKED",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_generated": False,
        "patch_generation_request_created": not issues,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": bool(evidence.get("agent_command_material_generated")),
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "output_hash_count": len(patch_request["output_hashes"]),
            "patch_generation_request_ready_count": 1 if not issues else 0,
            "candidate_patch_generated_count": 0,
            "agent_generated_evidence_material_count": 1 if evidence.get("agent_command_material_generated") else 0,
            "patch_queue_mutation_count": 0,
        },
        "validation_issues": issues,
        "patch_generation_request": patch_request,
        "boundary": [
            "This gate validates local candidate evidence and creates a patch-generation request packet only.",
            "It does not generate a manuscript patch, enqueue a patch, apply a patch, mutate source/package/archive state, call a provider/model, or perform external actions.",
            "A later patch-generation gate must explicitly consume this request packet before any candidate patch text exists.",
        ],
    }
    if any(str(item.get("issue") or "").startswith("forbidden_boundary_crossed") for item in issues):
        report["status"] = "FAIL"
        report["gate_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
    return report


def research_compute_evidence_gate_markdown(report):
    lines = [
        "# paper_factory Research Compute Evidence Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Gate state: {report.get('gate_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Agent generated evidence material: {report.get('agent_generated_evidence_material')}",
        f"- Patch generation request created: {report.get('patch_generation_request_created')}",
        f"- Candidate patch generated: {report.get('candidate_patch_generated')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    request = report.get("patch_generation_request") or {}
    lines.extend(["", "## Patch Generation Request", ""])
    lines.append(f"- Job: `{request.get('job_id') or ''}`")
    lines.append(f"- Slug: `{request.get('slug') or ''}`")
    lines.append(f"- Workspace: `{request.get('workspace_dir') or ''}`")
    for item in request.get("output_hashes") or []:
        lines.append(f"- `{item.get('path')}` {item.get('sha256')}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
