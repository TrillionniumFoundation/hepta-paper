"""Ingest executor output hashes into candidate evidence packages.

The ingestor turns a successful research-compute execution report into local
candidate evidence metadata. It does not generate or enqueue manuscript patches.
"""

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-evidence-ingest"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "ingest_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_generated",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_command_material_generated",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "validation_issues",
    "candidate_evidence",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "output_hash_count",
    "candidate_evidence_ready_count",
    "candidate_patch_generated_count",
    "agent_generated_evidence_material_count",
    "patch_queue_mutation_count",
]
REPORT_SCHEMA_NOTES = [
    "Packages research-compute executor output hashes as local candidate evidence only.",
    "No manuscript patch is generated or enqueued by this command.",
]


def _flag(report, key):
    return bool(report.get(key))


def validate_execute_report(execute_report):
    issues = []
    if execute_report.get("command") != "research-compute-execute":
        issues.append({"issue": "execute_report_command_mismatch", "detail": execute_report.get("command") or ""})
    if execute_report.get("status") != "PASS":
        issues.append({"issue": "execute_report_not_pass", "detail": execute_report.get("status") or ""})
    if not execute_report.get("execution_performed"):
        issues.append({"issue": "execution_not_performed"})
    if execute_report.get("missing_outputs"):
        issues.append({"issue": "missing_outputs_present", "detail": ",".join(execute_report.get("missing_outputs") or [])})
    if not execute_report.get("output_hashes"):
        issues.append({"issue": "output_hashes_required"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if _flag(execute_report, key):
            issues.append({"issue": f"forbidden_boundary_crossed:{key}"})
    workspace = execute_report.get("workspace_dir") or ""
    if not str(workspace).startswith("logs/paperctl/research_compute/"):
        issues.append({"issue": "workspace_outside_research_compute_logs", "detail": workspace})
    return issues


def research_compute_evidence_ingest(execute_report, label=""):
    issues = validate_execute_report(execute_report or {})
    policy = agent_autonomy_policy.normalize_policy((execute_report or {}).get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    output_hashes = list((execute_report or {}).get("output_hashes") or [])
    candidate_evidence = {
        "candidate_evidence_ready": not issues,
        "candidate_patch_generated": False,
        "patch_queue_mutation_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_command_material_generated": bool((execute_report or {}).get("agent_command_material_generated")),
        "job_id": (execute_report or {}).get("job_id") or "",
        "slug": (execute_report or {}).get("slug") or "",
        "workspace_dir": (execute_report or {}).get("workspace_dir") or "",
        "execute_report_path": (execute_report or {}).get("report_path") or "",
        "outputs": output_hashes,
        "gate_required_before_patch": True,
        "policy": "candidate_evidence_only_no_source_or_patch_queue_mutation",
    }
    status = "PASS" if not issues else "ATTENTION"
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "ingest_state": "CANDIDATE_EVIDENCE_READY_NOT_PATCHED" if not issues else "CANDIDATE_EVIDENCE_NOT_READY",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_generated": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_command_material_generated": bool((execute_report or {}).get("agent_command_material_generated")),
        "agent_generated_evidence_material": bool((execute_report or {}).get("agent_command_material_generated")),
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "output_hash_count": len(output_hashes),
            "candidate_evidence_ready_count": 1 if not issues else 0,
            "candidate_patch_generated_count": 0,
            "agent_generated_evidence_material_count": 1 if (execute_report or {}).get("agent_command_material_generated") else 0,
            "patch_queue_mutation_count": 0,
        },
        "validation_issues": issues,
        "candidate_evidence": candidate_evidence,
        "boundary": [
            "This ingestor reads a local research-compute execution report and packages output hashes as candidate evidence only.",
            "It does not generate a manuscript patch, enqueue a patch, apply a patch, mutate source/package/archive state, call a provider/model, or perform external actions.",
            "A later gate must consume this evidence before any candidate manuscript patch can be produced.",
        ],
    }
    if any(str(item.get("issue") or "").startswith("forbidden_boundary_crossed") for item in issues):
        report["status"] = "FAIL"
        report["ingest_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
    return report


def research_compute_evidence_ingest_markdown(report):
    lines = [
        "# paper_factory Research Compute Evidence Ingest",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Ingest state: {report.get('ingest_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Agent generated evidence material: {report.get('agent_generated_evidence_material')}",
        f"- Candidate patch generated: {report.get('candidate_patch_generated')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    evidence = report.get("candidate_evidence") or {}
    lines.extend(["", "## Candidate Evidence", ""])
    lines.append(f"- Job: `{evidence.get('job_id') or ''}`")
    lines.append(f"- Slug: `{evidence.get('slug') or ''}`")
    lines.append(f"- Workspace: `{evidence.get('workspace_dir') or ''}`")
    for item in evidence.get("outputs") or []:
        lines.append(f"- `{item.get('path')}` {item.get('sha256')}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
