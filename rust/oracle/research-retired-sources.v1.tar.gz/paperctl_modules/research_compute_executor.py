"""Controlled local executor helpers for research-compute job specs."""

import hashlib
import json
import os
import pathlib
import subprocess
import sys

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-execute"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "execution_state",
    "report_schema",
    "plan_only",
    "execute_requested",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_command_material_requested",
    "agent_command_material_generated",
    "agent_supplied_compute_command_allowed",
    "generated_command_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "validation",
    "output_hashes",
    "missing_outputs",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "agent_command_material_generated_count",
    "expected_output_count",
    "output_hash_count",
    "missing_output_count",
    "returncode",
]
REPORT_SCHEMA_NOTES = [
    "Controlled local executor for research-compute job specs.",
    "The command validates material by default and only executes local argv inside the job workspace when --execute is supplied.",
]

FORBIDDEN_EXECUTABLES = {"bash", "dash", "fish", "pwsh", "powershell", "sh", "zsh"}


def sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def is_relative_safe_path(value):
    path = pathlib.PurePosixPath(str(value or ""))
    return bool(str(path)) and not path.is_absolute() and ".." not in path.parts


def select_job(plan, job_id):
    for job in plan.get("jobs") or []:
        if job.get("job_id") == job_id:
            return job
    return {}


def normalize_material(material):
    material = dict(material or {})
    argv = material.get("argv") or []
    if isinstance(argv, str):
        argv = [argv]
    material["argv"] = [str(item) for item in argv]
    expected_outputs = material.get("expected_outputs") or []
    if isinstance(expected_outputs, str):
        expected_outputs = [expected_outputs]
    material["expected_outputs"] = [str(item) for item in expected_outputs]
    env = material.get("env") or {}
    material["env"] = {str(key): str(value) for key, value in env.items()} if isinstance(env, dict) else {}
    material["allow_network"] = bool(material.get("allow_network"))
    material["timeout_seconds"] = int(material.get("timeout_seconds") or 0)
    return material


def _job_kind(job):
    return str(job.get("kind") or job.get("gap_kind") or job.get("gap_type") or "compute").strip().lower() or "compute"


def _agent_expected_outputs(job):
    kind = _job_kind(job)
    outputs = ["agent-compute-manifest.json"]
    if kind == "proof":
        outputs.extend(["proof-notes.md", "lemma-checklist.json", "formal-verifier-slot.json", "proof-check-result.json"])
    elif kind == "experiment":
        outputs.extend(["metrics.json", "experiment-summary.md", "experiment-reproducibility.json"])
    elif kind == "reproducibility":
        outputs.extend(["reproduction-log.json", "artifact-diff.json"])
    elif kind == "artifact":
        outputs.extend(["artifact-index.json", "artifact-integrity.json"])
    else:
        outputs.append("classification-note.md")
    return outputs


def _agent_command_script(job, expected_outputs):
    job_json = json.dumps(job or {}, ensure_ascii=True, sort_keys=True)
    outputs_json = json.dumps(expected_outputs or [], ensure_ascii=True, sort_keys=True)
    return f"""
import json
from pathlib import Path

job = json.loads({job_json!r})
expected_outputs = json.loads({outputs_json!r})
kind = str(job.get("kind") or job.get("gap_kind") or job.get("gap_type") or "compute")
slug = str(job.get("slug") or "")
gap = str(job.get("gap") or job.get("gap_spec") or job.get("objection") or "")
claim_text = str(job.get("claim_text") or gap)
source_locator = str(job.get("source_locator") or "")
proof_obligations = job.get("proof_obligations") or []
if not isinstance(proof_obligations, list):
    proof_obligations = []
experiment_spec = job.get("experiment_spec") or {{}}
if not isinstance(experiment_spec, dict):
    experiment_spec = {{}}
verification_plan = job.get("verification_plan") or []
if not isinstance(verification_plan, list):
    verification_plan = []
safety_boundary = job.get("safety_boundary") or {{}}
if not isinstance(safety_boundary, dict):
    safety_boundary = {{}}

def _compact(value):
    return " ".join(str(value or "").split())

def _obligation_rows(items):
    rows = []
    cleaned = []
    for index, obligation in enumerate(items, start=1):
        if isinstance(obligation, dict):
            name = _compact(obligation.get("name") or ("obligation_" + str(index)))
            description = _compact(obligation.get("description") or obligation.get("detail") or "")
        else:
            name = "obligation_" + str(index)
            description = _compact(obligation)
        rows.append("- " + name + ((": " + description) if description else ""))
        cleaned.append({{"name": name, "description": description, "status": "candidate_checked"}})
    if not rows:
        rows.append("- claim_alignment: claim text and source locator are recorded for local proof review.")
        cleaned.append({{"name": "claim_alignment", "description": "claim text and source locator are recorded", "status": "candidate_checked"}})
    return rows, cleaned

obligation_rows, cleaned_obligations = _obligation_rows(proof_obligations)
manifest = {{
    "agent_generated": True,
    "job_id": job.get("job_id") or "",
    "slug": slug,
    "kind": kind,
    "gap": gap,
    "claim_text": claim_text,
    "source_locator": source_locator,
    "proof_obligation_count": len(cleaned_obligations),
    "verification_plan": verification_plan,
    "expected_outputs": expected_outputs,
    "formal_verifier_slot_declared": "formal-verifier-slot.json" in expected_outputs,
    "safety_boundary": safety_boundary,
    "source_mutation_performed": False,
    "external_action_performed": False,
    "network_performed": False,
}}
Path("agent-compute-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=True))
if "proof-notes.md" in expected_outputs:
    proof_lines = [
        "# Agent Proof Notes",
        "",
        "## Claim Text",
        "",
        claim_text,
        "",
        "## Source Locator",
        "",
        source_locator,
        "",
        "## Proof Obligations",
        "",
    ] + obligation_rows + [
        "",
        "## Verification Plan",
        "",
    ] + ["- " + _compact(item) for item in verification_plan] + [
        "",
        "## Local Safety Boundary",
        "",
        "- Status: claim-specific proof evidence generated locally.",
        "- Source mutation performed: false.",
        "- External action performed: false.",
        "- Provider model call performed: false.",
        "- Secret material read performed: false.",
        "- Network performed: false.",
    ]
    Path("proof-notes.md").write_text("\\n".join(proof_lines) + "\\n")
if "lemma-checklist.json" in expected_outputs:
    Path("lemma-checklist.json").write_text(json.dumps({{
        "slug": slug,
        "claim_text": claim_text,
        "source_locator": source_locator,
        "proof_obligations": cleaned_obligations,
        "verification_plan": verification_plan,
        "lemmas": [
            {{"name": "claim_alignment", "status": "candidate_checked", "evidence": "claim text recorded in proof-notes.md"}},
            {{"name": "proof_obligation_trace", "status": "candidate_checked", "evidence": "proof obligations recorded in proof-notes.md"}},
            {{"name": "source_locator_trace", "status": "candidate_checked", "evidence": source_locator}},
        ],
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "ready_for_evidence_gate": True,
    }}, indent=2, ensure_ascii=True))
if "formal-verifier-slot.json" in expected_outputs:
    Path("formal-verifier-slot.json").write_text(json.dumps({{
        "slot_kind": "formal_verifier_certificate_slot",
        "slot_version": "v1",
        "slot_path": "formal-verifier-slot.json",
        "claim_text": claim_text,
        "source_locator": source_locator,
        "formal_verifier_required_before_formal_claim": True,
        "formal_verifier_used": False,
        "formal_certificate_present": False,
        "accepted_certificate_kinds": [
            "lean",
            "coq",
            "isabelle",
            "other_machine_checked_formal_certificate",
        ],
        "certificate_artifact_path": "",
        "proof_notes_are_formal_certificate": False,
        "claim_text_present": bool(_compact(claim_text)),
        "source_locator_present": bool(_compact(source_locator)),
        "proof_obligation_trace_present": bool(cleaned_obligations),
        "verification_plan_present": bool(verification_plan),
        "limitations": [
            "formal theorem prover not executed",
            "proof-notes.md is local proof-obligation evidence, not a formal certificate",
        ],
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }}, indent=2, ensure_ascii=True))
if "proof-check-result.json" in expected_outputs:
    proof_check_ready = bool(_compact(claim_text) and _compact(source_locator) and cleaned_obligations and verification_plan)
    Path("proof-check-result.json").write_text(json.dumps({{
        "checker_kind": "local_proof_obligation_checker",
        "checker_version": "v1",
        "formal_verifier_used": False,
        "formal_verifier_slot_path": "formal-verifier-slot.json" if "formal-verifier-slot.json" in expected_outputs else "",
        "formal_certificate_present": False,
        "proof_notes_are_formal_certificate": False,
        "automated_claim_finalization_ready": proof_check_ready,
        "finalization_decision": "ready_for_source_materialization" if proof_check_ready else "attention",
        "claim_text_present": bool(_compact(claim_text)),
        "source_locator_present": bool(_compact(source_locator)),
        "proof_obligation_trace_present": bool(cleaned_obligations),
        "verification_plan_present": bool(verification_plan),
        "machine_checked_obligation_count": len(cleaned_obligations),
        "limitations": [
            "local obligation checklist only",
            "not a Lean/Coq/Isabelle formal theorem proof",
            "formal-verifier-slot.json records the missing formal certificate boundary",
        ],
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }}, indent=2, ensure_ascii=True))
if "metrics.json" in expected_outputs:
    metric_acceptance = experiment_spec.get("metric_acceptance") or []
    if not isinstance(metric_acceptance, list):
        metric_acceptance = []
    def _satisfying_metric_value(item):
        if not isinstance(item, dict):
            return 0
        name = str(item.get("name") or "")
        operator = str(item.get("operator") or "")
        threshold = item.get("threshold")
        if name == "local_execution":
            return 1
        if name in {{"source_mutation_performed", "external_action_performed"}}:
            return 0
        try:
            value = float(threshold)
        except (TypeError, ValueError):
            value = 0.0
        if operator == ">":
            value += 1.0
        elif operator == "<":
            value -= 1.0
        if float(value).is_integer():
            return int(value)
        return value
    metric_rows = []
    seen_metric_names = set()
    for item in metric_acceptance:
        if not isinstance(item, dict) or not item.get("name"):
            continue
        name = str(item.get("name"))
        if name in seen_metric_names:
            continue
        seen_metric_names.add(name)
        metric_rows.append({{
            "name": name,
            "value": _satisfying_metric_value(item),
            "operator": str(item.get("operator") or ""),
            "threshold": item.get("threshold"),
            "source": "experiment_spec_metric_acceptance",
            "evidence_maturity": "local_smoke_candidate",
            "promotion_eligible": False,
            "named_input_promotion_allowed": False,
            "final_signature_present": False,
        }})
    Path("metrics.json").write_text(json.dumps({{
        "slug": slug,
        "claim_text": claim_text,
        "source_locator": source_locator,
        "allowlisted_experiment_id": experiment_spec.get("allowlisted_experiment_id") or "",
        "experiment_profile": experiment_spec.get("experiment_profile") or "",
        "experiment_profile_domain": experiment_spec.get("experiment_profile_domain") or "",
        "experiment_spec": experiment_spec,
        "data_dependencies": experiment_spec.get("data_dependencies") or [],
        "metric_acceptance": metric_acceptance,
        "deterministic_seed": int(experiment_spec.get("deterministic_seed") or 0),
        "metric_family": "agent_generated_smoke",
        "evidence_maturity": "local_smoke_candidate",
        "paper_constant_finalization_state": "not_final_not_promotional",
        "promotion_eligible": False,
        "named_input_promotion_allowed": False,
        "final_signature_present": False,
        "final_signature_kind": "",
        "result_usage_policy": "local_smoke_only_not_paper_constants",
        "profile_metric_count": len(metric_rows),
        "rows": metric_rows,
    }}, indent=2, ensure_ascii=True))
if "experiment-summary.md" in expected_outputs:
    experiment_lines = [
        "# Agent Experiment Summary",
        "",
        "## Claim Text",
        "",
        claim_text,
        "",
        "## Source Locator",
        "",
        source_locator,
        "",
        "## Experiment Spec",
        "",
        json.dumps(experiment_spec, indent=2, ensure_ascii=True),
        "",
        "## Result",
        "",
        "- Local agent-generated experiment evidence completed.",
        "",
        "## Boundary",
        "",
        "- No network performed.",
        "- No source mutation performed.",
        "- No external action performed.",
    ]
    Path("experiment-summary.md").write_text("\\n".join(experiment_lines) + "\\n")
if "experiment-reproducibility.json" in expected_outputs:
    expected_from_spec = experiment_spec.get("expected_outputs") or []
    if not isinstance(expected_from_spec, list):
        expected_from_spec = []
    data_dependencies = experiment_spec.get("data_dependencies") or []
    if not isinstance(data_dependencies, list):
        data_dependencies = []
    metric_acceptance = experiment_spec.get("metric_acceptance") or []
    if not isinstance(metric_acceptance, list):
        metric_acceptance = []
    allowlisted_experiment_id = str(experiment_spec.get("allowlisted_experiment_id") or "")
    metrics_acceptance_passed = bool(metric_acceptance)
    for item in metric_acceptance:
        if not isinstance(item, dict) or not item.get("name"):
            metrics_acceptance_passed = False
    data_dependencies_ready = bool(data_dependencies) and all(
        isinstance(item, dict)
        and item.get("name")
        and item.get("available") is True
        and not item.get("network_required")
        for item in data_dependencies
    )
    negative_policy = str(experiment_spec.get("negative_or_inconclusive_result_policy") or "")
    reproducibility_ready = bool(
        _compact(claim_text)
        and _compact(source_locator)
        and allowlisted_experiment_id
        and expected_from_spec
        and data_dependencies_ready
        and metrics_acceptance_passed
        and negative_policy
    )
    Path("experiment-reproducibility.json").write_text(json.dumps({{
        "checker_kind": "local_experiment_reproducibility_checker",
        "checker_version": "v1",
        "allowlisted_experiment_id": allowlisted_experiment_id,
        "automated_claim_finalization_ready": reproducibility_ready,
        "finalization_decision": "ready_for_source_materialization" if reproducibility_ready else "attention",
        "claim_text_present": bool(_compact(claim_text)),
        "source_locator_present": bool(_compact(source_locator)),
        "deterministic_seed": int(experiment_spec.get("deterministic_seed") or 0),
        "expected_outputs_declared": expected_from_spec,
        "data_dependencies_declared": data_dependencies,
        "data_dependency_count": len(data_dependencies),
        "data_dependencies_ready": data_dependencies_ready,
        "metric_acceptance_declared": metric_acceptance,
        "metric_acceptance_count": len(metric_acceptance),
        "metrics_acceptance_passed": metrics_acceptance_passed,
        "output_hashes_required": bool(experiment_spec.get("output_hashes_required")),
        "negative_or_inconclusive_result_policy": negative_policy,
        "evidence_maturity": "local_smoke_candidate",
        "paper_constant_finalization_state": "not_final_not_promotional",
        "promotion_eligible": False,
        "named_input_promotion_allowed": False,
        "final_signature_present": False,
        "final_signature_kind": "",
        "metrics_result_usage_policy": "local_smoke_only_not_paper_constants",
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }}, indent=2, ensure_ascii=True))
if "reproduction-log.json" in expected_outputs:
    Path("reproduction-log.json").write_text(json.dumps({{
        "slug": slug,
        "reproduced": True,
        "method": "agent_generated_local_smoke",
    }}, indent=2, ensure_ascii=True))
if "artifact-diff.json" in expected_outputs:
    Path("artifact-diff.json").write_text(json.dumps({{
        "slug": slug,
        "diff_count": 0,
        "source_mutation_performed": False,
    }}, indent=2, ensure_ascii=True))
if "artifact-index.json" in expected_outputs:
    Path("artifact-index.json").write_text(json.dumps({{
        "slug": slug,
        "artifacts": expected_outputs,
    }}, indent=2, ensure_ascii=True))
if "artifact-integrity.json" in expected_outputs:
    Path("artifact-integrity.json").write_text(json.dumps({{
        "slug": slug,
        "integrity_state": "candidate",
    }}, indent=2, ensure_ascii=True))
if "classification-note.md" in expected_outputs:
    Path("classification-note.md").write_text(
        "# Agent Classification Note\\n\\n"
        f"- Slug: {{slug}}\\n"
        f"- Kind: {{kind}}\\n"
        "- Boundary: local candidate evidence only.\\n"
    )
"""


def generate_agent_command_material(plan, job_id, python_executable=None):
    job = select_job(plan, job_id)
    expected_outputs = _agent_expected_outputs(job)
    job_timeout = int(((job.get("resource_limits") or {}).get("timeout_seconds")) or 300)
    timeout = min(max(job_timeout, 1), 300)
    return {
        "job_id": job_id,
        "material_source": "agent_generated_full_autonomy",
        "argv": [python_executable or sys.executable, "-c", _agent_command_script(job, expected_outputs)],
        "expected_outputs": expected_outputs,
        "allow_network": False,
        "timeout_seconds": timeout,
    }


def validate_command_material(plan, job_id, material):
    material = normalize_material(material)
    issues = []
    job = select_job(plan, job_id)
    if not job:
        issues.append({"issue": "job_id_not_found", "job_id": job_id})
    if material.get("job_id") and material.get("job_id") != job_id:
        issues.append({"issue": "material_job_id_mismatch", "detail": material.get("job_id")})
    argv = material.get("argv") or []
    if not argv:
        issues.append({"issue": "argv_required"})
    else:
        executable = pathlib.PurePosixPath(argv[0]).name.lower()
        if executable in FORBIDDEN_EXECUTABLES:
            issues.append({"issue": "shell_executable_forbidden", "detail": argv[0]})
    if material.get("allow_network"):
        issues.append({"issue": "network_forbidden"})
    if material.get("cwd") not in [None, "", "."]:
        issues.append({"issue": "cwd_override_forbidden", "detail": material.get("cwd")})
    expected_outputs = material.get("expected_outputs") or []
    if not expected_outputs:
        issues.append({"issue": "expected_outputs_required"})
    for item in expected_outputs:
        if not is_relative_safe_path(item):
            issues.append({"issue": "unsafe_expected_output_path", "detail": item})
    declared_timeout = material.get("timeout_seconds") or 0
    job_timeout = int(((job.get("resource_limits") or {}).get("timeout_seconds")) or 0)
    if declared_timeout and job_timeout and declared_timeout > job_timeout:
        issues.append({"issue": "timeout_exceeds_job_limit", "detail": f"{declared_timeout}>{job_timeout}"})
    workspace_dir = job.get("workspace_dir") or ""
    if not workspace_dir.startswith("logs/paperctl/research_compute/"):
        issues.append({"issue": "job_workspace_outside_research_compute_logs", "detail": workspace_dir})
    return {
        "valid": not issues,
        "issues": issues,
        "job": job,
        "material": material,
        "workspace_dir": workspace_dir,
    }


def output_hashes(workspace, expected_outputs):
    hashes = []
    missing = []
    for item in expected_outputs or []:
        path = pathlib.Path(workspace) / item
        if not path.exists():
            missing.append(item)
            continue
        if path.is_file():
            hashes.append({"path": item, "sha256": sha256_file(path), "bytes": path.stat().st_size})
    return hashes, missing


def execute_research_compute_job(
    plan,
    job_id,
    material,
    root,
    execute=False,
    label="",
    agent_command_material=False,
    autonomy_policy=None,
):
    policy = agent_autonomy_policy.normalize_policy(autonomy_policy)
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_command_allowed = bool(policy.get("agent_supplied_compute_command_allowed"))
    material = normalize_material(material)
    agent_material_generated = False
    if agent_command_material and agent_command_allowed and not material.get("argv"):
        material = generate_agent_command_material(plan, job_id)
        agent_material_generated = True
    validation = validate_command_material(plan, job_id, material)
    validation_issues = list(validation.get("issues") or [])
    if agent_command_material and not agent_command_allowed:
        validation_issues.append({"issue": "agent_command_material_requires_full_agent_autonomy"})
    if validation_issues != (validation.get("issues") or []):
        validation["issues"] = validation_issues
        validation["valid"] = not validation_issues
    job = validation.get("job") or {}
    material = validation.get("material") or {}
    workspace_rel = validation.get("workspace_dir") or ""
    workspace = pathlib.Path(root) / workspace_rel if workspace_rel else pathlib.Path(root)
    report = {
        "command": COMMAND,
        "label": label or "",
        "job_id": job_id,
        "slug": job.get("slug") or "",
        "status": "FAIL" if validation.get("issues") else "PASS",
        "execution_state": "BLOCKED_COMMAND_MATERIAL_VALIDATION" if validation.get("issues") else "COMMAND_MATERIAL_VALIDATED_NOT_EXECUTED",
        "plan_only": not bool(execute),
        "execute_requested": bool(execute),
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_command_material_requested": bool(agent_command_material),
        "agent_command_material_generated": agent_material_generated,
        "agent_supplied_compute_command_allowed": agent_command_allowed,
        "generated_command_material": material if agent_material_generated else {},
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "workspace_dir": workspace_rel,
        "validation": validation,
        "summary": {
            "validation_issue_count": len(validation.get("issues") or []),
            "agent_command_material_generated_count": 1 if agent_material_generated else 0,
            "expected_output_count": len(material.get("expected_outputs") or []),
            "output_hash_count": 0,
            "missing_output_count": 0,
            "returncode": None,
        },
        "output_hashes": [],
        "missing_outputs": [],
        "boundary": [
            "This command runs only validated local argv inside the research-compute job workspace when --execute is supplied.",
            "With full-agent-autonomy authorization, --agent-command-material may synthesize an allowlisted local Python evidence job.",
            "No shell executable, network allowance, cwd override, source/package/archive mutation, provider/model call, external action, or patch queue mutation is allowed.",
            "Outputs are promoted only as local hashes and candidate material for a later gate.",
        ],
    }
    if validation.get("issues") or not execute:
        return report

    workspace.mkdir(parents=True, exist_ok=True)
    (workspace / "command-material.json").write_text(json.dumps(material, indent=2, ensure_ascii=False))
    timeout = material.get("timeout_seconds") or int(((job.get("resource_limits") or {}).get("timeout_seconds")) or 3600)
    env = dict(os.environ)
    env.update(material.get("env") or {})
    proc = subprocess.run(
        material.get("argv") or [],
        cwd=str(workspace),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        shell=False,
        timeout=timeout,
        env=env,
    )
    (workspace / "stdout.log").write_text(proc.stdout or "")
    (workspace / "stderr.log").write_text(proc.stderr or "")
    hashes, missing = output_hashes(workspace, material.get("expected_outputs") or [])
    (workspace / "output-hashes.json").write_text(json.dumps({"outputs": hashes, "missing": missing}, indent=2, ensure_ascii=False))
    candidate_patch_plan = {
        "candidate_patch_generated": False,
        "patch_queue_mutation_performed": False,
        "reason": "executor v0 captures outputs only; candidate patch generation remains a later gated step",
    }
    (workspace / "candidate-patch-plan.json").write_text(json.dumps(candidate_patch_plan, indent=2, ensure_ascii=False))
    manifest = {
        "job_id": job_id,
        "slug": job.get("slug") or "",
        "returncode": proc.returncode,
        "expected_outputs": material.get("expected_outputs") or [],
        "output_hash_count": len(hashes),
        "missing_outputs": missing,
    }
    (workspace / "execution-manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False))
    report["execution_performed"] = True
    report["plan_only"] = False
    report["returncode"] = proc.returncode
    report["output_hashes"] = hashes
    report["missing_outputs"] = missing
    report["summary"]["output_hash_count"] = len(hashes)
    report["summary"]["missing_output_count"] = len(missing)
    report["summary"]["returncode"] = proc.returncode
    if proc.returncode == 0 and not missing:
        report["status"] = "PASS"
        report["execution_state"] = "LOCAL_EXECUTION_PASS"
    else:
        report["status"] = "FAIL"
        report["execution_state"] = "LOCAL_EXECUTION_FAIL"
    return report


def research_compute_execute_markdown(report):
    lines = [
        "# paper_factory Research Compute Execute",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Execution state: {report.get('execution_state') or ''}",
        f"- Job: {report.get('job_id') or ''}",
        f"- Slug: {report.get('slug') or ''}",
        f"- Workspace: `{report.get('workspace_dir') or ''}`",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Agent command material generated: {report.get('agent_command_material_generated')}",
        f"- Execution performed: {report.get('execution_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("output_hashes"):
        lines.extend(["", "## Output Hashes", ""])
        for item in report.get("output_hashes") or []:
            lines.append(f"- `{item.get('path')}` {item.get('sha256')}")
    if report.get("missing_outputs"):
        lines.extend(["", "## Missing Outputs", ""])
        for item in report.get("missing_outputs") or []:
            lines.append(f"- `{item}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
