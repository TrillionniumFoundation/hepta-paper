"""Allowlisted local experiment specs for research-compute claim evidence."""


REQUIRED_OUTPUTS = {
    "agent-compute-manifest.json",
    "metrics.json",
    "experiment-summary.md",
    "experiment-reproducibility.json",
}

BASE_REQUIRED_METRICS = {
    "local_execution",
    "source_mutation_performed",
    "external_action_performed",
}

BASE_METRIC_ACCEPTANCE = [
    {"name": "local_execution", "operator": "==", "threshold": 1},
    {"name": "source_mutation_performed", "operator": "==", "threshold": 0},
    {"name": "external_action_performed", "operator": "==", "threshold": 0},
]

DQL_NONPROMOTIONAL_EVIDENCE_MATURITY = "local_smoke_candidate"
DQL_NONPROMOTIONAL_FINALIZATION_STATE = "not_final_not_promotional"

PROFILE_METRIC_ACCEPTANCE = {
    "local_reproducibility_smoke": [],
    "dql_value_policy_smoke": [
        {"name": "bellman_residual_max", "operator": "<=", "threshold": 0.01},
        {"name": "value_policy_improvement", "operator": ">=", "threshold": 0.0},
    ],
    "fbsde_solver_residual_smoke": [
        {"name": "terminal_residual_max", "operator": "<=", "threshold": 0.02},
        {"name": "pathwise_seed_reused", "operator": "==", "threshold": 1},
    ],
    "dynamic_contracting_counterfactual_smoke": [
        {"name": "incentive_constraint_violation_max", "operator": "<=", "threshold": 0.0},
        {"name": "counterfactual_grid_count", "operator": ">=", "threshold": 1},
    ],
    "robust_control_stability_smoke": [
        {"name": "lyapunov_margin_min", "operator": ">=", "threshold": 0.0},
        {"name": "disturbance_scenario_count", "operator": ">=", "threshold": 1},
    ],
}

EXPERIMENT_PROFILE_REGISTRY = {
    "local_reproducibility_smoke": {
        "domain": "generic",
        "required_outputs": REQUIRED_OUTPUTS,
        "required_data_dependency_kinds": {"recorded_claim_metadata"},
        "required_metric_names": BASE_REQUIRED_METRICS,
    },
    "dql_value_policy_smoke": {
        "domain": "deep_reinforcement_learning",
        "required_outputs": REQUIRED_OUTPUTS,
        "required_data_dependency_kinds": {"recorded_claim_metadata"},
        "required_metric_names": BASE_REQUIRED_METRICS
        | {item["name"] for item in PROFILE_METRIC_ACCEPTANCE["dql_value_policy_smoke"]},
    },
    "fbsde_solver_residual_smoke": {
        "domain": "stochastic_control",
        "required_outputs": REQUIRED_OUTPUTS,
        "required_data_dependency_kinds": {"recorded_claim_metadata"},
        "required_metric_names": BASE_REQUIRED_METRICS
        | {item["name"] for item in PROFILE_METRIC_ACCEPTANCE["fbsde_solver_residual_smoke"]},
    },
    "dynamic_contracting_counterfactual_smoke": {
        "domain": "economic_contracting",
        "required_outputs": REQUIRED_OUTPUTS,
        "required_data_dependency_kinds": {"recorded_claim_metadata"},
        "required_metric_names": BASE_REQUIRED_METRICS
        | {item["name"] for item in PROFILE_METRIC_ACCEPTANCE["dynamic_contracting_counterfactual_smoke"]},
    },
    "robust_control_stability_smoke": {
        "domain": "robust_control",
        "required_outputs": REQUIRED_OUTPUTS,
        "required_data_dependency_kinds": {"recorded_claim_metadata"},
        "required_metric_names": BASE_REQUIRED_METRICS
        | {item["name"] for item in PROFILE_METRIC_ACCEPTANCE["robust_control_stability_smoke"]},
    },
}

ALLOWED_EXPERIMENT_IDS = set(EXPERIMENT_PROFILE_REGISTRY)

FORBIDDEN_SPEC_FLAGS = [
    "allow_network",
    "network_allowed",
    "shell_allowed",
    "cwd_override_allowed",
    "external_action_allowed",
    "source_mutation_allowed",
    "secret_material_read_allowed",
]


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _rows_by_name(metrics):
    result = {}
    for item in (metrics or {}).get("rows") or []:
        if isinstance(item, dict) and item.get("name"):
            result[str(item.get("name"))] = item.get("value")
    return result


def _compare(value, operator, threshold):
    try:
        left = float(value)
        right = float(threshold)
    except (TypeError, ValueError):
        return False
    if operator == "==":
        return left == right
    if operator == ">=":
        return left >= right
    if operator == "<=":
        return left <= right
    if operator == ">":
        return left > right
    if operator == "<":
        return left < right
    return False


def _metric_acceptance_passes(spec, metrics):
    rows = _rows_by_name(metrics)
    for item in spec.get("metric_acceptance") or []:
        if not isinstance(item, dict):
            return False
        name = str(item.get("name") or "")
        operator = str(item.get("operator") or "")
        if name not in rows or not _compare(rows.get(name), operator, item.get("threshold")):
            return False
    return bool(spec.get("metric_acceptance"))


def _dql_smoke_nonpromotion_boundary_passes(metrics, reproducibility):
    metrics = metrics or {}
    reproducibility = reproducibility or {}
    rows = [item for item in metrics.get("rows") or [] if isinstance(item, dict)]
    domain_rows = [
        item
        for item in rows
        if item.get("name") in {"bellman_residual_max", "value_policy_improvement"}
    ]
    common = [
        metrics.get("evidence_maturity") == DQL_NONPROMOTIONAL_EVIDENCE_MATURITY,
        reproducibility.get("evidence_maturity") == DQL_NONPROMOTIONAL_EVIDENCE_MATURITY,
        metrics.get("paper_constant_finalization_state") == DQL_NONPROMOTIONAL_FINALIZATION_STATE,
        reproducibility.get("paper_constant_finalization_state") == DQL_NONPROMOTIONAL_FINALIZATION_STATE,
        metrics.get("promotion_eligible") is False,
        reproducibility.get("promotion_eligible") is False,
        metrics.get("named_input_promotion_allowed") is False,
        reproducibility.get("named_input_promotion_allowed") is False,
        metrics.get("final_signature_present") is False,
        reproducibility.get("final_signature_present") is False,
        bool(domain_rows),
    ]
    row_boundary = all(
        item.get("evidence_maturity") == DQL_NONPROMOTIONAL_EVIDENCE_MATURITY
        and item.get("promotion_eligible") is False
        and item.get("named_input_promotion_allowed") is False
        and item.get("final_signature_present") is False
        for item in domain_rows
    )
    return all(common) and row_boundary


def experiment_profile(profile_id):
    return dict(EXPERIMENT_PROFILE_REGISTRY.get(str(profile_id or "")) or {})


def experiment_metric_acceptance(profile_id):
    profile_metrics = PROFILE_METRIC_ACCEPTANCE.get(str(profile_id or "")) or []
    return [dict(item) for item in BASE_METRIC_ACCEPTANCE + list(profile_metrics)]


def infer_experiment_profile(item):
    text = " ".join(
        str((item or {}).get(key) or "")
        for key in ["slug", "risk_class", "objection", "proposed_fix", "evidence_needed", "verification"]
    ).lower()
    if any(token in text for token in ["dql", "deep q", "q-learning", "bellman", "value policy"]):
        return "dql_value_policy_smoke"
    if any(token in text for token in ["fbsde", "bsde", "backward stochastic"]):
        return "fbsde_solver_residual_smoke"
    if any(token in text for token in ["dynamic contract", "contracting", "principal-agent"]):
        return "dynamic_contracting_counterfactual_smoke"
    if any(token in text for token in ["robust control", "robust_control", "stability"]):
        return "robust_control_stability_smoke"
    return "local_reproducibility_smoke"


def validate_experiment_spec(spec, metrics=None, reproducibility=None, output_paths=None):
    spec = spec or {}
    metrics = metrics or {}
    reproducibility = reproducibility or {}
    output_paths = set(output_paths or [])
    experiment_id = str(spec.get("allowlisted_experiment_id") or spec.get("experiment_profile") or "")
    profile = experiment_profile(experiment_id)
    expected_outputs = set(str(item or "") for item in spec.get("expected_outputs") or [])
    data_dependencies = [item for item in spec.get("data_dependencies") or [] if isinstance(item, dict)]
    metric_acceptance = [item for item in spec.get("metric_acceptance") or [] if isinstance(item, dict)]
    metric_names = {str(item.get("name") or "") for item in metric_acceptance}
    dependency_kinds = {str(item.get("kind") or "") for item in data_dependencies}
    required_outputs = set(profile.get("required_outputs") or REQUIRED_OUTPUTS)
    required_metrics = set(profile.get("required_metric_names") or BASE_REQUIRED_METRICS)
    required_dependency_kinds = set(profile.get("required_data_dependency_kinds") or {"recorded_claim_metadata"})
    checks = [
        _check(
            "experiment_registry_id_allowlisted",
            experiment_id in ALLOWED_EXPERIMENT_IDS,
            "experiment_registry_id_not_allowlisted",
        ),
        _check(
            "experiment_registry_profile_registered",
            bool(profile),
            "experiment_registry_profile_not_registered",
        ),
        _check(
            "experiment_registry_no_network_required",
            spec.get("no_network_required") is True and not any(spec.get(key) for key in FORBIDDEN_SPEC_FLAGS),
            "experiment_registry_network_or_mutation_allowed",
        ),
        _check(
            "experiment_registry_expected_outputs",
            required_outputs.issubset(expected_outputs),
            "experiment_registry_expected_outputs_missing",
        ),
        _check(
            "experiment_registry_output_hashes_present",
            required_outputs.issubset(output_paths),
            "experiment_registry_output_hashes_missing",
        ),
        _check(
            "experiment_registry_profile_required_metrics",
            required_metrics.issubset(metric_names),
            "experiment_registry_profile_required_metrics_missing",
        ),
        _check(
            "experiment_registry_profile_data_dependency_kinds",
            required_dependency_kinds.issubset(dependency_kinds),
            "experiment_registry_profile_data_dependency_kinds_missing",
        ),
        _check(
            "experiment_registry_data_dependencies",
            bool(data_dependencies)
            and all(item.get("name") and item.get("available") is True and not item.get("network_required") for item in data_dependencies),
            "experiment_registry_data_dependencies_missing_or_unsafe",
        ),
        _check(
            "experiment_registry_metric_acceptance",
            bool(metric_acceptance) and all(item.get("name") and item.get("operator") and "threshold" in item for item in metric_acceptance),
            "experiment_registry_metric_acceptance_missing",
        ),
        _check(
            "experiment_registry_metric_acceptance_passed",
            _metric_acceptance_passes(spec, metrics),
            "experiment_registry_metric_acceptance_failed",
        ),
        _check(
            "experiment_registry_deterministic_seed",
            isinstance(spec.get("deterministic_seed"), int),
            "experiment_registry_deterministic_seed_missing",
        ),
        _check(
            "experiment_registry_negative_policy",
            bool(spec.get("negative_or_inconclusive_result_policy")),
            "experiment_registry_negative_policy_missing",
        ),
        _check(
            "experiment_registry_reproducibility_alignment",
            reproducibility.get("allowlisted_experiment_id") == experiment_id
            and reproducibility.get("data_dependency_count") == len(data_dependencies)
            and reproducibility.get("metric_acceptance_count") == len(metric_acceptance)
            and reproducibility.get("metrics_acceptance_passed") is True,
            "experiment_registry_reproducibility_alignment_failed",
        ),
    ]
    if experiment_id == "dql_value_policy_smoke":
        checks.append(
            _check(
                "experiment_registry_dql_smoke_nonpromotion_boundary",
                _dql_smoke_nonpromotion_boundary_passes(metrics, reproducibility),
                "experiment_registry_dql_smoke_nonpromotion_boundary_failed",
            )
        )
    return {
        "allowlisted_experiment_id": experiment_id,
        "experiment_profile_domain": profile.get("domain") or "",
        "registered_experiment_profile_count": len(EXPERIMENT_PROFILE_REGISTRY),
        "required_metric_names": sorted(required_metrics),
        "required_domain_metric_names": sorted(required_metrics - BASE_REQUIRED_METRICS),
        "experiment_spec_ready": all(item.get("passed") for item in checks),
        "checks": checks,
    }
