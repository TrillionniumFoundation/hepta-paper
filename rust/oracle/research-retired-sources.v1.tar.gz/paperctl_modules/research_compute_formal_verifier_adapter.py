"""Validate local formal-verifier certificate artifacts for proof evidence."""

import hashlib
import json
import pathlib
import re
import shutil


ALLOWED_CERTIFICATE_KINDS = {
    "lean",
    "coq",
    "isabelle",
    "other_machine_checked_formal_certificate",
}

FORBIDDEN_CERTIFICATE_FLAGS = [
    "synthetic_certificate_only",
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "network_performed",
    "provider_model_call_performed",
    "commit_performed",
]

LOCAL_PROOF_ARTIFACTS = {
    "proof-notes.md",
    "lemma-checklist.json",
    "formal-verifier-slot.json",
    "proof-check-result.json",
}

FORMAL_VERIFIER_ADAPTERS = {
    "lean": {
        "certificate_kind": "lean",
        "commands": ["lean"],
        "proof_source_extensions": [".lean"],
    },
    "coq": {
        "certificate_kind": "coq",
        "commands": ["coqc"],
        "proof_source_extensions": [".v"],
    },
    "isabelle": {
        "certificate_kind": "isabelle",
        "commands": ["isabelle"],
        "proof_source_extensions": [".thy"],
    },
}

FORMAL_VERIFIER_ADAPTER_CONTRACT_VERSION = "formal_verifier_adapter_v1"
COMMAND = "research-compute-formal-verifier-readiness"
PASS_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_READINESS_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_READINESS_ADAPTER_MISSING"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_readiness_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "formal_verifier_adapter_ready",
    "machine_checked_formal_claim_allowed",
    "local_proof_obligation_fallback_allowed",
    "summary",
    "checks",
    "manifest",
    "contract",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "adapter_count",
    "available_adapter_count",
    "supported_certificate_kind_count",
    "available_certificate_kind_count",
    "formal_verifier_adapter_ready_count",
    "machine_checked_formal_claim_allowed_count",
    "local_proof_obligation_fallback_allowed_count",
    "attention_check_count",
    "failed_check_count",
    "execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Reports local Lean/Coq/Isabelle adapter availability for future machine-checked theorem/proof claims.",
    "This command only checks executable availability; it does not execute provers, read secrets, mutate source, or perform external actions.",
]


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode()).hexdigest()


def _sha256_json(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()
    ).hexdigest()


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_relative_path(value):
    path = pathlib.PurePosixPath(str(value or ""))
    return bool(str(path)) and not path.is_absolute() and ".." not in path.parts and str(path) != "."


def _workspace_file(root, workspace_dir, relative_path):
    if not _safe_relative_path(relative_path):
        return pathlib.Path()
    workspace = (pathlib.Path(root) / str(workspace_dir or "")).resolve()
    candidate = (workspace / str(relative_path)).resolve()
    try:
        candidate.relative_to(workspace)
    except ValueError:
        return pathlib.Path()
    return candidate


def _read_json(path):
    if not path.exists() or not path.is_file():
        return {}
    try:
        return json.loads(path.read_text(errors="ignore"))
    except Exception:
        return {}


def _output_hash_map(report):
    result = {}
    for item in (report or {}).get("output_hashes") or []:
        path = str(item.get("path") or "")
        if path:
            result[path] = str(item.get("sha256") or "")
    return result


def _expected_claim_text(report, packet):
    return str((packet or {}).get("claim_text") or (report or {}).get("selected_claim_text") or "")


def _expected_source_locator(report, packet):
    return str((packet or {}).get("source_locator") or (report or {}).get("selected_source_locator") or "")


def _obligation_names(items):
    names = set()
    for index, item in enumerate(items or [], start=1):
        if isinstance(item, dict):
            name = str(item.get("name") or item.get("id") or "").strip()
        else:
            name = str(item or "").strip()
        names.add(name or f"obligation_{index}")
    return names


def _certificate_obligation_names(certificate):
    names = set()
    names.update(_obligation_names(certificate.get("proof_obligations") or []))
    for key in ["verified_obligations", "obligation_names", "machine_checked_obligations"]:
        for item in certificate.get(key) or []:
            if isinstance(item, dict):
                name = str(item.get("name") or item.get("id") or "").strip()
            else:
                name = str(item or "").strip()
            if name:
                names.add(name)
    return names


def _certificate_formal_statement_contracts(certificate):
    contracts = certificate.get("formal_statement_contracts") or []
    if isinstance(contracts, str):
        contracts = [contracts]
    return [str(item or "").strip() for item in contracts if str(item or "").strip()]


def _statement_contract_theorem_names(contracts):
    names = set()
    for item in contracts or []:
        match = re.search(r"\b(?:theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", str(item or ""))
        if match:
            names.add(match.group(1))
    return names


def _vacuous_true_statement_contracts(contracts):
    result = []
    for item in contracts or []:
        if re.search(r"\b(?:theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*[\s\S]*?:\s*True(?:\s|:=|$)", str(item or "")):
            result.append(item)
    return result


DECLARATION_SIGNATURE_RE = re.compile(
    r"^\s*(?:theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*[\s\S]*?(?::=|where\b)",
    re.M,
)
DECLARATION_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
NEXT_DECL_OR_SCOPE_RE = re.compile(r"^\s*(theorem|lemma|def|structure|class|abbrev|inductive|namespace|section|end)\b")
NAMESPACE_RE = re.compile(r"^\s*namespace\b")
SECTION_RE = re.compile(r"^\s*section\b")
END_RE = re.compile(r"^\s*end\b")


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _normalize_statement_signature(text):
    signature = str(text or "").strip()
    if not signature:
        return ""
    match = DECLARATION_SIGNATURE_RE.search(signature)
    if match:
        signature = match.group(0)
    signature = re.split(r":=|\bwhere\b", signature, maxsplit=1)[0]
    signature = re.sub(r"\s+", " ", signature).strip()
    if not re.match(r"^(?:theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*\b", signature):
        return ""
    if ":" not in signature:
        return ""
    return signature


def _source_statement_signatures(source_text):
    return [
        item["signature"]
        for item in _source_declaration_records(source_text)
        if item.get("signature") and item.get("top_level_namespace")
    ]


def _source_declaration_records(source_text):
    stripped_lean_text = _strip_lean_comments(source_text)
    lines = str(stripped_lean_text or "").splitlines()
    records = []
    scope_stack = []
    for index, line in enumerate(lines):
        match = DECLARATION_RE.match(line)
        if match:
            end = len(lines)
            for later in range(index + 1, len(lines)):
                if NEXT_DECL_OR_SCOPE_RE.match(lines[later]):
                    end = later
                    break
            block = "\n".join(lines[index:end])
            signature = _normalize_statement_signature(block)
            records.append(
                {
                    "kind": match.group(1),
                    "name": match.group(2),
                    "line_start": index + 1,
                    "line_end": end,
                    "signature": signature,
                    "namespace_depth": sum(1 for item in scope_stack if item == "namespace"),
                    "top_level_namespace": not any(item == "namespace" for item in scope_stack),
                }
            )
        if NAMESPACE_RE.match(line):
            scope_stack.append("namespace")
        elif SECTION_RE.match(line):
            scope_stack.append("section")
        elif END_RE.match(line) and scope_stack:
            scope_stack.pop()
    return records


def _certificate_source_path(certificate, proof_check, formal_slot):
    for source in (certificate or {}, proof_check or {}, formal_slot or {}):
        for key in ["lean_source_path", "proof_source_path", "source_artifact_path"]:
            text = str(source.get(key) or "").strip()
            if text:
                return text
    return ""


def _certificate_kind(certificate, formal_slot, proof_check):
    return str(
        certificate.get("certificate_kind")
        or certificate.get("formal_system")
        or proof_check.get("formal_certificate_kind")
        or formal_slot.get("certificate_kind")
        or ""
    ).strip().lower()


def _dict_field(container, key):
    value = (container or {}).get(key)
    return value if isinstance(value, dict) else {}


def _int_field(container, key, default=-1):
    try:
        return int((container or {}).get(key))
    except (TypeError, ValueError):
        return default


def _string_set(values):
    return {str(item or "").strip() for item in values or [] if str(item or "").strip()}


def _accepted_kinds(formal_slot):
    accepted = {
        str(item or "").strip().lower()
        for item in formal_slot.get("accepted_certificate_kinds") or []
        if str(item or "").strip()
    }
    return accepted or set(ALLOWED_CERTIFICATE_KINDS)


def formal_verifier_adapter_manifest(executable_lookup=None):
    """Return a local no-execution manifest for supported formal prover adapters."""

    lookup = executable_lookup or shutil.which
    adapters = []
    available_kinds = []
    for name, spec in FORMAL_VERIFIER_ADAPTERS.items():
        executable_path = ""
        command_name = ""
        for command in spec.get("commands") or []:
            found = lookup(command)
            if found:
                executable_path = str(found)
                command_name = command
                break
        available = bool(executable_path)
        if available:
            available_kinds.append(spec["certificate_kind"])
        adapters.append(
            {
                "adapter_name": name,
                "certificate_kind": spec["certificate_kind"],
                "commands": list(spec.get("commands") or []),
                "selected_command": command_name,
                "executable_path": executable_path,
                "available": available,
                "proof_source_extensions": list(spec.get("proof_source_extensions") or []),
                "execution_performed": False,
                "network_performed": False,
                "secret_material_read_performed": False,
                "source_mutation_performed": False,
                "external_action_performed": False,
            }
        )
    supported_kinds = sorted(spec["certificate_kind"] for spec in FORMAL_VERIFIER_ADAPTERS.values())
    return {
        "adapter_contract_version": FORMAL_VERIFIER_ADAPTER_CONTRACT_VERSION,
        "supported_certificate_kinds": supported_kinds,
        "available_certificate_kinds": sorted(available_kinds),
        "formal_verifier_adapter_ready": bool(available_kinds),
        "adapter_count": len(adapters),
        "available_adapter_count": len(available_kinds),
        "adapters": adapters,
        "execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
    }


def formal_verifier_adapter_contract(formal_slot=None, proof_check=None, executable_lookup=None):
    """Return quality-gate checks for the Lean/Coq/Isabelle adapter boundary."""

    formal_slot = formal_slot or {}
    proof_check = proof_check or {}
    manifest = formal_verifier_adapter_manifest(executable_lookup=executable_lookup)
    accepted = _accepted_kinds(formal_slot)
    supported = set(manifest["supported_certificate_kinds"])
    formal_claimed = bool(
        proof_check.get("formal_verifier_used")
        or proof_check.get("formal_certificate_present")
        or formal_slot.get("formal_verifier_used")
        or formal_slot.get("formal_certificate_present")
    )
    claimed_kind = str(
        proof_check.get("formal_certificate_kind")
        or formal_slot.get("certificate_kind")
        or ""
    ).strip().lower()
    checks = [
        _check(
            "formal_verifier_adapter_manifest_generated",
            manifest.get("adapter_contract_version") == FORMAL_VERIFIER_ADAPTER_CONTRACT_VERSION,
            "formal_verifier_adapter_manifest_missing",
        ),
        _check(
            "formal_verifier_adapter_slot_supports_lean_coq_isabelle",
            supported.issubset(accepted),
            "formal_verifier_adapter_slot_missing_lean_coq_isabelle",
        ),
        _check(
            "formal_verifier_adapter_no_execution_boundary",
            not any(manifest.get(key) for key in FORBIDDEN_CERTIFICATE_FLAGS if key in manifest),
            "formal_verifier_adapter_boundary_failed",
        ),
    ]
    if formal_claimed:
        checks.append(
            _check(
                "formal_verifier_adapter_claimed_kind_supported",
                bool(claimed_kind and claimed_kind in supported),
                "formal_verifier_adapter_claimed_kind_unsupported",
            )
        )
    else:
        checks.append(
            _check(
                "formal_verifier_adapter_missing_certificate_boundary_declared",
                formal_slot.get("formal_verifier_required_before_formal_claim") is True
                and formal_slot.get("proof_notes_are_formal_certificate") is False,
                "formal_verifier_adapter_missing_certificate_boundary_not_declared",
            )
        )
    return {
        "adapter_contract_version": FORMAL_VERIFIER_ADAPTER_CONTRACT_VERSION,
        "formal_verifier_adapter_ready": bool(manifest.get("formal_verifier_adapter_ready")),
        "supported_certificate_kinds": list(manifest.get("supported_certificate_kinds") or []),
        "available_certificate_kinds": list(manifest.get("available_certificate_kinds") or []),
        "checks": checks,
        "manifest": manifest,
    }


def formal_verifier_readiness(label="", executable_lookup=None):
    """Return a report-only readiness packet for local formal prover adapters."""

    formal_slot = {
        "formal_verifier_required_before_formal_claim": True,
        "proof_notes_are_formal_certificate": False,
        "accepted_certificate_kinds": sorted(ALLOWED_CERTIFICATE_KINDS),
    }
    proof_check = {
        "checker_kind": "local_proof_obligation_checker",
        "formal_verifier_used": False,
        "formal_certificate_present": False,
    }
    contract = formal_verifier_adapter_contract(
        formal_slot=formal_slot,
        proof_check=proof_check,
        executable_lookup=executable_lookup,
    )
    manifest = contract.get("manifest") or {}
    adapter_ready = bool(manifest.get("formal_verifier_adapter_ready"))
    availability_check = _check(
        "formal_verifier_adapter_available_for_machine_checked_claims",
        adapter_ready,
        "formal_verifier_adapter_executable_not_found",
        severity="readiness",
    )
    checks = list(contract.get("checks") or []) + [availability_check]
    attention_checks = [item for item in checks if item.get("status") == "ATTENTION"]
    failed_checks = [item for item in checks if item.get("status") == "FAIL"]
    summary = {
        "adapter_count": int(manifest.get("adapter_count") or 0),
        "available_adapter_count": int(manifest.get("available_adapter_count") or 0),
        "supported_certificate_kind_count": len(manifest.get("supported_certificate_kinds") or []),
        "available_certificate_kind_count": len(manifest.get("available_certificate_kinds") or []),
        "formal_verifier_adapter_ready_count": 1 if adapter_ready else 0,
        "machine_checked_formal_claim_allowed_count": 1 if adapter_ready else 0,
        "local_proof_obligation_fallback_allowed_count": 1,
        "attention_check_count": len(attention_checks),
        "failed_check_count": len(failed_checks),
        "execution_performed_count": 1 if manifest.get("execution_performed") else 0,
        "network_performed_count": 1 if manifest.get("network_performed") else 0,
        "external_action_performed_count": 1 if manifest.get("external_action_performed") else 0,
    }
    return {
        "command": COMMAND,
        "status": "PASS" if adapter_ready else "ATTENTION",
        "formal_verifier_readiness_state": PASS_STATE if adapter_ready else ATTENTION_STATE,
        "label": label or "",
        "plan_only": True,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "formal_verifier_adapter_ready": adapter_ready,
        "machine_checked_formal_claim_allowed": adapter_ready,
        "local_proof_obligation_fallback_allowed": True,
        "summary": summary,
        "checks": checks,
        "manifest": manifest,
        "contract": {
            "adapter_contract_version": contract.get("adapter_contract_version") or "",
            "formal_verifier_adapter_ready": bool(contract.get("formal_verifier_adapter_ready")),
            "supported_certificate_kinds": list(contract.get("supported_certificate_kinds") or []),
            "available_certificate_kinds": list(contract.get("available_certificate_kinds") or []),
        },
        "boundary": [
            "This command only checks local formal prover adapter availability.",
            "It does not execute Lean, Coq, Isabelle, or any proof checker.",
            "It does not read secrets, call providers, mutate source/package/archive state, commit, upload, email, or submit.",
            "Local proof-obligation evidence remains allowed as a non-machine-checked fallback until a formal certificate is available.",
        ],
    }


def formal_verifier_readiness_markdown(report):
    lines = [
        "# paper_factory Formal Verifier Readiness",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_readiness_state') or ''}",
        f"- Adapter ready: {report.get('formal_verifier_adapter_ready')}",
        f"- Machine-checked formal claim allowed: {report.get('machine_checked_formal_claim_allowed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Adapters", ""])
    for item in (report.get("manifest") or {}).get("adapters") or []:
        lines.append(
            f"- {item.get('adapter_name')}: available={item.get('available')} "
            f"command={item.get('selected_command') or ''} kind={item.get('certificate_kind') or ''}"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)


def _verified_status(certificate):
    status = str(certificate.get("verifier_status") or certificate.get("status") or "").strip().lower()
    return certificate.get("verified") is True or certificate.get("machine_checked") is True or status == "verified"


def validate_formal_verifier_certificate(report, packet, root, formal_slot=None, proof_check=None):
    """Return check-compatible validation for a declared formal proof certificate."""

    report = report or {}
    packet = packet or {}
    formal_slot = formal_slot or {}
    proof_check = proof_check or {}
    formal_claimed = bool(
        proof_check.get("formal_verifier_used")
        or proof_check.get("formal_certificate_present")
        or formal_slot.get("formal_verifier_used")
        or formal_slot.get("formal_certificate_present")
    )
    if not formal_claimed:
        return {
            "formal_certificate_required": False,
            "formal_certificate_verified": False,
            "formal_verifier_used": False,
            "formal_certificate_present": False,
            "certificate_artifact_path": "",
            "certificate_kind": "",
            "certificate_sha256": "",
            "checks": [],
        }

    checks = []
    workspace_dir = report.get("workspace_dir") or ""
    certificate_path = str(
        proof_check.get("certificate_artifact_path")
        or formal_slot.get("certificate_artifact_path")
        or ""
    )
    checks.append(
        _check(
            "formal_verifier_certificate_path_declared",
            bool(certificate_path),
            "formal_verifier_certificate_path_missing",
        )
    )
    safe_path = _safe_relative_path(certificate_path)
    checks.append(
        _check(
            "formal_verifier_certificate_path_safe",
            safe_path,
            "formal_verifier_certificate_path_unsafe",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_separate_from_local_notes",
            certificate_path not in LOCAL_PROOF_ARTIFACTS,
            "formal_verifier_certificate_must_be_separate_from_local_notes",
        )
    )

    certificate_file = _workspace_file(root, workspace_dir, certificate_path) if safe_path else pathlib.Path()
    certificate = _read_json(certificate_file)
    certificate_sha = _sha256_file(certificate_file) if certificate else ""
    output_hashes = _output_hash_map(report)
    declared_sha = output_hashes.get(certificate_path, "")
    checks.append(
        _check(
            "formal_verifier_certificate_output_hash_recorded",
            bool(declared_sha),
            "formal_verifier_certificate_output_hash_missing",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_output_hash_matches",
            bool(certificate_sha and declared_sha == certificate_sha),
            "formal_verifier_certificate_output_hash_mismatch",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_readable",
            bool(certificate),
            "formal_verifier_certificate_missing_or_unreadable",
        )
    )

    kind = _certificate_kind(certificate, formal_slot, proof_check)
    accepted_kinds = _accepted_kinds(formal_slot)
    checks.append(
        _check(
            "formal_verifier_certificate_kind_accepted",
            bool(kind and kind in accepted_kinds and kind in ALLOWED_CERTIFICATE_KINDS),
            "formal_verifier_certificate_kind_unsupported",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_verified",
            _verified_status(certificate),
            "formal_verifier_certificate_not_verified",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_not_synthetic",
            not certificate.get("synthetic_certificate_only"),
            "formal_verifier_certificate_synthetic_only",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_prover_execution_performed",
            certificate.get("prover_execution_performed") is True,
            "formal_verifier_certificate_prover_execution_missing",
        )
    )

    expected_claim = _expected_claim_text(report, packet)
    certificate_claim = str(certificate.get("claim_text") or "")
    certificate_claim_sha = str(certificate.get("claim_text_sha256") or "")
    checks.append(
        _check(
            "formal_verifier_certificate_claim_alignment",
            bool(
                expected_claim
                and (
                    certificate_claim == expected_claim
                    or certificate_claim_sha == _sha256_text(expected_claim)
                )
            ),
            "formal_verifier_certificate_claim_mismatch",
        )
    )

    expected_source = _expected_source_locator(report, packet)
    certificate_source = str(certificate.get("source_locator") or "")
    checks.append(
        _check(
            "formal_verifier_certificate_source_alignment",
            bool(expected_source and certificate_source == expected_source),
            "formal_verifier_certificate_source_mismatch",
        )
    )

    expected_obligations = _obligation_names(packet.get("proof_obligations") or [])
    certificate_obligations = _certificate_obligation_names(certificate)
    obligation_count = int(certificate.get("machine_checked_obligation_count") or 0)
    formal_statement_contract_count = int(certificate.get("formal_statement_contract_count") or 0)
    formal_statement_contract_source_match_count = int(
        certificate.get("formal_statement_contract_source_match_count") or 0
    )
    formal_statement_contracts = _certificate_formal_statement_contracts(certificate)
    normalized_formal_statement_contracts = [
        item for item in (_normalize_statement_signature(item) for item in formal_statement_contracts) if item
    ]
    formal_statement_contract_theorem_names = _statement_contract_theorem_names(formal_statement_contracts)
    vacuous_true_statement_contracts = _vacuous_true_statement_contracts(formal_statement_contracts)
    certificate_source_path = _certificate_source_path(certificate, proof_check, formal_slot)
    certificate_source_path_safe = _safe_relative_path(certificate_source_path)
    certificate_source_file = (
        _workspace_file(root, workspace_dir, certificate_source_path)
        if certificate_source_path_safe
        else pathlib.Path()
    )
    certificate_source_text = (
        certificate_source_file.read_text(errors="ignore")
        if certificate_source_file.exists() and certificate_source_file.is_file()
        else ""
    )
    certificate_source_sha = _sha256_file(certificate_source_file) if certificate_source_text else ""
    declared_source_sha = output_hashes.get(certificate_source_path, "")
    source_statement_signature_set = set(_source_statement_signatures(certificate_source_text))
    formal_statement_contracts_match_source_text = bool(
        normalized_formal_statement_contracts
        and set(normalized_formal_statement_contracts).issubset(source_statement_signature_set)
    )
    obligation_covered = bool(
        expected_obligations
        and expected_obligations.issubset(certificate_obligations)
        and obligation_count >= len(expected_obligations)
    )
    checks.append(
        _check(
            "formal_verifier_certificate_obligation_coverage",
            obligation_covered,
            "formal_verifier_certificate_obligation_coverage_missing",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_formal_statement_contracts_declared",
            bool(expected_obligations and formal_statement_contract_count >= len(expected_obligations)),
            "formal_verifier_certificate_formal_statement_contracts_missing",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_formal_statement_contracts_list_declared",
            bool(
                expected_obligations
                and len(formal_statement_contracts) >= len(expected_obligations)
                and len(formal_statement_contracts) >= formal_statement_contract_count
            ),
            "formal_verifier_certificate_formal_statement_contracts_list_missing",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_formal_statement_contracts_non_vacuous",
            not bool(vacuous_true_statement_contracts),
            "formal_verifier_certificate_formal_statement_contracts_vacuous_true",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_formal_statement_contracts_matched_source",
            bool(
                formal_statement_contract_count
                and formal_statement_contract_source_match_count >= formal_statement_contract_count
            ),
            "formal_verifier_certificate_formal_statement_contracts_not_matched_source",
        )
    )
    if kind == "lean":
        checks.append(
            _check(
                "formal_verifier_certificate_source_path_declared",
                bool(certificate_source_path),
                "formal_verifier_certificate_source_path_missing",
            )
        )
        checks.append(
            _check(
                "formal_verifier_certificate_source_path_safe",
                bool(certificate_source_path_safe),
                "formal_verifier_certificate_source_path_unsafe",
            )
        )
        checks.append(
            _check(
                "formal_verifier_certificate_source_output_hash_recorded",
                bool(declared_source_sha),
                "formal_verifier_certificate_source_output_hash_missing",
            )
        )
        checks.append(
            _check(
                "formal_verifier_certificate_source_output_hash_matches",
                bool(certificate_source_sha and declared_source_sha == certificate_source_sha),
                "formal_verifier_certificate_source_output_hash_mismatch",
            )
        )
        checks.append(
            _check(
                "formal_verifier_certificate_formal_statement_contracts_match_source_text",
                formal_statement_contracts_match_source_text,
                "formal_verifier_certificate_formal_statement_contracts_not_found_in_source_text",
            )
        )

    theorem_names = certificate.get("theorem_names") or []
    if isinstance(theorem_names, str):
        theorem_names = [theorem_names]
    expected_theorem_names = certificate.get("expected_theorem_names") or []
    if isinstance(expected_theorem_names, str):
        expected_theorem_names = [expected_theorem_names]
    theorem_name_set = {str(item or "").strip() for item in theorem_names if str(item or "").strip()}
    expected_theorem_name_set = {str(item or "").strip() for item in expected_theorem_names if str(item or "").strip()}
    obligation_name_list = sorted(expected_obligations)
    expected_theorem_name_list = sorted(expected_theorem_name_set)
    normalized_contract_hash = _sha256_json(normalized_formal_statement_contracts)
    expected_theorem_hash = _sha256_json(expected_theorem_name_list)
    obligation_hash = _sha256_json(obligation_name_list)
    authority_record = _dict_field(certificate, "authority_record")
    pinned_input = _dict_field(certificate, "pinned_verifier_input")
    source_binding = _dict_field(certificate, "source_binding")
    verifier_name = str(certificate.get("verifier") or kind or "").strip().lower()
    expected_claim_sha = _sha256_text(expected_claim)

    authority_record_declared = bool(authority_record)
    authority_kind_ok = authority_record.get("authority_kind") == "local_formal_verifier_execution"
    authority_identity_ok = bool(
        authority_record.get("certificate_kind") == kind
        and str(authority_record.get("verifier") or "").strip().lower() == verifier_name
        and authority_record.get("verification_status") == "verified"
        and authority_record.get("prover_execution_performed") is True
        and _int_field(authority_record, "execution_exit_code") == 0
    )
    authority_boundary_ok = not any(authority_record.get(key) for key in FORBIDDEN_CERTIFICATE_FLAGS)
    authority_record_verified = bool(
        authority_record_declared and authority_kind_ok and authority_identity_ok and authority_boundary_ok
    )

    pinned_input_declared = bool(pinned_input)
    pinned_source_ok = bool(
        pinned_input.get("proof_source_path") == certificate_source_path
        and pinned_input.get("proof_source_sha256") == certificate_source_sha
        and pinned_input.get("certificate_artifact_path") == certificate_path
        and str(pinned_input.get("verifier") or "").strip().lower() == verifier_name
    )
    pinned_claim_ok = bool(
        pinned_input.get("claim_text_sha256") == expected_claim_sha
        and pinned_input.get("source_locator") == expected_source
    )
    pinned_contract_ok = bool(
        pinned_input.get("formal_statement_contracts_sha256") == normalized_contract_hash
        and pinned_input.get("expected_theorem_names_sha256") == expected_theorem_hash
        and pinned_input.get("obligation_names_sha256") == obligation_hash
    )
    pinned_input_verified = bool(pinned_input_declared and pinned_source_ok and pinned_claim_ok and pinned_contract_ok)

    source_binding_declared = bool(source_binding)
    source_binding_claim_ok = bool(
        source_binding.get("claim_text_sha256") == expected_claim_sha
        and source_binding.get("source_locator") == expected_source
    )
    source_binding_source_ok = bool(
        source_binding.get("proof_source_path") == certificate_source_path
        and source_binding.get("proof_source_sha256") == certificate_source_sha
    )
    source_binding_contract_ok = source_binding.get("formal_statement_contracts_sha256") == normalized_contract_hash
    source_binding_theorem_ok = source_binding.get("expected_theorem_names_sha256") == expected_theorem_hash
    source_binding_obligation_ok = source_binding.get("obligation_names_sha256") == obligation_hash
    source_binding_verified = bool(
        source_binding_declared
        and source_binding_claim_ok
        and source_binding_source_ok
        and source_binding_contract_ok
        and source_binding_theorem_ok
        and source_binding_obligation_ok
    )
    checks.append(
        _check(
            "formal_verifier_certificate_theorem_names",
            bool(theorem_name_set),
            "formal_verifier_certificate_theorem_names_missing",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_expected_theorem_names_declared",
            bool(expected_theorem_name_set and expected_theorem_name_set.issubset(theorem_name_set)),
            "formal_verifier_certificate_expected_theorem_names_missing",
        )
    )
    checks.append(
        _check(
            "formal_verifier_certificate_expected_theorem_contracts_declared",
            bool(
                expected_theorem_name_set
                and expected_theorem_name_set.issubset(formal_statement_contract_theorem_names)
            ),
            "formal_verifier_certificate_expected_theorem_contracts_missing",
        )
    )
    checks.extend(
        [
            _check(
                "formal_verifier_certificate_authority_record_declared",
                authority_record_declared,
                "formal_verifier_certificate_authority_record_missing",
            ),
            _check(
                "formal_verifier_certificate_authority_record_kind",
                authority_kind_ok,
                "formal_verifier_certificate_authority_record_kind_mismatch",
            ),
            _check(
                "formal_verifier_certificate_authority_record_matches_certificate",
                authority_identity_ok,
                "formal_verifier_certificate_authority_record_identity_mismatch",
            ),
            _check(
                "formal_verifier_certificate_authority_record_boundary",
                authority_boundary_ok,
                "formal_verifier_certificate_authority_record_boundary_failed",
            ),
            _check(
                "formal_verifier_certificate_pinned_verifier_input_declared",
                pinned_input_declared,
                "formal_verifier_certificate_pinned_verifier_input_missing",
            ),
            _check(
                "formal_verifier_certificate_pinned_verifier_input_matches_source",
                pinned_source_ok,
                "formal_verifier_certificate_pinned_verifier_input_source_mismatch",
            ),
            _check(
                "formal_verifier_certificate_pinned_verifier_input_matches_claim",
                pinned_claim_ok,
                "formal_verifier_certificate_pinned_verifier_input_claim_mismatch",
            ),
            _check(
                "formal_verifier_certificate_pinned_verifier_input_matches_contracts",
                pinned_contract_ok,
                "formal_verifier_certificate_pinned_verifier_input_contract_mismatch",
            ),
            _check(
                "formal_verifier_certificate_source_binding_declared",
                source_binding_declared,
                "formal_verifier_certificate_source_binding_missing",
            ),
            _check(
                "formal_verifier_certificate_source_binding_matches_claim",
                source_binding_claim_ok,
                "formal_verifier_certificate_source_binding_claim_mismatch",
            ),
            _check(
                "formal_verifier_certificate_source_binding_matches_source",
                source_binding_source_ok,
                "formal_verifier_certificate_source_binding_source_mismatch",
            ),
            _check(
                "formal_verifier_certificate_source_binding_matches_contracts",
                source_binding_contract_ok,
                "formal_verifier_certificate_source_binding_contract_mismatch",
            ),
            _check(
                "formal_verifier_certificate_source_binding_matches_theorems",
                source_binding_theorem_ok,
                "formal_verifier_certificate_source_binding_theorem_mismatch",
            ),
            _check(
                "formal_verifier_certificate_source_binding_matches_obligations",
                source_binding_obligation_ok,
                "formal_verifier_certificate_source_binding_obligation_mismatch",
            ),
        ]
    )
    checks.append(
        _check(
            "formal_verifier_certificate_safety_boundary",
            not any(certificate.get(key) for key in FORBIDDEN_CERTIFICATE_FLAGS),
            "formal_verifier_certificate_safety_boundary_failed",
        )
    )

    verified = bool(checks) and all(item.get("passed") for item in checks)
    return {
        "formal_certificate_required": True,
        "formal_certificate_verified": verified,
        "formal_verifier_used": verified,
        "formal_certificate_present": verified,
        "certificate_artifact_path": certificate_path if verified else "",
        "certificate_kind": kind if verified else "",
        "certificate_sha256": certificate_sha if verified else "",
        "certificate_authority_record_verified": authority_record_verified,
        "pinned_verifier_input_verified": pinned_input_verified,
        "certificate_source_binding_verified": source_binding_verified,
        "certificate_authority_record": authority_record,
        "pinned_verifier_input": pinned_input,
        "certificate_source_binding": source_binding,
        "checks": checks,
    }
