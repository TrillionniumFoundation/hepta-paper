"""Report-only install/diagnostic plan for formal verifier adapters."""

import shutil

from paperctl_modules import research_compute_formal_verifier_adapter


COMMAND = "research-compute-formal-verifier-adapter-install-plan"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_ADAPTER_INSTALL_PLAN_ADAPTER_READY"
PLAN_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_ADAPTER_INSTALL_PLAN_READY"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_adapter_install_plan_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "install_execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "formal_verifier_adapter_ready",
    "machine_checked_formal_claim_allowed",
    "recommended_route",
    "recommended_next_command",
    "summary",
    "checks",
    "manifest",
    "install_tool_diagnostics",
    "install_routes",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "adapter_count",
    "available_adapter_count",
    "missing_adapter_count",
    "install_tool_count",
    "candidate_route_count",
    "recommended_route_count",
    "lean_route_count",
    "coq_route_count",
    "isabelle_route_count",
    "install_execution_performed_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Reports local formal verifier adapter availability and installation route candidates.",
    "This command is plan-only: it does not install packages, execute provers, fetch network resources, mutate source, read secrets, submit, email, upload, or commit.",
]

INSTALL_TOOLS = {
    "elan": {"commands": ["elan"], "route_tags": ["lean"]},
    "opam": {"commands": ["opam"], "route_tags": ["coq"]},
    "nix": {"commands": ["nix"], "route_tags": ["lean", "coq", "isabelle"]},
    "apt": {"commands": ["apt-get", "apt"], "route_tags": ["coq"]},
    "conda": {"commands": ["conda", "mamba", "micromamba"], "route_tags": ["lean", "coq"]},
    "brew": {"commands": ["brew"], "route_tags": ["lean", "coq", "isabelle"]},
}


def _check(name, passed, detail="", severity="readiness"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _first_available(commands, executable_lookup):
    for command in commands:
        found = executable_lookup(command)
        if found:
            return command, str(found)
    return "", ""


def install_tool_diagnostics(executable_lookup=None):
    lookup = executable_lookup or shutil.which
    diagnostics = []
    for name, spec in INSTALL_TOOLS.items():
        command, path = _first_available(spec["commands"], lookup)
        diagnostics.append(
            {
                "tool": name,
                "commands": list(spec["commands"]),
                "selected_command": command,
                "executable_path": path,
                "available": bool(path),
                "route_tags": list(spec["route_tags"]),
            }
        )
    return diagnostics


def _tool_available(diagnostics, tool):
    for item in diagnostics:
        if item["tool"] == tool and item["available"]:
            return True
    return False


def _route(adapter, route_id, install_tool, command, notes, auto_execute=False):
    return {
        "adapter_name": adapter,
        "route_id": route_id,
        "install_tool": install_tool,
        "command": command,
        "available_locally": bool(install_tool == "manual" or install_tool == "documented_only"),
        "install_tool_available": install_tool in {"manual", "documented_only"} or bool(install_tool),
        "auto_execute": bool(auto_execute),
        "recommended": False,
        "notes": notes,
        "install_execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "external_action_performed": False,
    }


def install_routes(diagnostics):
    routes = []
    if _tool_available(diagnostics, "elan"):
        routes.append(
            _route(
                "lean",
                "lean_elan_stable",
                "elan",
                "elan toolchain install stable && elan default stable",
                "Preferred local Lean route when elan is already installed.",
            )
        )
    if _tool_available(diagnostics, "nix"):
        routes.append(_route("lean", "lean_nix_shell", "nix", "nix shell nixpkgs#lean4", "Nix ephemeral Lean shell."))
        routes.append(_route("coq", "coq_nix_shell", "nix", "nix shell nixpkgs#coq", "Nix ephemeral Coq shell."))
        routes.append(_route("isabelle", "isabelle_nix_shell", "nix", "nix shell nixpkgs#isabelle", "Nix ephemeral Isabelle shell."))
    if _tool_available(diagnostics, "opam"):
        routes.append(_route("coq", "coq_opam", "opam", "opam install coq", "Preferred Coq route when opam is already installed."))
    if _tool_available(diagnostics, "apt"):
        routes.append(_route("coq", "coq_apt", "apt", "sudo apt-get update && sudo apt-get install -y coq", "System package route; requires explicit system package mutation approval."))
    if _tool_available(diagnostics, "conda"):
        routes.append(_route("lean", "lean_conda", "conda", "conda install -c conda-forge lean", "Conda Lean route if available."))
        routes.append(_route("coq", "coq_conda", "conda", "conda install -c conda-forge coq", "Conda Coq route if available."))
    if _tool_available(diagnostics, "brew"):
        routes.append(_route("lean", "lean_brew", "brew", "brew install lean", "Homebrew Lean route."))
        routes.append(_route("coq", "coq_brew", "brew", "brew install coq", "Homebrew Coq route."))
        routes.append(_route("isabelle", "isabelle_brew", "brew", "brew install --cask isabelle", "Homebrew Isabelle route."))
    routes.append(
        _route(
            "isabelle",
            "isabelle_manual_download",
            "manual",
            "download Isabelle from the official distribution and add its bin directory to PATH",
            "Manual route documented for environments without package managers; not auto-executable.",
        )
    )
    return routes


def _select_route(routes, manifest):
    missing = [
        item["adapter_name"]
        for item in manifest.get("adapters") or []
        if not item.get("available")
    ]
    preference = ["lean", "coq", "isabelle"]
    for adapter in preference:
        if adapter not in missing:
            continue
        for route in routes:
            if route.get("adapter_name") == adapter and route.get("install_tool") not in {"manual", "documented_only"}:
                route["recommended"] = True
                return route
    for route in routes:
        if route.get("adapter_name") in missing:
            route["recommended"] = True
            return route
    return {}


def formal_verifier_adapter_install_plan(label="", executable_lookup=None):
    lookup = executable_lookup or shutil.which
    manifest = research_compute_formal_verifier_adapter.formal_verifier_adapter_manifest(
        executable_lookup=lookup
    )
    diagnostics = install_tool_diagnostics(executable_lookup=lookup)
    routes = install_routes(diagnostics)
    recommended = _select_route(routes, manifest)
    adapter_ready = bool(manifest.get("formal_verifier_adapter_ready"))
    checks = [
        _check(
            "formal_verifier_adapter_manifest_generated",
            manifest.get("adapter_contract_version")
            == research_compute_formal_verifier_adapter.FORMAL_VERIFIER_ADAPTER_CONTRACT_VERSION,
            "formal_verifier_adapter_manifest_missing",
        ),
        _check(
            "formal_verifier_adapter_available",
            adapter_ready,
            "formal_verifier_adapter_executable_not_found",
        ),
        _check(
            "formal_verifier_install_route_available",
            bool(routes),
            "formal_verifier_install_route_missing",
        ),
    ]
    missing_adapter_count = sum(1 for item in manifest.get("adapters") or [] if not item.get("available"))
    install_tool_count = sum(1 for item in diagnostics if item.get("available"))
    recommended_count = 1 if recommended else 0
    status = "PASS" if adapter_ready else "ATTENTION"
    state = READY_STATE if adapter_ready else PLAN_STATE
    return {
        "command": COMMAND,
        "status": status,
        "formal_verifier_adapter_install_plan_state": state,
        "label": label or "",
        "plan_only": True,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "install_execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "formal_verifier_adapter_ready": adapter_ready,
        "machine_checked_formal_claim_allowed": adapter_ready,
        "recommended_route": recommended,
        "recommended_next_command": recommended.get("command") if recommended else "",
        "summary": {
            "adapter_count": int(manifest.get("adapter_count") or 0),
            "available_adapter_count": int(manifest.get("available_adapter_count") or 0),
            "missing_adapter_count": missing_adapter_count,
            "install_tool_count": install_tool_count,
            "candidate_route_count": len(routes),
            "recommended_route_count": recommended_count,
            "lean_route_count": sum(1 for route in routes if route.get("adapter_name") == "lean"),
            "coq_route_count": sum(1 for route in routes if route.get("adapter_name") == "coq"),
            "isabelle_route_count": sum(1 for route in routes if route.get("adapter_name") == "isabelle"),
            "install_execution_performed_count": 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
        },
        "checks": checks,
        "manifest": manifest,
        "install_tool_diagnostics": diagnostics,
        "install_routes": routes,
        "boundary": [
            "This command is a local diagnostic and installation plan only.",
            "It checks PATH for executables and package-manager tools but does not run package managers, fetch network resources, install packages, or execute provers.",
            "It does not mutate source/package/archive state, enqueue or merge patches, read secrets, call providers, upload, email, submit, send Telegram, or commit.",
            "A later install/apply command must be separately reviewed before any system package, network, or prover execution is performed.",
        ],
    }


def formal_verifier_adapter_install_plan_markdown(report):
    lines = [
        "# paper_factory Formal Verifier Adapter Install Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_adapter_install_plan_state') or ''}",
        f"- Adapter ready: {report.get('formal_verifier_adapter_ready')}",
        f"- Recommended next command: `{report.get('recommended_next_command') or ''}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Routes", ""])
    for item in report.get("install_routes") or []:
        marker = " recommended" if item.get("recommended") else ""
        lines.append(
            f"- `{item.get('route_id')}`{marker}: adapter={item.get('adapter_name')} tool={item.get('install_tool')} command=`{item.get('command')}`"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
