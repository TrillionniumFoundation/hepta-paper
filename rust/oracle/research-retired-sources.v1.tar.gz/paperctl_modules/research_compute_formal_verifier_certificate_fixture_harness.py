"""Local fixture harness for the formal verifier certificate intake path."""

import hashlib
import json
import pathlib

from paperctl_modules import research_compute_formal_verifier_certificate_intake


COMMAND = "research-compute-formal-verifier-certificate-fixture-harness"
PASS_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_CERTIFICATE_FIXTURE_HARNESS_PASS"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_CERTIFICATE_FIXTURE_HARNESS_FAILED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_certificate_fixture_harness_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "fixture_artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "fixture_harness_ready",
    "certificate_intake_accepted",
    "machine_checked_formal_claim_allowed",
    "synthetic_certificate_only",
    "fixture_root",
    "fixture_workspace_dir",
    "fixture_evidence_report_path",
    "fixture_certificate_path",
    "summary",
    "checks",
    "validation_issues",
    "fixture_evidence_report",
    "certificate_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "fixture_artifact_count",
    "fixture_harness_ready_count",
    "certificate_intake_accepted_count",
    "certificate_intake_issue_count",
    "validation_issue_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Generates a local synthetic certificate artifact and feeds it through formal-verifier certificate intake.",
    "This command is a fixture harness only; synthetic certificates must be rejected as production machine-checked proof evidence.",
    "This command does not execute Lean, Coq, Isabelle, mutate source, read secrets, upload, email, submit, or commit.",
]

CLAIM_TEXT = "For every admissible policy, the profiled estimator is consistent."
SOURCE_LOCATOR = "paper.tex:120"
PROOF_OBLIGATIONS = [
    {"name": "claim_alignment", "status": "machine_checked_fixture"},
    {"name": "proof_obligation_trace", "status": "machine_checked_fixture"},
]


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode()).hexdigest()


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_json(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True))
    return {
        "path": str(path),
        "sha256": _sha256_file(path),
        "bytes": path.stat().st_size,
    }


def _check(name, passed, detail=""):
    return {
        "name": name,
        "status": "PASS" if passed else "FAIL",
        "passed": bool(passed),
        "detail": "" if passed else detail,
    }


def _fixture_payloads():
    formal_slot = {
        "slot_kind": "formal_verifier_certificate_slot",
        "formal_verifier_required_before_formal_claim": True,
        "proof_notes_are_formal_certificate": False,
        "accepted_certificate_kinds": [
            "lean",
            "coq",
            "isabelle",
            "other_machine_checked_formal_certificate",
        ],
        "formal_verifier_used": True,
        "formal_certificate_present": True,
        "certificate_kind": "lean",
        "certificate_artifact_path": "formal-verifier-certificate.json",
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }
    proof_check = {
        "checker_kind": "formal_theorem_prover",
        "formal_verifier_slot_path": "formal-verifier-slot.json",
        "formal_verifier_used": True,
        "formal_certificate_present": True,
        "formal_certificate_kind": "lean",
        "certificate_artifact_path": "formal-verifier-certificate.json",
        "machine_checked_obligation_count": len(PROOF_OBLIGATIONS),
        "automated_claim_finalization_ready": True,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
        "limitations": ["synthetic fixture certificate; no prover was executed"],
    }
    certificate = {
        "certificate_kind": "lean",
        "verifier": "lean",
        "verifier_status": "verified",
        "verified": True,
        "machine_checked": True,
        "synthetic_certificate_only": True,
        "prover_execution_performed": False,
        "claim_text": CLAIM_TEXT,
        "claim_text_sha256": _sha256_text(CLAIM_TEXT),
        "source_locator": SOURCE_LOCATOR,
        "proof_obligations": PROOF_OBLIGATIONS,
        "verified_obligations": [item["name"] for item in PROOF_OBLIGATIONS],
        "machine_checked_obligation_count": len(PROOF_OBLIGATIONS),
        "formal_statement_contract_count": len(PROOF_OBLIGATIONS),
        "formal_statement_contract_source_match_count": len(PROOF_OBLIGATIONS),
        "theorem_names": ["ProfiledEstimatorConsistencyFixture"],
        "expected_theorem_names": ["ProfiledEstimatorConsistencyFixture"],
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
        "provider_model_call_performed": False,
        "commit_performed": False,
    }
    return formal_slot, proof_check, certificate


def formal_verifier_certificate_fixture_harness(root, label=""):
    root = pathlib.Path(root)
    workspace = root / "formal-verifier-certificate-fixture-workspace"
    formal_slot, proof_check, certificate = _fixture_payloads()
    slot_info = _write_json(workspace / "formal-verifier-slot.json", formal_slot)
    proof_info = _write_json(workspace / "proof-check-result.json", proof_check)
    certificate_info = _write_json(workspace / "formal-verifier-certificate.json", certificate)
    evidence_report = {
        "command": "research-compute-claim-evidence-execution",
        "status": "PASS",
        "selected_claim_kind": "theorem_or_proof",
        "workspace_dir": "formal-verifier-certificate-fixture-workspace",
        "output_hashes": [
            {"path": "formal-verifier-slot.json", "sha256": slot_info["sha256"], "bytes": slot_info["bytes"]},
            {"path": "proof-check-result.json", "sha256": proof_info["sha256"], "bytes": proof_info["bytes"]},
            {"path": "formal-verifier-certificate.json", "sha256": certificate_info["sha256"], "bytes": certificate_info["bytes"]},
        ],
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "selected_claim_packet": {
            "claim_packet_id": "formal-verifier-certificate-fixture-claim",
            "slug": "Formal_Verifier_Certificate_Fixture",
            "claim_kind": "theorem_or_proof",
            "claim_text": CLAIM_TEXT,
            "source_locator": SOURCE_LOCATOR,
            "proof_obligations": PROOF_OBLIGATIONS,
        },
    }
    evidence_info = _write_json(root / "formal-verifier-certificate-fixture-evidence-execution.json", evidence_report)
    evidence_report["report_path"] = evidence_info["path"]
    evidence_report["report_sha256"] = evidence_info["sha256"]
    certificate_intake = research_compute_formal_verifier_certificate_intake.formal_verifier_certificate_intake(
        evidence_report,
        root=str(root),
        label=label or "",
    )
    intake_accepted = bool(
        certificate_intake.get("status") == "PASS"
        and certificate_intake.get("formal_certificate_verified")
        and certificate_intake.get("machine_checked_formal_claim_allowed")
    )
    synthetic_rejected = bool(
        certificate_intake.get("status") == "ATTENTION"
        and not certificate_intake.get("formal_certificate_verified")
        and not certificate_intake.get("machine_checked_formal_claim_allowed")
    )
    checks = [
        _check("fixture_formal_slot_written", pathlib.Path(slot_info["path"]).exists(), "formal_slot_missing"),
        _check("fixture_proof_check_written", pathlib.Path(proof_info["path"]).exists(), "proof_check_missing"),
        _check("fixture_certificate_written", pathlib.Path(certificate_info["path"]).exists(), "certificate_missing"),
        _check("certificate_intake_rejects_synthetic_fixture", synthetic_rejected, "synthetic_fixture_certificate_was_accepted"),
        _check("fixture_no_prover_execution", True, ""),
        _check("fixture_no_external_action", not certificate_intake.get("external_action_performed"), "external_action_performed"),
    ]
    validation_issues = [
        {"issue": check["detail"] or check["name"]}
        for check in checks
        if check.get("status") != "PASS"
    ]
    status = "PASS" if not validation_issues else "FAIL"
    state = PASS_STATE if status == "PASS" else FAILED_STATE
    return {
        "command": COMMAND,
        "status": status,
        "formal_verifier_certificate_fixture_harness_state": state,
        "label": label or "",
        "plan_only": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "fixture_artifact_write_performed": True,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "fixture_harness_ready": status == "PASS",
        "certificate_intake_accepted": intake_accepted,
        "machine_checked_formal_claim_allowed": False,
        "synthetic_certificate_only": True,
        "fixture_root": str(root),
        "fixture_workspace_dir": str(workspace),
        "fixture_evidence_report_path": evidence_info["path"],
        "fixture_certificate_path": certificate_info["path"],
        "summary": {
            "fixture_artifact_count": 4,
            "fixture_harness_ready_count": 1 if status == "PASS" else 0,
            "certificate_intake_accepted_count": 1 if intake_accepted else 0,
            "certificate_intake_issue_count": int((certificate_intake.get("summary") or {}).get("certificate_issue_count") or 0),
            "validation_issue_count": len(validation_issues),
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "fixture_evidence_report": evidence_report,
        "certificate_intake_report": certificate_intake,
        "boundary": [
            "This command is a local synthetic fixture harness for the certificate intake path.",
            "It writes fixture artifacts under the command batch directory and validates that production certificate intake rejects synthetic certificates.",
            "It does not execute Lean, Coq, Isabelle, or any proof checker; synthetic_certificate_only remains true.",
            "It does not mutate paper sources, packages, archives, patch queues, or commits, and it does not upload, email, submit, read secrets, call providers, or send Telegram.",
        ],
    }


def formal_verifier_certificate_fixture_harness_markdown(report):
    lines = [
        "# paper_factory Formal Verifier Certificate Fixture Harness",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_certificate_fixture_harness_state') or ''}",
        f"- Certificate intake accepted: {report.get('certificate_intake_accepted')}",
        f"- Synthetic certificate only: {report.get('synthetic_certificate_only')}",
        f"- Prover execution performed: {report.get('prover_execution_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for item in report.get("checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
