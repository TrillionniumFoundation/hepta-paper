"""Standalone intake gate for machine-checked formal verifier certificates."""

from paperctl_modules import report_ref_health, research_compute_formal_verifier_adapter


COMMAND = "research-compute-formal-verifier-certificate-intake"
EVIDENCE_EXECUTION_COMMAND = "research-compute-claim-evidence-execution"
EVIDENCE_EXECUTION_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN
ACCEPTED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_CERTIFICATE_INTAKE_ACCEPTED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_CERTIFICATE_INTAKE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_CERTIFICATE_INTAKE_FAILED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_certificate_intake_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "formal_certificate_required",
    "formal_certificate_verified",
    "formal_verifier_used",
    "machine_checked_formal_claim_allowed",
    "local_proof_obligation_fallback_detected",
    "certificate_artifact_path",
    "certificate_kind",
    "certificate_sha256",
    "certificate_authority_record_verified",
    "pinned_verifier_input_verified",
    "certificate_source_binding_verified",
    "evidence_execution_report_path",
    "workspace_root",
    "summary",
    "checks",
    "validation_issues",
    "certificate_validation",
    "evidence_ref",
    "evidence_ref_health",
    "selected_claim_packet",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "certificate_check_count",
    "certificate_issue_count",
    "formal_certificate_required_count",
    "formal_certificate_verified_count",
    "formal_verifier_used_count",
    "machine_checked_formal_claim_allowed_count",
    "local_proof_obligation_fallback_detected_count",
    "certificate_authority_record_verified_count",
    "pinned_verifier_input_verified_count",
    "certificate_source_binding_verified_count",
    "evidence_execution_report_validation_issue_count",
    "forbidden_boundary_count",
    "execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Reads one local claim evidence-execution report and validates any declared machine-checked formal certificate artifact.",
    "This command does not execute Lean, Coq, Isabelle, mutate source, read secrets, call providers, upload, email, submit, or commit.",
]
FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _read_json_file(root, workspace_dir, relative_path):
    if not workspace_dir or not relative_path:
        return {}
    return research_compute_formal_verifier_adapter._read_json(
        research_compute_formal_verifier_adapter._workspace_file(root, workspace_dir, relative_path)
    )


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _forbidden_issues(report):
    issues = []
    for key in FORBIDDEN_KEYS:
        if (report or {}).get(key):
            issues.append({"issue": f"forbidden_evidence_execution_boundary:{key}"})
    return issues


def _base_report(
    label,
    status,
    state,
    validation_issues,
    checks=None,
    certificate_validation=None,
    evidence_report=None,
    evidence_ref_health=None,
):
    certificate_validation = certificate_validation or {}
    checks = list(checks or [])
    issue_checks = [item for item in checks if item.get("status") != "PASS"]
    forbidden_count = sum(
        1
        for item in validation_issues or []
        if str(item.get("issue") or "").startswith("forbidden_")
    )
    verified = bool(certificate_validation.get("formal_certificate_verified"))
    required = bool(certificate_validation.get("formal_certificate_required"))
    formal_used = bool(certificate_validation.get("formal_verifier_used"))
    authority_verified = bool(certificate_validation.get("certificate_authority_record_verified"))
    pinned_verified = bool(certificate_validation.get("pinned_verifier_input_verified"))
    source_binding_verified = bool(certificate_validation.get("certificate_source_binding_verified"))
    local_fallback = bool(
        evidence_report
        and not formal_used
        and (
            (evidence_report or {}).get("selected_claim_kind") == "theorem_or_proof"
            or ((evidence_report or {}).get("selected_claim_packet") or {}).get("claim_kind") == "theorem_or_proof"
        )
    )
    return {
        "command": COMMAND,
        "status": status,
        "formal_verifier_certificate_intake_state": state,
        "label": label or "",
        "plan_only": True,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "formal_certificate_required": required,
        "formal_certificate_verified": verified,
        "formal_verifier_used": formal_used,
        "machine_checked_formal_claim_allowed": verified,
        "local_proof_obligation_fallback_detected": local_fallback,
        "certificate_artifact_path": certificate_validation.get("certificate_artifact_path") or "",
        "certificate_kind": certificate_validation.get("certificate_kind") or "",
        "certificate_sha256": certificate_validation.get("certificate_sha256") or "",
        "certificate_authority_record_verified": authority_verified,
        "pinned_verifier_input_verified": pinned_verified,
        "certificate_source_binding_verified": source_binding_verified,
        "summary": {
            "validation_issue_count": len(validation_issues or []),
            "certificate_check_count": len(checks),
            "certificate_issue_count": len(issue_checks),
            "formal_certificate_required_count": 1 if required else 0,
            "formal_certificate_verified_count": 1 if verified else 0,
            "formal_verifier_used_count": 1 if formal_used else 0,
            "machine_checked_formal_claim_allowed_count": 1 if verified else 0,
            "local_proof_obligation_fallback_detected_count": 1 if local_fallback else 0,
            "certificate_authority_record_verified_count": 1 if authority_verified else 0,
            "pinned_verifier_input_verified_count": 1 if pinned_verified else 0,
            "certificate_source_binding_verified_count": 1 if source_binding_verified else 0,
            "evidence_execution_report_validation_issue_count": sum(
                1
                for item in validation_issues or []
                if str(item.get("issue") or "").startswith("claim_evidence_execution_")
            ),
            "forbidden_boundary_count": forbidden_count,
            "execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": list(validation_issues or []),
        "certificate_validation": certificate_validation,
        "evidence_ref": {
            "command": (evidence_report or {}).get("command") or "",
            "status": (evidence_report or {}).get("status") or "",
            "created_at": (evidence_report or {}).get("created_at") or "",
            "report_path": (evidence_report or {}).get("report_path") or "",
            "report_sha256": (evidence_report or {}).get("report_sha256") or "",
            "workspace_dir": (evidence_report or {}).get("workspace_dir") or "",
            "selected_claim_kind": (evidence_report or {}).get("selected_claim_kind") or "",
        },
        "evidence_ref_health": evidence_ref_health or {},
        "selected_claim_packet": (evidence_report or {}).get("selected_claim_packet") or {},
        "boundary": [
            "This intake reads only local evidence report metadata and local workspace certificate artifacts.",
            "It does not execute Lean, Coq, Isabelle, or any proof checker.",
            "It does not mutate source/package/archive state, enqueue or merge patches, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
            "Local proof-obligation evidence remains non-machine-checked unless this command verifies a separate formal certificate artifact.",
        ],
    }


def formal_verifier_certificate_intake(evidence_execution_report=None, root=".", label=""):
    report = evidence_execution_report or {}
    validation_issues = []
    if not report:
        validation_issues.append({"issue": "claim_evidence_execution_report_missing"})
        return _base_report(label, "ATTENTION", ATTENTION_STATE, validation_issues)
    evidence_ref_issues, evidence_ref_health = report_ref_health.consumed_report_ref_issues(
        "claim_evidence_execution",
        report,
        expected_command=EVIDENCE_EXECUTION_COMMAND,
        max_age_min=EVIDENCE_EXECUTION_MAX_AGE_MIN,
    )
    validation_issues.extend(evidence_ref_issues)
    if report.get("command") != EVIDENCE_EXECUTION_COMMAND:
        validation_issues.append({"issue": "claim_evidence_execution_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        validation_issues.append({"issue": "claim_evidence_execution_not_pass", "detail": report.get("status") or ""})
    if report.get("selected_claim_kind") != "theorem_or_proof":
        validation_issues.append({"issue": "formal_certificate_intake_requires_theorem_or_proof", "detail": report.get("selected_claim_kind") or ""})
    validation_issues.extend(_forbidden_issues(report))

    packet = report.get("selected_claim_packet") or {}
    workspace_dir = report.get("workspace_dir") or ""
    formal_slot = _read_json_file(root, workspace_dir, "formal-verifier-slot.json")
    proof_check = _read_json_file(root, workspace_dir, "proof-check-result.json")
    checks = [
        _check("formal_verifier_slot_readable", bool(formal_slot), "formal_verifier_slot_missing_or_unreadable"),
        _check("proof_check_result_readable", bool(proof_check), "proof_check_result_missing_or_unreadable"),
    ]
    certificate_validation = research_compute_formal_verifier_adapter.validate_formal_verifier_certificate(
        report,
        packet,
        root,
        formal_slot=formal_slot,
        proof_check=proof_check,
    )
    checks.extend(certificate_validation.get("checks") or [])

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    issue_checks = [item for item in checks if item.get("status") != "PASS"]
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif validation_issues or issue_checks or not certificate_validation.get("formal_certificate_verified"):
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = ACCEPTED_STATE
    return _base_report(
        label,
        status,
        state,
        validation_issues,
        checks=checks,
        certificate_validation=certificate_validation,
        evidence_report=report,
        evidence_ref_health=evidence_ref_health,
    )


def formal_verifier_certificate_intake_markdown(report):
    lines = [
        "# paper_factory Formal Verifier Certificate Intake",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_certificate_intake_state') or ''}",
        f"- Formal certificate verified: {report.get('formal_certificate_verified')}",
        f"- Certificate kind: {report.get('certificate_kind') or ''}",
        f"- Authority record verified: {report.get('certificate_authority_record_verified')}",
        f"- Pinned verifier input verified: {report.get('pinned_verifier_input_verified')}",
        f"- Certificate source binding verified: {report.get('certificate_source_binding_verified')}",
        f"- Local proof fallback detected: {report.get('local_proof_obligation_fallback_detected')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for item in report.get("checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
