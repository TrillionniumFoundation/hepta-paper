"""Run a local Lean smoke proof and feed its certificate through intake."""

import datetime as dt
import hashlib
import json
import pathlib
import shutil
import subprocess

from paperctl_modules import research_compute_formal_verifier_certificate_intake


COMMAND = "research-compute-formal-verifier-lean-execution-harness"
PASS_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_LEAN_EXECUTION_HARNESS_PASS"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_LEAN_EXECUTION_HARNESS_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_LEAN_EXECUTION_HARNESS_FAILED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_lean_execution_harness_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_execution_ready",
    "certificate_intake_accepted",
    "machine_checked_formal_claim_allowed",
    "synthetic_certificate_only",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "lake_project_detected",
    "lake_build_required",
    "lake_build_performed",
    "lake_build_ready",
    "lake_project_root",
    "lake_executable_path",
    "lake_exit_code",
    "workspace_root",
    "workspace_dir",
    "evidence_execution_report_path",
    "certificate_path",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "lake_build",
    "evidence_execution_report",
    "certificate_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "artifact_count",
    "lean_execution_ready_count",
    "lake_build_required_count",
    "lake_build_performed_count",
    "lake_build_ready_count",
    "certificate_intake_accepted_count",
    "certificate_intake_issue_count",
    "validation_issue_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Writes a local Lean smoke theorem, executes Lean, records a machine-checked certificate, and feeds it through formal-verifier certificate intake.",
    "This command mutates only its report workspace; it does not mutate manuscript source, read secrets, call providers, upload, email, submit, or commit.",
]

CLAIM_TEXT = "For every natural number n, n = n."
SOURCE_LOCATOR = "formal-verifier-lean-execution.lean:1"
THEOREM_NAME = "PaperFactoryIdentityCertificate"
AUX_THEOREM_NAME = "PaperFactoryIdentityCertificateStatementPresent"
PROOF_OBLIGATIONS = [
    {"name": "lean_source_typechecked", "status": "machine_checked"},
    {"name": "theorem_statement_present", "status": "machine_checked"},
]
LEAN_SOURCE = """theorem PaperFactoryIdentityCertificate (n : Nat) : n = n := by
  rfl

theorem PaperFactoryIdentityCertificateStatementPresent (n : Nat) : n = n := by
  rfl
"""
FORMAL_STATEMENT_CONTRACTS = [
    "theorem PaperFactoryIdentityCertificate (n : Nat) : n = n",
    "theorem PaperFactoryIdentityCertificateStatementPresent (n : Nat) : n = n",
]


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode()).hexdigest()


def _sha256_json(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()
    ).hexdigest()


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_json(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True))
    return {
        "path": str(path),
        "sha256": _sha256_file(path),
        "bytes": path.stat().st_size,
    }


def _write_text(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload)
    return {
        "path": str(path),
        "sha256": _sha256_file(path),
        "bytes": path.stat().st_size,
    }


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _relative_to_root(root, path):
    try:
        return str(pathlib.Path(path).resolve().relative_to(pathlib.Path(root).resolve()))
    except ValueError:
        return str(path)


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def _run_lake_build(lake_executable, root, timeout_seconds, runner=None):
    command = [lake_executable, "build"]
    if runner:
        return runner(command, timeout_seconds, pathlib.Path(root))
    return subprocess.run(
        command,
        check=False,
        cwd=str(root),
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_lean_execution_harness(
    root,
    label="",
    lean_executable="",
    lake_executable="",
    project_root=None,
    timeout_seconds=180,
    lake_timeout_seconds=300,
    runner=None,
    lake_runner=None,
):
    root = pathlib.Path(root)
    project_root = pathlib.Path(project_root).resolve() if project_root else root.resolve()
    workspace = root / "formal-verifier-lean-execution-workspace"
    lean_source_path = workspace / "formal-verifier-lean-execution.lean"
    lean_info = _write_text(lean_source_path, LEAN_SOURCE)

    selected_lean = str(lean_executable or shutil.which("lean") or "")
    checks = [
        _check("lean_source_written", lean_source_path.exists(), "lean_source_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
    ]
    lean_result = None
    lean_stdout = ""
    lean_stderr = ""
    lean_exit_code = None
    lean_timed_out = False
    execution_performed = False
    if selected_lean:
        try:
            lean_result = _run_lean(selected_lean, lean_source_path, timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(lean_result, "returncode", 1))
            lean_stdout = str(getattr(lean_result, "stdout", "") or "")
            lean_stderr = str(getattr(lean_result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_timed_out = True
            lean_exit_code = 124
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")
    lean_passed = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    checks.extend(
        [
            _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
            _check("lean_execution_exit_zero", lean_passed, "lean_execution_failed"),
        ]
    )
    lake_project_detected = (project_root / "lakefile.lean").exists() or (project_root / "lakefile.toml").exists()
    selected_lake = str(lake_executable or shutil.which("lake") or "") if lake_project_detected else ""
    lake_result = None
    lake_stdout = ""
    lake_stderr = ""
    lake_exit_code = None
    lake_timed_out = False
    lake_build_performed = False
    if lake_project_detected:
        checks.append(
            _check("lake_executable_found", bool(selected_lake), "lake_executable_not_found", severity="readiness")
        )
        if selected_lake:
            try:
                lake_result = _run_lake_build(
                    selected_lake,
                    project_root,
                    lake_timeout_seconds,
                    runner=lake_runner,
                )
                lake_build_performed = True
                lake_exit_code = int(getattr(lake_result, "returncode", 1))
                lake_stdout = str(getattr(lake_result, "stdout", "") or "")
                lake_stderr = str(getattr(lake_result, "stderr", "") or "")
            except subprocess.TimeoutExpired as exc:
                lake_build_performed = True
                lake_timed_out = True
                lake_exit_code = 124
                lake_stdout = str(exc.stdout or "")
                lake_stderr = str(exc.stderr or "")
        lake_build_ready = bool(lake_build_performed and lake_exit_code == 0 and not lake_timed_out)
        checks.extend(
            [
                _check("lake_build_performed", lake_build_performed, "lake_build_not_performed"),
                _check("lake_build_exit_zero", lake_build_ready, "lake_build_failed"),
            ]
        )
    else:
        lake_build_ready = True

    formal_slot = {
        "slot_kind": "formal_verifier_certificate_slot",
        "formal_verifier_required_before_formal_claim": True,
        "proof_notes_are_formal_certificate": False,
        "accepted_certificate_kinds": [
            "lean",
            "coq",
            "isabelle",
            "other_machine_checked_formal_certificate",
        ],
        "formal_verifier_used": lean_passed,
        "formal_certificate_present": lean_passed,
        "certificate_kind": "lean" if lean_passed else "",
        "certificate_artifact_path": "formal-verifier-certificate.json" if lean_passed else "",
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }
    proof_check = {
        "checker_kind": "formal_theorem_prover" if lean_passed else "formal_theorem_prover_failed",
        "formal_verifier_slot_path": "formal-verifier-slot.json",
        "formal_verifier_used": lean_passed,
        "formal_certificate_present": lean_passed,
        "formal_certificate_kind": "lean" if lean_passed else "",
        "certificate_artifact_path": "formal-verifier-certificate.json" if lean_passed else "",
        "machine_checked_obligation_count": len(PROOF_OBLIGATIONS) if lean_passed else 0,
        "automated_claim_finalization_ready": lean_passed,
        "lean_executable_path": selected_lean,
        "lean_source_path": "formal-verifier-lean-execution.lean",
        "lean_source_sha256": lean_info["sha256"],
        "lean_exit_code": lean_exit_code,
        "lean_stdout": lean_stdout,
        "lean_stderr": lean_stderr,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }
    claim_text_sha = _sha256_text(CLAIM_TEXT)
    expected_theorem_names = [THEOREM_NAME] if lean_passed else []
    obligation_names = sorted(item["name"] for item in PROOF_OBLIGATIONS)
    contracts_hash = _sha256_json(FORMAL_STATEMENT_CONTRACTS if lean_passed else [])
    theorem_names_hash = _sha256_json(sorted(expected_theorem_names))
    obligation_names_hash = _sha256_json(obligation_names)
    certificate = {
        "certificate_kind": "lean",
        "verifier": "lean",
        "verifier_status": "verified" if lean_passed else "failed",
        "verified": lean_passed,
        "machine_checked": lean_passed,
        "synthetic_certificate_only": False,
        "prover_execution_performed": execution_performed,
        "claim_text": CLAIM_TEXT,
        "claim_text_sha256": claim_text_sha,
        "source_locator": SOURCE_LOCATOR,
        "proof_obligations": PROOF_OBLIGATIONS,
        "verified_obligations": [item["name"] for item in PROOF_OBLIGATIONS] if lean_passed else [],
        "machine_checked_obligation_count": len(PROOF_OBLIGATIONS) if lean_passed else 0,
        "formal_statement_contract_count": len(FORMAL_STATEMENT_CONTRACTS) if lean_passed else 0,
        "formal_statement_contracts": FORMAL_STATEMENT_CONTRACTS if lean_passed else [],
        "formal_statement_contract_source_match_count": len(FORMAL_STATEMENT_CONTRACTS) if lean_passed else 0,
        "theorem_names": [THEOREM_NAME, AUX_THEOREM_NAME] if lean_passed else [],
        "expected_theorem_names": expected_theorem_names,
        "lean_executable_path": selected_lean,
        "lean_source_path": "formal-verifier-lean-execution.lean",
        "lean_source_sha256": lean_info["sha256"],
        "lean_exit_code": lean_exit_code,
        "lean_stdout": lean_stdout,
        "lean_stderr": lean_stderr,
        "authority_record": {
            "authority_kind": "local_formal_verifier_execution",
            "certificate_kind": "lean",
            "verifier": "lean",
            "verification_status": "verified" if lean_passed else "failed",
            "prover_execution_performed": execution_performed,
            "execution_exit_code": lean_exit_code,
            "lake_build_performed": lake_build_performed,
            "lake_exit_code": lake_exit_code,
            "source_mutation_performed": False,
            "external_action_performed": False,
            "secret_material_read_performed": False,
            "network_performed": False,
            "provider_model_call_performed": False,
            "commit_performed": False,
        },
        "pinned_verifier_input": {
            "verifier": "lean",
            "verifier_executable_path": selected_lean,
            "proof_source_path": "formal-verifier-lean-execution.lean",
            "proof_source_sha256": lean_info["sha256"],
            "certificate_artifact_path": "formal-verifier-certificate.json",
            "claim_text_sha256": claim_text_sha,
            "source_locator": SOURCE_LOCATOR,
            "formal_statement_contracts_sha256": contracts_hash,
            "expected_theorem_names_sha256": theorem_names_hash,
            "obligation_names_sha256": obligation_names_hash,
            "formal_verifier_slot_path": "formal-verifier-slot.json",
            "proof_check_result_path": "proof-check-result.json",
        },
        "source_binding": {
            "claim_text_sha256": claim_text_sha,
            "source_locator": SOURCE_LOCATOR,
            "proof_source_path": "formal-verifier-lean-execution.lean",
            "proof_source_sha256": lean_info["sha256"],
            "formal_statement_contracts_sha256": contracts_hash,
            "expected_theorem_names_sha256": theorem_names_hash,
            "obligation_names_sha256": obligation_names_hash,
        },
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
        "provider_model_call_performed": False,
        "commit_performed": False,
    }
    slot_info = _write_json(workspace / "formal-verifier-slot.json", formal_slot)
    proof_info = _write_json(workspace / "proof-check-result.json", proof_check)
    certificate_info = _write_json(workspace / "formal-verifier-certificate.json", certificate)
    output_hashes = [
        {"path": "formal-verifier-lean-execution.lean", "sha256": lean_info["sha256"], "bytes": lean_info["bytes"]},
        {"path": "formal-verifier-slot.json", "sha256": slot_info["sha256"], "bytes": slot_info["bytes"]},
        {"path": "proof-check-result.json", "sha256": proof_info["sha256"], "bytes": proof_info["bytes"]},
        {"path": "formal-verifier-certificate.json", "sha256": certificate_info["sha256"], "bytes": certificate_info["bytes"]},
    ]
    evidence_report = {
        "created_at": dt.datetime.now().replace(microsecond=0).isoformat(sep=" "),
        "command": "research-compute-claim-evidence-execution",
        "status": "PASS" if lean_passed else "ATTENTION",
        "selected_claim_kind": "theorem_or_proof",
        "workspace_dir": "formal-verifier-lean-execution-workspace",
        "output_hashes": output_hashes,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "selected_claim_packet": {
            "claim_packet_id": "formal-verifier-lean-execution-claim",
            "slug": "Formal_Verifier_Lean_Execution",
            "claim_kind": "theorem_or_proof",
            "claim_text": CLAIM_TEXT,
            "source_locator": SOURCE_LOCATOR,
            "proof_obligations": PROOF_OBLIGATIONS,
        },
    }
    evidence_info = _write_json(root / "formal-verifier-lean-execution-evidence-execution.json", evidence_report)
    evidence_report["report_path"] = evidence_info["path"]
    evidence_report["report_sha256"] = evidence_info["sha256"]
    certificate_intake = research_compute_formal_verifier_certificate_intake.formal_verifier_certificate_intake(
        evidence_report,
        root=str(root),
        label=label or "",
    )
    intake_accepted = bool(
        certificate_intake.get("status") == "PASS"
        and certificate_intake.get("formal_certificate_verified")
        and certificate_intake.get("machine_checked_formal_claim_allowed")
    )
    checks.extend(
        [
            _check("certificate_intake_accepted", intake_accepted, "certificate_intake_not_accepted"),
            _check("no_network", True),
            _check("no_external_action", not certificate_intake.get("external_action_performed"), "external_action_performed"),
            _check("no_source_mutation", not certificate_intake.get("source_mutation_performed"), "source_mutation_performed"),
        ]
    )
    validation_issues = [
        {"issue": item.get("detail") or item.get("name")}
        for item in checks
        if item.get("status") != "PASS"
    ]
    status = "PASS" if not validation_issues else "ATTENTION"
    state = PASS_STATE if status == "PASS" else ATTENTION_STATE
    if (execution_performed and lean_timed_out) or (lake_build_performed and lake_timed_out):
        state = ATTENTION_STATE
    return {
        "command": COMMAND,
        "status": status,
        "formal_verifier_lean_execution_harness_state": state if status != "FAIL" else FAILED_STATE,
        "label": label or "",
        "plan_only": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed or lake_build_performed,
        "prover_execution_performed": execution_performed or lake_build_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_execution_ready": lean_passed,
        "certificate_intake_accepted": intake_accepted,
        "machine_checked_formal_claim_allowed": intake_accepted,
        "synthetic_certificate_only": False,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": str(lean_source_path),
        "lake_project_detected": lake_project_detected,
        "lake_build_required": lake_project_detected,
        "lake_build_performed": lake_build_performed,
        "lake_build_ready": lake_build_ready,
        "lake_project_root": str(project_root),
        "lake_executable_path": selected_lake,
        "lake_exit_code": lake_exit_code,
        "workspace_root": str(root),
        "workspace_dir": str(workspace),
        "evidence_execution_report_path": evidence_info["path"],
        "certificate_path": certificate_info["path"],
        "summary": {
            "artifact_count": 5,
            "lean_execution_ready_count": 1 if lean_passed else 0,
            "lake_build_required_count": 1 if lake_project_detected else 0,
            "lake_build_performed_count": 1 if lake_build_performed else 0,
            "lake_build_ready_count": 1 if lake_project_detected and lake_build_ready else 0,
            "certificate_intake_accepted_count": 1 if intake_accepted else 0,
            "certificate_intake_issue_count": int((certificate_intake.get("summary") or {}).get("certificate_issue_count") or 0),
            "validation_issue_count": len(validation_issues),
            "prover_execution_performed_count": 1 if (execution_performed or lake_build_performed) else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": _relative_to_root(root, lean_source_path),
            "source_sha256": lean_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
        },
        "lake_build": {
            "project_detected": lake_project_detected,
            "required": lake_project_detected,
            "performed": lake_build_performed,
            "ready": lake_build_ready,
            "project_root": str(project_root),
            "executable_path": selected_lake,
            "exit_code": lake_exit_code,
            "timed_out": lake_timed_out,
            "stdout": lake_stdout,
            "stderr": lake_stderr,
        },
        "evidence_execution_report": evidence_report,
        "certificate_intake_report": certificate_intake,
        "boundary": [
            "This harness executes only the local Lean binary on a workspace smoke theorem and, when a Lake project is present, local lake build.",
            "It writes artifacts only under the command report workspace.",
            "It does not mutate manuscript source/package/archive state, enqueue or merge patches, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
            "Passing this harness proves the formal-verifier execution and certificate-intake path, not that production manuscript claims have Lean certificates.",
        ],
    }


def formal_verifier_lean_execution_harness_markdown(report):
    lines = [
        "# paper_factory Formal Verifier Lean Execution Harness",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_lean_execution_harness_state') or ''}",
        f"- Lean executable: {report.get('lean_executable_path') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Lake project detected: {report.get('lake_project_detected')}",
        f"- Lake build ready: {report.get('lake_build_ready')}",
        f"- Lake exit code: {report.get('lake_exit_code')}",
        f"- Certificate intake accepted: {report.get('certificate_intake_accepted')}",
        f"- Synthetic certificate only: {report.get('synthetic_certificate_only')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for item in report.get("checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
