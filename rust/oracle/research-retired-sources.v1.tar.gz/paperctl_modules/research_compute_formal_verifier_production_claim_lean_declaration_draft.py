"""Draft and syntax-check Lean declarations for extracted production statements."""

import hashlib
import json
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-declaration-draft"
STATEMENT_COMMAND = "research-compute-formal-verifier-production-claim-lean-statement-extraction"

READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_DECLARATION_DRAFT_PLACEHOLDER_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_DECLARATION_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_DECLARATION_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_DECLARATION_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_declaration_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_declaration_draft_ready",
    "lean_proof_replacement_required",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "statement_extraction_report_path",
    "statement_extraction_report_sha256",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "candidate_statements",
    "statement_extraction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "candidate_statement_count",
    "lean_declaration_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "lean_proof_replacement_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Builds a Lean declaration draft from extracted candidate statements and syntax-checks it.",
    "The draft intentionally uses axiom placeholders, so it cannot be consumed as a machine-checked production proof.",
    "This command writes local draft artifacts and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom)\b", re.I)
DECLARATION_RE = re.compile(r"^\s*(theorem|lemma|axiom)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _statement_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_statement_extraction_report_missing")
        return issues
    if report.get("command") != STATEMENT_COMMAND:
        _issue(issues, "production_claim_lean_statement_extraction_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_statement_extraction_not_pass", report.get("status") or "")
    if not report.get("statement_extraction_ready"):
        _issue(issues, "production_claim_lean_statement_extraction_not_ready")
    if not report.get("candidate_statements") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_candidate_statements_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_statement_extraction_boundary:{key}")
    return issues


def _lean_identifier(value, fallback="ProductionClaim"):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    ident = "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)
    if not ident or not ident[0].isalpha():
        ident = fallback
    return ident[:160]


def _lean_source(report):
    namespace = _lean_identifier(report.get("slug") or "ProductionClaim", "ProductionClaimFormalization")
    lines = [
        "/-",
        "paper_factory production claim Lean declaration draft.",
        "This file syntax-checks extracted candidate statements as placeholders.",
        "It is not a machine-checked proof certificate.",
        "-/",
        "",
        f"namespace {namespace}",
        "",
    ]
    for index, item in enumerate(report.get("candidate_statements") or [], start=1):
        name = _lean_identifier(item.get("lean_theorem_name_hint") or item.get("work_item_id") or f"Statement{index}")
        lines.extend(
            [
                "/-",
                f"Work item: {item.get('work_item_id') or ''}",
                f"Source locator: {item.get('source_locator') or ''}",
                "Extracted candidate statement:",
                item.get("candidate_statement_text") or "",
                "-/",
                f"axiom {name} : Prop",
                "",
            ]
        )
    lines.extend([f"end {namespace}", ""])
    return "\n".join(lines)


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_production_claim_lean_declaration_draft(
    statement_extraction_report=None,
    output_root=None,
    lean_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    report = statement_extraction_report or {}
    validation_issues = _statement_issues(report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(report.get("production_claim_machine_checked"))
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    lean_source_text = _lean_source(report)
    source_info = _write_text(output_root / "production-claim-lean-declaration-draft.lean", lean_source_text)
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if selected_lean:
        try:
            result = _run_lean(selected_lean, source_info["path"], timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    declarations = DECLARATION_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    checks = [
        _check("statement_extraction_report_consumable", not _statement_issues(report), "production_claim_lean_statement_extraction_not_consumable"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("lean_declarations_present", bool(declarations), "lean_declarations_missing"),
        _check("placeholder_tokens_present_for_draft", bool(placeholders) or machine_checked, "placeholder_tokens_missing_for_declaration_draft", severity="readiness"),
        _check("no_source_mutation", not report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
    elif lean_exit_zero and declarations and placeholders:
        status = "PASS"
        state = READY_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_declaration_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_declaration_draft_ready": status == "PASS",
        "lean_proof_replacement_required": bool(status == "PASS" and state == READY_STATE),
        "production_claim_machine_checked": machine_checked and state == CLOSED_STATE,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": report.get("claim_packet_id") or "",
        "slug": report.get("slug") or "",
        "statement_extraction_report_path": report.get("report_path") or "",
        "statement_extraction_report_sha256": report.get("report_sha256") or "",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "candidate_statement_count": len(report.get("candidate_statements") or []),
            "lean_declaration_count": len(declarations),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "lean_proof_replacement_required_count": 1 if status == "PASS" and state == READY_STATE else 0,
            "production_claim_machine_checked_count": 1 if machine_checked and state == CLOSED_STATE else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "declaration_names": [item[1] for item in declarations],
            "placeholder_token_count": len(placeholders),
        },
        "candidate_statements": list(report.get("candidate_statements") or []),
        "statement_extraction_report": report,
        "boundary": [
            "This command syntax-checks a Lean declaration draft only; axiom placeholders mean the production claim is not machine-checked.",
            "A Lean exit code of zero for this draft is not a proof certificate.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_declaration_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Declaration Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_declaration_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Proof replacement required: {report.get('lean_proof_replacement_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
