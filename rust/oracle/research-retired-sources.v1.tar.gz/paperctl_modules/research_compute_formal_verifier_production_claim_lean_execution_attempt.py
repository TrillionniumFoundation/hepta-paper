"""Execute a production-claim Lean skeleton without accepting placeholders."""

import datetime as dt
import hashlib
import json
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import research_compute_formal_verifier_certificate_intake


COMMAND = "research-compute-formal-verifier-production-claim-lean-execution-attempt"
PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-plan"
PASS_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_EXECUTION_ATTEMPT_CERTIFICATE_ACCEPTED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_EXECUTION_ATTEMPT_INCOMPLETE"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_EXECUTION_ATTEMPT_FAILED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_execution_attempt_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_execution_attempt_ready",
    "production_claim_machine_checked",
    "certificate_intake_accepted",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "plan_report_path",
    "workspace_root",
    "attempt_workspace_dir",
    "attempt_evidence_report_path",
    "certificate_path",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "certificate_intake_report",
    "selected_claim_packet",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "lean_declaration_count",
    "placeholder_token_count",
    "vacuous_true_declaration_count",
    "target_theorem_expected_count",
    "target_theorem_declared_count",
    "target_theorem_missing_count",
    "proof_obligation_count",
    "formal_statement_contract_count",
    "formal_statement_contract_missing_count",
    "formal_statement_contract_source_match_count",
    "formal_statement_contract_source_mismatch_count",
    "artifact_count",
    "certificate_intake_accepted_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Runs Lean on a production-claim formalization file and refuses comment-only or placeholder skeletons even when Lean exits zero.",
    "This command writes only attempt-workspace artifacts; it does not mutate manuscript source, read secrets, call providers, upload, email, submit, or commit.",
]

FORBIDDEN_PLAN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
FORMAL_STATEMENT_KEYS = [
    "lean_statement",
    "formal_statement",
    "theorem_statement",
    "lean_declaration",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom)\b|work item, not a machine-checked certificate|Next step:", re.I)
DECLARATION_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
DECLARATION_SIGNATURE_RE = re.compile(
    r"^\s*(?:theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*[\s\S]*?(?::=|where\b)",
    re.M,
)
NEXT_DECL_OR_SCOPE_RE = re.compile(r"^\s*(theorem|lemma|def|structure|class|abbrev|inductive|namespace|section|end)\b")
NAMESPACE_RE = re.compile(r"^\s*namespace\b")
SECTION_RE = re.compile(r"^\s*section\b")
END_RE = re.compile(r"^\s*end\b")
VACUOUS_TRUE_DECLARATION_RE = re.compile(
    r"^\s*(?:theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*[\s\S]*?:\s*True\s*:=",
    re.M,
)


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode()).hexdigest()


def _sha256_json(value):
    return hashlib.sha256(
        json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(",", ":")).encode()
    ).hexdigest()


def _write_json(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True))
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _write_text(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _safe_path(root, path_text):
    if not path_text:
        return pathlib.Path()
    path = pathlib.Path(path_text)
    if not path.is_absolute():
        path = pathlib.Path(root) / path
    return path.resolve()


def _safe_token(value, fallback="claim"):
    text = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in str(value or ""))
    text = text.strip(".-_")
    return (text or fallback)[:120]


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def _expected_theorem_names(plan, report, packet):
    names = []
    for value in [
        (plan or {}).get("proposed_theorem_name"),
        (report or {}).get("proposed_theorem_name"),
        (packet or {}).get("expected_lean_theorem_name"),
        (packet or {}).get("proposed_theorem_name"),
    ]:
        text = str(value or "").strip()
        if text and text not in names:
            names.append(text)
    return names


def _work_item_formal_statement(item):
    item = item or {}
    for key in FORMAL_STATEMENT_KEYS:
        text = str(item.get(key) or "").strip()
        if text:
            return text
    return ""


def _normalize_statement_signature(text):
    signature = str(text or "").strip()
    if not signature:
        return ""
    match = DECLARATION_SIGNATURE_RE.search(signature)
    if match:
        signature = match.group(0)
    signature = re.split(r":=|\bwhere\b", signature, maxsplit=1)[0]
    signature = re.sub(r"\s+", " ", signature).strip()
    if not re.match(r"^(theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*\b", signature):
        return ""
    if ":" not in signature:
        return ""
    return signature


def _source_statement_signatures(lean_source_text):
    return [
        item["signature"]
        for item in _source_declaration_records(lean_source_text)
        if item.get("signature") and item.get("top_level_namespace")
    ]


def _source_declaration_records(lean_source_text):
    stripped_lean_text = _strip_lean_comments(lean_source_text)
    lines = str(stripped_lean_text or "").splitlines()
    records = []
    scope_stack = []
    for index, line in enumerate(lines):
        match = DECLARATION_RE.match(line)
        if match:
            end = len(lines)
            for later in range(index + 1, len(lines)):
                if NEXT_DECL_OR_SCOPE_RE.match(lines[later]):
                    end = later
                    break
            block = "\n".join(lines[index:end])
            signature = _normalize_statement_signature(block)
            records.append(
                {
                    "kind": match.group(1),
                    "name": match.group(2),
                    "line_start": index + 1,
                    "line_end": end,
                    "signature": signature,
                    "namespace_depth": sum(1 for item in scope_stack if item == "namespace"),
                    "top_level_namespace": not any(item == "namespace" for item in scope_stack),
                }
            )
        if NAMESPACE_RE.match(line):
            scope_stack.append("namespace")
        elif SECTION_RE.match(line):
            scope_stack.append("section")
        elif END_RE.match(line) and scope_stack:
            scope_stack.pop()
    return records


def _plan_validation_issues(plan_report):
    issues = []
    if not plan_report:
        issues.append({"issue": "production_claim_lean_plan_report_missing"})
        return issues
    if plan_report.get("command") != PLAN_COMMAND:
        issues.append({"issue": "production_claim_lean_plan_command_mismatch", "detail": plan_report.get("command") or ""})
    if plan_report.get("status") != "PASS":
        issues.append({"issue": "production_claim_lean_plan_not_pass", "detail": plan_report.get("status") or ""})
    if not plan_report.get("lean_plan_ready"):
        issues.append({"issue": "production_claim_lean_plan_not_ready"})
    for key in FORBIDDEN_PLAN_KEYS:
        if plan_report.get(key):
            issues.append({"issue": f"forbidden_plan_boundary:{key}"})
    return issues


def formal_verifier_production_claim_lean_execution_attempt(
    plan_report=None,
    root=".",
    output_root=None,
    lean_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    root = pathlib.Path(root).resolve()
    output_root = pathlib.Path(output_root or root).resolve()
    report = plan_report or {}
    validation_issues = _plan_validation_issues(report)
    packet = dict(report.get("selected_claim_packet") or {})
    plan = dict(report.get("formalization_plan") or {})
    lean_source = _safe_path(root, report.get("lean_skeleton_path") or "")
    lean_source_text = lean_source.read_text(errors="ignore") if lean_source.exists() else ""
    lean_source_without_comments = _strip_lean_comments(lean_source_text)
    source_declaration_records = _source_declaration_records(lean_source_text)
    declarations = [(item.get("kind"), item.get("name")) for item in source_declaration_records]
    declaration_names = [item.get("name") for item in source_declaration_records]
    top_level_declaration_names = [
        item.get("name")
        for item in source_declaration_records
        if item.get("top_level_namespace")
    ]
    placeholder_tokens = PLACEHOLDER_RE.findall(lean_source_without_comments)
    vacuous_true_declarations = VACUOUS_TRUE_DECLARATION_RE.findall(lean_source_without_comments)
    if not lean_source.exists():
        validation_issues.append({"issue": "lean_source_missing", "detail": str(lean_source)})

    selected_lean = str(lean_executable or shutil.which("lean") or "")
    lean_stdout = ""
    lean_stderr = ""
    lean_exit_code = None
    lean_timed_out = False
    execution_performed = False
    if selected_lean and lean_source.exists():
        try:
            lean_result = _run_lean(selected_lean, lean_source, timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(lean_result, "returncode", 1))
            lean_stdout = str(getattr(lean_result, "stdout", "") or "")
            lean_stderr = str(getattr(lean_result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_timed_out = True
            lean_exit_code = 124
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    declarations_present = bool(declarations)
    placeholders_absent = not bool(placeholder_tokens)
    vacuous_true_absent = not bool(vacuous_true_declarations)
    expected_theorem_names = _expected_theorem_names(plan, report, packet)
    declared_name_set = set(top_level_declaration_names)
    declared_expected_theorem_names = [name for name in expected_theorem_names if name in declared_name_set]
    target_theorem_names_declared = bool(
        expected_theorem_names
        and len(declared_expected_theorem_names) == len(expected_theorem_names)
    )
    obligations = list(plan.get("work_items") or packet.get("proof_obligations") or [])
    formal_statement_contracts = [
        _work_item_formal_statement(item)
        for item in obligations
        if _work_item_formal_statement(item)
    ]
    normalized_formal_statement_contracts = [
        _normalize_statement_signature(item)
        for item in formal_statement_contracts
        if _normalize_statement_signature(item)
    ]
    source_statement_signatures = _source_statement_signatures(lean_source_text)
    source_statement_signature_set = set(source_statement_signatures)
    matched_formal_statement_contracts = [
        item
        for item in normalized_formal_statement_contracts
        if item in source_statement_signature_set
    ]
    formal_statement_contracts_complete = bool(
        obligations
        and len(formal_statement_contracts) >= len(obligations)
    )
    formal_statement_contracts_match_source = bool(
        normalized_formal_statement_contracts
        and len(normalized_formal_statement_contracts) >= len(obligations)
        and len(matched_formal_statement_contracts) == len(normalized_formal_statement_contracts)
    )
    production_machine_checked = bool(
        lean_exit_zero
        and declarations_present
        and placeholders_absent
        and vacuous_true_absent
        and target_theorem_names_declared
        and formal_statement_contracts_complete
        and formal_statement_contracts_match_source
        and obligations
        and not validation_issues
    )

    claim_id = _safe_token(packet.get("claim_packet_id") or report.get("claim_packet_id") or "claim")
    slug = _safe_token(packet.get("slug") or report.get("slug") or "production-claim")
    workspace = output_root / f"{slug}-{claim_id}-lean-execution-attempt"
    copied_source_info = _write_text(workspace / "production-claim-lean-source.lean", lean_source_text)
    claim_text = packet.get("claim_text") or ""
    claim_text_sha = _sha256_text(claim_text)
    verified_obligation_names = [
        str(item.get("obligation_name") or item.get("name") or f"obligation_{index}").strip()
        for index, item in enumerate(obligations, start=1)
    ]
    verified_obligation_names = [item for item in verified_obligation_names if item]
    contracts_hash = _sha256_json(normalized_formal_statement_contracts)
    theorem_names_hash = _sha256_json(sorted(expected_theorem_names))
    obligation_names_hash = _sha256_json(sorted(verified_obligation_names))
    source_locator = packet.get("source_locator") or report.get("source_locator") or ""
    certificate = {
        "certificate_kind": "lean",
        "verifier": "lean",
        "verifier_status": "verified" if production_machine_checked else "incomplete",
        "verified": production_machine_checked,
        "machine_checked": production_machine_checked,
        "synthetic_certificate_only": False,
        "prover_execution_performed": execution_performed,
        "claim_text": claim_text,
        "claim_text_sha256": claim_text_sha,
        "source_locator": source_locator,
        "proof_obligations": obligations,
        "verified_obligations": verified_obligation_names if production_machine_checked else [],
        "machine_checked_obligation_count": len(obligations) if production_machine_checked else 0,
        "formal_statement_contract_count": len(formal_statement_contracts),
        "formal_statement_contracts": normalized_formal_statement_contracts,
        "formal_statement_contract_source_match_count": len(matched_formal_statement_contracts),
        "theorem_names": declaration_names if production_machine_checked else [],
        "expected_theorem_names": expected_theorem_names,
        "target_theorem_names_declared": target_theorem_names_declared,
        "lean_executable_path": selected_lean,
        "lean_source_path": "production-claim-lean-source.lean",
        "lean_source_sha256": copied_source_info["sha256"],
        "lean_exit_code": lean_exit_code,
        "lean_declaration_count": len(declarations),
        "placeholder_token_count": len(placeholder_tokens),
        "vacuous_true_declaration_count": len(vacuous_true_declarations),
        "target_theorem_expected_count": len(expected_theorem_names),
        "target_theorem_declared_count": len(declared_expected_theorem_names),
        "target_theorem_missing_count": max(0, len(expected_theorem_names) - len(declared_expected_theorem_names)),
        "formal_statement_contract_count": len(formal_statement_contracts),
        "formal_statement_contract_missing_count": max(0, len(obligations) - len(formal_statement_contracts)),
        "formal_statement_contract_source_match_count": len(matched_formal_statement_contracts),
        "formal_statement_contract_source_mismatch_count": max(0, len(normalized_formal_statement_contracts) - len(matched_formal_statement_contracts)),
        "authority_record": {
            "authority_kind": "local_formal_verifier_execution",
            "certificate_kind": "lean",
            "verifier": "lean",
            "verification_status": "verified" if production_machine_checked else "incomplete",
            "prover_execution_performed": execution_performed,
            "execution_exit_code": lean_exit_code,
            "source_mutation_performed": False,
            "external_action_performed": False,
            "secret_material_read_performed": False,
            "network_performed": False,
            "provider_model_call_performed": False,
            "commit_performed": False,
        },
        "pinned_verifier_input": {
            "verifier": "lean",
            "verifier_executable_path": selected_lean,
            "proof_source_path": "production-claim-lean-source.lean",
            "proof_source_sha256": copied_source_info["sha256"],
            "certificate_artifact_path": "formal-verifier-certificate.json",
            "claim_text_sha256": claim_text_sha,
            "source_locator": source_locator,
            "formal_statement_contracts_sha256": contracts_hash,
            "expected_theorem_names_sha256": theorem_names_hash,
            "obligation_names_sha256": obligation_names_hash,
            "formal_verifier_slot_path": "formal-verifier-slot.json",
            "proof_check_result_path": "proof-check-result.json",
        },
        "source_binding": {
            "claim_text_sha256": claim_text_sha,
            "source_locator": source_locator,
            "proof_source_path": "production-claim-lean-source.lean",
            "proof_source_sha256": copied_source_info["sha256"],
            "formal_statement_contracts_sha256": contracts_hash,
            "expected_theorem_names_sha256": theorem_names_hash,
            "obligation_names_sha256": obligation_names_hash,
        },
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
        "provider_model_call_performed": False,
        "commit_performed": False,
    }
    formal_slot = {
        "slot_kind": "formal_verifier_certificate_slot",
        "formal_verifier_required_before_formal_claim": True,
        "proof_notes_are_formal_certificate": False,
        "accepted_certificate_kinds": ["lean", "coq", "isabelle", "other_machine_checked_formal_certificate"],
        "formal_verifier_used": production_machine_checked,
        "formal_certificate_present": production_machine_checked,
        "certificate_kind": "lean" if production_machine_checked else "",
        "certificate_artifact_path": "formal-verifier-certificate.json" if production_machine_checked else "",
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }
    proof_check = {
        "checker_kind": "formal_theorem_prover" if production_machine_checked else "formal_theorem_prover_incomplete",
        "formal_verifier_slot_path": "formal-verifier-slot.json",
        "formal_verifier_used": production_machine_checked,
        "formal_certificate_present": production_machine_checked,
        "formal_certificate_kind": "lean" if production_machine_checked else "",
        "certificate_artifact_path": "formal-verifier-certificate.json" if production_machine_checked else "",
        "machine_checked_obligation_count": len(obligations) if production_machine_checked else 0,
        "automated_claim_finalization_ready": production_machine_checked,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_declaration_count": len(declarations),
        "placeholder_token_count": len(placeholder_tokens),
        "vacuous_true_declaration_count": len(vacuous_true_declarations),
        "target_theorem_expected_count": len(expected_theorem_names),
        "target_theorem_declared_count": len(declared_expected_theorem_names),
        "target_theorem_missing_count": max(0, len(expected_theorem_names) - len(declared_expected_theorem_names)),
        "formal_statement_contract_count": len(formal_statement_contracts),
        "formal_statement_contract_missing_count": max(0, len(obligations) - len(formal_statement_contracts)),
        "formal_statement_contract_source_match_count": len(matched_formal_statement_contracts),
        "formal_statement_contract_source_mismatch_count": max(0, len(normalized_formal_statement_contracts) - len(matched_formal_statement_contracts)),
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "network_performed": False,
    }
    slot_info = _write_json(workspace / "formal-verifier-slot.json", formal_slot)
    proof_info = _write_json(workspace / "proof-check-result.json", proof_check)
    certificate_info = _write_json(workspace / "formal-verifier-certificate.json", certificate)
    evidence_report = {
        "created_at": dt.datetime.now().replace(microsecond=0).isoformat(sep=" "),
        "command": "research-compute-claim-evidence-execution",
        "status": "PASS" if production_machine_checked else "ATTENTION",
        "selected_claim_kind": "theorem_or_proof",
        "workspace_dir": workspace.name,
        "output_hashes": [
            {"path": "production-claim-lean-source.lean", "sha256": copied_source_info["sha256"], "bytes": copied_source_info["bytes"]},
            {"path": "formal-verifier-slot.json", "sha256": slot_info["sha256"], "bytes": slot_info["bytes"]},
            {"path": "proof-check-result.json", "sha256": proof_info["sha256"], "bytes": proof_info["bytes"]},
            {"path": "formal-verifier-certificate.json", "sha256": certificate_info["sha256"], "bytes": certificate_info["bytes"]},
        ],
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "selected_claim_packet": packet,
    }
    evidence_info = _write_json(output_root / "production-claim-lean-execution-evidence-execution.json", evidence_report)
    evidence_report["report_path"] = evidence_info["path"]
    evidence_report["report_sha256"] = evidence_info["sha256"]
    certificate_intake = research_compute_formal_verifier_certificate_intake.formal_verifier_certificate_intake(
        evidence_report,
        root=str(output_root),
        label=label or "",
    )
    certificate_accepted = bool(
        certificate_intake.get("status") == "PASS"
        and certificate_intake.get("formal_certificate_verified")
        and certificate_intake.get("machine_checked_formal_claim_allowed")
    )

    checks = [
        _check("production_claim_lean_plan_ready", not validation_issues, "production_claim_lean_plan_not_consumable"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("lean_declarations_present", declarations_present, "lean_declarations_missing"),
        _check("lean_placeholder_tokens_absent", placeholders_absent, "lean_placeholder_tokens_present"),
        _check("lean_vacuous_true_declarations_absent", vacuous_true_absent, "lean_vacuous_true_declarations_present"),
        _check("lean_target_theorem_names_declared", target_theorem_names_declared, "lean_target_theorem_names_missing"),
        _check("proof_obligations_present", bool(obligations), "proof_obligations_missing"),
        _check("formal_statement_contracts_cover_obligations", formal_statement_contracts_complete, "formal_statement_contracts_missing"),
        _check("formal_statement_contracts_match_lean_source", formal_statement_contracts_match_source, "formal_statement_contracts_not_found_in_lean_source"),
        _check("certificate_intake_accepted", certificate_accepted, "certificate_intake_not_accepted"),
        _check("no_source_mutation", True),
        _check("no_external_action", True),
    ]
    issue_checks = [item for item in checks if item.get("status") != "PASS"]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif production_machine_checked and certificate_accepted and not issue_checks:
        status = "PASS"
        state = PASS_STATE
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
    return {
        "command": COMMAND,
        "status": status,
        "formal_verifier_production_claim_lean_execution_attempt_state": state,
        "label": label or "",
        "plan_only": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_execution_attempt_ready": status == "PASS",
        "production_claim_machine_checked": production_machine_checked and certificate_accepted,
        "certificate_intake_accepted": certificate_accepted,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": str(lean_source),
        "claim_packet_id": packet.get("claim_packet_id") or report.get("claim_packet_id") or "",
        "slug": packet.get("slug") or report.get("slug") or "",
        "plan_report_path": report.get("report_path") or "",
        "workspace_root": str(root),
        "attempt_workspace_dir": str(workspace),
        "attempt_evidence_report_path": evidence_info["path"],
        "certificate_path": certificate_info["path"],
        "summary": {
            "validation_issue_count": len(validation_issues),
            "lean_declaration_count": len(declarations),
            "placeholder_token_count": len(placeholder_tokens),
            "vacuous_true_declaration_count": len(vacuous_true_declarations),
            "target_theorem_expected_count": len(expected_theorem_names),
            "target_theorem_declared_count": len(declared_expected_theorem_names),
            "target_theorem_missing_count": max(0, len(expected_theorem_names) - len(declared_expected_theorem_names)),
            "proof_obligation_count": len(obligations),
            "formal_statement_contract_count": len(formal_statement_contracts),
            "formal_statement_contract_missing_count": max(0, len(obligations) - len(formal_statement_contracts)),
            "formal_statement_contract_source_match_count": len(matched_formal_statement_contracts),
            "formal_statement_contract_source_mismatch_count": max(0, len(normalized_formal_statement_contracts) - len(matched_formal_statement_contracts)),
            "artifact_count": 5,
            "certificate_intake_accepted_count": 1 if certificate_accepted else 0,
            "production_claim_machine_checked_count": 1 if production_machine_checked and certificate_accepted else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": str(lean_source),
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "declaration_names": declaration_names,
            "expected_theorem_names": expected_theorem_names,
            "declared_expected_theorem_names": declared_expected_theorem_names,
            "placeholder_token_count": len(placeholder_tokens),
            "vacuous_true_declaration_count": len(vacuous_true_declarations),
            "formal_statement_contract_count": len(formal_statement_contracts),
            "formal_statement_contracts": normalized_formal_statement_contracts,
            "source_statement_signatures": source_statement_signatures,
            "matched_formal_statement_contracts": matched_formal_statement_contracts,
        },
        "certificate_intake_report": certificate_intake,
        "selected_claim_packet": packet,
        "boundary": [
            "This command may execute Lean on a production-claim formalization file, but it refuses comment-only skeletons and placeholder proofs.",
            "A Lean exit code of zero is not enough: theorem/lemma declarations, the plan's expected theorem name, explicit formal-statement contracts for all obligations that match Lean source declarations, no placeholder tokens, no vacuous : True declarations, proof-obligation coverage, and certificate intake acceptance are all required.",
            "It writes only local attempt artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_execution_attempt_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Execution Attempt",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_execution_attempt_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        f"- Certificate intake accepted: {report.get('certificate_intake_accepted')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for item in report.get("checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
