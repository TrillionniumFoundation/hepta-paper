"""Classify whether dispatched Lean work is ready for a proof attempt."""

import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-feasibility-gate"
DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-work-item-dispatch"

DISPATCH_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_WORK_ITEM_DISPATCH_READY"
DISPATCH_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"

CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_MACHINE_CHECKED_CLOSED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_READY_FOR_PROOF_ATTEMPT"
STATEMENT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_MATHEMATICAL_STATEMENT_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_feasibility_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_feasibility_gate_ready",
    "lean_proof_attempt_ready",
    "mathematical_statement_required",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "dispatch_report_path",
    "dispatch_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "work_item_classifications",
    "dispatch_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "work_item_count",
    "candidate_formal_statement_count",
    "vacuous_true_statement_count",
    "missing_formal_statement_count",
    "process_obligation_count",
    "lean_proof_attempt_ready_count",
    "mathematical_statement_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes Lean work-item dispatch evidence and decides whether a proof attempt has actual formal theorem statements to verify.",
    "Process/checklist obligations are not treated as mathematical theorem statements.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PROCESS_OBLIGATION_MARKERS = [
    "checklist",
    "downgrade",
    "scope",
    "boundary",
    "referee_gap",
    "no_write",
    "verification",
    "evidence",
]
VACUOUS_TRUE_STATEMENT_RE = re.compile(
    r"^\s*(?:theorem|lemma)\s+[A-Za-z_][A-Za-z0-9_']*[\s\S]*?:\s*True\s*:=",
    re.M,
)


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _dispatch_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_work_item_dispatch_report_missing")
        return issues
    if report.get("command") != DISPATCH_COMMAND:
        _issue(issues, "production_claim_lean_work_item_dispatch_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_work_item_dispatch_not_pass", report.get("status") or "")
    if not report.get("formalization_work_item_dispatch_ready"):
        _issue(issues, "production_claim_lean_work_item_dispatch_not_ready")
    state = report.get("formal_verifier_production_claim_lean_work_item_dispatch_state") or ""
    if state not in {DISPATCH_READY_STATE, DISPATCH_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_work_item_dispatch_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_dispatch_boundary:{key}")
    return issues


def _item_statement_text(item):
    for key in ["lean_statement", "formal_statement", "theorem_statement", "lean_declaration"]:
        value = str((item or {}).get(key) or "").strip()
        if value:
            return value
    return ""


def _item_is_process_obligation(item):
    text = " ".join(
        [
            str((item or {}).get("work_item_id") or ""),
            str((item or {}).get("obligation_name") or ""),
            str((item or {}).get("description") or ""),
            str((item or {}).get("lean_task") or ""),
        ]
    ).lower()
    return any(marker in text for marker in PROCESS_OBLIGATION_MARKERS)


def _classify_item(item):
    item = item or {}
    statement_text = _item_statement_text(item)
    has_statement = bool(statement_text)
    vacuous_true_statement = bool(VACUOUS_TRUE_STATEMENT_RE.search(statement_text))
    process_obligation = _item_is_process_obligation(item)
    proof_attempt_ready = bool(has_statement and not process_obligation and not vacuous_true_statement)
    if proof_attempt_ready:
        next_required_action = "prove_candidate_statement"
    elif vacuous_true_statement:
        next_required_action = "extract_non_vacuous_mathematical_theorem_statement"
    else:
        next_required_action = "extract_mathematical_theorem_statement"
    return {
        "work_item_id": item.get("work_item_id") or "",
        "obligation_name": item.get("obligation_name") or "",
        "source_locator": item.get("source_locator") or "",
        "has_candidate_formal_statement": has_statement,
        "vacuous_true_statement": vacuous_true_statement,
        "process_or_evidence_obligation": process_obligation,
        "lean_proof_attempt_ready": proof_attempt_ready,
        "next_required_action": next_required_action,
    }


def formal_verifier_production_claim_lean_feasibility_gate(
    work_item_dispatch_report=None,
    label="",
):
    dispatch_report = work_item_dispatch_report or {}
    validation_issues = _dispatch_issues(dispatch_report)
    work_items = list(dispatch_report.get("formalization_work_items") or [])
    classifications = [_classify_item(item) for item in work_items]
    machine_checked = bool(
        dispatch_report.get("formal_verifier_production_claim_lean_work_item_dispatch_state") == DISPATCH_CLOSED_STATE
        and dispatch_report.get("production_claim_machine_checked")
    )
    ready_items = [item for item in classifications if item["lean_proof_attempt_ready"]]
    missing_statement_count = sum(1 for item in classifications if not item["has_candidate_formal_statement"])
    if dispatch_report.get("dispatch_route") == "formalization" and not work_items:
        _issue(validation_issues, "production_claim_lean_work_items_missing")

    checks = [
        _check("work_item_dispatch_report_consumable", not _dispatch_issues(dispatch_report), "production_claim_lean_work_item_dispatch_not_consumable"),
        _check("work_items_present_or_closed", machine_checked or bool(work_items), "production_claim_lean_work_items_missing"),
        _check("no_source_mutation", not dispatch_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not dispatch_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif ready_items:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "lean_proof_attempt"
        next_agent_command = dispatch_report.get("next_agent_command") or ""
    else:
        status = "PASS"
        state = STATEMENT_REQUIRED_STATE
        next_agent_stage = "mathematical_theorem_statement_extraction"
        next_agent_command = dispatch_report.get("next_agent_command") or ""

    statement_required = bool(status == "PASS" and state == STATEMENT_REQUIRED_STATE)
    proof_attempt_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_feasibility_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_feasibility_gate_ready": status == "PASS",
        "lean_proof_attempt_ready": proof_attempt_ready,
        "mathematical_statement_required": statement_required,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": dispatch_report.get("claim_packet_id") or "",
        "slug": dispatch_report.get("slug") or "",
        "dispatch_report_path": dispatch_report.get("report_path") or "",
        "dispatch_report_sha256": dispatch_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "work_item_count": len(work_items),
            "candidate_formal_statement_count": sum(1 for item in classifications if item["has_candidate_formal_statement"]),
            "vacuous_true_statement_count": sum(1 for item in classifications if item["vacuous_true_statement"]),
            "missing_formal_statement_count": missing_statement_count,
            "process_obligation_count": sum(1 for item in classifications if item["process_or_evidence_obligation"]),
            "lean_proof_attempt_ready_count": 1 if proof_attempt_ready else 0,
            "mathematical_statement_required_count": 1 if statement_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "work_item_classifications": classifications,
        "dispatch_report": dispatch_report,
        "boundary": [
            "This command separates mathematical theorem-statement extraction from Lean proof execution.",
            "Process, evidence, checklist, downgrade, and no-write obligations are not accepted as Lean theorem statements.",
            "Vacuous theorem/lemma declarations of type True are not accepted as production theorem statements.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_feasibility_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Feasibility Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_feasibility_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean proof attempt ready: {report.get('lean_proof_attempt_ready')}",
        f"- Mathematical statement required: {report.get('mathematical_statement_required')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Work Item Classifications", ""])
    for item in report.get("work_item_classifications") or []:
        lines.append(
            f"- {item.get('work_item_id')}: statement={item.get('has_candidate_formal_statement')} "
            f"process={item.get('process_or_evidence_obligation')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
