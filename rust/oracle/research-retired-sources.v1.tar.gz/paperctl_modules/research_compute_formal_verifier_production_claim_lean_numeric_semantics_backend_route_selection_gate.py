"""Select the next non-vacuous backend route for Lean numeric semantics proofs."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-backend-route-selection-gate"
PRODUCTION_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-local-backend-production-plan"

PRODUCTION_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_BACKEND_PRODUCTION_PLAN_READY"
PRODUCTION_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_BACKEND_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"

TRUSTED_IMPORT_RECOMMENDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_TRUSTED_IMPORT_SETUP_RECOMMENDED"
LOCAL_BACKEND_RECOMMENDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_LOCAL_BACKEND_AUTHORING_RECOMMENDED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_backend_route_selection_gate_ready",
    "recommended_backend_route",
    "trusted_import_setup_recommended",
    "local_backend_authoring_recommended",
    "backend_action_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "local_backend_production_plan_report_path",
    "local_backend_production_plan_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "route_decisions",
    "selected_route_acceptance_criteria",
    "critical_blockers",
    "local_backend_production_plan_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "route_decision_count",
    "selected_route_count",
    "trusted_import_setup_recommended_count",
    "local_backend_authoring_recommended_count",
    "backend_action_required_count",
    "local_backend_production_item_count",
    "critical_blocker_count",
    "acceptance_criterion_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the local backend production plan and selects a preferred next proof-source route.",
    "The route decision is report-only; it does not perform dependency setup, author proofs, execute Lean, or mutate source.",
    "The selected route remains blocked until its acceptance criteria are satisfied with no-placeholder proof/import evidence.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _production_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_local_backend_production_plan_report_missing")
        return issues
    if report.get("command") != PRODUCTION_PLAN_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_local_backend_production_plan_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_local_backend_production_plan_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_local_backend_production_plan_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_local_backend_production_plan_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan_state") or ""
    if state not in {PRODUCTION_PLAN_READY_STATE, PRODUCTION_PLAN_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_local_backend_production_plan_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_local_backend_production_plan_boundary:{key}")
    return issues


def _route_decisions(report):
    item_count = len(report.get("local_backend_production_items") or [])
    trusted_required = bool(report.get("lean_trusted_import_setup_required"))
    local_required = bool(report.get("lean_local_numeric_backend_required"))
    trusted_score = 80 if trusted_required and item_count else 40
    local_score = 50 if local_required and item_count else 30
    decisions = [
        {
            "route": "trusted_import_setup_then_law_import",
            "score": trusted_score,
            "recommended": trusted_score >= local_score,
            "action_required": True,
            "rationale": "Reuses established ordered/topological numeric laws once Lean project and Mathlib/import provenance are ready.",
            "blocking_condition": "Mathlib/import setup is not yet ready.",
        },
        {
            "route": "local_non_degenerate_numeric_backend",
            "score": local_score,
            "recommended": local_score > trusted_score,
            "action_required": True,
            "rationale": "Avoids external imports but requires authoring a full nondegenerate scalar backend and all law proofs locally.",
            "blocking_condition": "No local theorem/lemma proof sources exist for the law items.",
        },
    ]
    return decisions


def formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate(
    local_backend_production_plan_report=None,
    label="",
):
    plan_report = local_backend_production_plan_report or {}
    validation_issues = _production_plan_issues(plan_report)
    machine_checked = bool(
        plan_report.get("production_claim_machine_checked")
        and plan_report.get("formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan_state") == PRODUCTION_PLAN_CLOSED_STATE
    )
    decisions = [] if machine_checked else _route_decisions(plan_report)
    selected = [item for item in decisions if item.get("recommended")]
    if not selected and not machine_checked:
        _issue(validation_issues, "backend_route_recommendation_missing")

    selected_route = selected[0].get("route") if selected else ""
    trusted_recommended = selected_route == "trusted_import_setup_then_law_import"
    local_recommended = selected_route == "local_non_degenerate_numeric_backend"
    acceptance = [
        "Selected route must satisfy all five local backend production items.",
        "No selected route may use Unit/True/Subsingleton shortcuts, placeholders, or signature fields as proofs.",
        "Trusted import route requires a successful import probe and local dependency provenance before satisfying a law item.",
        "Local backend route requires no-placeholder theorem/lemma evidence for order, inverse/sqrt, filter, and theorem-bridge obligations.",
    ]
    blockers = list(plan_report.get("critical_blockers") or [])
    checks = [
        _check("local_backend_production_plan_consumable", not _production_plan_issues(plan_report), "production_claim_lean_numeric_semantics_local_backend_production_plan_not_consumable"),
        _check("route_decision_present_or_closed", machine_checked or bool(selected), "backend_route_recommendation_missing"),
        _check("selected_route_action_required", machine_checked or bool(selected and selected[0].get("action_required")), "selected_route_action_missing", severity="readiness"),
        _check("no_source_mutation", not plan_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not plan_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif trusted_recommended:
        status = "PASS"
        state = TRUSTED_IMPORT_RECOMMENDED_STATE
        next_agent_stage = "trusted_import_setup_execution_plan"
        next_agent_command = ""
    else:
        status = "PASS"
        state = LOCAL_BACKEND_RECOMMENDED_STATE
        next_agent_stage = "local_non_degenerate_numeric_backend_draft"
        next_agent_command = ""

    action_required = bool(status == "PASS" and selected and selected[0].get("action_required"))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_backend_route_selection_gate_ready": status == "PASS",
        "recommended_backend_route": selected_route,
        "trusted_import_setup_recommended": trusted_recommended,
        "local_backend_authoring_recommended": local_recommended,
        "backend_action_required": action_required,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": plan_report.get("claim_packet_id") or "",
        "slug": plan_report.get("slug") or "",
        "local_backend_production_plan_report_path": plan_report.get("report_path") or "",
        "local_backend_production_plan_report_sha256": plan_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "route_decision_count": len(decisions),
            "selected_route_count": len(selected),
            "trusted_import_setup_recommended_count": 1 if trusted_recommended else 0,
            "local_backend_authoring_recommended_count": 1 if local_recommended else 0,
            "backend_action_required_count": 1 if action_required else 0,
            "local_backend_production_item_count": len(plan_report.get("local_backend_production_items") or []),
            "critical_blocker_count": len(blockers),
            "acceptance_criterion_count": len(acceptance),
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "route_decisions": decisions,
        "selected_route_acceptance_criteria": acceptance,
        "critical_blockers": blockers,
        "local_backend_production_plan_report": plan_report,
        "boundary": [
            "This command selects a route only; it does not execute the selected route.",
            "The recommended route remains blocked until its setup/proof-source acceptance criteria are satisfied.",
            "It does not execute Lean, mutate dependency/source/manuscript/package/archive state, fetch dependencies, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Backend Route Selection Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Recommended route: {report.get('recommended_backend_route') or ''}",
        f"- Action required: {report.get('backend_action_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Route Decisions", ""])
    for item in report.get("route_decisions") or []:
        lines.append(
            f"- {item.get('route')}: score={item.get('score')} "
            f"recommended={item.get('recommended')} action_required={item.get('action_required')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
