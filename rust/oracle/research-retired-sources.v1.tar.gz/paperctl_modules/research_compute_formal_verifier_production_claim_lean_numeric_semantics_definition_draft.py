"""Draft Lean numeric asymptotic semantics after refinement work-item gating."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-definition-draft"
REFINEMENT_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-refinement-gate"

REFINEMENT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_NUMERIC_REFINEMENT_REQUIRED"
REFINEMENT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_READY_FOR_THEOREM_DRAFT"
REFINEMENT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_MACHINE_CHECKED_CLOSED"

ALGEBRAIC_LAWS_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_ALGEBRAIC_LAWS_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_READY_FOR_THEOREM_DRAFT"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_definition_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_definition_draft_ready",
    "lean_algebraic_laws_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "numeric_semantics_refinement_gate_report_path",
    "numeric_semantics_refinement_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "numeric_semantics_definition_drafts",
    "numeric_semantics_refinement_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "numeric_semantics_work_item_count",
    "numeric_definition_draft_count",
    "lean_structure_count",
    "lean_definition_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "lean_algebraic_laws_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes numeric-semantics refinement work items and drafts Lean definitions for real-rate-like asymptotic semantics.",
    "The draft introduces operations for order, inverse, and square root, but does not certify algebraic/order/topology laws.",
    "This command writes local draft artifacts, syntax-checks Lean, and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
DEFINITION_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _refinement_gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_refinement_gate_report_missing")
        return issues
    if report.get("command") != REFINEMENT_GATE_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_refinement_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_refinement_gate_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_refinement_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_refinement_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_refinement_gate_state") or ""
    if state not in {REFINEMENT_REQUIRED_STATE, REFINEMENT_READY_STATE, REFINEMENT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_refinement_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_refinement_gate_boundary:{key}")
    return issues


def _lean_identifier(value, fallback="ProductionClaimFormalization"):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    ident = "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)
    if not ident or not ident[0].isalpha():
        ident = fallback
    return ident[:120]


def _definition_drafts(report):
    drafts = []
    for item in report.get("numeric_semantics_work_items") or []:
        work_item_id = item.get("work_item_id") or ""
        drafts.append(
            {
                "work_item_id": work_item_id,
                "kind": item.get("kind") or "",
                "lean_definition_name": _lean_identifier(work_item_id, "NumericSemanticsDefinition"),
                "required_definition": item.get("required_definition") or "",
                "affected_primitives": list(item.get("affected_primitives") or []),
                "lean_definition_draft_available": True,
                "algebraic_laws_complete": False,
                "next_required_action": "supply_algebraic_order_and_topology_laws",
            }
        )
    return drafts


def _lean_source(report, drafts):
    namespace = _lean_identifier(report.get("slug") or "ProductionClaim", "ProductionClaimFormalization")
    lines = [
        "/-",
        "paper_factory production claim Lean numeric-semantics draft.",
        "This file moves beyond Nat proxy rates by making order, inverse,",
        "square-root, and asymptotic comparison operations explicit.",
        "The algebraic, order, and topology laws remain a required boundary.",
        "-/",
        "",
        "universe u",
        "",
        f"namespace {namespace}",
        "",
        "structure RateScalar where",
        "  Carrier : Type u",
        "  zero : Carrier",
        "  one : Carrier",
        "  add : Carrier -> Carrier -> Carrier",
        "  mul : Carrier -> Carrier -> Carrier",
        "  inv : Carrier -> Carrier",
        "  sqrt : Carrier -> Carrier",
        "  le : Carrier -> Carrier -> Prop",
        "  lt : Carrier -> Carrier -> Prop",
        "",
        "structure NumericRateInputs (S : RateScalar) where",
        "  barRhoN : Nat -> S.Carrier",
        "  n2Scale : Nat -> S.Carrier",
        "  deltaT : Nat -> S.Carrier",
        "  driftBlockError : Nat -> S.Carrier",
        "  diffusionBlockError : Nat -> S.Carrier",
        "",
        "def Eventually (P : Nat -> Prop) : Prop :=",
        "  Exists (fun N0 : Nat => forall N : Nat, N0 <= N -> P N)",
        "",
        "def Positive (S : RateScalar) (x : S.Carrier) : Prop :=",
        "  S.lt S.zero x",
        "",
        "def LittleO (S : RateScalar) (x scale : Nat -> S.Carrier) : Prop :=",
        "  forall c : S.Carrier, Positive S c -> Eventually (fun N => S.le (S.mul c (x N)) (scale N))",
        "",
        "def InvSqrtScale (S : RateScalar) (n2 : Nat -> S.Carrier) : Nat -> S.Carrier :=",
        "  fun N => S.inv (S.sqrt (n2 N))",
        "",
        "def SqrtDeltaTOverN2Scale (S : RateScalar) (deltaT n2 : Nat -> S.Carrier) : Nat -> S.Carrier :=",
        "  fun N => S.sqrt (S.mul (deltaT N) (S.inv (n2 N)))",
        "",
        "def FixedDeltaT (S : RateScalar) (deltaT : Nat -> S.Carrier) : Prop :=",
        "  Exists (fun d : S.Carrier => Eventually (fun N => deltaT N = d))",
        "",
        "def FixedDeltaMomentBound (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  And (FixedDeltaT S input.deltaT) (LittleO S input.barRhoN (InvSqrtScale S input.n2Scale))",
        "",
        "def DriftBlockRate (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  LittleO S input.driftBlockError (SqrtDeltaTOverN2Scale S input.deltaT input.n2Scale)",
        "",
        "def DiffusionBlockRate (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  LittleO S input.diffusionBlockError (InvSqrtScale S input.n2Scale)",
        "",
        "def HighFrequencyBlockRates (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  And (DriftBlockRate S input) (DiffusionBlockRate S input)",
        "",
        "def DirectEulerLimitEligibility (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  Or (FixedDeltaMomentBound S input) (HighFrequencyBlockRates S input)",
        "",
        "def WaldInferenceEligibility (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  DirectEulerLimitEligibility S input",
        "",
        "def NumericProductionClaimSemantics (S : RateScalar) (input : NumericRateInputs S) : Prop :=",
        "  WaldInferenceEligibility S input",
        "",
    ]
    lines.extend(
        [
            "/- Numeric work-item draft index.",
            "The next stage must attach laws for RateScalar and connect",
            "the filter/eventual semantics to the manuscript theorem target.",
        ]
    )
    for item in drafts:
        lines.append(
            f"{item.get('work_item_id')}: {item.get('lean_definition_name')} "
            f"affected={','.join(item.get('affected_primitives') or [])}"
        )
    lines.extend(["-/", "", f"end {namespace}", ""])
    return "\n".join(lines)


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_production_claim_lean_numeric_semantics_definition_draft(
    numeric_semantics_refinement_gate_report=None,
    output_root=None,
    lean_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    gate_report = numeric_semantics_refinement_gate_report or {}
    validation_issues = _refinement_gate_issues(gate_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(
        gate_report.get("production_claim_machine_checked")
        and gate_report.get("formal_verifier_production_claim_lean_numeric_semantics_refinement_gate_state") == REFINEMENT_CLOSED_STATE
    )
    drafts = _definition_drafts(gate_report)
    lean_source_text = _lean_source(gate_report, drafts)
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-definition-draft.lean", lean_source_text)
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if selected_lean:
        try:
            result = _run_lean(selected_lean, source_info["path"], timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    definitions = DEFINITION_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    algebraic_laws_complete = False
    checks = [
        _check("numeric_semantics_refinement_gate_report_consumable", not _refinement_gate_issues(gate_report), "production_claim_lean_numeric_semantics_refinement_gate_not_consumable"),
        _check("numeric_semantics_work_items_present_or_closed", machine_checked or bool(drafts), "numeric_semantics_work_items_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("lean_structures_present", bool(structures), "lean_structures_missing"),
        _check("lean_definitions_present", bool(definitions), "lean_definitions_missing"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("algebraic_order_topology_laws_complete", machine_checked or algebraic_laws_complete, "algebraic_order_topology_laws_required", severity="readiness"),
        _check("no_source_mutation", not gate_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not gate_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif lean_exit_zero and structures and definitions and drafts and not placeholders and not algebraic_laws_complete:
        status = "PASS"
        state = ALGEBRAIC_LAWS_REQUIRED_STATE
        next_agent_stage = "numeric_semantics_law_gate"
        next_agent_command = ""
    elif lean_exit_zero and structures and definitions and drafts and not placeholders:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    law_required = bool(status == "PASS" and state == ALGEBRAIC_LAWS_REQUIRED_STATE)
    theorem_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_definition_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_definition_draft_ready": bool(status == "PASS" and state in {ALGEBRAIC_LAWS_REQUIRED_STATE, READY_STATE}),
        "lean_algebraic_laws_required": law_required,
        "lean_theorem_draft_ready": theorem_ready,
        "production_claim_machine_checked": machine_checked,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": gate_report.get("claim_packet_id") or "",
        "slug": gate_report.get("slug") or "",
        "numeric_semantics_refinement_gate_report_path": gate_report.get("report_path") or "",
        "numeric_semantics_refinement_gate_report_sha256": gate_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "numeric_semantics_work_item_count": len(gate_report.get("numeric_semantics_work_items") or []),
            "numeric_definition_draft_count": len(drafts),
            "lean_structure_count": len(structures),
            "lean_definition_count": len(definitions),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "lean_algebraic_laws_required_count": 1 if law_required else 0,
            "lean_theorem_draft_ready_count": 1 if theorem_ready else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "definition_names": definitions,
            "placeholder_token_count": len(placeholders),
        },
        "numeric_semantics_definition_drafts": drafts,
        "numeric_semantics_refinement_gate_report": gate_report,
        "boundary": [
            "This command drafts numeric asymptotic definitions, but RateScalar algebraic/order/topology laws are still required.",
            "The resulting Lean file is syntax-checked only; it is not a theorem proof or a production-claim certificate.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_definition_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Definition Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_definition_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Algebraic laws required: {report.get('lean_algebraic_laws_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Numeric Semantics Definition Drafts", ""])
    for item in report.get("numeric_semantics_definition_drafts") or []:
        lines.append(
            f"- {item.get('work_item_id')}: {item.get('lean_definition_name')} "
            f"laws_complete={item.get('algebraic_laws_complete')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
