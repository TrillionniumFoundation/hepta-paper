"""Gate whether the Wald/direct-Euler bridge statement has a real proof source."""

import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-proof-source-gate"
STATEMENT_DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-statement-draft"

STATEMENT_DRAFT_PROOF_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_STATEMENT_DRAFT_PROOF_REQUIRED"
STATEMENT_DRAFT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_STATEMENT_DRAFT_MACHINE_CHECKED_CLOSED"

PROOF_SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_PROOF_SOURCE_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_READY_FOR_NO_PLACEHOLDER_PROOF"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_ready",
    "domain_theorem_bridge_proof_source_required",
    "domain_theorem_bridge_no_placeholder_proof_available",
    "placeholder_proof_rejected",
    "assumption_echo_allowed",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_statement_draft_report_path",
    "domain_theorem_bridge_statement_draft_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "proof_source_classifications",
    "proof_source_gaps",
    "domain_theorem_bridge_statement_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "lean_declaration_count",
    "placeholder_token_count",
    "proof_source_available_count",
    "proof_source_gap_count",
    "placeholder_proof_rejected_count",
    "domain_theorem_bridge_proof_source_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the Wald/direct-Euler domain bridge Lean statement draft and refuses axiom/sorry placeholders as proof evidence.",
    "Only no-placeholder Lean proof source or a trusted local theorem can unlock proof execution.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
DECLARATION_RE = re.compile(r"^\s*(theorem|lemma|axiom)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _statement_draft_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_statement_draft_report_missing")
        return issues
    if report.get("command") != STATEMENT_DRAFT_COMMAND:
        _issue(issues, "domain_theorem_bridge_statement_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_statement_draft_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft_state") or ""
    if state not in {STATEMENT_DRAFT_PROOF_REQUIRED_STATE, STATEMENT_DRAFT_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_statement_draft_state_not_consumable", state)
    if not report.get("lean_domain_theorem_bridge_statements") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_lean_statement_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_statement_draft_boundary:{key}")
    return issues


def _lean_source_text(report):
    path = pathlib.Path(report.get("lean_source_path") or "")
    if not path.exists():
        return "", "lean_source_path_missing"
    try:
        return path.read_text(errors="replace"), ""
    except OSError as exc:
        return "", f"lean_source_read_failed:{exc}"


def _classify_statement(item, placeholders):
    declaration_kind = item.get("declaration_kind") or ""
    declaration_name = item.get("lean_declaration_name") or ""
    proof_available = bool(
        item.get("proof_available")
        or item.get("no_placeholder_proof_available")
        or item.get("trusted_local_theorem")
        or item.get("proof_artifact_sha256")
    )
    placeholder_required = bool(item.get("placeholder_proof_required") or declaration_kind == "axiom" or placeholders)
    gap = bool(not proof_available or placeholder_required)
    return {
        "lean_declaration_name": declaration_name,
        "declaration_kind": declaration_kind,
        "proof_available": proof_available,
        "placeholder_proof_present": placeholder_required,
        "placeholder_proof_rejected": placeholder_required,
        "proof_source_gap": gap,
        "assumption_echo_allowed": False,
        "next_required_action": "supply_no_placeholder_domain_theorem_bridge_proof_source" if gap else "run_no_placeholder_proof_execution",
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate(
    domain_theorem_bridge_statement_draft_report=None,
    label="",
):
    statement_report = domain_theorem_bridge_statement_draft_report or {}
    validation_issues = _statement_draft_issues(statement_report)
    source_text, source_issue = _lean_source_text(statement_report)
    if source_issue and statement_report:
        _issue(validation_issues, source_issue)
    placeholders = PLACEHOLDER_RE.findall(source_text)
    declarations = DECLARATION_RE.findall(source_text)
    classifications = [
        _classify_statement(item, placeholders)
        for item in statement_report.get("lean_domain_theorem_bridge_statements") or []
    ]
    proof_gaps = [item for item in classifications if item["proof_source_gap"]]
    proof_available_count = sum(1 for item in classifications if item["proof_available"] and not item["placeholder_proof_present"])
    placeholder_rejected = bool(placeholders or any(item["placeholder_proof_present"] for item in classifications))
    machine_checked = bool(
        statement_report.get("production_claim_machine_checked")
        and statement_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft_state") == STATEMENT_DRAFT_CLOSED_STATE
    )
    ready_for_proof = bool(not validation_issues and classifications and not proof_gaps and not machine_checked)
    checks = [
        _check("domain_theorem_bridge_statement_draft_report_consumable", not _statement_draft_issues(statement_report), "domain_theorem_bridge_statement_draft_not_consumable"),
        _check("lean_source_readable", not source_issue, source_issue or "lean_source_path_missing"),
        _check("lean_declaration_present_or_closed", machine_checked or bool(declarations), "lean_domain_theorem_bridge_declaration_missing"),
        _check("no_placeholder_proof_available", ready_for_proof or machine_checked, "domain_theorem_bridge_no_placeholder_proof_source_missing", severity="readiness"),
        _check("placeholder_proof_rejected", placeholder_rejected or machine_checked, "placeholder_proof_not_detected_for_rejection", severity="readiness"),
        _check("assumption_echo_disallowed", True, ""),
        _check("no_source_mutation", not statement_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not statement_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif ready_for_proof:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "domain_theorem_bridge_no_placeholder_proof_execution"
        next_agent_command = ""
    else:
        status = "PASS"
        state = PROOF_SOURCE_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_proof_source_intake"
        next_agent_command = ""

    proof_source_required = bool(status == "PASS" and state == PROOF_SOURCE_REQUIRED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_ready": status == "PASS",
        "domain_theorem_bridge_proof_source_required": proof_source_required,
        "domain_theorem_bridge_no_placeholder_proof_available": bool(status == "PASS" and state == READY_STATE),
        "placeholder_proof_rejected": bool(status == "PASS" and placeholder_rejected and not machine_checked),
        "assumption_echo_allowed": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": statement_report.get("claim_packet_id") or "",
        "slug": statement_report.get("slug") or "",
        "domain_theorem_bridge_statement_draft_report_path": statement_report.get("report_path") or "",
        "domain_theorem_bridge_statement_draft_report_sha256": statement_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "lean_declaration_count": len(declarations),
            "placeholder_token_count": len(placeholders),
            "proof_source_available_count": proof_available_count,
            "proof_source_gap_count": len(proof_gaps),
            "placeholder_proof_rejected_count": 1 if placeholder_rejected and not machine_checked else 0,
            "domain_theorem_bridge_proof_source_required_count": 1 if proof_source_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "proof_source_classifications": classifications,
        "proof_source_gaps": proof_gaps,
        "domain_theorem_bridge_statement_draft_report": statement_report,
        "boundary": [
            "This command rejects axiom/sorry/admit/opaque placeholders as Wald/direct-Euler bridge proof evidence.",
            "The bridge still requires a no-placeholder Lean proof or trusted local theorem source before production-claim machine checking can close.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Proof Source Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Proof source required: {report.get('domain_theorem_bridge_proof_source_required')}",
        f"- Placeholder proof rejected: {report.get('placeholder_proof_rejected')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Proof Source Gaps", ""])
    for item in report.get("proof_source_gaps") or []:
        lines.append(f"- {item.get('lean_declaration_name')}: {item.get('next_required_action')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
