"""Intake local proof sources for the Wald/direct-Euler domain bridge."""

import hashlib
import os
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-proof-source-intake"
PROOF_SOURCE_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-proof-source-gate"

PROOF_SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_PROOF_SOURCE_REQUIRED"
PROOF_SOURCE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_READY_FOR_NO_PLACEHOLDER_PROOF"
PROOF_SOURCE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_GATE_MACHINE_CHECKED_CLOSED"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_ready",
    "domain_theorem_bridge_proof_sources_required",
    "domain_theorem_bridge_proof_source_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_proof_source_gate_report_path",
    "domain_theorem_bridge_proof_source_gate_report_sha256",
    "source_root",
    "candidate_limit",
    "excluded_directory_names",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "proof_source_intake_classifications",
    "candidate_lean_source_files",
    "candidate_manuscript_source_contexts",
    "domain_theorem_bridge_proof_source_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_gap_count",
    "local_lean_file_count",
    "local_text_source_file_count",
    "candidate_lean_source_file_count",
    "candidate_manuscript_source_context_count",
    "proof_source_candidate_count",
    "proof_source_ready_count",
    "proof_source_required_count",
    "placeholder_candidate_count",
    "assumption_echo_candidate_count",
    "vacuous_true_candidate_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the Wald/direct-Euler bridge proof-source gate and inventories local Lean/source candidates.",
    "Only theorem/lemma-style Lean sources without placeholder tokens, without vacuous : True bodies, and without assumption-echo markers can satisfy the bridge.",
    "Mathlib cache and external dependency directories are excluded; this command reads local files and writes reports only.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
EXCLUDED_DIR_NAMES = {
    ".git",
    ".lake",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "logs",
    "node_modules",
}
TEXT_SUFFIXES = {".tex", ".md"}
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
NEXT_DECL_RE = re.compile(r"^\s*(theorem|lemma|def|structure|inductive|namespace|section|end)\b")
NAMESPACE_RE = re.compile(r"^\s*namespace\b")
SECTION_RE = re.compile(r"^\s*section\b")
END_RE = re.compile(r"^\s*end\b")
ASSUMPTION_ECHO_RE = re.compile(r"\b(exact\s+I\.waldDirectEulerValid|exact\s+h|by\s+assumption|assumption)\b")
VACUOUS_TRUE_RE = re.compile(r":\s*True\s*:=", re.M)
DOMAIN_MARKER_RE = re.compile(
    r"(waldDirectEulerDomainBridge|Wald|direct Euler|direct-score|profileEquivalence|profile-equivalence|"
    r"barRhoN|rhoAlpha|rhoBeta|rho_\{N,\\alpha\}|rho_\{N,\\beta\}|IsLittleO|LittleOAtTop|atTop)"
)


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_proof_source_gate_report_missing")
        return issues
    if report.get("command") != PROOF_SOURCE_GATE_COMMAND:
        _issue(issues, "domain_theorem_bridge_proof_source_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_proof_source_gate_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_proof_source_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_state") or ""
    if state not in {PROOF_SOURCE_REQUIRED_STATE, PROOF_SOURCE_READY_STATE, PROOF_SOURCE_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_proof_source_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_proof_source_gate_boundary:{key}")
    return issues


def _walk_files(source_root, suffixes, candidate_limit):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
        for filename in filenames:
            if len(files) >= int(candidate_limit or 0):
                return files
            path = pathlib.Path(dirpath) / filename
            if path.suffix in suffixes and path.is_file():
                files.append(path)
    return files


def _text_source_files(source_root, candidate_limit):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    files = []
    preferred = root / "submission" / "AoS" / "NSM_AoS" / "main.tex"
    if preferred.exists():
        files.append(preferred)
    search_roots = [root / "submission", root / "docs"]
    for search_root in search_roots:
        if not search_root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(search_root):
            dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
            for filename in filenames:
                if len(files) >= int(candidate_limit or 0):
                    return files
                path = pathlib.Path(dirpath) / filename
                if path in files:
                    continue
                if path.suffix in TEXT_SUFFIXES and path.is_file():
                    files.append(path)
    return files


def _extract_theorem_statements(lean_text):
    lines = str(lean_text or "").splitlines()
    statements = []
    scope_stack = []
    for index, line in enumerate(lines):
        match = THEOREM_RE.match(line)
        if match:
            end = len(lines)
            for later in range(index + 1, len(lines)):
                if NEXT_DECL_RE.match(lines[later]):
                    end = later
                    break
            block = "\n".join(lines[index:end])
            statement_text = block.split(":=", 1)[0]
            statement_text = re.sub(rf"^\s*{match.group(1)}\s+{re.escape(match.group(2))}\b", "", statement_text, count=1)
            statements.append(
                {
                    "name": match.group(2),
                    "statement_text": statement_text,
                    "domain_statement_marker_count": len(DOMAIN_MARKER_RE.findall(statement_text)),
                    "top_level_namespace": not any(item == "namespace" for item in scope_stack),
                }
            )
        if NAMESPACE_RE.match(line):
            scope_stack.append("namespace")
        elif SECTION_RE.match(line):
            scope_stack.append("section")
        elif END_RE.match(line) and scope_stack:
            scope_stack.pop()
    return statements


def _scan_lean_sources(source_root, candidate_limit):
    candidates = []
    for path in _walk_files(source_root, {".lean"}, candidate_limit):
        text = path.read_text(errors="replace")
        lean_text = _strip_lean_comments(text)
        theorem_statements = _extract_theorem_statements(lean_text)
        theorem_names = [item.get("name") for item in theorem_statements]
        placeholder_count = len(PLACEHOLDER_RE.findall(lean_text))
        assumption_echo_count = len(ASSUMPTION_ECHO_RE.findall(lean_text))
        vacuous_true_count = len(VACUOUS_TRUE_RE.findall(lean_text))
        domain_marker_count = len(DOMAIN_MARKER_RE.findall(lean_text))
        domain_statement_marker_count = sum(int(item.get("domain_statement_marker_count") or 0) for item in theorem_statements)
        candidates.append(
            {
                "path": str(path),
                "text_sha256": _sha256_text(text),
                "theorem_or_lemma_count": len(theorem_names),
                "theorem_or_lemma_names": theorem_names[:10],
                "placeholder_token_count": placeholder_count,
                "assumption_echo_marker_count": assumption_echo_count,
                "vacuous_true_marker_count": vacuous_true_count,
                "domain_marker_count": domain_marker_count,
                "domain_statement_marker_count": domain_statement_marker_count,
                "_domain_statement_theorem_names": [
                    item.get("name")
                    for item in theorem_statements
                    if int(item.get("domain_statement_marker_count") or 0) and item.get("top_level_namespace")
                ],
                "text": lean_text,
            }
        )
    return candidates


def _scan_text_contexts(source_root, candidate_limit):
    contexts = []
    for path in _text_source_files(source_root, candidate_limit):
        text = path.read_text(errors="replace")
        if not DOMAIN_MARKER_RE.search(text):
            continue
        lines = text.splitlines()
        for index, line in enumerate(lines):
            matched = DOMAIN_MARKER_RE.findall(line)
            if not matched:
                continue
            start = max(index - 3, 0)
            end = min(index + 4, len(lines))
            excerpt = "\n".join(lines[start:end])
            contexts.append(
                {
                    "source_locator": f"{path}:{index + 1}",
                    "context_start_line": start + 1,
                    "matched_markers": list(dict.fromkeys(matched))[:8],
                    "excerpt_sha256": _sha256_text(excerpt),
                }
            )
            if len(contexts) >= int(candidate_limit or 0):
                return contexts
    return contexts


def _candidate_terms(gap):
    terms = []
    for key in ["lean_declaration_name", "declaration_kind", "next_required_action"]:
        value = str(gap.get(key) or "").strip()
        if value:
            terms.append(value)
    terms.extend(["waldDirectEulerDomainBridge", "Wald", "directEuler", "profileEquivalence", "LittleOAtTop"])
    return [term for index, term in enumerate(terms) if term and term not in terms[:index]]


def _classify_gap(gap, lean_candidates):
    terms = _candidate_terms(gap)
    matches = []
    for candidate in lean_candidates:
        text = candidate.get("text") or ""
        matched_terms = [term for term in terms if term and term in text]
        if not matched_terms:
            continue
        domain_statement_theorem_names = set(candidate.get("_domain_statement_theorem_names") or [])
        has_named_theorem = any(name == gap.get("lean_declaration_name") for name in domain_statement_theorem_names)
        has_any_domain_theorem = bool(candidate.get("theorem_or_lemma_count") and candidate.get("domain_statement_marker_count"))
        no_placeholders = candidate.get("placeholder_token_count", 0) == 0
        no_assumption_echo = candidate.get("assumption_echo_marker_count", 0) == 0
        no_vacuous_true = candidate.get("vacuous_true_marker_count", 0) == 0
        ready = bool(has_named_theorem and no_placeholders and no_assumption_echo and no_vacuous_true)
        blockers = []
        if not has_named_theorem:
            blockers.append("domain_theorem_statement_missing")
        if not no_placeholders:
            blockers.append("placeholder_token_present")
        if not no_assumption_echo:
            blockers.append("assumption_echo_marker_present")
        if not no_vacuous_true:
            blockers.append("vacuous_true_marker_present")
        matches.append(
            {
                "path": candidate.get("path") or "",
                "text_sha256": candidate.get("text_sha256") or "",
                "matched_terms": matched_terms[:8],
                "theorem_or_lemma_count": candidate.get("theorem_or_lemma_count", 0),
                "theorem_or_lemma_names": candidate.get("theorem_or_lemma_names") or [],
                "placeholder_token_count": candidate.get("placeholder_token_count", 0),
                "assumption_echo_marker_count": candidate.get("assumption_echo_marker_count", 0),
                "vacuous_true_marker_count": candidate.get("vacuous_true_marker_count", 0),
                "domain_marker_count": candidate.get("domain_marker_count", 0),
                "domain_statement_marker_count": candidate.get("domain_statement_marker_count", 0),
                "proof_source_ready": ready,
                "blockers": blockers,
            }
        )
    ready = any(match.get("proof_source_ready") for match in matches)
    return {
        "lean_declaration_name": gap.get("lean_declaration_name") or "",
        "declaration_kind": gap.get("declaration_kind") or "",
        "required_source_kind": "local_no_placeholder_domain_theorem_bridge_proof",
        "source_candidate_count": len(matches),
        "proof_source_ready": ready,
        "source_candidates": matches[:8],
        "next_required_action": "wire_no_placeholder_domain_theorem_bridge_proof_source" if ready else "produce_no_placeholder_domain_theorem_bridge_proof_source",
    }


def _source_file_summary(candidate):
    return {
        "path": candidate.get("path") or "",
        "text_sha256": candidate.get("text_sha256") or "",
        "theorem_or_lemma_count": candidate.get("theorem_or_lemma_count", 0),
        "theorem_or_lemma_names": candidate.get("theorem_or_lemma_names") or [],
        "placeholder_token_count": candidate.get("placeholder_token_count", 0),
        "assumption_echo_marker_count": candidate.get("assumption_echo_marker_count", 0),
        "vacuous_true_marker_count": candidate.get("vacuous_true_marker_count", 0),
        "domain_marker_count": candidate.get("domain_marker_count", 0),
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake(
    domain_theorem_bridge_proof_source_gate_report=None,
    source_root="",
    candidate_limit=500,
    label="",
):
    gate_report = domain_theorem_bridge_proof_source_gate_report or {}
    validation_issues = _gate_issues(gate_report)
    machine_checked = bool(
        gate_report.get("production_claim_machine_checked")
        and gate_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_gate_state") == PROOF_SOURCE_CLOSED_STATE
    )
    proof_gaps = [] if machine_checked else list(gate_report.get("proof_source_gaps") or [])
    lean_candidates = _scan_lean_sources(source_root or ".", candidate_limit)
    text_contexts = _scan_text_contexts(source_root or ".", candidate_limit)
    classifications = [] if machine_checked else [_classify_gap(gap, lean_candidates) for gap in proof_gaps]
    ready_count = sum(1 for item in classifications if item.get("proof_source_ready"))
    candidate_count = sum(item.get("source_candidate_count", 0) for item in classifications)
    if proof_gaps and ready_count < len(proof_gaps):
        _issue(validation_issues, "domain_theorem_bridge_proof_sources_required", f"{ready_count}/{len(proof_gaps)} ready")

    checks = [
        _check("domain_theorem_bridge_proof_source_gate_report_consumable", not _gate_issues(gate_report), "domain_theorem_bridge_proof_source_gate_not_consumable"),
        _check("proof_source_gaps_present_or_closed", machine_checked or bool(proof_gaps), "domain_theorem_bridge_proof_source_gaps_missing"),
        _check("local_lean_sources_scanned", machine_checked or bool(lean_candidates), "local_lean_sources_missing", severity="readiness"),
        _check("manuscript_source_contexts_scanned", machine_checked or bool(text_contexts), "domain_theorem_bridge_source_context_missing", severity="readiness"),
        _check("all_domain_bridge_proof_sources_ready", machine_checked or (bool(proof_gaps) and ready_count == len(proof_gaps)), "domain_theorem_bridge_proof_sources_required", severity="readiness"),
        _check("no_source_mutation", not gate_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not gate_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_proof_source_gate_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif proof_gaps and ready_count == len(proof_gaps):
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "domain_theorem_bridge_no_placeholder_proof_execution"
        next_agent_command = ""
    else:
        status = "PASS"
        state = SOURCE_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_proof_source_production_plan"
        next_agent_command = ""

    source_required = bool(status == "PASS" and state == SOURCE_REQUIRED_STATE)
    proof_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_ready": status == "PASS",
        "domain_theorem_bridge_proof_sources_required": source_required,
        "domain_theorem_bridge_proof_source_ready": proof_ready,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": gate_report.get("claim_packet_id") or "",
        "slug": gate_report.get("slug") or "",
        "domain_theorem_bridge_proof_source_gate_report_path": gate_report.get("report_path") or "",
        "domain_theorem_bridge_proof_source_gate_report_sha256": gate_report.get("report_sha256") or "",
        "source_root": str(source_root or "."),
        "candidate_limit": int(candidate_limit or 0),
        "excluded_directory_names": sorted(EXCLUDED_DIR_NAMES),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_gap_count": len(proof_gaps),
            "local_lean_file_count": len(lean_candidates),
            "local_text_source_file_count": len(_text_source_files(source_root or ".", candidate_limit)),
            "candidate_lean_source_file_count": sum(1 for item in lean_candidates if item.get("domain_marker_count")),
            "candidate_manuscript_source_context_count": len(text_contexts),
            "proof_source_candidate_count": candidate_count,
            "proof_source_ready_count": ready_count,
            "proof_source_required_count": 1 if source_required else 0,
            "placeholder_candidate_count": sum(1 for item in lean_candidates if item.get("placeholder_token_count", 0) > 0 and item.get("domain_marker_count", 0) > 0),
            "assumption_echo_candidate_count": sum(1 for item in lean_candidates if item.get("assumption_echo_marker_count", 0) > 0 and item.get("domain_marker_count", 0) > 0),
            "vacuous_true_candidate_count": sum(1 for item in lean_candidates if item.get("vacuous_true_marker_count", 0) > 0 and item.get("domain_marker_count", 0) > 0),
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "proof_source_intake_classifications": classifications,
        "candidate_lean_source_files": [_source_file_summary(item) for item in lean_candidates if item.get("domain_marker_count")][:20],
        "candidate_manuscript_source_contexts": text_contexts[:20],
        "domain_theorem_bridge_proof_source_gate_report": gate_report,
        "boundary": [
            "This command inventories local proof-source candidates only; mentions, source text, and axiom drafts are not proof evidence.",
            "The Wald/direct-Euler bridge remains open until a nonvacuous no-placeholder Lean theorem or trusted local theorem source is available.",
            "It excludes dependency caches such as .lake, reads local files only, and does not execute Lean, mutate source, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Proof Source Intake",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Proof sources required: {report.get('domain_theorem_bridge_proof_sources_required')}",
        f"- Proof source ready: {report.get('domain_theorem_bridge_proof_source_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Classifications", ""])
    for item in report.get("proof_source_intake_classifications") or []:
        lines.append(
            f"- {item.get('lean_declaration_name')}: ready={item.get('proof_source_ready')} "
            f"candidates={item.get('source_candidate_count')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
