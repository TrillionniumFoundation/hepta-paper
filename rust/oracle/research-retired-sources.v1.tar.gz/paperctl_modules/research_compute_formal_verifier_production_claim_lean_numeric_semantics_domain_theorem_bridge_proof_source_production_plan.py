"""Plan production of a no-placeholder proof source for the Wald/direct-Euler bridge."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-proof-source-production-plan"
SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-proof-source-intake"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
SOURCE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_READY"
SOURCE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_PRODUCTION_PLAN_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_PRODUCTION_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_PROOF_SOURCE_PRODUCTION_PLAN_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan_ready",
    "domain_theorem_bridge_proof_sources_required",
    "domain_theorem_bridge_semantic_refinement_required",
    "assumption_echo_allowed",
    "placeholder_allowed",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_proof_source_intake_report_path",
    "domain_theorem_bridge_proof_source_intake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "proof_source_production_items",
    "acceptance_criteria",
    "critical_risks",
    "domain_theorem_bridge_proof_source_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_gap_count",
    "proof_source_production_item_count",
    "semantic_refinement_required_count",
    "acceptance_criterion_count",
    "critical_risk_count",
    "domain_theorem_bridge_proof_sources_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes domain-bridge proof-source intake gaps and plans no-placeholder proof-source production.",
    "The plan distinguishes Mathlib numeric infrastructure from the source-backed domain theorem bridge.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _source_intake_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_proof_source_intake_report_missing")
        return issues
    if report.get("command") != SOURCE_INTAKE_COMMAND:
        _issue(issues, "domain_theorem_bridge_proof_source_intake_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_proof_source_intake_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_proof_source_intake_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_state") or ""
    if state not in {SOURCE_REQUIRED_STATE, SOURCE_READY_STATE, SOURCE_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_proof_source_intake_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_proof_source_intake_boundary:{key}")
    return issues


def _source_locators(report):
    locators = []
    for context in report.get("candidate_manuscript_source_contexts") or []:
        locator = context.get("source_locator") or ""
        if locator and locator not in locators:
            locators.append(locator)
    return locators[:12]


def _plan_items(report):
    classifications = report.get("proof_source_intake_classifications") or []
    gaps = [item for item in classifications if not item.get("proof_source_ready")]
    if not gaps and not report.get("domain_theorem_bridge_proof_sources_required"):
        return []
    locators = _source_locators(report)
    return [
        {
            "work_item_id": "domain-bridge-rate-eligibility-lemma",
            "route": "formalization",
            "lean_declaration_name": "waldDirectEulerRateEligibility",
            "required_source_kind": "source_backed_rate_condition_lemma",
            "source_locators": locators,
            "semantic_refinement_required": True,
            "acceptance_criteria": [
                "formalizes fixed-Delta-t bar_rho_N=o(n_2^{-1/2}) and high-frequency rhoAlpha/rhoBeta little-o alternatives",
                "uses Mathlib Filter.atTop and Asymptotics.IsLittleO rather than an uninterpreted True field",
                "contains no sorry/admit/axiom/opaque placeholder tokens",
            ],
            "next_required_action": "draft_rate_condition_semantics_and_no_placeholder_lemma",
        },
        {
            "work_item_id": "domain-bridge-direct-euler-limit-source-lemma",
            "route": "formalization",
            "lean_declaration_name": "directEulerLimitSourceBacked",
            "required_source_kind": "source_backed_direct_euler_limit_input",
            "source_locators": locators,
            "semantic_refinement_required": True,
            "acceptance_criteria": [
                "identifies whether directEulerLimit is an assumption, imported theorem, or previously proved local theorem",
                "records provenance for the CLT/input theorem used by the bridge",
                "does not manufacture a direct Euler limit theorem from notation alone",
            ],
            "next_required_action": "classify_direct_euler_limit_as_assumption_or_proved_source",
        },
        {
            "work_item_id": "domain-bridge-profile-equivalence-transfer-lemma",
            "route": "formalization",
            "lean_declaration_name": "profileEquivalenceTransfersDirectScoreLimit",
            "required_source_kind": "source_backed_profile_equivalence_implication",
            "source_locators": locators,
            "semantic_refinement_required": True,
            "acceptance_criteria": [
                "refines profileEquivalence from a bare Prop into an implication usable by Lean",
                "proves transfer from direct-score/direct-Euler limit to profiled estimator validity",
                "rejects exact h, by assumption, or restating waldDirectEulerValid as a premise",
            ],
            "next_required_action": "draft_profile_equivalence_transfer_statement",
        },
        {
            "work_item_id": "domain-bridge-assembly-theorem",
            "route": "formalization",
            "lean_declaration_name": "waldDirectEulerDomainBridge",
            "required_source_kind": "no_placeholder_domain_bridge_theorem",
            "source_locators": locators,
            "semantic_refinement_required": True,
            "acceptance_criteria": [
                "replaces the axiom statement draft with a theorem or lemma",
                "depends only on source-backed premises and trusted Mathlib imports",
                "passes no-placeholder/sorry/admit/axiom gate and Lean execution",
            ],
            "next_required_action": "assemble_no_placeholder_domain_bridge_proof",
        },
    ]


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan(
    domain_theorem_bridge_proof_source_intake_report=None,
    label="",
):
    intake_report = domain_theorem_bridge_proof_source_intake_report or {}
    validation_issues = _source_intake_issues(intake_report)
    machine_checked = bool(
        intake_report.get("production_claim_machine_checked")
        and intake_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_intake_state") == SOURCE_CLOSED_STATE
    )
    items = [] if machine_checked else _plan_items(intake_report)
    if intake_report.get("domain_theorem_bridge_proof_sources_required") and not items and not machine_checked:
        _issue(validation_issues, "domain_theorem_bridge_proof_sources_required_but_no_production_items")

    acceptance_criteria = [
        "No proof source may use sorry, admit, axiom, opaque, or a theorem that simply restates the target as a hypothesis.",
        "The bridge must separate Mathlib numeric/order/filter facts from the source-backed domain implication.",
        "profileEquivalence and waldDirectEulerValid must be refined beyond bare Prop fields before a real proof can close.",
        "All source-backed assumptions must carry source locators or trusted local theorem provenance.",
        "Production claim machine_checked remains false until Lean verifies a no-placeholder replacement theorem.",
    ]
    critical_risks = [
        {
            "risk": "bare_prop_semantics",
            "mitigation": "refine profileEquivalence/waldDirectEulerValid into an implication-bearing structure or theorem before proof execution",
        },
        {
            "risk": "assumption_echo_proof",
            "mitigation": "reject exact h/by assumption proofs that take waldDirectEulerValid or the bridge statement as a premise",
        },
        {
            "risk": "source_overclaim",
            "mitigation": "keep direct Euler CLT/input and profile-equivalence transfer as explicit source-backed obligations",
        },
        {
            "risk": "placeholder_reintroduction",
            "mitigation": "run no-placeholder gate over the replacement theorem before any machine_checked claim",
        },
    ]
    checks = [
        _check("domain_theorem_bridge_proof_source_intake_report_consumable", not _source_intake_issues(intake_report), "domain_theorem_bridge_proof_source_intake_not_consumable"),
        _check("proof_source_production_items_present_or_closed", machine_checked or bool(items), "proof_source_production_items_missing"),
        _check("semantic_refinement_required_recorded", machine_checked or any(item.get("semantic_refinement_required") for item in items), "semantic_refinement_required_missing"),
        _check("assumption_echo_disallowed", True, ""),
        _check("placeholder_disallowed", True, ""),
        _check("no_source_mutation", not intake_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not intake_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = PLAN_READY_STATE
        next_agent_stage = "domain_theorem_bridge_semantic_refinement_draft"
        next_agent_command = ""

    sources_required = bool(status == "PASS" and items)
    semantic_refinement_required = bool(status == "PASS" and any(item.get("semantic_refinement_required") for item in items))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan_ready": status == "PASS",
        "domain_theorem_bridge_proof_sources_required": sources_required,
        "domain_theorem_bridge_semantic_refinement_required": semantic_refinement_required,
        "assumption_echo_allowed": False,
        "placeholder_allowed": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": intake_report.get("claim_packet_id") or "",
        "slug": intake_report.get("slug") or "",
        "domain_theorem_bridge_proof_source_intake_report_path": intake_report.get("report_path") or "",
        "domain_theorem_bridge_proof_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_gap_count": (intake_report.get("summary") or {}).get("proof_source_gap_count", 0),
            "proof_source_production_item_count": len(items),
            "semantic_refinement_required_count": sum(1 for item in items if item.get("semantic_refinement_required")),
            "acceptance_criterion_count": len(acceptance_criteria),
            "critical_risk_count": len(critical_risks),
            "domain_theorem_bridge_proof_sources_required_count": 1 if sources_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "proof_source_production_items": items,
        "acceptance_criteria": acceptance_criteria,
        "critical_risks": critical_risks,
        "domain_theorem_bridge_proof_source_intake_report": intake_report,
        "boundary": [
            "This command plans proof-source production only; it does not author or verify the Wald/direct-Euler bridge proof.",
            "The current Lean statement draft remains an axiom until semantic refinement and a no-placeholder theorem replacement are produced.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Proof Source Production Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_proof_source_production_plan_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Proof sources required: {report.get('domain_theorem_bridge_proof_sources_required')}",
        f"- Semantic refinement required: {report.get('domain_theorem_bridge_semantic_refinement_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Proof Source Production Items", ""])
    for item in report.get("proof_source_production_items") or []:
        lines.append(
            f"- {item.get('work_item_id')}: {item.get('lean_declaration_name')} "
            f"semantic_refinement={item.get('semantic_refinement_required')} next={item.get('next_required_action')}"
        )
    lines.extend(["", "## Critical Risks", ""])
    for item in report.get("critical_risks") or []:
        lines.append(f"- {item.get('risk')}: {item.get('mitigation')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
