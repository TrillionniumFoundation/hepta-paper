"""Extract source-backed domain theorem bridge context for numeric law proof gaps."""

import datetime as dt
import hashlib
import pathlib
import re

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-source-extraction"
DISCOVERY_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-law-source-discovery-gate"
DISCOVERY_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

DISCOVERY_DOMAIN_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_DOMAIN_THEOREM_BRIDGE_REQUIRED"
DISCOVERY_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_READY"
DISCOVERY_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_MACHINE_CHECKED_CLOSED"

STATEMENT_DRAFT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SOURCE_EXTRACTION_STATEMENT_DRAFT_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SOURCE_EXTRACTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SOURCE_EXTRACTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SOURCE_EXTRACTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_source_extraction_ready",
    "domain_theorem_bridge_statement_draft_required",
    "domain_theorem_bridge_proof_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "trusted_import_law_source_discovery_gate_report_path",
    "trusted_import_law_source_discovery_gate_report_sha256",
    "source_root",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "domain_theorem_bridge_source_items",
    "candidate_domain_theorem_statements",
    "proof_obligations",
    "trusted_import_law_source_discovery_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "domain_bridge_gap_count",
    "source_file_scan_count",
    "source_context_candidate_count",
    "candidate_statement_count",
    "proof_obligation_count",
    "statement_draft_required_count",
    "proof_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes trusted-import law-source discovery and extracts manuscript source context for remaining domain theorem bridges.",
    "The output is source-backed candidate statement material, not a proof and not a Lean theorem.",
    "The Wald/direct-Euler bridge remains proof-required until a no-placeholder Lean theorem or trusted local proof source is supplied.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
SEARCH_TERMS = [
    "Wald inference",
    "direct Euler limit",
    "direct-score limit",
    "profile-equivalence theorem",
    "rho_{N,\\alpha}",
    "rho_{N,\\beta}",
    "sqrt{\\Delta t/n_2}",
    "n_2^{-1/2}",
    "high-frequency triangular array",
    "transferring the assumed direct-score limit",
]
SOURCE_SUFFIXES = {".tex", ".md"}


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _discovery_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_report_missing")
        return issues
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        "production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate",
        report,
        max_age_min=DISCOVERY_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)
    if report.get("command") != DISCOVERY_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_state") or ""
    if state not in {DISCOVERY_DOMAIN_REQUIRED_STATE, DISCOVERY_READY_STATE, DISCOVERY_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_state_not_consumable", state)
    if not report.get("domain_theorem_bridge_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_not_required_by_input")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_trusted_import_law_source_discovery_gate_boundary:{key}")
    return issues


def _domain_gap_items(report):
    return [
        item
        for item in report.get("trusted_import_law_source_classifications") or []
        if item.get("domain_theorem_bridge_required")
    ]


def _source_files(source_root):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    preferred = root / "submission" / "AoS" / "NSM_AoS" / "main.tex"
    if preferred.exists():
        return [preferred]
    files = []
    for path in root.rglob("*"):
        if path.is_file() and path.suffix in SOURCE_SUFFIXES and ".lake" not in path.parts:
            files.append(path)
    return files[:200]


def _line_context(lines, line_index, radius=4):
    start = max(line_index - radius, 0)
    end = min(line_index + radius + 1, len(lines))
    excerpt = "\n".join(line.rstrip() for line in lines[start:end])
    return start + 1, excerpt


def _scan_contexts(source_root):
    contexts = []
    files = _source_files(source_root)
    for path in files:
        text = path.read_text(errors="replace")
        lines = text.splitlines()
        for idx, line in enumerate(lines):
            matched_terms = [term for term in SEARCH_TERMS if term in line]
            if not matched_terms:
                continue
            line_no, excerpt = _line_context(lines, idx)
            contexts.append(
                {
                    "source_locator": f"{path}:{idx + 1}",
                    "context_start_line": line_no,
                    "matched_terms": matched_terms,
                    "excerpt": excerpt,
                    "excerpt_sha256": _sha256_text(excerpt),
                }
            )
    return files, contexts


def _candidate_statement(contexts):
    bound_context = next(
        (
            item
            for item in contexts
            if "Wald inference" in item.get("excerpt", "") and "direct Euler limit" in item.get("excerpt", "")
        ),
        None,
    )
    high_frequency_context = next(
        (
            item
            for item in contexts
            if "transferring the assumed direct-score limit" in item.get("excerpt", "")
            or "rho_{N,\\alpha}" in item.get("excerpt", "")
        ),
        None,
    )
    text = (
        "A Wald/direct-Euler bridge may be used only when the bound report supplies a theorem-level "
        "fixed-Delta-t moment bound bar_rho_N=o(n_2^{-1/2}) or high-frequency block bounds "
        "rho_{N,alpha}=o(sqrt(Delta t/n_2)) and rho_{N,beta}=o(n_2^{-1/2}); under the direct Euler "
        "CLT/input assumptions, profile equivalence then transfers the direct-score limit to the profiled estimator."
    )
    return {
        "candidate_statement_id": "domain-theorem-bridge-statement-0001",
        "candidate_statement_kind": "source_backed_domain_bridge_candidate",
        "candidate_statement_text": text,
        "candidate_statement_sha256": _sha256_text(text),
        "primary_source_locator": (bound_context or {}).get("source_locator") or "",
        "supporting_source_locator": (high_frequency_context or {}).get("source_locator") or "",
        "lean_namespace_hint": "NSMAoSFormalization",
        "lean_theorem_name_hint": "waldDirectEulerDomainBridge",
        "lean_statement_draft_required": True,
        "proof_ready": False,
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction(
    trusted_import_law_source_discovery_gate_report=None,
    source_root="",
    label="",
):
    discovery_report = trusted_import_law_source_discovery_gate_report or {}
    discovery_validation_issues = _discovery_issues(discovery_report)
    validation_issues = list(discovery_validation_issues)
    machine_checked = bool(
        discovery_report.get("production_claim_machine_checked")
        and discovery_report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_state") == DISCOVERY_CLOSED_STATE
    )
    domain_gap_items = [] if machine_checked else _domain_gap_items(discovery_report)
    files, contexts = _scan_contexts(source_root or ".")
    if domain_gap_items and not contexts:
        _issue(validation_issues, "domain_theorem_bridge_source_context_missing")
    candidate_statements = [] if machine_checked or not contexts else [_candidate_statement(contexts)]
    proof_obligations = []
    for item in domain_gap_items:
        proof_obligations.append(
            {
                "work_item_id": item.get("work_item_id") or "",
                "dispatch_id": item.get("dispatch_id") or "",
                "lean_field_name": item.get("lean_field_name") or "",
                "required_law": item.get("required_law") or "",
                "required_source_kind": "source_backed_domain_theorem_bridge",
                "trusted_import_candidates_available": bool(discovery_report.get("trusted_import_candidates_ready")),
                "statement_draft_required": True,
                "no_placeholder_proof_required": True,
                "assumption_echo_allowed": False,
                "next_required_action": "draft_source_backed_domain_bridge_statement",
            }
        )
    source_items = [
        {
            "work_item_id": item.get("work_item_id") or "",
            "domain_theorem_bridge_required": True,
            "source_context_candidates": contexts[:8],
            "candidate_statement_ids": [statement.get("candidate_statement_id") for statement in candidate_statements],
        }
        for item in domain_gap_items
    ]
    if domain_gap_items and not candidate_statements and not machine_checked:
        _issue(validation_issues, "domain_theorem_bridge_candidate_statement_missing")

    checks = [
        _check("trusted_import_law_source_discovery_gate_consumable", not _discovery_issues(discovery_report), "production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_not_consumable"),
        _check("domain_bridge_gap_present_or_closed", machine_checked or bool(domain_gap_items), "domain_bridge_gap_missing"),
        _check("source_context_candidates_present", machine_checked or bool(contexts), "domain_theorem_bridge_source_context_missing", severity="readiness"),
        _check("candidate_statement_present_or_closed", machine_checked or bool(candidate_statements), "domain_theorem_bridge_candidate_statement_missing", severity="readiness"),
        _check("no_source_mutation", not discovery_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not discovery_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif discovery_validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = STATEMENT_DRAFT_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_statement_draft"
        next_agent_command = ""

    statement_required = bool(status == "PASS" and state == STATEMENT_DRAFT_REQUIRED_STATE)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_source_extraction_ready": status == "PASS",
        "domain_theorem_bridge_statement_draft_required": statement_required,
        "domain_theorem_bridge_proof_required": statement_required,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": discovery_report.get("claim_packet_id") or "",
        "slug": discovery_report.get("slug") or "",
        "trusted_import_law_source_discovery_gate_report_path": discovery_report.get("report_path") or "",
        "trusted_import_law_source_discovery_gate_report_sha256": discovery_report.get("report_sha256") or "",
        "source_root": str(source_root or "."),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "domain_bridge_gap_count": len(domain_gap_items),
            "source_file_scan_count": len(files),
            "source_context_candidate_count": len(contexts),
            "candidate_statement_count": len(candidate_statements),
            "proof_obligation_count": len(proof_obligations),
            "statement_draft_required_count": 1 if statement_required else 0,
            "proof_required_count": 1 if statement_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "domain_theorem_bridge_source_items": source_items,
        "candidate_domain_theorem_statements": candidate_statements,
        "proof_obligations": proof_obligations,
        "trusted_import_law_source_discovery_gate_report": discovery_report,
        "boundary": [
            "This command extracts source-backed domain theorem bridge context only; it does not prove the bridge.",
            "The candidate statement must still be translated to Lean and backed by a no-placeholder proof or trusted local theorem.",
            "It does not execute Lean, mutate source/manuscript/package/archive state, fetch dependencies, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Source Extraction",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Statement draft required: {report.get('domain_theorem_bridge_statement_draft_required')}",
        f"- Proof required: {report.get('domain_theorem_bridge_proof_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Candidate Statements", ""])
    for item in report.get("candidate_domain_theorem_statements") or []:
        lines.append(f"- {item.get('candidate_statement_id')}: {item.get('candidate_statement_text')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
