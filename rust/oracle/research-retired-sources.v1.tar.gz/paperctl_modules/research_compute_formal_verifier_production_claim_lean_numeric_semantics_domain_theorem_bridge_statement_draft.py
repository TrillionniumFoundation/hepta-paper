"""Draft and syntax-check a Lean statement for the Wald/direct-Euler domain bridge."""

import datetime as dt
import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-statement-draft"
SOURCE_EXTRACTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-source-extraction"
SOURCE_EXTRACTION_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

SOURCE_EXTRACTION_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SOURCE_EXTRACTION_STATEMENT_DRAFT_REQUIRED"
SOURCE_EXTRACTION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SOURCE_EXTRACTION_MACHINE_CHECKED_CLOSED"

PROOF_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_STATEMENT_DRAFT_PROOF_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_STATEMENT_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_STATEMENT_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_STATEMENT_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_statement_draft_ready",
    "domain_theorem_bridge_proof_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_source_extraction_report_path",
    "domain_theorem_bridge_source_extraction_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "lean_domain_theorem_bridge_statements",
    "proof_obligations",
    "domain_theorem_bridge_source_extraction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "candidate_statement_count",
    "proof_obligation_count",
    "lean_declaration_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "domain_theorem_bridge_proof_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes source-backed Wald/direct-Euler domain bridge extraction and writes a Lean statement draft.",
    "The Lean draft uses an axiom placeholder, so it is syntax-checked but not a machine-checked proof.",
    "This command writes local draft artifacts only and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
DECLARATION_RE = re.compile(r"^\s*(theorem|lemma|axiom)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _source_extraction_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_source_extraction_report_missing")
        return issues
    ref_issues, _health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_source_extraction",
        report,
        max_age_min=SOURCE_EXTRACTION_MAX_AGE_MIN,
    )
    issues.extend(ref_issues)
    if report.get("command") != SOURCE_EXTRACTION_COMMAND:
        _issue(issues, "domain_theorem_bridge_source_extraction_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_source_extraction_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction_state") or ""
    if state not in {SOURCE_EXTRACTION_REQUIRED_STATE, SOURCE_EXTRACTION_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_source_extraction_state_not_consumable", state)
    if not report.get("candidate_domain_theorem_statements") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_candidate_statement_missing")
    if not report.get("proof_obligations") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_proof_obligation_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_source_extraction_boundary:{key}")
    return issues


def _lean_identifier(value, fallback):
    raw = str(value or "").strip()
    ident = re.sub(r"[^A-Za-z0-9_']", "_", raw)
    ident = re.sub(r"_+", "_", ident).strip("_")
    if not ident or not ident[0].isalpha():
        ident = fallback
    if ident in {"axiom", "theorem", "lemma", "def", "structure", "namespace", "end"}:
        ident = fallback
    return ident[:160]


def _comment_text(value):
    return str(value or "").replace("-/", "- /")


def _lean_source(report):
    candidate = (report.get("candidate_domain_theorem_statements") or [{}])[0]
    theorem_name = _lean_identifier(candidate.get("lean_theorem_name_hint") or "waldDirectEulerDomainBridge", "waldDirectEulerDomainBridge")
    namespace = _lean_identifier(candidate.get("lean_namespace_hint") or "NSMAoSFormalization", "NSMAoSFormalization")
    lines = [
        "import Mathlib",
        "",
        "open Filter Asymptotics",
        "",
        "/-",
        "paper_factory source-backed Wald/direct-Euler domain bridge Lean statement draft.",
        "This file syntax-checks the theorem interface only.",
        "The declaration below is a proof-required placeholder, not a proof certificate.",
        f"Candidate statement id: {candidate.get('candidate_statement_id') or ''}",
        f"Primary source locator: {candidate.get('primary_source_locator') or ''}",
        f"Supporting source locator: {candidate.get('supporting_source_locator') or ''}",
        "Candidate statement:",
        _comment_text(candidate.get("candidate_statement_text") or ""),
        "-/",
        "",
        f"namespace {namespace}",
        "",
        "noncomputable section",
        "",
        "def RateSeq := Nat -> Real",
        "",
        "def LittleOAtTop (f g : RateSeq) : Prop :=",
        "  Asymptotics.IsLittleO atTop f g",
        "",
        "structure WaldDirectEulerBridgeInputs where",
        "  barRhoN : RateSeq",
        "  rhoAlpha : RateSeq",
        "  rhoBeta : RateSeq",
        "  fixedDeltaScale : RateSeq",
        "  highFrequencyDriftScale : RateSeq",
        "  highFrequencyDiffusionScale : RateSeq",
        "  directEulerLimit : Prop",
        "  profileEquivalence : Prop",
        "  waldDirectEulerValid : Prop",
        "",
        f"axiom {theorem_name} (I : WaldDirectEulerBridgeInputs) :",
        "  (LittleOAtTop I.barRhoN I.fixedDeltaScale ∨",
        "    (LittleOAtTop I.rhoAlpha I.highFrequencyDriftScale ∧",
        "      LittleOAtTop I.rhoBeta I.highFrequencyDiffusionScale)) ->",
        "  I.directEulerLimit ->",
        "  I.profileEquivalence ->",
        "  I.waldDirectEulerValid",
        "",
        "end",
        "",
        f"end {namespace}",
        "",
    ]
    return "\n".join(lines)


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft(
    domain_theorem_bridge_source_extraction_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    source_report = domain_theorem_bridge_source_extraction_report or {}
    validation_issues = _source_extraction_issues(source_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    source_root_path = pathlib.Path(source_root or ".").resolve()
    machine_checked = bool(
        source_report.get("production_claim_machine_checked")
        and source_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_source_extraction_state") == SOURCE_EXTRACTION_CLOSED_STATE
    )
    lean_source_text = _lean_source(source_report)
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-domain-theorem-bridge-statement-draft.lean", lean_source_text)
    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_info["path"])
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command:
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    declarations = DECLARATION_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    checks = [
        _check("domain_theorem_bridge_source_extraction_report_consumable", not _source_extraction_issues(source_report), "domain_theorem_bridge_source_extraction_not_consumable"),
        _check("candidate_statement_present_or_closed", machine_checked or bool(source_report.get("candidate_domain_theorem_statements")), "domain_theorem_bridge_candidate_statement_missing"),
        _check("proof_obligation_present_or_closed", machine_checked or bool(source_report.get("proof_obligations")), "domain_theorem_bridge_proof_obligation_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("lean_declaration_present", bool(declarations), "lean_domain_theorem_bridge_declaration_missing"),
        _check("placeholder_tokens_present_for_proof_boundary", bool(placeholders) or machine_checked, "placeholder_tokens_missing_for_statement_draft", severity="readiness"),
        _check("no_source_mutation", not source_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not source_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif lean_exit_zero and declarations and placeholders:
        status = "PASS"
        state = PROOF_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_proof_source_gate"
        next_agent_command = ""
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    proof_required = bool(status == "PASS" and state == PROOF_REQUIRED_STATE)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_statement_draft_ready": bool(status == "PASS" and state == PROOF_REQUIRED_STATE),
        "domain_theorem_bridge_proof_required": proof_required,
        "lean_theorem_draft_ready": bool(status == "PASS" and state in {PROOF_REQUIRED_STATE, CLOSED_STATE}),
        "production_claim_machine_checked": machine_checked and state == CLOSED_STATE,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": source_report.get("claim_packet_id") or "",
        "slug": source_report.get("slug") or "",
        "domain_theorem_bridge_source_extraction_report_path": source_report.get("report_path") or "",
        "domain_theorem_bridge_source_extraction_report_sha256": source_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "candidate_statement_count": len(source_report.get("candidate_domain_theorem_statements") or []),
            "proof_obligation_count": len(source_report.get("proof_obligations") or []),
            "lean_declaration_count": len(declarations),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "domain_theorem_bridge_proof_required_count": 1 if proof_required else 0,
            "lean_theorem_draft_ready_count": 1 if status == "PASS" and state in {PROOF_REQUIRED_STATE, CLOSED_STATE} else 0,
            "production_claim_machine_checked_count": 1 if machine_checked and state == CLOSED_STATE else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": lake_env_used,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "declaration_names": [item[1] for item in declarations],
            "placeholder_token_count": len(placeholders),
        },
        "lean_domain_theorem_bridge_statements": [
            {
                "lean_declaration_name": item[1],
                "declaration_kind": item[0],
                "proof_available": False,
                "placeholder_proof_required": True,
                "machine_checked": False,
            }
            for item in declarations
        ],
        "proof_obligations": list(source_report.get("proof_obligations") or []),
        "domain_theorem_bridge_source_extraction_report": source_report,
        "boundary": [
            "This command syntax-checks a Lean statement draft only; the axiom placeholder is not a proof.",
            "A Lean exit code of zero for this file confirms syntax/import readiness, not the Wald/direct-Euler theorem.",
            "The next stage must replace the axiom with a no-placeholder proof or trusted local theorem source.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Statement Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_statement_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Lake env used: {report.get('lake_env_used')}",
        f"- Domain theorem bridge proof required: {report.get('domain_theorem_bridge_proof_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Lean Statements", ""])
    for item in report.get("lean_domain_theorem_bridge_statements") or []:
        lines.append(
            f"- {item.get('lean_declaration_name')}: proof_available={item.get('proof_available')} "
            f"placeholder_required={item.get('placeholder_proof_required')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
