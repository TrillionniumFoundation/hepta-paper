"""Gate proof-source readiness for the Wald/direct-Euler transfer field."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-proof-source-gate"
SEMANTIC_REFINEMENT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-semantic-refinement-draft"

SEMANTIC_REFINEMENT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SEMANTIC_REFINEMENT_DRAFT_FIELD_PROOF_SOURCE_REQUIRED"
SEMANTIC_REFINEMENT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_SEMANTIC_REFINEMENT_DRAFT_MACHINE_CHECKED_CLOSED"

PROOF_SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_GATE_PROOF_SOURCE_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate_ready",
    "profile_equivalence_transfer_proof_source_required",
    "transfer_field_as_production_proof_rejected",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_semantic_refinement_draft_report_path",
    "domain_theorem_bridge_semantic_refinement_draft_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "proof_source_classifications",
    "proof_source_gaps",
    "domain_theorem_bridge_semantic_refinement_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "semantic_refinement_obligation_count",
    "transfer_field_proof_source_available_count",
    "proof_source_gap_count",
    "transfer_field_as_production_proof_rejected_count",
    "profile_equivalence_transfer_proof_source_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the Wald/direct-Euler semantic refinement draft and refuses to count a transfer field as production proof.",
    "Only a no-placeholder source-backed proof source for profileEquivalenceTransfer can unlock the next proof step.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _semantic_refinement_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_semantic_refinement_draft_report_missing")
        return issues
    if report.get("command") != SEMANTIC_REFINEMENT_COMMAND:
        _issue(issues, "domain_theorem_bridge_semantic_refinement_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_semantic_refinement_draft_not_pass", report.get("status") or "")
    if not report.get("domain_theorem_bridge_semantic_refinement_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_semantic_refinement_draft_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_semantic_refinement_draft_state") or ""
    if state not in {SEMANTIC_REFINEMENT_REQUIRED_STATE, SEMANTIC_REFINEMENT_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_semantic_refinement_draft_state_not_consumable", state)
    if report.get("field_as_production_proof_allowed") and not report.get("production_claim_machine_checked"):
        _issue(issues, "transfer_field_incorrectly_allowed_as_production_proof")
    if not report.get("semantic_refinement_obligations") and not report.get("production_claim_machine_checked"):
        _issue(issues, "semantic_refinement_obligations_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_semantic_refinement_boundary:{key}")
    return issues


def _classify_obligations(report):
    classifications = []
    gaps = []
    for obligation in report.get("semantic_refinement_obligations") or []:
        proof_required = bool(obligation.get("proof_source_required"))
        available = bool(obligation.get("proof_source_available"))
        item = {
            "obligation_id": obligation.get("obligation_id") or "",
            "lean_field_name": obligation.get("lean_field_name") or "",
            "required_source_kind": obligation.get("required_source_kind") or "source_backed_profile_equivalence_transfer_theorem",
            "proof_source_required": proof_required,
            "proof_source_available": available,
            "field_as_production_proof_allowed": bool(obligation.get("field_as_production_proof_allowed")),
            "next_required_action": "wire_no_placeholder_transfer_field_proof_source" if available else "produce_no_placeholder_transfer_field_proof_source",
        }
        classifications.append(item)
        if proof_required and not available:
            gaps.append(item)
    return classifications, gaps


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate(
    domain_theorem_bridge_semantic_refinement_draft_report=None,
    label="",
):
    semantic_report = domain_theorem_bridge_semantic_refinement_draft_report or {}
    validation_issues = _semantic_refinement_issues(semantic_report)
    machine_checked = bool(
        semantic_report.get("production_claim_machine_checked")
        and semantic_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_semantic_refinement_draft_state") == SEMANTIC_REFINEMENT_CLOSED_STATE
    )
    classifications, gaps = ([], []) if machine_checked else _classify_obligations(semantic_report)
    if classifications and any(item.get("field_as_production_proof_allowed") for item in classifications):
        _issue(validation_issues, "transfer_field_classification_allows_field_as_proof")
    if classifications and gaps:
        _issue(validation_issues, "profile_equivalence_transfer_proof_source_required", f"{len(gaps)} gap(s)")

    checks = [
        _check("domain_theorem_bridge_semantic_refinement_draft_report_consumable", not _semantic_refinement_issues(semantic_report), "domain_theorem_bridge_semantic_refinement_draft_not_consumable"),
        _check("semantic_refinement_obligations_present_or_closed", machine_checked or bool(classifications), "semantic_refinement_obligations_missing"),
        _check("transfer_field_not_counted_as_production_proof", not semantic_report.get("field_as_production_proof_allowed"), "transfer_field_incorrectly_allowed_as_production_proof"),
        _check("profile_equivalence_transfer_source_present_or_gap_recorded", machine_checked or bool(gaps), "profile_equivalence_transfer_gap_missing", severity="readiness"),
        _check("no_source_mutation", not semantic_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not semantic_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_semantic_refinement_draft_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = PROOF_SOURCE_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_proof_source_intake"
        next_agent_command = ""

    source_required = bool(status == "PASS" and state == PROOF_SOURCE_REQUIRED_STATE and gaps)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate_ready": status == "PASS",
        "profile_equivalence_transfer_proof_source_required": source_required,
        "transfer_field_as_production_proof_rejected": status == "PASS" and not machine_checked,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": semantic_report.get("claim_packet_id") or "",
        "slug": semantic_report.get("slug") or "",
        "domain_theorem_bridge_semantic_refinement_draft_report_path": semantic_report.get("report_path") or "",
        "domain_theorem_bridge_semantic_refinement_draft_report_sha256": semantic_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "semantic_refinement_obligation_count": len(classifications),
            "transfer_field_proof_source_available_count": sum(1 for item in classifications if item.get("proof_source_available")),
            "proof_source_gap_count": len(gaps),
            "transfer_field_as_production_proof_rejected_count": 1 if status == "PASS" and not machine_checked else 0,
            "profile_equivalence_transfer_proof_source_required_count": 1 if source_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "proof_source_classifications": classifications,
        "proof_source_gaps": gaps,
        "domain_theorem_bridge_semantic_refinement_draft_report": semantic_report,
        "boundary": [
            "This command refuses to treat the profileEquivalenceTransfer field as standalone production proof.",
            "The Wald/direct-Euler bridge remains open until a no-placeholder, source-backed transfer proof source is available.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Proof Source Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Transfer proof source required: {report.get('profile_equivalence_transfer_proof_source_required')}",
        f"- Field as production proof rejected: {report.get('transfer_field_as_production_proof_rejected')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Proof Source Gaps", ""])
    for item in report.get("proof_source_gaps") or []:
        lines.append(
            f"- {item.get('obligation_id')}: field={item.get('lean_field_name')} "
            f"next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
