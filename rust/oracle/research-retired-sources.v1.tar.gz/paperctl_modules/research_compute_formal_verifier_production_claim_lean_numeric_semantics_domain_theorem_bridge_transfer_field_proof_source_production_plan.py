"""Plan production of a no-placeholder proof source for profileEquivalenceTransfer."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-proof-source-production-plan"
SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-proof-source-intake"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
SOURCE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_INTAKE_READY"
SOURCE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_PRODUCTION_PLAN_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_PRODUCTION_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_PRODUCTION_PLAN_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_ready",
    "profile_equivalence_transfer_proof_sources_required",
    "source_theorem_provenance_required",
    "assumption_echo_allowed",
    "placeholder_allowed",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_transfer_field_proof_source_intake_report_path",
    "domain_theorem_bridge_transfer_field_proof_source_intake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "proof_source_production_items",
    "acceptance_criteria",
    "critical_risks",
    "domain_theorem_bridge_transfer_field_proof_source_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_gap_count",
    "proof_source_production_item_count",
    "source_theorem_provenance_required_count",
    "acceptance_criterion_count",
    "critical_risk_count",
    "profile_equivalence_transfer_proof_sources_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes transfer-field proof-source intake gaps and plans source-backed proof-source production.",
    "The plan keeps profile-equivalence transfer separate from generated semantic-refinement drafts.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _source_intake_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_intake_report_missing")
        return issues
    if report.get("command") != SOURCE_INTAKE_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_intake_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_intake_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_intake_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_intake_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_intake_state") or ""
    if state not in {SOURCE_REQUIRED_STATE, SOURCE_READY_STATE, SOURCE_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_intake_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_proof_source_intake_boundary:{key}")
    return issues


def _source_locators(report):
    locators = []
    for context in report.get("candidate_manuscript_source_contexts") or []:
        locator = context.get("source_locator") or ""
        if locator and locator not in locators:
            locators.append(locator)
    return locators[:12]


def _ready_source_candidates(report):
    candidates = []
    for classification in report.get("proof_source_intake_classifications") or []:
        for candidate in classification.get("source_candidates") or []:
            if candidate.get("proof_source_ready"):
                candidates.append(candidate)
    return candidates


def _ready_source_locators(report):
    locators = []
    for candidate in _ready_source_candidates(report):
        path = candidate.get("path") or ""
        digest = candidate.get("text_sha256") or ""
        locator = f"{path} sha256={digest}" if digest else path
        if locator and locator not in locators:
            locators.append(locator)
    return locators


def _ready_source_theorem_names(report):
    names = []
    for candidate in _ready_source_candidates(report):
        for name in candidate.get("theorem_or_lemma_names") or []:
            if name and name not in names:
                names.append(name)
    return names


def _plan_items(report):
    if not report.get("profile_equivalence_transfer_proof_sources_required"):
        if not report.get("profile_equivalence_transfer_proof_source_ready"):
            return []
        locators = _source_locators(report) + _ready_source_locators(report)
        theorem_names = _ready_source_theorem_names(report)
        lean_declaration_name = theorem_names[0] if theorem_names else "profileEquivalenceTransfersDirectScoreLimit"
        return [
            {
                "work_item_id": "transfer-field-existing-proof-source-verification",
                "route": "integration",
                "lean_declaration_name": lean_declaration_name,
                "required_source_kind": "existing_no_placeholder_transfer_theorem",
                "source_locators": locators,
                "source_theorem_provenance_required": True,
                "acceptance_criteria": [
                    "consumes the ready local Lean proof source found by proof-source intake",
                    "verifies the theorem name is wired into the source-backed transfer target",
                    "keeps production_claim_machine_checked=false until the full bridge replacement passes",
                ],
                "next_required_action": "wire_existing_no_placeholder_transfer_theorem",
            }
        ]
    locators = _source_locators(report)
    return [
        {
            "work_item_id": "transfer-field-profile-equivalence-semantics",
            "route": "formalization",
            "lean_declaration_name": "ProfileEquivalenceTransferSemantics",
            "required_source_kind": "source_backed_profile_equivalence_transfer_statement",
            "source_locators": locators,
            "source_theorem_provenance_required": True,
            "acceptance_criteria": [
                "states profile-equivalence as an implication, not as a bare Prop",
                "ties the implication to source locators for the direct-score/profile equivalence argument",
                "does not cite generated logs as theorem provenance",
            ],
            "next_required_action": "draft_profile_equivalence_transfer_semantics_from_source",
        },
        {
            "work_item_id": "transfer-field-direct-score-transfer-lemma",
            "route": "formalization",
            "lean_declaration_name": "profileEquivalenceTransfersDirectScoreLimit",
            "required_source_kind": "no_placeholder_transfer_theorem",
            "source_locators": locators,
            "source_theorem_provenance_required": True,
            "acceptance_criteria": [
                "proves transfer from direct Euler/direct-score limit and rate premises to profiled estimator validity",
                "uses explicit premises rather than exact h/by assumption on the target",
                "contains no sorry/admit/axiom/opaque placeholder tokens",
            ],
            "next_required_action": "produce_no_placeholder_transfer_theorem",
        },
        {
            "work_item_id": "transfer-field-bridge-rewire",
            "route": "integration",
            "lean_declaration_name": "waldDirectEulerDomainBridge",
            "required_source_kind": "bridge_rewire_to_transfer_theorem",
            "source_locators": locators,
            "source_theorem_provenance_required": True,
            "acceptance_criteria": [
                "rewires WaldDirectEulerBridgeSemantics.profileEquivalenceTransfer to the produced theorem",
                "reruns Lean execution and no-placeholder gates over the bridge",
                "keeps production_claim_machine_checked=false until the full theorem replacement passes",
            ],
            "next_required_action": "rerun_domain_bridge_no_placeholder_execution_after_transfer_source",
        },
    ]


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan(
    domain_theorem_bridge_transfer_field_proof_source_intake_report=None,
    label="",
):
    intake_report = domain_theorem_bridge_transfer_field_proof_source_intake_report or {}
    validation_issues = _source_intake_issues(intake_report)
    machine_checked = bool(
        intake_report.get("production_claim_machine_checked")
        and intake_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_intake_state") == SOURCE_CLOSED_STATE
    )
    items = [] if machine_checked else _plan_items(intake_report)
    if intake_report.get("profile_equivalence_transfer_proof_sources_required") and not items and not machine_checked:
        _issue(validation_issues, "profile_equivalence_transfer_proof_sources_required_but_no_production_items")

    acceptance_criteria = [
        "No proof source may use sorry, admit, axiom, opaque, or a theorem that simply restates the target as a hypothesis.",
        "Generated report artifacts under logs/paperctl/_batches are not accepted as proof-source provenance.",
        "profileEquivalenceTransfer must be discharged by a source-backed theorem or trusted local theorem source.",
        "The bridge must be rerun through Lean/no-placeholder gates after the transfer theorem is wired.",
        "Production claim machine_checked remains false until Lean verifies the full no-placeholder bridge replacement.",
    ]
    critical_risks = [
        {
            "risk": "generated_draft_misclassified_as_proof",
            "mitigation": "keep logs/report artifacts excluded from transfer proof-source intake",
        },
        {
            "risk": "assumption_echo_transfer",
            "mitigation": "reject exact h/by assumption proofs that take profileEquivalenceTransfer or target validity as a premise",
        },
        {
            "risk": "source_overclaim",
            "mitigation": "require source locators or trusted local theorem provenance for direct-score/profile-equivalence transfer",
        },
    ]
    checks = [
        _check("domain_theorem_bridge_transfer_field_proof_source_intake_report_consumable", not _source_intake_issues(intake_report), "domain_theorem_bridge_transfer_field_proof_source_intake_not_consumable"),
        _check("proof_source_production_items_present_or_closed", machine_checked or bool(items), "proof_source_production_items_missing"),
        _check("source_theorem_provenance_required_recorded", machine_checked or any(item.get("source_theorem_provenance_required") for item in items), "source_theorem_provenance_required_missing"),
        _check("assumption_echo_disallowed", True, ""),
        _check("placeholder_disallowed", True, ""),
        _check("no_source_mutation", not intake_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not intake_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = PLAN_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_semantic_statement_draft"
        next_agent_command = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-semantic-statement-draft"

    sources_required = bool(status == "PASS" and items)
    provenance_required = bool(status == "PASS" and any(item.get("source_theorem_provenance_required") for item in items))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_ready": status == "PASS",
        "profile_equivalence_transfer_proof_sources_required": sources_required,
        "source_theorem_provenance_required": provenance_required,
        "assumption_echo_allowed": False,
        "placeholder_allowed": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": intake_report.get("claim_packet_id") or "",
        "slug": intake_report.get("slug") or "",
        "domain_theorem_bridge_transfer_field_proof_source_intake_report_path": intake_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_proof_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_gap_count": (intake_report.get("summary") or {}).get("proof_source_gap_count", 0),
            "proof_source_production_item_count": len(items),
            "source_theorem_provenance_required_count": sum(1 for item in items if item.get("source_theorem_provenance_required")),
            "acceptance_criterion_count": len(acceptance_criteria),
            "critical_risk_count": len(critical_risks),
            "profile_equivalence_transfer_proof_sources_required_count": 1 if sources_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "proof_source_production_items": items,
        "acceptance_criteria": acceptance_criteria,
        "critical_risks": critical_risks,
        "domain_theorem_bridge_transfer_field_proof_source_intake_report": intake_report,
        "boundary": [
            "This command plans transfer-field proof-source production only; it does not author or verify the theorem.",
            "Generated semantic-refinement drafts are not proof sources for profileEquivalenceTransfer.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Proof Source Production Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Transfer proof sources required: {report.get('profile_equivalence_transfer_proof_sources_required')}",
        f"- Source theorem provenance required: {report.get('source_theorem_provenance_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Proof Source Production Items", ""])
    for item in report.get("proof_source_production_items") or []:
        lines.append(
            f"- {item.get('work_item_id')}: {item.get('lean_declaration_name')} "
            f"provenance_required={item.get('source_theorem_provenance_required')} next={item.get('next_required_action')}"
        )
    lines.extend(["", "## Critical Risks", ""])
    for item in report.get("critical_risks") or []:
        lines.append(f"- {item.get('risk')}: {item.get('mitigation')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
