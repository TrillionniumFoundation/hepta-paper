"""Draft Lean semantics for the Wald/direct-Euler transfer field."""

import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-semantic-statement-draft"
PRODUCTION_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-proof-source-production-plan"
NO_PLACEHOLDER_PROOF_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-no-placeholder-proof-attempt"
PRODUCTION_PLAN_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

PRODUCTION_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_PRODUCTION_PLAN_READY"
PRODUCTION_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_PROOF_SOURCE_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"

FIELD_PROOF_SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SEMANTIC_STATEMENT_DRAFT_FIELD_PROOF_SOURCE_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SEMANTIC_STATEMENT_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SEMANTIC_STATEMENT_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SEMANTIC_STATEMENT_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft_ready",
    "profile_equivalence_transfer_proof_source_required",
    "field_as_production_proof_allowed",
    "source_theorem_provenance_required",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_transfer_field_proof_source_production_plan_report_path",
    "domain_theorem_bridge_transfer_field_proof_source_production_plan_report_sha256",
    "domain_theorem_bridge_transfer_field_proof_source_production_plan_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "transfer_field_semantic_statements",
    "transfer_field_proof_obligations",
    "source_locators",
    "domain_theorem_bridge_transfer_field_proof_source_production_plan_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_production_plan_ref_validation_issue_count",
    "proof_source_production_item_count",
    "source_locator_count",
    "lean_structure_count",
    "lean_theorem_count",
    "semantic_transfer_field_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_proof_source_required_count",
    "source_theorem_provenance_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the transfer-field proof-source production plan and drafts an implication-bearing Lean semantic statement.",
    "The generated theorem is only relative to a sourceBackedProfileEquivalenceTransfer field; that field remains the proof-source obligation.",
    "This command writes local draft artifacts, syntax-checks Lean, and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _production_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_production_plan_report_missing")
        return issues
    if report.get("command") != PRODUCTION_PLAN_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_production_plan_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_production_plan_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_production_plan_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_state") or ""
    if state not in {PRODUCTION_PLAN_READY_STATE, PRODUCTION_PLAN_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_production_plan_state_not_consumable", state)
    if not report.get("proof_source_production_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_transfer_field_proof_source_production_items_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_proof_source_production_plan_boundary:{key}")
    return issues


def _source_locators(report):
    locators = []
    for item in report.get("proof_source_production_items") or []:
        for locator in item.get("source_locators") or []:
            locator = str(locator or "").strip()
            if locator and locator not in locators:
                locators.append(locator)
    return locators[:16]


def _source_theorem_provenance_required(report):
    return any(item.get("source_theorem_provenance_required") for item in report.get("proof_source_production_items") or [])


def _comment_text(value):
    return str(value or "").replace("-/", "- /")


def _lean_source(report):
    locators = _source_locators(report)
    locator_lines = "\n".join(f"Source locator: {_comment_text(locator)}" for locator in locators)
    if not locator_lines:
        locator_lines = "Source locator: unavailable"
    return f"""import Mathlib

open Filter Asymptotics

/-
paper_factory profile-equivalence transfer semantic statement draft.
This file checks the Lean interface for the transfer field only.
It does not certify the paper theorem or the transfer proof source.
{locator_lines}
-/

namespace NSMAoSFormalization

noncomputable section

def RateSeq := Nat -> Real

def LittleOAtTop (f g : RateSeq) : Prop :=
  Asymptotics.IsLittleO atTop f g

structure ProfileEquivalenceTransferSemantics where
  barRhoN : RateSeq
  rhoAlpha : RateSeq
  rhoBeta : RateSeq
  fixedDeltaScale : RateSeq
  highFrequencyDriftScale : RateSeq
  highFrequencyDiffusionScale : RateSeq
  directEulerLimit : Prop
  profiledEstimatorWaldValid : Prop
  sourceBackedProfileEquivalenceTransfer :
    (Or (LittleOAtTop barRhoN fixedDeltaScale)
      (And (LittleOAtTop rhoAlpha highFrequencyDriftScale)
        (LittleOAtTop rhoBeta highFrequencyDiffusionScale))) ->
    directEulerLimit ->
    profiledEstimatorWaldValid

theorem profileEquivalenceTransferSemanticImplicationDraft
    (S : ProfileEquivalenceTransferSemantics)
    (hRate : Or (LittleOAtTop S.barRhoN S.fixedDeltaScale)
      (And (LittleOAtTop S.rhoAlpha S.highFrequencyDriftScale)
        (LittleOAtTop S.rhoBeta S.highFrequencyDiffusionScale)))
    (hEuler : S.directEulerLimit) :
    S.profiledEstimatorWaldValid :=
  S.sourceBackedProfileEquivalenceTransfer hRate hEuler

end

end NSMAoSFormalization
"""


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft(
    domain_theorem_bridge_transfer_field_proof_source_production_plan_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    plan_report = domain_theorem_bridge_transfer_field_proof_source_production_plan_report or {}
    plan_ref_issues, plan_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_proof_source_production_plan",
        plan_report,
        expected_command=PRODUCTION_PLAN_COMMAND,
        max_age_min=PRODUCTION_PLAN_MAX_AGE_MIN,
    )
    validation_issues = plan_ref_issues + _production_plan_issues(plan_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    source_root_path = pathlib.Path(source_root or ".").resolve()
    machine_checked = bool(
        plan_report.get("production_claim_machine_checked")
        and plan_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_proof_source_production_plan_state") == PRODUCTION_PLAN_CLOSED_STATE
    )
    source_locators = _source_locators(plan_report)
    source_theorem_provenance_required = _source_theorem_provenance_required(plan_report)
    lean_source_text = _lean_source(plan_report)
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-semantic-statement-draft.lean", lean_source_text)
    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_info["path"])
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command:
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    theorem_names = THEOREM_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    semantic_field_count = lean_source_text.count("sourceBackedProfileEquivalenceTransfer")
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    checks = [
        _check("domain_theorem_bridge_transfer_field_proof_source_production_plan_report_consumable", not _production_plan_issues(plan_report), "domain_theorem_bridge_transfer_field_proof_source_production_plan_not_consumable"),
        _check("domain_theorem_bridge_transfer_field_proof_source_production_plan_ref_fresh", not plan_ref_issues, "domain_theorem_bridge_transfer_field_proof_source_production_plan_ref_not_fresh"),
        _check("source_locators_present_or_closed", machine_checked or bool(source_locators), "source_locators_missing", severity="readiness"),
        _check("source_theorem_provenance_required_recorded", machine_checked or source_theorem_provenance_required, "source_theorem_provenance_required_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("semantic_structure_present", "ProfileEquivalenceTransferSemantics" in structures, "profile_equivalence_transfer_semantics_missing"),
        _check("semantic_implication_theorem_present", "profileEquivalenceTransferSemanticImplicationDraft" in theorem_names, "profile_equivalence_transfer_semantic_implication_missing"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("field_as_production_proof_rejected", True, ""),
        _check("no_source_mutation", not plan_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not plan_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_proof_source_production_plan_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif lean_exit_zero and "ProfileEquivalenceTransferSemantics" in structures and "profileEquivalenceTransferSemanticImplicationDraft" in theorem_names and not placeholders:
        status = "PASS"
        state = FIELD_PROOF_SOURCE_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_no_placeholder_proof_source"
        next_agent_command = NO_PLACEHOLDER_PROOF_ATTEMPT_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    field_proof_required = bool(status == "PASS" and state == FIELD_PROOF_SOURCE_REQUIRED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft_ready": bool(status == "PASS" and state == FIELD_PROOF_SOURCE_REQUIRED_STATE),
        "profile_equivalence_transfer_proof_source_required": field_proof_required,
        "field_as_production_proof_allowed": False,
        "source_theorem_provenance_required": bool(source_theorem_provenance_required and not machine_checked),
        "production_claim_machine_checked": machine_checked and state == CLOSED_STATE,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": plan_report.get("claim_packet_id") or "",
        "slug": plan_report.get("slug") or "",
        "domain_theorem_bridge_transfer_field_proof_source_production_plan_report_path": plan_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_proof_source_production_plan_report_sha256": plan_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_proof_source_production_plan_ref_health": plan_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_production_plan_ref_validation_issue_count": len(plan_ref_issues),
            "proof_source_production_item_count": len(plan_report.get("proof_source_production_items") or []),
            "source_locator_count": len(source_locators),
            "lean_structure_count": len(structures),
            "lean_theorem_count": len(theorem_names),
            "semantic_transfer_field_count": 1 if semantic_field_count else 0,
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_proof_source_required_count": 1 if field_proof_required else 0,
            "source_theorem_provenance_required_count": 1 if source_theorem_provenance_required and not machine_checked else 0,
            "production_claim_machine_checked_count": 1 if machine_checked and state == CLOSED_STATE else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": lake_env_used,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
        },
        "transfer_field_semantic_statements": [
            {
                "lean_structure_name": "ProfileEquivalenceTransferSemantics",
                "lean_relative_theorem_name": "profileEquivalenceTransferSemanticImplicationDraft",
                "semantic_field_name": "sourceBackedProfileEquivalenceTransfer",
                "source_locators": source_locators,
                "field_as_production_proof_allowed": False,
                "proof_source_required": field_proof_required,
                "machine_checked": False,
            }
        ],
        "transfer_field_proof_obligations": [
            {
                "obligation_id": "profile-equivalence-transfer-no-placeholder-theorem",
                "lean_declaration_name": "profileEquivalenceTransfersDirectScoreLimit",
                "required_source_kind": "source_backed_no_placeholder_profile_equivalence_transfer_theorem",
                "source_theorem_provenance_required": bool(source_theorem_provenance_required),
                "proof_source_required": field_proof_required,
                "assumption_echo_allowed": False,
                "placeholder_allowed": False,
                "next_required_action": "produce_or_intake_no_placeholder_profile_equivalence_transfer_theorem",
            }
        ],
        "source_locators": source_locators,
        "domain_theorem_bridge_transfer_field_proof_source_production_plan_report": plan_report,
        "boundary": [
            "This command syntax-checks a transfer-field semantic statement only; the sourceBackedProfileEquivalenceTransfer field is not production proof.",
            "Generated artifacts under logs/paperctl/_batches must not be accepted by proof-source intake as theorem provenance.",
            "The next stage still requires profileEquivalenceTransfersDirectScoreLimit as a source-backed no-placeholder theorem.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Semantic Statement Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_semantic_statement_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Transfer proof source required: {report.get('profile_equivalence_transfer_proof_source_required')}",
        f"- Source theorem provenance required: {report.get('source_theorem_provenance_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Semantic Statements", ""])
    for item in report.get("transfer_field_semantic_statements") or []:
        lines.append(
            f"- {item.get('lean_structure_name')}: field={item.get('semantic_field_name')} "
            f"proof_source_required={item.get('proof_source_required')}"
        )
    lines.extend(["", "## Proof Obligations", ""])
    for item in report.get("transfer_field_proof_obligations") or []:
        lines.append(
            f"- {item.get('obligation_id')}: {item.get('lean_declaration_name')} "
            f"source_provenance_required={item.get('source_theorem_provenance_required')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
