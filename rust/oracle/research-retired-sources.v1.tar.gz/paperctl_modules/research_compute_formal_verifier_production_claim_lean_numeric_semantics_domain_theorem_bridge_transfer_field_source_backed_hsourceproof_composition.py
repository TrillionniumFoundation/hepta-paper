"""Compose the source-backed hSourceProof after all premise proof sources are ready."""

import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-hsourceproof-composition"
PREMISE_PROOF_WORK_ITEM_DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-work-item-dispatch"
TARGET_THEOREM_INTEGRATION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-target-theorem-integration"
PREMISE_PROOF_WORK_ITEM_DISPATCH_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

WORK_ITEMS_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_WORK_ITEM_DISPATCH_READY_SOURCE_TERMS_REQUIRED"
WORK_ITEMS_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"

HSOURCEPROOF_COMPOSITION_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_HSOURCEPROOF_COMPOSITION_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_HSOURCEPROOF_COMPOSITION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_HSOURCEPROOF_COMPOSITION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_HSOURCEPROOF_COMPOSITION_FAILED"

SOURCE_RELATIVE_PATH = "PaperFactoryFormalVerifier/SourceBacked/TransferComposition.lean"
EXPECTED_THEOREM_NAME = "sourceBackedProfileEquivalenceTransfersDirectScoreLimit"
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"
EXPECTED_PREMISE_PROOF_NAMES = [
    "sourceBackedProfileEquivalenceTheoremAnchor",
    "sourceBackedProfileEquivalenceProofAnchor",
    "sourceBackedFastTransferAnchor",
    "sourceBackedOperationalCertificateAnchor",
    "sourceBackedFixedDeltaRateNegligible",
    "sourceBackedHighFrequencyDriftRateNegligible",
    "sourceBackedHighFrequencyDiffusionRateNegligible",
    "sourceBackedFastTransferCertificate",
    "sourceBackedOperationalCertificate",
    "sourceBackedDirectEulerLimit",
]
FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*(?:theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
DEF_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STATEMENT_ASSUMPTION_ECHO_RE = re.compile(r"\bhSourceProof\b")
PREMISE_ASSUMPTION_ECHO_RE = re.compile(r"\bh(ProfileEquivalence|Fast|Operational|Fixed|Drift|Diffusion|Euler)")
UNSAFE_SOURCE_PARTS = {".git", ".lake", "logs", "node_modules", "__pycache__"}

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_hsourceproof_composition_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "lean_source_sha256",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "hsourceproof_composition",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "premise_proof_work_item_dispatch_validation_issue_count",
    "premise_proof_work_item_count",
    "ready_work_item_count",
    "blocking_work_item_count",
    "ready_candidate_work_item_count",
    "lean_structure_count",
    "lean_def_count",
    "lean_theorem_count",
    "expected_premise_proof_reference_count",
    "placeholder_token_count",
    "statement_assumption_echo_marker_count",
    "premise_assumption_echo_marker_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_source_backed_hsourceproof_composition_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "profile_equivalence_transfer_target_theorem_proved_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the premise-proof work-item dispatch after all ten source-tree premise proof theorems are ready.",
    "Runs Lean on a source-tree hSourceProof composition theorem and records source-proof readiness without promoting the final target theorem.",
    "Generated logs, statement-assumption echo, premise-assumption echo, placeholders, source mutation, and external actions remain outside this boundary.",
]


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _strip_lean_comments_and_strings(text):
    out = []
    i = 0
    depth = 0
    in_string = False
    in_char = False
    while i < len(text):
        ch = text[i]
        nxt = text[i + 1] if i + 1 < len(text) else ""
        if in_string:
            if ch == "\\":
                out.append(" ")
                if i + 1 < len(text):
                    out.append(" ")
                    i += 2
                    continue
            elif ch == '"':
                in_string = False
            out.append("\n" if ch == "\n" else " ")
            i += 1
            continue
        if in_char:
            if ch == "\\":
                out.append(" ")
                if i + 1 < len(text):
                    out.append(" ")
                    i += 2
                    continue
            elif ch == "'":
                in_char = False
            out.append("\n" if ch == "\n" else " ")
            i += 1
            continue
        if depth:
            if ch == "/" and nxt == "-":
                depth += 1
                out.extend("  ")
                i += 2
                continue
            if ch == "-" and nxt == "/":
                depth -= 1
                out.extend("  ")
                i += 2
                continue
            out.append("\n" if ch == "\n" else " ")
            i += 1
            continue
        if ch == "-" and nxt == "-":
            out.extend("  ")
            i += 2
            while i < len(text) and text[i] != "\n":
                out.append(" ")
                i += 1
            continue
        if ch == "/" and nxt == "-":
            depth = 1
            out.extend("  ")
            i += 2
            continue
        if ch == '"':
            in_string = True
            out.append(" ")
            i += 1
            continue
        if ch == "'":
            in_char = True
            out.append(" ")
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


def _candidate_source_paths(work_items):
    paths = []
    for item in work_items:
        for candidate in item.get("candidate_sources") or []:
            if candidate.get("ready"):
                paths.append(candidate.get("path") or "")
    return [path for path in paths if path]


def _unsafe_candidate_path(path):
    text = str(path or "")
    if not text:
        return "empty_candidate_path"
    parts = set(pathlib.PurePosixPath(text.replace("\\", "/")).parts)
    if ".lake" in parts or ".git" in parts or "node_modules" in parts or "__pycache__" in parts:
        return "candidate_source_path_generated_or_cache"
    if "logs" in parts and "paperctl" in parts and "_batches" in parts:
        return "candidate_source_path_generated_log"
    return ""


def _dispatch_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report_missing")
        return issues
    if report.get("command") != PREMISE_PROOF_WORK_ITEM_DISPATCH_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_state") or ""
    if state not in {WORK_ITEMS_READY_STATE, WORK_ITEMS_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_state_not_consumable", state)
    work_items = list(report.get("premise_proof_work_items") or [])
    if not work_items:
        _issue(issues, "premise_proof_work_items_missing")
    blocking = [item for item in work_items if item.get("blocking")]
    if blocking:
        _issue(issues, "premise_proof_work_items_still_blocking", str(len(blocking)))
    if not report.get("profile_equivalence_transfer_source_backed_premise_proof_terms_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_premise_proof_terms_not_ready")
    for item in work_items:
        if not item.get("ready_candidate_count"):
            _issue(issues, "premise_proof_work_item_missing_ready_candidate", item.get("work_item_id") or "")
        if item.get("ready_candidate_count", 0) > item.get("local_candidate_count", 0):
            _issue(issues, "premise_proof_work_item_ready_candidate_count_exceeds_local_candidates", item.get("work_item_id") or "")
    for path in _candidate_source_paths(work_items):
        unsafe = _unsafe_candidate_path(path)
        if unsafe:
            _issue(issues, unsafe, path)
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_source_ready_premature_in_dispatch")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_boundary:{key}")
    return issues


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds, cwd)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    dispatch_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    source_path = source_root_path / SOURCE_RELATIVE_PATH
    dispatch_ref_issues, dispatch_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch",
        dispatch_report,
        expected_command=PREMISE_PROOF_WORK_ITEM_DISPATCH_COMMAND,
        max_age_min=PREMISE_PROOF_WORK_ITEM_DISPATCH_MAX_AGE_MIN,
    )
    validation_issues = dispatch_ref_issues + _dispatch_issues(dispatch_report)
    machine_checked = bool(dispatch_report.get("production_claim_machine_checked"))
    work_items = list(dispatch_report.get("premise_proof_work_items") or [])
    source_text = source_path.read_text() if source_path.exists() else ""
    stripped_source = _strip_lean_comments_and_strings(source_text)
    if not source_path.exists():
        _issue(validation_issues, "hsourceproof_composition_source_missing", SOURCE_RELATIVE_PATH)

    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_path)
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command and source_path.exists():
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(stripped_source)
    defs = DEF_RE.findall(stripped_source)
    theorem_names = THEOREM_RE.findall(stripped_source)
    placeholders = PLACEHOLDER_RE.findall(stripped_source)
    statement_echo = STATEMENT_ASSUMPTION_ECHO_RE.findall(stripped_source)
    premise_echo = PREMISE_ASSUMPTION_ECHO_RE.findall(stripped_source)
    expected_refs = [name for name in EXPECTED_PREMISE_PROOF_NAMES if re.search(rf"\b{re.escape(name)}\b", stripped_source)]
    target_theorem_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    all_work_items_ready = bool(work_items and all(not item.get("blocking") for item in work_items))
    hsourceproof_ready = bool(
        lean_exit_zero
        and EXPECTED_THEOREM_NAME in theorem_names
        and TARGET_STATEMENT_NAME in defs
        and len(expected_refs) == len(EXPECTED_PREMISE_PROOF_NAMES)
        and not target_theorem_declarations
        and not placeholders
        and not statement_echo
        and not premise_echo
        and all_work_items_ready
        and not validation_issues
        and not machine_checked
    )
    checks = [
        _check("premise_proof_work_item_dispatch_report_consumable", not _dispatch_issues(dispatch_report), "premise_proof_work_item_dispatch_not_consumable"),
        _check("premise_work_items_present", bool(work_items), "premise_work_items_missing"),
        _check("premise_work_items_all_ready", all_work_items_ready or machine_checked, "premise_work_items_not_all_ready"),
        _check("composition_source_present", source_path.exists(), "hsourceproof_composition_source_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("hsourceproof_composition_theorem_present", EXPECTED_THEOREM_NAME in theorem_names, "hsourceproof_composition_theorem_missing"),
        _check("target_statement_def_present", TARGET_STATEMENT_NAME in defs, "target_statement_def_missing"),
        _check("expected_premise_proof_references_present", len(expected_refs) == len(EXPECTED_PREMISE_PROOF_NAMES), "expected_premise_proof_references_missing"),
        _check("target_theorem_not_declared", not target_theorem_declarations, "target_theorem_declared_without_final_integration"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("statement_assumption_echo_absent", not statement_echo, "statement_assumption_echo_present"),
        _check("premise_assumption_echo_absent", not premise_echo, "premise_assumption_echo_present"),
        _check("no_source_mutation", not dispatch_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not dispatch_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif hsourceproof_ready:
        status = "PASS"
        state = HSOURCEPROOF_COMPOSITION_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration"
        next_agent_command = TARGET_THEOREM_INTEGRATION_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    source_sha = _sha256_file(source_path) if source_path.exists() else ""
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": bool(status == "PASS" and all_work_items_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_hsourceproof_composition_ready": bool(status == "PASS" and hsourceproof_ready),
        "profile_equivalence_transfer_source_backed_proof_source_ready": bool(status == "PASS" and hsourceproof_ready),
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": str(source_path),
        "lean_source_sha256": source_sha,
        "claim_packet_id": dispatch_report.get("claim_packet_id") or "",
        "slug": dispatch_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report_path": dispatch_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report_sha256": dispatch_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_ref_health": dispatch_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "premise_proof_work_item_dispatch_validation_issue_count": len(dispatch_ref_issues),
            "premise_proof_work_item_count": len(work_items),
            "ready_work_item_count": sum(1 for item in work_items if not item.get("blocking")),
            "blocking_work_item_count": sum(1 for item in work_items if item.get("blocking")),
            "ready_candidate_work_item_count": sum(1 for item in work_items if item.get("ready_candidate_count")),
            "lean_structure_count": len(structures),
            "lean_def_count": len(defs),
            "lean_theorem_count": len(theorem_names),
            "expected_premise_proof_reference_count": len(expected_refs),
            "placeholder_token_count": len(placeholders),
            "statement_assumption_echo_marker_count": len(statement_echo),
            "premise_assumption_echo_marker_count": len(premise_echo),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_source_backed_hsourceproof_composition_ready_count": 1 if status == "PASS" and hsourceproof_ready else 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 1 if status == "PASS" and hsourceproof_ready else 0,
            "profile_equivalence_transfer_target_theorem_proved_count": 1 if production_checked else 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "source_path": str(source_path),
            "source_sha256": source_sha,
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "def_names": defs,
            "theorem_names": theorem_names,
            "expected_premise_proof_references": expected_refs,
            "placeholder_token_count": len(placeholders),
            "statement_assumption_echo_marker_count": len(statement_echo),
            "premise_assumption_echo_marker_count": len(premise_echo),
        },
        "hsourceproof_composition": {
            "lean_declaration_name": EXPECTED_THEOREM_NAME,
            "target_statement_name": TARGET_STATEMENT_NAME,
            "source_tree_relative_path": SOURCE_RELATIVE_PATH,
            "source_backed_premise_proof_terms_ready": bool(all_work_items_ready and not production_checked),
            "source_backed_hsourceproof_composition_ready": bool(status == "PASS" and hsourceproof_ready),
            "source_backed_proof_source_ready": bool(status == "PASS" and hsourceproof_ready),
            "proves_target_theorem": False,
            "next_required_action": "wire_source_backed_hSourceProof_into_target_theorem_without_statement_assumption_echo",
        },
        "formalization_route": [
            {
                "step_id": "consume_ready_source_backed_premise_terms",
                "status": "ready" if all_work_items_ready else "attention",
                "output": "all ten premise proof work items are ready from source-tree Lean theorem candidates",
            },
            {
                "step_id": "compose_hSourceProof",
                "status": "ready" if hsourceproof_ready else "attention",
                "output": "Lean checks a source-tree theorem for ProfileEquivalenceTransfersDirectScoreLimitStatement",
            },
            {
                "step_id": "target_theorem_integration",
                "status": "pending" if hsourceproof_ready else "attention",
                "output": "the final target theorem still needs to consume the composed source proof",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_report": dispatch_report,
        "boundary": [
            "This command composes the source-backed hSourceProof only; it does not prove or promote the final target theorem.",
            "It consumes source-tree premise proof readiness and runs Lean on PaperFactoryFormalVerifier/SourceBacked/TransferComposition.lean.",
            "It rejects generated logs, placeholders, statement-assumption echo, premise-assumption echo, source mutation, external action, and commits.",
            "The next stage must wire the composed source proof into profileEquivalenceTransfersDirectScoreLimit without assuming hSourceProof.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source-Backed hSourceProof Composition",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Work items: {summary.get('premise_proof_work_item_count', 0)}",
        f"- Ready work items: {summary.get('ready_work_item_count', 0)}",
        f"- hSourceProof composition ready: {report.get('profile_equivalence_transfer_source_backed_hsourceproof_composition_ready')}",
        f"- Source-backed proof source ready: {report.get('profile_equivalence_transfer_source_backed_proof_source_ready')}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
