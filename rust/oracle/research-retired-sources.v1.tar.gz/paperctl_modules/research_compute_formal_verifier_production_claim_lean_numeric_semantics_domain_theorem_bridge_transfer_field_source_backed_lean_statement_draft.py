"""Draft a source-backed Lean statement interface for the transfer theorem."""

import datetime as dt
import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-lean-statement-draft"
SOURCE_BACKED_THEOREM_EXTRACTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-theorem-extraction"
SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-no-placeholder-lean-proof-attempt"
SOURCE_BACKED_THEOREM_EXTRACTION_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

SOURCE_BACKED_THEOREM_EXTRACTION_SOURCE_ANCHORS_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_THEOREM_EXTRACTION_SOURCE_ANCHORS_READY_LEAN_PROOF_REQUIRED"
SOURCE_BACKED_THEOREM_EXTRACTION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_THEOREM_EXTRACTION_MACHINE_CHECKED_CLOSED"

SOURCE_BACKED_LEAN_STATEMENT_DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_LEAN_STATEMENT_DRAFT_READY_PROOF_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_LEAN_STATEMENT_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_LEAN_STATEMENT_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_LEAN_STATEMENT_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_ready",
    "profile_equivalence_transfer_lean_statement_draft_ready",
    "profile_equivalence_transfer_no_placeholder_lean_statement_ready",
    "profile_equivalence_transfer_lean_proof_required",
    "profile_equivalence_transfer_lean_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "profile_equivalence_transfer_field_forwarding_detected",
    "profile_equivalence_transfer_assumption_echo_detected",
    "field_forwarding_allowed_as_production_proof",
    "generated_log_provenance_allowed",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_anchor_inputs",
    "lean_statement_interfaces",
    "source_backed_lean_statement_obligations",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "theorem_extraction_ref_validation_issue_count",
    "source_anchor_input_count",
    "required_source_anchor_count",
    "required_source_anchor_ready_count",
    "lean_structure_count",
    "lean_def_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "field_forwarding_marker_count",
    "assumption_echo_marker_count",
    "target_theorem_declaration_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_lean_statement_draft_ready_count",
    "profile_equivalence_transfer_no_placeholder_lean_statement_ready_count",
    "profile_equivalence_transfer_lean_proof_required_count",
    "profile_equivalence_transfer_lean_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes source-backed manuscript anchor extraction and writes an explicit Lean statement interface for profileEquivalenceTransfersDirectScoreLimit.",
    "The generated Lean proves only definitional expansion of the statement interface; it does not prove the target transfer theorem.",
    "Field-forwarding, generated logs, placeholders, and assumption echo remain rejected as production proof sources.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
DEF_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
FIELD_FORWARDING_RE = re.compile(r"\bsourceBackedProfileEquivalenceTransfer\b")
ASSUMPTION_ECHO_RE = re.compile(r"\b(by\s+assumption|assumption|exact\s+h[A-Za-z0-9_']*)\b")
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
STATEMENT_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimitStatementDraft"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _extraction_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_missing")
        return issues
    if report.get("command") != SOURCE_BACKED_THEOREM_EXTRACTION_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_state") or ""
    if state not in {SOURCE_BACKED_THEOREM_EXTRACTION_SOURCE_ANCHORS_READY_STATE, SOURCE_BACKED_THEOREM_EXTRACTION_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_state_not_consumable", state)
    if not report.get("profile_equivalence_transfer_source_anchors_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_anchors_not_ready")
    if not report.get("profile_equivalence_transfer_lean_proof_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_lean_proof_required_missing")
    if report.get("profile_equivalence_transfer_lean_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_lean_proof_source_ready_premature")
    if report.get("field_forwarding_allowed_as_production_proof"):
        _issue(issues, "field_forwarding_allowed_as_production_proof")
    if report.get("generated_log_provenance_allowed"):
        _issue(issues, "generated_log_provenance_allowed")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_boundary:{key}")
    return issues


def _source_anchor_inputs(report):
    anchors = []
    for item in report.get("source_anchor_extractions") or []:
        matches = item.get("matches") or []
        locators = [str(match.get("source_locator") or "") for match in matches if match.get("source_locator")]
        anchors.append(
            {
                "anchor_id": item.get("anchor_id") or "",
                "label": item.get("label") or "",
                "required": bool(item.get("required")),
                "formal_role": item.get("formal_role") or "",
                "found": bool(item.get("found")),
                "match_count": int(item.get("match_count") or 0),
                "source_locators": locators[:4],
            }
        )
    return anchors


def _comment_text(value):
    return str(value or "").replace("-/", "- /")


def _anchor_comment_lines(anchors):
    lines = []
    for item in anchors:
        if not item.get("found"):
            continue
        locators = item.get("source_locators") or ["unavailable"]
        for locator in locators[:2]:
            lines.append(f"{item.get('label')}: {_comment_text(locator)}")
    if not lines:
        lines = ["source anchors unavailable"]
    return "\n".join(f"Source anchor: {line}" for line in lines[:16])


def _lean_source(anchors):
    anchor_lines = _anchor_comment_lines(anchors)
    return f"""import Mathlib

open Filter Asymptotics

/-
paper_factory source-backed profile-equivalence transfer statement draft.
This file checks the Lean statement interface only.
It does not declare or prove profileEquivalenceTransfersDirectScoreLimit.
{anchor_lines}
-/

namespace NSMAoSFormalization

noncomputable section

def RateSeq := Nat -> Real

def LittleOAtTop (f g : RateSeq) : Prop :=
  Asymptotics.IsLittleO atTop f g

structure ProfileEquivalenceTransferRatePremises where
  fixedDeltaRateNegligible : Prop
  highFrequencyDriftRateNegligible : Prop
  highFrequencyDiffusionRateNegligible : Prop
  fastTransferCertificate : Prop
  operationalCertificate : Prop

structure DirectEulerLimitInput where
  directEulerLimit : Prop
  waldValidForDirectEuler : Prop

structure ProfileEquivalenceSourceAnchors where
  profileEquivalenceTheoremAnchor : Prop
  profileEquivalenceProofAnchor : Prop
  fastTransferAnchor : Prop
  operationalCertificateAnchor : Prop
  highFrequencyScheduleAnchor : Prop
  directHfInputAnchor : Prop

structure ProfileEquivalenceTransferLeanStatement where
  ratePremises : ProfileEquivalenceTransferRatePremises
  directEulerInput : DirectEulerLimitInput
  sourceAnchors : ProfileEquivalenceSourceAnchors
  profiledEstimatorWaldValid : Prop

def ProfileEquivalenceTransfersDirectScoreLimitStatement
    (S : ProfileEquivalenceTransferLeanStatement) : Prop :=
  S.sourceAnchors.profileEquivalenceTheoremAnchor ->
  S.sourceAnchors.profileEquivalenceProofAnchor ->
  S.sourceAnchors.fastTransferAnchor ->
  S.sourceAnchors.operationalCertificateAnchor ->
  S.ratePremises.fixedDeltaRateNegligible ->
  S.ratePremises.highFrequencyDriftRateNegligible ->
  S.ratePremises.highFrequencyDiffusionRateNegligible ->
  S.ratePremises.fastTransferCertificate ->
  S.ratePremises.operationalCertificate ->
  S.directEulerInput.directEulerLimit ->
  S.profiledEstimatorWaldValid

theorem profileEquivalenceTransfersDirectScoreLimitStatementDraft
    (S : ProfileEquivalenceTransferLeanStatement) :
    ProfileEquivalenceTransfersDirectScoreLimitStatement S =
      (S.sourceAnchors.profileEquivalenceTheoremAnchor ->
       S.sourceAnchors.profileEquivalenceProofAnchor ->
       S.sourceAnchors.fastTransferAnchor ->
       S.sourceAnchors.operationalCertificateAnchor ->
       S.ratePremises.fixedDeltaRateNegligible ->
       S.ratePremises.highFrequencyDriftRateNegligible ->
       S.ratePremises.highFrequencyDiffusionRateNegligible ->
       S.ratePremises.fastTransferCertificate ->
       S.ratePremises.operationalCertificate ->
       S.directEulerInput.directEulerLimit ->
       S.profiledEstimatorWaldValid) := by
  rfl

end

end NSMAoSFormalization
"""


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft(
    domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    extraction_report = domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report or {}
    extraction_ref_issues, extraction_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction",
        extraction_report,
        expected_command=SOURCE_BACKED_THEOREM_EXTRACTION_COMMAND,
        max_age_min=SOURCE_BACKED_THEOREM_EXTRACTION_MAX_AGE_MIN,
    )
    validation_issues = extraction_ref_issues + _extraction_issues(extraction_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    source_root_path = pathlib.Path(source_root or ".").resolve()
    machine_checked = bool(
        extraction_report.get("production_claim_machine_checked")
        and extraction_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_state") == SOURCE_BACKED_THEOREM_EXTRACTION_CLOSED_STATE
    )
    anchors = _source_anchor_inputs(extraction_report)
    required_anchors = [item for item in anchors if item.get("required")]
    required_ready_count = sum(1 for item in required_anchors if item.get("found"))
    lean_source_text = _lean_source(anchors)
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-lean-statement-draft.lean", lean_source_text)
    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_info["path"])
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command:
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    defs = DEF_RE.findall(lean_source_text)
    theorem_names = THEOREM_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    field_forwarding_markers = FIELD_FORWARDING_RE.findall(lean_source_text)
    assumption_echo_markers = ASSUMPTION_ECHO_RE.findall(lean_source_text)
    target_theorem_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    statement_theorem_present = STATEMENT_THEOREM_NAME in theorem_names
    statement_def_present = "ProfileEquivalenceTransfersDirectScoreLimitStatement" in defs
    required_structures_present = {
        "ProfileEquivalenceTransferRatePremises",
        "DirectEulerLimitInput",
        "ProfileEquivalenceSourceAnchors",
        "ProfileEquivalenceTransferLeanStatement",
    }.issubset(set(structures))
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    no_placeholder_statement_ready = bool(
        lean_exit_zero
        and statement_theorem_present
        and statement_def_present
        and required_structures_present
        and not placeholders
        and not field_forwarding_markers
        and not assumption_echo_markers
        and not target_theorem_declarations
    )
    lean_proof_required = bool(extraction_report.get("profile_equivalence_transfer_lean_proof_required") and not machine_checked)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_consumable", not _extraction_issues(extraction_report), "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_not_consumable"),
        _check("domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_ref_fresh", not extraction_ref_issues, "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_ref_not_fresh"),
        _check("required_source_anchors_ready", machine_checked or required_ready_count == len(required_anchors) and bool(required_anchors), "required_source_anchors_not_ready"),
        _check("lean_proof_requirement_preserved", machine_checked or lean_proof_required, "lean_proof_required_missing", severity="readiness"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("statement_structures_present", required_structures_present, "statement_structures_missing"),
        _check("statement_def_present", statement_def_present, "statement_def_missing"),
        _check("statement_theorem_present", statement_theorem_present, "statement_theorem_missing"),
        _check("target_theorem_not_declared", not target_theorem_declarations, "target_theorem_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("field_forwarding_absent", not field_forwarding_markers, "field_forwarding_marker_present"),
        _check("assumption_echo_absent", not assumption_echo_markers, "assumption_echo_marker_present"),
        _check("generated_log_provenance_rejected", True, ""),
        _check("no_source_mutation", not extraction_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not extraction_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif no_placeholder_statement_ready and lean_proof_required:
        status = "PASS"
        state = SOURCE_BACKED_LEAN_STATEMENT_DRAFT_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof"
        next_agent_command = SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    target_theorem_proved = bool(production_checked)
    statement_ready = bool(status == "PASS" and no_placeholder_statement_ready)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_lean_statement_draft_ready": statement_ready,
        "profile_equivalence_transfer_no_placeholder_lean_statement_ready": bool(statement_ready and not placeholders),
        "profile_equivalence_transfer_lean_proof_required": bool(status == "PASS" and lean_proof_required and not production_checked),
        "profile_equivalence_transfer_lean_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": target_theorem_proved,
        "profile_equivalence_transfer_field_forwarding_detected": bool(field_forwarding_markers),
        "profile_equivalence_transfer_assumption_echo_detected": bool(assumption_echo_markers),
        "field_forwarding_allowed_as_production_proof": False,
        "generated_log_provenance_allowed": False,
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": extraction_report.get("claim_packet_id") or "",
        "slug": extraction_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_path": extraction_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report_sha256": extraction_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_ref_health": extraction_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "theorem_extraction_ref_validation_issue_count": len(extraction_ref_issues),
            "source_anchor_input_count": len(anchors),
            "required_source_anchor_count": len(required_anchors),
            "required_source_anchor_ready_count": required_ready_count,
            "lean_structure_count": len(structures),
            "lean_def_count": len(defs),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "field_forwarding_marker_count": len(field_forwarding_markers),
            "assumption_echo_marker_count": len(assumption_echo_markers),
            "target_theorem_declaration_count": len(target_theorem_declarations),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_lean_statement_draft_ready_count": 1 if statement_ready else 0,
            "profile_equivalence_transfer_no_placeholder_lean_statement_ready_count": 1 if statement_ready and not placeholders else 0,
            "profile_equivalence_transfer_lean_proof_required_count": 1 if lean_proof_required and not production_checked else 0,
            "profile_equivalence_transfer_lean_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": lake_env_used,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "def_names": defs,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "field_forwarding_marker_count": len(field_forwarding_markers),
            "assumption_echo_marker_count": len(assumption_echo_markers),
            "target_theorem_declaration_count": len(target_theorem_declarations),
        },
        "source_anchor_inputs": anchors,
        "lean_statement_interfaces": [
            {
                "lean_declaration_name": "ProfileEquivalenceTransferRatePremises",
                "declaration_kind": "structure",
                "source_labels": ["prop:fast_transfer", "prop:operational_certificate", "cor:hf_calibration_schedule"],
            },
            {
                "lean_declaration_name": "DirectEulerLimitInput",
                "declaration_kind": "structure",
                "source_labels": ["ass:direct_hf_input", "thm:profile_equivalence"],
            },
            {
                "lean_declaration_name": "ProfileEquivalenceSourceAnchors",
                "declaration_kind": "structure",
                "source_labels": ["thm:profile_equivalence", "app:profile_equivalence_proof", "prop:fast_transfer", "prop:operational_certificate"],
            },
            {
                "lean_declaration_name": "ProfileEquivalenceTransfersDirectScoreLimitStatement",
                "declaration_kind": "def",
                "target_theorem_name": TARGET_THEOREM_NAME,
                "proves_target_theorem": False,
            },
            {
                "lean_declaration_name": STATEMENT_THEOREM_NAME,
                "declaration_kind": "theorem",
                "proof_kind": "definitional_expansion_only",
                "proves_target_theorem": False,
            },
        ],
        "source_backed_lean_statement_obligations": [
            {
                "obligation_id": "profile-equivalence-transfer-source-backed-no-placeholder-lean-proof",
                "lean_declaration_name": TARGET_THEOREM_NAME,
                "statement_interface_ready": bool(statement_ready),
                "lean_proof_required": bool(status == "PASS" and lean_proof_required and not production_checked),
                "lean_proof_source_ready": False,
                "field_forwarding_allowed_as_production_proof": False,
                "generated_log_provenance_allowed": False,
                "placeholder_allowed": False,
                "target_theorem_proved": target_theorem_proved,
                "next_required_action": "construct_source_backed_no_placeholder_profile_equivalence_transfer_lean_proof",
            }
        ],
        "formalization_route": [
            {
                "step_id": "extract_source_anchors",
                "status": "ready" if anchors else "missing",
                "output": "source-backed labels and locators are available to the Lean statement draft",
            },
            {
                "step_id": "draft_lean_statement",
                "status": "ready" if statement_ready else "attention",
                "output": "explicit profile-equivalence transfer theorem interface checked by Lean",
            },
            {
                "step_id": "prove_or_intake_lean_theorem",
                "status": "blocked_on_proof_source" if status == "PASS" and not production_checked else "closed",
                "output": "source-backed no-placeholder Lean theorem for profileEquivalenceTransfersDirectScoreLimit",
            },
            {
                "step_id": "rewire_bridge",
                "status": "pending" if status == "PASS" and not production_checked else "closed",
                "output": "waldDirectEulerDomainBridge consumes the produced transfer theorem and reruns Lean gates",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report": extraction_report,
        "boundary": [
            "This command drafts and checks only the Lean statement interface for the source-backed profile-equivalence transfer theorem.",
            "The target theorem profileEquivalenceTransfersDirectScoreLimit is not declared or proved here.",
            "A source anchor, generated Lean artifact, statement equality, field forwarding, or assumption echo is not a production proof.",
            "The next stage must construct or intake a source-backed no-placeholder Lean proof outside logs/paperctl/_batches.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Source Backed Lean Statement Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Statement draft ready: {report.get('profile_equivalence_transfer_lean_statement_draft_ready')}",
        f"- Target theorem proved: {report.get('profile_equivalence_transfer_target_theorem_proved')}",
        f"- Lean proof required: {report.get('profile_equivalence_transfer_lean_proof_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Statement Interfaces", ""])
    for item in report.get("lean_statement_interfaces") or []:
        lines.append(
            f"- {item.get('lean_declaration_name')}: kind={item.get('declaration_kind')} "
            f"proves_target={item.get('proves_target_theorem')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
