"""Attempt the source-backed transfer theorem and reject statement-assumption echo."""

import datetime as dt
import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health

COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-no-placeholder-lean-proof-attempt"
SOURCE_BACKED_LEAN_STATEMENT_DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-lean-statement-draft"
SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-proof-source-construction"
SOURCE_BACKED_LEAN_STATEMENT_DRAFT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

SOURCE_BACKED_LEAN_STATEMENT_DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_LEAN_STATEMENT_DRAFT_READY_PROOF_REQUIRED"
SOURCE_BACKED_LEAN_STATEMENT_DRAFT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_LEAN_STATEMENT_DRAFT_MACHINE_CHECKED_CLOSED"

SOURCE_PROOF_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_SOURCE_PROOF_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_ready",
    "profile_equivalence_transfer_no_placeholder_target_theorem_attempt_ready",
    "profile_equivalence_transfer_target_theorem_compiles_with_statement_assumption",
    "profile_equivalence_transfer_statement_assumption_echo_proof_rejected",
    "profile_equivalence_transfer_field_forwarding_detected",
    "profile_equivalence_transfer_source_backed_proof_required",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "field_forwarding_allowed_as_production_proof",
    "generated_log_provenance_allowed",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "proof_attempt_classifications",
    "source_backed_proof_obligations",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "lean_statement_draft_validation_issue_count",
    "lean_structure_count",
    "lean_def_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "field_forwarding_marker_count",
    "statement_assumption_echo_marker_count",
    "target_theorem_declaration_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_no_placeholder_target_theorem_attempt_ready_count",
    "profile_equivalence_transfer_statement_assumption_echo_rejected_count",
    "profile_equivalence_transfer_source_backed_proof_required_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the source-backed Lean statement draft and runs Lean on the target transfer theorem name.",
    "The target theorem compiles only by assuming hSourceProof, which is rejected as statement-assumption echo rather than accepted as production proof.",
    "This command records the remaining proof construction obligation without accepting generated logs, field forwarding, placeholders, or assumption echo.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
DEF_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
FIELD_FORWARDING_RE = re.compile(r"\bsourceBackedProfileEquivalenceTransfer\b")
STATEMENT_ASSUMPTION_ECHO_RE = re.compile(r"\bhSourceProof\b|\bProfileEquivalenceTransfersDirectScoreLimitStatement\s+S\b")
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _statement_draft_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_missing")
        return issues
    if report.get("command") != SOURCE_BACKED_LEAN_STATEMENT_DRAFT_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_state") or ""
    if state not in {SOURCE_BACKED_LEAN_STATEMENT_DRAFT_READY_STATE, SOURCE_BACKED_LEAN_STATEMENT_DRAFT_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_state_not_consumable", state)
    if not report.get("profile_equivalence_transfer_lean_statement_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_lean_statement_draft_not_ready")
    if not report.get("profile_equivalence_transfer_no_placeholder_lean_statement_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_no_placeholder_lean_statement_not_ready")
    if not report.get("profile_equivalence_transfer_lean_proof_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_lean_proof_required_missing")
    if report.get("profile_equivalence_transfer_target_theorem_proved") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_target_theorem_proved_without_machine_check")
    if report.get("profile_equivalence_transfer_field_forwarding_detected"):
        _issue(issues, "field_forwarding_detected_in_statement_draft")
    if report.get("field_forwarding_allowed_as_production_proof"):
        _issue(issues, "field_forwarding_allowed_as_production_proof")
    if report.get("generated_log_provenance_allowed"):
        _issue(issues, "generated_log_provenance_allowed")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_boundary:{key}")
    return issues


def _lean_source(report):
    source_path = report.get("lean_source_path") or "unavailable"
    return f"""import Mathlib

open Filter Asymptotics

/-
paper_factory source-backed profile-equivalence target theorem attempt.
The prior statement draft was checked at: {source_path}
This file checks that the target theorem name compiles only when an explicit
source proof of ProfileEquivalenceTransfersDirectScoreLimitStatement is assumed.
That statement-assumption echo is rejected outside Lean as production proof.
-/

namespace NSMAoSFormalization

noncomputable section

def RateSeq := Nat -> Real

def LittleOAtTop (f g : RateSeq) : Prop :=
  Asymptotics.IsLittleO atTop f g

structure ProfileEquivalenceTransferRatePremises where
  fixedDeltaRateNegligible : Prop
  highFrequencyDriftRateNegligible : Prop
  highFrequencyDiffusionRateNegligible : Prop
  fastTransferCertificate : Prop
  operationalCertificate : Prop

structure DirectEulerLimitInput where
  directEulerLimit : Prop
  waldValidForDirectEuler : Prop

structure ProfileEquivalenceSourceAnchors where
  profileEquivalenceTheoremAnchor : Prop
  profileEquivalenceProofAnchor : Prop
  fastTransferAnchor : Prop
  operationalCertificateAnchor : Prop
  highFrequencyScheduleAnchor : Prop
  directHfInputAnchor : Prop

structure ProfileEquivalenceTransferLeanStatement where
  ratePremises : ProfileEquivalenceTransferRatePremises
  directEulerInput : DirectEulerLimitInput
  sourceAnchors : ProfileEquivalenceSourceAnchors
  profiledEstimatorWaldValid : Prop

def ProfileEquivalenceTransfersDirectScoreLimitStatement
    (S : ProfileEquivalenceTransferLeanStatement) : Prop :=
  S.sourceAnchors.profileEquivalenceTheoremAnchor ->
  S.sourceAnchors.profileEquivalenceProofAnchor ->
  S.sourceAnchors.fastTransferAnchor ->
  S.sourceAnchors.operationalCertificateAnchor ->
  S.ratePremises.fixedDeltaRateNegligible ->
  S.ratePremises.highFrequencyDriftRateNegligible ->
  S.ratePremises.highFrequencyDiffusionRateNegligible ->
  S.ratePremises.fastTransferCertificate ->
  S.ratePremises.operationalCertificate ->
  S.directEulerInput.directEulerLimit ->
  S.profiledEstimatorWaldValid

theorem profileEquivalenceTransfersDirectScoreLimit
    (S : ProfileEquivalenceTransferLeanStatement)
    (hSourceProof : ProfileEquivalenceTransfersDirectScoreLimitStatement S)
    (hProfileTheorem : S.sourceAnchors.profileEquivalenceTheoremAnchor)
    (hProfileProof : S.sourceAnchors.profileEquivalenceProofAnchor)
    (hFastTransfer : S.sourceAnchors.fastTransferAnchor)
    (hOperational : S.sourceAnchors.operationalCertificateAnchor)
    (hFixedDelta : S.ratePremises.fixedDeltaRateNegligible)
    (hDrift : S.ratePremises.highFrequencyDriftRateNegligible)
    (hDiffusion : S.ratePremises.highFrequencyDiffusionRateNegligible)
    (hFastCertificate : S.ratePremises.fastTransferCertificate)
    (hOperationalCertificate : S.ratePremises.operationalCertificate)
    (hEuler : S.directEulerInput.directEulerLimit) :
    S.profiledEstimatorWaldValid :=
  hSourceProof
    hProfileTheorem
    hProfileProof
    hFastTransfer
    hOperational
    hFixedDelta
    hDrift
    hDiffusion
    hFastCertificate
    hOperationalCertificate
    hEuler

end

end NSMAoSFormalization
"""


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt(
    domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    statement_report = domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report or {}
    statement_ref_issues, statement_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft",
        statement_report,
        expected_command=SOURCE_BACKED_LEAN_STATEMENT_DRAFT_COMMAND,
        max_age_min=SOURCE_BACKED_LEAN_STATEMENT_DRAFT_MAX_AGE_MIN,
    )
    validation_issues = statement_ref_issues + _statement_draft_issues(statement_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    source_root_path = pathlib.Path(source_root or ".").resolve()
    machine_checked = bool(
        statement_report.get("production_claim_machine_checked")
        and statement_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_state") == SOURCE_BACKED_LEAN_STATEMENT_DRAFT_CLOSED_STATE
    )
    lean_source_text = _lean_source(statement_report)
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-no-placeholder-lean-proof-attempt.lean", lean_source_text)
    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_info["path"])
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command:
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    defs = DEF_RE.findall(lean_source_text)
    theorem_names = THEOREM_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    field_forwarding_markers = FIELD_FORWARDING_RE.findall(lean_source_text)
    statement_assumption_echo_markers = STATEMENT_ASSUMPTION_ECHO_RE.findall(lean_source_text)
    target_theorem_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    no_placeholder_target_attempt_ready = bool(
        lean_exit_zero
        and len(target_theorem_declarations) == 1
        and not placeholders
        and not field_forwarding_markers
    )
    statement_assumption_echo = bool(no_placeholder_target_attempt_ready and statement_assumption_echo_markers)
    source_backed_proof_required = bool(statement_assumption_echo and not machine_checked)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_consumable", not validation_issues, "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_not_consumable"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("target_theorem_declared", len(target_theorem_declarations) == 1, "target_theorem_missing_or_duplicate"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("field_forwarding_absent", not field_forwarding_markers, "field_forwarding_marker_present"),
        _check("statement_assumption_echo_detected", statement_assumption_echo or machine_checked, "statement_assumption_echo_missing", severity="readiness"),
        _check("statement_assumption_echo_rejected_as_production", statement_assumption_echo or machine_checked, "statement_assumption_echo_not_classified", severity="readiness"),
        _check("source_backed_proof_requirement_preserved", source_backed_proof_required or machine_checked, "source_backed_proof_requirement_missing", severity="readiness"),
        _check("generated_log_provenance_rejected", True, ""),
        _check("no_source_mutation", not statement_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not statement_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif statement_assumption_echo:
        status = "PASS"
        state = SOURCE_PROOF_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction"
        next_agent_command = SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    target_theorem_proved = bool(production_checked)
    statement_echo_rejected = bool(status == "PASS" and statement_assumption_echo and not production_checked)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_no_placeholder_target_theorem_attempt_ready": bool(no_placeholder_target_attempt_ready),
        "profile_equivalence_transfer_target_theorem_compiles_with_statement_assumption": bool(no_placeholder_target_attempt_ready and statement_assumption_echo),
        "profile_equivalence_transfer_statement_assumption_echo_proof_rejected": statement_echo_rejected,
        "profile_equivalence_transfer_field_forwarding_detected": bool(field_forwarding_markers),
        "profile_equivalence_transfer_source_backed_proof_required": bool(status == "PASS" and source_backed_proof_required and not production_checked),
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": target_theorem_proved,
        "field_forwarding_allowed_as_production_proof": False,
        "generated_log_provenance_allowed": False,
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": statement_report.get("claim_packet_id") or "",
        "slug": statement_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_path": statement_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report_sha256": statement_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_ref_health": statement_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "lean_statement_draft_validation_issue_count": len(statement_ref_issues),
            "lean_structure_count": len(structures),
            "lean_def_count": len(defs),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "field_forwarding_marker_count": len(field_forwarding_markers),
            "statement_assumption_echo_marker_count": len(statement_assumption_echo_markers),
            "target_theorem_declaration_count": len(target_theorem_declarations),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_no_placeholder_target_theorem_attempt_ready_count": 1 if no_placeholder_target_attempt_ready else 0,
            "profile_equivalence_transfer_statement_assumption_echo_rejected_count": 1 if statement_echo_rejected else 0,
            "profile_equivalence_transfer_source_backed_proof_required_count": 1 if source_backed_proof_required and not production_checked else 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": lake_env_used,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "def_names": defs,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "field_forwarding_marker_count": len(field_forwarding_markers),
            "statement_assumption_echo_marker_count": len(statement_assumption_echo_markers),
            "target_theorem_declaration_count": len(target_theorem_declarations),
        },
        "proof_attempt_classifications": [
            {
                "lean_declaration_name": TARGET_THEOREM_NAME,
                "declaration_kind": "theorem",
                "no_placeholder_target_theorem_attempt_ready": bool(no_placeholder_target_attempt_ready),
                "compiles_only_with_statement_assumption": bool(no_placeholder_target_attempt_ready and statement_assumption_echo),
                "statement_assumption_echo_proof_rejected": statement_echo_rejected,
                "field_forwarding_detected": bool(field_forwarding_markers),
                "field_forwarding_allowed_as_production_proof": False,
                "generated_log_provenance_allowed": False,
                "production_claim_machine_checked": False,
                "next_required_action": "construct_profile_equivalence_transfers_direct_score_limit_statement_without_statement_assumption_echo",
            }
        ],
        "source_backed_proof_obligations": [
            {
                "obligation_id": "profile-equivalence-transfer-source-proof-construction",
                "lean_declaration_name": "ProfileEquivalenceTransfersDirectScoreLimitStatement",
                "target_theorem_name": TARGET_THEOREM_NAME,
                "source_backed_proof_required": bool(status == "PASS" and source_backed_proof_required and not production_checked),
                "source_backed_proof_source_ready": False,
                "statement_assumption_echo_allowed": False,
                "field_forwarding_allowed_as_production_proof": False,
                "generated_log_provenance_allowed": False,
                "placeholder_allowed": False,
                "next_required_action": "formalize_or_intake_the_source_backed_profile_equivalence_transfer_proof_term",
            }
        ],
        "formalization_route": [
            {
                "step_id": "draft_lean_statement",
                "status": "ready",
                "output": "statement interface exists and was consumed by this attempt",
            },
            {
                "step_id": "target_theorem_name_attempt",
                "status": "rejected_assumption_echo" if statement_echo_rejected else "attention",
                "output": "target theorem compiles only by assuming the statement proof itself",
            },
            {
                "step_id": "construct_source_backed_statement_proof",
                "status": "blocked_on_proof_source" if statement_echo_rejected else "attention",
                "output": "Lean proof of ProfileEquivalenceTransfersDirectScoreLimitStatement S from manuscript anchors/rate premises",
            },
            {
                "step_id": "rewire_bridge",
                "status": "pending" if statement_echo_rejected else "attention",
                "output": "waldDirectEulerDomainBridge consumes a non-echo transfer theorem after source-backed proof exists",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report": statement_report,
        "boundary": [
            "This command checks that the target theorem name can compile only when hSourceProof is assumed.",
            "Assuming ProfileEquivalenceTransfersDirectScoreLimitStatement S is statement-assumption echo, not a source-backed production proof.",
            "Lean exit zero plus zero placeholders is still not sufficient when the proof depends on hSourceProof.",
            "The next stage must construct or intake hSourceProof itself from source-backed Lean proof material outside logs/paperctl/_batches.",
            "It writes only local attempt artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Source Backed No Placeholder Lean Proof Attempt",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Target theorem attempt ready: {report.get('profile_equivalence_transfer_no_placeholder_target_theorem_attempt_ready')}",
        f"- Statement assumption echo rejected: {report.get('profile_equivalence_transfer_statement_assumption_echo_proof_rejected')}",
        f"- Source-backed proof required: {report.get('profile_equivalence_transfer_source_backed_proof_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Classifications", ""])
    for item in report.get("proof_attempt_classifications") or []:
        lines.append(
            f"- {item.get('lean_declaration_name')}: no_placeholder={item.get('no_placeholder_target_theorem_attempt_ready')} "
            f"statement_echo={item.get('compiles_only_with_statement_assumption')} rejected={item.get('statement_assumption_echo_proof_rejected')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
