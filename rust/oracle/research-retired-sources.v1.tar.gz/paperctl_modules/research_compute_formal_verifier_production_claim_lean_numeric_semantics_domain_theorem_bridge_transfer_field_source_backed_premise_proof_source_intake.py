"""Intake source-backed Lean proof sources for transfer-field premise terms."""

import hashlib
import os
import pathlib
import re

from paperctl_modules import report_ref_health

COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-source-intake"
PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-construction"
PREMISE_PROOF_WORK_ITEM_DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-work-item-dispatch"
PREMISE_PROOF_TERM_CONSTRUCTION_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

PREMISE_BUNDLE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_BUNDLE_READY_SOURCE_TERMS_REQUIRED"
PREMISE_CONSTRUCTION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_MACHINE_CHECKED_CLOSED"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_sources_required",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "source_root",
    "candidate_limit",
    "excluded_directory_names",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "premise_proof_source_intake_classifications",
    "candidate_lean_source_files",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "premise_proof_term_construction_validation_issue_count",
    "premise_proof_term_requirement_count",
    "local_lean_file_count",
    "candidate_lean_source_file_count",
    "premise_proof_source_candidate_count",
    "premise_proof_source_ready_count",
    "premise_proof_source_missing_count",
    "placeholder_candidate_count",
    "assumption_echo_candidate_count",
    "vacuous_true_candidate_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the premise proof-term construction report and inventories local Lean proof-source candidates for each premise.",
    "Generated report logs, Mathlib cache, dependency directories, placeholders, assumption echo, and vacuous : True theorem bodies are rejected as production premise proof sources.",
    "This command reads local files and writes reports only; it does not prove the transfer statement or target theorem.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
EXCLUDED_DIR_NAMES = {
    ".git",
    ".lake",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "logs",
    "node_modules",
}
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
NEXT_DECL_RE = re.compile(r"^\s*(theorem|lemma|def|structure|inductive|namespace|section|end)\b")
NAMESPACE_RE = re.compile(r"^\s*namespace\b")
SECTION_RE = re.compile(r"^\s*section\b")
END_RE = re.compile(r"^\s*end\b")
ASSUMPTION_ECHO_RE = re.compile(r"\b(exact\s+h|:=\s*h[A-Z_a-z0-9']*|by\s+assumption|assumption)\b")
VACUOUS_TRUE_RE = re.compile(r":\s*True\s*:=", re.M)
SOURCE_BACKED_STATEMENT_RE = re.compile(
    r"(ProfileEquivalence|profileEquivalence|SourceBacked|sourceBacked|Premise|premise|Proof|proof|"
    r"FastTransfer|fastTransfer|OperationalCertificate|operationalCertificate|directEuler|DirectEuler|"
    r"fixedDelta|FixedDelta|highFrequency|HighFrequency|Rate|rate|Negligible|negligible)"
)


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _normalize(value):
    return re.sub(r"[^a-z0-9]", "", str(value or "").lower())


def _premise_report_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_missing")
        return issues
    if report.get("command") != PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_state") or ""
    if state not in {PREMISE_BUNDLE_READY_STATE, PREMISE_CONSTRUCTION_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_state_not_consumable",
            state,
        )
    if not report.get("profile_equivalence_transfer_premise_assumption_echo_rejected") and not report.get("production_claim_machine_checked"):
        _issue(issues, "premise_assumption_echo_rejection_missing")
    if not report.get("profile_equivalence_transfer_source_backed_premise_proof_terms_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_backed_premise_proof_terms_requirement_missing")
    if not report.get("premise_proof_term_requirements") and not report.get("production_claim_machine_checked"):
        _issue(issues, "premise_proof_term_requirements_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_boundary:{key}")
    return issues


def _walk_lean_files(source_root, candidate_limit):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
        for filename in filenames:
            if len(files) >= int(candidate_limit or 0):
                return files
            path = pathlib.Path(dirpath) / filename
            if path.suffix == ".lean" and path.is_file():
                files.append(path)
    return files


def _extract_theorem_statements(lean_text):
    lines = str(lean_text or "").splitlines()
    statements = []
    scope_stack = []
    for index, line in enumerate(lines):
        match = THEOREM_RE.match(line)
        if match:
            end = len(lines)
            for later in range(index + 1, len(lines)):
                if NEXT_DECL_RE.match(lines[later]):
                    end = later
                    break
            block = "\n".join(lines[index:end])
            statement_text = block.split(":=", 1)[0]
            statement_text = re.sub(rf"^\s*{match.group(1)}\s+{re.escape(match.group(2))}\b", "", statement_text, count=1)
            statements.append(
                {
                    "name": match.group(2),
                    "statement_text": statement_text,
                    "normalized_name": _normalize(match.group(2)),
                    "normalized_statement_text": _normalize(statement_text),
                    "source_backed_statement_marker_count": len(SOURCE_BACKED_STATEMENT_RE.findall(statement_text)),
                    "top_level_namespace": not any(item == "namespace" for item in scope_stack),
                }
            )
        if NAMESPACE_RE.match(line):
            scope_stack.append("namespace")
        elif SECTION_RE.match(line):
            scope_stack.append("section")
        elif END_RE.match(line) and scope_stack:
            scope_stack.pop()
    return statements


def _scan_lean_sources(source_root, candidate_limit):
    candidates = []
    for path in _walk_lean_files(source_root, candidate_limit):
        text = path.read_text(errors="replace")
        lean_text = _strip_lean_comments(text)
        theorem_statements = _extract_theorem_statements(lean_text)
        theorem_names = [item.get("name") for item in theorem_statements]
        candidates.append(
            {
                "path": str(path),
                "text_sha256": _sha256_text(text),
                "theorem_or_lemma_count": len(theorem_names),
                "theorem_or_lemma_names": theorem_names[:20],
                "source_backed_statement_marker_count": sum(int(item.get("source_backed_statement_marker_count") or 0) for item in theorem_statements),
                "placeholder_token_count": len(PLACEHOLDER_RE.findall(lean_text)),
                "assumption_echo_marker_count": len(ASSUMPTION_ECHO_RE.findall(lean_text)),
                "vacuous_true_marker_count": len(VACUOUS_TRUE_RE.findall(lean_text)),
                "_normalized_text": _normalize(lean_text),
                "_theorem_statements": theorem_statements,
            }
        )
    return candidates


def _requirement_terms(requirement):
    terms = []
    for key in ["lean_premise_name", "subgoal_id"]:
        value = str(requirement.get(key) or "").strip()
        if value:
            terms.append(value)
    terms.extend(str(label or "").strip() for label in requirement.get("source_labels") or [])
    return [term for index, term in enumerate(terms) if term and term not in terms[:index]]


def _classify_requirement(requirement, lean_candidates):
    terms = _requirement_terms(requirement)
    normalized_terms = [_normalize(term) for term in terms if _normalize(term)]
    matching = []
    for candidate in lean_candidates:
        text = candidate.get("_normalized_text") or ""
        matched_theorem_statement_count = 0
        for statement in candidate.get("_theorem_statements") or []:
            normalized_name = statement.get("normalized_name") or ""
            statement_marker_count = int(statement.get("source_backed_statement_marker_count") or 0)
            if not statement_marker_count:
                continue
            if not statement.get("top_level_namespace"):
                continue
            if any(
                normalized and (normalized in normalized_name or normalized_name in normalized)
                for normalized in normalized_terms
            ):
                matched_theorem_statement_count += 1
        matched_terms = [
            term
            for term, normalized in zip(terms, normalized_terms)
            if normalized and normalized in text
        ]
        if not matched_terms:
            continue
        ready = bool(
            candidate.get("theorem_or_lemma_count")
            and matched_theorem_statement_count
            and not candidate.get("placeholder_token_count")
            and not candidate.get("assumption_echo_marker_count")
            and not candidate.get("vacuous_true_marker_count")
        )
        matching.append(
            {
                "path": candidate.get("path") or "",
                "text_sha256": candidate.get("text_sha256") or "",
                "theorem_or_lemma_count": candidate.get("theorem_or_lemma_count", 0),
                "theorem_or_lemma_names": candidate.get("theorem_or_lemma_names") or [],
                "matched_terms": matched_terms[:10],
                "matched_theorem_statement_count": matched_theorem_statement_count,
                "source_backed_statement_marker_count": candidate.get("source_backed_statement_marker_count", 0),
                "placeholder_token_count": candidate.get("placeholder_token_count", 0),
                "assumption_echo_marker_count": candidate.get("assumption_echo_marker_count", 0),
                "vacuous_true_marker_count": candidate.get("vacuous_true_marker_count", 0),
                "ready": ready,
            }
        )
    ready_matches = [item for item in matching if item.get("ready")]
    return {
        "subgoal_id": requirement.get("subgoal_id") or "",
        "lean_premise_name": requirement.get("lean_premise_name") or "",
        "source_labels": list(requirement.get("source_labels") or []),
        "source_anchors_ready": bool(requirement.get("source_anchors_ready")),
        "proof_term_required": True,
        "proof_source_candidate_count": len(matching),
        "proof_source_ready_count": len(ready_matches),
        "proof_term_ready": bool(ready_matches),
        "blocking": not bool(ready_matches),
        "blocking_reason": "" if ready_matches else "no source-tree Lean proof term without placeholder, vacuous True, or assumption echo was found",
        "candidate_sources": matching[:10],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report,
    source_root=".",
    candidate_limit=500,
    label=None,
):
    premise_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    premise_ref_issues, premise_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction",
        premise_report,
        expected_command=PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND,
        max_age_min=PREMISE_PROOF_TERM_CONSTRUCTION_MAX_AGE_MIN,
    )
    validation_issues = premise_ref_issues + _premise_report_issues(premise_report)
    machine_checked = bool(premise_report.get("production_claim_machine_checked"))
    lean_candidates = _scan_lean_sources(source_root_path, candidate_limit)
    public_candidates = [{k: v for k, v in item.items() if not k.startswith("_")} for item in lean_candidates]
    requirements = list(premise_report.get("premise_proof_term_requirements") or [])
    classifications = [_classify_requirement(item, lean_candidates) for item in requirements]
    ready_count = sum(1 for item in classifications if item.get("proof_term_ready"))
    candidate_count = sum(int(item.get("proof_source_candidate_count") or 0) for item in classifications)
    placeholder_count = sum(int(item.get("placeholder_token_count") or 0) for candidate in public_candidates for item in [candidate])
    assumption_echo_count = sum(int(item.get("assumption_echo_marker_count") or 0) for item in public_candidates)
    vacuous_true_count = sum(int(item.get("vacuous_true_marker_count") or 0) for item in public_candidates)
    all_ready = bool(classifications and ready_count == len(classifications))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_consumable", not validation_issues, "premise_proof_term_construction_report_not_consumable"),
        _check("premise_requirements_present", bool(requirements), "premise_requirements_missing"),
        _check("generated_logs_excluded", True, ""),
        _check("source_tree_scan_performed", True, ""),
        _check("source_backed_premise_terms_ready", all_ready or machine_checked, "source_backed_premise_terms_missing", severity="readiness"),
        _check("no_source_mutation", not premise_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not premise_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif all_ready:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition"
        next_agent_command = ""
    else:
        status = "PASS"
        state = SOURCE_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch"
        next_agent_command = PREMISE_PROOF_WORK_ITEM_DISPATCH_COMMAND
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_source_backed_premise_proof_sources_required": bool(status == "PASS" and not all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "production_claim_machine_checked": production_checked,
        "claim_packet_id": premise_report.get("claim_packet_id") or "",
        "slug": premise_report.get("slug") or "",
        "source_root": str(source_root_path),
        "candidate_limit": int(candidate_limit or 0),
        "excluded_directory_names": sorted(EXCLUDED_DIR_NAMES),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_path": premise_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report_sha256": premise_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_ref_health": premise_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "premise_proof_term_construction_validation_issue_count": len(premise_ref_issues),
            "premise_proof_term_requirement_count": len(requirements),
            "local_lean_file_count": len(public_candidates),
            "candidate_lean_source_file_count": len([item for item in public_candidates if item.get("theorem_or_lemma_count")]),
            "premise_proof_source_candidate_count": candidate_count,
            "premise_proof_source_ready_count": ready_count,
            "premise_proof_source_missing_count": max(len(classifications) - ready_count, 0),
            "placeholder_candidate_count": placeholder_count,
            "assumption_echo_candidate_count": assumption_echo_count,
            "vacuous_true_candidate_count": vacuous_true_count,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "premise_proof_source_intake_classifications": classifications,
        "candidate_lean_source_files": public_candidates,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_report": premise_report,
        "boundary": [
            "This command scans only local source-tree Lean files and excludes logs/paperctl/_batches, .lake, and dependency/cache directories.",
            "A source anchor, generated Lean draft, placeholder declaration, vacuous : True theorem body, or assumption-echo proof is not a production premise proof term.",
            "It does not prove ProfileEquivalenceTransfersDirectScoreLimitStatement or profileEquivalenceTransfersDirectScoreLimit.",
            "It writes only local reports and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source-Backed Premise Proof Source Intake",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_state') or ''}",
        f"- Premise requirements: {summary.get('premise_proof_term_requirement_count', 0)}",
        f"- Ready premise sources: {summary.get('premise_proof_source_ready_count', 0)}",
        f"- Missing premise sources: {summary.get('premise_proof_source_missing_count', 0)}",
        f"- Candidate Lean files: {summary.get('candidate_lean_source_file_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
