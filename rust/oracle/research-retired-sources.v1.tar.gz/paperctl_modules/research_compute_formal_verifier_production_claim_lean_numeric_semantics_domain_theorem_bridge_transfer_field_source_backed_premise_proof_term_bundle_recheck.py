"""Recheck source-backed premise proof-term bundle readiness."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-bundle-recheck"
SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-reintake"
PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-construction"

SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_READY_SOURCE_PROOF_BODY_SOURCES_REQUIRED"
SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_MACHINE_CHECKED_CLOSED"

BUNDLE_RECHECK_BLOCKED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_BUNDLE_RECHECK_BLOCKED_SOURCE_PROOF_BODY_SOURCES_REQUIRED"
BUNDLE_RECHECK_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_BUNDLE_RECHECK_READY_FOR_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_BUNDLE_RECHECK_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_BUNDLE_RECHECK_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_BUNDLE_RECHECK_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "bundle_recheck_items",
    "bundle_recheck_requirements",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_body_source_authoring_item_count",
    "bundle_recheck_item_count",
    "required_source_tree_proof_body_source_count",
    "ready_source_tree_proof_body_source_item_count",
    "ready_source_tree_proof_body_source_count",
    "missing_source_tree_proof_body_source_count",
    "blocking_source_tree_proof_body_source_count",
    "authoring_ready_count",
    "authoring_blocking_count",
    "vacuous_true_body_candidate_count",
    "non_domain_statement_body_candidate_count",
    "domain_statement_body_candidate_count",
    "statement_contract_body_candidate_count",
    "statement_contract_mismatch_body_candidate_count",
    "source_tree_lean_check_performed_body_candidate_count",
    "source_tree_lean_check_pass_body_candidate_count",
    "source_tree_lean_check_fail_body_candidate_count",
    "source_tree_lean_check_timeout_body_candidate_count",
    "source_authorization_preflight_ready_body_candidate_count",
    "source_authorization_preflight_missing_body_candidate_count",
    "source_authorization_preflight_mismatch_body_candidate_count",
    "source_authoring_artifact_preflight_ready_body_candidate_count",
    "source_authoring_artifact_preflight_missing_body_candidate_count",
    "source_authoring_artifact_preflight_mismatch_body_candidate_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes proof-body-source authoring/reintake and records whether the premise proof-term bundle may be rechecked.",
    "The bundle recheck is blocked until every expected sourceBacked theorem has a source-tree no-placeholder nonvacuous proof body bound to its statement contract.",
    "The command does not compose the target proof and never promotes bundle_recheck to source-backed proof source readiness without machine-checked closure.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _authoring_reintake_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_missing")
        return issues
    if report.get("command") != SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_state") or ""
    if state not in {SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_READY_STATE, SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_body_source_authoring_reintake_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_source_authoring_reintake_items_missing")
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_source_ready_premature")
    if report.get("profile_equivalence_transfer_target_theorem_proved") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_target_theorem_proved_without_machine_check")
    if not report.get("production_claim_machine_checked"):
        for item in report.get("source_theorem_proof_body_source_authoring_reintake_items") or []:
            ready_count = int(item.get("source_tree_proof_body_source_ready_count") or 0)
            if item.get("authoring_ready"):
                ready_count = max(ready_count, 1)
            if ready_count and int(item.get("source_tree_lean_check_pass_body_candidate_count") or 0) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_authoring_item_without_lean_check_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
            if ready_count and int(item.get("source_authorization_preflight_ready_body_candidate_count") or 0) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_authoring_item_without_authorization_preflight_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
            if ready_count and int(item.get("source_authoring_artifact_preflight_ready_body_candidate_count") or 0) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_authoring_item_without_authoring_artifact_preflight_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_boundary:{key}")
    return issues


def _bundle_recheck_item(item, index):
    ready_source_count = int(item.get("source_tree_proof_body_source_ready_count") or 0)
    authoring_ready = bool(item.get("authoring_ready") or ready_source_count)
    expected = item.get("expected_lean_proof_name") or f"sourceBackedPremiseTheorem{index}"
    return {
        "bundle_recheck_item_id": f"premise-proof-term-bundle-recheck-{index:02d}-{expected}",
        "expected_lean_proof_name": expected,
        "expected_statement_field_name": item.get("expected_statement_field_name") or "",
        "lean_premise_name": item.get("lean_premise_name") or "",
        "dispatch_group": item.get("dispatch_group") or "",
        "source_labels": list(item.get("source_labels") or []),
        "source_anchor_kinds": list(item.get("source_anchor_kinds") or []),
        "required_output_kind": "source_tree_no_placeholder_nonvacuous_contract_bound_lean_proof_body_source",
        "source_tree_proof_body_source_candidate_count": int(item.get("source_tree_proof_body_source_candidate_count") or 0),
        "source_tree_proof_body_source_ready_count": ready_source_count,
        "vacuous_true_body_candidate_count": int(item.get("vacuous_true_body_candidate_count") or 0),
        "non_domain_statement_body_candidate_count": int(item.get("non_domain_statement_body_candidate_count") or 0),
        "domain_statement_body_candidate_count": int(item.get("domain_statement_body_candidate_count") or 0),
        "statement_contract_body_candidate_count": int(item.get("statement_contract_body_candidate_count") or 0),
        "statement_contract_mismatch_body_candidate_count": int(item.get("statement_contract_mismatch_body_candidate_count") or 0),
        "source_tree_lean_check_performed_body_candidate_count": int(item.get("source_tree_lean_check_performed_body_candidate_count") or 0),
        "source_tree_lean_check_pass_body_candidate_count": int(item.get("source_tree_lean_check_pass_body_candidate_count") or 0),
        "source_tree_lean_check_fail_body_candidate_count": int(item.get("source_tree_lean_check_fail_body_candidate_count") or 0),
        "source_tree_lean_check_timeout_body_candidate_count": int(item.get("source_tree_lean_check_timeout_body_candidate_count") or 0),
        "source_authorization_preflight_ready_body_candidate_count": int(item.get("source_authorization_preflight_ready_body_candidate_count") or 0),
        "source_authorization_preflight_missing_body_candidate_count": int(item.get("source_authorization_preflight_missing_body_candidate_count") or 0),
        "source_authorization_preflight_mismatch_body_candidate_count": int(item.get("source_authorization_preflight_mismatch_body_candidate_count") or 0),
        "source_authoring_artifact_preflight_ready_body_candidate_count": int(item.get("source_authoring_artifact_preflight_ready_body_candidate_count") or 0),
        "source_authoring_artifact_preflight_missing_body_candidate_count": int(item.get("source_authoring_artifact_preflight_missing_body_candidate_count") or 0),
        "source_authoring_artifact_preflight_mismatch_body_candidate_count": int(item.get("source_authoring_artifact_preflight_mismatch_body_candidate_count") or 0),
        "vacuous_true_rejected_as_source_proof": bool(item.get("vacuous_true_rejected_as_source_proof")),
        "non_domain_statement_rejected_as_source_proof": bool(item.get("non_domain_statement_rejected_as_source_proof")),
        "statement_contract_mismatch_rejected_as_source_proof": bool(item.get("statement_contract_mismatch_rejected_as_source_proof")),
        "bundle_recheck_ready": authoring_ready,
        "bundle_recheck_blocking": not authoring_ready,
        "source_backed_proof_source_ready": False,
        "blocking_reason": "" if authoring_ready else (item.get("blocking_reason") or "source-tree proof body source is missing or not contract-bound"),
        "next_required_action": "" if authoring_ready else (item.get("next_required_action") or f"author and reintake source-tree proof body source for {expected}"),
        "must_not_use": list(item.get("must_not_use") or []),
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report,
    label=None,
):
    authoring_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report or {}
    validation_issues = _authoring_reintake_issues(authoring_report)
    machine_checked = bool(authoring_report.get("production_claim_machine_checked"))
    authoring_items = list(authoring_report.get("source_theorem_proof_body_source_authoring_reintake_items") or [])
    bundle_items = [_bundle_recheck_item(item, index + 1) for index, item in enumerate(authoring_items)]
    required_count = len(bundle_items)
    ready_item_count = sum(1 for item in bundle_items if item.get("bundle_recheck_ready"))
    ready_source_count = sum(int(item.get("source_tree_proof_body_source_ready_count") or 0) for item in bundle_items)
    missing_count = max(required_count - ready_item_count, 0)
    blocking_count = sum(1 for item in bundle_items if item.get("bundle_recheck_blocking"))
    summary_from_authoring = authoring_report.get("summary") or {}
    authoring_blocking_count = int(summary_from_authoring.get("authoring_blocking_count") if summary_from_authoring.get("authoring_blocking_count") is not None else blocking_count)
    authoring_ready_count = int(summary_from_authoring.get("authoring_ready_count") if summary_from_authoring.get("authoring_ready_count") is not None else ready_item_count)
    all_sources_ready = bool(required_count and ready_item_count == required_count and blocking_count == 0 and authoring_blocking_count == 0)
    if authoring_report.get("profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready") and not all_sources_ready and not machine_checked:
        _issue(validation_issues, "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_premature")
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_consumable", not _authoring_reintake_issues(authoring_report), "source_theorem_proof_body_source_authoring_reintake_report_not_consumable"),
        _check("bundle_recheck_items_present", bool(bundle_items), "bundle_recheck_items_missing"),
        _check("all_required_source_tree_proof_body_sources_ready", all_sources_ready or machine_checked, "source_tree_proof_body_sources_missing_or_not_contract_bound", severity="readiness"),
        _check("source_backed_proof_source_not_promoted_by_bundle_recheck", not authoring_report.get("profile_equivalence_transfer_source_backed_proof_source_ready") or machine_checked, "source_backed_proof_source_ready_premature"),
        _check("target_theorem_not_promoted_by_bundle_recheck", not authoring_report.get("profile_equivalence_transfer_target_theorem_proved") or machine_checked, "target_theorem_proved_without_machine_check"),
        _check("no_source_mutation", not authoring_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not authoring_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and not bundle_items:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif all_sources_ready:
        status = "PASS"
        state = BUNDLE_RECHECK_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction"
        next_agent_command = PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND
    elif bundle_items:
        status = "PASS"
        state = BUNDLE_RECHECK_BLOCKED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake"
        next_agent_command = SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    source_body_sources_ready = bool(status == "PASS" and all_sources_ready and not production_checked)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": source_body_sources_ready,
        "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready": source_body_sources_ready,
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": source_body_sources_ready,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": bool(production_checked),
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "claim_packet_id": authoring_report.get("claim_packet_id") or "",
        "slug": authoring_report.get("slug") or "",
        "source_root": authoring_report.get("source_root") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_path": authoring_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report_sha256": authoring_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_body_source_authoring_item_count": len(authoring_items),
            "bundle_recheck_item_count": len(bundle_items),
            "required_source_tree_proof_body_source_count": required_count,
            "ready_source_tree_proof_body_source_item_count": ready_item_count,
            "ready_source_tree_proof_body_source_count": ready_source_count,
            "missing_source_tree_proof_body_source_count": missing_count,
            "blocking_source_tree_proof_body_source_count": blocking_count,
            "authoring_ready_count": authoring_ready_count,
            "authoring_blocking_count": authoring_blocking_count,
            "vacuous_true_body_candidate_count": sum(int(item.get("vacuous_true_body_candidate_count") or 0) for item in bundle_items),
            "non_domain_statement_body_candidate_count": sum(int(item.get("non_domain_statement_body_candidate_count") or 0) for item in bundle_items),
            "domain_statement_body_candidate_count": sum(int(item.get("domain_statement_body_candidate_count") or 0) for item in bundle_items),
            "statement_contract_body_candidate_count": sum(int(item.get("statement_contract_body_candidate_count") or 0) for item in bundle_items),
            "statement_contract_mismatch_body_candidate_count": sum(int(item.get("statement_contract_mismatch_body_candidate_count") or 0) for item in bundle_items),
            "source_tree_lean_check_performed_body_candidate_count": sum(int(item.get("source_tree_lean_check_performed_body_candidate_count") or 0) for item in bundle_items),
            "source_tree_lean_check_pass_body_candidate_count": sum(int(item.get("source_tree_lean_check_pass_body_candidate_count") or 0) for item in bundle_items),
            "source_tree_lean_check_fail_body_candidate_count": sum(int(item.get("source_tree_lean_check_fail_body_candidate_count") or 0) for item in bundle_items),
            "source_tree_lean_check_timeout_body_candidate_count": sum(int(item.get("source_tree_lean_check_timeout_body_candidate_count") or 0) for item in bundle_items),
            "source_authorization_preflight_ready_body_candidate_count": sum(int(item.get("source_authorization_preflight_ready_body_candidate_count") or 0) for item in bundle_items),
            "source_authorization_preflight_missing_body_candidate_count": sum(int(item.get("source_authorization_preflight_missing_body_candidate_count") or 0) for item in bundle_items),
            "source_authorization_preflight_mismatch_body_candidate_count": sum(int(item.get("source_authorization_preflight_mismatch_body_candidate_count") or 0) for item in bundle_items),
            "source_authoring_artifact_preflight_ready_body_candidate_count": sum(int(item.get("source_authoring_artifact_preflight_ready_body_candidate_count") or 0) for item in bundle_items),
            "source_authoring_artifact_preflight_missing_body_candidate_count": sum(int(item.get("source_authoring_artifact_preflight_missing_body_candidate_count") or 0) for item in bundle_items),
            "source_authoring_artifact_preflight_mismatch_body_candidate_count": sum(int(item.get("source_authoring_artifact_preflight_mismatch_body_candidate_count") or 0) for item in bundle_items),
            "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count": 1 if source_body_sources_ready else 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 1 if production_checked else 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "bundle_recheck_items": bundle_items,
        "bundle_recheck_requirements": [
            "Every expected sourceBacked premise theorem must have at least one source-tree proof body source.",
            "Each proof body source must be nonvacuous, no-placeholder, domain-looking, and bound to the expected statement contract.",
            "bundle_recheck readiness does not prove or promote ProfileEquivalenceTransfersDirectScoreLimitStatement.",
            "source_backed_proof_source_ready remains false until machine-checked closure.",
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_report": authoring_report,
        "boundary": [
            "This command rechecks readiness only; it is not a proof composition command.",
            "A bundle_recheck PASS with blocked state means source proof body sources are still missing and must not be interpreted as source-backed proof source readiness.",
            "Vacuous : True bodies, non-domain statements, statement-contract mismatches, generated logs, work items, implementation plans, skeleton bodies, placeholders, field forwarding, and assumption echo remain rejected as proof sources.",
            "It writes only local reports and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Proof-Term Bundle Recheck",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck_state') or ''}",
        f"- Required proof body sources: {summary.get('required_source_tree_proof_body_source_count', 0)}",
        f"- Ready proof body sources: {summary.get('ready_source_tree_proof_body_source_item_count', 0)}",
        f"- Missing proof body sources: {summary.get('missing_source_tree_proof_body_source_count', 0)}",
        f"- Statement-contract mismatches: {summary.get('statement_contract_mismatch_body_candidate_count', 0)}",
        f"- Source-backed proof source ready: {report.get('profile_equivalence_transfer_source_backed_proof_source_ready')}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
