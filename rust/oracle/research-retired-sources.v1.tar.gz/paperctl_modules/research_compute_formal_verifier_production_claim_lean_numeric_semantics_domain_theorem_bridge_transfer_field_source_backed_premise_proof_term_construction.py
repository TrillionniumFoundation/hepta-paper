"""Construct a premise-proof bundle draft while rejecting premise-assumption echo."""

import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health

COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-construction"
SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-proof-source-construction"
SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-source-intake"
SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_OBSTRUCTION_RECORDED"
SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_MACHINE_CHECKED_CLOSED"

PREMISE_BUNDLE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_BUNDLE_READY_SOURCE_TERMS_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_ready",
    "profile_equivalence_transfer_premise_bundle_composition_ready",
    "profile_equivalence_transfer_premise_assumption_echo_rejected",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_required",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "field_forwarding_allowed_as_production_proof",
    "generated_log_provenance_allowed",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "premise_proof_term_requirements",
    "premise_bundle_composition",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_construction_validation_issue_count",
    "premise_proof_term_requirement_count",
    "premise_proof_term_source_anchor_ready_count",
    "premise_proof_term_ready_count",
    "premise_proof_term_blocking_count",
    "lean_structure_count",
    "lean_def_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "target_theorem_declaration_count",
    "premise_assumption_echo_marker_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_premise_bundle_composition_ready_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_required_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the proof-source construction obstruction and checks a Lean theorem that bundles premise proofs when they are already supplied.",
    "Premise proof arguments are explicitly classified as premise-assumption echo and are not source-backed production proof terms.",
    "The final transfer statement and target theorem remain unproved until the premise proof terms are constructed from source-backed Lean material.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
DEF_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
PREMISE_ASSUMPTION_ECHO_RE = re.compile(r"\bh(ProfileEquivalence|Fast|Operational|Fixed|Drift|Diffusion|Euler)")
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
PREMISE_BUNDLE_THEOREM_NAME = "profileEquivalenceTransferPremiseProofTermBundleDraft"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _construction_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_missing")
        return issues
    if report.get("command") != SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_state") or ""
    if state not in {SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE, SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_state_not_consumable", state)
    if not report.get("profile_equivalence_transfer_proof_construction_obstruction_recorded") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_proof_construction_obstruction_missing")
    if not report.get("profile_equivalence_transfer_source_backed_proof_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_required_missing")
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_source_ready_premature")
    if report.get("profile_equivalence_transfer_target_theorem_proved") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_target_theorem_proved_without_machine_check")
    if report.get("field_forwarding_allowed_as_production_proof"):
        _issue(issues, "field_forwarding_allowed_as_production_proof")
    if report.get("generated_log_provenance_allowed"):
        _issue(issues, "generated_log_provenance_allowed")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_boundary:{key}")
    return issues


def _premise_requirements(report):
    requirements = []
    for item in report.get("proof_construction_subgoals") or []:
        requirements.append(
            {
                "subgoal_id": item.get("subgoal_id") or "",
                "lean_premise_name": item.get("lean_premise_name") or "",
                "source_labels": list(item.get("source_labels") or []),
                "source_anchors_ready": bool(item.get("source_anchors_ready")),
                "proof_term_required": bool(item.get("proof_term_required", True)),
                "proof_term_ready": False,
                "blocking": True,
                "blocking_reason": item.get("blocking_reason") or "source-backed proof term has not been constructed",
                "premise_assumption_echo_allowed": False,
                "generated_log_provenance_allowed": False,
                "field_forwarding_allowed_as_production_proof": False,
            }
        )
    return requirements


def _lean_source():
    return """import Mathlib

open Filter Asymptotics

/-
paper_factory source-backed profile-equivalence premise proof-term bundle draft.
This file checks only the bundle composition from already supplied premise proofs.
Those premise proof arguments are classified outside Lean as assumption echo.
It does not declare or prove profileEquivalenceTransfersDirectScoreLimit.
-/

namespace NSMAoSFormalization

noncomputable section

def RateSeq := Nat -> Real

def LittleOAtTop (f g : RateSeq) : Prop :=
  Asymptotics.IsLittleO atTop f g

structure ProfileEquivalenceTransferRatePremises where
  fixedDeltaRateNegligible : Prop
  highFrequencyDriftRateNegligible : Prop
  highFrequencyDiffusionRateNegligible : Prop
  fastTransferCertificate : Prop
  operationalCertificate : Prop

structure DirectEulerLimitInput where
  directEulerLimit : Prop
  waldValidForDirectEuler : Prop

structure ProfileEquivalenceSourceAnchors where
  profileEquivalenceTheoremAnchor : Prop
  profileEquivalenceProofAnchor : Prop
  fastTransferAnchor : Prop
  operationalCertificateAnchor : Prop
  highFrequencyScheduleAnchor : Prop
  directHfInputAnchor : Prop

structure ProfileEquivalenceTransferLeanStatement where
  ratePremises : ProfileEquivalenceTransferRatePremises
  directEulerInput : DirectEulerLimitInput
  sourceAnchors : ProfileEquivalenceSourceAnchors
  profiledEstimatorWaldValid : Prop

structure ProfileEquivalenceTransferPremiseProofTerms
    (S : ProfileEquivalenceTransferLeanStatement) where
  profileEquivalenceTheoremAnchor : S.sourceAnchors.profileEquivalenceTheoremAnchor
  profileEquivalenceProofAnchor : S.sourceAnchors.profileEquivalenceProofAnchor
  fastTransferAnchor : S.sourceAnchors.fastTransferAnchor
  operationalCertificateAnchor : S.sourceAnchors.operationalCertificateAnchor
  fixedDeltaRateNegligible : S.ratePremises.fixedDeltaRateNegligible
  highFrequencyDriftRateNegligible : S.ratePremises.highFrequencyDriftRateNegligible
  highFrequencyDiffusionRateNegligible : S.ratePremises.highFrequencyDiffusionRateNegligible
  fastTransferCertificate : S.ratePremises.fastTransferCertificate
  operationalCertificate : S.ratePremises.operationalCertificate
  directEulerLimit : S.directEulerInput.directEulerLimit

theorem profileEquivalenceTransferPremiseProofTermBundleDraft
    (S : ProfileEquivalenceTransferLeanStatement)
    (hProfileEquivalenceTheoremAnchor : S.sourceAnchors.profileEquivalenceTheoremAnchor)
    (hProfileEquivalenceProofAnchor : S.sourceAnchors.profileEquivalenceProofAnchor)
    (hFastTransferAnchor : S.sourceAnchors.fastTransferAnchor)
    (hOperationalCertificateAnchor : S.sourceAnchors.operationalCertificateAnchor)
    (hFixedDeltaRateNegligible : S.ratePremises.fixedDeltaRateNegligible)
    (hDriftRateNegligible : S.ratePremises.highFrequencyDriftRateNegligible)
    (hDiffusionRateNegligible : S.ratePremises.highFrequencyDiffusionRateNegligible)
    (hFastTransferCertificate : S.ratePremises.fastTransferCertificate)
    (hOperationalCertificate : S.ratePremises.operationalCertificate)
    (hEulerLimit : S.directEulerInput.directEulerLimit) :
    ProfileEquivalenceTransferPremiseProofTerms S :=
  {
    profileEquivalenceTheoremAnchor := hProfileEquivalenceTheoremAnchor
    profileEquivalenceProofAnchor := hProfileEquivalenceProofAnchor
    fastTransferAnchor := hFastTransferAnchor
    operationalCertificateAnchor := hOperationalCertificateAnchor
    fixedDeltaRateNegligible := hFixedDeltaRateNegligible
    highFrequencyDriftRateNegligible := hDriftRateNegligible
    highFrequencyDiffusionRateNegligible := hDiffusionRateNegligible
    fastTransferCertificate := hFastTransferCertificate
    operationalCertificate := hOperationalCertificate
    directEulerLimit := hEulerLimit
  }

end

end NSMAoSFormalization
"""


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction(
    domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    construction_report = domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report or {}
    construction_ref_issues, construction_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction",
        construction_report,
        expected_command=SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_COMMAND,
        max_age_min=SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_MAX_AGE_MIN,
    )
    validation_issues = construction_ref_issues + _construction_issues(construction_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    source_root_path = pathlib.Path(source_root or ".").resolve()
    machine_checked = bool(
        construction_report.get("production_claim_machine_checked")
        and construction_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_state") == SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_CLOSED_STATE
    )
    requirements = _premise_requirements(construction_report)
    lean_source_text = _lean_source()
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-construction.lean", lean_source_text)
    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_info["path"])
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command:
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    defs = DEF_RE.findall(lean_source_text)
    theorem_names = THEOREM_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    premise_assumption_echo_markers = PREMISE_ASSUMPTION_ECHO_RE.findall(lean_source_text)
    target_theorem_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    proof_term_ready_count = sum(1 for item in requirements if item.get("proof_term_ready"))
    blocking_count = sum(1 for item in requirements if item.get("blocking"))
    premise_bundle_ready = bool(
        lean_exit_zero
        and PREMISE_BUNDLE_THEOREM_NAME in theorem_names
        and "ProfileEquivalenceTransferPremiseProofTerms" in structures
        and not placeholders
        and not target_theorem_declarations
        and premise_assumption_echo_markers
        and requirements
    )
    source_backed_terms_required = bool(construction_report.get("profile_equivalence_transfer_source_backed_proof_required") and not machine_checked)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_consumable", not validation_issues, "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_not_consumable"),
        _check("premise_requirements_present", bool(requirements), "premise_requirements_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("premise_bundle_structure_present", "ProfileEquivalenceTransferPremiseProofTerms" in structures, "premise_bundle_structure_missing"),
        _check("premise_bundle_theorem_present", PREMISE_BUNDLE_THEOREM_NAME in theorem_names, "premise_bundle_theorem_missing"),
        _check("target_theorem_not_declared", not target_theorem_declarations, "target_theorem_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("premise_assumption_echo_detected", bool(premise_assumption_echo_markers) or machine_checked, "premise_assumption_echo_missing", severity="readiness"),
        _check("premise_assumption_echo_rejected_as_production", bool(premise_assumption_echo_markers) or machine_checked, "premise_assumption_echo_not_classified", severity="readiness"),
        _check("source_backed_premise_terms_still_required", source_backed_terms_required or machine_checked, "source_backed_premise_terms_requirement_missing", severity="readiness"),
        _check("generated_log_provenance_rejected", True, ""),
        _check("no_source_mutation", not construction_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not construction_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif premise_bundle_ready and source_backed_terms_required:
        status = "PASS"
        state = PREMISE_BUNDLE_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake"
        next_agent_command = SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    premise_echo_rejected = bool(status == "PASS" and premise_assumption_echo_markers and not production_checked)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_bundle_composition_ready": bool(status == "PASS" and premise_bundle_ready),
        "profile_equivalence_transfer_premise_assumption_echo_rejected": premise_echo_rejected,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_required": bool(status == "PASS" and source_backed_terms_required and not production_checked),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "field_forwarding_allowed_as_production_proof": False,
        "generated_log_provenance_allowed": False,
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": construction_report.get("claim_packet_id") or "",
        "slug": construction_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_path": construction_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report_sha256": construction_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_ref_health": construction_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_construction_validation_issue_count": len(construction_ref_issues),
            "premise_proof_term_requirement_count": len(requirements),
            "premise_proof_term_source_anchor_ready_count": sum(1 for item in requirements if item.get("source_anchors_ready")),
            "premise_proof_term_ready_count": proof_term_ready_count,
            "premise_proof_term_blocking_count": blocking_count,
            "lean_structure_count": len(structures),
            "lean_def_count": len(defs),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "target_theorem_declaration_count": len(target_theorem_declarations),
            "premise_assumption_echo_marker_count": len(premise_assumption_echo_markers),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_premise_bundle_composition_ready_count": 1 if status == "PASS" and premise_bundle_ready else 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_required_count": 1 if source_backed_terms_required and not production_checked else 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": lake_env_used,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "def_names": defs,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "target_theorem_declaration_count": len(target_theorem_declarations),
            "premise_assumption_echo_marker_count": len(premise_assumption_echo_markers),
        },
        "premise_proof_term_requirements": requirements,
        "premise_bundle_composition": {
            "lean_declaration_name": PREMISE_BUNDLE_THEOREM_NAME,
            "bundle_structure_name": "ProfileEquivalenceTransferPremiseProofTerms",
            "composition_ready": bool(status == "PASS" and premise_bundle_ready),
            "premise_assumption_echo_rejected": premise_echo_rejected,
            "source_backed_premise_proof_terms_ready": False,
            "proves_profile_equivalence_transfer_statement": False,
            "proves_target_theorem": False,
            "next_required_action": "replace_premise_assumptions_with_source_backed_lean_proof_terms",
        },
        "formalization_route": [
            {
                "step_id": "bundle_premise_proofs",
                "status": "ready" if premise_bundle_ready else "attention",
                "output": "Lean checks a bundle constructor from ten supplied premise proofs",
            },
            {
                "step_id": "reject_premise_assumption_echo",
                "status": "ready" if premise_echo_rejected else "attention",
                "output": "premise arguments remain assumptions, not source-backed proof terms",
            },
            {
                "step_id": "source_backed_premise_proof_source_intake",
                "status": "blocked_on_proof_source" if premise_echo_rejected else "attention",
                "output": "find or construct Lean proof terms for each premise outside generated logs",
            },
            {
                "step_id": "compose_hSourceProof",
                "status": "pending" if premise_echo_rejected else "attention",
                "output": "use source-backed premise terms plus transfer implication proof to build hSourceProof",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_report": construction_report,
        "boundary": [
            "This command checks only that already supplied premise proof arguments can be bundled in Lean.",
            "The premise proof arguments are assumption echo and are rejected as production proof source.",
            "It does not prove ProfileEquivalenceTransfersDirectScoreLimitStatement or profileEquivalenceTransfersDirectScoreLimit.",
            "The next stage must construct source-backed Lean proof terms for the premise fields outside logs/paperctl/_batches.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Source Backed Premise Proof Term Construction",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Premise bundle ready: {report.get('profile_equivalence_transfer_premise_bundle_composition_ready')}",
        f"- Premise assumption echo rejected: {report.get('profile_equivalence_transfer_premise_assumption_echo_rejected')}",
        f"- Source-backed premise terms ready: {report.get('profile_equivalence_transfer_source_backed_premise_proof_terms_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Premise Requirements", ""])
    for item in report.get("premise_proof_term_requirements") or []:
        lines.append(
            f"- {item.get('subgoal_id')}: premise={item.get('lean_premise_name')} "
            f"anchors_ready={item.get('source_anchors_ready')} proof_ready={item.get('proof_term_ready')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
