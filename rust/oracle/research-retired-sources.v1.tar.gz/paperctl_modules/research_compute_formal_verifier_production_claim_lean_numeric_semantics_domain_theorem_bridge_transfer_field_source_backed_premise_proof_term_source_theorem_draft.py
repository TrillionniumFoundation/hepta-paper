"""Draft Lean theorem statements for source-backed transfer-field premise terms."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-draft"
SOURCE_CONSTRUCTION_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-construction-attempt"
SOURCE_THEOREM_PROOF_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-source-intake"

SOURCE_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_CONSTRUCTION_ATTEMPT_OBSTRUCTION_RECORDED"
SOURCE_CONSTRUCTION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_CONSTRUCTION_ATTEMPT_MACHINE_CHECKED_CLOSED"

SOURCE_THEOREM_DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_DRAFT_READY_SOURCE_PROOFS_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft_ready",
    "profile_equivalence_transfer_premise_source_theorem_draft_ready",
    "profile_equivalence_transfer_premise_source_theorem_assumption_echo_rejected",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_required",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_theorem_drafts",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_draft_count",
    "source_theorem_declaration_count",
    "expected_source_theorem_declaration_count",
    "expected_source_theorem_missing_count",
    "assumption_echo_marker_count",
    "target_theorem_declaration_count",
    "lean_structure_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_required_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the source-construction obstruction and checks Lean theorem-name/statement drafts for the expected source-backed premise proof terms.",
    "The theorem draft bodies deliberately forward a theorem-specific assumption and are rejected as production proof.",
    "Generated report logs and assumption echo must not be promoted to source-backed premise proof terms.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
ASSUMPTION_ECHO_RE = re.compile(r"\bexact\s+h[A-Z][A-Za-z0-9_']*")
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _source_construction_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_missing")
        return issues
    if report.get("command") != SOURCE_CONSTRUCTION_ATTEMPT_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_state") or ""
    if state not in {SOURCE_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE, SOURCE_CONSTRUCTION_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_state_not_consumable",
            state,
        )
    if not report.get("premise_proof_term_source_construction_attempts") and not report.get("production_claim_machine_checked"):
        _issue(issues, "premise_proof_term_source_construction_attempts_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_boundary:{key}")
    return issues


def _field_name(premise_name):
    text = re.sub(r"[^A-Za-z0-9_]", "", str(premise_name or "premiseProofTerm"))
    if not text:
        text = "premiseProofTerm"
    return f"{text[:1].lower()}{text[1:]}Statement"


def _source_theorem_drafts(attempts):
    drafts = []
    for item in attempts:
        expected = item.get("expected_lean_proof_name") or ""
        premise = item.get("lean_premise_name") or expected or item.get("work_item_id") or ""
        if not expected:
            continue
        drafts.append(
            {
                "lean_premise_name": premise,
                "expected_lean_proof_name": expected,
                "statement_field_name": _field_name(premise),
                "dispatch_group": item.get("dispatch_group") or "",
                "source_labels": list(item.get("source_labels") or []),
                "source_anchors_ready": bool(item.get("source_anchors_ready")),
                "source_theorem_declared": True,
                "proof_body_kind": "assumption_echo_statement_draft",
                "assumption_echo_rejected_as_production": True,
                "production_proof_ready": False,
                "next_required_action": f"replace the assumption-echo body of {expected} with a source-tree proof term",
            }
        )
    return drafts


def _lean_source(drafts):
    fields = []
    theorems = []
    for item in drafts:
        field = item["statement_field_name"]
        theorem_name = item["expected_lean_proof_name"]
        hyp_name = f"h{theorem_name[:1].upper()}{theorem_name[1:]}"
        fields.append(f"  {field} : Prop")
        theorems.append(
            f"""theorem {theorem_name}
    (S : ProfileEquivalencePremiseProofTermSourceTheoremStatements)
    ({hyp_name} : S.{field}) :
    S.{field} := by
  exact {hyp_name}
"""
        )
    if not fields:
        fields.append("  noSourceTheoremDraft : Prop")
        theorems.append(
            """theorem noSourceBackedPremiseProofTermSourceTheoremDraft
    (S : ProfileEquivalencePremiseProofTermSourceTheoremStatements)
    (hNoSourceTheoremDraft : S.noSourceTheoremDraft) :
    S.noSourceTheoremDraft := by
  exact hNoSourceTheoremDraft
"""
        )
    return """import Mathlib

namespace NSMAoSFormalization

noncomputable section

structure ProfileEquivalencePremiseProofTermSourceTheoremStatements where
{fields}

{theorems}
end

end NSMAoSFormalization
""".format(fields="\n".join(fields), theorems="\n".join(theorems))


def _run_lean(source_info, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(source_info["path"])
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": 124,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report,
    output_root,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    source_construction_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _source_construction_issues(source_construction_report)
    machine_checked = bool(source_construction_report.get("production_claim_machine_checked"))
    attempts = list(source_construction_report.get("premise_proof_term_source_construction_attempts") or [])
    drafts = _source_theorem_drafts(attempts)
    expected_names = {item.get("expected_lean_proof_name") for item in drafts if item.get("expected_lean_proof_name")}
    lean_text = _lean_source(drafts)
    output_root = pathlib.Path(output_root)
    source_info = _write_text(output_root / "ProfileEquivalencePremiseProofTermSourceTheoremDraft.lean", lean_text)
    lean_result = _run_lean(source_info, source_root_path, lean_executable, lake_executable, timeout_seconds, runner=runner)
    theorem_names = THEOREM_RE.findall(lean_text)
    structures = STRUCTURE_RE.findall(lean_text)
    placeholders = PLACEHOLDER_RE.findall(lean_text)
    assumption_echo_markers = ASSUMPTION_ECHO_RE.findall(lean_text)
    expected_declarations = [name for name in theorem_names if name in expected_names]
    missing_expected = sorted(expected_names - set(expected_declarations))
    target_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    target_declarations.extend([name for name in structures if name == TARGET_STATEMENT_NAME])
    lean_exit_zero = bool(lean_result.get("exit_code") == 0 and not lean_result.get("timed_out"))
    draft_ready = bool(lean_exit_zero and drafts and len(expected_declarations) == len(drafts) and assumption_echo_markers and not placeholders and not target_declarations)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_consumable", not _source_construction_issues(source_construction_report), "source_construction_attempt_not_consumable"),
        _check("source_theorem_drafts_present", bool(drafts), "source_theorem_drafts_missing"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("expected_source_theorem_declarations_present", len(expected_declarations) == len(drafts), "expected_source_theorem_declarations_missing"),
        _check("target_theorem_not_declared", not target_declarations, "target_theorem_or_statement_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("assumption_echo_detected", bool(assumption_echo_markers) or machine_checked, "assumption_echo_missing", severity="readiness"),
        _check("assumption_echo_rejected_as_production", bool(assumption_echo_markers) or machine_checked, "assumption_echo_not_classified", severity="readiness"),
        _check("no_source_mutation", not source_construction_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not source_construction_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif draft_ready:
        status = "PASS"
        state = SOURCE_THEOREM_DRAFT_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake"
        next_agent_command = SOURCE_THEOREM_PROOF_SOURCE_INTAKE_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    assumption_echo_rejected = bool(status == "PASS" and assumption_echo_markers and not production_checked)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": True,
        "prover_execution_performed": True,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_draft_ready": bool(status == "PASS" and draft_ready),
        "profile_equivalence_transfer_premise_source_theorem_assumption_echo_rejected": assumption_echo_rejected,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_required": bool(status == "PASS" and not production_checked),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_result.get("selected_lean") or "",
        "lake_executable_path": lean_result.get("selected_lake") or "",
        "lake_env_used": bool(lean_result.get("lake_env_used")),
        "lean_exit_code": lean_result.get("exit_code"),
        "lean_source_path": source_info["path"],
        "claim_packet_id": source_construction_report.get("claim_packet_id") or "",
        "slug": source_construction_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_path": source_construction_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report_sha256": source_construction_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_draft_count": len(drafts),
            "source_theorem_declaration_count": len(theorem_names),
            "expected_source_theorem_declaration_count": len(expected_declarations),
            "expected_source_theorem_missing_count": len(missing_expected),
            "assumption_echo_marker_count": len(assumption_echo_markers),
            "target_theorem_declaration_count": len(target_declarations),
            "lean_structure_count": len(structures),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_required_count": 1 if status == "PASS" and not production_checked else 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_result.get("command") or [],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_result.get("exit_code"),
            "timed_out": bool(lean_result.get("timed_out")),
            "stdout": lean_result.get("stdout") or "",
            "stderr": lean_result.get("stderr") or "",
            "structure_names": structures,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "assumption_echo_marker_count": len(assumption_echo_markers),
            "expected_source_theorem_declaration_count": len(expected_declarations),
            "target_theorem_declaration_count": len(target_declarations),
        },
        "source_theorem_drafts": drafts,
        "formalization_route": [
            {
                "step_id": "source_theorem_statement_draft",
                "status": "ready" if draft_ready else "attention",
                "output": "Lean checks the expected premise source theorem names and statements",
            },
            {
                "step_id": "reject_source_theorem_assumption_echo",
                "status": "ready" if assumption_echo_rejected else "attention",
                "output": "the draft theorem bodies are assumption echo and are not production proof",
            },
            {
                "step_id": "source_theorem_proof_source_intake",
                "status": "pending" if assumption_echo_rejected else "attention",
                "output": "find or construct source-tree proofs for the ten expected theorem names",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt_report": source_construction_report,
        "boundary": [
            "This command checks theorem-name and statement drafts only.",
            "The theorem bodies forward theorem-specific assumptions and are rejected as production proof.",
            "Generated logs, field forwarding, statement assumptions, and premise-assumption echo remain rejected as source-backed proof.",
            "It does not prove ProfileEquivalenceTransfersDirectScoreLimitStatement or profileEquivalenceTransfersDirectScoreLimit.",
            "It writes only local draft/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Proof-Term Source Theorem Draft",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_draft_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Source theorem drafts: {summary.get('source_theorem_draft_count', 0)}",
        f"- Expected theorem declarations: {summary.get('expected_source_theorem_declaration_count', 0)}",
        f"- Assumption echo markers: {summary.get('assumption_echo_marker_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
