"""Record Lean-checked obstruction for source-theorem proof bodies."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-construction"
SKELETON_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-skeleton-gate"
SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-work-item-dispatch"

SKELETON_GATE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SKELETON_GATE_READY_SOURCE_PROOF_BODIES_REQUIRED"
SKELETON_GATE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SKELETON_GATE_MACHINE_CHECKED_CLOSED"

OBSTRUCTION_RECORDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_OBSTRUCTION_RECORDED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_construction_obstruction_recorded",
    "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_theorem_proof_body_construction_attempts",
    "dispatch_groups",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_skeleton_item_count",
    "source_theorem_proof_body_construction_attempt_count",
    "source_theorem_proof_body_construction_ready_count",
    "source_theorem_proof_body_construction_blocking_count",
    "source_tree_proof_body_candidate_count",
    "source_tree_proof_body_ready_count",
    "skeleton_rejected_count",
    "expected_source_theorem_declaration_count",
    "target_theorem_declaration_count",
    "lean_structure_count",
    "lean_inductive_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "obstruction_theorem_count",
    "lean_exit_zero_count",
    "dispatch_group_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the source theorem proof skeleton gate and records one source-tree proof body construction obstruction per expected sourceBacked theorem.",
    "Runs Lean on an obstruction taxonomy while declaring no expected sourceBacked theorem and no target transfer theorem.",
    "This command records missing proof-body construction only; it is not production proof.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
INDUCTIVE_RE = re.compile(r"^\s*inductive\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"
OBSTRUCTION_THEOREM_NAME = "profileEquivalencePremiseSourceTheoremProofBodyConstructionObstructionDraft"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _skeleton_gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_missing")
        return issues
    if report.get("command") != SKELETON_GATE_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_state") or ""
    if state not in {SKELETON_GATE_READY_STATE, SKELETON_GATE_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_skeleton_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_skeleton_items_missing")
    if not report.get("profile_equivalence_transfer_premise_source_theorem_proof_skeleton_rejected") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_skeleton_rejection_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_boundary:{key}")
    return issues


def _lean_name(value, fallback):
    text = re.sub(r"[^A-Za-z0-9_]", "", str(value or fallback))
    if not text:
        text = fallback
    return f"{text[:1].lower()}{text[1:]}"


def _body_construction_attempts(skeleton_items):
    attempts = []
    for index, item in enumerate(skeleton_items, start=1):
        expected = item.get("expected_lean_proof_name") or f"sourceBackedPremiseTheorem{index}"
        attempts.append(
            {
                "body_construction_attempt_id": f"source-theorem-proof-body-construction-{index:02d}-{expected}",
                "expected_lean_proof_name": expected,
                "lean_premise_name": item.get("lean_premise_name") or "",
                "dispatch_group": item.get("dispatch_group") or "",
                "source_labels": list(item.get("source_labels") or []),
                "source_anchor_kinds": list(item.get("source_anchor_kinds") or []),
                "skeleton_statement_field_name": item.get("skeleton_statement_field_name") or "",
                "skeleton_declared": bool(item.get("skeleton_declared")),
                "skeleton_rejected_as_production": bool(item.get("skeleton_rejected_as_production")),
                "required_output_kind": "source_tree_no_placeholder_lean_proof_body",
                "source_tree_proof_body_candidate_count": 0,
                "source_tree_proof_body_ready_count": 0,
                "source_tree_proof_body_constructed": False,
                "body_construction_blocking": True,
                "must_not_use": list(item.get("must_not_use") or [])
                + [
                    "generated proof-body skeletons",
                    "theorem-specific assumption echo",
                ],
                "blocking_reason": "no source-tree no-placeholder proof body is available for the expected sourceBacked theorem",
                "next_required_action": f"construct a source-tree no-placeholder proof body for {expected}",
            }
        )
    return attempts


def _lean_source(attempts):
    constructors = []
    fields = []
    theorem_args = []
    for item in attempts:
        theorem_name = item.get("expected_lean_proof_name") or item.get("lean_premise_name") or "sourceTheoremProofBody"
        constructor = _lean_name(theorem_name, "sourceTheoremProofBody")
        field = f"{constructor}BodyBlocked"
        constructors.append(f"  | {constructor}")
        fields.append(f"  {field} : Prop")
        theorem_args.append(f"    (_h{field[:1].upper()}{field[1:]} : O.{field})")
    if not constructors:
        constructors.append("  | noSourceTheoremProofBody")
        fields.append("  noSourceTheoremProofBodyBlocked : Prop")
        theorem_args.append("    (_hNoSourceTheoremProofBodyBlocked : O.noSourceTheoremProofBodyBlocked)")
    return """import Mathlib

namespace NSMAoSFormalization

noncomputable section

inductive ProfileEquivalencePremiseSourceTheoremProofBodyName where
{constructors}
  deriving DecidableEq, Repr

structure ProfileEquivalencePremiseSourceTheoremProofBodyConstructionAttempt where
  theoremName : ProfileEquivalencePremiseSourceTheoremProofBodyName
  skeletonStatementReady : Prop
  skeletonRejectedAsProof : Prop
  localSourceTreeProofBodyFound : Prop
  noPlaceholderProofBodyConstructed : Prop
  bodyConstructionBlocked : Prop

structure ProfileEquivalencePremiseSourceTheoremProofBodyConstructionObstruction where
{fields}

theorem profileEquivalencePremiseSourceTheoremProofBodyConstructionObstructionDraft
    (O : ProfileEquivalencePremiseSourceTheoremProofBodyConstructionObstruction)
{theorem_args} :
    True := by
  exact True.intro

end

end NSMAoSFormalization
""".format(
        constructors="\n".join(constructors),
        fields="\n".join(fields),
        theorem_args="\n".join(theorem_args),
    )


def _run_lean(source_info, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(source_info["path"])
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": False,
            "exit_code": 124,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report,
    output_root,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    skeleton_gate_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _skeleton_gate_issues(skeleton_gate_report)
    machine_checked = bool(skeleton_gate_report.get("production_claim_machine_checked"))
    skeleton_items = list(skeleton_gate_report.get("source_theorem_proof_skeleton_items") or [])
    attempts = _body_construction_attempts(skeleton_items)
    expected_names = {item.get("expected_lean_proof_name") for item in attempts if item.get("expected_lean_proof_name")}
    lean_text = _lean_source(attempts)
    output_root = pathlib.Path(output_root)
    source_info = _write_text(output_root / "ProfileEquivalencePremiseSourceTheoremProofBodyConstruction.lean", lean_text)
    lean_result = _run_lean(source_info, source_root_path, lean_executable, lake_executable, timeout_seconds, runner=runner)
    theorem_names = THEOREM_RE.findall(lean_text)
    structures = STRUCTURE_RE.findall(lean_text)
    inductives = INDUCTIVE_RE.findall(lean_text)
    placeholders = PLACEHOLDER_RE.findall(lean_text)
    expected_declarations = [name for name in theorem_names if name in expected_names]
    target_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    target_declarations.extend([name for name in structures if name == TARGET_STATEMENT_NAME])
    lean_exit_zero = bool(lean_result.get("exit_code") == 0 and not lean_result.get("timed_out"))
    obstruction_ready = bool(
        lean_exit_zero
        and attempts
        and OBSTRUCTION_THEOREM_NAME in theorem_names
        and not expected_declarations
        and not target_declarations
        and not placeholders
    )
    blocking_count = sum(1 for item in attempts if item.get("body_construction_blocking"))
    ready_count = sum(1 for item in attempts if item.get("source_tree_proof_body_constructed"))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_consumable", not _skeleton_gate_issues(skeleton_gate_report), "source_theorem_proof_skeleton_gate_report_not_consumable"),
        _check("source_theorem_proof_skeleton_items_present", bool(skeleton_items), "source_theorem_proof_skeleton_items_missing"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("obstruction_theorem_present", OBSTRUCTION_THEOREM_NAME in theorem_names, "body_construction_obstruction_theorem_missing"),
        _check("no_expected_source_theorem_declarations", not expected_declarations, "expected_source_theorem_declared_without_source_body"),
        _check("target_theorem_not_declared", not target_declarations, "target_theorem_or_statement_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("proof_body_construction_blocking_recorded", bool(blocking_count) or machine_checked, "proof_body_construction_blocking_missing", severity="readiness"),
        _check("no_source_mutation", not skeleton_gate_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not skeleton_gate_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif obstruction_ready:
        status = "PASS"
        state = OBSTRUCTION_RECORDED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch"
        next_agent_command = SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    dispatch_groups = list(skeleton_gate_report.get("dispatch_groups") or [])
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": True,
        "prover_execution_performed": True,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_construction_obstruction_recorded": bool(status == "PASS" and obstruction_ready),
        "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready": False,
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_result.get("selected_lean") or "",
        "lake_executable_path": lean_result.get("selected_lake") or "",
        "lake_env_used": bool(lean_result.get("lake_env_used")),
        "lean_exit_code": lean_result.get("exit_code"),
        "lean_source_path": source_info["path"],
        "claim_packet_id": skeleton_gate_report.get("claim_packet_id") or "",
        "slug": skeleton_gate_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_path": skeleton_gate_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report_sha256": skeleton_gate_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_skeleton_item_count": len(skeleton_items),
            "source_theorem_proof_body_construction_attempt_count": len(attempts),
            "source_theorem_proof_body_construction_ready_count": ready_count,
            "source_theorem_proof_body_construction_blocking_count": blocking_count,
            "source_tree_proof_body_candidate_count": sum(int(item.get("source_tree_proof_body_candidate_count") or 0) for item in attempts),
            "source_tree_proof_body_ready_count": sum(int(item.get("source_tree_proof_body_ready_count") or 0) for item in attempts),
            "skeleton_rejected_count": sum(1 for item in attempts if item.get("skeleton_rejected_as_production")),
            "expected_source_theorem_declaration_count": len(expected_declarations),
            "target_theorem_declaration_count": len(target_declarations),
            "lean_structure_count": len(structures),
            "lean_inductive_count": len(inductives),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "obstruction_theorem_count": 1 if OBSTRUCTION_THEOREM_NAME in theorem_names else 0,
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "dispatch_group_count": len(dispatch_groups),
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_result.get("command") or [],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_result.get("exit_code"),
            "timed_out": bool(lean_result.get("timed_out")),
            "stdout": lean_result.get("stdout") or "",
            "stderr": lean_result.get("stderr") or "",
            "structure_names": structures,
            "inductive_names": inductives,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "expected_source_theorem_declaration_count": len(expected_declarations),
            "target_theorem_declaration_count": len(target_declarations),
        },
        "source_theorem_proof_body_construction_attempts": attempts,
        "dispatch_groups": dispatch_groups,
        "formalization_route": [
            {
                "step_id": "lean_body_construction_obstruction_taxonomy",
                "status": "ready" if obstruction_ready else "attention",
                "output": "Lean checks an obstruction taxonomy for missing source-tree proof bodies",
            },
            {
                "step_id": "source_tree_no_placeholder_proof_body_construction",
                "status": "blocked_on_source_tree_proof_bodies" if blocking_count else "ready",
                "output": "construct no-placeholder proof bodies for each expected sourceBacked theorem",
            },
            {
                "step_id": "replace_skeleton_theorem_bodies",
                "status": "pending",
                "output": "replace skeleton assumption echoes only after source-tree proof bodies exist",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_report": skeleton_gate_report,
        "boundary": [
            "This command records source theorem proof-body construction obstruction only.",
            "It declares no sourceBacked expected theorem, no ProfileEquivalenceTransfersDirectScoreLimitStatement, and no target theorem.",
            "Skeleton declarations, theorem-specific assumptions, generated logs, placeholders, field forwarding, statement assumptions, premise assumptions, and plans remain rejected as proof.",
            "It writes only local draft/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Body Construction",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Body construction attempts: {summary.get('source_theorem_proof_body_construction_attempt_count', 0)}",
        f"- Blocking attempts: {summary.get('source_theorem_proof_body_construction_blocking_count', 0)}",
        f"- Source tree proof bodies ready: {summary.get('source_tree_proof_body_ready_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
