"""Plan implementation for missing premise source-theorem proof bodies."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-implementation-plan"
SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-work-item-dispatch"
SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-intake"

WORK_ITEMS_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_READY_SOURCE_PROOF_BODIES_REQUIRED"
WORK_ITEMS_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"

IMPLEMENTATION_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_READY_SOURCE_PROOF_BODIES_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_implementation_plan_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_theorem_proof_body_implementation_items",
    "dispatch_groups",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_body_work_item_count",
    "source_theorem_proof_body_implementation_item_count",
    "implementation_ready_count",
    "implementation_blocking_count",
    "source_anchor_translation_ready_count",
    "source_theorem_statement_ready_count",
    "source_tree_proof_body_ready_count",
    "source_tree_proof_body_candidate_count",
    "skeleton_rejected_count",
    "expected_source_theorem_declaration_count",
    "target_theorem_declaration_count",
    "lean_structure_count",
    "lean_inductive_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "implementation_plan_theorem_count",
    "lean_exit_zero_count",
    "dispatch_group_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes proof-body work items and emits one implementation plan item per missing source-tree no-placeholder proof body.",
    "Runs Lean on a taxonomy for the proof-body implementation plan while declaring no expected sourceBacked theorem and no target transfer theorem.",
    "The plan is not a proof; it keeps source-tree no-placeholder proof body construction as the hard boundary.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
INDUCTIVE_RE = re.compile(r"^\s*inductive\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"
IMPLEMENTATION_PLAN_THEOREM_NAME = "profileEquivalencePremiseSourceTheoremProofBodyImplementationPlanDraft"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _dispatch_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_missing")
        return issues
    if report.get("command") != SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_state") or ""
    if state not in {WORK_ITEMS_READY_STATE, WORK_ITEMS_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_body_work_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_work_items_missing")
    for item in report.get("source_theorem_proof_body_work_items") or []:
        candidate_count = int(item.get("source_tree_proof_body_candidate_count") or 0)
        ready_count = int(item.get("source_tree_proof_body_ready_count") or 0)
        proof_name = item.get("expected_lean_proof_name") or item.get("work_item_id") or ""
        if ready_count > candidate_count:
            _issue(
                issues,
                "source_theorem_proof_body_work_item_ready_count_exceeds_candidate_count",
                proof_name,
            )
        if item.get("status") == "ready" and not item.get("blocking") and ready_count <= 0:
            _issue(
                issues,
                "source_theorem_proof_body_ready_work_item_without_ready_body_evidence",
                proof_name,
            )
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_boundary:{key}")
    return issues


def _lean_name(value, fallback):
    text = re.sub(r"[^A-Za-z0-9_]", "", str(value or fallback))
    if not text:
        text = fallback
    return f"{text[:1].lower()}{text[1:]}"


def _lean_source(work_items):
    constructors = []
    fields = []
    theorem_args = []
    for item in work_items:
        expected = item.get("expected_lean_proof_name") or item.get("lean_premise_name") or "sourceTheoremProofBody"
        constructor = _lean_name(expected, "sourceTheoremProofBody")
        field = f"{constructor}ProofBodyImplementationBlocked"
        constructors.append(f"  | {constructor}")
        fields.append(f"  {field} : Prop")
        theorem_args.append(f"    (_h{field[:1].upper()}{field[1:]} : P.{field})")
    if not constructors:
        constructors.append("  | noSourceTheoremProofBodyImplementation")
        fields.append("  noSourceTheoremProofBodyImplementationBlocked : Prop")
        theorem_args.append("    (_hNoSourceTheoremProofBodyImplementationBlocked : P.noSourceTheoremProofBodyImplementationBlocked)")
    return """import Mathlib

namespace NSMAoSFormalization

noncomputable section

inductive ProfileEquivalencePremiseSourceTheoremProofBodyImplementationTask where
  | translateSourceAnchor
  | bindLeanStatement
  | deriveBodyObligation
  | eliminateSkeletonAssumption
  | constructNoPlaceholderProofBody
  | replaceSkeletonBody
  | recheckSourceTheorem
  deriving DecidableEq, Repr

inductive ProfileEquivalencePremiseSourceTheoremProofBodyImplementationName where
{constructors}
  deriving DecidableEq, Repr

structure ProfileEquivalencePremiseSourceTheoremProofBodyImplementationPlanItem where
  theoremName : ProfileEquivalencePremiseSourceTheoremProofBodyImplementationName
  task : ProfileEquivalencePremiseSourceTheoremProofBodyImplementationTask
  sourceAnchorTranslationReady : Prop
  sourceTheoremStatementReady : Prop
  skeletonRejectedAsProof : Prop
  sourceTreeProofBodyReady : Prop
  implementationBlocked : Prop

structure ProfileEquivalencePremiseSourceTheoremProofBodyImplementationPlan where
{fields}

theorem profileEquivalencePremiseSourceTheoremProofBodyImplementationPlanDraft
    (P : ProfileEquivalencePremiseSourceTheoremProofBodyImplementationPlan)
{theorem_args} :
    True := by
  exact True.intro

end

end NSMAoSFormalization
""".format(
        constructors="\n".join(constructors),
        fields="\n".join(fields),
        theorem_args="\n".join(theorem_args),
    )


def _run_lean(source_info, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(source_info["path"])
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": False,
            "exit_code": 124,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def _implementation_items(work_items):
    items = []
    steps = [
        "translate_source_anchor_to_body_statement",
        "bind_expected_source_theorem_statement",
        "derive_source_tree_proof_body_obligation",
        "eliminate_skeleton_assumption_echo",
        "construct_no_placeholder_proof_body",
        "replace_skeleton_theorem_body",
        "recheck_source_theorem_and_intake",
    ]
    for index, item in enumerate(work_items, start=1):
        expected = item.get("expected_lean_proof_name") or f"sourceBackedPremiseTheorem{index}"
        body_ready = bool(item.get("status") == "ready" and not item.get("blocking"))
        items.append(
            {
                "implementation_item_id": f"source-theorem-proof-body-implementation-{index:02d}-{expected}",
                "expected_lean_proof_name": expected,
                "lean_premise_name": item.get("lean_premise_name") or "",
                "dispatch_group": item.get("dispatch_group") or "",
                "source_labels": list(item.get("source_labels") or []),
                "source_anchor_kinds": list(item.get("source_anchor_kinds") or []),
                "skeleton_statement_field_name": item.get("skeleton_statement_field_name") or "",
                "source_anchor_translation_ready": bool(item.get("source_labels")),
                "source_theorem_statement_ready": True,
                "skeleton_rejected_as_production": bool(item.get("skeleton_rejected_as_production")),
                "source_tree_proof_body_candidate_count": int(item.get("source_tree_proof_body_candidate_count") or 0),
                "source_tree_proof_body_ready_count": int(item.get("source_tree_proof_body_ready_count") or 0),
                "source_tree_proof_body_ready": body_ready,
                "implementation_ready": body_ready,
                "implementation_blocking": not body_ready,
                "proof_body_obligation_steps": steps,
                "must_not_use": list(item.get("must_not_use") or []),
                "blocking_reason": "" if body_ready else (item.get("blocking_reason") or "source-tree proof body missing"),
                "next_required_action": item.get("next_required_action") or f"construct a source-tree no-placeholder proof body for {expected}",
            }
        )
    return items


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report,
    output_root,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    dispatch_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _dispatch_issues(dispatch_report)
    machine_checked = bool(dispatch_report.get("production_claim_machine_checked"))
    work_items = list(dispatch_report.get("source_theorem_proof_body_work_items") or [])
    implementation_items = _implementation_items(work_items)
    lean_text = _lean_source(work_items)
    output_root = pathlib.Path(output_root)
    source_info = _write_text(output_root / "ProfileEquivalencePremiseSourceTheoremProofBodyImplementationPlan.lean", lean_text)
    lean_result = _run_lean(source_info, source_root_path, lean_executable, lake_executable, timeout_seconds, runner=runner)
    theorem_names = THEOREM_RE.findall(lean_text)
    structures = STRUCTURE_RE.findall(lean_text)
    inductives = INDUCTIVE_RE.findall(lean_text)
    placeholders = PLACEHOLDER_RE.findall(lean_text)
    expected_source_theorem_names = {item.get("expected_lean_proof_name") for item in work_items if item.get("expected_lean_proof_name")}
    expected_source_theorem_declarations = [name for name in theorem_names if name in expected_source_theorem_names]
    target_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    target_declarations.extend([name for name in structures if name == TARGET_STATEMENT_NAME])
    lean_exit_zero = bool(lean_result.get("exit_code") == 0 and not lean_result.get("timed_out"))
    ready_count = sum(1 for item in implementation_items if item.get("implementation_ready"))
    blocking_count = sum(1 for item in implementation_items if item.get("implementation_blocking"))
    plan_ready = bool(lean_exit_zero and implementation_items and IMPLEMENTATION_PLAN_THEOREM_NAME in theorem_names and not expected_source_theorem_declarations and not target_declarations and not placeholders)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_consumable", not _dispatch_issues(dispatch_report), "source_theorem_proof_body_work_item_dispatch_report_not_consumable"),
        _check("source_theorem_proof_body_work_items_present", bool(work_items), "source_theorem_proof_body_work_items_missing"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("implementation_plan_theorem_present", IMPLEMENTATION_PLAN_THEOREM_NAME in theorem_names, "implementation_plan_theorem_missing"),
        _check("no_expected_source_theorem_declarations", not expected_source_theorem_declarations, "expected_source_theorem_declared_by_plan"),
        _check("target_theorem_not_declared", not target_declarations, "target_theorem_or_statement_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("implementation_blocking_recorded", bool(blocking_count) or machine_checked, "implementation_blocking_missing", severity="readiness"),
        _check("no_source_mutation", not dispatch_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not dispatch_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif plan_ready:
        status = "PASS"
        state = IMPLEMENTATION_PLAN_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake"
        next_agent_command = SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    dispatch_groups = list(dispatch_report.get("dispatch_groups") or [])
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": True,
        "prover_execution_performed": True,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_implementation_plan_ready": bool(status == "PASS" and plan_ready),
        "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready": False,
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_result.get("selected_lean") or "",
        "lake_executable_path": lean_result.get("selected_lake") or "",
        "lake_env_used": bool(lean_result.get("lake_env_used")),
        "lean_exit_code": lean_result.get("exit_code"),
        "lean_source_path": source_info["path"],
        "claim_packet_id": dispatch_report.get("claim_packet_id") or "",
        "slug": dispatch_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_path": dispatch_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report_sha256": dispatch_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_body_work_item_count": len(work_items),
            "source_theorem_proof_body_implementation_item_count": len(implementation_items),
            "implementation_ready_count": ready_count,
            "implementation_blocking_count": blocking_count,
            "source_anchor_translation_ready_count": sum(1 for item in implementation_items if item.get("source_anchor_translation_ready")),
            "source_theorem_statement_ready_count": sum(1 for item in implementation_items if item.get("source_theorem_statement_ready")),
            "source_tree_proof_body_ready_count": sum(1 for item in implementation_items if item.get("source_tree_proof_body_ready")),
            "source_tree_proof_body_candidate_count": sum(int(item.get("source_tree_proof_body_candidate_count") or 0) for item in implementation_items),
            "skeleton_rejected_count": sum(1 for item in implementation_items if item.get("skeleton_rejected_as_production")),
            "expected_source_theorem_declaration_count": len(expected_source_theorem_declarations),
            "target_theorem_declaration_count": len(target_declarations),
            "lean_structure_count": len(structures),
            "lean_inductive_count": len(inductives),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "implementation_plan_theorem_count": 1 if IMPLEMENTATION_PLAN_THEOREM_NAME in theorem_names else 0,
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "dispatch_group_count": len(dispatch_groups),
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_result.get("command") or [],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_result.get("exit_code"),
            "timed_out": bool(lean_result.get("timed_out")),
            "stdout": lean_result.get("stdout") or "",
            "stderr": lean_result.get("stderr") or "",
            "structure_names": structures,
            "inductive_names": inductives,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "expected_source_theorem_declaration_count": len(expected_source_theorem_declarations),
            "target_theorem_declaration_count": len(target_declarations),
        },
        "source_theorem_proof_body_implementation_items": implementation_items,
        "dispatch_groups": dispatch_groups,
        "formalization_route": [
            {
                "step_id": "lean_proof_body_implementation_plan_taxonomy",
                "status": "ready" if plan_ready else "attention",
                "output": "Lean checks a taxonomy for per-theorem source-tree proof body implementation planning",
            },
            {
                "step_id": "source_tree_proof_body_construction",
                "status": "blocked_on_source_tree_proof_bodies" if blocking_count else "ready",
                "output": "construct no-placeholder proof bodies for each expected sourceBacked theorem",
            },
            {
                "step_id": "source_theorem_recheck",
                "status": "pending",
                "output": "recheck sourceBacked theorem declarations only after proof bodies exist",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_report": dispatch_report,
        "boundary": [
            "This command creates a Lean-checked implementation plan only; the plan is not a proof body.",
            "It declares no sourceBacked expected theorem, no ProfileEquivalenceTransfersDirectScoreLimitStatement, and no target theorem.",
            "Generated logs, source anchors alone, skeleton bodies, placeholders, field forwarding, statement assumptions, premise assumptions, source theorem assumption echo, and dispatch work items remain rejected as proof.",
            "It writes only local draft/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Body Implementation Plan",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Implementation items: {summary.get('source_theorem_proof_body_implementation_item_count', 0)}",
        f"- Blocking items: {summary.get('implementation_blocking_count', 0)}",
        f"- Source tree proof bodies ready: {summary.get('source_tree_proof_body_ready_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
