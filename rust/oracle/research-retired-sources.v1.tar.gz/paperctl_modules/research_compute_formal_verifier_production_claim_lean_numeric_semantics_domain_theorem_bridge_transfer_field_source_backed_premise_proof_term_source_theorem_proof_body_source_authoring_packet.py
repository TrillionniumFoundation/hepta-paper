"""Build read-only proof-body source authoring packets."""

import hashlib
import json


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-packet"
AUTHORING_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-plan-capstone"
AUTHORIZATION_PREFLIGHT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authorization-preflight"
SOURCE_BODY_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-intake"

AUTHORING_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PLAN_CAPSTONE_CONTRACT_BOUND_SOURCE_AUTHORING_PLAN_READY"
AUTHORING_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PLAN_CAPSTONE_MACHINE_CHECKED_CLOSED"
AUTHORIZATION_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_AUTHORIZATION_REQUIRED"
AUTHORIZATION_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_AUTHORIZATION_READY"
AUTHORIZATION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_MACHINE_CHECKED_CLOSED"
SOURCE_INTAKE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_SOURCE_REQUIRED"
SOURCE_INTAKE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_READY"
SOURCE_INTAKE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

AUTHORING_PACKET_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PACKET_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PACKET_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PACKET_FAILED"

AUTHORING_PACKET_SCHEMA_ID = "paper_factory.source_tree_proof_body_source_authoring_packet.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_packet_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "source_authoring_packet_consumable_as_authorization_manifest",
    "source_authoring_packet_consumable_as_proof_source",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "next_agent_command_precondition",
    "summary",
    "checks",
    "validation_issues",
    "source_theorem_proof_body_source_authoring_packets",
    "packet_runbook",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_authoring_plan_item_count",
    "source_authorization_preflight_item_count",
    "source_authorization_preflight_missing_item_count",
    "source_intake_classification_count",
    "source_intake_missing_classification_count",
    "source_authoring_packet_contract_mismatch_count",
    "source_theorem_proof_body_source_authoring_packet_count",
    "source_theorem_proof_body_source_authoring_packet_ready_count",
    "source_authorization_manifest_required_count",
    "source_authorization_missing_item_count",
    "source_authorization_source_file_missing_item_count",
    "source_authorization_preflight_ready_item_count",
    "source_intake_candidate_body_count",
    "source_intake_ready_body_count",
    "source_authoring_packet_consumable_as_authorization_manifest_count",
    "source_authoring_packet_consumable_as_proof_source_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_packet_ready_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Consumes authoring-plan, authorization-preflight, and source-body-source intake reports to build proof-body source authoring packets.",
    "The packet is an execution checklist only; it is not an authorization manifest, Lean proof source, or proof-readiness signal.",
    "A later source-body-source intake must still consume a real authorization-preflight report and locally Lean-check the authored source.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _sha256_json(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _report_issues(report, *, command, state_field, consumable_states, missing_issue, command_issue, status_issue, state_issue, items_field, items_issue, premature_issue):
    issues = []
    if not report:
        _issue(issues, missing_issue)
        return issues
    if report.get("command") != command:
        _issue(issues, command_issue, report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, status_issue, report.get("status") or "")
    state = report.get(state_field) or ""
    if state not in consumable_states:
        _issue(issues, state_issue, state)
    if not report.get(items_field) and not report.get("production_claim_machine_checked"):
        _issue(issues, items_issue)
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, premature_issue)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_{command}:{key}")
    return issues


def _authoring_plan_issues(report):
    return _report_issues(
        report,
        command=AUTHORING_PLAN_COMMAND,
        state_field="formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_state",
        consumable_states={AUTHORING_PLAN_READY_STATE, AUTHORING_PLAN_CLOSED_STATE},
        missing_issue="source_authoring_plan_capstone_report_missing",
        command_issue="source_authoring_plan_capstone_command_mismatch",
        status_issue="source_authoring_plan_capstone_not_pass",
        state_issue="source_authoring_plan_capstone_state_not_consumable",
        items_field="source_authoring_plan_items",
        items_issue="source_authoring_plan_items_missing",
        premature_issue="source_backed_proof_source_ready_premature_in_authoring_plan",
    )


def _authorization_preflight_issues(report):
    return _report_issues(
        report,
        command=AUTHORIZATION_PREFLIGHT_COMMAND,
        state_field="formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_state",
        consumable_states={AUTHORIZATION_REQUIRED_STATE, AUTHORIZATION_READY_STATE, AUTHORIZATION_CLOSED_STATE},
        missing_issue="source_authorization_preflight_report_missing",
        command_issue="source_authorization_preflight_command_mismatch",
        status_issue="source_authorization_preflight_not_pass",
        state_issue="source_authorization_preflight_state_not_consumable",
        items_field="source_authorization_preflight_items",
        items_issue="source_authorization_preflight_items_missing",
        premature_issue="source_backed_proof_source_ready_premature_in_authorization_preflight",
    )


def _source_intake_issues(report):
    return _report_issues(
        report,
        command=SOURCE_BODY_SOURCE_INTAKE_COMMAND,
        state_field="formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_state",
        consumable_states={SOURCE_INTAKE_REQUIRED_STATE, SOURCE_INTAKE_READY_STATE, SOURCE_INTAKE_CLOSED_STATE},
        missing_issue="source_body_source_intake_report_missing",
        command_issue="source_body_source_intake_command_mismatch",
        status_issue="source_body_source_intake_not_pass",
        state_issue="source_body_source_intake_state_not_consumable",
        items_field="source_theorem_proof_body_source_intake_classifications",
        items_issue="source_body_source_intake_classifications_missing",
        premature_issue="source_backed_proof_source_ready_premature_in_source_intake",
    )


def _by_name(items):
    return {str(item.get("expected_lean_proof_name") or ""): item for item in items or []}


def _label_set(item):
    return {str(label) for label in item.get("source_labels") or [] if str(label)}


def _contract_value(item, *keys):
    for key in keys:
        value = item.get(key)
        if value not in (None, ""):
            return str(value)
    return ""


def _contract_alignment_issues(plan_items, preflight_by_name, intake_by_name):
    issues = []
    for plan_item in plan_items or []:
        expected = plan_item.get("expected_lean_proof_name") or ""
        if not expected:
            _issue(issues, "source_authoring_plan_item_expected_lean_proof_name_missing")
            continue
        preflight_item = preflight_by_name.get(expected)
        intake_item = intake_by_name.get(expected)
        if not preflight_item:
            _issue(issues, "source_authorization_preflight_item_missing_for_authoring_plan_item", expected)
        if not intake_item:
            _issue(issues, "source_body_source_intake_classification_missing_for_authoring_plan_item", expected)
        if preflight_item:
            comparisons = [
                (
                    "source_authorization_preflight_expected_path_mismatch",
                    plan_item.get("expected_source_tree_relative_path") or "",
                    preflight_item.get("expected_source_tree_relative_path") or "",
                ),
                (
                    "source_authorization_preflight_expected_statement_field_mismatch",
                    plan_item.get("expected_statement_field_name") or "",
                    preflight_item.get("expected_statement_field_name") or "",
                ),
                (
                    "source_authorization_preflight_expected_template_id_mismatch",
                    plan_item.get("source_authorization_template_id") or "",
                    _contract_value(preflight_item, "expected_source_authorization_template_id", "source_authorization_template_id"),
                ),
                (
                    "source_authorization_preflight_expected_template_sha256_mismatch",
                    plan_item.get("source_authorization_template_sha256") or "",
                    _contract_value(preflight_item, "expected_source_authorization_template_sha256", "source_authorization_template_sha256"),
                ),
                (
                    "source_authorization_preflight_expected_anchor_contract_id_mismatch",
                    plan_item.get("source_anchor_binding_contract_id") or "",
                    _contract_value(preflight_item, "expected_source_anchor_binding_contract_id", "source_anchor_binding_contract_id"),
                ),
                (
                    "source_authorization_preflight_expected_anchor_contract_sha256_mismatch",
                    plan_item.get("source_anchor_binding_contract_sha256") or "",
                    _contract_value(preflight_item, "expected_source_anchor_binding_contract_sha256", "source_anchor_binding_contract_sha256"),
                ),
            ]
            for issue, expected_value, actual_value in comparisons:
                if expected_value and actual_value and expected_value != actual_value:
                    _issue(issues, issue, expected)
            if not _label_set(plan_item).issubset(_label_set(preflight_item)):
                _issue(issues, "source_authorization_preflight_source_labels_mismatch", expected)
        if intake_item:
            if (plan_item.get("expected_statement_field_name") or "") != (intake_item.get("expected_statement_field_name") or ""):
                _issue(issues, "source_body_source_intake_expected_statement_field_mismatch", expected)
            if not _label_set(plan_item).issubset(_label_set(intake_item)):
                _issue(issues, "source_body_source_intake_source_labels_mismatch", expected)
    return issues


def _packet_item(plan_item, preflight_item, intake_item):
    source_labels = list(plan_item.get("source_labels") or [])
    source_path = plan_item.get("expected_source_tree_relative_path") or ""
    expected = plan_item.get("expected_lean_proof_name") or ""
    template = plan_item.get("source_authorization_manifest_template") or {}
    intake_candidate_count = int((intake_item or {}).get("source_theorem_proof_body_source_candidate_count") or 0)
    intake_ready_count = int((intake_item or {}).get("source_theorem_proof_body_source_ready_count") or 0)
    preflight_ready = bool((preflight_item or {}).get("source_authorization_preflight_ready"))
    manifest_missing = not bool((preflight_item or {}).get("source_authorization_entry_present"))
    source_missing = not bool((preflight_item or {}).get("source_file_present"))
    payload = {
        "schema_id": AUTHORING_PACKET_SCHEMA_ID,
        "rank": int(plan_item.get("rank") or 0),
        "expected_lean_proof_name": expected,
        "expected_statement_field_name": plan_item.get("expected_statement_field_name") or "",
        "expected_source_tree_relative_path": source_path,
        "source_labels": source_labels,
        "source_authorization_template_id": plan_item.get("source_authorization_template_id") or "",
        "source_authorization_template_sha256": plan_item.get("source_authorization_template_sha256") or "",
        "source_anchor_binding_contract_id": plan_item.get("source_anchor_binding_contract_id") or "",
        "source_anchor_binding_contract_sha256": plan_item.get("source_anchor_binding_contract_sha256") or "",
        "primary_source_locators": list(plan_item.get("primary_source_locators") or []),
    }
    payload_sha = _sha256_json(payload)
    return {
        "source_authoring_packet_id": f"source-authoring-packet-{int(plan_item.get('rank') or 0):02d}-{payload_sha[:16]}",
        "source_authoring_packet_schema_id": AUTHORING_PACKET_SCHEMA_ID,
        "source_authoring_packet_payload_sha256": payload_sha,
        "rank": payload["rank"],
        "priority_bucket": plan_item.get("priority_bucket") or "",
        "expected_lean_proof_name": expected,
        "expected_statement_field_name": payload["expected_statement_field_name"],
        "expected_source_tree_relative_path": source_path,
        "source_labels": source_labels,
        "source_anchor_bindings": list(plan_item.get("source_anchor_bindings") or []),
        "source_backed_theorem_obligation_ids": list(plan_item.get("source_backed_theorem_obligation_ids") or []),
        "required_output_kind": plan_item.get("required_output_kind") or "source_tree_no_placeholder_nonvacuous_contract_bound_lean_proof_body_source",
        "source_authorization_manifest_required": True,
        "source_authorization_manifest_filename": plan_item.get("source_authorization_manifest_filename") or "proof-body-source-authorization.json",
        "source_authorization_scope": plan_item.get("source_authorization_scope") or "",
        "source_authorization_manifest_template": template,
        "source_authorization_template_schema_id": plan_item.get("source_authorization_template_schema_id") or "",
        "source_authorization_template_id": plan_item.get("source_authorization_template_id") or "",
        "source_authorization_template_sha256": plan_item.get("source_authorization_template_sha256") or "",
        "source_anchor_binding_contract_schema_id": plan_item.get("source_anchor_binding_contract_schema_id") or "",
        "source_anchor_binding_contract_id": plan_item.get("source_anchor_binding_contract_id") or "",
        "source_anchor_binding_contract_sha256": plan_item.get("source_anchor_binding_contract_sha256") or "",
        "source_anchor_binding_contract_payload": dict(plan_item.get("source_anchor_binding_contract_payload") or {}),
        "authorization_preflight_item_present": bool(preflight_item),
        "source_authorization_preflight_ready": preflight_ready,
        "source_authorization_manifest_entry_missing": manifest_missing,
        "source_file_missing": source_missing,
        "source_authorization_preflight_blocking_reason": (preflight_item or {}).get("blocking_reason") or "source authorization preflight item missing",
        "source_intake_classification_present": bool(intake_item),
        "source_intake_candidate_body_count": intake_candidate_count,
        "source_intake_ready_body_count": intake_ready_count,
        "source_intake_blocking_reason": (intake_item or {}).get("blocking_reason") or "source-body-source intake classification missing",
        "authoring_packet_ready": True,
        "source_body_source_ready": False,
        "source_backed_proof_source_ready": False,
        "machine_checked": False,
        "source_authoring_packet_consumable_as_authorization_manifest": False,
        "source_authoring_packet_consumable_as_proof_source": False,
        "execution_checklist": [
            f"author {source_path} with theorem {expected}",
            f"use statement field {payload['expected_statement_field_name']} in the Lean statement contract",
            "avoid sorry/admit/axiom/opaque placeholders, skeleton echo, assumption echo, and vacuous True statements",
            "create proof-body-source-authorization.json with the packet's template id/hash and anchor contract id/hash",
            "rerun authorization-preflight, then rerun source-body-source intake with that preflight report",
        ],
    }


def _packet_runbook():
    return [
        {
            "step": "author_source_tree_lean_file",
            "description": "write the expected Lean declaration at the packet path without placeholders or assumption echo",
            "promotes_readiness": False,
        },
        {
            "step": "create_authorization_manifest_entry",
            "description": "use the packet template and anchor contract ids/hashes plus full Lean source text_sha256",
            "promotes_readiness": False,
        },
        {
            "step": "rerun_authorization_preflight",
            "command": AUTHORIZATION_PREFLIGHT_COMMAND,
            "promotes_readiness": False,
        },
        {
            "step": "rerun_source_body_source_intake",
            "command": SOURCE_BODY_SOURCE_INTAKE_COMMAND,
            "promotes_readiness": False,
        },
    ]


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report,
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report,
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report,
    label=None,
):
    authoring_plan_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report or {}
    authorization_preflight_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report or {}
    intake_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report or {}
    validation_issues = []
    validation_issues.extend(_authoring_plan_issues(authoring_plan_report))
    validation_issues.extend(_authorization_preflight_issues(authorization_preflight_report))
    validation_issues.extend(_source_intake_issues(intake_report))

    plan_items = list(authoring_plan_report.get("source_authoring_plan_items") or [])
    preflight_by_name = _by_name(authorization_preflight_report.get("source_authorization_preflight_items") or [])
    intake_by_name = _by_name(intake_report.get("source_theorem_proof_body_source_intake_classifications") or [])
    contract_alignment_issues = _contract_alignment_issues(plan_items, preflight_by_name, intake_by_name)
    validation_issues.extend(contract_alignment_issues)
    packet_items = [
        _packet_item(plan_item, preflight_by_name.get(plan_item.get("expected_lean_proof_name") or ""), intake_by_name.get(plan_item.get("expected_lean_proof_name") or ""))
        for plan_item in plan_items
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = AUTHORING_PACKET_READY_STATE
    packet_ready = bool(status == "PASS" and packet_items)
    checks = [
        _check("source_authoring_plan_capstone_report_consumable", not _authoring_plan_issues(authoring_plan_report), "source_authoring_plan_capstone_report_not_consumable"),
        _check("source_authorization_preflight_report_consumable", not _authorization_preflight_issues(authorization_preflight_report), "source_authorization_preflight_report_not_consumable"),
        _check("source_body_source_intake_report_consumable", not _source_intake_issues(intake_report), "source_body_source_intake_report_not_consumable"),
        _check("authoring_packet_contract_items_aligned", not contract_alignment_issues, "authoring_packet_contract_items_not_aligned"),
        _check("source_authoring_packets_present", bool(packet_items), "source_authoring_packets_missing"),
        _check("authoring_packet_not_authorization_manifest", True, ""),
        _check("authoring_packet_not_proof_source", True, ""),
    ]
    return {
        "created_at": "",
        "command": COMMAND,
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_state": state,
        "label": label or "",
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_ready": packet_ready,
        "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_packet_ready": packet_ready,
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": False,
        "production_claim_machine_checked": False,
        "source_authoring_packet_consumable_as_authorization_manifest": False,
        "source_authoring_packet_consumable_as_proof_source": False,
        "claim_packet_id": authoring_plan_report.get("claim_packet_id") or authorization_preflight_report.get("claim_packet_id") or intake_report.get("claim_packet_id") or "",
        "slug": authoring_plan_report.get("slug") or authorization_preflight_report.get("slug") or intake_report.get("slug") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_path": authoring_plan_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_sha256": authoring_plan_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_path": authorization_preflight_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_sha256": authorization_preflight_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_path": intake_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "next_agent_stage": "source_tree_proof_body_source_authoring",
        "next_agent_command": SOURCE_BODY_SOURCE_INTAKE_COMMAND,
        "next_agent_command_precondition": "author the Lean proof body source, add proof-body-source-authorization.json, then rerun authorization-preflight and intake",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_authoring_plan_item_count": len(plan_items),
            "source_authorization_preflight_item_count": len(authorization_preflight_report.get("source_authorization_preflight_items") or []),
            "source_authorization_preflight_missing_item_count": sum(
                1 for item in plan_items if not preflight_by_name.get(item.get("expected_lean_proof_name") or "")
            ),
            "source_intake_classification_count": len(intake_report.get("source_theorem_proof_body_source_intake_classifications") or []),
            "source_intake_missing_classification_count": sum(
                1 for item in plan_items if not intake_by_name.get(item.get("expected_lean_proof_name") or "")
            ),
            "source_authoring_packet_contract_mismatch_count": len(contract_alignment_issues),
            "source_theorem_proof_body_source_authoring_packet_count": len(packet_items),
            "source_theorem_proof_body_source_authoring_packet_ready_count": len(packet_items) if packet_ready else 0,
            "source_authorization_manifest_required_count": sum(1 for item in packet_items if item.get("source_authorization_manifest_required")),
            "source_authorization_missing_item_count": sum(1 for item in packet_items if item.get("source_authorization_manifest_entry_missing")),
            "source_authorization_source_file_missing_item_count": sum(1 for item in packet_items if item.get("source_file_missing")),
            "source_authorization_preflight_ready_item_count": sum(1 for item in packet_items if item.get("source_authorization_preflight_ready")),
            "source_intake_candidate_body_count": sum(int(item.get("source_intake_candidate_body_count") or 0) for item in packet_items),
            "source_intake_ready_body_count": sum(int(item.get("source_intake_ready_body_count") or 0) for item in packet_items),
            "source_authoring_packet_consumable_as_authorization_manifest_count": 0,
            "source_authoring_packet_consumable_as_proof_source_count": 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_packet_ready_count": 1 if packet_ready else 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count": 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_theorem_proof_body_source_authoring_packets": packet_items,
        "packet_runbook": _packet_runbook(),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report": authoring_plan_report,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report": authorization_preflight_report,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report": intake_report,
        "boundary": {
            "read_only": True,
            "proof_generating": False,
            "authorization_manifest": False,
            "lean_source": False,
            "source_mutation_allowed": False,
            "external_action_allowed": False,
            "promotes_source_proof_ready": False,
            "promotes_machine_checked": False,
        },
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source theorem proof body source authoring packet",
        "",
        f"- Status: `{report.get('status')}`",
        f"- State: `{report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_state')}`",
        f"- Packets: {summary.get('source_theorem_proof_body_source_authoring_packet_count', 0)}",
        f"- Missing authorizations: {summary.get('source_authorization_missing_item_count', 0)}",
        f"- Missing source files: {summary.get('source_authorization_source_file_missing_item_count', 0)}",
        f"- Intake-ready bodies: {summary.get('source_intake_ready_body_count', 0)}",
        f"- Consumable as authorization manifest: `{report.get('source_authoring_packet_consumable_as_authorization_manifest')}`",
        f"- Consumable as proof source: `{report.get('source_authoring_packet_consumable_as_proof_source')}`",
        "",
        "## Top packets",
    ]
    for item in (report.get("source_theorem_proof_body_source_authoring_packets") or [])[:5]:
        lines.append(
            f"- rank {item.get('rank')}: `{item.get('expected_lean_proof_name')}` -> `{item.get('expected_source_tree_relative_path')}`"
        )
    return "\n".join(lines) + "\n"
