"""Plan source-tree proof body source authoring and reintake."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-reintake"
SOURCE_IMPLEMENTATION_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-implementation-plan"
SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-intake"
BUNDLE_RECHECK_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-bundle-recheck"

SOURCE_IMPLEMENTATION_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_IMPLEMENTATION_PLAN_READY_SOURCE_PROOF_BODY_SOURCES_REQUIRED"
SOURCE_IMPLEMENTATION_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_IMPLEMENTATION_PLAN_MACHINE_CHECKED_CLOSED"
SOURCE_INTAKE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_SOURCE_REQUIRED"
SOURCE_INTAKE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_READY"
SOURCE_INTAKE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

AUTHORING_REINTAKE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_READY_SOURCE_PROOF_BODY_SOURCES_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_REINTAKE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_targets_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_theorem_proof_body_source_authoring_reintake_items",
    "reintake_command_packet",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_body_source_implementation_item_count",
    "source_theorem_proof_body_source_authoring_item_count",
    "authoring_ready_count",
    "authoring_blocking_count",
    "source_tree_proof_body_source_candidate_count",
    "source_tree_proof_body_source_ready_count",
    "source_tree_proof_body_source_missing_count",
    "vacuous_true_body_candidate_count",
    "non_domain_statement_body_candidate_count",
    "domain_statement_body_candidate_count",
    "statement_contract_body_candidate_count",
    "statement_contract_mismatch_body_candidate_count",
    "local_statement_contract_definition_body_candidate_count",
    "source_tree_lean_check_performed_body_candidate_count",
    "source_tree_lean_check_pass_body_candidate_count",
    "source_tree_lean_check_fail_body_candidate_count",
    "source_tree_lean_check_timeout_body_candidate_count",
    "source_authorization_preflight_ready_body_candidate_count",
    "source_authorization_preflight_missing_body_candidate_count",
    "source_authorization_preflight_mismatch_body_candidate_count",
    "source_authoring_artifact_preflight_ready_body_candidate_count",
    "source_authoring_artifact_preflight_missing_body_candidate_count",
    "source_authoring_artifact_preflight_mismatch_body_candidate_count",
    "expected_source_theorem_declaration_count",
    "target_theorem_declaration_count",
    "lean_structure_count",
    "lean_inductive_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "authoring_reintake_theorem_count",
    "lean_exit_zero_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes proof-body-source implementation plans and source-only intake reports to produce authoring/reintake obligations.",
    "The command does not synthesize source proof bodies; it records that source-backed authoring must happen in source tree and then be reintaked.",
    "Vacuous : True theorem bodies, non-domain statements, statement-contract mismatches, locally defined statement contracts, generated logs, work items, plans, skeletons, placeholders, and assumption echo remain rejected proof sources.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
INDUCTIVE_RE = re.compile(r"^\s*inductive\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"
AUTHORING_REINTAKE_THEOREM_NAME = "profileEquivalencePremiseSourceTheoremProofBodySourceAuthoringReintakeDraft"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _implementation_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report_missing")
        return issues
    if report.get("command") != SOURCE_IMPLEMENTATION_PLAN_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_state") or ""
    if state not in {SOURCE_IMPLEMENTATION_PLAN_READY_STATE, SOURCE_IMPLEMENTATION_PLAN_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_body_source_implementation_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_source_implementation_items_missing")
    if not report.get("production_claim_machine_checked"):
        for item in report.get("source_theorem_proof_body_source_implementation_items") or []:
            ready_count = int(item.get("source_tree_proof_body_source_ready_count") or 0)
            if item.get("implementation_ready"):
                ready_count = max(ready_count, 1)
            if ready_count and int(item.get("source_tree_lean_check_pass_body_candidate_count") or 0) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_implementation_item_without_lean_check_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
            if ready_count and int(item.get("source_authorization_preflight_ready_body_candidate_count") or 0) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_implementation_item_without_authorization_preflight_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
            if ready_count and int(item.get("source_authoring_artifact_preflight_ready_body_candidate_count") or 0) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_implementation_item_without_authoring_artifact_preflight_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_boundary:{key}")
    return issues


def _intake_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_missing")
        return issues
    if report.get("command") != SOURCE_INTAKE_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_state") or ""
    if state not in {SOURCE_INTAKE_REQUIRED_STATE, SOURCE_INTAKE_READY_STATE, SOURCE_INTAKE_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_body_source_intake_classifications") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_source_intake_classifications_missing")
    if not report.get("production_claim_machine_checked"):
        for item in report.get("source_theorem_proof_body_source_intake_classifications") or []:
            ready_count = int(item.get("source_theorem_proof_body_source_ready_count") or 0)
            if not ready_count:
                continue
            ready_bodies = [
                candidate
                for candidate in item.get("candidate_bodies") or []
                if candidate.get("ready")
            ]
            if len(ready_bodies) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_count_without_ready_candidate_bodies",
                    item.get("expected_lean_proof_name") or "",
                )
                continue
            if any(
                not candidate.get("source_tree_lean_check_performed")
                or not candidate.get("source_tree_lean_exit_zero")
                or candidate.get("source_tree_lean_check_timed_out")
                for candidate in ready_bodies
            ):
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_without_lean_check_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
            if any(
                not candidate.get("source_authorization_preflight_entry_present")
                or not candidate.get("source_authorization_preflight_ready")
                or not candidate.get("source_authorization_preflight_text_sha256_match")
                or not candidate.get("source_authorization_preflight_template_id_match")
                or not candidate.get("source_authorization_preflight_anchor_contract_id_match")
                for candidate in ready_bodies
            ):
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_without_authorization_preflight_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
            if any(
                not candidate.get("source_authoring_artifact_preflight_entry_present")
                or not candidate.get("source_authoring_artifact_preflight_ready")
                or not candidate.get("source_authoring_artifact_preflight_text_sha256_match")
                or not candidate.get("source_authoring_artifact_preflight_work_order_contract_match")
                or not candidate.get("source_authoring_artifact_preflight_packet_contract_match")
                or not candidate.get("source_authoring_artifact_preflight_template_id_match")
                or not candidate.get("source_authoring_artifact_preflight_anchor_contract_id_match")
                for candidate in ready_bodies
            ):
                _issue(
                    issues,
                    "source_theorem_proof_body_source_ready_without_authoring_artifact_preflight_pass_evidence",
                    item.get("expected_lean_proof_name") or "",
                )
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_boundary:{key}")
    return issues


def _lean_name(value, fallback):
    text = re.sub(r"[^A-Za-z0-9_]", "", str(value or fallback))
    if not text:
        text = fallback
    return f"{text[:1].lower()}{text[1:]}"


def _classifications_by_expected(intake_report):
    return {
        item.get("expected_lean_proof_name"): item
        for item in intake_report.get("source_theorem_proof_body_source_intake_classifications") or []
        if item.get("expected_lean_proof_name")
    }


def _authoring_items(implementation_items, intake_report):
    classifications = _classifications_by_expected(intake_report)
    items = []
    for index, item in enumerate(implementation_items, start=1):
        expected = item.get("expected_lean_proof_name") or f"sourceBackedPremiseTheorem{index}"
        classification = classifications.get(expected, {})
        ready_count = int(classification.get("source_theorem_proof_body_source_ready_count") or 0)
        candidate_count = int(classification.get("source_theorem_proof_body_source_candidate_count") or 0)
        vacuous_count = sum(int(candidate.get("vacuous_true_marker_count") or 0) for candidate in classification.get("candidate_bodies") or [])
        non_domain_count = sum(int(candidate.get("non_domain_statement_marker_count") or 0) for candidate in classification.get("candidate_bodies") or [])
        domain_statement_count = sum(1 for candidate in classification.get("candidate_bodies") or [] if int(candidate.get("domain_statement_marker_count") or 0))
        statement_contract_count = sum(int(candidate.get("statement_contract_marker_count") or 0) for candidate in classification.get("candidate_bodies") or [])
        statement_contract_mismatch_count = sum(int(candidate.get("statement_contract_mismatch_marker_count") or 0) for candidate in classification.get("candidate_bodies") or [])
        local_statement_contract_definition_count = sum(
            int(candidate.get("local_statement_contract_definition_marker_count") or 0)
            for candidate in classification.get("candidate_bodies") or []
        )
        lean_check_performed_count = sum(1 for candidate in classification.get("candidate_bodies") or [] if candidate.get("source_tree_lean_check_performed"))
        lean_check_pass_count = sum(1 for candidate in classification.get("candidate_bodies") or [] if candidate.get("source_tree_lean_exit_zero") and not candidate.get("source_tree_lean_check_timed_out"))
        lean_check_timeout_count = sum(1 for candidate in classification.get("candidate_bodies") or [] if candidate.get("source_tree_lean_check_timed_out"))
        lean_check_fail_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_tree_lean_check_performed") and not candidate.get("source_tree_lean_exit_zero")
        )
        preflight_ready_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_preflight_entry_present")
            and candidate.get("source_authorization_preflight_ready")
            and candidate.get("source_authorization_preflight_text_sha256_match")
            and candidate.get("source_authorization_preflight_template_id_match")
            and candidate.get("source_authorization_preflight_anchor_contract_id_match")
        )
        preflight_missing_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and not candidate.get("source_authorization_preflight_entry_present")
        )
        preflight_mismatch_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and candidate.get("source_authorization_preflight_entry_present")
            and not (
                candidate.get("source_authorization_preflight_ready")
                and candidate.get("source_authorization_preflight_text_sha256_match")
                and candidate.get("source_authorization_preflight_template_id_match")
                and candidate.get("source_authorization_preflight_anchor_contract_id_match")
            )
        )
        artifact_preflight_ready_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and candidate.get("source_authoring_artifact_preflight_entry_present")
            and candidate.get("source_authoring_artifact_preflight_ready")
            and candidate.get("source_authoring_artifact_preflight_text_sha256_match")
            and candidate.get("source_authoring_artifact_preflight_work_order_contract_match")
            and candidate.get("source_authoring_artifact_preflight_packet_contract_match")
            and candidate.get("source_authoring_artifact_preflight_template_id_match")
            and candidate.get("source_authoring_artifact_preflight_anchor_contract_id_match")
        )
        artifact_preflight_missing_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and not candidate.get("source_authoring_artifact_preflight_entry_present")
        )
        artifact_preflight_mismatch_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and candidate.get("source_authoring_artifact_preflight_entry_present")
            and not (
                candidate.get("source_authoring_artifact_preflight_ready")
                and candidate.get("source_authoring_artifact_preflight_text_sha256_match")
                and candidate.get("source_authoring_artifact_preflight_work_order_contract_match")
                and candidate.get("source_authoring_artifact_preflight_packet_contract_match")
                and candidate.get("source_authoring_artifact_preflight_template_id_match")
                and candidate.get("source_authoring_artifact_preflight_anchor_contract_id_match")
            )
        )
        ready = bool(ready_count)
        items.append(
            {
                "authoring_item_id": f"source-theorem-proof-body-source-authoring-{index:02d}-{expected}",
                "expected_lean_proof_name": expected,
                "expected_statement_field_name": classification.get("expected_statement_field_name") or "",
                "lean_premise_name": item.get("lean_premise_name") or classification.get("lean_premise_name") or "",
                "dispatch_group": item.get("dispatch_group") or classification.get("dispatch_group") or "",
                "source_labels": list(item.get("source_labels") or classification.get("source_labels") or []),
                "source_anchor_kinds": list(item.get("source_anchor_kinds") or classification.get("source_anchor_kinds") or []),
                "source_anchor_translation_ready": bool(item.get("source_anchor_translation_ready") or classification.get("source_anchor_translation_ready")),
                "source_theorem_statement_ready": bool(item.get("source_theorem_statement_ready") or classification.get("source_theorem_statement_ready")),
                "source_tree_proof_body_source_candidate_count": candidate_count,
                "source_tree_proof_body_source_ready_count": ready_count,
                "vacuous_true_body_candidate_count": vacuous_count,
                "non_domain_statement_body_candidate_count": non_domain_count,
                "domain_statement_body_candidate_count": domain_statement_count,
                "statement_contract_body_candidate_count": statement_contract_count,
                "statement_contract_mismatch_body_candidate_count": statement_contract_mismatch_count,
                "local_statement_contract_definition_body_candidate_count": local_statement_contract_definition_count,
                "source_tree_lean_check_performed_body_candidate_count": lean_check_performed_count,
                "source_tree_lean_check_pass_body_candidate_count": lean_check_pass_count,
                "source_tree_lean_check_fail_body_candidate_count": lean_check_fail_count,
                "source_tree_lean_check_timeout_body_candidate_count": lean_check_timeout_count,
                "source_authorization_preflight_ready_body_candidate_count": preflight_ready_count,
                "source_authorization_preflight_missing_body_candidate_count": preflight_missing_count,
                "source_authorization_preflight_mismatch_body_candidate_count": preflight_mismatch_count,
                "source_authoring_artifact_preflight_ready_body_candidate_count": artifact_preflight_ready_count,
                "source_authoring_artifact_preflight_missing_body_candidate_count": artifact_preflight_missing_count,
                "source_authoring_artifact_preflight_mismatch_body_candidate_count": artifact_preflight_mismatch_count,
                "vacuous_true_rejected_as_source_proof": bool(vacuous_count),
                "non_domain_statement_rejected_as_source_proof": bool(non_domain_count),
                "statement_contract_mismatch_rejected_as_source_proof": bool(statement_contract_mismatch_count),
                "local_statement_contract_definition_rejected_as_source_proof": bool(local_statement_contract_definition_count),
                "authoring_ready": ready,
                "authoring_blocking": not ready,
                "source_mutation_performed": False,
                "reintake_required_after_authoring": not ready,
                "required_output_kind": "source_tree_no_placeholder_nonvacuous_contract_bound_lean_proof_body_source",
                "must_not_use": [
                    "logs/paperctl/_batches generated Lean artifacts",
                    ".lake or dependency cache material",
                    "sorry/admit/axiom/opaque placeholders",
                    "vacuous : True theorem bodies",
                    "theorem bodies with mismatched source theorem statement contracts",
                    "theorem bodies that locally define their expected statement contract",
                    "field forwarding",
                    "statement assumption echo",
                    "premise assumption echo",
                    "source theorem assumption echo",
                    "skeleton theorem bodies",
                    "implementation plans or dispatch work items",
                ],
                "blocking_reason": "" if ready else (
                    "source-tree Lean theorem body locally defines its expected statement contract; imported/source-backed statement context is required"
                    if local_statement_contract_definition_count
                    else "source-tree nonvacuous no-placeholder proof body source bound to the expected source theorem statement contract has not been authored and reintaked"
                ),
                "next_required_action": "" if ready else f"author a source-tree nonvacuous no-placeholder Lean proof body source for {expected} with its expected statement contract, then rerun source-only intake",
            }
        )
    return items


def _lean_source(authoring_items):
    constructors = []
    fields = []
    theorem_args = []
    for item in authoring_items:
        expected = item.get("expected_lean_proof_name") or "sourceTheoremProofBodySource"
        constructor = _lean_name(expected, "sourceTheoremProofBodySource")
        field = f"{constructor}AuthoringBlocked"
        constructors.append(f"  | {constructor}")
        fields.append(f"  {field} : Prop")
        theorem_args.append(f"    (_h{field[:1].upper()}{field[1:]} : A.{field})")
    if not constructors:
        constructors.append("  | noSourceTheoremProofBodySourceAuthoring")
        fields.append("  noSourceTheoremProofBodySourceAuthoringBlocked : Prop")
        theorem_args.append("    (_hNoSourceTheoremProofBodySourceAuthoringBlocked : A.noSourceTheoremProofBodySourceAuthoringBlocked)")
    return """

namespace NSMAoSFormalization

noncomputable section

inductive ProfileEquivalencePremiseSourceTheoremProofBodySourceAuthoringTask where
  | authorSourceTreeBody
  | rejectGeneratedBody
  | rejectVacuousTrueBody
  | rejectAssumptionEcho
  | rerunSourceOnlyIntake
  | recheckPremiseBundle
  deriving DecidableEq, Repr

inductive ProfileEquivalencePremiseSourceTheoremProofBodySourceAuthoringName where
{constructors}
  deriving DecidableEq, Repr

structure ProfileEquivalencePremiseSourceTheoremProofBodySourceAuthoringReintakeObligation where
{fields}

theorem profileEquivalencePremiseSourceTheoremProofBodySourceAuthoringReintakeDraft
    (A : ProfileEquivalencePremiseSourceTheoremProofBodySourceAuthoringReintakeObligation)
{theorem_args} :
    True := by
  exact True.intro

end

end NSMAoSFormalization
""".format(
        constructors="\n".join(constructors),
        fields="\n".join(fields),
        theorem_args="\n".join(theorem_args),
    )


def _run_lean(source_info, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(source_info["path"])
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": False,
            "exit_code": 124,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report,
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report,
    output_root,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    implementation_plan_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report or {}
    intake_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _implementation_plan_issues(implementation_plan_report) + _intake_issues(intake_report)
    machine_checked = bool(implementation_plan_report.get("production_claim_machine_checked") or intake_report.get("production_claim_machine_checked"))
    implementation_items = list(implementation_plan_report.get("source_theorem_proof_body_source_implementation_items") or [])
    authoring_items = _authoring_items(implementation_items, intake_report)
    lean_text = _lean_source(authoring_items)
    output_root = pathlib.Path(output_root)
    source_info = _write_text(output_root / "ProfileEquivalencePremiseSourceTheoremProofBodySourceAuthoringReintake.lean", lean_text)
    lean_result = _run_lean(source_info, source_root_path, lean_executable, lake_executable, timeout_seconds, runner=runner)
    theorem_names = THEOREM_RE.findall(lean_text)
    structures = STRUCTURE_RE.findall(lean_text)
    inductives = INDUCTIVE_RE.findall(lean_text)
    placeholders = PLACEHOLDER_RE.findall(lean_text)
    expected_source_theorem_names = {item.get("expected_lean_proof_name") for item in authoring_items if item.get("expected_lean_proof_name")}
    expected_source_theorem_declarations = [name for name in theorem_names if name in expected_source_theorem_names]
    target_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    target_declarations.extend([name for name in structures if name == TARGET_STATEMENT_NAME])
    lean_exit_zero = bool(lean_result.get("exit_code") == 0 and not lean_result.get("timed_out"))
    ready_count = sum(1 for item in authoring_items if item.get("authoring_ready"))
    blocking_count = sum(1 for item in authoring_items if item.get("authoring_blocking"))
    authoring_ready = bool(lean_exit_zero and authoring_items and AUTHORING_REINTAKE_THEOREM_NAME in theorem_names and not expected_source_theorem_declarations and not target_declarations and not placeholders)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report_consumable", not _implementation_plan_issues(implementation_plan_report), "source_body_source_implementation_plan_report_not_consumable"),
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_consumable", not _intake_issues(intake_report), "source_body_source_intake_report_not_consumable"),
        _check("source_theorem_proof_body_source_authoring_items_present", bool(authoring_items), "authoring_items_missing"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("authoring_reintake_theorem_present", AUTHORING_REINTAKE_THEOREM_NAME in theorem_names, "authoring_reintake_theorem_missing"),
        _check("no_expected_source_theorem_declarations", not expected_source_theorem_declarations, "expected_source_theorem_declared_by_authoring_plan"),
        _check("target_theorem_not_declared", not target_declarations, "target_theorem_or_statement_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("authoring_blocking_recorded", bool(blocking_count) or machine_checked, "authoring_blocking_missing", severity="readiness"),
        _check("source_authoring_not_synthesized", not implementation_plan_report.get("source_mutation_performed") and not intake_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not implementation_plan_report.get("external_action_performed") and not intake_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif authoring_ready:
        status = "PASS"
        state = AUTHORING_REINTAKE_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_manual_authoring" if blocking_count else "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck"
        next_agent_command = "" if blocking_count else BUNDLE_RECHECK_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    reintake_command_packet = {
        "command": SOURCE_INTAKE_COMMAND,
        "requires_after_authoring": bool(blocking_count),
        "implementation_plan_report_path": intake_report.get("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_path") or "",
        "source_root": str(source_root_path),
        "reason": "rerun source-only proof-body-source intake after source-tree authoring creates nonvacuous no-placeholder proof body sources bound to the expected statement contracts",
    }
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": True,
        "prover_execution_performed": True,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_targets_ready": bool(status == "PASS" and authoring_items),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": False,
        "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready": False,
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_result.get("selected_lean") or "",
        "lake_executable_path": lean_result.get("selected_lake") or "",
        "lake_env_used": bool(lean_result.get("lake_env_used")),
        "lean_exit_code": lean_result.get("exit_code"),
        "lean_source_path": source_info["path"],
        "claim_packet_id": implementation_plan_report.get("claim_packet_id") or intake_report.get("claim_packet_id") or "",
        "slug": implementation_plan_report.get("slug") or intake_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report_path": implementation_plan_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report_sha256": implementation_plan_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_path": intake_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_body_source_implementation_item_count": len(implementation_items),
            "source_theorem_proof_body_source_authoring_item_count": len(authoring_items),
            "authoring_ready_count": ready_count,
            "authoring_blocking_count": blocking_count,
            "source_tree_proof_body_source_candidate_count": sum(int(item.get("source_tree_proof_body_source_candidate_count") or 0) for item in authoring_items),
            "source_tree_proof_body_source_ready_count": sum(int(item.get("source_tree_proof_body_source_ready_count") or 0) for item in authoring_items),
            "source_tree_proof_body_source_missing_count": max(len(authoring_items) - ready_count, 0),
            "vacuous_true_body_candidate_count": sum(int(item.get("vacuous_true_body_candidate_count") or 0) for item in authoring_items),
            "non_domain_statement_body_candidate_count": sum(int(item.get("non_domain_statement_body_candidate_count") or 0) for item in authoring_items),
            "domain_statement_body_candidate_count": sum(int(item.get("domain_statement_body_candidate_count") or 0) for item in authoring_items),
            "statement_contract_body_candidate_count": sum(int(item.get("statement_contract_body_candidate_count") or 0) for item in authoring_items),
            "statement_contract_mismatch_body_candidate_count": sum(int(item.get("statement_contract_mismatch_body_candidate_count") or 0) for item in authoring_items),
            "local_statement_contract_definition_body_candidate_count": sum(int(item.get("local_statement_contract_definition_body_candidate_count") or 0) for item in authoring_items),
            "source_tree_lean_check_performed_body_candidate_count": sum(int(item.get("source_tree_lean_check_performed_body_candidate_count") or 0) for item in authoring_items),
            "source_tree_lean_check_pass_body_candidate_count": sum(int(item.get("source_tree_lean_check_pass_body_candidate_count") or 0) for item in authoring_items),
            "source_tree_lean_check_fail_body_candidate_count": sum(int(item.get("source_tree_lean_check_fail_body_candidate_count") or 0) for item in authoring_items),
            "source_tree_lean_check_timeout_body_candidate_count": sum(int(item.get("source_tree_lean_check_timeout_body_candidate_count") or 0) for item in authoring_items),
            "source_authorization_preflight_ready_body_candidate_count": sum(int(item.get("source_authorization_preflight_ready_body_candidate_count") or 0) for item in authoring_items),
            "source_authorization_preflight_missing_body_candidate_count": sum(int(item.get("source_authorization_preflight_missing_body_candidate_count") or 0) for item in authoring_items),
            "source_authorization_preflight_mismatch_body_candidate_count": sum(int(item.get("source_authorization_preflight_mismatch_body_candidate_count") or 0) for item in authoring_items),
            "source_authoring_artifact_preflight_ready_body_candidate_count": sum(int(item.get("source_authoring_artifact_preflight_ready_body_candidate_count") or 0) for item in authoring_items),
            "source_authoring_artifact_preflight_missing_body_candidate_count": sum(int(item.get("source_authoring_artifact_preflight_missing_body_candidate_count") or 0) for item in authoring_items),
            "source_authoring_artifact_preflight_mismatch_body_candidate_count": sum(int(item.get("source_authoring_artifact_preflight_mismatch_body_candidate_count") or 0) for item in authoring_items),
            "expected_source_theorem_declaration_count": len(expected_source_theorem_declarations),
            "target_theorem_declaration_count": len(target_declarations),
            "lean_structure_count": len(structures),
            "lean_inductive_count": len(inductives),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "authoring_reintake_theorem_count": 1 if AUTHORING_REINTAKE_THEOREM_NAME in theorem_names else 0,
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_result.get("command") or [],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_result.get("exit_code"),
            "timed_out": bool(lean_result.get("timed_out")),
            "stdout": lean_result.get("stdout") or "",
            "stderr": lean_result.get("stderr") or "",
            "structure_names": structures,
            "inductive_names": inductives,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "expected_source_theorem_declaration_count": len(expected_source_theorem_declarations),
            "target_theorem_declaration_count": len(target_declarations),
        },
        "source_theorem_proof_body_source_authoring_reintake_items": authoring_items,
        "reintake_command_packet": reintake_command_packet,
        "formalization_route": [
            {
                "step_id": "lean_authoring_reintake_obligation_taxonomy",
                "status": "ready" if authoring_ready else "attention",
                "output": "Lean checks a taxonomy for authoring/reintake obligations without declaring sourceBacked theorems",
            },
            {
                "step_id": "manual_source_tree_authoring",
                "status": "blocked_on_source_backed_proof_body_sources" if blocking_count else "ready",
                "output": "author nonvacuous no-placeholder source-tree proof body sources for the 10 expected sourceBacked theorems with their expected statement contracts",
            },
            {
                "step_id": "source_only_reintake",
                "status": "pending",
                "output": "rerun source-only intake after source-tree proof body sources exist",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_implementation_plan_report": implementation_plan_report,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_report": intake_report,
        "boundary": [
            "This command records authoring/reintake obligations only; it does not synthesize source proof body sources.",
            "It declares no sourceBacked expected theorem, no ProfileEquivalenceTransfersDirectScoreLimitStatement, and no target theorem.",
            "Vacuous : True bodies, non-domain statements, statement-contract mismatches, locally defined statement contracts, generated logs, source anchors alone, skeleton bodies, placeholders, field forwarding, statement assumptions, premise assumptions, source theorem assumption echo, and work items remain rejected as proof.",
            "It writes only local draft/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Body Source Authoring/Reintake",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_reintake_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Authoring items: {summary.get('source_theorem_proof_body_source_authoring_item_count', 0)}",
        f"- Blocking items: {summary.get('authoring_blocking_count', 0)}",
        f"- Ready proof body sources: {summary.get('source_tree_proof_body_source_ready_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
