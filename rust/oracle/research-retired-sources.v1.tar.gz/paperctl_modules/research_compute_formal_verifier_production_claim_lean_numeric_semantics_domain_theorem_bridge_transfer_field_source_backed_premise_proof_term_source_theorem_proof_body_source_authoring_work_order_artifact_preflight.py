"""Preflight authored proof-body source artifacts against work orders."""

import hashlib
import json
import os
import pathlib

from paperctl_modules import research_compute_formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch as work_order_dispatch_core
from paperctl_modules import research_compute_formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight as authorization_preflight_core


WORK_ORDER_DISPATCH_COMMAND = work_order_dispatch_core.COMMAND
COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-work-order-artifact-preflight"

WORK_ORDER_DISPATCH_READY_STATE = work_order_dispatch_core.READY_STATE
ARTIFACT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_ARTIFACT_PREFLIGHT_ARTIFACT_REQUIRED"
ARTIFACT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_ARTIFACT_PREFLIGHT_ARTIFACT_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_ARTIFACT_PREFLIGHT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_ARTIFACT_PREFLIGHT_FAILED"

SOURCE_AUTHORIZATION_SCOPE = authorization_preflight_core.SOURCE_AUTHORIZATION_SCOPE
SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID = authorization_preflight_core.SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID
SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID = authorization_preflight_core.SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID
SOURCE_AUTHORIZATION_MANIFEST_FILENAMES = authorization_preflight_core.SOURCE_AUTHORIZATION_MANIFEST_FILENAMES
EXCLUDED_DIR_NAMES = authorization_preflight_core.EXCLUDED_DIR_NAMES

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_artifacts_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "source_authoring_artifact_consumable_as_authorization_manifest",
    "source_authoring_artifact_consumable_as_lean_source",
    "source_authoring_artifact_consumable_as_proof_source",
    "claim_packet_id",
    "slug",
    "source_root",
    "source_authorization_manifest_paths",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "next_agent_command_precondition",
    "summary",
    "checks",
    "validation_issues",
    "source_theorem_proof_body_source_authoring_artifact_preflight_items",
    "source_authorization_manifests",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_authoring_work_order_count",
    "source_authoring_artifact_preflight_item_count",
    "source_authoring_artifact_preflight_ready_item_count",
    "source_authorization_manifest_count",
    "source_authorization_manifest_entry_count",
    "source_authorization_manifest_missing_item_count",
    "source_authorization_not_marked_authorized_item_count",
    "source_authorization_scope_mismatch_item_count",
    "source_authorization_work_order_id_mismatch_item_count",
    "source_authorization_work_order_payload_mismatch_item_count",
    "source_authorization_template_mismatch_item_count",
    "source_authorization_anchor_contract_mismatch_item_count",
    "source_authorization_statement_mismatch_item_count",
    "source_authorization_source_labels_mismatch_item_count",
    "source_authorization_audit_metadata_missing_item_count",
    "source_authorization_source_file_missing_item_count",
    "source_authorization_text_hash_match_item_count",
    "source_authorization_text_hash_mismatch_item_count",
    "source_authoring_artifact_consumable_as_authorization_manifest_count",
    "source_authoring_artifact_consumable_as_lean_source_count",
    "source_authoring_artifact_consumable_as_proof_source_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_artifacts_ready_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Consumes source proof-body authoring work orders and validates local Lean source plus authorization manifest artifacts against them.",
    "This command is read-only and does not run Lean; source-body-source intake must still perform declaration shape and Lean checks.",
    "Artifact-preflight readiness is not proof-body-source readiness, proof-term readiness, or machine-checked theorem readiness.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _relative_path(path, source_root):
    candidate = pathlib.Path(path or "")
    root = pathlib.Path(source_root or ".").resolve()
    try:
        return str(candidate.resolve().relative_to(root))
    except (OSError, ValueError):
        return str(candidate)


def _safe_relative_source_path(value):
    path = pathlib.PurePosixPath(str(value or ""))
    return bool(str(path)) and not path.is_absolute() and ".." not in path.parts and str(path) != "."


def _work_order_dispatch_issues(report):
    issues = []
    if not report:
        _issue(issues, "source_authoring_work_order_dispatch_report_missing")
        return issues
    if report.get("command") != WORK_ORDER_DISPATCH_COMMAND:
        _issue(issues, "source_authoring_work_order_dispatch_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "source_authoring_work_order_dispatch_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_state") or ""
    if state != WORK_ORDER_DISPATCH_READY_STATE:
        _issue(issues, "source_authoring_work_order_dispatch_state_not_ready", state)
    if not report.get("profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_work_orders_ready"):
        _issue(issues, "source_authoring_work_orders_ready_flag_missing")
    if not report.get("source_theorem_proof_body_source_authoring_work_orders"):
        _issue(issues, "source_authoring_work_orders_missing")
    if report.get("source_authoring_work_order_consumable_as_authorization_manifest"):
        _issue(issues, "source_authoring_work_order_consumable_as_authorization_manifest")
    if report.get("source_authoring_work_order_consumable_as_lean_source"):
        _issue(issues, "source_authoring_work_order_consumable_as_lean_source")
    if report.get("source_authoring_work_order_consumable_as_proof_source"):
        _issue(issues, "source_authoring_work_order_consumable_as_proof_source")
    for key in [
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
        "profile_equivalence_transfer_source_backed_proof_source_ready",
        "profile_equivalence_transfer_target_theorem_proved",
        "production_claim_machine_checked",
    ]:
        if report.get(key):
            _issue(issues, f"source_authoring_work_order_dispatch_premature_{key}")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_source_authoring_work_order_dispatch:{key}")
    return issues


def _work_order_item_issues(item):
    issues = []
    expected = item.get("expected_lean_proof_name") or ""
    for key in [
        "source_authoring_work_order_id",
        "source_authoring_work_order_payload_sha256",
        "source_authoring_packet_id",
        "source_authoring_packet_payload_sha256",
        "expected_lean_proof_name",
        "expected_statement_field_name",
        "expected_source_tree_relative_path",
        "source_authorization_template_id",
        "source_authorization_template_sha256",
        "source_anchor_binding_contract_id",
        "source_anchor_binding_contract_sha256",
    ]:
        if not item.get(key):
            _issue(issues, f"source_authoring_work_order_item_{key}_missing", expected)
    if not item.get("source_labels"):
        _issue(issues, "source_authoring_work_order_item_source_labels_missing", expected)
    if not item.get("source_authorization_manifest_template"):
        _issue(issues, "source_authoring_work_order_item_authorization_manifest_template_missing", expected)
    if not item.get("source_anchor_binding_contract_payload"):
        _issue(issues, "source_authoring_work_order_item_anchor_contract_payload_missing", expected)
    if not _safe_relative_source_path(item.get("expected_source_tree_relative_path") or ""):
        _issue(issues, "source_authoring_work_order_item_expected_source_path_unsafe", expected)
    if item.get("source_body_source_ready"):
        _issue(issues, "source_authoring_work_order_item_source_body_source_ready_premature", expected)
    if item.get("source_backed_proof_source_ready"):
        _issue(issues, "source_authoring_work_order_item_source_backed_proof_source_ready_premature", expected)
    if item.get("machine_checked"):
        _issue(issues, "source_authoring_work_order_item_machine_checked_premature", expected)
    if item.get("source_authoring_work_order_consumable_as_authorization_manifest"):
        _issue(issues, "source_authoring_work_order_item_consumable_as_authorization_manifest", expected)
    if item.get("source_authoring_work_order_consumable_as_lean_source"):
        _issue(issues, "source_authoring_work_order_item_consumable_as_lean_source", expected)
    if item.get("source_authoring_work_order_consumable_as_proof_source"):
        _issue(issues, "source_authoring_work_order_item_consumable_as_proof_source", expected)
    return issues


def _bounded_authorization_manifest_paths(source_root, expected_source_paths):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    candidate_dirs = {root}
    for expected_path in expected_source_paths or []:
        if not _safe_relative_source_path(expected_path):
            continue
        expected = (root / str(expected_path)).resolve()
        try:
            expected.relative_to(root)
        except ValueError:
            continue
        candidate_dirs.add(expected.parent)
    candidates = []
    for directory in sorted(candidate_dirs):
        for filename in sorted(SOURCE_AUTHORIZATION_MANIFEST_FILENAMES):
            path = directory / filename
            if path.is_file():
                candidates.append(path)
    return sorted(set(candidates))


def _walk_authorization_manifests(source_root, expected_source_paths=None):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    if expected_source_paths is not None:
        return _bounded_authorization_manifest_paths(root, expected_source_paths)
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
        for filename in filenames:
            if filename not in SOURCE_AUTHORIZATION_MANIFEST_FILENAMES:
                continue
            path = pathlib.Path(dirpath) / filename
            if path.is_file():
                files.append(path)
    return sorted(files)


def _scan_authorization_manifests(source_root, expected_source_paths=None):
    root = pathlib.Path(source_root or ".").resolve()
    manifests = []
    entries = {}
    issues = []
    for path in _walk_authorization_manifests(root, expected_source_paths=expected_source_paths):
        rel_path = _relative_path(path, root)
        try:
            payload = json.loads(path.read_text(errors="replace"))
        except json.JSONDecodeError as exc:
            _issue(issues, "source_authoring_artifact_manifest_invalid_json", f"{rel_path}:{exc}")
            manifests.append({"path": rel_path, "valid": False, "authorization_scope": "", "entry_count": 0})
            continue
        scope = str(payload.get("authorization_scope") or payload.get("scope") or "")
        if scope != SOURCE_AUTHORIZATION_SCOPE:
            _issue(issues, "source_authoring_artifact_manifest_scope_mismatch", rel_path)
        source_entries = payload.get("authorized_sources") or []
        if not isinstance(source_entries, list):
            _issue(issues, "source_authoring_artifact_manifest_sources_not_list", rel_path)
            source_entries = []
        valid_entry_count = 0
        for entry in source_entries:
            if not isinstance(entry, dict):
                _issue(issues, "source_authoring_artifact_manifest_entry_not_object", rel_path)
                continue
            source_path = str(entry.get("path") or entry.get("source_path") or "")
            expected_name = str(entry.get("expected_lean_proof_name") or entry.get("lean_declaration_name") or "")
            if not source_path or not expected_name:
                _issue(issues, "source_authoring_artifact_manifest_entry_missing_path_or_name", rel_path)
                continue
            entries[(source_path, expected_name)] = {
                "manifest_path": rel_path,
                "authorization_scope": scope,
                "authorized": bool(entry.get("authorized")),
                "path": source_path,
                "expected_lean_proof_name": expected_name,
                "expected_statement_field_name": str(entry.get("expected_statement_field_name") or ""),
                "text_sha256": str(entry.get("text_sha256") or entry.get("source_text_sha256") or ""),
                "source_labels": list(entry.get("source_labels") or []),
                "source_authorization_template_schema_id": str(entry.get("source_authorization_template_schema_id") or ""),
                "source_authorization_template_id": str(entry.get("source_authorization_template_id") or ""),
                "source_authorization_template_sha256": str(entry.get("source_authorization_template_sha256") or ""),
                "source_anchor_binding_contract_schema_id": str(entry.get("source_anchor_binding_contract_schema_id") or ""),
                "source_anchor_binding_contract_id": str(entry.get("source_anchor_binding_contract_id") or ""),
                "source_anchor_binding_contract_sha256": str(entry.get("source_anchor_binding_contract_sha256") or ""),
                "source_authoring_work_order_id": str(entry.get("source_authoring_work_order_id") or ""),
                "source_authoring_work_order_payload_sha256": str(entry.get("source_authoring_work_order_payload_sha256") or ""),
                "source_authoring_packet_id": str(entry.get("source_authoring_packet_id") or ""),
                "source_authoring_packet_payload_sha256": str(entry.get("source_authoring_packet_payload_sha256") or ""),
                "operator_id": str(entry.get("operator_id") or ""),
                "authorization_ref": str(entry.get("authorization_ref") or ""),
            }
            valid_entry_count += 1
        manifests.append(
            {
                "path": rel_path,
                "valid": bool(scope == SOURCE_AUTHORIZATION_SCOPE),
                "authorization_scope": scope,
                "entry_count": valid_entry_count,
            }
        )
    return manifests, entries, issues


def _source_file_hash(source_root, relative_path):
    if not _safe_relative_source_path(relative_path):
        return "", False
    root = pathlib.Path(source_root or ".").resolve()
    path = (root / str(relative_path or "")).resolve()
    try:
        path.relative_to(root)
    except ValueError:
        return "", False
    if not path.is_file():
        return "", False
    return _sha256_text(path.read_text(errors="replace")), True


def _artifact_item(work_order, entries, source_root):
    expected_path = work_order.get("expected_source_tree_relative_path") or ""
    expected_name = work_order.get("expected_lean_proof_name") or ""
    expected_path_safe = _safe_relative_source_path(expected_path)
    entry = entries.get((expected_path, expected_name)) or {}
    expected_labels = set(work_order.get("source_labels") or [])
    entry_labels = set(entry.get("source_labels") or [])
    source_hash, source_file_present = _source_file_hash(source_root, expected_path)
    entry_present = bool(entry)
    authorized_mark = bool(entry.get("authorized"))
    scope_match = entry.get("authorization_scope") == SOURCE_AUTHORIZATION_SCOPE
    path_match = entry.get("path") == expected_path
    statement_match = entry.get("expected_statement_field_name") == (work_order.get("expected_statement_field_name") or "")
    labels_match = bool(not expected_labels or expected_labels.issubset(entry_labels))
    audit_metadata_present = bool(entry.get("operator_id") and entry.get("authorization_ref"))
    template_schema_match = entry.get("source_authorization_template_schema_id") == SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID
    template_id_match = entry.get("source_authorization_template_id") == (work_order.get("source_authorization_template_id") or "")
    template_sha_match = entry.get("source_authorization_template_sha256") == (work_order.get("source_authorization_template_sha256") or "")
    anchor_schema_match = entry.get("source_anchor_binding_contract_schema_id") == SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID
    anchor_id_match = entry.get("source_anchor_binding_contract_id") == (work_order.get("source_anchor_binding_contract_id") or "")
    anchor_sha_match = entry.get("source_anchor_binding_contract_sha256") == (work_order.get("source_anchor_binding_contract_sha256") or "")
    work_order_id_match = entry.get("source_authoring_work_order_id") == (work_order.get("source_authoring_work_order_id") or "")
    work_order_payload_match = entry.get("source_authoring_work_order_payload_sha256") == (work_order.get("source_authoring_work_order_payload_sha256") or "")
    packet_id_match = entry.get("source_authoring_packet_id") == (work_order.get("source_authoring_packet_id") or "")
    packet_payload_match = entry.get("source_authoring_packet_payload_sha256") == (work_order.get("source_authoring_packet_payload_sha256") or "")
    hash_match = bool(source_file_present and entry.get("text_sha256") and entry.get("text_sha256") == source_hash)
    ready = bool(
        entry_present
        and expected_path_safe
        and authorized_mark
        and scope_match
        and path_match
        and statement_match
        and labels_match
        and audit_metadata_present
        and template_schema_match
        and template_id_match
        and template_sha_match
        and anchor_schema_match
        and anchor_id_match
        and anchor_sha_match
        and work_order_id_match
        and work_order_payload_match
        and packet_id_match
        and packet_payload_match
        and source_file_present
        and hash_match
    )
    if ready:
        reason = ""
    elif not expected_path_safe:
        reason = "expected source path is unsafe"
    elif not entry_present:
        reason = "source authorization manifest entry missing"
    elif not authorized_mark:
        reason = "source authorization manifest entry is not marked authorized"
    elif not scope_match:
        reason = "source authorization manifest scope mismatch"
    elif not path_match:
        reason = "source authorization manifest path mismatch"
    elif not statement_match:
        reason = "source authorization manifest statement contract mismatch"
    elif not labels_match:
        reason = "source authorization manifest source labels do not cover expected labels"
    elif not audit_metadata_present:
        reason = "source authorization manifest lacks operator_id or authorization_ref"
    elif not template_schema_match or not template_id_match or not template_sha_match:
        reason = "source authorization manifest template contract mismatch"
    elif not anchor_schema_match or not anchor_id_match or not anchor_sha_match:
        reason = "source authorization manifest source-anchor binding contract mismatch"
    elif not work_order_id_match or not work_order_payload_match:
        reason = "source authorization manifest work-order contract mismatch"
    elif not packet_id_match or not packet_payload_match:
        reason = "source authorization manifest authoring-packet contract mismatch"
    elif not source_file_present:
        reason = "authorized Lean source file is missing"
    else:
        reason = "source authorization manifest text_sha256 does not match Lean source file"
    return {
        "rank": int(work_order.get("rank") or 0),
        "source_authoring_work_order_id": work_order.get("source_authoring_work_order_id") or "",
        "source_authoring_work_order_payload_sha256": work_order.get("source_authoring_work_order_payload_sha256") or "",
        "source_authoring_packet_id": work_order.get("source_authoring_packet_id") or "",
        "source_authoring_packet_payload_sha256": work_order.get("source_authoring_packet_payload_sha256") or "",
        "expected_lean_proof_name": expected_name,
        "expected_statement_field_name": work_order.get("expected_statement_field_name") or "",
        "expected_source_tree_relative_path": expected_path,
        "expected_source_tree_relative_path_safe": expected_path_safe,
        "source_labels": list(work_order.get("source_labels") or []),
        "source_authorization_manifest_path": entry.get("manifest_path") or "",
        "source_authorization_entry_present": entry_present,
        "source_authorization_marked_authorized": authorized_mark,
        "source_authorization_scope_match": scope_match,
        "source_authorization_path_match": path_match,
        "source_authorization_statement_contract_match": statement_match,
        "source_authorization_source_labels_match": labels_match,
        "source_authorization_audit_metadata_present": audit_metadata_present,
        "source_authorization_template_schema_id_match": template_schema_match,
        "source_authorization_template_id_match": template_id_match,
        "source_authorization_template_sha256_match": template_sha_match,
        "source_anchor_binding_contract_schema_id_match": anchor_schema_match,
        "source_anchor_binding_contract_id_match": anchor_id_match,
        "source_anchor_binding_contract_sha256_match": anchor_sha_match,
        "source_authorization_work_order_id_match": work_order_id_match,
        "source_authorization_work_order_payload_sha256_match": work_order_payload_match,
        "source_authorization_packet_id_match": packet_id_match,
        "source_authorization_packet_payload_sha256_match": packet_payload_match,
        "source_file_present": source_file_present,
        "source_file_text_sha256": source_hash,
        "source_authorization_text_sha256": entry.get("text_sha256") or "",
        "source_authorization_text_sha256_match": hash_match,
        "source_authoring_artifact_preflight_ready": ready,
        "source_body_source_ready": False,
        "source_backed_proof_source_ready": False,
        "machine_checked": False,
        "source_authoring_artifact_consumable_as_authorization_manifest": False,
        "source_authoring_artifact_consumable_as_lean_source": False,
        "source_authoring_artifact_consumable_as_proof_source": False,
        "blocking_reason": reason,
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report,
    source_root=".",
    label=None,
):
    work_order_dispatch_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _work_order_dispatch_issues(work_order_dispatch_report)
    work_orders = list(work_order_dispatch_report.get("source_theorem_proof_body_source_authoring_work_orders") or [])
    for item in work_orders:
        validation_issues.extend(_work_order_item_issues(item))
    expected_source_paths = [item.get("expected_source_tree_relative_path") or "" for item in work_orders]
    manifests, entries, manifest_issues = _scan_authorization_manifests(source_root_path, expected_source_paths=expected_source_paths)
    validation_issues.extend(manifest_issues)
    artifact_items = [_artifact_item(item, entries, source_root_path) for item in work_orders]
    ready_count = sum(1 for item in artifact_items if item.get("source_authoring_artifact_preflight_ready"))
    all_ready = bool(artifact_items and ready_count == len(artifact_items))
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    missing_required_report = any(item.get("issue") == "source_authoring_work_order_dispatch_report_missing" for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif missing_required_report or not work_orders or validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif all_ready:
        status = "PASS"
        state = ARTIFACT_READY_STATE
    else:
        status = "PASS"
        state = ARTIFACT_REQUIRED_STATE
    checks = [
        _check("source_authoring_work_order_dispatch_report_consumable", not _work_order_dispatch_issues(work_order_dispatch_report), "source_authoring_work_order_dispatch_report_not_consumable"),
        _check("source_authoring_work_orders_present", bool(work_orders), "source_authoring_work_orders_missing"),
        _check("source_authoring_work_orders_have_contracts", not [issue for item in work_orders for issue in _work_order_item_issues(item)], "source_authoring_work_order_contract_missing"),
        _check("source_authoring_artifacts_ready", all_ready, "source_authoring_artifacts_not_ready", severity="readiness"),
        _check("source_authoring_artifact_not_authorization_manifest", True, ""),
        _check("source_authoring_artifact_not_lean_source", True, ""),
        _check("source_authoring_artifact_not_proof_source", True, ""),
    ]
    return {
        "created_at": "",
        "command": COMMAND,
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_state": state,
        "label": label or "",
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_artifacts_ready": bool(status == "PASS" and all_ready),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": False,
        "production_claim_machine_checked": False,
        "source_authoring_artifact_consumable_as_authorization_manifest": False,
        "source_authoring_artifact_consumable_as_lean_source": False,
        "source_authoring_artifact_consumable_as_proof_source": False,
        "claim_packet_id": work_order_dispatch_report.get("claim_packet_id") or "",
        "slug": work_order_dispatch_report.get("slug") or "",
        "source_root": str(source_root_path),
        "source_authorization_manifest_paths": [item.get("path") or "" for item in manifests],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report_path": work_order_dispatch_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report_sha256": work_order_dispatch_report.get("report_sha256") or "",
        "next_agent_stage": "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight",
        "next_agent_command": authorization_preflight_core.COMMAND,
        "next_agent_command_precondition": "artifact preflight ready; rerun authorization-preflight and then source-body-source intake with local Lean check",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_authoring_work_order_count": len(work_orders),
            "source_authoring_artifact_preflight_item_count": len(artifact_items),
            "source_authoring_artifact_preflight_ready_item_count": ready_count,
            "source_authorization_manifest_count": len(manifests),
            "source_authorization_manifest_entry_count": len(entries),
            "source_authorization_manifest_missing_item_count": sum(1 for item in artifact_items if not item.get("source_authorization_entry_present")),
            "source_authorization_not_marked_authorized_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_marked_authorized")),
            "source_authorization_scope_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_scope_match")),
            "source_authorization_work_order_id_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_work_order_id_match")),
            "source_authorization_work_order_payload_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_work_order_payload_sha256_match")),
            "source_authorization_template_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and (not item.get("source_authorization_template_schema_id_match") or not item.get("source_authorization_template_id_match") or not item.get("source_authorization_template_sha256_match"))),
            "source_authorization_anchor_contract_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and (not item.get("source_anchor_binding_contract_schema_id_match") or not item.get("source_anchor_binding_contract_id_match") or not item.get("source_anchor_binding_contract_sha256_match"))),
            "source_authorization_statement_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_statement_contract_match")),
            "source_authorization_source_labels_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_source_labels_match")),
            "source_authorization_audit_metadata_missing_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_audit_metadata_present")),
            "source_authorization_source_file_missing_item_count": sum(1 for item in artifact_items if not item.get("source_file_present")),
            "source_authorization_text_hash_match_item_count": sum(1 for item in artifact_items if item.get("source_authorization_text_sha256_match")),
            "source_authorization_text_hash_mismatch_item_count": sum(1 for item in artifact_items if item.get("source_authorization_entry_present") and item.get("source_file_present") and not item.get("source_authorization_text_sha256_match")),
            "source_authoring_artifact_consumable_as_authorization_manifest_count": 0,
            "source_authoring_artifact_consumable_as_lean_source_count": 0,
            "source_authoring_artifact_consumable_as_proof_source_count": 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_artifacts_ready_count": 1 if (status == "PASS" and all_ready) else 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count": 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_theorem_proof_body_source_authoring_artifact_preflight_items": artifact_items,
        "source_authorization_manifests": manifests,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_report": work_order_dispatch_report,
        "boundary": [
            "This command reads local Lean source files only to compute text_sha256 and compares authorization manifests to source authoring work-order ids/hashes.",
            "It does not run Lean, author source files, create or modify authorization manifests, mutate manuscript/source packages, or promote proof readiness.",
            "Artifact-preflight readiness is not proof-body-source readiness, proof-term readiness, proof-source readiness, or machine-checked theorem readiness.",
            "Authorization-preflight and source-body-source intake must still verify the manifest, source shape, statement contract, placeholder rejection, and local Lean check.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source theorem proof body source authoring work-order artifact preflight",
        "",
        f"- Status: `{report.get('status')}`",
        f"- State: `{report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_state')}`",
        f"- Work orders: {summary.get('source_authoring_work_order_count', 0)}",
        f"- Artifact-ready items: {summary.get('source_authoring_artifact_preflight_ready_item_count', 0)}",
        f"- Authorization manifests: {summary.get('source_authorization_manifest_count', 0)}",
        f"- Missing manifest entries: {summary.get('source_authorization_manifest_missing_item_count', 0)}",
        f"- Missing source files: {summary.get('source_authorization_source_file_missing_item_count', 0)}",
        f"- Consumable as proof source: `{report.get('source_authoring_artifact_consumable_as_proof_source')}`",
        "",
        "## Blocking Items",
    ]
    for item in report.get("source_theorem_proof_body_source_authoring_artifact_preflight_items") or []:
        if item.get("source_authoring_artifact_preflight_ready"):
            continue
        lines.append(
            f"- rank {item.get('rank')}: `{item.get('expected_lean_proof_name')}` -> `{item.get('expected_source_tree_relative_path')}` reason={item.get('blocking_reason')}"
        )
    return "\n".join(lines) + "\n"
