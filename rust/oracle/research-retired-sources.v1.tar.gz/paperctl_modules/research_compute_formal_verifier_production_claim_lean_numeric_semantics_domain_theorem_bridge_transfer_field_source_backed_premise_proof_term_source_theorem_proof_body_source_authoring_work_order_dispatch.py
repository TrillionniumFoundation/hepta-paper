"""Dispatch read-only proof-body source authoring work orders."""

import hashlib
import json

from paperctl_modules import research_compute_formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet as authoring_packet_core


AUTHORING_PACKET_COMMAND = authoring_packet_core.COMMAND
COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-work-order-dispatch"

AUTHORING_PACKET_READY_STATE = authoring_packet_core.AUTHORING_PACKET_READY_STATE
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_DISPATCH_READY"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_DISPATCH_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_DISPATCH_FAILED"

WORK_ORDER_SCHEMA_ID = "paper_factory.source_tree_proof_body_source_authoring_work_order.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_work_orders_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "source_authoring_work_order_consumable_as_authorization_manifest",
    "source_authoring_work_order_consumable_as_lean_source",
    "source_authoring_work_order_consumable_as_proof_source",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "next_agent_command_precondition",
    "summary",
    "checks",
    "validation_issues",
    "source_theorem_proof_body_source_authoring_work_orders",
    "work_order_runbook",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_authoring_packet_count",
    "source_authoring_packet_ready_count",
    "source_authoring_work_order_count",
    "source_authoring_work_order_ready_count",
    "source_authoring_work_order_required_count",
    "source_authorization_manifest_required_count",
    "source_authorization_manifest_missing_work_order_count",
    "source_file_missing_work_order_count",
    "source_intake_ready_body_count",
    "source_authorization_preflight_ready_item_count",
    "source_authoring_work_order_consumable_as_authorization_manifest_count",
    "source_authoring_work_order_consumable_as_lean_source_count",
    "source_authoring_work_order_consumable_as_proof_source_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_work_orders_ready_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Consumes a source proof-body authoring-packet report and dispatches per-theorem authoring work orders.",
    "Work orders are human execution checklists only; they are not authorization manifests, Lean source files, proof sources, or proof-readiness evidence.",
    "A later authorization-preflight and source-body-source intake run must still verify the real local manifest, source hash, and Lean check.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _sha256_json(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _packet_report_issues(report):
    issues = []
    if not report:
        _issue(issues, "source_authoring_packet_report_missing")
        return issues
    if report.get("command") != AUTHORING_PACKET_COMMAND:
        _issue(issues, "source_authoring_packet_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "source_authoring_packet_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_state") or ""
    if state != AUTHORING_PACKET_READY_STATE:
        _issue(issues, "source_authoring_packet_state_not_ready", state)
    if not report.get("profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_packet_ready"):
        _issue(issues, "source_authoring_packet_ready_flag_missing")
    if not report.get("source_theorem_proof_body_source_authoring_packets"):
        _issue(issues, "source_authoring_packets_missing")
    summary = report.get("summary") or {}
    if int(summary.get("source_authorization_preflight_missing_item_count") or 0):
        _issue(issues, "source_authoring_packet_preflight_coverage_missing")
    if int(summary.get("source_intake_missing_classification_count") or 0):
        _issue(issues, "source_authoring_packet_intake_coverage_missing")
    if int(summary.get("source_authoring_packet_contract_mismatch_count") or 0):
        _issue(issues, "source_authoring_packet_contract_mismatch_present")
    if report.get("source_authoring_packet_consumable_as_authorization_manifest"):
        _issue(issues, "source_authoring_packet_consumable_as_authorization_manifest")
    if report.get("source_authoring_packet_consumable_as_proof_source"):
        _issue(issues, "source_authoring_packet_consumable_as_proof_source")
    for key in [
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
        "profile_equivalence_transfer_source_backed_proof_source_ready",
        "profile_equivalence_transfer_target_theorem_proved",
        "production_claim_machine_checked",
    ]:
        if report.get(key):
            _issue(issues, f"source_authoring_packet_premature_{key}")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_authoring_packet:{key}")
    return issues


def _packet_item_issues(item):
    issues = []
    expected = item.get("expected_lean_proof_name") or ""
    for key in [
        "source_authoring_packet_id",
        "source_authoring_packet_payload_sha256",
        "expected_lean_proof_name",
        "expected_statement_field_name",
        "expected_source_tree_relative_path",
        "source_authorization_template_id",
        "source_authorization_template_sha256",
        "source_anchor_binding_contract_id",
        "source_anchor_binding_contract_sha256",
    ]:
        if not item.get(key):
            _issue(issues, f"source_authoring_packet_item_{key}_missing", expected)
    if not item.get("source_labels"):
        _issue(issues, "source_authoring_packet_item_source_labels_missing", expected)
    if not item.get("source_authorization_manifest_template"):
        _issue(issues, "source_authoring_packet_item_authorization_manifest_template_missing", expected)
    if not item.get("source_anchor_binding_contract_payload"):
        _issue(issues, "source_authoring_packet_item_anchor_contract_payload_missing", expected)
    if not item.get("authoring_packet_ready"):
        _issue(issues, "source_authoring_packet_item_not_ready", expected)
    if item.get("source_body_source_ready"):
        _issue(issues, "source_authoring_packet_item_source_body_source_ready_premature", expected)
    if item.get("source_backed_proof_source_ready"):
        _issue(issues, "source_authoring_packet_item_source_backed_proof_source_ready_premature", expected)
    if item.get("machine_checked"):
        _issue(issues, "source_authoring_packet_item_machine_checked_premature", expected)
    if item.get("source_authoring_packet_consumable_as_authorization_manifest"):
        _issue(issues, "source_authoring_packet_item_consumable_as_authorization_manifest", expected)
    if item.get("source_authoring_packet_consumable_as_proof_source"):
        _issue(issues, "source_authoring_packet_item_consumable_as_proof_source", expected)
    return issues


def _work_order_item(packet):
    payload = {
        "schema_id": WORK_ORDER_SCHEMA_ID,
        "source_authoring_packet_id": packet.get("source_authoring_packet_id") or "",
        "source_authoring_packet_payload_sha256": packet.get("source_authoring_packet_payload_sha256") or "",
        "rank": int(packet.get("rank") or 0),
        "expected_lean_proof_name": packet.get("expected_lean_proof_name") or "",
        "expected_statement_field_name": packet.get("expected_statement_field_name") or "",
        "expected_source_tree_relative_path": packet.get("expected_source_tree_relative_path") or "",
        "source_authorization_template_id": packet.get("source_authorization_template_id") or "",
        "source_authorization_template_sha256": packet.get("source_authorization_template_sha256") or "",
        "source_anchor_binding_contract_id": packet.get("source_anchor_binding_contract_id") or "",
        "source_anchor_binding_contract_sha256": packet.get("source_anchor_binding_contract_sha256") or "",
    }
    payload_sha = _sha256_json(payload)
    expected_name = payload["expected_lean_proof_name"]
    source_path = payload["expected_source_tree_relative_path"]
    return {
        "source_authoring_work_order_id": f"source-authoring-work-order-{payload['rank']:02d}-{payload_sha[:16]}",
        "source_authoring_work_order_schema_id": WORK_ORDER_SCHEMA_ID,
        "source_authoring_work_order_payload_sha256": payload_sha,
        "source_authoring_packet_id": payload["source_authoring_packet_id"],
        "source_authoring_packet_payload_sha256": payload["source_authoring_packet_payload_sha256"],
        "rank": payload["rank"],
        "priority_bucket": packet.get("priority_bucket") or "",
        "work_order_kind": "lean_proof_body_source_and_authorization_manifest_authoring",
        "expected_lean_proof_name": expected_name,
        "expected_statement_field_name": payload["expected_statement_field_name"],
        "expected_source_tree_relative_path": source_path,
        "source_labels": list(packet.get("source_labels") or []),
        "source_anchor_bindings": list(packet.get("source_anchor_bindings") or []),
        "source_backed_theorem_obligation_ids": list(packet.get("source_backed_theorem_obligation_ids") or []),
        "source_authorization_manifest_required": True,
        "source_authorization_manifest_filename": packet.get("source_authorization_manifest_filename") or "proof-body-source-authorization.json",
        "source_authorization_scope": packet.get("source_authorization_scope") or "",
        "source_authorization_manifest_template": dict(packet.get("source_authorization_manifest_template") or {}),
        "source_authorization_template_schema_id": packet.get("source_authorization_template_schema_id") or "",
        "source_authorization_template_id": payload["source_authorization_template_id"],
        "source_authorization_template_sha256": payload["source_authorization_template_sha256"],
        "source_anchor_binding_contract_schema_id": packet.get("source_anchor_binding_contract_schema_id") or "",
        "source_anchor_binding_contract_id": payload["source_anchor_binding_contract_id"],
        "source_anchor_binding_contract_sha256": payload["source_anchor_binding_contract_sha256"],
        "source_anchor_binding_contract_payload": dict(packet.get("source_anchor_binding_contract_payload") or {}),
        "source_authorization_manifest_entry_missing": bool(packet.get("source_authorization_manifest_entry_missing")),
        "source_file_missing": bool(packet.get("source_file_missing")),
        "source_authorization_preflight_ready": bool(packet.get("source_authorization_preflight_ready")),
        "source_intake_candidate_body_count": int(packet.get("source_intake_candidate_body_count") or 0),
        "source_intake_ready_body_count": int(packet.get("source_intake_ready_body_count") or 0),
        "source_authoring_work_order_required": True,
        "source_authoring_work_order_ready": True,
        "source_body_source_ready": False,
        "source_backed_proof_source_ready": False,
        "machine_checked": False,
        "source_authoring_work_order_consumable_as_authorization_manifest": False,
        "source_authoring_work_order_consumable_as_lean_source": False,
        "source_authoring_work_order_consumable_as_proof_source": False,
        "work_order_tasks": [
            f"author Lean declaration {expected_name} in {source_path}",
            f"make the declaration statement reference {payload['expected_statement_field_name']}",
            "avoid sorry/admit/axiom/opaque placeholders, skeleton echo, assumption echo, and vacuous True statements",
            "add proof-body-source-authorization.json entry with the expected path/theorem/statement/hash/source labels/operator_id/authorization_ref",
            "include this work-order id/hash and source authoring-packet id/hash in the manifest entry",
            "include the packet authorization template id/hash and source-anchor binding contract id/hash in the manifest entry",
        ],
        "acceptance_criteria": [
            "authorization-preflight reports this item ready",
            "source-body-source intake sees a candidate body for this theorem",
            "the local Lean source file passes the configured Lean check",
            "downstream bundle-recheck still reports no premature proof readiness unless all required source bodies are ready",
        ],
        "must_not_do": [
            "do not treat this work order as an authorization manifest",
            "do not treat this work order as Lean proof source",
            "do not mark source proof readiness from this work order",
        ],
    }


def _work_order_runbook():
    return [
        {
            "step": "complete_each_work_order",
            "description": "author the Lean source and manifest entry for each listed theorem",
            "promotes_readiness": False,
        },
        {
            "step": "rerun_authorization_preflight",
            "command": authoring_packet_core.AUTHORIZATION_PREFLIGHT_COMMAND,
            "promotes_readiness": False,
        },
        {
            "step": "rerun_source_body_source_intake",
            "command": authoring_packet_core.SOURCE_BODY_SOURCE_INTAKE_COMMAND,
            "promotes_readiness": False,
        },
        {
            "step": "rerun_downstream_bundle_recheck",
            "description": "only downstream verified source bodies can affect proof-body-source readiness",
            "promotes_readiness": False,
        },
    ]


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report,
    label=None,
):
    authoring_packet_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report or {}
    validation_issues = _packet_report_issues(authoring_packet_report)
    packet_items = list(authoring_packet_report.get("source_theorem_proof_body_source_authoring_packets") or [])
    for item in packet_items:
        validation_issues.extend(_packet_item_issues(item))
    work_orders = [_work_order_item(item) for item in packet_items]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE
    dispatch_ready = bool(status == "PASS" and work_orders)
    checks = [
        _check("source_authoring_packet_report_consumable", not _packet_report_issues(authoring_packet_report), "source_authoring_packet_report_not_consumable"),
        _check("source_authoring_work_orders_present", bool(work_orders), "source_authoring_work_orders_missing"),
        _check("source_authoring_work_orders_have_contracts", not [issue for item in packet_items for issue in _packet_item_issues(item)], "source_authoring_work_order_contract_missing"),
        _check("work_order_not_authorization_manifest", True, ""),
        _check("work_order_not_lean_source", True, ""),
        _check("work_order_not_proof_source", True, ""),
    ]
    return {
        "created_at": "",
        "command": COMMAND,
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_state": state,
        "label": label or "",
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_ready": dispatch_ready,
        "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_work_orders_ready": dispatch_ready,
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": False,
        "production_claim_machine_checked": False,
        "source_authoring_work_order_consumable_as_authorization_manifest": False,
        "source_authoring_work_order_consumable_as_lean_source": False,
        "source_authoring_work_order_consumable_as_proof_source": False,
        "claim_packet_id": authoring_packet_report.get("claim_packet_id") or "",
        "slug": authoring_packet_report.get("slug") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report_path": authoring_packet_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report_sha256": authoring_packet_report.get("report_sha256") or "",
        "next_agent_stage": "source_tree_proof_body_source_authoring",
        "next_agent_command": authoring_packet_core.AUTHORIZATION_PREFLIGHT_COMMAND,
        "next_agent_command_precondition": "complete work orders in real Lean source and authorization manifest files, then rerun authorization-preflight and source-body-source intake",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_authoring_packet_count": len(packet_items),
            "source_authoring_packet_ready_count": sum(1 for item in packet_items if item.get("authoring_packet_ready")),
            "source_authoring_work_order_count": len(work_orders),
            "source_authoring_work_order_ready_count": len(work_orders) if dispatch_ready else 0,
            "source_authoring_work_order_required_count": sum(1 for item in work_orders if item.get("source_authoring_work_order_required")),
            "source_authorization_manifest_required_count": sum(1 for item in work_orders if item.get("source_authorization_manifest_required")),
            "source_authorization_manifest_missing_work_order_count": sum(1 for item in work_orders if item.get("source_authorization_manifest_entry_missing")),
            "source_file_missing_work_order_count": sum(1 for item in work_orders if item.get("source_file_missing")),
            "source_intake_ready_body_count": sum(int(item.get("source_intake_ready_body_count") or 0) for item in work_orders),
            "source_authorization_preflight_ready_item_count": sum(1 for item in work_orders if item.get("source_authorization_preflight_ready")),
            "source_authoring_work_order_consumable_as_authorization_manifest_count": 0,
            "source_authoring_work_order_consumable_as_lean_source_count": 0,
            "source_authoring_work_order_consumable_as_proof_source_count": 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authoring_work_orders_ready_count": 1 if dispatch_ready else 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count": 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_theorem_proof_body_source_authoring_work_orders": work_orders,
        "work_order_runbook": _work_order_runbook(),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_packet_report": authoring_packet_report,
        "boundary": {
            "read_only": True,
            "proof_generating": False,
            "authorization_manifest": False,
            "lean_source": False,
            "source_mutation_allowed": False,
            "external_action_allowed": False,
            "promotes_source_proof_ready": False,
            "promotes_machine_checked": False,
        },
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source theorem proof body source authoring work-order dispatch",
        "",
        f"- Status: `{report.get('status')}`",
        f"- State: `{report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_dispatch_state')}`",
        f"- Work orders: {summary.get('source_authoring_work_order_count', 0)}",
        f"- Missing authorizations: {summary.get('source_authorization_manifest_missing_work_order_count', 0)}",
        f"- Missing source files: {summary.get('source_file_missing_work_order_count', 0)}",
        f"- Intake-ready bodies: {summary.get('source_intake_ready_body_count', 0)}",
        f"- Consumable as authorization manifest: `{report.get('source_authoring_work_order_consumable_as_authorization_manifest')}`",
        f"- Consumable as Lean source: `{report.get('source_authoring_work_order_consumable_as_lean_source')}`",
        f"- Consumable as proof source: `{report.get('source_authoring_work_order_consumable_as_proof_source')}`",
        "",
        "## Top work orders",
    ]
    for item in (report.get("source_theorem_proof_body_source_authoring_work_orders") or [])[:5]:
        lines.append(
            f"- rank {item.get('rank')}: `{item.get('expected_lean_proof_name')}` -> `{item.get('expected_source_tree_relative_path')}`"
        )
    return "\n".join(lines) + "\n"
