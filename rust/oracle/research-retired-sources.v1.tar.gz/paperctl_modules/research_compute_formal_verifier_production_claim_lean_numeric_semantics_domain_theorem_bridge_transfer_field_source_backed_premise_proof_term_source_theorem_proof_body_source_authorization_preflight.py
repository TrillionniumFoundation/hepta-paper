"""Preflight proof-body source authorization manifests against authoring contracts."""

import hashlib
import json
import os
import pathlib


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authorization-preflight"
AUTHORING_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-plan-capstone"
SOURCE_BODY_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-intake"

AUTHORING_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PLAN_CAPSTONE_CONTRACT_BOUND_SOURCE_AUTHORING_PLAN_READY"
AUTHORING_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_PLAN_CAPSTONE_MACHINE_CHECKED_CLOSED"

AUTHORIZATION_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_AUTHORIZATION_REQUIRED"
AUTHORIZATION_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_AUTHORIZATION_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_FAILED"

SOURCE_AUTHORIZATION_SCOPE = "source_tree_contract_bound_lean_proof_body_source_authorization"
SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID = "paper_factory.source_tree_proof_body_source_authorization_template.v1"
SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID = "paper_factory.source_tree_proof_body_source_anchor_binding_contract.v1"
SOURCE_AUTHORIZATION_MANIFEST_FILENAMES = {
    "proof-body-source-authorization.json",
    "source-proof-authorization.json",
}

EXCLUDED_DIR_NAMES = {
    ".git",
    ".lake",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "logs",
    "node_modules",
    "target",
}

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorization_preflight_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorizations_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "source_root",
    "source_authorization_manifest_paths",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "next_agent_command_precondition",
    "summary",
    "checks",
    "validation_issues",
    "source_authorization_preflight_items",
    "source_authorization_manifests",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "authoring_plan_item_count",
    "source_authorization_manifest_count",
    "source_authorization_manifest_entry_count",
    "source_authorization_preflight_item_count",
    "source_authorization_preflight_ready_item_count",
    "source_authorization_missing_item_count",
    "source_authorization_not_marked_authorized_item_count",
    "source_authorization_scope_mismatch_item_count",
    "source_authorization_path_mismatch_item_count",
    "source_authorization_statement_mismatch_item_count",
    "source_authorization_source_labels_mismatch_item_count",
    "source_authorization_audit_metadata_missing_item_count",
    "source_authorization_template_mismatch_item_count",
    "source_authorization_anchor_contract_mismatch_item_count",
    "source_authorization_source_file_missing_item_count",
    "source_authorization_text_hash_match_item_count",
    "source_authorization_text_hash_mismatch_item_count",
    "source_tree_proof_body_source_ready_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorization_preflight_ready_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorizations_ready_count",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Consumes a proof-body source authoring-plan capstone report and validates local authorization manifests against its issued template and anchor-binding contracts.",
    "This preflight is read-only; it does not author Lean source, run Lean, mutate manuscript/source packages, or promote proof readiness.",
    "A preflight-ready authorization remains only an authorization; source-body intake must still verify source shape and local Lean check.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _relative_path(path, source_root):
    candidate = pathlib.Path(path or "")
    root = pathlib.Path(source_root or ".").resolve()
    try:
        return str(candidate.resolve().relative_to(root))
    except (OSError, ValueError):
        return str(candidate)


def _safe_relative_source_path(value):
    path = pathlib.PurePosixPath(str(value or ""))
    return bool(str(path)) and not path.is_absolute() and ".." not in path.parts and str(path) != "."


def _authoring_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "source_authoring_plan_capstone_report_missing")
        return issues
    if report.get("command") != AUTHORING_PLAN_COMMAND:
        _issue(issues, "source_authoring_plan_capstone_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "source_authoring_plan_capstone_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_state") or ""
    if state not in {AUTHORING_PLAN_READY_STATE, AUTHORING_PLAN_CLOSED_STATE}:
        _issue(issues, "source_authoring_plan_capstone_state_not_consumable", state)
    if not report.get("source_authoring_plan_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_authoring_plan_items_missing")
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_backed_proof_source_ready_premature_in_authoring_plan")
    for item in report.get("source_authoring_plan_items") or []:
        expected_path = item.get("expected_source_tree_relative_path") or ""
        if not _safe_relative_source_path(expected_path):
            detail = item.get("expected_lean_proof_name") or expected_path
            _issue(issues, "source_authoring_plan_item_expected_source_path_unsafe", detail)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_source_authoring_plan_capstone_boundary:{key}")
    return issues


def _bounded_authorization_manifest_paths(source_root, expected_source_paths):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    candidate_dirs = {root}
    for expected_path in expected_source_paths or []:
        if not _safe_relative_source_path(expected_path):
            continue
        expected = (root / str(expected_path)).resolve()
        try:
            expected.relative_to(root)
        except ValueError:
            continue
        candidate_dirs.add(expected.parent)
    candidates = []
    for directory in sorted(candidate_dirs):
        for filename in sorted(SOURCE_AUTHORIZATION_MANIFEST_FILENAMES):
            path = directory / filename
            if path.is_file():
                candidates.append(path)
    return sorted(set(candidates))


def _walk_authorization_manifests(source_root, expected_source_paths=None):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    if expected_source_paths is not None:
        return _bounded_authorization_manifest_paths(root, expected_source_paths)
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
        for filename in filenames:
            if filename not in SOURCE_AUTHORIZATION_MANIFEST_FILENAMES:
                continue
            path = pathlib.Path(dirpath) / filename
            if path.is_file():
                files.append(path)
    return sorted(files)


def _scan_authorization_manifests(source_root, expected_source_paths=None):
    root = pathlib.Path(source_root or ".").resolve()
    manifests = []
    entries = {}
    issues = []
    for path in _walk_authorization_manifests(root, expected_source_paths=expected_source_paths):
        rel_path = _relative_path(path, root)
        try:
            payload = json.loads(path.read_text(errors="replace"))
        except json.JSONDecodeError as exc:
            _issue(issues, "source_authorization_manifest_invalid_json", f"{rel_path}:{exc}")
            manifests.append({"path": rel_path, "valid": False, "authorization_scope": "", "entry_count": 0})
            continue
        scope = str(payload.get("authorization_scope") or payload.get("scope") or "")
        if scope != SOURCE_AUTHORIZATION_SCOPE:
            _issue(issues, "source_authorization_manifest_scope_mismatch", rel_path)
        source_entries = payload.get("authorized_sources") or []
        if not isinstance(source_entries, list):
            _issue(issues, "source_authorization_manifest_sources_not_list", rel_path)
            source_entries = []
        valid_entry_count = 0
        for entry in source_entries:
            if not isinstance(entry, dict):
                _issue(issues, "source_authorization_manifest_entry_not_object", rel_path)
                continue
            source_path = str(entry.get("path") or entry.get("source_path") or "")
            expected_name = str(entry.get("expected_lean_proof_name") or entry.get("lean_declaration_name") or "")
            if not source_path or not expected_name:
                _issue(issues, "source_authorization_manifest_entry_missing_path_or_name", rel_path)
                continue
            entries[(source_path, expected_name)] = {
                "manifest_path": rel_path,
                "authorization_scope": scope,
                "authorized": bool(entry.get("authorized")),
                "path": source_path,
                "expected_lean_proof_name": expected_name,
                "expected_statement_field_name": str(entry.get("expected_statement_field_name") or ""),
                "text_sha256": str(entry.get("text_sha256") or entry.get("source_text_sha256") or ""),
                "source_labels": list(entry.get("source_labels") or []),
                "source_authorization_template_schema_id": str(entry.get("source_authorization_template_schema_id") or ""),
                "source_authorization_template_id": str(entry.get("source_authorization_template_id") or ""),
                "source_authorization_template_sha256": str(entry.get("source_authorization_template_sha256") or ""),
                "source_anchor_binding_contract_schema_id": str(entry.get("source_anchor_binding_contract_schema_id") or ""),
                "source_anchor_binding_contract_id": str(entry.get("source_anchor_binding_contract_id") or ""),
                "source_anchor_binding_contract_sha256": str(entry.get("source_anchor_binding_contract_sha256") or ""),
                "operator_id": str(entry.get("operator_id") or ""),
                "authorization_ref": str(entry.get("authorization_ref") or ""),
            }
            valid_entry_count += 1
        manifests.append(
            {
                "path": rel_path,
                "valid": bool(scope == SOURCE_AUTHORIZATION_SCOPE),
                "authorization_scope": scope,
                "entry_count": valid_entry_count,
            }
        )
    return manifests, entries, issues


def _source_file_hash(source_root, relative_path):
    if not _safe_relative_source_path(relative_path):
        return "", False
    root = pathlib.Path(source_root or ".").resolve()
    path = (root / str(relative_path or "")).resolve()
    try:
        path.relative_to(root)
    except ValueError:
        return "", False
    if not path.is_file():
        return "", False
    return _sha256_text(path.read_text(errors="replace")), True


def _preflight_item(item, entries, source_root):
    expected_path = item.get("expected_source_tree_relative_path") or ""
    expected_name = item.get("expected_lean_proof_name") or ""
    expected_path_safe = _safe_relative_source_path(expected_path)
    entry = entries.get((expected_path, expected_name)) or {}
    expected_labels = set(item.get("source_labels") or [])
    entry_labels = set(entry.get("source_labels") or [])
    source_hash, source_file_present = _source_file_hash(source_root, expected_path)
    entry_present = bool(entry)
    scope_match = entry.get("authorization_scope") == SOURCE_AUTHORIZATION_SCOPE
    authorized_mark = bool(entry.get("authorized"))
    path_match = bool(entry.get("path") == expected_path)
    statement_match = bool(entry.get("expected_statement_field_name") == (item.get("expected_statement_field_name") or ""))
    labels_match = bool(not expected_labels or expected_labels.issubset(entry_labels))
    audit_metadata_present = bool(entry.get("operator_id") and entry.get("authorization_ref"))
    template_schema_match = entry.get("source_authorization_template_schema_id") == SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID
    template_id_match = entry.get("source_authorization_template_id") == (item.get("source_authorization_template_id") or "")
    template_sha_match = entry.get("source_authorization_template_sha256") == (item.get("source_authorization_template_sha256") or "")
    anchor_schema_match = entry.get("source_anchor_binding_contract_schema_id") == SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID
    anchor_id_match = entry.get("source_anchor_binding_contract_id") == (item.get("source_anchor_binding_contract_id") or "")
    anchor_sha_match = entry.get("source_anchor_binding_contract_sha256") == (item.get("source_anchor_binding_contract_sha256") or "")
    hash_match = bool(source_file_present and entry.get("text_sha256") and entry.get("text_sha256") == source_hash)
    ready = bool(
        entry_present
        and expected_path_safe
        and authorized_mark
        and scope_match
        and path_match
        and statement_match
        and labels_match
        and audit_metadata_present
        and template_schema_match
        and template_id_match
        and template_sha_match
        and anchor_schema_match
        and anchor_id_match
        and anchor_sha_match
        and source_file_present
        and hash_match
    )
    if ready:
        reason = ""
    elif not expected_path_safe:
        reason = "expected source path is unsafe"
    elif not entry_present:
        reason = "source authorization manifest entry missing"
    elif not authorized_mark:
        reason = "source authorization manifest entry is not marked authorized"
    elif not scope_match:
        reason = "source authorization manifest scope mismatch"
    elif not path_match:
        reason = "source authorization manifest path mismatch"
    elif not statement_match:
        reason = "source authorization manifest statement contract mismatch"
    elif not labels_match:
        reason = "source authorization manifest source labels do not cover expected labels"
    elif not audit_metadata_present:
        reason = "source authorization manifest lacks operator_id or authorization_ref"
    elif not template_schema_match or not template_id_match or not template_sha_match:
        reason = "source authorization manifest template contract mismatch"
    elif not anchor_schema_match or not anchor_id_match or not anchor_sha_match:
        reason = "source authorization manifest source-anchor binding contract mismatch"
    elif not source_file_present:
        reason = "authorized Lean source file is missing"
    else:
        reason = "source authorization manifest text_sha256 does not match Lean source file"
    return {
        "rank": int(item.get("rank") or 0),
        "expected_lean_proof_name": expected_name,
        "expected_statement_field_name": item.get("expected_statement_field_name") or "",
        "expected_source_tree_relative_path": expected_path,
        "expected_source_tree_relative_path_safe": expected_path_safe,
        "source_labels": list(item.get("source_labels") or []),
        "source_authorization_manifest_path": entry.get("manifest_path") or "",
        "source_authorization_entry_present": entry_present,
        "source_authorization_marked_authorized": authorized_mark,
        "source_authorization_scope_match": scope_match,
        "source_authorization_path_match": path_match,
        "source_authorization_statement_contract_match": statement_match,
        "source_authorization_source_labels_match": labels_match,
        "source_authorization_audit_metadata_present": audit_metadata_present,
        "source_authorization_template_schema_id_match": template_schema_match,
        "source_authorization_template_id_match": template_id_match,
        "source_authorization_template_sha256_match": template_sha_match,
        "source_anchor_binding_contract_schema_id_match": anchor_schema_match,
        "source_anchor_binding_contract_id_match": anchor_id_match,
        "source_anchor_binding_contract_sha256_match": anchor_sha_match,
        "expected_source_authorization_template_id": item.get("source_authorization_template_id") or "",
        "expected_source_authorization_template_sha256": item.get("source_authorization_template_sha256") or "",
        "source_authorization_template_id": entry.get("source_authorization_template_id") or "",
        "source_authorization_template_sha256": entry.get("source_authorization_template_sha256") or "",
        "expected_source_anchor_binding_contract_id": item.get("source_anchor_binding_contract_id") or "",
        "expected_source_anchor_binding_contract_sha256": item.get("source_anchor_binding_contract_sha256") or "",
        "source_anchor_binding_contract_id": entry.get("source_anchor_binding_contract_id") or "",
        "source_anchor_binding_contract_sha256": entry.get("source_anchor_binding_contract_sha256") or "",
        "source_file_present": source_file_present,
        "source_file_text_sha256": source_hash,
        "source_authorization_text_sha256": entry.get("text_sha256") or "",
        "source_authorization_text_sha256_match": hash_match,
        "source_authorization_preflight_ready": ready,
        "source_body_source_ready": False,
        "source_backed_proof_source_ready": False,
        "machine_checked": False,
        "blocking_reason": reason,
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report,
    source_root=".",
    label=None,
):
    authoring_plan_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _authoring_plan_issues(authoring_plan_report)
    machine_checked = bool(authoring_plan_report.get("production_claim_machine_checked"))
    plan_items = list(authoring_plan_report.get("source_authoring_plan_items") or [])
    expected_source_paths = [item.get("expected_source_tree_relative_path") or "" for item in plan_items]
    manifests, entries, manifest_issues = _scan_authorization_manifests(source_root_path, expected_source_paths=expected_source_paths)
    validation_issues.extend(manifest_issues)
    preflight_items = [_preflight_item(item, entries, source_root_path) for item in plan_items]
    ready_count = sum(1 for item in preflight_items if item.get("source_authorization_preflight_ready"))
    all_ready = bool(preflight_items and ready_count == len(preflight_items))
    checks = [
        _check("source_authoring_plan_capstone_report_consumable", not _authoring_plan_issues(authoring_plan_report), "source_authoring_plan_capstone_report_not_consumable"),
        _check("source_authoring_plan_items_present", bool(plan_items), "source_authoring_plan_items_missing"),
        _check("source_authorization_manifests_valid_json", not manifest_issues, "source_authorization_manifest_validation_issue"),
        _check("source_authorization_preflight_ready", all_ready or machine_checked, "source_authorization_manifest_entries_not_ready", severity="readiness"),
        _check("source_authorization_does_not_promote_proof_readiness", not all_ready or not authoring_plan_report.get("profile_equivalence_transfer_source_backed_proof_source_ready"), "source_authorization_preflight_promoted_proof_readiness"),
        _check("no_source_mutation", not authoring_plan_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not authoring_plan_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    missing_required_report = any(item.get("issue") == "source_authoring_plan_capstone_report_missing" for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
        next_agent_command_precondition = ""
    elif missing_required_report or not plan_items or manifest_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
        next_agent_command_precondition = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
        next_agent_command_precondition = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
        next_agent_command_precondition = ""
    elif all_ready:
        status = "PASS"
        state = AUTHORIZATION_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake"
        next_agent_command = SOURCE_BODY_SOURCE_INTAKE_COMMAND
        next_agent_command_precondition = "authorization preflight passed; source-body intake must still verify source shape and local Lean check"
    else:
        status = "PASS"
        state = AUTHORIZATION_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_source_theorem_proof_body_source_authoring"
        next_agent_command = COMMAND
        next_agent_command_precondition = "author Lean proof body source and proof-body-source-authorization.json entries matching the capstone template and anchor contracts, then rerun authorization preflight"
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorization_preflight_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorizations_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": bool(production_checked),
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": bool(production_checked),
        "claim_packet_id": authoring_plan_report.get("claim_packet_id") or "",
        "slug": authoring_plan_report.get("slug") or "",
        "source_root": str(source_root_path),
        "source_authorization_manifest_paths": [item.get("path") or "" for item in manifests],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_path": authoring_plan_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report_sha256": authoring_plan_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "next_agent_command_precondition": next_agent_command_precondition,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "authoring_plan_item_count": len(plan_items),
            "source_authorization_manifest_count": len(manifests),
            "source_authorization_manifest_entry_count": len(entries),
            "source_authorization_preflight_item_count": len(preflight_items),
            "source_authorization_preflight_ready_item_count": ready_count,
            "source_authorization_missing_item_count": sum(1 for item in preflight_items if not item.get("source_authorization_entry_present")),
            "source_authorization_not_marked_authorized_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_marked_authorized")),
            "source_authorization_scope_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_scope_match")),
            "source_authorization_path_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_path_match")),
            "source_authorization_statement_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_statement_contract_match")),
            "source_authorization_source_labels_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_source_labels_match")),
            "source_authorization_audit_metadata_missing_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and not item.get("source_authorization_audit_metadata_present")),
            "source_authorization_template_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and (not item.get("source_authorization_template_schema_id_match") or not item.get("source_authorization_template_id_match") or not item.get("source_authorization_template_sha256_match"))),
            "source_authorization_anchor_contract_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and (not item.get("source_anchor_binding_contract_schema_id_match") or not item.get("source_anchor_binding_contract_id_match") or not item.get("source_anchor_binding_contract_sha256_match"))),
            "source_authorization_source_file_missing_item_count": sum(1 for item in preflight_items if not item.get("source_file_present")),
            "source_authorization_text_hash_match_item_count": sum(1 for item in preflight_items if item.get("source_authorization_text_sha256_match")),
            "source_authorization_text_hash_mismatch_item_count": sum(1 for item in preflight_items if item.get("source_authorization_entry_present") and item.get("source_file_present") and not item.get("source_authorization_text_sha256_match")),
            "source_tree_proof_body_source_ready_count": 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorization_preflight_ready_count": 1 if status == "PASS" else 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_source_authorizations_ready_count": 1 if (status == "PASS" and all_ready and not production_checked) else 0,
            "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready_count": 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 1 if production_checked else 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_authorization_preflight_items": preflight_items,
        "source_authorization_manifests": manifests,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_plan_capstone_report": authoring_plan_report,
        "boundary": [
            "This command validates proof-body-source authorization manifests against an authoring-plan capstone only.",
            "It reads local source files only to compute text_sha256; it does not run Lean, mutate Lean source, mutate manuscript/source packages, or create authorization manifests.",
            "Authorization-preflight readiness is not proof-body-source readiness, proof-term readiness, or machine-checked theorem readiness.",
            "Source-body intake must still verify declaration shape, statement contract, placeholder rejection, source hash, authorization, and local Lean check.",
            "It writes only local reports and does not read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Body Source Authorization Preflight",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_state') or ''}",
        f"- Authoring-plan items: {summary.get('authoring_plan_item_count', 0)}",
        f"- Authorization manifests: {summary.get('source_authorization_manifest_count', 0)}",
        f"- Preflight-ready authorizations: {summary.get('source_authorization_preflight_ready_item_count', 0)}",
        f"- Source files missing: {summary.get('source_authorization_source_file_missing_item_count', 0)}",
        f"- Source-backed proof source ready: {report.get('profile_equivalence_transfer_source_backed_proof_source_ready')}",
        "",
        "## Blocking Items",
    ]
    for item in report.get("source_authorization_preflight_items") or []:
        if item.get("source_authorization_preflight_ready"):
            continue
        lines.append(
            f"- rank={item.get('rank')} proof={item.get('expected_lean_proof_name')} path={item.get('expected_source_tree_relative_path')} reason={item.get('blocking_reason')}"
        )
    lines.extend(["", "## Boundary"])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
