"""Intake source-tree proof bodies for premise source theorems."""

import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-intake"
SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-implementation-plan"
AUTHORIZATION_PREFLIGHT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authorization-preflight"
ARTIFACT_PREFLIGHT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-authoring-work-order-artifact-preflight"
SOURCE_THEOREM_PROOF_BODY_SOURCE_CONSTRUCTION_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-source-construction-attempt"
BUNDLE_RECHECK_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-bundle-recheck"

IMPLEMENTATION_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_READY_SOURCE_PROOF_BODIES_REQUIRED"
IMPLEMENTATION_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_MACHINE_CHECKED_CLOSED"
AUTHORIZATION_PREFLIGHT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_AUTHORIZATION_REQUIRED"
AUTHORIZATION_PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_AUTHORIZATION_READY"
AUTHORIZATION_PREFLIGHT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORIZATION_PREFLIGHT_MACHINE_CHECKED_CLOSED"
ARTIFACT_PREFLIGHT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_ARTIFACT_PREFLIGHT_ARTIFACT_REQUIRED"
ARTIFACT_PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_AUTHORING_WORK_ORDER_ARTIFACT_PREFLIGHT_ARTIFACT_READY"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_SOURCE_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_SOURCE_INTAKE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_required",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "candidate_limit",
    "excluded_directory_names",
    "source_authorization_manifest_paths",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "source_theorem_proof_body_source_intake_classifications",
    "candidate_lean_source_files",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_body_requirement_count",
    "local_lean_file_count",
    "candidate_lean_source_file_count",
    "source_theorem_proof_body_source_candidate_count",
    "source_theorem_proof_body_source_ready_count",
    "source_theorem_proof_body_source_missing_count",
    "placeholder_body_candidate_count",
    "assumption_echo_body_candidate_count",
    "skeleton_echo_body_candidate_count",
    "vacuous_true_body_candidate_count",
    "non_domain_statement_body_candidate_count",
    "domain_statement_body_candidate_count",
    "statement_contract_body_candidate_count",
    "statement_contract_mismatch_body_candidate_count",
    "local_statement_contract_definition_body_candidate_count",
    "source_authorization_manifest_count",
    "source_authorization_validation_issue_count",
    "source_authorized_body_candidate_count",
    "source_authorization_missing_body_candidate_count",
    "source_authorization_stale_body_candidate_count",
    "source_authorization_metadata_missing_body_candidate_count",
    "source_authorization_source_labels_mismatch_body_candidate_count",
    "source_authorization_template_mismatch_body_candidate_count",
    "source_authorization_anchor_contract_mismatch_body_candidate_count",
    "source_authorization_preflight_report_present_count",
    "source_authorization_preflight_ready_body_candidate_count",
    "source_authorization_preflight_missing_body_candidate_count",
    "source_authorization_preflight_mismatch_body_candidate_count",
    "source_authoring_artifact_preflight_report_present_count",
    "source_authoring_artifact_preflight_ready_body_candidate_count",
    "source_authoring_artifact_preflight_missing_body_candidate_count",
    "source_authoring_artifact_preflight_mismatch_body_candidate_count",
    "source_tree_lean_check_candidate_file_count",
    "source_tree_lean_check_pass_file_count",
    "source_tree_lean_check_fail_file_count",
    "source_tree_lean_check_timeout_file_count",
    "generated_log_body_candidate_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes proof-body implementation-plan reports and inventories local source-tree theorem/lemma bodies for each expected sourceBacked theorem.",
    "Generated logs, Mathlib/dependency caches, placeholders, skeleton bodies, assumption echo, vacuous : True, non-domain statements, statement-contract mismatches, locally defined statement contracts, and source files lacking hash/statement/source-label/audit-metadata authorization are rejected as proof bodies.",
    "This command reads local files and writes reports only; it does not construct or mutate source theorem proof bodies.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
EXCLUDED_DIR_NAMES = {
    ".git",
    ".lake",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "logs",
    "node_modules",
}
SOURCE_AUTHORIZATION_SCOPE = "source_tree_contract_bound_lean_proof_body_source_authorization"
SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID = "paper_factory.source_tree_proof_body_source_authorization_template.v1"
SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID = "paper_factory.source_tree_proof_body_source_anchor_binding_contract.v1"
SUGGESTED_LEAN_SOURCE_PATH = "PaperFactoryFormalVerifier/SourceBacked/PremiseProofBodies.lean"
SOURCE_AUTHORIZATION_MANIFEST_FILENAMES = {
    "proof-body-source-authorization.json",
    "source-proof-authorization.json",
}
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
DECL_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b")
NEXT_DECL_RE = re.compile(r"^\s*(theorem|lemma|def|structure|inductive|namespace|section|end)\b")
NAMESPACE_RE = re.compile(r"^\s*namespace\b")
SECTION_RE = re.compile(r"^\s*section\b")
END_RE = re.compile(r"^\s*end\b")
ASSUMPTION_ECHO_RE = re.compile(r"\b(exact\s+h[A-Za-z0-9_']*|:=\s*h[A-Za-z0-9_']*|by\s+assumption|assumption)\b")
SKELETON_ECHO_RE = re.compile(r"\b(Skeleton|skeleton|implementationPlan|ImplementationPlan|proofBodyImplementationBlocked)\b")
VACUOUS_TRUE_RE = re.compile(r":\s*True\s*:=", re.M)
DOMAIN_STATEMENT_RE = re.compile(
    r"(ProfileEquivalence|profileEquivalence|DirectEuler|directEuler|FastTransfer|fastTransfer|OperationalCertificate|operationalCertificate|HighFrequency|highFrequency|fixedDelta|FixedDelta|drift|Drift|diffusion|Diffusion|certificate|Certificate|anchor|Anchor|sourceBacked|SourceBacked|rate|Rate|premise|Premise)"
)
LOCAL_STATEMENT_DECL_KEYWORDS = "def|abbrev|theorem|lemma|inductive|structure|class|axiom|opaque"


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _sha256_json(payload):
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode()).hexdigest()


def _authorization_template_contract(expected_name, expected_statement_field, source_labels):
    payload = {
        "schema_id": SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID,
        "authorization_scope": SOURCE_AUTHORIZATION_SCOPE,
        "expected_source_tree_relative_path": SUGGESTED_LEAN_SOURCE_PATH,
        "expected_lean_proof_name": expected_name or "",
        "expected_statement_field_name": expected_statement_field or "",
        "source_labels": sorted(source_labels or []),
    }
    sha = _sha256_json(payload)
    return {
        "source_authorization_template_schema_id": SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID,
        "source_authorization_template_id": f"source-proof-body-template-{sha[:16]}",
        "source_authorization_template_sha256": sha,
    }


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _implementation_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_missing")
        return issues
    if report.get("command") != SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_state") or ""
    if state not in {IMPLEMENTATION_PLAN_READY_STATE, IMPLEMENTATION_PLAN_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_body_implementation_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_implementation_items_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_boundary:{key}")
    return issues


def _authorization_preflight_issues(report):
    issues = []
    if not report:
        return issues
    if report.get("command") != AUTHORIZATION_PREFLIGHT_COMMAND:
        _issue(issues, "source_authorization_preflight_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "source_authorization_preflight_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_state") or ""
    if state not in {AUTHORIZATION_PREFLIGHT_REQUIRED_STATE, AUTHORIZATION_PREFLIGHT_READY_STATE, AUTHORIZATION_PREFLIGHT_CLOSED_STATE}:
        _issue(issues, "source_authorization_preflight_state_not_consumable", state)
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_authorization_preflight_promoted_source_backed_proof_source_ready")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_source_authorization_preflight_boundary:{key}")
    return issues


def _artifact_preflight_issues(report):
    issues = []
    if not report:
        return issues
    if report.get("command") != ARTIFACT_PREFLIGHT_COMMAND:
        _issue(issues, "source_authoring_artifact_preflight_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "source_authoring_artifact_preflight_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_state") or ""
    if state not in {ARTIFACT_PREFLIGHT_REQUIRED_STATE, ARTIFACT_PREFLIGHT_READY_STATE}:
        _issue(issues, "source_authoring_artifact_preflight_state_not_consumable", state)
    for key in [
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready",
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
        "profile_equivalence_transfer_source_backed_proof_source_ready",
        "production_claim_machine_checked",
    ]:
        if report.get(key):
            _issue(issues, f"source_authoring_artifact_preflight_promoted_{key}")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_source_authoring_artifact_preflight_boundary:{key}")
    return issues


def _authorization_preflight_entries(report):
    entries = {}
    if not report:
        return entries
    for item in report.get("source_authorization_preflight_items") or []:
        source_path = item.get("expected_source_tree_relative_path") or ""
        expected_name = item.get("expected_lean_proof_name") or ""
        if source_path and expected_name:
            entries[(source_path, expected_name)] = item
    return entries


def _artifact_preflight_entries(report):
    entries = {}
    if not report:
        return entries
    for item in report.get("source_theorem_proof_body_source_authoring_artifact_preflight_items") or []:
        source_path = item.get("expected_source_tree_relative_path") or ""
        expected_name = item.get("expected_lean_proof_name") or ""
        if source_path and expected_name:
            entries[(source_path, expected_name)] = item
    return entries


def _walk_lean_files(source_root, candidate_limit):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
        for filename in filenames:
            if len(files) >= int(candidate_limit or 0):
                return files
            path = pathlib.Path(dirpath) / filename
            if path.suffix == ".lean" and path.is_file():
                files.append(path)
    return files


def _bounded_source_authorization_manifest_paths(source_root, expected_source_paths):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    candidate_dirs = {root}
    for expected_path in expected_source_paths or []:
        if not _safe_relative_source_path(expected_path):
            continue
        expected = (root / str(expected_path)).resolve()
        try:
            expected.relative_to(root)
        except ValueError:
            continue
        candidate_dirs.add(expected.parent)
    candidates = []
    for directory in sorted(candidate_dirs):
        for filename in sorted(SOURCE_AUTHORIZATION_MANIFEST_FILENAMES):
            path = directory / filename
            if path.is_file():
                candidates.append(path)
    return sorted(set(candidates))


def _walk_source_authorization_manifests(source_root, expected_source_paths=None):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    if expected_source_paths is not None:
        return _bounded_source_authorization_manifest_paths(root, expected_source_paths)
    files = []
    for dirpath, dirnames, filenames in os.walk(root):
        dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
        for filename in filenames:
            if filename not in SOURCE_AUTHORIZATION_MANIFEST_FILENAMES:
                continue
            path = pathlib.Path(dirpath) / filename
            if path.is_file():
                files.append(path)
    return sorted(files)


def _relative_source_path(path, source_root):
    candidate = pathlib.Path(path or "")
    root = pathlib.Path(source_root or ".").resolve()
    try:
        return str(candidate.resolve().relative_to(root))
    except (OSError, ValueError):
        return str(candidate)


def _safe_relative_source_path(value):
    path = pathlib.PurePosixPath(str(value or ""))
    return bool(str(path)) and not path.is_absolute() and ".." not in path.parts and str(path) != "."


def _scan_source_authorization_manifests(source_root, expected_source_paths=None):
    root = pathlib.Path(source_root or ".").resolve()
    manifests = []
    entries = {}
    issues = []
    for path in _walk_source_authorization_manifests(root, expected_source_paths=expected_source_paths):
        rel_path = _relative_source_path(path, root)
        try:
            payload = json.loads(path.read_text(errors="replace"))
        except json.JSONDecodeError as exc:
            _issue(issues, "source_authorization_manifest_invalid_json", f"{rel_path}:{exc}")
            manifests.append({"path": rel_path, "valid": False, "entry_count": 0})
            continue
        scope = str(payload.get("authorization_scope") or payload.get("scope") or "")
        if scope != SOURCE_AUTHORIZATION_SCOPE:
            _issue(issues, "source_authorization_manifest_scope_mismatch", rel_path)
        source_entries = payload.get("authorized_sources") or []
        if not isinstance(source_entries, list):
            _issue(issues, "source_authorization_manifest_sources_not_list", rel_path)
            source_entries = []
        valid_entry_count = 0
        for entry in source_entries:
            if not isinstance(entry, dict):
                _issue(issues, "source_authorization_manifest_entry_not_object", rel_path)
                continue
            source_path = str(entry.get("path") or entry.get("source_path") or "")
            expected_name = str(entry.get("expected_lean_proof_name") or entry.get("lean_declaration_name") or "")
            if not source_path or not expected_name:
                _issue(issues, "source_authorization_manifest_entry_missing_path_or_name", rel_path)
                continue
            key = (source_path, expected_name)
            entries[key] = {
                "manifest_path": rel_path,
                "authorization_scope": scope,
                "authorized": bool(entry.get("authorized")),
                "path": source_path,
                "expected_lean_proof_name": expected_name,
                "expected_statement_field_name": str(entry.get("expected_statement_field_name") or ""),
                "text_sha256": str(entry.get("text_sha256") or entry.get("source_text_sha256") or ""),
                "source_labels": list(entry.get("source_labels") or []),
                "source_authorization_template_schema_id": str(entry.get("source_authorization_template_schema_id") or ""),
                "source_authorization_template_id": str(entry.get("source_authorization_template_id") or ""),
                "source_authorization_template_sha256": str(entry.get("source_authorization_template_sha256") or ""),
                "source_anchor_binding_contract_schema_id": str(entry.get("source_anchor_binding_contract_schema_id") or ""),
                "source_anchor_binding_contract_id": str(entry.get("source_anchor_binding_contract_id") or ""),
                "source_anchor_binding_contract_sha256": str(entry.get("source_anchor_binding_contract_sha256") or ""),
                "source_authoring_work_order_id": str(entry.get("source_authoring_work_order_id") or ""),
                "source_authoring_work_order_payload_sha256": str(entry.get("source_authoring_work_order_payload_sha256") or ""),
                "source_authoring_packet_id": str(entry.get("source_authoring_packet_id") or ""),
                "source_authoring_packet_payload_sha256": str(entry.get("source_authoring_packet_payload_sha256") or ""),
                "operator_id": str(entry.get("operator_id") or ""),
                "authorization_ref": str(entry.get("authorization_ref") or ""),
            }
            valid_entry_count += 1
        manifests.append(
            {
                "path": rel_path,
                "valid": bool(scope == SOURCE_AUTHORIZATION_SCOPE and not any(item.get("issue", "").startswith("source_authorization_manifest") and item.get("detail") == rel_path for item in issues)),
                "authorization_scope": scope,
                "entry_count": valid_entry_count,
            }
        )
    return manifests, entries, issues


def _extract_theorem_bodies(text):
    lines = str(text or "").splitlines()
    bodies = []
    scope_stack = []
    for index, line in enumerate(lines):
        match = DECL_RE.match(line)
        if match:
            end = len(lines)
            for later in range(index + 1, len(lines)):
                if NEXT_DECL_RE.match(lines[later]):
                    end = later
                    break
            block = "\n".join(lines[index:end])
            statement_text = block.split(":=", 1)[0]
            statement_text = re.sub(rf"^\s*{match.group(1)}\s+{re.escape(match.group(2))}\b", "", statement_text, count=1)
            domain_marker_count = len(DOMAIN_STATEMENT_RE.findall(statement_text))
            bodies.append(
                {
                    "kind": match.group(1),
                    "name": match.group(2),
                    "line_start": index + 1,
                    "line_end": end,
                    "body_text_sha256": _sha256_text(block),
                    "statement_text_sha256": _sha256_text(statement_text),
                    "domain_statement_marker_count": domain_marker_count,
                    "non_domain_statement_marker_count": 0 if domain_marker_count else 1,
                    "top_level_namespace": not any(item == "namespace" for item in scope_stack),
                    "placeholder_token_count": len(PLACEHOLDER_RE.findall(block)),
                    "assumption_echo_marker_count": len(ASSUMPTION_ECHO_RE.findall(block)),
                    "skeleton_echo_marker_count": len(SKELETON_ECHO_RE.findall(block)),
                    "vacuous_true_marker_count": len(VACUOUS_TRUE_RE.findall(block)),
                    "_statement_text": statement_text,
                    "_body_text": block,
                }
            )
        if NAMESPACE_RE.match(line):
            scope_stack.append("namespace")
        elif SECTION_RE.match(line):
            scope_stack.append("section")
        elif END_RE.match(line) and scope_stack:
            scope_stack.pop()
    return bodies


def _expected_statement_field_name(item):
    premise = item.get("lean_premise_name") or item.get("expected_lean_proof_name") or "premiseProofTerm"
    text = re.sub(r"[^A-Za-z0-9_]", "", str(premise or "premiseProofTerm"))
    if not text:
        text = "premiseProofTerm"
    return f"{text[:1].lower()}{text[1:]}Statement"


def _local_statement_contract_definition_count(source_text, expected_statement_field):
    field = str(expected_statement_field or "").strip()
    if not field:
        return 0
    escaped = re.escape(field)
    keyword_decl = re.compile(rf"^\s*(?:{LOCAL_STATEMENT_DECL_KEYWORDS})\s+{escaped}\b", re.M)
    field_decl = re.compile(rf"^\s*{escaped}\s*:", re.M)
    return len(keyword_decl.findall(str(source_text or ""))) + len(field_decl.findall(str(source_text or "")))


def _scan_lean_sources(source_root, candidate_limit):
    candidates = []
    root = pathlib.Path(source_root or ".").resolve()
    for path in _walk_lean_files(source_root, candidate_limit):
        text = path.read_text(errors="replace")
        source_text_without_comments = _strip_lean_comments(text)
        bodies = _extract_theorem_bodies(source_text_without_comments)
        candidates.append(
            {
                "path": str(path),
                "relative_path": _relative_source_path(path, root),
                "text_sha256": _sha256_text(text),
                "theorem_or_lemma_body_count": len(bodies),
                "theorem_or_lemma_names": [item.get("name") for item in bodies][:50],
                "placeholder_body_candidate_count": sum(int(item.get("placeholder_token_count") or 0) for item in bodies),
                "assumption_echo_body_candidate_count": sum(int(item.get("assumption_echo_marker_count") or 0) for item in bodies),
                "skeleton_echo_body_candidate_count": sum(int(item.get("skeleton_echo_marker_count") or 0) for item in bodies),
                "vacuous_true_body_candidate_count": sum(int(item.get("vacuous_true_marker_count") or 0) for item in bodies),
                "non_domain_statement_body_candidate_count": sum(int(item.get("non_domain_statement_marker_count") or 0) for item in bodies),
                "domain_statement_body_candidate_count": sum(1 for item in bodies if int(item.get("domain_statement_marker_count") or 0)),
                "_source_text": text,
                "_source_text_without_comments": source_text_without_comments,
                "_bodies": bodies,
            }
        )
    return candidates


def _run_lean_check(path, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(path)
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds, capture_output=True, text=True)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "exit_zero": bool(proc.returncode == 0),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": 124,
            "exit_zero": False,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def _lean_check_for_candidate(candidate, source_root, lean_executable, lake_executable, timeout_seconds, runner, cache):
    key = (candidate.get("path") or "", candidate.get("text_sha256") or "")
    if key not in cache:
        cache[key] = _run_lean_check(
            candidate.get("path") or "",
            source_root,
            lean_executable=lean_executable,
            lake_executable=lake_executable,
            timeout_seconds=timeout_seconds,
            runner=runner,
        )
    return cache[key]


def _source_authorization_for(item, candidate, expected_statement_field, authorization_entries, authorization_preflight_entries, authorization_preflight_report_present, artifact_preflight_entries, artifact_preflight_report_present):
    source_path = candidate.get("relative_path") or candidate.get("path") or ""
    expected_name = item.get("expected_lean_proof_name") or ""
    expected_template = _authorization_template_contract(expected_name, expected_statement_field, item.get("source_labels") or [])
    expected_anchor_contract_id = item.get("source_anchor_binding_contract_id") or ""
    expected_anchor_contract_sha = item.get("source_anchor_binding_contract_sha256") or ""
    anchor_contract_required = bool(expected_anchor_contract_id or expected_anchor_contract_sha)
    entry = authorization_entries.get((source_path, expected_name)) or {}
    if not entry:
        return {
            "source_authorized": False,
            "source_authorization_manifest_path": "",
            "source_authorization_scope": "",
            "source_authorization_entry_present": False,
            "source_authorization_sha256_match": False,
            "source_authorization_statement_contract_match": False,
            "source_authorization_operator_id_present": False,
            "source_authorization_ref_present": False,
            "source_authorization_source_labels_match": False,
            "source_authorization_template_schema_id_match": False,
            "source_authorization_template_id_match": False,
            "source_authorization_template_sha256_match": False,
            "source_authorization_expected_path_match": False,
            "source_authorization_anchor_contract_schema_id_match": not anchor_contract_required,
            "source_authorization_anchor_contract_id_match": not anchor_contract_required,
            "source_authorization_anchor_contract_sha256_match": not anchor_contract_required,
            "source_authorization_preflight_report_present": bool(authorization_preflight_report_present),
            "source_authorization_preflight_entry_present": False,
            "source_authorization_preflight_ready": False,
            "source_authorization_preflight_text_sha256_match": False,
            "source_authorization_preflight_template_id_match": False,
            "source_authorization_preflight_anchor_contract_id_match": False,
            "source_authoring_artifact_preflight_report_present": bool(artifact_preflight_report_present),
            "source_authoring_artifact_preflight_entry_present": False,
            "source_authoring_artifact_preflight_ready": False,
            "source_authoring_artifact_preflight_text_sha256_match": False,
            "source_authoring_artifact_preflight_work_order_contract_match": False,
            "source_authoring_artifact_preflight_packet_contract_match": False,
            "source_authoring_artifact_preflight_template_id_match": False,
            "source_authoring_artifact_preflight_anchor_contract_id_match": False,
            "expected_source_authorization_template_id": expected_template["source_authorization_template_id"],
            "expected_source_authorization_template_sha256": expected_template["source_authorization_template_sha256"],
            "expected_source_anchor_binding_contract_id": expected_anchor_contract_id,
            "expected_source_anchor_binding_contract_sha256": expected_anchor_contract_sha,
            "source_authorization_stale": False,
            "source_authorization_blocking_reason": "source proof body candidate lacks an explicit source-tree authorization manifest entry",
        }
    sha_match = bool(entry.get("text_sha256") and entry.get("text_sha256") == candidate.get("text_sha256"))
    statement_match = bool(not entry.get("expected_statement_field_name") or entry.get("expected_statement_field_name") == expected_statement_field)
    scope_match = entry.get("authorization_scope") == SOURCE_AUTHORIZATION_SCOPE
    operator_present = bool(entry.get("operator_id"))
    authorization_ref_present = bool(entry.get("authorization_ref"))
    expected_labels = set(item.get("source_labels") or [])
    entry_labels = set(entry.get("source_labels") or [])
    source_labels_match = bool(not expected_labels or expected_labels.issubset(entry_labels))
    template_schema_match = entry.get("source_authorization_template_schema_id") == SOURCE_AUTHORIZATION_TEMPLATE_SCHEMA_ID
    template_id_match = entry.get("source_authorization_template_id") == expected_template["source_authorization_template_id"]
    template_sha_match = entry.get("source_authorization_template_sha256") == expected_template["source_authorization_template_sha256"]
    expected_path_match = source_path == SUGGESTED_LEAN_SOURCE_PATH
    anchor_contract_schema_match = bool(
        not anchor_contract_required
        or entry.get("source_anchor_binding_contract_schema_id") == SOURCE_ANCHOR_BINDING_CONTRACT_SCHEMA_ID
    )
    anchor_contract_id_match = bool(
        not expected_anchor_contract_id
        or entry.get("source_anchor_binding_contract_id") == expected_anchor_contract_id
    )
    anchor_contract_sha_match = bool(
        not expected_anchor_contract_sha
        or entry.get("source_anchor_binding_contract_sha256") == expected_anchor_contract_sha
    )
    preflight = authorization_preflight_entries.get((source_path, expected_name)) or {}
    preflight_entry_present = bool(preflight)
    preflight_ready = bool(preflight.get("source_authorization_preflight_ready"))
    preflight_text_hash_match = bool(
        preflight_entry_present
        and preflight.get("source_file_text_sha256")
        and preflight.get("source_file_text_sha256") == candidate.get("text_sha256")
        and preflight.get("source_authorization_text_sha256") == entry.get("text_sha256")
        and preflight.get("source_authorization_text_sha256_match")
    )
    preflight_template_id_match = bool(
        preflight_entry_present
        and (
            not entry.get("source_authorization_template_id")
            or preflight.get("source_authorization_template_id") == entry.get("source_authorization_template_id")
        )
        and (
            not entry.get("source_authorization_template_sha256")
            or preflight.get("source_authorization_template_sha256") == entry.get("source_authorization_template_sha256")
        )
    )
    preflight_anchor_contract_id_match = bool(
        preflight_entry_present
        and (
            not entry.get("source_anchor_binding_contract_id")
            or preflight.get("source_anchor_binding_contract_id") == entry.get("source_anchor_binding_contract_id")
        )
        and (
            not entry.get("source_anchor_binding_contract_sha256")
            or preflight.get("source_anchor_binding_contract_sha256") == entry.get("source_anchor_binding_contract_sha256")
        )
    )
    preflight_match = bool(
        preflight_entry_present
        and preflight_ready
        and preflight_text_hash_match
        and preflight_template_id_match
        and preflight_anchor_contract_id_match
    )
    artifact_preflight = artifact_preflight_entries.get((source_path, expected_name)) or {}
    artifact_entry_present = bool(artifact_preflight)
    artifact_ready = bool(artifact_preflight.get("source_authoring_artifact_preflight_ready"))
    artifact_text_hash_match = bool(
        artifact_entry_present
        and artifact_preflight.get("source_file_text_sha256")
        and artifact_preflight.get("source_file_text_sha256") == candidate.get("text_sha256")
        and artifact_preflight.get("source_authorization_text_sha256") == entry.get("text_sha256")
        and artifact_preflight.get("source_authorization_text_sha256_match")
    )
    artifact_work_order_contract_match = bool(
        artifact_entry_present
        and artifact_preflight.get("source_authoring_work_order_id")
        and artifact_preflight.get("source_authoring_work_order_id") == entry.get("source_authoring_work_order_id")
        and artifact_preflight.get("source_authoring_work_order_payload_sha256")
        and artifact_preflight.get("source_authoring_work_order_payload_sha256") == entry.get("source_authoring_work_order_payload_sha256")
        and artifact_preflight.get("source_authorization_work_order_id_match")
        and artifact_preflight.get("source_authorization_work_order_payload_sha256_match")
    )
    artifact_packet_contract_match = bool(
        artifact_entry_present
        and artifact_preflight.get("source_authoring_packet_id")
        and artifact_preflight.get("source_authoring_packet_id") == entry.get("source_authoring_packet_id")
        and artifact_preflight.get("source_authoring_packet_payload_sha256")
        and artifact_preflight.get("source_authoring_packet_payload_sha256") == entry.get("source_authoring_packet_payload_sha256")
        and artifact_preflight.get("source_authorization_packet_id_match")
        and artifact_preflight.get("source_authorization_packet_payload_sha256_match")
    )
    artifact_template_id_match = bool(
        artifact_entry_present
        and artifact_preflight.get("source_authorization_template_id_match")
        and artifact_preflight.get("source_authorization_template_sha256_match")
    )
    artifact_anchor_contract_id_match = bool(
        artifact_entry_present
        and artifact_preflight.get("source_anchor_binding_contract_id_match")
        and artifact_preflight.get("source_anchor_binding_contract_sha256_match")
    )
    artifact_match = bool(
        artifact_entry_present
        and artifact_ready
        and artifact_text_hash_match
        and artifact_work_order_contract_match
        and artifact_packet_contract_match
        and artifact_template_id_match
        and artifact_anchor_contract_id_match
    )
    authorized = bool(
        entry.get("authorized")
        and sha_match
        and statement_match
        and scope_match
        and operator_present
        and authorization_ref_present
        and source_labels_match
        and template_schema_match
        and template_id_match
        and template_sha_match
        and expected_path_match
        and anchor_contract_schema_match
        and anchor_contract_id_match
        and anchor_contract_sha_match
        and preflight_match
        and artifact_match
    )
    stale = bool(entry.get("authorized") and not sha_match)
    if authorized:
        reason = ""
    elif not entry.get("authorized"):
        reason = "source authorization manifest entry is not marked authorized"
    elif not scope_match:
        reason = "source authorization manifest scope does not permit proof-body source intake"
    elif not sha_match:
        reason = "source authorization manifest text_sha256 does not match the Lean source file"
    elif not statement_match:
        reason = "source authorization manifest expected statement contract does not match the proof body contract"
    elif not operator_present or not authorization_ref_present:
        reason = "source authorization manifest entry lacks operator_id or authorization_ref audit metadata"
    elif not template_schema_match or not template_id_match or not template_sha_match:
        reason = "source authorization manifest entry is not bound to the expected capstone-issued authorization template"
    elif not expected_path_match:
        reason = "source authorization manifest entry path does not match the capstone-issued expected source path"
    elif not anchor_contract_schema_match or not anchor_contract_id_match or not anchor_contract_sha_match:
        reason = "source authorization manifest entry is not bound to the expected source-anchor binding contract"
    elif not preflight_entry_present:
        reason = "source authorization manifest entry lacks a matching authorization-preflight report item"
    elif not preflight_ready:
        reason = "source authorization manifest entry did not pass authorization preflight"
    elif not preflight_text_hash_match:
        reason = "source authorization manifest entry hash does not match authorization-preflight evidence"
    elif not preflight_template_id_match or not preflight_anchor_contract_id_match:
        reason = "source authorization manifest entry contract does not match authorization-preflight evidence"
    elif not artifact_entry_present:
        reason = "source authorization manifest entry lacks a matching work-order artifact-preflight report item"
    elif not artifact_ready:
        reason = "source authorization manifest entry did not pass work-order artifact preflight"
    elif not artifact_text_hash_match:
        reason = "source authorization manifest entry hash does not match work-order artifact-preflight evidence"
    elif not artifact_work_order_contract_match or not artifact_packet_contract_match:
        reason = "source authorization manifest entry is not bound to matching work-order and authoring-packet artifact-preflight evidence"
    elif not artifact_template_id_match or not artifact_anchor_contract_id_match:
        reason = "source authorization manifest entry contract does not match work-order artifact-preflight evidence"
    else:
        reason = "source authorization manifest source_labels do not cover the expected source labels"
    return {
        "source_authorized": authorized,
        "source_authorization_manifest_path": entry.get("manifest_path") or "",
        "source_authorization_scope": entry.get("authorization_scope") or "",
        "source_authorization_entry_present": True,
        "source_authorization_sha256_match": sha_match,
        "source_authorization_statement_contract_match": statement_match,
        "source_authorization_operator_id_present": operator_present,
        "source_authorization_ref_present": authorization_ref_present,
        "source_authorization_source_labels_match": source_labels_match,
        "source_authorization_template_schema_id_match": template_schema_match,
        "source_authorization_template_id_match": template_id_match,
        "source_authorization_template_sha256_match": template_sha_match,
        "source_authorization_expected_path_match": expected_path_match,
        "source_authorization_anchor_contract_schema_id_match": anchor_contract_schema_match,
        "source_authorization_anchor_contract_id_match": anchor_contract_id_match,
        "source_authorization_anchor_contract_sha256_match": anchor_contract_sha_match,
        "source_authorization_preflight_report_present": bool(authorization_preflight_report_present),
        "source_authorization_preflight_entry_present": preflight_entry_present,
        "source_authorization_preflight_ready": preflight_ready,
        "source_authorization_preflight_text_sha256_match": preflight_text_hash_match,
        "source_authorization_preflight_template_id_match": preflight_template_id_match,
        "source_authorization_preflight_anchor_contract_id_match": preflight_anchor_contract_id_match,
        "source_authoring_artifact_preflight_report_present": bool(artifact_preflight_report_present),
        "source_authoring_artifact_preflight_entry_present": artifact_entry_present,
        "source_authoring_artifact_preflight_ready": artifact_ready,
        "source_authoring_artifact_preflight_text_sha256_match": artifact_text_hash_match,
        "source_authoring_artifact_preflight_work_order_contract_match": artifact_work_order_contract_match,
        "source_authoring_artifact_preflight_packet_contract_match": artifact_packet_contract_match,
        "source_authoring_artifact_preflight_template_id_match": artifact_template_id_match,
        "source_authoring_artifact_preflight_anchor_contract_id_match": artifact_anchor_contract_id_match,
        "source_authoring_work_order_id": entry.get("source_authoring_work_order_id") or "",
        "source_authoring_work_order_payload_sha256": entry.get("source_authoring_work_order_payload_sha256") or "",
        "source_authoring_packet_id": entry.get("source_authoring_packet_id") or "",
        "source_authoring_packet_payload_sha256": entry.get("source_authoring_packet_payload_sha256") or "",
        "source_authorization_template_id": entry.get("source_authorization_template_id") or "",
        "source_authorization_template_sha256": entry.get("source_authorization_template_sha256") or "",
        "source_anchor_binding_contract_id": entry.get("source_anchor_binding_contract_id") or "",
        "source_anchor_binding_contract_sha256": entry.get("source_anchor_binding_contract_sha256") or "",
        "expected_source_authorization_template_id": expected_template["source_authorization_template_id"],
        "expected_source_authorization_template_sha256": expected_template["source_authorization_template_sha256"],
        "expected_source_anchor_binding_contract_id": expected_anchor_contract_id,
        "expected_source_anchor_binding_contract_sha256": expected_anchor_contract_sha,
        "source_authorization_stale": stale,
        "source_authorization_blocking_reason": reason,
        "source_authorization_operator_id": entry.get("operator_id") or "",
        "source_authorization_ref": entry.get("authorization_ref") or "",
    }


def _classify_proof_body(item, lean_candidates, authorization_entries, authorization_preflight_entries, authorization_preflight_report_present, artifact_preflight_entries, artifact_preflight_report_present):
    expected_name = item.get("expected_lean_proof_name") or ""
    expected_statement_field = _expected_statement_field_name(item)
    matching = []
    for candidate in lean_candidates:
        for body in candidate.get("_bodies") or []:
            if body.get("name") != expected_name:
                continue
            if not body.get("top_level_namespace"):
                continue
            statement_text = str(body.get("_statement_text") or "")
            statement_contract_marker_count = statement_text.count(expected_statement_field)
            local_statement_contract_definition_marker_count = _local_statement_contract_definition_count(
                candidate.get("_source_text_without_comments") or "",
                expected_statement_field,
            )
            local_statement_contract_defined = bool(local_statement_contract_definition_marker_count)
            source_authorization = _source_authorization_for(
                item,
                candidate,
                expected_statement_field,
                authorization_entries,
                authorization_preflight_entries,
                authorization_preflight_report_present,
                artifact_preflight_entries,
                artifact_preflight_report_present,
            )
            shape_ready = bool(
                not body.get("placeholder_token_count")
                and not body.get("assumption_echo_marker_count")
                and not body.get("skeleton_echo_marker_count")
                and not body.get("vacuous_true_marker_count")
                and body.get("domain_statement_marker_count")
                and statement_contract_marker_count
                and not local_statement_contract_defined
            )
            ready = bool(shape_ready and source_authorization.get("source_authorized"))
            matching.append(
                {
                    "path": candidate.get("path") or "",
                    "relative_path": candidate.get("relative_path") or "",
                    "text_sha256": candidate.get("text_sha256") or "",
                    "matched_theorem_name": expected_name,
                    "expected_statement_field_name": expected_statement_field,
                    "kind": body.get("kind") or "",
                    "line_start": body.get("line_start") or 0,
                    "line_end": body.get("line_end") or 0,
                    "body_text_sha256": body.get("body_text_sha256") or "",
                    "statement_text_sha256": body.get("statement_text_sha256") or "",
                    "domain_statement_marker_count": body.get("domain_statement_marker_count", 0),
                    "non_domain_statement_marker_count": body.get("non_domain_statement_marker_count", 0),
                    "statement_contract_marker_count": statement_contract_marker_count,
                    "statement_contract_mismatch_marker_count": 0 if statement_contract_marker_count else 1,
                    "local_statement_contract_definition_marker_count": local_statement_contract_definition_marker_count,
                    "local_statement_contract_defined": local_statement_contract_defined,
                    "placeholder_token_count": body.get("placeholder_token_count", 0),
                    "assumption_echo_marker_count": body.get("assumption_echo_marker_count", 0),
                    "skeleton_echo_marker_count": body.get("skeleton_echo_marker_count", 0),
                    "vacuous_true_marker_count": body.get("vacuous_true_marker_count", 0),
                    "source_shape_blocking_reason": (
                        "source-tree Lean theorem body locally defines its expected statement contract; imported/source-backed statement context is required"
                        if local_statement_contract_defined
                        else ""
                    ),
                    "shape_ready_without_authorization": shape_ready,
                    "ready": ready,
                    **source_authorization,
                }
            )
    ready_matches = [candidate for candidate in matching if candidate.get("ready")]
    shape_ready_matches = [candidate for candidate in matching if candidate.get("shape_ready_without_authorization")]
    local_statement_contract_definition_count = sum(1 for candidate in matching if candidate.get("local_statement_contract_defined"))
    stale_authorization_count = sum(1 for candidate in matching if candidate.get("source_authorization_stale"))
    missing_authorization_count = sum(1 for candidate in matching if not candidate.get("source_authorization_entry_present"))
    return {
        "lean_premise_name": item.get("lean_premise_name") or "",
        "expected_lean_proof_name": expected_name,
        "expected_statement_field_name": expected_statement_field,
        "dispatch_group": item.get("dispatch_group") or "",
        "source_labels": list(item.get("source_labels") or []),
        "source_anchor_kinds": list(item.get("source_anchor_kinds") or []),
        "source_anchor_translation_ready": bool(item.get("source_anchor_translation_ready")),
        "source_theorem_statement_ready": bool(item.get("source_theorem_statement_ready")),
        "skeleton_rejected_as_production": bool(item.get("skeleton_rejected_as_production")),
        "source_theorem_proof_body_source_required": True,
        "source_theorem_proof_body_source_candidate_count": len(matching),
        "source_theorem_proof_body_source_ready_count": len(ready_matches),
        "source_theorem_proof_body_ready": bool(ready_matches),
        "blocking": not bool(ready_matches),
        "blocking_reason": "" if ready_matches else (
            "source-tree Lean theorem body has the expected shape but lacks a current authorization manifest entry"
            if shape_ready_matches and (missing_authorization_count or stale_authorization_count)
            else "source-tree Lean theorem body locally defines its expected statement contract; imported/source-backed statement context is required"
            if local_statement_contract_definition_count
            else "no source-tree Lean theorem body with the expected statement contract, domain statement shape, and without placeholder, skeleton echo, vacuous True, assumption echo, or missing authorization was found"
        ),
        "candidate_bodies": matching[:10],
    }


def _apply_lean_checks(classifications, lean_candidates, source_root, lean_executable, lake_executable, timeout_seconds, runner):
    candidates_by_path = {candidate.get("path") or "": candidate for candidate in lean_candidates}
    cache = {}
    for classification in classifications:
        for body in classification.get("candidate_bodies") or []:
            shape_and_authorized = bool(body.get("shape_ready_without_authorization") and body.get("source_authorized"))
            candidate = candidates_by_path.get(body.get("path") or "") or {}
            if not shape_and_authorized or not candidate:
                body["source_tree_lean_check_performed"] = False
                body["source_tree_lean_exit_zero"] = False
                body["source_tree_lean_exit_code"] = None
                body["source_tree_lean_check_timed_out"] = False
                body["ready"] = False
                continue
            lean_check = _lean_check_for_candidate(
                candidate,
                source_root,
                lean_executable,
                lake_executable,
                timeout_seconds,
                runner,
                cache,
            )
            body["source_tree_lean_check_performed"] = True
            body["source_tree_lean_exit_zero"] = bool(lean_check.get("exit_zero"))
            body["source_tree_lean_exit_code"] = lean_check.get("exit_code")
            body["source_tree_lean_check_timed_out"] = bool(lean_check.get("timed_out"))
            body["source_tree_lean_check_command"] = list(lean_check.get("command") or [])
            body["source_tree_lean_check_stdout"] = lean_check.get("stdout") or ""
            body["source_tree_lean_check_stderr"] = lean_check.get("stderr") or ""
            body["ready"] = bool(lean_check.get("exit_zero"))
            if not body["ready"]:
                body["source_authorization_blocking_reason"] = "source-tree Lean file did not pass local Lean check"
        ready_matches = [candidate for candidate in classification.get("candidate_bodies") or [] if candidate.get("ready")]
        shape_ready_matches = [
            candidate
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("shape_ready_without_authorization")
        ]
        lean_check_fail_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_tree_lean_check_performed") and not candidate.get("source_tree_lean_exit_zero")
        )
        missing_authorization_count = sum(1 for candidate in classification.get("candidate_bodies") or [] if not candidate.get("source_authorization_entry_present"))
        stale_authorization_count = sum(1 for candidate in classification.get("candidate_bodies") or [] if candidate.get("source_authorization_stale"))
        local_statement_contract_definition_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("local_statement_contract_defined")
        )
        preflight_block_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and (
                not candidate.get("source_authorization_preflight_entry_present")
                or not candidate.get("source_authorization_preflight_ready")
                or not candidate.get("source_authorization_preflight_text_sha256_match")
                or not candidate.get("source_authorization_preflight_template_id_match")
                or not candidate.get("source_authorization_preflight_anchor_contract_id_match")
            )
        )
        artifact_block_count = sum(
            1
            for candidate in classification.get("candidate_bodies") or []
            if candidate.get("source_authorization_entry_present")
            and candidate.get("source_authorization_preflight_entry_present")
            and candidate.get("source_authorization_preflight_ready")
            and (
                not candidate.get("source_authoring_artifact_preflight_entry_present")
                or not candidate.get("source_authoring_artifact_preflight_ready")
                or not candidate.get("source_authoring_artifact_preflight_text_sha256_match")
                or not candidate.get("source_authoring_artifact_preflight_work_order_contract_match")
                or not candidate.get("source_authoring_artifact_preflight_packet_contract_match")
                or not candidate.get("source_authoring_artifact_preflight_template_id_match")
                or not candidate.get("source_authoring_artifact_preflight_anchor_contract_id_match")
            )
        )
        classification["source_theorem_proof_body_source_ready_count"] = len(ready_matches)
        classification["source_theorem_proof_body_ready"] = bool(ready_matches)
        classification["blocking"] = not bool(ready_matches)
        if ready_matches:
            classification["blocking_reason"] = ""
        elif shape_ready_matches and lean_check_fail_count:
            classification["blocking_reason"] = "source-tree Lean theorem body has expected shape and authorization but fails local Lean check"
        elif shape_ready_matches and (missing_authorization_count or stale_authorization_count):
            classification["blocking_reason"] = "source-tree Lean theorem body has the expected shape but lacks a current authorization manifest entry"
        elif shape_ready_matches and preflight_block_count:
            classification["blocking_reason"] = "source-tree Lean theorem body has the expected shape and authorization manifest but lacks matching authorization-preflight evidence"
        elif shape_ready_matches and artifact_block_count:
            classification["blocking_reason"] = "source-tree Lean theorem body has the expected shape and authorization manifest but lacks matching work-order artifact-preflight evidence"
        elif local_statement_contract_definition_count:
            classification["blocking_reason"] = "source-tree Lean theorem body locally defines its expected statement contract; imported/source-backed statement context is required"
        else:
            classification["blocking_reason"] = "no source-tree Lean theorem body with the expected statement contract, domain statement shape, without placeholder, skeleton echo, vacuous True, assumption echo, missing authorization, or Lean check failure was found"
    return cache


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report,
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report=None,
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report=None,
    source_root=".",
    candidate_limit=500,
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    implementation_plan_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report or {}
    authorization_preflight_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report or {}
    artifact_preflight_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _implementation_plan_issues(implementation_plan_report)
    authorization_preflight_issues = _authorization_preflight_issues(authorization_preflight_report)
    validation_issues.extend(authorization_preflight_issues)
    artifact_preflight_issues = _artifact_preflight_issues(artifact_preflight_report)
    validation_issues.extend(artifact_preflight_issues)
    machine_checked = bool(implementation_plan_report.get("production_claim_machine_checked"))
    implementation_items = list(implementation_plan_report.get("source_theorem_proof_body_implementation_items") or [])
    for item in implementation_items:
        expected_source_path = item.get("expected_source_tree_relative_path") or ""
        if expected_source_path and not _safe_relative_source_path(expected_source_path):
            _issue(
                validation_issues,
                "source_theorem_proof_body_implementation_item_expected_source_path_unsafe",
                item.get("expected_lean_proof_name") or expected_source_path,
            )
    lean_candidates = _scan_lean_sources(source_root_path, candidate_limit)
    expected_source_paths = [
        item.get("expected_source_tree_relative_path") or SUGGESTED_LEAN_SOURCE_PATH
        for item in implementation_items
    ]
    authorization_manifests, authorization_entries, authorization_issues = _scan_source_authorization_manifests(source_root_path, expected_source_paths=expected_source_paths)
    authorization_preflight_entries = _authorization_preflight_entries(authorization_preflight_report)
    authorization_preflight_report_present = bool(authorization_preflight_report)
    artifact_preflight_entries = _artifact_preflight_entries(artifact_preflight_report)
    artifact_preflight_report_present = bool(artifact_preflight_report)
    validation_issues.extend(authorization_issues)
    public_candidates = [{k: v for k, v in candidate.items() if not k.startswith("_")} for candidate in lean_candidates]
    classifications = [
        _classify_proof_body(
            item,
            lean_candidates,
            authorization_entries,
            authorization_preflight_entries,
            authorization_preflight_report_present,
            artifact_preflight_entries,
            artifact_preflight_report_present,
        )
        for item in implementation_items
    ]
    lean_check_cache = _apply_lean_checks(
        classifications,
        lean_candidates,
        source_root_path,
        lean_executable,
        lake_executable,
        timeout_seconds,
        runner,
    )
    ready_count = sum(1 for item in classifications if item.get("source_theorem_proof_body_ready"))
    candidate_count = sum(int(item.get("source_theorem_proof_body_source_candidate_count") or 0) for item in classifications)
    placeholder_count = sum(int(item.get("placeholder_body_candidate_count") or 0) for item in public_candidates)
    assumption_echo_count = sum(int(item.get("assumption_echo_body_candidate_count") or 0) for item in public_candidates)
    skeleton_echo_count = sum(int(item.get("skeleton_echo_body_candidate_count") or 0) for item in public_candidates)
    vacuous_true_count = sum(int(item.get("vacuous_true_body_candidate_count") or 0) for item in public_candidates)
    non_domain_statement_count = sum(int(item.get("non_domain_statement_body_candidate_count") or 0) for item in public_candidates)
    domain_statement_count = sum(int(item.get("domain_statement_body_candidate_count") or 0) for item in public_candidates)
    statement_contract_count = sum(
        int(body.get("statement_contract_marker_count") or 0)
        for item in classifications
        for body in item.get("candidate_bodies") or []
    )
    statement_contract_mismatch_count = sum(
        int(body.get("statement_contract_mismatch_marker_count") or 0)
        for item in classifications
        for body in item.get("candidate_bodies") or []
    )
    local_statement_contract_definition_count = sum(
        int(body.get("local_statement_contract_definition_marker_count") or 0)
        for item in classifications
        for body in item.get("candidate_bodies") or []
    )
    source_authorized_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorized")
    )
    source_authorization_missing_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if not body.get("source_authorization_entry_present")
    )
    source_authorization_stale_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_stale")
    )
    source_authorization_metadata_missing_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and (not body.get("source_authorization_operator_id_present") or not body.get("source_authorization_ref_present"))
    )
    source_authorization_source_labels_mismatch_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present") and not body.get("source_authorization_source_labels_match")
    )
    source_authorization_template_mismatch_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and (
            not body.get("source_authorization_template_schema_id_match")
            or not body.get("source_authorization_template_id_match")
            or not body.get("source_authorization_template_sha256_match")
            or not body.get("source_authorization_expected_path_match")
        )
    )
    source_authorization_anchor_contract_mismatch_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and (
            body.get("expected_source_anchor_binding_contract_id")
            or body.get("expected_source_anchor_binding_contract_sha256")
        )
        and (
            not body.get("source_authorization_anchor_contract_schema_id_match")
            or not body.get("source_authorization_anchor_contract_id_match")
            or not body.get("source_authorization_anchor_contract_sha256_match")
        )
    )
    source_authorization_preflight_ready_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and body.get("source_authorization_preflight_entry_present")
        and body.get("source_authorization_preflight_ready")
        and body.get("source_authorization_preflight_text_sha256_match")
        and body.get("source_authorization_preflight_template_id_match")
        and body.get("source_authorization_preflight_anchor_contract_id_match")
    )
    source_authorization_preflight_missing_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present") and not body.get("source_authorization_preflight_entry_present")
    )
    source_authorization_preflight_mismatch_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and body.get("source_authorization_preflight_entry_present")
        and (
            not body.get("source_authorization_preflight_ready")
            or not body.get("source_authorization_preflight_text_sha256_match")
            or not body.get("source_authorization_preflight_template_id_match")
            or not body.get("source_authorization_preflight_anchor_contract_id_match")
        )
    )
    source_authoring_artifact_preflight_ready_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and body.get("source_authoring_artifact_preflight_entry_present")
        and body.get("source_authoring_artifact_preflight_ready")
        and body.get("source_authoring_artifact_preflight_text_sha256_match")
        and body.get("source_authoring_artifact_preflight_work_order_contract_match")
        and body.get("source_authoring_artifact_preflight_packet_contract_match")
        and body.get("source_authoring_artifact_preflight_template_id_match")
        and body.get("source_authoring_artifact_preflight_anchor_contract_id_match")
    )
    source_authoring_artifact_preflight_missing_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present") and not body.get("source_authoring_artifact_preflight_entry_present")
    )
    source_authoring_artifact_preflight_mismatch_count = sum(
        1
        for item in classifications
        for body in item.get("candidate_bodies") or []
        if body.get("source_authorization_entry_present")
        and body.get("source_authoring_artifact_preflight_entry_present")
        and (
            not body.get("source_authoring_artifact_preflight_ready")
            or not body.get("source_authoring_artifact_preflight_text_sha256_match")
            or not body.get("source_authoring_artifact_preflight_work_order_contract_match")
            or not body.get("source_authoring_artifact_preflight_packet_contract_match")
            or not body.get("source_authoring_artifact_preflight_template_id_match")
            or not body.get("source_authoring_artifact_preflight_anchor_contract_id_match")
        )
    )
    lean_check_results = list(lean_check_cache.values())
    lean_check_candidate_count = len(lean_check_results)
    lean_check_pass_count = sum(1 for item in lean_check_results if item.get("exit_zero"))
    lean_check_timeout_count = sum(1 for item in lean_check_results if item.get("timed_out"))
    lean_check_fail_count = sum(1 for item in lean_check_results if not item.get("exit_zero"))
    all_ready = bool(classifications and ready_count == len(classifications))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_consumable", not _implementation_plan_issues(implementation_plan_report), "proof_body_implementation_plan_report_not_consumable"),
        _check("source_authorization_preflight_report_consumable_if_provided", not authorization_preflight_issues, "source_authorization_preflight_report_not_consumable"),
        _check("source_authoring_artifact_preflight_report_consumable_if_provided", not artifact_preflight_issues, "source_authoring_artifact_preflight_report_not_consumable"),
        _check("source_theorem_proof_body_requirements_present", bool(implementation_items), "source_theorem_proof_body_requirements_missing"),
        _check("generated_logs_excluded", True, ""),
        _check("source_tree_scan_performed", True, ""),
        _check("source_theorem_proof_bodies_ready", all_ready or machine_checked, "source_theorem_proof_bodies_missing", severity="readiness"),
        _check("no_source_mutation", not implementation_plan_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not implementation_plan_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif authorization_preflight_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif artifact_preflight_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif authorization_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif all_ready:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck"
        next_agent_command = BUNDLE_RECHECK_COMMAND
    else:
        status = "PASS"
        state = SOURCE_REQUIRED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_construction_attempt"
        next_agent_command = SOURCE_THEOREM_PROOF_BODY_SOURCE_CONSTRUCTION_ATTEMPT_COMMAND
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_required": bool(status == "PASS" and not all_ready and not production_checked),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_sources_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_check_results[0].get("selected_lean") if lean_check_results else (lean_executable or shutil.which("lean") or "lean"),
        "lake_executable_path": lean_check_results[0].get("selected_lake") if lean_check_results else (lake_executable or shutil.which("lake") or ""),
        "claim_packet_id": implementation_plan_report.get("claim_packet_id") or "",
        "slug": implementation_plan_report.get("slug") or "",
        "source_root": str(source_root_path),
        "candidate_limit": int(candidate_limit or 0),
        "excluded_directory_names": sorted(EXCLUDED_DIR_NAMES),
        "source_authorization_manifest_paths": [item.get("path") or "" for item in authorization_manifests],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_path": implementation_plan_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report_sha256": implementation_plan_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_path": authorization_preflight_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report_sha256": authorization_preflight_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report_path": artifact_preflight_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report_sha256": artifact_preflight_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_body_requirement_count": len(implementation_items),
            "local_lean_file_count": len(public_candidates),
            "candidate_lean_source_file_count": len([item for item in public_candidates if item.get("theorem_or_lemma_body_count")]),
            "source_theorem_proof_body_source_candidate_count": candidate_count,
            "source_theorem_proof_body_source_ready_count": ready_count,
            "source_theorem_proof_body_source_missing_count": max(len(classifications) - ready_count, 0),
            "placeholder_body_candidate_count": placeholder_count,
            "assumption_echo_body_candidate_count": assumption_echo_count,
            "skeleton_echo_body_candidate_count": skeleton_echo_count,
            "vacuous_true_body_candidate_count": vacuous_true_count,
            "non_domain_statement_body_candidate_count": non_domain_statement_count,
            "domain_statement_body_candidate_count": domain_statement_count,
            "statement_contract_body_candidate_count": statement_contract_count,
            "statement_contract_mismatch_body_candidate_count": statement_contract_mismatch_count,
            "local_statement_contract_definition_body_candidate_count": local_statement_contract_definition_count,
            "source_authorization_manifest_count": len(authorization_manifests),
            "source_authorization_validation_issue_count": len(authorization_issues),
            "source_authorized_body_candidate_count": source_authorized_count,
            "source_authorization_missing_body_candidate_count": source_authorization_missing_count,
            "source_authorization_stale_body_candidate_count": source_authorization_stale_count,
            "source_authorization_metadata_missing_body_candidate_count": source_authorization_metadata_missing_count,
            "source_authorization_source_labels_mismatch_body_candidate_count": source_authorization_source_labels_mismatch_count,
            "source_authorization_template_mismatch_body_candidate_count": source_authorization_template_mismatch_count,
            "source_authorization_anchor_contract_mismatch_body_candidate_count": source_authorization_anchor_contract_mismatch_count,
            "source_authorization_preflight_report_present_count": 1 if authorization_preflight_report_present else 0,
            "source_authorization_preflight_ready_body_candidate_count": source_authorization_preflight_ready_count,
            "source_authorization_preflight_missing_body_candidate_count": source_authorization_preflight_missing_count,
            "source_authorization_preflight_mismatch_body_candidate_count": source_authorization_preflight_mismatch_count,
            "source_authoring_artifact_preflight_report_present_count": 1 if artifact_preflight_report_present else 0,
            "source_authoring_artifact_preflight_ready_body_candidate_count": source_authoring_artifact_preflight_ready_count,
            "source_authoring_artifact_preflight_missing_body_candidate_count": source_authoring_artifact_preflight_missing_count,
            "source_authoring_artifact_preflight_mismatch_body_candidate_count": source_authoring_artifact_preflight_mismatch_count,
            "source_tree_lean_check_candidate_file_count": lean_check_candidate_count,
            "source_tree_lean_check_pass_file_count": lean_check_pass_count,
            "source_tree_lean_check_fail_file_count": lean_check_fail_count,
            "source_tree_lean_check_timeout_file_count": lean_check_timeout_count,
            "generated_log_body_candidate_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_theorem_proof_body_source_intake_classifications": classifications,
        "candidate_lean_source_files": public_candidates,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan_report": implementation_plan_report,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authorization_preflight_report": authorization_preflight_report,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_authoring_work_order_artifact_preflight_report": artifact_preflight_report,
        "boundary": [
            "This command scans only local source-tree Lean files and excludes logs/paperctl/_batches, .lake, and dependency/cache directories.",
            "Generated reports, implementation plans, work items, skeleton bodies, placeholders, vacuous : True bodies, non-domain statements, statement-contract mismatches, and assumption-echo theorem bodies are not production proof bodies.",
            "The expected statement contract must come from an imported/source-backed context; a theorem body that locally defines its expected statement field is treated as synthetic and is not production-ready.",
            "A shape-valid Lean theorem body is still blocked unless a local proof-body-source authorization manifest names the file, theorem, statement contract, current file hash, covering source labels, operator_id, authorization_ref, capstone-issued authorization template id/hash, any expected source-anchor binding contract id/hash, and matching authorization-preflight plus work-order artifact-preflight report items.",
            "A shape-valid and authorization/artifact-preflight-valid Lean theorem body is still blocked unless the local Lean source file passes a Lean check.",
            "It does not prove ProfileEquivalenceTransfersDirectScoreLimitStatement or profileEquivalenceTransfersDirectScoreLimit.",
            "It writes only local reports and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Body Source Intake",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_source_intake_state') or ''}",
        f"- Proof body requirements: {summary.get('source_theorem_proof_body_requirement_count', 0)}",
        f"- Ready proof bodies: {summary.get('source_theorem_proof_body_source_ready_count', 0)}",
        f"- Missing proof bodies: {summary.get('source_theorem_proof_body_source_missing_count', 0)}",
        f"- Candidate Lean files: {summary.get('candidate_lean_source_file_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
