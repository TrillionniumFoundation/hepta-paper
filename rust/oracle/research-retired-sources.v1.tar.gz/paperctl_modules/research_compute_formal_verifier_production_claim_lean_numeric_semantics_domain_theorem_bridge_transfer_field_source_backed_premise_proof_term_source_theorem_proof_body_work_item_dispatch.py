"""Dispatch work items for missing premise source-theorem proof bodies."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-work-item-dispatch"
SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-construction"
SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-implementation-plan"

SOURCE_THEOREM_PROOF_BODY_OBSTRUCTION_RECORDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_OBSTRUCTION_RECORDED"
SOURCE_THEOREM_PROOF_BODY_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_MACHINE_CHECKED_CLOSED"

WORK_ITEMS_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_READY_SOURCE_PROOF_BODIES_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_BODY_WORK_ITEM_DISPATCH_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_body_work_items_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "source_theorem_proof_body_work_items",
    "dispatch_groups",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_body_construction_attempt_count",
    "source_theorem_proof_body_work_item_count",
    "ready_work_item_count",
    "blocking_work_item_count",
    "source_tree_proof_body_candidate_work_item_count",
    "source_tree_proof_body_ready_work_item_count",
    "missing_source_tree_proof_body_work_item_count",
    "skeleton_rejected_work_item_count",
    "dispatch_group_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes source theorem proof-body construction obstruction and emits one work item per missing source-tree proof body.",
    "Dispatch work items are planning artifacts and are not source theorem proofs or proof bodies.",
    "Generated logs, skeletons, placeholders, field forwarding, statement assumptions, premise assumptions, and assumption echo remain rejected proof sources.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
ANCHOR_KIND_BY_PREFIX = {
    "thm": "manuscript_theorem_anchor",
    "app": "manuscript_appendix_proof_anchor",
    "prop": "manuscript_proposition_anchor",
    "cor": "manuscript_corollary_anchor",
    "ass": "manuscript_assumption_anchor",
}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _body_construction_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_missing")
        return issues
    if report.get("command") != SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_state") or ""
    if state not in {SOURCE_THEOREM_PROOF_BODY_OBSTRUCTION_RECORDED_STATE, SOURCE_THEOREM_PROOF_BODY_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_body_construction_attempts") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_construction_attempts_missing")
    if not report.get("profile_equivalence_transfer_premise_source_theorem_proof_body_construction_obstruction_recorded") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_body_construction_obstruction_missing")
    for attempt in report.get("source_theorem_proof_body_construction_attempts") or []:
        candidate_count = int(attempt.get("source_tree_proof_body_candidate_count") or 0)
        ready_count = int(attempt.get("source_tree_proof_body_ready_count") or 0)
        proof_name = attempt.get("expected_lean_proof_name") or attempt.get("body_construction_attempt_id") or ""
        if ready_count > candidate_count:
            _issue(
                issues,
                "source_theorem_proof_body_ready_count_exceeds_candidate_count",
                proof_name,
            )
        if attempt.get("source_tree_proof_body_constructed") and ready_count <= 0:
            _issue(
                issues,
                "source_tree_proof_body_constructed_without_ready_body_evidence",
                proof_name,
            )
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_boundary:{key}")
    return issues


def _anchor_kind(label):
    prefix = str(label or "").split(":", 1)[0]
    return ANCHOR_KIND_BY_PREFIX.get(prefix, "source_anchor")


def _dispatch_group(source_labels):
    labels = list(source_labels or [])
    if not labels:
        return "unlabeled-source-theorem-proof-bodies"
    if any(str(label).startswith("cor:hf_calibration_schedule") for label in labels):
        return "high-frequency-rate-source-theorem-proof-bodies"
    if any(str(label).startswith("prop:fast_transfer") for label in labels):
        return "fast-transfer-source-theorem-proof-bodies"
    if any(str(label).startswith("prop:operational_certificate") for label in labels):
        return "operational-certificate-source-theorem-proof-bodies"
    if any(str(label).startswith("ass:direct_hf_input") for label in labels):
        return "direct-euler-input-source-theorem-proof-bodies"
    if any(str(label).startswith("thm:profile_equivalence") or str(label).startswith("app:profile_equivalence") for label in labels):
        return "profile-equivalence-source-theorem-proof-bodies"
    return "source-theorem-proof-body-obligations"


def _work_item(attempt, index):
    ready = bool(attempt.get("source_tree_proof_body_constructed"))
    source_labels = list(attempt.get("source_labels") or [])
    expected = attempt.get("expected_lean_proof_name") or f"sourceBackedPremiseTheorem{index}"
    return {
        "work_item_id": f"source-theorem-proof-body-{index:02d}-{expected}",
        "status": "ready" if ready else "blocked_on_source_tree_proof_body",
        "blocking": not ready,
        "lean_premise_name": attempt.get("lean_premise_name") or "",
        "expected_lean_proof_name": expected,
        "required_output_kind": "source_tree_no_placeholder_lean_proof_body",
        "source_labels": source_labels,
        "source_anchor_kinds": sorted({_anchor_kind(label) for label in source_labels}),
        "skeleton_statement_field_name": attempt.get("skeleton_statement_field_name") or "",
        "skeleton_rejected_as_production": bool(attempt.get("skeleton_rejected_as_production")),
        "source_tree_proof_body_candidate_count": int(attempt.get("source_tree_proof_body_candidate_count") or 0),
        "source_tree_proof_body_ready_count": int(attempt.get("source_tree_proof_body_ready_count") or 0),
        "source_tree_proof_body_ready": ready,
        "dispatch_group": attempt.get("dispatch_group") or _dispatch_group(source_labels),
        "must_not_use": [
            "logs/paperctl/_batches generated Lean artifacts",
            ".lake or dependency cache material",
            "sorry/admit/axiom/opaque placeholders",
            "field forwarding",
            "statement assumption echo",
            "premise assumption echo",
            "source theorem assumption echo",
            "skeleton theorem bodies",
            "implementation plans or dispatch work items",
        ],
        "next_required_action": (
            "replace the skeleton theorem body and recheck the source theorem proof"
            if ready
            else f"construct a source-tree no-placeholder proof body for {expected}"
        ),
        "blocking_reason": "" if ready else (attempt.get("blocking_reason") or "source-tree proof body construction is blocked"),
    }


def _group_counts(work_items):
    groups = {}
    for item in work_items:
        key = item.get("dispatch_group") or "ungrouped"
        bucket = groups.setdefault(
            key,
            {
                "dispatch_group": key,
                "work_item_count": 0,
                "ready_work_item_count": 0,
                "blocking_work_item_count": 0,
            },
        )
        bucket["work_item_count"] += 1
        if item.get("blocking"):
            bucket["blocking_work_item_count"] += 1
        else:
            bucket["ready_work_item_count"] += 1
    return list(groups.values())


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report,
    label=None,
):
    body_construction_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report or {}
    validation_issues = _body_construction_issues(body_construction_report)
    machine_checked = bool(body_construction_report.get("production_claim_machine_checked"))
    attempts = list(body_construction_report.get("source_theorem_proof_body_construction_attempts") or [])
    work_items = [_work_item(item, index + 1) for index, item in enumerate(attempts)]
    ready_count = sum(1 for item in work_items if not item.get("blocking"))
    blocking_count = sum(1 for item in work_items if item.get("blocking"))
    all_ready = bool(work_items and ready_count == len(work_items))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_consumable", not _body_construction_issues(body_construction_report), "source_theorem_proof_body_construction_report_not_consumable"),
        _check("source_theorem_proof_body_work_items_present", bool(work_items), "source_theorem_proof_body_work_items_missing"),
        _check("blocking_source_tree_proof_bodies_dispatched", bool(blocking_count) or all_ready or machine_checked, "blocking_source_tree_proof_bodies_not_dispatched", severity="readiness"),
        _check("dispatch_not_production_proof", not machine_checked or body_construction_report.get("production_claim_machine_checked"), "dispatch_must_not_promote_production"),
        _check("no_source_mutation", not body_construction_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not body_construction_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif work_items:
        status = "PASS"
        state = WORK_ITEMS_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_implementation_plan" if blocking_count else "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_bundle_recheck"
        next_agent_command = SOURCE_THEOREM_PROOF_BODY_IMPLEMENTATION_PLAN_COMMAND if blocking_count else ""
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    groups = _group_counts(work_items)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_body_work_items_ready": bool(status == "PASS" and work_items),
        "profile_equivalence_transfer_premise_source_theorem_proof_bodies_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "production_claim_machine_checked": production_checked,
        "claim_packet_id": body_construction_report.get("claim_packet_id") or "",
        "slug": body_construction_report.get("slug") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_path": body_construction_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report_sha256": body_construction_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_body_construction_attempt_count": len(attempts),
            "source_theorem_proof_body_work_item_count": len(work_items),
            "ready_work_item_count": ready_count,
            "blocking_work_item_count": blocking_count,
            "source_tree_proof_body_candidate_work_item_count": sum(1 for item in work_items if item.get("source_tree_proof_body_candidate_count")),
            "source_tree_proof_body_ready_work_item_count": sum(1 for item in work_items if item.get("source_tree_proof_body_ready_count")),
            "missing_source_tree_proof_body_work_item_count": blocking_count,
            "skeleton_rejected_work_item_count": sum(1 for item in work_items if item.get("skeleton_rejected_as_production")),
            "dispatch_group_count": len(groups),
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_theorem_proof_body_work_items": work_items,
        "dispatch_groups": groups,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction_report": body_construction_report,
        "boundary": [
            "This command dispatches source theorem proof-body work items only; a work item is not a proof body.",
            "Generated logs, source anchors alone, skeleton bodies, placeholders, field forwarding, statement assumptions, premise assumptions, and assumption echo remain rejected as production proof.",
            "ProfileEquivalenceTransfersDirectScoreLimitStatement and profileEquivalenceTransfersDirectScoreLimit remain unproved until all sourceBacked theorem proof bodies are constructed, bundled, and composed.",
            "It writes only local reports and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Body Work Item Dispatch",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_work_item_dispatch_state') or ''}",
        f"- Work items: {summary.get('source_theorem_proof_body_work_item_count', 0)}",
        f"- Blocking work items: {summary.get('blocking_work_item_count', 0)}",
        f"- Ready work items: {summary.get('ready_work_item_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
