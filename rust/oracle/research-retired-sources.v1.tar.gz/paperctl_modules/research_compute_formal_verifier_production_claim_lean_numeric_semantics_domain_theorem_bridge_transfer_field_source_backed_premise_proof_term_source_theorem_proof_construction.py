"""Record Lean-checked construction obstruction for premise source theorem proofs."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-construction"
SOURCE_THEOREM_PROOF_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-source-intake"
SOURCE_THEOREM_PROOF_WORK_ITEM_DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-work-item-dispatch"

SOURCE_PROOF_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
SOURCE_PROOF_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SOURCE_INTAKE_READY"
SOURCE_PROOF_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

OBSTRUCTION_RECORDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_CONSTRUCTION_OBSTRUCTION_RECORDED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_CONSTRUCTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_CONSTRUCTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_CONSTRUCTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_construction_obstruction_recorded",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_theorem_proof_construction_attempts",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_requirement_count",
    "source_theorem_proof_construction_attempt_count",
    "source_theorem_proof_construction_ready_count",
    "source_theorem_proof_construction_blocking_count",
    "source_theorem_proof_source_candidate_count",
    "source_theorem_proof_source_ready_count",
    "expected_source_theorem_declaration_count",
    "target_theorem_declaration_count",
    "lean_structure_count",
    "lean_inductive_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "obstruction_theorem_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes premise source-theorem proof-source intake and runs Lean on an obstruction taxonomy for missing source theorem proof construction.",
    "The generated Lean file declares no expected source theorem and no target transfer theorem.",
    "This command records proof construction obstruction only; it is not production proof.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
INDUCTIVE_RE = re.compile(r"^\s*inductive\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"
OBSTRUCTION_THEOREM_NAME = "profileEquivalencePremiseSourceTheoremProofConstructionObstructionDraft"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _intake_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_missing")
        return issues
    if report.get("command") != SOURCE_THEOREM_PROOF_SOURCE_INTAKE_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_state") or ""
    if state not in {SOURCE_PROOF_REQUIRED_STATE, SOURCE_PROOF_READY_STATE, SOURCE_PROOF_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_source_intake_classifications") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_source_intake_classifications_missing")
    if not report.get("production_claim_machine_checked"):
        classifications = list(report.get("source_theorem_proof_source_intake_classifications") or [])
        for item in classifications:
            ready_count = int(item.get("source_theorem_proof_source_ready_count") or 0)
            candidate_count = int(item.get("source_theorem_proof_source_candidate_count") or 0)
            if ready_count > candidate_count:
                _issue(
                    issues,
                    "source_theorem_proof_source_ready_count_exceeds_candidate_count",
                    item.get("expected_lean_proof_name") or "",
                )
            ready_sources = [candidate for candidate in item.get("candidate_sources") or [] if candidate.get("ready")]
            if ready_count and len(ready_sources) < ready_count:
                _issue(
                    issues,
                    "source_theorem_proof_source_ready_count_without_ready_candidate_sources",
                    item.get("expected_lean_proof_name") or "",
                )
        if report.get("profile_equivalence_transfer_premise_source_theorem_proof_sources_ready") and any(
            not int(item.get("source_theorem_proof_source_ready_count") or 0)
            for item in classifications
        ):
            _issue(issues, "source_theorem_proof_sources_ready_without_all_ready_classifications")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_boundary:{key}")
    return issues


def _lean_name(value, fallback):
    text = re.sub(r"[^A-Za-z0-9_]", "", str(value or fallback))
    if not text:
        text = fallback
    return f"{text[:1].lower()}{text[1:]}"


def _lean_source(classifications):
    constructors = []
    fields = []
    theorem_args = []
    for item in classifications:
        theorem_name = item.get("expected_lean_proof_name") or item.get("lean_premise_name") or "sourceTheoremProof"
        constructor = _lean_name(theorem_name, "sourceTheoremProof")
        field = f"{constructor}Blocked"
        constructors.append(f"  | {constructor}")
        fields.append(f"  {field} : Prop")
        theorem_args.append(f"    (_h{field[:1].upper()}{field[1:]} : O.{field})")
    if not constructors:
        constructors.append("  | noSourceTheoremProof")
        fields.append("  noSourceTheoremProofBlocked : Prop")
        theorem_args.append("    (_hNoSourceTheoremProofBlocked : O.noSourceTheoremProofBlocked)")
    return """import Mathlib

namespace NSMAoSFormalization

noncomputable section

inductive ProfileEquivalencePremiseSourceTheoremProofName where
{constructors}
  deriving DecidableEq, Repr

structure ProfileEquivalencePremiseSourceTheoremProofConstructionAttempt where
  theoremName : ProfileEquivalencePremiseSourceTheoremProofName
  sourceAnchorReady : Prop
  localNoPlaceholderLeanProofSourceFound : Prop
  sourceTheoremProofConstructed : Prop
  constructionBlocked : Prop

structure ProfileEquivalencePremiseSourceTheoremProofConstructionObstruction where
{fields}

theorem profileEquivalencePremiseSourceTheoremProofConstructionObstructionDraft
    (O : ProfileEquivalencePremiseSourceTheoremProofConstructionObstruction)
{theorem_args} :
    True := by
  exact True.intro

end

end NSMAoSFormalization
""".format(
        constructors="\n".join(constructors),
        fields="\n".join(fields),
        theorem_args="\n".join(theorem_args),
    )


def _run_lean(source_info, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(source_info["path"])
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": 124,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def _attempts(classifications):
    attempts = []
    for item in classifications:
        ready_candidates = int(item.get("source_theorem_proof_source_ready_count") or 0)
        source_candidates = int(item.get("source_theorem_proof_source_candidate_count") or 0)
        expected = item.get("expected_lean_proof_name") or ""
        attempts.append(
            {
                "lean_premise_name": item.get("lean_premise_name") or "",
                "expected_lean_proof_name": expected,
                "dispatch_group": item.get("dispatch_group") or "",
                "source_labels": list(item.get("source_labels") or []),
                "source_anchors_ready": bool(item.get("source_anchors_ready")),
                "source_theorem_proof_source_candidate_count": source_candidates,
                "source_theorem_proof_source_ready_count": ready_candidates,
                "source_theorem_proof_constructed": False,
                "construction_blocked": not bool(ready_candidates),
                "blocking_reason": item.get("blocking_reason") or "source theorem proof source is not ready",
                "next_required_action": f"construct a source-tree no-placeholder proof for {expected}" if expected else "construct a source-tree no-placeholder source theorem proof",
            }
        )
    return attempts


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report,
    output_root,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    intake_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _intake_issues(intake_report)
    machine_checked = bool(intake_report.get("production_claim_machine_checked"))
    classifications = list(intake_report.get("source_theorem_proof_source_intake_classifications") or [])
    attempts = _attempts(classifications)
    lean_text = _lean_source(classifications)
    output_root = pathlib.Path(output_root)
    source_info = _write_text(output_root / "ProfileEquivalencePremiseSourceTheoremProofConstruction.lean", lean_text)
    lean_result = _run_lean(source_info, source_root_path, lean_executable, lake_executable, timeout_seconds, runner=runner)
    theorem_names = THEOREM_RE.findall(lean_text)
    structures = STRUCTURE_RE.findall(lean_text)
    inductives = INDUCTIVE_RE.findall(lean_text)
    placeholders = PLACEHOLDER_RE.findall(lean_text)
    expected_source_theorem_names = {item.get("expected_lean_proof_name") for item in classifications if item.get("expected_lean_proof_name")}
    expected_source_theorem_declarations = [name for name in theorem_names if name in expected_source_theorem_names]
    target_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    target_declarations.extend([name for name in structures if name == TARGET_STATEMENT_NAME])
    lean_exit_zero = bool(lean_result.get("exit_code") == 0 and not lean_result.get("timed_out"))
    blocking_count = sum(1 for item in attempts if item.get("construction_blocked"))
    ready_count = sum(1 for item in attempts if item.get("source_theorem_proof_constructed"))
    candidate_count = sum(int(item.get("source_theorem_proof_source_candidate_count") or 0) for item in attempts)
    source_ready_count = sum(int(item.get("source_theorem_proof_source_ready_count") or 0) for item in attempts)
    obstruction_recorded = bool(lean_exit_zero and OBSTRUCTION_THEOREM_NAME in theorem_names and attempts and blocking_count)
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_consumable", not _intake_issues(intake_report), "source_theorem_proof_source_intake_not_consumable"),
        _check("source_theorem_proof_requirements_present", bool(classifications), "source_theorem_proof_requirements_missing"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("obstruction_theorem_present", OBSTRUCTION_THEOREM_NAME in theorem_names, "obstruction_theorem_missing"),
        _check("no_expected_source_theorem_declarations", not expected_source_theorem_declarations, "expected_source_theorem_declared_without_source_proof"),
        _check("target_theorem_not_declared", not target_declarations, "target_theorem_or_statement_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("source_theorem_proof_construction_blocking_recorded", bool(blocking_count) or machine_checked, "source_theorem_proof_construction_blocking_missing", severity="readiness"),
        _check("no_source_mutation", not intake_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not intake_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif obstruction_recorded:
        status = "PASS"
        state = OBSTRUCTION_RECORDED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_work_items"
        next_agent_command = SOURCE_THEOREM_PROOF_WORK_ITEM_DISPATCH_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": True,
        "prover_execution_performed": True,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_construction_obstruction_recorded": bool(status == "PASS" and obstruction_recorded),
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_result.get("selected_lean") or "",
        "lake_executable_path": lean_result.get("selected_lake") or "",
        "lake_env_used": bool(lean_result.get("lake_env_used")),
        "lean_exit_code": lean_result.get("exit_code"),
        "lean_source_path": source_info["path"],
        "claim_packet_id": intake_report.get("claim_packet_id") or "",
        "slug": intake_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_path": intake_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_requirement_count": len(classifications),
            "source_theorem_proof_construction_attempt_count": len(attempts),
            "source_theorem_proof_construction_ready_count": ready_count,
            "source_theorem_proof_construction_blocking_count": blocking_count,
            "source_theorem_proof_source_candidate_count": candidate_count,
            "source_theorem_proof_source_ready_count": source_ready_count,
            "expected_source_theorem_declaration_count": len(expected_source_theorem_declarations),
            "target_theorem_declaration_count": len(target_declarations),
            "lean_structure_count": len(structures),
            "lean_inductive_count": len(inductives),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "obstruction_theorem_count": 1 if OBSTRUCTION_THEOREM_NAME in theorem_names else 0,
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_source_backed_premise_proof_terms_ready_count": 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_result.get("command") or [],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_result.get("exit_code"),
            "timed_out": bool(lean_result.get("timed_out")),
            "stdout": lean_result.get("stdout") or "",
            "stderr": lean_result.get("stderr") or "",
            "structure_names": structures,
            "inductive_names": inductives,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "expected_source_theorem_declaration_count": len(expected_source_theorem_declarations),
            "target_theorem_declaration_count": len(target_declarations),
        },
        "source_theorem_proof_construction_attempts": attempts,
        "formalization_route": [
            {
                "step_id": "lean_source_theorem_proof_obstruction_taxonomy",
                "status": "ready" if obstruction_recorded else "attention",
                "output": "Lean checks a taxonomy for missing source theorem proof construction",
            },
            {
                "step_id": "source_theorem_proof_work_items",
                "status": "blocked_on_source_theorem_proofs" if obstruction_recorded else "attention",
                "output": "construct no-placeholder proofs for the ten sourceBacked theorem names",
            },
            {
                "step_id": "compose_premise_bundle",
                "status": "pending",
                "output": "compose the sourceBacked theorem proofs into premise proof terms only after all are ready",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_source_intake_report": intake_report,
        "boundary": [
            "This command records a Lean-checked source theorem proof construction obstruction only.",
            "It declares no sourceBacked expected theorem, no ProfileEquivalenceTransfersDirectScoreLimitStatement, and no target theorem.",
            "Generated logs, source anchors, placeholders, field forwarding, statement assumptions, and assumption echo remain rejected as production proof.",
            "It writes only local draft/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Construction",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_construction_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Attempts: {summary.get('source_theorem_proof_construction_attempt_count', 0)}",
        f"- Blocking attempts: {summary.get('source_theorem_proof_construction_blocking_count', 0)}",
        f"- Expected source theorem declarations: {summary.get('expected_source_theorem_declaration_count', 0)}",
        f"- Target theorem declarations: {summary.get('target_theorem_declaration_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
