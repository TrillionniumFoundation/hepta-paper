"""Gate skeleton source-theorem proofs for premise proof terms."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-skeleton-gate"
IMPLEMENTATION_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-implementation-plan"
SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-theorem-proof-body-construction"

IMPLEMENTATION_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_IMPLEMENTATION_PLAN_READY_SOURCE_THEOREM_PROOFS_REQUIRED"
IMPLEMENTATION_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_IMPLEMENTATION_PLAN_MACHINE_CHECKED_CLOSED"

SKELETON_GATE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SKELETON_GATE_READY_SOURCE_PROOF_BODIES_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SKELETON_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SKELETON_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_TERM_SOURCE_THEOREM_PROOF_SKELETON_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_skeleton_gate_ready",
    "profile_equivalence_transfer_premise_source_theorem_proof_skeleton_rejected",
    "profile_equivalence_transfer_premise_source_theorem_proofs_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_theorem_proof_skeleton_items",
    "dispatch_groups",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_theorem_proof_implementation_item_count",
    "source_theorem_proof_skeleton_item_count",
    "source_theorem_proof_skeleton_rejected_count",
    "expected_source_theorem_declaration_count",
    "expected_source_theorem_missing_count",
    "assumption_echo_marker_count",
    "source_tree_proof_body_ready_count",
    "target_theorem_declaration_count",
    "lean_structure_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "dispatch_group_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes source theorem proof implementation items and checks Lean skeleton theorem declarations for each expected sourceBacked theorem.",
    "Skeleton theorem bodies deliberately echo theorem-specific assumptions and are rejected as production proof.",
    "This gate keeps source-tree no-placeholder proof body construction as the hard boundary.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
ASSUMPTION_ECHO_RE = re.compile(r"\bexact\s+h[A-Z][A-Za-z0-9_']*")
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
TARGET_STATEMENT_NAME = "ProfileEquivalenceTransfersDirectScoreLimitStatement"


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _implementation_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_missing")
        return issues
    if report.get("command") != IMPLEMENTATION_PLAN_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_state") or ""
    if state not in {IMPLEMENTATION_PLAN_READY_STATE, IMPLEMENTATION_PLAN_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_state_not_consumable",
            state,
        )
    if not report.get("source_theorem_proof_implementation_items") and not report.get("production_claim_machine_checked"):
        _issue(issues, "source_theorem_proof_implementation_items_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_boundary:{key}")
    return issues


def _field_name(expected):
    text = re.sub(r"[^A-Za-z0-9_]", "", str(expected or "sourceTheoremProof"))
    if not text:
        text = "sourceTheoremProof"
    return f"{text[:1].lower()}{text[1:]}SkeletonStatement"


def _skeleton_items(implementation_items):
    items = []
    for index, item in enumerate(implementation_items, start=1):
        expected = item.get("expected_lean_proof_name") or f"sourceBackedPremiseTheorem{index}"
        items.append(
            {
                "skeleton_item_id": f"source-theorem-proof-skeleton-{index:02d}-{expected}",
                "expected_lean_proof_name": expected,
                "lean_premise_name": item.get("lean_premise_name") or "",
                "dispatch_group": item.get("dispatch_group") or "",
                "source_labels": list(item.get("source_labels") or []),
                "source_anchor_kinds": list(item.get("source_anchor_kinds") or []),
                "skeleton_statement_field_name": _field_name(expected),
                "skeleton_declared": True,
                "skeleton_body_kind": "theorem_specific_assumption_echo",
                "skeleton_rejected_as_production": True,
                "source_tree_proof_body_ready": False,
                "must_not_use": list(item.get("must_not_use") or [])
                + [
                    "skeleton proof body",
                    "source theorem assumption echo",
                ],
                "blocking_reason": "skeleton theorem body is only a theorem-specific assumption echo",
                "next_required_action": f"replace the skeleton assumption for {expected} with a no-placeholder source-tree proof body",
            }
        )
    return items


def _lean_source(items):
    fields = []
    theorems = []
    for item in items:
        field = item["skeleton_statement_field_name"]
        theorem_name = item["expected_lean_proof_name"]
        hyp_name = f"h{theorem_name[:1].upper()}{theorem_name[1:]}"
        fields.append(f"  {field} : Prop")
        theorems.append(
            f"""theorem {theorem_name}
    (S : ProfileEquivalencePremiseSourceTheoremProofSkeletonStatements)
    ({hyp_name} : S.{field}) :
    S.{field} := by
  exact {hyp_name}
"""
        )
    if not fields:
        fields.append("  noSourceTheoremProofSkeleton : Prop")
        theorems.append(
            """theorem noSourceBackedPremiseSourceTheoremProofSkeleton
    (S : ProfileEquivalencePremiseSourceTheoremProofSkeletonStatements)
    (hNoSourceTheoremProofSkeleton : S.noSourceTheoremProofSkeleton) :
    S.noSourceTheoremProofSkeleton := by
  exact hNoSourceTheoremProofSkeleton
"""
        )
    return """import Mathlib

namespace NSMAoSFormalization

noncomputable section

structure ProfileEquivalencePremiseSourceTheoremProofSkeletonStatements where
{fields}

{theorems}
end

end NSMAoSFormalization
""".format(fields="\n".join(fields), theorems="\n".join(theorems))


def _run_lean(source_info, source_root, lean_executable="", lake_executable="", timeout_seconds=180, runner=None):
    selected_lean = lean_executable or shutil.which("lean") or "lean"
    selected_lake = lake_executable or shutil.which("lake") or ""
    source_path = pathlib.Path(source_info["path"])
    lakefile_exists = pathlib.Path(source_root or ".").joinpath("lakefile.lean").exists() or pathlib.Path(source_root or ".").joinpath("lakefile.toml").exists()
    if selected_lake and lakefile_exists:
        command = [selected_lake, "env", selected_lean, str(source_path)]
        lake_env_used = True
    else:
        command = [selected_lean, str(source_path)]
        lake_env_used = False
    run = runner or subprocess.run
    try:
        proc = run(command, timeout=timeout_seconds)
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": int(proc.returncode),
            "timed_out": False,
            "stdout": (proc.stdout or "") if isinstance(proc.stdout, str) else "",
            "stderr": (proc.stderr or "") if isinstance(proc.stderr, str) else "",
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "command": command,
            "selected_lean": selected_lean,
            "selected_lake": selected_lake,
            "lake_env_used": lake_env_used,
            "exit_code": 124,
            "timed_out": True,
            "stdout": exc.stdout or "",
            "stderr": exc.stderr or "",
        }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report,
    output_root,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    implementation_plan_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    validation_issues = _implementation_plan_issues(implementation_plan_report)
    machine_checked = bool(implementation_plan_report.get("production_claim_machine_checked"))
    implementation_items = list(implementation_plan_report.get("source_theorem_proof_implementation_items") or [])
    skeleton_items = _skeleton_items(implementation_items)
    expected_names = {item.get("expected_lean_proof_name") for item in skeleton_items if item.get("expected_lean_proof_name")}
    lean_text = _lean_source(skeleton_items)
    output_root = pathlib.Path(output_root)
    source_info = _write_text(output_root / "ProfileEquivalencePremiseSourceTheoremProofSkeletonGate.lean", lean_text)
    lean_result = _run_lean(source_info, source_root_path, lean_executable, lake_executable, timeout_seconds, runner=runner)
    theorem_names = THEOREM_RE.findall(lean_text)
    structures = STRUCTURE_RE.findall(lean_text)
    placeholders = PLACEHOLDER_RE.findall(lean_text)
    assumption_echo_markers = ASSUMPTION_ECHO_RE.findall(lean_text)
    expected_declarations = [name for name in theorem_names if name in expected_names]
    missing_expected = sorted(expected_names - set(expected_declarations))
    target_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    target_declarations.extend([name for name in structures if name == TARGET_STATEMENT_NAME])
    lean_exit_zero = bool(lean_result.get("exit_code") == 0 and not lean_result.get("timed_out"))
    skeleton_ready = bool(
        lean_exit_zero
        and skeleton_items
        and len(expected_declarations) == len(skeleton_items)
        and assumption_echo_markers
        and not placeholders
        and not target_declarations
    )
    skeleton_rejected_count = sum(1 for item in skeleton_items if item.get("skeleton_rejected_as_production"))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_consumable", not _implementation_plan_issues(implementation_plan_report), "source_theorem_proof_implementation_plan_report_not_consumable"),
        _check("source_theorem_proof_implementation_items_present", bool(implementation_items), "source_theorem_proof_implementation_items_missing"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("expected_source_theorem_declarations_present", len(expected_declarations) == len(skeleton_items), "expected_source_theorem_declarations_missing"),
        _check("target_theorem_not_declared", not target_declarations, "target_theorem_or_statement_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("skeleton_assumption_echo_detected", bool(assumption_echo_markers) or machine_checked, "skeleton_assumption_echo_missing", severity="readiness"),
        _check("skeleton_rejected_as_production", bool(skeleton_rejected_count) or machine_checked, "skeleton_not_classified", severity="readiness"),
        _check("no_source_mutation", not implementation_plan_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not implementation_plan_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif skeleton_ready:
        status = "PASS"
        state = SKELETON_GATE_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_body_construction"
        next_agent_command = SOURCE_THEOREM_PROOF_BODY_CONSTRUCTION_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    skeleton_rejected = bool(status == "PASS" and skeleton_rejected_count and assumption_echo_markers and not production_checked)
    dispatch_groups = list(implementation_plan_report.get("dispatch_groups") or [])
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": True,
        "prover_execution_performed": True,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_source_theorem_proof_skeleton_gate_ready": bool(status == "PASS" and skeleton_ready),
        "profile_equivalence_transfer_premise_source_theorem_proof_skeleton_rejected": skeleton_rejected,
        "profile_equivalence_transfer_premise_source_theorem_proofs_ready": False,
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": False,
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": lean_result.get("selected_lean") or "",
        "lake_executable_path": lean_result.get("selected_lake") or "",
        "lake_env_used": bool(lean_result.get("lake_env_used")),
        "lean_exit_code": lean_result.get("exit_code"),
        "lean_source_path": source_info["path"],
        "claim_packet_id": implementation_plan_report.get("claim_packet_id") or "",
        "slug": implementation_plan_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_path": implementation_plan_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report_sha256": implementation_plan_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_theorem_proof_implementation_item_count": len(implementation_items),
            "source_theorem_proof_skeleton_item_count": len(skeleton_items),
            "source_theorem_proof_skeleton_rejected_count": skeleton_rejected_count,
            "expected_source_theorem_declaration_count": len(expected_declarations),
            "expected_source_theorem_missing_count": len(missing_expected),
            "assumption_echo_marker_count": len(assumption_echo_markers),
            "source_tree_proof_body_ready_count": sum(1 for item in skeleton_items if item.get("source_tree_proof_body_ready")),
            "target_theorem_declaration_count": len(target_declarations),
            "lean_structure_count": len(structures),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "dispatch_group_count": len(dispatch_groups),
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_result.get("command") or [],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_result.get("exit_code"),
            "timed_out": bool(lean_result.get("timed_out")),
            "stdout": lean_result.get("stdout") or "",
            "stderr": lean_result.get("stderr") or "",
            "structure_names": structures,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "assumption_echo_marker_count": len(assumption_echo_markers),
            "expected_source_theorem_declaration_count": len(expected_declarations),
            "expected_source_theorem_missing": missing_expected,
            "target_theorem_declaration_count": len(target_declarations),
        },
        "source_theorem_proof_skeleton_items": skeleton_items,
        "dispatch_groups": dispatch_groups,
        "formalization_route": [
            {
                "step_id": "source_theorem_proof_skeleton_gate",
                "status": "ready" if skeleton_ready else "attention",
                "output": "Lean checks skeleton declarations for the expected sourceBacked theorem names",
            },
            {
                "step_id": "reject_skeleton_assumption_echo",
                "status": "ready" if skeleton_rejected else "attention",
                "output": "the skeleton bodies are theorem-specific assumption echo and are not production proof",
            },
            {
                "step_id": "source_tree_proof_body_construction",
                "status": "blocked_on_source_theorem_proof_bodies" if skeleton_rejected else "attention",
                "output": "replace each skeleton body with a source-tree no-placeholder proof term",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_implementation_plan_report": implementation_plan_report,
        "boundary": [
            "This command checks skeleton theorem declarations only; the skeleton bodies are not source theorem proofs.",
            "The theorem bodies forward theorem-specific assumptions and are rejected as production proof.",
            "It does not declare ProfileEquivalenceTransfersDirectScoreLimitStatement or profileEquivalenceTransfersDirectScoreLimit.",
            "Generated logs, source anchors alone, placeholders, field forwarding, statement assumptions, premise assumptions, source theorem assumption echo, skeletons, and plans remain rejected as proof.",
            "It writes only local draft/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Premise Source-Theorem Proof Skeleton Gate",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_theorem_proof_skeleton_gate_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Skeleton items: {summary.get('source_theorem_proof_skeleton_item_count', 0)}",
        f"- Expected theorem declarations: {summary.get('expected_source_theorem_declaration_count', 0)}",
        f"- Assumption echo markers: {summary.get('assumption_echo_marker_count', 0)}",
        f"- Source tree proof bodies ready: {summary.get('source_tree_proof_body_ready_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
