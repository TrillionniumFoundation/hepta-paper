"""Dispatch source-backed premise proof work items for the transfer field."""

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-work-item-dispatch"
PREMISE_PROOF_SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-source-intake"
PREMISE_PROOF_TERM_SOURCE_CONSTRUCTION_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-source-construction-attempt"
HSOURCEPROOF_COMPOSITION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-hsourceproof-composition"
PREMISE_PROOF_SOURCE_INTAKE_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

PREMISE_PROOF_SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
PREMISE_PROOF_SOURCE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_READY"
PREMISE_PROOF_SOURCE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

WORK_ITEMS_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_WORK_ITEM_DISPATCH_READY_SOURCE_TERMS_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_WORK_ITEM_DISPATCH_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PREMISE_PROOF_WORK_ITEM_DISPATCH_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_ready",
    "profile_equivalence_transfer_premise_proof_work_items_ready",
    "profile_equivalence_transfer_source_backed_premise_proof_terms_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "premise_proof_work_items",
    "dispatch_groups",
    "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "premise_proof_source_intake_validation_issue_count",
    "premise_proof_work_item_count",
    "ready_work_item_count",
    "blocking_work_item_count",
    "source_anchor_ready_work_item_count",
    "local_candidate_work_item_count",
    "missing_source_work_item_count",
    "dispatch_group_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes source-backed premise proof-source intake and emits one machine-readable work item per missing Lean premise proof term.",
    "Dispatch work items are not production proof and cannot satisfy ProfileEquivalenceTransfersDirectScoreLimitStatement.",
    "Generated logs, field forwarding, statement assumptions, and premise-assumption echo remain rejected proof sources.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
ANCHOR_KIND_BY_PREFIX = {
    "thm": "manuscript_theorem_anchor",
    "app": "manuscript_appendix_proof_anchor",
    "prop": "manuscript_proposition_anchor",
    "cor": "manuscript_corollary_anchor",
    "ass": "manuscript_assumption_anchor",
}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _intake_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_missing")
        return issues
    if report.get("command") != PREMISE_PROOF_SOURCE_INTAKE_COMMAND:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_command_mismatch",
            report.get("command") or "",
        )
    if report.get("status") != "PASS":
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_not_pass",
            report.get("status") or "",
        )
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_state") or ""
    if state not in {PREMISE_PROOF_SOURCE_REQUIRED_STATE, PREMISE_PROOF_SOURCE_READY_STATE, PREMISE_PROOF_SOURCE_CLOSED_STATE}:
        _issue(
            issues,
            "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_state_not_consumable",
            state,
        )
    if not report.get("premise_proof_source_intake_classifications") and not report.get("production_claim_machine_checked"):
        _issue(issues, "premise_proof_source_classifications_missing")
    for classification in report.get("premise_proof_source_intake_classifications") or []:
        candidate_count = int(classification.get("proof_source_candidate_count") or 0)
        ready_count = int(classification.get("proof_source_ready_count") or 0)
        proof_name = classification.get("lean_premise_name") or classification.get("subgoal_id") or ""
        if ready_count > candidate_count:
            _issue(
                issues,
                "premise_proof_source_ready_count_exceeds_candidate_count",
                proof_name,
            )
        if classification.get("proof_term_ready") and ready_count <= 0:
            _issue(
                issues,
                "premise_proof_source_ready_without_ready_candidate_evidence",
                proof_name,
            )
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_boundary:{key}")
    return issues


def _anchor_kind(label):
    prefix = str(label or "").split(":", 1)[0]
    return ANCHOR_KIND_BY_PREFIX.get(prefix, "source_anchor")


def _expected_proof_name(premise_name):
    name = str(premise_name or "premiseProofTerm").strip()
    if not name:
        name = "premiseProofTerm"
    return f"sourceBacked{name[:1].upper()}{name[1:]}"


def _dispatch_group(source_labels):
    labels = list(source_labels or [])
    if not labels:
        return "unlabeled-source-anchor"
    if any(str(label).startswith("cor:hf_calibration_schedule") for label in labels):
        return "high-frequency-rate-premises"
    if any(str(label).startswith("prop:fast_transfer") for label in labels):
        return "fast-transfer-premises"
    if any(str(label).startswith("prop:operational_certificate") for label in labels):
        return "operational-certificate-premises"
    if any(str(label).startswith("ass:direct_hf_input") for label in labels):
        return "direct-euler-input-premises"
    if any(str(label).startswith("thm:profile_equivalence") or str(label).startswith("app:profile_equivalence") for label in labels):
        return "profile-equivalence-anchor-premises"
    return "source-anchor-premises"


def _work_item(classification, index):
    ready = bool(classification.get("proof_term_ready"))
    source_labels = list(classification.get("source_labels") or [])
    premise_name = classification.get("lean_premise_name") or f"premiseProofTerm{index}"
    source_kinds = sorted({_anchor_kind(label) for label in source_labels})
    return {
        "work_item_id": f"source-backed-premise-proof-term-{index:02d}-{classification.get('subgoal_id') or premise_name}",
        "status": "ready" if ready else "blocked_on_source_backed_lean_proof_term",
        "blocking": not ready,
        "lean_premise_name": premise_name,
        "subgoal_id": classification.get("subgoal_id") or "",
        "expected_lean_proof_name": _expected_proof_name(premise_name),
        "required_output_kind": "no_placeholder_source_tree_lean_theorem_or_lemma",
        "source_labels": source_labels,
        "source_anchor_kinds": source_kinds,
        "source_anchors_ready": bool(classification.get("source_anchors_ready")),
        "local_candidate_count": int(classification.get("proof_source_candidate_count") or 0),
        "ready_candidate_count": int(classification.get("proof_source_ready_count") or 0),
        "candidate_sources": list(classification.get("candidate_sources") or []),
        "dispatch_group": _dispatch_group(source_labels),
        "must_not_use": [
            "logs/paperctl/_batches generated Lean artifacts",
            ".lake or dependency cache material",
            "sorry/admit/axiom/opaque placeholders",
            "field forwarding",
            "statement assumption echo",
            "premise assumption echo",
        ],
        "next_required_action": (
            "wire the ready source-tree Lean theorem into hSourceProof composition"
            if ready
            else "construct or locate a source-tree Lean theorem/lemma proving this premise without placeholders or assumption echo"
        ),
        "blocking_reason": "" if ready else (classification.get("blocking_reason") or "source-backed Lean proof term missing"),
    }


def _group_counts(work_items):
    groups = {}
    for item in work_items:
        key = item.get("dispatch_group") or "ungrouped"
        bucket = groups.setdefault(key, {"dispatch_group": key, "work_item_count": 0, "ready_work_item_count": 0, "blocking_work_item_count": 0})
        bucket["work_item_count"] += 1
        if item.get("blocking"):
            bucket["blocking_work_item_count"] += 1
        else:
            bucket["ready_work_item_count"] += 1
    return list(groups.values())


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch(
    domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report,
    label=None,
):
    intake_report = domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report or {}
    intake_ref_issues, intake_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake",
        intake_report,
        expected_command=PREMISE_PROOF_SOURCE_INTAKE_COMMAND,
        max_age_min=PREMISE_PROOF_SOURCE_INTAKE_MAX_AGE_MIN,
    )
    validation_issues = intake_ref_issues + _intake_issues(intake_report)
    machine_checked = bool(intake_report.get("production_claim_machine_checked"))
    classifications = list(intake_report.get("premise_proof_source_intake_classifications") or [])
    work_items = [_work_item(item, index + 1) for index, item in enumerate(classifications)]
    ready_count = sum(1 for item in work_items if not item.get("blocking"))
    blocking_count = sum(1 for item in work_items if item.get("blocking"))
    all_ready = bool(work_items and ready_count == len(work_items))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_consumable", not _intake_issues(intake_report), "premise_proof_source_intake_not_consumable"),
        _check("premise_work_items_present", bool(work_items), "premise_work_items_missing"),
        _check("missing_source_terms_dispatched", bool(blocking_count) or all_ready or machine_checked, "missing_source_terms_not_dispatched", severity="readiness"),
        _check("dispatch_not_production_proof", not machine_checked or intake_report.get("production_claim_machine_checked"), "dispatch_must_not_promote_production"),
        _check("no_source_mutation", not intake_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not intake_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif work_items:
        status = "PASS"
        state = WORK_ITEMS_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_source_construction_attempt" if blocking_count else "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition"
        next_agent_command = PREMISE_PROOF_TERM_SOURCE_CONSTRUCTION_ATTEMPT_COMMAND if blocking_count else HSOURCEPROOF_COMPOSITION_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    production_checked = bool(machine_checked and state == CLOSED_STATE)
    groups = _group_counts(work_items)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": True,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_premise_proof_work_items_ready": bool(status == "PASS" and work_items),
        "profile_equivalence_transfer_source_backed_premise_proof_terms_ready": bool(status == "PASS" and all_ready and not production_checked),
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "production_claim_machine_checked": production_checked,
        "claim_packet_id": intake_report.get("claim_packet_id") or "",
        "slug": intake_report.get("slug") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_path": intake_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_ref_health": intake_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "premise_proof_source_intake_validation_issue_count": len(intake_ref_issues),
            "premise_proof_work_item_count": len(work_items),
            "ready_work_item_count": ready_count,
            "blocking_work_item_count": blocking_count,
            "source_anchor_ready_work_item_count": sum(1 for item in work_items if item.get("source_anchors_ready")),
            "local_candidate_work_item_count": sum(1 for item in work_items if item.get("local_candidate_count")),
            "missing_source_work_item_count": blocking_count,
            "dispatch_group_count": len(groups),
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "premise_proof_work_items": work_items,
        "dispatch_groups": groups,
        "domain_theorem_bridge_transfer_field_source_backed_premise_proof_source_intake_report": intake_report,
        "boundary": [
            "This command dispatches proof work items only; a work item is not a proof term.",
            "Generated logs, field forwarding, statement assumptions, and premise-assumption echo remain rejected as production proof.",
            "ProfileEquivalenceTransfersDirectScoreLimitStatement and profileEquivalenceTransfersDirectScoreLimit remain unproved until all source-backed premise proof terms are constructed and composed.",
            "It writes only local reports and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source-Backed Premise Proof Work Item Dispatch",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_premise_proof_work_item_dispatch_state') or ''}",
        f"- Work items: {summary.get('premise_proof_work_item_count', 0)}",
        f"- Blocking work items: {summary.get('blocking_work_item_count', 0)}",
        f"- Ready work items: {summary.get('ready_work_item_count', 0)}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
