"""Record source-backed proof construction gaps for the transfer theorem."""

import hashlib
import pathlib
import re
import shutil
import subprocess

from paperctl_modules import report_ref_health

COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-proof-source-construction"
SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-no-placeholder-lean-proof-attempt"
SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-premise-proof-term-construction"
SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_SOURCE_PROOF_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_SOURCE_PROOF_REQUIRED"
SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_MACHINE_CHECKED_CLOSED"

PROOF_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_OBSTRUCTION_RECORDED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_PROOF_SOURCE_CONSTRUCTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_ready",
    "profile_equivalence_transfer_proof_construction_obstruction_recorded",
    "profile_equivalence_transfer_source_backed_proof_required",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "profile_equivalence_transfer_statement_assumption_echo_rejected",
    "field_forwarding_allowed_as_production_proof",
    "generated_log_provenance_allowed",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_anchor_inputs",
    "proof_construction_subgoals",
    "proof_construction_obstructions",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "no_placeholder_lean_proof_attempt_validation_issue_count",
    "source_anchor_input_count",
    "source_anchor_ready_count",
    "proof_construction_subgoal_count",
    "proof_construction_blocking_subgoal_count",
    "proof_term_required_count",
    "proof_term_ready_count",
    "lean_inductive_count",
    "lean_def_count",
    "lean_theorem_count",
    "placeholder_token_count",
    "target_theorem_declaration_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_proof_construction_obstruction_recorded_count",
    "profile_equivalence_transfer_source_backed_proof_required_count",
    "profile_equivalence_transfer_source_backed_proof_source_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the source-backed no-placeholder Lean proof attempt and records the remaining hSourceProof construction obstruction.",
    "The generated Lean checks a proof-source gap map only; it does not prove profileEquivalenceTransfersDirectScoreLimit or ProfileEquivalenceTransfersDirectScoreLimitStatement.",
    "Every statement antecedent is tracked as a proof-term construction subgoal with generated logs, statement assumptions, and field forwarding rejected.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*theorem\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
DEF_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
INDUCTIVE_RE = re.compile(r"^\s*inductive\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
OBSTRUCTION_THEOREM_NAME = "profileEquivalenceTransferProofConstructionObstructionDraft"

PROOF_CONSTRUCTION_SUBGOAL_SPECS = [
    {
        "subgoal_id": "profile-equivalence-theorem-anchor-proof-term",
        "lean_premise_name": "profileEquivalenceTheoremAnchor",
        "source_labels": ["thm:profile_equivalence"],
        "blocking_reason": "manuscript theorem anchor is present but no Lean proof term imports it into the statement proof",
    },
    {
        "subgoal_id": "profile-equivalence-proof-anchor-proof-term",
        "lean_premise_name": "profileEquivalenceProofAnchor",
        "source_labels": ["app:profile_equivalence_proof"],
        "blocking_reason": "manuscript proof anchor is present but not formalized as a Lean derivation",
    },
    {
        "subgoal_id": "fast-transfer-anchor-proof-term",
        "lean_premise_name": "fastTransferAnchor",
        "source_labels": ["prop:fast_transfer"],
        "blocking_reason": "fast-transfer proposition is source-backed but not converted to a Lean premise proof",
    },
    {
        "subgoal_id": "operational-certificate-anchor-proof-term",
        "lean_premise_name": "operationalCertificateAnchor",
        "source_labels": ["prop:operational_certificate"],
        "blocking_reason": "operational certificate proposition is source-backed but not converted to a Lean premise proof",
    },
    {
        "subgoal_id": "fixed-delta-rate-negligibility-proof-term",
        "lean_premise_name": "fixedDeltaRateNegligible",
        "source_labels": ["prop:fast_transfer", "prop:operational_certificate"],
        "blocking_reason": "fixed-delta rate negligibility is only a Prop field, not a constructed Lean proof",
    },
    {
        "subgoal_id": "high-frequency-drift-rate-negligibility-proof-term",
        "lean_premise_name": "highFrequencyDriftRateNegligible",
        "source_labels": ["cor:hf_calibration_schedule"],
        "blocking_reason": "high-frequency drift rate negligibility needs a Lean proof from the calibration schedule",
    },
    {
        "subgoal_id": "high-frequency-diffusion-rate-negligibility-proof-term",
        "lean_premise_name": "highFrequencyDiffusionRateNegligible",
        "source_labels": ["cor:hf_calibration_schedule"],
        "blocking_reason": "high-frequency diffusion rate negligibility needs a Lean proof from the calibration schedule",
    },
    {
        "subgoal_id": "fast-transfer-certificate-proof-term",
        "lean_premise_name": "fastTransferCertificate",
        "source_labels": ["prop:fast_transfer"],
        "blocking_reason": "fast-transfer certificate is only a Prop field until a Lean certificate proof is constructed",
    },
    {
        "subgoal_id": "operational-certificate-proof-term",
        "lean_premise_name": "operationalCertificate",
        "source_labels": ["prop:operational_certificate"],
        "blocking_reason": "operational certificate is only a Prop field until a Lean certificate proof is constructed",
    },
    {
        "subgoal_id": "direct-euler-limit-proof-term",
        "lean_premise_name": "directEulerLimit",
        "source_labels": ["ass:direct_hf_input", "thm:profile_equivalence"],
        "blocking_reason": "direct Euler limit is an input Prop field and must be connected to imported/direct theorem proof source",
    },
]


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _proof_attempt_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_missing")
        return issues
    if report.get("command") != SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_state") or ""
    if state not in {SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_SOURCE_PROOF_REQUIRED_STATE, SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_state_not_consumable", state)
    if not report.get("profile_equivalence_transfer_statement_assumption_echo_proof_rejected") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_statement_assumption_echo_rejection_missing")
    if not report.get("profile_equivalence_transfer_source_backed_proof_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_required_missing")
    if report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_source_ready_premature")
    if report.get("profile_equivalence_transfer_target_theorem_proved") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_target_theorem_proved_without_machine_check")
    if report.get("field_forwarding_allowed_as_production_proof"):
        _issue(issues, "field_forwarding_allowed_as_production_proof")
    if report.get("generated_log_provenance_allowed"):
        _issue(issues, "generated_log_provenance_allowed")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_boundary:{key}")
    return issues


def _source_anchor_inputs(report):
    statement_report = report.get("domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft_report") or {}
    anchors = statement_report.get("source_anchor_inputs") or []
    if not anchors:
        extraction_report = statement_report.get("domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_report") or {}
        anchors = extraction_report.get("source_anchor_extractions") or []
    normalized = []
    for item in anchors:
        matches = item.get("matches") or []
        locators = list(item.get("source_locators") or [])
        for match in matches:
            locator = str(match.get("source_locator") or "")
            if locator and locator not in locators:
                locators.append(locator)
        normalized.append(
            {
                "anchor_id": item.get("anchor_id") or "",
                "label": item.get("label") or "",
                "required": bool(item.get("required")),
                "formal_role": item.get("formal_role") or "",
                "found": bool(item.get("found")),
                "match_count": int(item.get("match_count") or len(locators)),
                "source_locators": [str(locator) for locator in locators[:4]],
            }
        )
    return normalized


def _anchor_ready_by_label(anchors):
    return {item.get("label"): bool(item.get("found")) for item in anchors}


def _construction_subgoals(anchors):
    ready_by_label = _anchor_ready_by_label(anchors)
    subgoals = []
    for spec in PROOF_CONSTRUCTION_SUBGOAL_SPECS:
        labels = list(spec["source_labels"])
        anchor_ready = all(ready_by_label.get(label, False) for label in labels)
        subgoals.append(
            {
                "subgoal_id": spec["subgoal_id"],
                "lean_premise_name": spec["lean_premise_name"],
                "source_labels": labels,
                "source_anchors_ready": anchor_ready,
                "proof_term_required": True,
                "proof_term_ready": False,
                "blocking": True,
                "blocking_reason": spec["blocking_reason"],
                "generated_log_provenance_allowed": False,
                "statement_assumption_echo_allowed": False,
                "field_forwarding_allowed_as_production_proof": False,
            }
        )
    return subgoals


def _lean_source():
    return """import Mathlib

/-
paper_factory source-backed profile-equivalence proof construction obstruction.
This file checks only that the obstruction taxonomy is well formed in Lean.
It does not declare or prove profileEquivalenceTransfersDirectScoreLimit.
-/

namespace NSMAoSFormalization

inductive ProfileEquivalenceTransferProofSourceGap where
  | profileEquivalenceTheoremAnchor
  | profileEquivalenceProofAnchor
  | fastTransferAnchor
  | operationalCertificateAnchor
  | fixedDeltaRateNegligibility
  | highFrequencyDriftRateNegligibility
  | highFrequencyDiffusionRateNegligibility
  | fastTransferCertificate
  | operationalCertificate
  | directEulerLimit

def ProfileEquivalenceTransferProofSourceGap.isBlocking
    (_gap : ProfileEquivalenceTransferProofSourceGap) : Prop :=
  True

theorem profileEquivalenceTransferProofConstructionObstructionDraft :
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.profileEquivalenceTheoremAnchor ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.profileEquivalenceProofAnchor ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.fastTransferAnchor ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.operationalCertificateAnchor ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.fixedDeltaRateNegligibility ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.highFrequencyDriftRateNegligibility ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.highFrequencyDiffusionRateNegligibility ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.fastTransferCertificate ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.operationalCertificate ∧
    ProfileEquivalenceTransferProofSourceGap.isBlocking
      ProfileEquivalenceTransferProofSourceGap.directEulerLimit := by
  simp [ProfileEquivalenceTransferProofSourceGap.isBlocking]

end NSMAoSFormalization
"""


def _lean_command(source_root, lean_executable, lake_executable, lean_source_path):
    root = pathlib.Path(source_root or ".").resolve()
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    if selected_lean and selected_lake and (root / "lakefile.lean").exists():
        return [selected_lake, "env", selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, True
    if selected_lean:
        return [selected_lean, "--error=warning", str(lean_source_path)], selected_lean, selected_lake, False
    return [], selected_lean, selected_lake, False


def _run_lean(command, timeout_seconds, cwd, runner=None):
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=str(cwd),
    )


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction(
    domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    proof_attempt_report = domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report or {}
    proof_attempt_ref_issues, proof_attempt_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt",
        proof_attempt_report,
        expected_command=SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_COMMAND,
        max_age_min=SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_MAX_AGE_MIN,
    )
    validation_issues = proof_attempt_ref_issues + _proof_attempt_issues(proof_attempt_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    source_root_path = pathlib.Path(source_root or ".").resolve()
    machine_checked = bool(
        proof_attempt_report.get("production_claim_machine_checked")
        and proof_attempt_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_state") == SOURCE_BACKED_NO_PLACEHOLDER_LEAN_PROOF_ATTEMPT_CLOSED_STATE
    )
    anchors = _source_anchor_inputs(proof_attempt_report)
    subgoals = _construction_subgoals(anchors)
    lean_source_text = _lean_source()
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-proof-source-construction.lean", lean_source_text)
    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_info["path"])
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command:
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    inductives = INDUCTIVE_RE.findall(lean_source_text)
    defs = DEF_RE.findall(lean_source_text)
    theorem_names = THEOREM_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    target_theorem_declarations = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    obstruction_ready = bool(
        lean_exit_zero
        and OBSTRUCTION_THEOREM_NAME in theorem_names
        and "ProfileEquivalenceTransferProofSourceGap" in inductives
        and not placeholders
        and not target_theorem_declarations
        and subgoals
    )
    source_backed_proof_required = bool(proof_attempt_report.get("profile_equivalence_transfer_source_backed_proof_required") and not machine_checked)
    proof_term_ready_count = sum(1 for item in subgoals if item.get("proof_term_ready"))
    blocking_count = sum(1 for item in subgoals if item.get("blocking"))
    checks = [
        _check("domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_consumable", not validation_issues, "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_not_consumable"),
        _check("source_anchor_inputs_present", bool(anchors), "source_anchor_inputs_missing", severity="readiness"),
        _check("proof_construction_subgoals_present", bool(subgoals), "proof_construction_subgoals_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("obstruction_gap_inductive_present", "ProfileEquivalenceTransferProofSourceGap" in inductives, "obstruction_gap_inductive_missing"),
        _check("obstruction_theorem_present", OBSTRUCTION_THEOREM_NAME in theorem_names, "obstruction_theorem_missing"),
        _check("target_theorem_not_declared", not target_theorem_declarations, "target_theorem_declared_without_proof"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("proof_terms_not_ready", proof_term_ready_count == 0 and blocking_count == len(subgoals), "proof_terms_ready_unexpectedly", severity="readiness"),
        _check("source_backed_proof_requirement_preserved", source_backed_proof_required or machine_checked, "source_backed_proof_requirement_missing", severity="readiness"),
        _check("generated_log_provenance_rejected", True, ""),
        _check("no_source_mutation", not proof_attempt_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not proof_attempt_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif obstruction_ready and source_backed_proof_required:
        status = "PASS"
        state = PROOF_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_premise_proof_term_construction"
        next_agent_command = SOURCE_BACKED_PREMISE_PROOF_TERM_CONSTRUCTION_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    obstruction_recorded = bool(status == "PASS" and state == PROOF_CONSTRUCTION_OBSTRUCTION_RECORDED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_proof_construction_obstruction_recorded": obstruction_recorded,
        "profile_equivalence_transfer_source_backed_proof_required": bool(status == "PASS" and source_backed_proof_required and not production_checked),
        "profile_equivalence_transfer_source_backed_proof_source_ready": False,
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "profile_equivalence_transfer_statement_assumption_echo_rejected": bool(proof_attempt_report.get("profile_equivalence_transfer_statement_assumption_echo_proof_rejected")),
        "field_forwarding_allowed_as_production_proof": False,
        "generated_log_provenance_allowed": False,
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": proof_attempt_report.get("claim_packet_id") or "",
        "slug": proof_attempt_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_path": proof_attempt_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report_sha256": proof_attempt_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_ref_health": proof_attempt_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "no_placeholder_lean_proof_attempt_validation_issue_count": len(proof_attempt_ref_issues),
            "source_anchor_input_count": len(anchors),
            "source_anchor_ready_count": sum(1 for item in anchors if item.get("found")),
            "proof_construction_subgoal_count": len(subgoals),
            "proof_construction_blocking_subgoal_count": blocking_count,
            "proof_term_required_count": sum(1 for item in subgoals if item.get("proof_term_required")),
            "proof_term_ready_count": proof_term_ready_count,
            "lean_inductive_count": len(inductives),
            "lean_def_count": len(defs),
            "lean_theorem_count": len(theorem_names),
            "placeholder_token_count": len(placeholders),
            "target_theorem_declaration_count": len(target_theorem_declarations),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_proof_construction_obstruction_recorded_count": 1 if obstruction_recorded else 0,
            "profile_equivalence_transfer_source_backed_proof_required_count": 1 if source_backed_proof_required and not production_checked else 0,
            "profile_equivalence_transfer_source_backed_proof_source_ready_count": 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": lake_env_used,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "inductive_names": inductives,
            "def_names": defs,
            "theorem_names": theorem_names,
            "placeholder_token_count": len(placeholders),
            "target_theorem_declaration_count": len(target_theorem_declarations),
        },
        "source_anchor_inputs": anchors,
        "proof_construction_subgoals": subgoals,
        "proof_construction_obstructions": [
            {
                "obstruction_id": "profile-equivalence-transfer-hSourceProof-missing",
                "lean_declaration_name": "ProfileEquivalenceTransfersDirectScoreLimitStatement",
                "target_theorem_name": TARGET_THEOREM_NAME,
                "blocking_subgoal_count": blocking_count,
                "proof_term_ready_count": proof_term_ready_count,
                "statement_assumption_echo_allowed": False,
                "generated_log_provenance_allowed": False,
                "field_forwarding_allowed_as_production_proof": False,
                "next_required_action": "construct_each_blocking_premise_proof_term_and_compose_hSourceProof_without_assuming_the_statement",
            }
        ],
        "formalization_route": [
            {
                "step_id": "reject_statement_assumption_echo",
                "status": "ready" if proof_attempt_report.get("profile_equivalence_transfer_statement_assumption_echo_proof_rejected") else "missing",
                "output": "previous gate established hSourceProof cannot be assumed as production proof",
            },
            {
                "step_id": "map_statement_antecedents_to_subgoals",
                "status": "ready" if obstruction_recorded else "attention",
                "output": "ten proof-term construction subgoals mapped to source labels and Lean premise fields",
            },
            {
                "step_id": "construct_premise_proof_terms",
                "status": "blocked_on_proof_source" if obstruction_recorded else "attention",
                "output": "source-backed Lean terms for each Prop premise and final statement proof",
            },
            {
                "step_id": "rewire_transfer_theorem",
                "status": "pending" if obstruction_recorded else "attention",
                "output": "replace hSourceProof assumption echo with constructed source-backed proof term",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_no_placeholder_lean_proof_attempt_report": proof_attempt_report,
        "boundary": [
            "This command records proof construction subgoals and checks only the obstruction taxonomy in Lean.",
            "It does not prove profileEquivalenceTransfersDirectScoreLimit or ProfileEquivalenceTransfersDirectScoreLimitStatement.",
            "Every generated-log artifact, source anchor, statement assumption, and field-forwarding shortcut remains rejected as production proof.",
            "The next stage must construct Lean proof terms for the blocking premises and compose hSourceProof without assuming it.",
            "It writes only local obstruction artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Source Backed Proof Source Construction",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_proof_source_construction_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Obstruction recorded: {report.get('profile_equivalence_transfer_proof_construction_obstruction_recorded')}",
        f"- Source-backed proof required: {report.get('profile_equivalence_transfer_source_backed_proof_required')}",
        f"- Source-backed proof source ready: {report.get('profile_equivalence_transfer_source_backed_proof_source_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Subgoals", ""])
    for item in report.get("proof_construction_subgoals") or []:
        lines.append(
            f"- {item.get('subgoal_id')}: premise={item.get('lean_premise_name')} "
            f"anchors_ready={item.get('source_anchors_ready')} proof_ready={item.get('proof_term_ready')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
