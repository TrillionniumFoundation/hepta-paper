"""Integrate the source-backed hSourceProof into the target theorem source."""

import pathlib
import re
import subprocess

from paperctl_modules import report_ref_health
from paperctl_modules.research_compute_formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition import (
    COMMAND as HSOURCEPROOF_COMPOSITION_COMMAND,
    HSOURCEPROOF_COMPOSITION_READY_STATE,
    CLOSED_STATE as HSOURCEPROOF_COMPOSITION_CLOSED_STATE,
    _check,
    _issue,
    _lean_command,
    _run_lean,
    _sha256_file,
    _strip_lean_comments_and_strings,
)


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-target-theorem-integration"
MACHINE_CHECKED_CLOSURE_CAPSTONE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-machine-checked-closure-capstone"
HSOURCEPROOF_COMPOSITION_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

TARGET_THEOREM_INTEGRATION_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_TARGET_THEOREM_INTEGRATION_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_TARGET_THEOREM_INTEGRATION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_TARGET_THEOREM_INTEGRATION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_TARGET_THEOREM_INTEGRATION_FAILED"

SOURCE_RELATIVE_PATH = "PaperFactoryFormalVerifier/SourceBacked/TargetTheoremIntegration.lean"
TARGET_THEOREM_NAME = "profileEquivalenceTransfersDirectScoreLimit"
SOURCE_PROOF_THEOREM_NAME = "sourceBackedProfileEquivalenceTransfersDirectScoreLimit"
FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*(?:theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
STATEMENT_ASSUMPTION_ECHO_RE = re.compile(r"\bhSourceProof\b")

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration_ready",
    "profile_equivalence_transfer_source_backed_hsourceproof_composition_ready",
    "profile_equivalence_transfer_source_backed_proof_source_ready",
    "profile_equivalence_transfer_target_theorem_integration_ready",
    "profile_equivalence_transfer_target_theorem_proved",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lake_env_used",
    "lean_exit_code",
    "lean_source_path",
    "lean_source_sha256",
    "claim_packet_id",
    "slug",
    "source_root",
    "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report_path",
    "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report_sha256",
    "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "target_theorem_integration",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "hsourceproof_composition_validation_issue_count",
    "lean_theorem_count",
    "target_theorem_declaration_count",
    "source_proof_theorem_reference_count",
    "placeholder_token_count",
    "statement_assumption_echo_marker_count",
    "lean_exit_zero_count",
    "profile_equivalence_transfer_target_theorem_integration_ready_count",
    "profile_equivalence_transfer_target_theorem_proved_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a ready source-backed hSourceProof composition report.",
    "Runs Lean on the source-tree target theorem integration file and rejects hSourceProof statement-assumption echo.",
    "This is a local source integration gate; it does not perform source apply, external action, commit, or final production closure.",
]


def _composition_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report_missing")
        return issues
    if report.get("command") != HSOURCEPROOF_COMPOSITION_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_state") or ""
    if state not in {HSOURCEPROOF_COMPOSITION_READY_STATE, HSOURCEPROOF_COMPOSITION_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_state_not_consumable", state)
    if not report.get("profile_equivalence_transfer_source_backed_hsourceproof_composition_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_hsourceproof_composition_not_ready")
    if not report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_backed_proof_source_not_ready")
    if report.get("profile_equivalence_transfer_target_theorem_proved") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_target_theorem_proved_premature_in_hsourceproof_composition")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_boundary:{key}")
    return issues


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration(
    domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report,
    source_root=".",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    runner=None,
    label=None,
):
    composition_report = domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report or {}
    source_root_path = pathlib.Path(source_root or ".").resolve()
    source_path = source_root_path / SOURCE_RELATIVE_PATH
    composition_ref_issues, composition_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition",
        composition_report,
        expected_command=HSOURCEPROOF_COMPOSITION_COMMAND,
        max_age_min=HSOURCEPROOF_COMPOSITION_MAX_AGE_MIN,
    )
    validation_issues = composition_ref_issues + _composition_issues(composition_report)
    machine_checked = bool(composition_report.get("production_claim_machine_checked"))
    source_text = source_path.read_text() if source_path.exists() else ""
    stripped_source = _strip_lean_comments_and_strings(source_text)
    if not source_path.exists():
        _issue(validation_issues, "target_theorem_integration_source_missing", SOURCE_RELATIVE_PATH)

    command, selected_lean, selected_lake, lake_env_used = _lean_command(source_root_path, lean_executable, lake_executable, source_path)
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if command and source_path.exists():
        try:
            result = _run_lean(command, timeout_seconds, source_root_path, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    theorem_names = THEOREM_RE.findall(stripped_source)
    placeholders = PLACEHOLDER_RE.findall(stripped_source)
    statement_echo = STATEMENT_ASSUMPTION_ECHO_RE.findall(stripped_source)
    target_theorems = [name for name in theorem_names if name == TARGET_THEOREM_NAME]
    source_proof_refs = re.findall(rf"\b{re.escape(SOURCE_PROOF_THEOREM_NAME)}\b", stripped_source)
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    integration_ready = bool(
        lean_exit_zero
        and len(target_theorems) == 1
        and source_proof_refs
        and not placeholders
        and not statement_echo
        and not validation_issues
        and not machine_checked
    )
    checks = [
        _check("hsourceproof_composition_report_consumable", not _composition_issues(composition_report), "hsourceproof_composition_report_not_consumable"),
        _check("source_backed_hsourceproof_composition_ready", bool(composition_report.get("profile_equivalence_transfer_source_backed_hsourceproof_composition_ready")) or machine_checked, "hsourceproof_composition_not_ready"),
        _check("target_theorem_integration_source_present", source_path.exists(), "target_theorem_integration_source_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("target_theorem_declared_once", len(target_theorems) == 1, "target_theorem_missing_or_duplicate"),
        _check("source_proof_theorem_referenced", bool(source_proof_refs), "source_proof_theorem_reference_missing"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("statement_assumption_echo_absent", not statement_echo, "statement_assumption_echo_present"),
        _check("no_source_mutation", not composition_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not composition_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif integration_ready:
        status = "PASS"
        state = TARGET_THEOREM_INTEGRATION_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_machine_checked_closure_capstone"
        next_agent_command = MACHINE_CHECKED_CLOSURE_CAPSTONE_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    source_sha = _sha256_file(source_path) if source_path.exists() else ""
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_source_backed_hsourceproof_composition_ready": bool(composition_report.get("profile_equivalence_transfer_source_backed_hsourceproof_composition_ready") and status == "PASS"),
        "profile_equivalence_transfer_source_backed_proof_source_ready": bool(composition_report.get("profile_equivalence_transfer_source_backed_proof_source_ready") and status == "PASS"),
        "profile_equivalence_transfer_target_theorem_integration_ready": bool(status == "PASS" and integration_ready),
        "profile_equivalence_transfer_target_theorem_proved": bool(production_checked),
        "production_claim_machine_checked": production_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lake_env_used": lake_env_used,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": str(source_path),
        "lean_source_sha256": source_sha,
        "claim_packet_id": composition_report.get("claim_packet_id") or "",
        "slug": composition_report.get("slug") or "",
        "source_root": str(source_root_path),
        "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report_path": composition_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report_sha256": composition_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_ref_health": composition_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "hsourceproof_composition_validation_issue_count": len(composition_ref_issues),
            "lean_theorem_count": len(theorem_names),
            "target_theorem_declaration_count": len(target_theorems),
            "source_proof_theorem_reference_count": len(source_proof_refs),
            "placeholder_token_count": len(placeholders),
            "statement_assumption_echo_marker_count": len(statement_echo),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "profile_equivalence_transfer_target_theorem_integration_ready_count": 1 if status == "PASS" and integration_ready else 0,
            "profile_equivalence_transfer_target_theorem_proved_count": 1 if production_checked else 0,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": command,
            "source_path": str(source_path),
            "source_sha256": source_sha,
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "theorem_names": theorem_names,
            "target_theorem_declaration_count": len(target_theorems),
            "source_proof_theorem_reference_count": len(source_proof_refs),
            "placeholder_token_count": len(placeholders),
            "statement_assumption_echo_marker_count": len(statement_echo),
        },
        "target_theorem_integration": {
            "lean_declaration_name": TARGET_THEOREM_NAME,
            "source_tree_relative_path": SOURCE_RELATIVE_PATH,
            "source_proof_theorem_name": SOURCE_PROOF_THEOREM_NAME,
            "target_theorem_integration_ready": bool(status == "PASS" and integration_ready),
            "target_theorem_proved": bool(production_checked),
            "next_required_action": "machine_checked_closure_capstone_or_full_semantic_source_contract_reduction",
        },
        "formalization_route": [
            {
                "step_id": "consume_hsourceproof_composition",
                "status": "ready" if composition_report.get("profile_equivalence_transfer_source_backed_hsourceproof_composition_ready") else "attention",
                "output": "source-backed hSourceProof composition report is ready",
            },
            {
                "step_id": "integrate_target_theorem",
                "status": "ready" if integration_ready else "attention",
                "output": "Lean checks target theorem source without hSourceProof statement-assumption echo",
            },
            {
                "step_id": "production_closure",
                "status": "pending" if integration_ready else "attention",
                "output": "final production closure still requires a capstone over semantic source contracts",
            },
        ],
        "domain_theorem_bridge_transfer_field_source_backed_hsourceproof_composition_report": composition_report,
        "boundary": [
            "This command verifies local source-tree target theorem integration without an hSourceProof statement-assumption parameter.",
            "It does not perform source apply, manuscript/package/archive mutation, provider/model calls, upload, email, portal action, Telegram send, or commit.",
            "It records integration readiness; production_claim_machine_checked remains false until a dedicated closure capstone accepts the semantic source contract boundary.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration_markdown(report):
    summary = report.get("summary") or {}
    lines = [
        "# Source-Backed Target Theorem Integration",
        "",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_target_theorem_integration_state') or ''}",
        f"- Lean exit: {report.get('lean_exit_code')}",
        f"- Target theorem declarations: {summary.get('target_theorem_declaration_count', 0)}",
        f"- Source proof references: {summary.get('source_proof_theorem_reference_count', 0)}",
        f"- Integration ready: {report.get('profile_equivalence_transfer_target_theorem_integration_ready')}",
        f"- Production machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Boundary",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    return "\n".join(lines) + "\n"
