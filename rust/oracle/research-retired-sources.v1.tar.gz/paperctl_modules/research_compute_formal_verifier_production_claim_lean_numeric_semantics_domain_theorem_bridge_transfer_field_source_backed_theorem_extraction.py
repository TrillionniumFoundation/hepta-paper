"""Extract manuscript anchors for the source-backed transfer theorem."""

import hashlib
import os
import pathlib
import re

from paperctl_modules import report_ref_health


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-theorem-extraction"
NO_PLACEHOLDER_PROOF_ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-no-placeholder-proof-attempt"
SOURCE_BACKED_LEAN_STATEMENT_DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-domain-theorem-bridge-transfer-field-source-backed-lean-statement-draft"
NO_PLACEHOLDER_PROOF_ATTEMPT_MAX_AGE_MIN = report_ref_health.DEFAULT_REPORT_MAX_AGE_MIN

NO_PLACEHOLDER_PROOF_ATTEMPT_FIELD_SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_NO_PLACEHOLDER_PROOF_ATTEMPT_FIELD_SOURCE_PROOF_REQUIRED"
NO_PLACEHOLDER_PROOF_ATTEMPT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_NO_PLACEHOLDER_PROOF_ATTEMPT_MACHINE_CHECKED_CLOSED"

SOURCE_ANCHORS_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_THEOREM_EXTRACTION_SOURCE_ANCHORS_READY_LEAN_PROOF_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_THEOREM_EXTRACTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_THEOREM_EXTRACTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DOMAIN_THEOREM_BRIDGE_TRANSFER_FIELD_SOURCE_BACKED_THEOREM_EXTRACTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_ready",
    "profile_equivalence_transfer_source_anchors_ready",
    "profile_equivalence_transfer_lean_proof_required",
    "profile_equivalence_transfer_lean_proof_source_ready",
    "field_forwarding_allowed_as_production_proof",
    "generated_log_provenance_allowed",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "source_root",
    "source_file_count",
    "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_path",
    "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_sha256",
    "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_ref_health",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "source_anchor_extractions",
    "source_backed_theorem_obligations",
    "formalization_route",
    "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "no_placeholder_proof_attempt_ref_validation_issue_count",
    "source_file_count",
    "required_source_anchor_count",
    "required_source_anchor_ready_count",
    "optional_source_anchor_count",
    "optional_source_anchor_ready_count",
    "source_anchor_ready_count",
    "source_anchor_missing_count",
    "lean_proof_required_count",
    "lean_proof_source_ready_count",
    "field_forwarding_rejected_count",
    "generated_log_provenance_rejected_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the transfer-field no-placeholder proof attempt and extracts source-backed theorem anchors from manuscript sources.",
    "Source anchors can make the next Lean statement construction precise, but they are not by themselves a Lean proof source.",
    "This command reads local manuscript/source files only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
EXCLUDED_DIR_NAMES = {".git", ".lake", "__pycache__", "logs", "node_modules"}
TEXT_SUFFIXES = {".tex", ".md"}
ANCHOR_SPECS = [
    {
        "anchor_id": "conditional-profile-perturbation-theorem",
        "label": "thm:profile_equivalence",
        "required": True,
        "formal_role": "transfer theorem mapping uniform score-moment error to profiled/direct Euler root equivalence",
    },
    {
        "anchor_id": "profile-equivalence-proof",
        "label": "app:profile_equivalence_proof",
        "required": True,
        "formal_role": "proof source for the profile-equivalence perturbation theorem",
    },
    {
        "anchor_id": "fast-transfer-source-condition",
        "label": "prop:fast_transfer",
        "required": True,
        "formal_role": "source-backed calibration-to-heldout transfer condition",
    },
    {
        "anchor_id": "operational-certificate-source-condition",
        "label": "prop:operational_certificate",
        "required": True,
        "formal_role": "finite-grid validation and coverage certificate feeding the transfer theorem",
    },
    {
        "anchor_id": "high-frequency-calibration-schedule",
        "label": "cor:hf_calibration_schedule",
        "required": False,
        "formal_role": "high-frequency drift/diffusion block rate route",
    },
    {
        "anchor_id": "direct-high-frequency-input",
        "label": "ass:direct_hf_input",
        "required": False,
        "formal_role": "direct Euler high-frequency CLT input condition",
    },
]


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _proof_attempt_issues(report):
    issues = []
    if not report:
        _issue(issues, "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_missing")
        return issues
    if report.get("command") != NO_PLACEHOLDER_PROOF_ATTEMPT_COMMAND:
        _issue(issues, "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_state") or ""
    if state not in {NO_PLACEHOLDER_PROOF_ATTEMPT_FIELD_SOURCE_REQUIRED_STATE, NO_PLACEHOLDER_PROOF_ATTEMPT_CLOSED_STATE}:
        _issue(issues, "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_state_not_consumable", state)
    if not report.get("profile_equivalence_transfer_field_forwarding_proof_rejected") and not report.get("production_claim_machine_checked"):
        _issue(issues, "field_forwarding_rejection_missing")
    if not report.get("profile_equivalence_transfer_source_proof_required") and not report.get("production_claim_machine_checked"):
        _issue(issues, "profile_equivalence_transfer_source_proof_required_missing")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_boundary:{key}")
    return issues


def _walk_source_files(source_root):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    preferred = root / "submission" / "AoS" / "NSM_AoS" / "main.tex"
    files = []
    if preferred.exists():
        files.append(preferred)
    for search_root in [root / "submission", root / "docs"]:
        if not search_root.exists():
            continue
        for dirpath, dirnames, filenames in os.walk(search_root):
            dirnames[:] = [name for name in dirnames if name not in EXCLUDED_DIR_NAMES]
            for filename in filenames:
                path = pathlib.Path(dirpath) / filename
                if path in files:
                    continue
                if path.suffix in TEXT_SUFFIXES and path.is_file():
                    files.append(path)
    return files


def _label_pattern(label):
    return re.compile(r"\\label\{" + re.escape(label) + r"\}")


def _window(lines, index, before=8, after=10):
    start = max(index - before, 0)
    end = min(index + after + 1, len(lines))
    return start + 1, "\n".join(lines[start:end])


def _extract_anchors(source_root):
    files = _walk_source_files(source_root)
    found = []
    for spec in ANCHOR_SPECS:
        pattern = _label_pattern(spec["label"])
        matches = []
        for path in files:
            text = path.read_text(errors="replace")
            lines = text.splitlines()
            for index, line in enumerate(lines):
                if not pattern.search(line):
                    continue
                start_line, excerpt = _window(lines, index)
                matches.append(
                    {
                        "source_locator": f"{path}:{index + 1}",
                        "context_start_line": start_line,
                        "excerpt_sha256": _sha256_text(excerpt),
                        "excerpt_line_count": len(excerpt.splitlines()),
                    }
                )
        found.append(
            {
                "anchor_id": spec["anchor_id"],
                "label": spec["label"],
                "required": bool(spec["required"]),
                "formal_role": spec["formal_role"],
                "found": bool(matches),
                "match_count": len(matches),
                "matches": matches[:4],
            }
        )
    return files, found


def _source_obligations(anchor_ready, lean_proof_required):
    return [
        {
            "obligation_id": "profile-equivalence-transfer-source-theorem-statement",
            "lean_declaration_name": "profileEquivalenceTransfersDirectScoreLimit",
            "source_labels": ["thm:profile_equivalence", "app:profile_equivalence_proof"],
            "required_source_kind": "manuscript_theorem_and_proof_anchor",
            "source_anchors_ready": anchor_ready,
            "lean_proof_required": lean_proof_required,
            "field_forwarding_allowed_as_production_proof": False,
            "generated_log_provenance_allowed": False,
            "next_required_action": "draft_lean_statement_from_profile_equivalence_source_anchors",
        },
        {
            "obligation_id": "profile-equivalence-transfer-rate-premises",
            "lean_declaration_name": "ProfileEquivalenceTransferRatePremises",
            "source_labels": ["prop:fast_transfer", "prop:operational_certificate", "cor:hf_calibration_schedule"],
            "required_source_kind": "rate_and_certificate_premise_mapping",
            "source_anchors_ready": anchor_ready,
            "lean_proof_required": lean_proof_required,
            "field_forwarding_allowed_as_production_proof": False,
            "generated_log_provenance_allowed": False,
            "next_required_action": "map_fixed_delta_and_high_frequency_rate_premises_to_lean_fields",
        },
        {
            "obligation_id": "direct-euler-limit-input",
            "lean_declaration_name": "DirectEulerLimitInput",
            "source_labels": ["ass:direct_hf_input", "thm:profile_equivalence"],
            "required_source_kind": "direct_euler_limit_assumption_interface",
            "source_anchors_ready": anchor_ready,
            "lean_proof_required": lean_proof_required,
            "field_forwarding_allowed_as_production_proof": False,
            "generated_log_provenance_allowed": False,
            "next_required_action": "separate_imported_direct_euler_limit_from_profile_equivalence_transfer",
        },
    ]


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction(
    domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report=None,
    source_root="",
    label="",
):
    attempt_report = domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report or {}
    attempt_ref_issues, attempt_ref_health = report_ref_health.consumed_report_ref_issues(
        "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt",
        attempt_report,
        expected_command=NO_PLACEHOLDER_PROOF_ATTEMPT_COMMAND,
        max_age_min=NO_PLACEHOLDER_PROOF_ATTEMPT_MAX_AGE_MIN,
    )
    validation_issues = attempt_ref_issues + _proof_attempt_issues(attempt_report)
    source_root_path = pathlib.Path(source_root or ".").resolve()
    source_files, anchors = _extract_anchors(source_root_path)
    required_anchors = [item for item in anchors if item.get("required")]
    optional_anchors = [item for item in anchors if not item.get("required")]
    required_ready_count = sum(1 for item in required_anchors if item.get("found"))
    optional_ready_count = sum(1 for item in optional_anchors if item.get("found"))
    source_anchors_ready = bool(required_anchors and required_ready_count == len(required_anchors))
    if not source_files:
        _issue(validation_issues, "manuscript_source_files_missing", str(source_root_path))
    if required_anchors and required_ready_count < len(required_anchors):
        _issue(validation_issues, "required_source_anchors_missing", f"{required_ready_count}/{len(required_anchors)} ready")

    machine_checked = bool(
        attempt_report.get("production_claim_machine_checked")
        and attempt_report.get("formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_state") == NO_PLACEHOLDER_PROOF_ATTEMPT_CLOSED_STATE
    )
    lean_proof_required = bool(source_anchors_ready and not machine_checked)
    lean_proof_source_ready = False
    checks = [
        _check("domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_consumable", not _proof_attempt_issues(attempt_report), "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_not_consumable"),
        _check("domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_ref_fresh", not attempt_ref_issues, "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_ref_not_fresh"),
        _check("source_files_present", bool(source_files), "manuscript_source_files_missing"),
        _check("required_source_anchors_ready", source_anchors_ready or machine_checked, "required_source_anchors_missing"),
        _check("field_forwarding_rejected_before_source_extraction", bool(attempt_report.get("profile_equivalence_transfer_field_forwarding_proof_rejected")) or machine_checked, "field_forwarding_rejection_missing"),
        _check("lean_proof_still_required", lean_proof_required or machine_checked, "lean_proof_requirement_not_recorded", severity="readiness"),
        _check("generated_log_provenance_rejected", True, ""),
        _check("no_source_mutation", not attempt_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not attempt_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif source_anchors_ready:
        status = "PASS"
        state = SOURCE_ANCHORS_READY_STATE
        next_agent_stage = "domain_theorem_bridge_transfer_field_source_backed_lean_statement_draft"
        next_agent_command = SOURCE_BACKED_LEAN_STATEMENT_DRAFT_COMMAND
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    production_checked = bool(machine_checked and state == CLOSED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_ready": bool(status == "PASS"),
        "profile_equivalence_transfer_source_anchors_ready": bool(status == "PASS" and source_anchors_ready),
        "profile_equivalence_transfer_lean_proof_required": bool(status == "PASS" and lean_proof_required),
        "profile_equivalence_transfer_lean_proof_source_ready": lean_proof_source_ready,
        "field_forwarding_allowed_as_production_proof": False,
        "generated_log_provenance_allowed": False,
        "production_claim_machine_checked": production_checked,
        "claim_packet_id": attempt_report.get("claim_packet_id") or "",
        "slug": attempt_report.get("slug") or "",
        "source_root": str(source_root_path),
        "source_file_count": len(source_files),
        "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_path": attempt_report.get("report_path") or "",
        "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report_sha256": attempt_report.get("report_sha256") or "",
        "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_ref_health": attempt_ref_health,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "no_placeholder_proof_attempt_ref_validation_issue_count": len(attempt_ref_issues),
            "source_file_count": len(source_files),
            "required_source_anchor_count": len(required_anchors),
            "required_source_anchor_ready_count": required_ready_count,
            "optional_source_anchor_count": len(optional_anchors),
            "optional_source_anchor_ready_count": optional_ready_count,
            "source_anchor_ready_count": sum(1 for item in anchors if item.get("found")),
            "source_anchor_missing_count": sum(1 for item in anchors if not item.get("found")),
            "lean_proof_required_count": 1 if lean_proof_required else 0,
            "lean_proof_source_ready_count": 1 if lean_proof_source_ready else 0,
            "field_forwarding_rejected_count": 1 if attempt_report.get("profile_equivalence_transfer_field_forwarding_proof_rejected") else 0,
            "generated_log_provenance_rejected_count": 1,
            "production_claim_machine_checked_count": 1 if production_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "source_anchor_extractions": anchors,
        "source_backed_theorem_obligations": _source_obligations(source_anchors_ready, lean_proof_required),
        "formalization_route": [
            {
                "step_id": "extract_source_anchors",
                "status": "ready" if source_anchors_ready else "missing",
                "output": "source labels and excerpt hashes for profile-equivalence transfer",
            },
            {
                "step_id": "draft_lean_statement",
                "status": "pending",
                "output": "explicit rate/direct-Euler/profile-validity theorem interface without field forwarding",
            },
            {
                "step_id": "prove_or_intake_lean_theorem",
                "status": "blocked_on_proof_source",
                "output": "source-backed no-placeholder Lean theorem outside generated logs",
            },
            {
                "step_id": "rewire_bridge",
                "status": "pending",
                "output": "waldDirectEulerDomainBridge consumes produced transfer theorem and reruns Lean gates",
            },
        ],
        "domain_theorem_bridge_transfer_field_no_placeholder_proof_attempt_report": attempt_report,
        "boundary": [
            "This command extracts manuscript theorem/proof anchors only; source anchors are not a Lean production proof.",
            "Field-forwarding and generated log artifacts remain rejected as proof-source provenance.",
            "The next stage must draft and prove a source-backed Lean theorem for profileEquivalenceTransfersDirectScoreLimit outside logs/paperctl/_batches.",
            "It reads local manuscript/source files only and does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Domain Theorem Bridge Transfer Field Source Backed Theorem Extraction",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_domain_theorem_bridge_transfer_field_source_backed_theorem_extraction_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Source anchors ready: {report.get('profile_equivalence_transfer_source_anchors_ready')}",
        f"- Lean proof required: {report.get('profile_equivalence_transfer_lean_proof_required')}",
        f"- Lean proof source ready: {report.get('profile_equivalence_transfer_lean_proof_source_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Source Anchors", ""])
    for item in report.get("source_anchor_extractions") or []:
        lines.append(
            f"- {item.get('anchor_id')}: label={item.get('label')} "
            f"required={item.get('required')} found={item.get('found')} matches={item.get('match_count')}"
        )
    lines.extend(["", "## Obligations", ""])
    for item in report.get("source_backed_theorem_obligations") or []:
        lines.append(
            f"- {item.get('obligation_id')}: {item.get('lean_declaration_name')} "
            f"lean_proof_required={item.get('lean_proof_required')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
