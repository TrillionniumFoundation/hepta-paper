"""Gate algebraic/order/topology laws required for numeric Lean semantics."""

import hashlib
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-gate"
NUMERIC_DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-definition-draft"

NUMERIC_DRAFT_LAWS_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_ALGEBRAIC_LAWS_REQUIRED"
NUMERIC_DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_READY_FOR_THEOREM_DRAFT"
NUMERIC_DRAFT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_DEFINITION_DRAFT_MACHINE_CHECKED_CLOSED"

LAW_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_LAW_OBLIGATIONS_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_READY_FOR_THEOREM_DRAFT"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_law_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_law_gate_ready",
    "lean_numeric_semantics_laws_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "numeric_semantics_definition_draft_report_path",
    "numeric_semantics_definition_draft_report_sha256",
    "lean_source_path",
    "lean_source_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_law_features",
    "numeric_semantics_law_obligations",
    "numeric_semantics_definition_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "numeric_definition_draft_count",
    "lean_structure_count",
    "lean_definition_count",
    "law_obligation_count",
    "rate_scalar_structure_count",
    "rate_scalar_law_structure_count",
    "order_law_source_count",
    "inverse_sqrt_law_source_count",
    "filter_bridge_source_count",
    "theorem_bridge_source_count",
    "lean_numeric_semantics_laws_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a numeric-semantics definition draft and checks whether RateScalar laws and theorem bridges are present.",
    "Reports law obligations instead of treating an operation-only structure as proof-ready semantics.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _numeric_draft_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_definition_draft_report_missing")
        return issues
    if report.get("command") != NUMERIC_DRAFT_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_definition_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_definition_draft_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_definition_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_definition_draft_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_definition_draft_state") or ""
    if state not in {NUMERIC_DRAFT_LAWS_REQUIRED_STATE, NUMERIC_DRAFT_READY_STATE, NUMERIC_DRAFT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_definition_draft_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_definition_draft_boundary:{key}")
    return issues


def _resolve_lean_source_path(report, source_root):
    path_text = report.get("lean_source_path") or (report.get("lean_execution") or {}).get("source_path") or ""
    if not path_text:
        return pathlib.Path()
    path = pathlib.Path(path_text)
    if path.is_absolute():
        return path
    return pathlib.Path(source_root or ".") / path


def _law_features(text):
    text = str(text or "")
    return {
        "source_available": bool(text),
        "rate_scalar_structure_present": bool(re.search(r"^\s*structure\s+RateScalar\b", text, re.M)),
        "rate_scalar_law_structure_present": bool(re.search(r"^\s*structure\s+RateScalarLaws\b", text, re.M)),
        "order_laws_present": bool(re.search(r"\b(le_refl|le_trans|lt_of_lt_of_le|PartialOrder|Preorder)\b", text)),
        "inverse_sqrt_laws_present": bool(re.search(r"\b(inv_mul|mul_inv|sqrt_mul_self|sq_sqrt|sqrt_nonneg)\b", text)),
        "filter_bridge_present": bool(re.search(r"\b(Filter|atTop|Tendsto|EventuallyEq)\b", text)),
        "theorem_bridge_present": bool(re.search(r"^\s*theorem\s+.*(Wald|DirectEuler|ProductionClaim)", text, re.M)),
        "source_byte_count": len(text.encode()),
    }


def _law_obligations(features):
    obligations = []
    if features.get("rate_scalar_structure_present") and not features.get("rate_scalar_law_structure_present"):
        obligations.append(
            {
                "work_item_id": "numeric-laws-rate-scalar-law-structure",
                "kind": "law_obligation",
                "required_law": "introduce RateScalarLaws tying operations to algebraic, order, inverse, square-root, and filter semantics",
                "blocking_theorem_readiness": True,
            }
        )
    if not features.get("order_laws_present"):
        obligations.append(
            {
                "work_item_id": "numeric-laws-order-preorder",
                "kind": "law_obligation",
                "required_law": "prove or import reflexive/transitive order laws for the rate scalar order",
                "blocking_theorem_readiness": True,
            }
        )
    if not features.get("inverse_sqrt_laws_present"):
        obligations.append(
            {
                "work_item_id": "numeric-laws-inverse-sqrt",
                "kind": "law_obligation",
                "required_law": "prove inverse and square-root laws needed for n_2^{-1/2} and sqrt(Delta t / n_2)",
                "blocking_theorem_readiness": True,
            }
        )
    if not features.get("filter_bridge_present"):
        obligations.append(
            {
                "work_item_id": "numeric-laws-filter-at-top-bridge",
                "kind": "law_obligation",
                "required_law": "bind Eventually/LittleO to an atTop/filter limit semantics",
                "blocking_theorem_readiness": True,
            }
        )
    if not features.get("theorem_bridge_present"):
        obligations.append(
            {
                "work_item_id": "numeric-laws-wald-direct-euler-theorem-bridge",
                "kind": "law_obligation",
                "required_law": "prove the implication from numeric eligibility conditions to Wald/direct-Euler validity",
                "blocking_theorem_readiness": True,
            }
        )
    return obligations


def formal_verifier_production_claim_lean_numeric_semantics_law_gate(
    numeric_semantics_definition_draft_report=None,
    source_root="",
    label="",
):
    numeric_report = numeric_semantics_definition_draft_report or {}
    validation_issues = _numeric_draft_issues(numeric_report)
    machine_checked = bool(
        numeric_report.get("production_claim_machine_checked")
        and numeric_report.get("formal_verifier_production_claim_lean_numeric_semantics_definition_draft_state") == NUMERIC_DRAFT_CLOSED_STATE
    )
    lean_source_path = _resolve_lean_source_path(numeric_report, source_root)
    lean_source_text = ""
    lean_source_sha = ""
    if lean_source_path and lean_source_path.exists():
        lean_source_text = lean_source_path.read_text(errors="replace")
        lean_source_sha = _sha256_file(lean_source_path)
    elif not machine_checked:
        _issue(validation_issues, "lean_numeric_semantics_definition_draft_source_missing", str(lean_source_path or ""))

    features = _law_features(lean_source_text)
    obligations = [] if machine_checked else _law_obligations(features)
    summary = numeric_report.get("summary") or {}
    syntax_checked = bool(numeric_report.get("lean_exit_code") == 0 or summary.get("lean_exit_zero_count"))
    if numeric_report.get("lean_algebraic_laws_required") and not obligations and not machine_checked:
        _issue(validation_issues, "algebraic_laws_required_but_no_obligations")

    checks = [
        _check("numeric_semantics_definition_draft_report_consumable", not _numeric_draft_issues(numeric_report), "production_claim_lean_numeric_semantics_definition_draft_not_consumable"),
        _check("numeric_semantics_definition_draft_lean_syntax_checked", syntax_checked or machine_checked, "lean_numeric_semantics_definition_draft_not_syntax_checked"),
        _check("lean_source_available", bool(lean_source_text) or machine_checked, "lean_numeric_semantics_definition_draft_source_missing", severity="readiness"),
        _check("rate_scalar_structure_present", features.get("rate_scalar_structure_present") or machine_checked, "rate_scalar_structure_missing"),
        _check("numeric_semantics_laws_complete", machine_checked or not obligations, "numeric_semantics_law_obligations_required", severity="readiness"),
        _check("no_source_mutation", not numeric_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not numeric_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif obligations:
        status = "PASS"
        state = LAW_REQUIRED_STATE
        next_agent_stage = "numeric_semantics_law_signature_draft"
        next_agent_command = ""
    else:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""

    laws_required = bool(status == "PASS" and state == LAW_REQUIRED_STATE)
    theorem_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_law_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_law_gate_ready": status == "PASS",
        "lean_numeric_semantics_laws_required": laws_required,
        "lean_theorem_draft_ready": theorem_ready,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": numeric_report.get("claim_packet_id") or "",
        "slug": numeric_report.get("slug") or "",
        "numeric_semantics_definition_draft_report_path": numeric_report.get("report_path") or "",
        "numeric_semantics_definition_draft_report_sha256": numeric_report.get("report_sha256") or "",
        "lean_source_path": str(lean_source_path or ""),
        "lean_source_sha256": lean_source_sha,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "numeric_definition_draft_count": summary.get("numeric_definition_draft_count", 0),
            "lean_structure_count": summary.get("lean_structure_count", 0),
            "lean_definition_count": summary.get("lean_definition_count", 0),
            "law_obligation_count": len(obligations),
            "rate_scalar_structure_count": 1 if features.get("rate_scalar_structure_present") else 0,
            "rate_scalar_law_structure_count": 1 if features.get("rate_scalar_law_structure_present") else 0,
            "order_law_source_count": 1 if features.get("order_laws_present") else 0,
            "inverse_sqrt_law_source_count": 1 if features.get("inverse_sqrt_laws_present") else 0,
            "filter_bridge_source_count": 1 if features.get("filter_bridge_present") else 0,
            "theorem_bridge_source_count": 1 if features.get("theorem_bridge_present") else 0,
            "lean_numeric_semantics_laws_required_count": 1 if laws_required else 0,
            "lean_theorem_draft_ready_count": 1 if theorem_ready else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_law_features": features,
        "numeric_semantics_law_obligations": obligations,
        "numeric_semantics_definition_draft_report": numeric_report,
        "boundary": [
            "This command refuses operation-only RateScalar semantics as theorem-ready numeric semantics.",
            "The next stage must draft or import algebraic/order/topology laws and theorem bridges before proof drafting.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Law Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_law_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Laws required: {report.get('lean_numeric_semantics_laws_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Numeric Semantics Law Obligations", ""])
    for item in report.get("numeric_semantics_law_obligations") or []:
        lines.append(f"- {item.get('work_item_id')}: {item.get('required_law')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
