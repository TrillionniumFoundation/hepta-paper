"""Gate whether numeric law signatures have real Lean proofs or imports."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-gate"
LAW_SIGNATURE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-signature-draft"

LAW_SIGNATURE_PROOFS_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_PROOFS_REQUIRED"
LAW_SIGNATURE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_READY_FOR_THEOREM_DRAFT"
LAW_SIGNATURE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_MACHINE_CHECKED_CLOSED"

PROOFS_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_PROOFS_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_READY_FOR_THEOREM_DRAFT"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_law_proof_gate_ready",
    "lean_law_proofs_required",
    "lean_theorem_draft_ready",
    "signature_only_laws_rejected",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "numeric_semantics_law_signature_draft_report_path",
    "numeric_semantics_law_signature_draft_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "law_proof_gaps",
    "law_signature_field_classifications",
    "numeric_semantics_law_signature_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "law_signature_field_count",
    "law_proof_available_count",
    "law_proof_gap_count",
    "signature_only_law_count",
    "lean_law_proofs_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a numeric law-signature draft and refuses to treat law fields as proved laws.",
    "Only no-placeholder Lean proofs or trusted local imports can unlock theorem drafting.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _law_signature_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_law_signature_draft_report_missing")
        return issues
    if report.get("command") != LAW_SIGNATURE_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_law_signature_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_law_signature_draft_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_law_signature_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_law_signature_draft_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft_state") or ""
    if state not in {LAW_SIGNATURE_PROOFS_REQUIRED_STATE, LAW_SIGNATURE_READY_STATE, LAW_SIGNATURE_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_law_signature_draft_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_law_signature_draft_boundary:{key}")
    return issues


def _law_proof_available(field):
    return bool(
        field.get("law_proof_available")
        or field.get("lean_proof_available")
        or field.get("proof_artifact_sha256")
        or field.get("trusted_import_path")
    )


def _classify_field(field):
    field = field or {}
    proof_available = _law_proof_available(field)
    signature_available = bool(field.get("law_signature_available") or field.get("lean_field_name"))
    gap = bool(not proof_available)
    return {
        "work_item_id": field.get("work_item_id") or "",
        "lean_field_name": field.get("lean_field_name") or "",
        "kind": field.get("kind") or "",
        "required_law": field.get("required_law") or "",
        "law_signature_available": signature_available,
        "law_proof_available": proof_available,
        "signature_only_law": bool(signature_available and not proof_available),
        "law_proof_gap": gap,
        "blocking_theorem_readiness": bool(field.get("blocking_theorem_readiness", True)),
        "next_required_action": "supply_no_placeholder_law_proof_or_trusted_import" if gap else "draft_theorem_against_law_proofs",
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate(
    numeric_semantics_law_signature_draft_report=None,
    label="",
):
    signature_report = numeric_semantics_law_signature_draft_report or {}
    validation_issues = _law_signature_issues(signature_report)
    fields = list(signature_report.get("numeric_semantics_law_signature_fields") or [])
    classifications = [_classify_field(field) for field in fields]
    proof_gaps = [item for item in classifications if item["law_proof_gap"]]
    signature_only_laws = [item for item in classifications if item["signature_only_law"]]
    machine_checked = bool(
        signature_report.get("production_claim_machine_checked")
        and signature_report.get("formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft_state") == LAW_SIGNATURE_CLOSED_STATE
    )
    theorem_ready = bool(not validation_issues and fields and not proof_gaps and not machine_checked)
    checks = [
        _check("numeric_semantics_law_signature_draft_report_consumable", not _law_signature_issues(signature_report), "production_claim_lean_numeric_semantics_law_signature_draft_not_consumable"),
        _check("law_signature_fields_present_or_closed", machine_checked or bool(fields), "law_signature_fields_missing"),
        _check("law_proofs_available", not proof_gaps or machine_checked, "law_proofs_missing", severity="readiness"),
        _check("signature_only_laws_rejected", not signature_only_laws or machine_checked, "signature_only_law_fields_present", severity="readiness"),
        _check("no_source_mutation", not signature_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not signature_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif theorem_ready:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""
    else:
        status = "PASS"
        state = PROOFS_REQUIRED_STATE
        next_agent_stage = "numeric_semantics_law_proof_work_item_dispatch"
        next_agent_command = ""

    proofs_required = bool(status == "PASS" and state == PROOFS_REQUIRED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_law_proof_gate_ready": status == "PASS",
        "lean_law_proofs_required": proofs_required,
        "lean_theorem_draft_ready": bool(status == "PASS" and state == READY_STATE),
        "signature_only_laws_rejected": bool(status == "PASS" and signature_only_laws and not machine_checked),
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": signature_report.get("claim_packet_id") or "",
        "slug": signature_report.get("slug") or "",
        "numeric_semantics_law_signature_draft_report_path": signature_report.get("report_path") or "",
        "numeric_semantics_law_signature_draft_report_sha256": signature_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "law_signature_field_count": len(fields),
            "law_proof_available_count": sum(1 for item in classifications if item["law_proof_available"]),
            "law_proof_gap_count": len(proof_gaps),
            "signature_only_law_count": len(signature_only_laws),
            "lean_law_proofs_required_count": 1 if proofs_required else 0,
            "lean_theorem_draft_ready_count": 1 if status == "PASS" and state == READY_STATE else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "law_proof_gaps": proof_gaps,
        "law_signature_field_classifications": classifications,
        "numeric_semantics_law_signature_draft_report": signature_report,
        "boundary": [
            "This command rejects law-signature fields as proof evidence.",
            "Each law obligation needs a no-placeholder Lean proof or a trusted local import before theorem drafting can proceed.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Law Proof Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Law proofs required: {report.get('lean_law_proofs_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Signature-only laws rejected: {report.get('signature_only_laws_rejected')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Law Proof Gaps", ""])
    for item in report.get("law_proof_gaps") or []:
        lines.append(f"- {item.get('work_item_id')}: {item.get('required_law')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
