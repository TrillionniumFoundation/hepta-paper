"""Intake local proof/import sources for Lean numeric-law work items."""

import hashlib
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-source-intake"
DISPATCH_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-work-item-dispatch"

DISPATCH_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_WORK_ITEM_DISPATCH_READY"
DISPATCH_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_law_proof_source_intake_ready",
    "lean_law_proof_sources_required",
    "lean_law_proof_or_import_ready",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "numeric_semantics_law_proof_work_item_dispatch_report_path",
    "numeric_semantics_law_proof_work_item_dispatch_report_sha256",
    "source_root",
    "candidate_limit",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "law_proof_source_classifications",
    "candidate_source_files",
    "numeric_semantics_law_proof_work_item_dispatch_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "law_proof_work_item_count",
    "local_lean_file_count",
    "candidate_source_file_count",
    "law_source_candidate_count",
    "law_proof_or_import_ready_count",
    "law_proof_source_gap_count",
    "lean_law_proof_sources_required_count",
    "lean_theorem_draft_ready_count",
    "vacuous_true_candidate_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes numeric-law proof dispatch work items and inventories local Lean proof/import candidates.",
    "A mention or signature is not enough; only theorem/lemma-style local evidence without placeholder tokens and without vacuous : True bodies can satisfy a work item.",
    "This command reads local source context and writes only reports; it does not execute Lean, mutate source, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
EXCLUDED_DIR_NAMES = {
    ".git",
    ".lake",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "logs",
    "node_modules",
}
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
NEXT_DECL_RE = re.compile(r"^\s*(theorem|lemma|def|structure|inductive|namespace|section|end)\b")
NAMESPACE_RE = re.compile(r"^\s*namespace\b")
SECTION_RE = re.compile(r"^\s*section\b")
END_RE = re.compile(r"^\s*end\b")
VACUOUS_TRUE_RE = re.compile(r":\s*True\s*:=", re.M)


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _dispatch_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_report_missing")
        return issues
    if report.get("command") != DISPATCH_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_law_proof_work_item_dispatch_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_state") or ""
    if state not in {DISPATCH_READY_STATE, DISPATCH_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_law_proof_work_item_dispatch_boundary:{key}")
    return issues


def _lean_identifier(value):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    return "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)


def _field_name(value):
    ident = _lean_identifier(value)
    return ident[:1].lower() + ident[1:] if ident else ""


def _lean_files(source_root, candidate_limit):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    files = []
    for path in root.rglob("*.lean"):
        if len(files) >= int(candidate_limit or 0):
            break
        if path.is_file() and not any(part in EXCLUDED_DIR_NAMES for part in path.relative_to(root).parts[:-1]):
            files.append(path)
    return files


def _extract_theorem_statements(lean_text):
    lines = str(lean_text or "").splitlines()
    statements = []
    scope_stack = []
    for index, line in enumerate(lines):
        match = THEOREM_RE.match(line)
        if match:
            end = len(lines)
            for later in range(index + 1, len(lines)):
                if NEXT_DECL_RE.match(lines[later]):
                    end = later
                    break
            block = "\n".join(lines[index:end])
            statement_text = block.split(":=", 1)[0]
            statement_text = re.sub(rf"^\s*{match.group(1)}\s+{re.escape(match.group(2))}\b", "", statement_text, count=1)
            statements.append(
                {
                    "name": match.group(2),
                    "statement_text": statement_text,
                    "normalized_name": _lean_identifier(match.group(2)).lower(),
                    "normalized_statement_text": _lean_identifier(statement_text).lower(),
                    "top_level_namespace": not any(item == "namespace" for item in scope_stack),
                }
            )
        if NAMESPACE_RE.match(line):
            scope_stack.append("namespace")
        elif SECTION_RE.match(line):
            scope_stack.append("section")
        elif END_RE.match(line) and scope_stack:
            scope_stack.pop()
    return statements


def _candidate_terms(item):
    terms = []
    for key in ["work_item_id", "lean_field_name", "required_law"]:
        value = str(item.get(key) or "").strip()
        if value:
            terms.append(value)
    field = item.get("lean_field_name") or _field_name(item.get("work_item_id") or "")
    if field:
        terms.append(field)
    ident = _lean_identifier(item.get("work_item_id") or "")
    if ident:
        terms.append(ident)
    return [term for index, term in enumerate(terms) if term and term not in terms[:index]]


def _scan_sources(source_root, candidate_limit):
    candidates = []
    for path in _lean_files(source_root, candidate_limit):
        text = path.read_text(errors="replace")
        lean_text = _strip_lean_comments(text)
        theorem_statements = _extract_theorem_statements(lean_text)
        candidates.append(
            {
                "path": str(path),
                "text_sha256": _sha256_text(text),
                "placeholder_token_count": len(PLACEHOLDER_RE.findall(lean_text)),
                "vacuous_true_marker_count": len(VACUOUS_TRUE_RE.findall(lean_text)),
                "theorem_or_lemma_count": len(theorem_statements),
                "text": lean_text,
                "_theorem_statements": theorem_statements,
            }
        )
    return candidates


def _classify_item(item, source_candidates):
    terms = _candidate_terms(item)
    matches = []
    for candidate in source_candidates:
        lean_text = candidate.get("text") or ""
        matched_terms = [term for term in terms if term and term in lean_text]
        if not matched_terms:
            continue
        normalized_terms = [_lean_identifier(term).lower() for term in terms if _lean_identifier(term)]
        matched_theorem_statement_count = 0
        theorem_names = []
        for statement in candidate.get("_theorem_statements") or []:
            theorem_names.append(statement.get("name") or "")
            if not statement.get("top_level_namespace"):
                continue
            normalized_name = statement.get("normalized_name") or ""
            normalized_statement_text = statement.get("normalized_statement_text") or ""
            name_matches = any(normalized and (normalized in normalized_name or normalized_name in normalized) for normalized in normalized_terms)
            statement_matches = any(normalized and normalized in normalized_statement_text for normalized in normalized_terms)
            if name_matches and statement_matches:
                matched_theorem_statement_count += 1
        proof_ready = bool(
            theorem_names
            and matched_theorem_statement_count
            and candidate.get("placeholder_token_count", 0) == 0
            and candidate.get("vacuous_true_marker_count", 0) == 0
            and "proof_ready=false" not in lean_text
        )
        matches.append(
            {
                "path": candidate.get("path") or "",
                "text_sha256": candidate.get("text_sha256") or "",
                "matched_terms": matched_terms[:5],
                "theorem_or_lemma_count": candidate.get("theorem_or_lemma_count", 0),
                "matched_theorem_statement_count": matched_theorem_statement_count,
                "placeholder_token_count": candidate.get("placeholder_token_count", 0),
                "vacuous_true_marker_count": candidate.get("vacuous_true_marker_count", 0),
                "proof_or_import_ready": proof_ready,
            }
        )
    ready = any(match.get("proof_or_import_ready") for match in matches)
    return {
        "work_item_id": item.get("work_item_id") or "",
        "dispatch_id": item.get("dispatch_id") or "",
        "lean_field_name": item.get("lean_field_name") or "",
        "required_law": item.get("required_law") or "",
        "proof_required": bool(item.get("proof_required")),
        "trusted_import_allowed": bool(item.get("trusted_import_allowed")),
        "no_placeholder_required": bool(item.get("no_placeholder_required")),
        "source_candidate_count": len(matches),
        "proof_or_import_ready": ready,
        "source_candidates": matches[:5],
        "next_required_action": "wire_no_placeholder_proof_or_trusted_import" if ready else "produce_or_locate_no_placeholder_law_proof_source",
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake(
    numeric_semantics_law_proof_work_item_dispatch_report=None,
    source_root="",
    candidate_limit=500,
    label="",
):
    dispatch_report = numeric_semantics_law_proof_work_item_dispatch_report or {}
    validation_issues = _dispatch_issues(dispatch_report)
    machine_checked = bool(
        dispatch_report.get("production_claim_machine_checked")
        and dispatch_report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_state") == DISPATCH_CLOSED_STATE
    )
    work_items = list(dispatch_report.get("law_proof_work_items") or [])
    source_candidates = _scan_sources(source_root or ".", candidate_limit)
    classifications = [] if machine_checked else [_classify_item(item, source_candidates) for item in work_items]
    ready_count = sum(1 for item in classifications if item.get("proof_or_import_ready"))
    source_candidate_count = sum(item.get("source_candidate_count", 0) for item in classifications)

    checks = [
        _check("numeric_semantics_law_proof_work_item_dispatch_report_consumable", not _dispatch_issues(dispatch_report), "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_not_consumable"),
        _check("law_proof_work_items_present_or_closed", machine_checked or bool(work_items), "law_proof_work_items_missing"),
        _check("local_lean_sources_scanned", machine_checked or bool(source_candidates), "local_lean_sources_missing", severity="readiness"),
        _check("all_law_proof_sources_ready", machine_checked or (bool(work_items) and ready_count == len(work_items)), "law_proof_sources_required", severity="readiness"),
        _check("no_source_mutation", not dispatch_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not dispatch_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif ready_count == len(work_items) and work_items:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "numeric_semantics_law_proof_or_import_execution"
        next_agent_command = ""
    else:
        status = "PASS"
        state = SOURCE_REQUIRED_STATE
        next_agent_stage = "numeric_semantics_law_proof_source_production"
        next_agent_command = ""

    source_required = bool(status == "PASS" and state == SOURCE_REQUIRED_STATE)
    ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_law_proof_source_intake_ready": status == "PASS",
        "lean_law_proof_sources_required": source_required,
        "lean_law_proof_or_import_ready": ready,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": dispatch_report.get("claim_packet_id") or "",
        "slug": dispatch_report.get("slug") or "",
        "numeric_semantics_law_proof_work_item_dispatch_report_path": dispatch_report.get("report_path") or "",
        "numeric_semantics_law_proof_work_item_dispatch_report_sha256": dispatch_report.get("report_sha256") or "",
        "source_root": str(source_root or "."),
        "candidate_limit": int(candidate_limit or 0),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "law_proof_work_item_count": len(work_items),
            "local_lean_file_count": len(source_candidates),
            "candidate_source_file_count": sum(1 for item in source_candidates if item.get("theorem_or_lemma_count") or item.get("placeholder_token_count") or True),
            "law_source_candidate_count": source_candidate_count,
            "law_proof_or_import_ready_count": ready_count,
            "law_proof_source_gap_count": max(0, len(work_items) - ready_count),
            "lean_law_proof_sources_required_count": 1 if source_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "vacuous_true_candidate_count": sum(1 for item in source_candidates if item.get("vacuous_true_marker_count", 0) > 0),
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "law_proof_source_classifications": classifications,
        "candidate_source_files": [
            {key: value for key, value in item.items() if key != "text"} for item in source_candidates[:20]
        ],
        "numeric_semantics_law_proof_work_item_dispatch_report": dispatch_report,
        "boundary": [
            "This command inventories local Lean proof/import sources only; mentions and signatures are not proofs.",
            "A work item is ready only with theorem/lemma-style local evidence or a trusted import without placeholder tokens or vacuous : True bodies.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Law Proof Source Intake",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Law proof sources required: {report.get('lean_law_proof_sources_required')}",
        f"- Law proof/import ready: {report.get('lean_law_proof_or_import_ready')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Law Proof Source Classifications", ""])
    for item in report.get("law_proof_source_classifications") or []:
        lines.append(
            f"- {item.get('work_item_id')}: candidates={item.get('source_candidate_count')} "
            f"ready={item.get('proof_or_import_ready')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
