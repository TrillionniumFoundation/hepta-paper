"""Plan production of nondegenerate Lean numeric-law proof sources."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-source-production-plan"
SOURCE_INTAKE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-source-intake"

SOURCE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_SOURCE_REQUIRED"
SOURCE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_READY"
SOURCE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_INTAKE_MACHINE_CHECKED_CLOSED"

PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_PRODUCTION_PLAN_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_PRODUCTION_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_PRODUCTION_PLAN_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_law_proof_source_production_plan_ready",
    "lean_law_proof_sources_required",
    "lean_theorem_draft_ready",
    "degenerate_model_forbidden",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "numeric_semantics_law_proof_source_intake_report_path",
    "numeric_semantics_law_proof_source_intake_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "proof_source_production_items",
    "acceptance_criteria",
    "critical_risks",
    "numeric_semantics_law_proof_source_intake_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "law_proof_source_gap_count",
    "proof_source_production_item_count",
    "degenerate_model_forbidden_count",
    "acceptance_criterion_count",
    "critical_risk_count",
    "lean_law_proof_sources_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes proof-source intake gaps and plans source production with nondegenerate proof criteria.",
    "The plan explicitly forbids vacuous Unit/True law models and signature-only proofs.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _source_intake_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_intake_report_missing")
        return issues
    if report.get("command") != SOURCE_INTAKE_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_intake_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_intake_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_law_proof_source_intake_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_intake_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake_state") or ""
    if state not in {SOURCE_REQUIRED_STATE, SOURCE_READY_STATE, SOURCE_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_intake_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_law_proof_source_intake_boundary:{key}")
    return issues


def _plan_items(report):
    items = []
    for item in report.get("law_proof_source_classifications") or []:
        if item.get("proof_or_import_ready"):
            continue
        items.append(
            {
                "work_item_id": item.get("work_item_id") or "",
                "dispatch_id": item.get("dispatch_id") or "",
                "lean_field_name": item.get("lean_field_name") or "",
                "required_law": item.get("required_law") or "",
                "route": "formalization",
                "source_candidate_count": item.get("source_candidate_count", 0),
                "required_source_kind": "no_placeholder_lean_proof_or_trusted_import",
                "degenerate_model_allowed": False,
                "signature_only_allowed": False,
                "trusted_import_allowed": bool(item.get("trusted_import_allowed")),
                "acceptance_criteria": [
                    "contains theorem or lemma evidence for the specific law obligation",
                    "contains no sorry/admit/axiom/opaque placeholder tokens",
                    "uses a nondegenerate scalar model or an imported ordered/topological numeric structure",
                    "connects the law to the source-backed RateScalar/NumericRateInputs semantics",
                    "records local provenance for any trusted import",
                ],
                "next_required_action": "author_or_locate_source_backed_law_proof",
            }
        )
    return items


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan(
    numeric_semantics_law_proof_source_intake_report=None,
    label="",
):
    intake_report = numeric_semantics_law_proof_source_intake_report or {}
    validation_issues = _source_intake_issues(intake_report)
    machine_checked = bool(
        intake_report.get("production_claim_machine_checked")
        and intake_report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_intake_state") == SOURCE_CLOSED_STATE
    )
    items = [] if machine_checked else _plan_items(intake_report)
    if intake_report.get("lean_law_proof_sources_required") and not items and not machine_checked:
        _issue(validation_issues, "law_proof_sources_required_but_no_production_items")

    acceptance_criteria = [
        "No generated proof source may use Unit, True, or always-true order as a substitute for numeric semantics.",
        "No generated proof source may use sorry, admit, axiom, opaque, or a theorem that only restates a field as a hypothesis.",
        "Every trusted import must be local, hashable, and tied to the law work item it satisfies.",
        "Theorem draft readiness remains false until all law proof sources are independently checked.",
    ]
    critical_risks = [
        {
            "risk": "degenerate_law_model",
            "mitigation": "forbid vacuous Unit/True models and require nondegenerate numeric semantics or trusted imports",
        },
        {
            "risk": "signature_field_as_proof",
            "mitigation": "treat RateScalarLaws/NumericLawSignature fields as obligations only",
        },
        {
            "risk": "placeholder_or_assumption_echo",
            "mitigation": "require no-placeholder proof evidence and reject restating the target as a premise",
        },
        {
            "risk": "mathlib_dependency_gap",
            "mitigation": "record local trusted import provenance before using ordered/topological real-number laws",
        },
    ]
    checks = [
        _check("numeric_semantics_law_proof_source_intake_report_consumable", not _source_intake_issues(intake_report), "production_claim_lean_numeric_semantics_law_proof_source_intake_not_consumable"),
        _check("proof_source_production_items_present_or_closed", machine_checked or bool(items), "proof_source_production_items_missing"),
        _check("degenerate_model_forbidden", all(not item.get("degenerate_model_allowed") for item in items), "degenerate_model_allowed"),
        _check("signature_only_disallowed", all(not item.get("signature_only_allowed") for item in items), "signature_only_allowed"),
        _check("no_source_mutation", not intake_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not intake_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = PLAN_READY_STATE
        next_agent_stage = "numeric_semantics_law_proof_source_draft"
        next_agent_command = ""

    source_required = bool(status == "PASS" and items)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_law_proof_source_production_plan_ready": status == "PASS",
        "lean_law_proof_sources_required": source_required,
        "lean_theorem_draft_ready": False,
        "degenerate_model_forbidden": True,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": intake_report.get("claim_packet_id") or "",
        "slug": intake_report.get("slug") or "",
        "numeric_semantics_law_proof_source_intake_report_path": intake_report.get("report_path") or "",
        "numeric_semantics_law_proof_source_intake_report_sha256": intake_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "law_proof_source_gap_count": (intake_report.get("summary") or {}).get("law_proof_source_gap_count", 0),
            "proof_source_production_item_count": len(items),
            "degenerate_model_forbidden_count": 1,
            "acceptance_criterion_count": len(acceptance_criteria),
            "critical_risk_count": len(critical_risks),
            "lean_law_proof_sources_required_count": 1 if source_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "proof_source_production_items": items,
        "acceptance_criteria": acceptance_criteria,
        "critical_risks": critical_risks,
        "numeric_semantics_law_proof_source_intake_report": intake_report,
        "boundary": [
            "This command plans proof-source production only; it does not author or verify proofs.",
            "Degenerate scalar models and signature-only evidence are explicitly forbidden.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Law Proof Source Production Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Law proof sources required: {report.get('lean_law_proof_sources_required')}",
        f"- Degenerate model forbidden: {report.get('degenerate_model_forbidden')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Proof Source Production Items", ""])
    for item in report.get("proof_source_production_items") or []:
        lines.append(
            f"- {item.get('work_item_id')}: degenerate_allowed={item.get('degenerate_model_allowed')} "
            f"signature_only_allowed={item.get('signature_only_allowed')} next={item.get('next_required_action')}"
        )
    lines.extend(["", "## Critical Risks", ""])
    for item in report.get("critical_risks") or []:
        lines.append(f"- {item.get('risk')}: {item.get('mitigation')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
