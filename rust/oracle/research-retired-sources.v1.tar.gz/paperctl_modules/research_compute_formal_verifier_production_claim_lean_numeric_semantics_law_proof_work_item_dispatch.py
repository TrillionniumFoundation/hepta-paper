"""Dispatch Lean numeric-law proof work items from proof-gate gaps."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-work-item-dispatch"
PROOF_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-gate"

PROOF_GATE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_PROOFS_REQUIRED"
PROOF_GATE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_READY_FOR_THEOREM_DRAFT"
PROOF_GATE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_GATE_MACHINE_CHECKED_CLOSED"

READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_WORK_ITEM_DISPATCH_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_WORK_ITEM_DISPATCH_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_WORK_ITEM_DISPATCH_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_law_proof_work_item_dispatch_ready",
    "lean_law_proofs_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "numeric_semantics_law_proof_gate_report_path",
    "numeric_semantics_law_proof_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "law_proof_work_items",
    "numeric_semantics_law_proof_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "law_proof_gap_count",
    "law_proof_work_item_count",
    "blocking_work_item_count",
    "lean_law_proofs_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes law-proof gate gaps and creates dispatchable local Lean proof/import work items.",
    "Dispatch work items are not proofs and do not make the production claim machine checked.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _proof_gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_gate_report_missing")
        return issues
    if report.get("command") != PROOF_GATE_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_gate_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_law_proof_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate_state") or ""
    if state not in {PROOF_GATE_REQUIRED_STATE, PROOF_GATE_READY_STATE, PROOF_GATE_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_law_proof_gate_boundary:{key}")
    return issues


def _work_items(report):
    items = []
    for index, gap in enumerate(report.get("law_proof_gaps") or [], start=1):
        work_item_id = gap.get("work_item_id") or f"numeric-law-proof-gap-{index:04d}"
        items.append(
            {
                "work_item_id": work_item_id,
                "dispatch_id": f"lean-law-proof-{index:04d}",
                "route": "formalization",
                "kind": "lean_numeric_law_proof_or_trusted_import",
                "required_law": gap.get("required_law") or "",
                "lean_field_name": gap.get("lean_field_name") or "",
                "source_work_item_id": work_item_id,
                "proof_required": True,
                "trusted_import_allowed": True,
                "no_placeholder_required": True,
                "blocking_theorem_readiness": bool(gap.get("blocking_theorem_readiness", True)),
                "production_claim_machine_checked_after_dispatch": False,
                "next_required_action": "produce_no_placeholder_lean_law_proof_or_trusted_import",
            }
        )
    return items


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch(
    numeric_semantics_law_proof_gate_report=None,
    label="",
):
    proof_report = numeric_semantics_law_proof_gate_report or {}
    validation_issues = _proof_gate_issues(proof_report)
    machine_checked = bool(
        proof_report.get("production_claim_machine_checked")
        and proof_report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_gate_state") == PROOF_GATE_CLOSED_STATE
    )
    items = [] if machine_checked else _work_items(proof_report)
    if proof_report.get("lean_law_proofs_required") and not items and not machine_checked:
        _issue(validation_issues, "law_proofs_required_but_no_dispatch_work_items")
    checks = [
        _check("numeric_semantics_law_proof_gate_report_consumable", not _proof_gate_issues(proof_report), "production_claim_lean_numeric_semantics_law_proof_gate_not_consumable"),
        _check("law_proof_work_items_present_or_closed", machine_checked or bool(items), "law_proof_work_items_missing"),
        _check("all_work_items_require_no_placeholder_proofs", all(item.get("no_placeholder_required") for item in items), "no_placeholder_requirement_missing"),
        _check("no_source_mutation", not proof_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not proof_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "numeric_semantics_law_proof_or_import_execution"
        next_agent_command = ""

    law_proofs_required = bool(status == "PASS" and items)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_law_proof_work_item_dispatch_ready": status == "PASS",
        "lean_law_proofs_required": law_proofs_required,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": proof_report.get("claim_packet_id") or "",
        "slug": proof_report.get("slug") or "",
        "numeric_semantics_law_proof_gate_report_path": proof_report.get("report_path") or "",
        "numeric_semantics_law_proof_gate_report_sha256": proof_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "law_proof_gap_count": len(proof_report.get("law_proof_gaps") or []),
            "law_proof_work_item_count": len(items),
            "blocking_work_item_count": sum(1 for item in items if item.get("blocking_theorem_readiness")),
            "lean_law_proofs_required_count": 1 if law_proofs_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "law_proof_work_items": items,
        "numeric_semantics_law_proof_gate_report": proof_report,
        "boundary": [
            "This command dispatches local proof/import work items only; it does not prove law obligations.",
            "Every work item requires a no-placeholder proof or a trusted local import before theorem drafting.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Law Proof Work Item Dispatch",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_law_proof_work_item_dispatch_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Law proofs required: {report.get('lean_law_proofs_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Law Proof Work Items", ""])
    for item in report.get("law_proof_work_items") or []:
        lines.append(
            f"- {item.get('dispatch_id')}: {item.get('work_item_id')} "
            f"route={item.get('route')} no_placeholder={item.get('no_placeholder_required')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
