"""Draft Lean law signatures for numeric production-claim semantics."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-signature-draft"
LAW_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-gate"

LAW_GATE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_LAW_OBLIGATIONS_REQUIRED"
LAW_GATE_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_READY_FOR_THEOREM_DRAFT"
LAW_GATE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_GATE_MACHINE_CHECKED_CLOSED"

PROOFS_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_PROOFS_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_READY_FOR_THEOREM_DRAFT"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_SIGNATURE_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_law_signature_draft_ready",
    "lean_law_proofs_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "numeric_semantics_law_gate_report_path",
    "numeric_semantics_law_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "numeric_semantics_law_signature_fields",
    "numeric_semantics_law_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "law_obligation_count",
    "law_signature_field_count",
    "lean_structure_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "lean_law_proofs_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes numeric-semantics law-gate obligations and drafts Lean law signatures.",
    "Law signature fields are obligations, not proved laws or theorem certificates.",
    "This command writes local draft artifacts, syntax-checks Lean, and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _law_gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_law_gate_report_missing")
        return issues
    if report.get("command") != LAW_GATE_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_law_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_law_gate_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_law_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_law_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_law_gate_state") or ""
    if state not in {LAW_GATE_REQUIRED_STATE, LAW_GATE_READY_STATE, LAW_GATE_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_law_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_law_gate_boundary:{key}")
    return issues


def _lean_identifier(value, fallback="ProductionClaimFormalization"):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    ident = "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)
    if not ident or not ident[0].isalpha():
        ident = fallback
    return ident[:120]


def _field_name(work_item_id):
    ident = _lean_identifier(work_item_id, "lawObligation")
    return ident[:1].lower() + ident[1:]


def _signature_fields(report):
    fields = []
    seen = set()
    for item in report.get("numeric_semantics_law_obligations") or []:
        work_item_id = str(item.get("work_item_id") or "").strip()
        if not work_item_id or work_item_id in seen:
            continue
        seen.add(work_item_id)
        fields.append(
            {
                "work_item_id": work_item_id,
                "lean_field_name": _field_name(work_item_id),
                "required_law": item.get("required_law") or "",
                "kind": item.get("kind") or "law_obligation",
                "law_signature_available": True,
                "law_proof_available": False,
                "blocking_theorem_readiness": bool(item.get("blocking_theorem_readiness", True)),
                "next_required_action": "provide_no_placeholder_law_proof_or_import",
            }
        )
    return fields


def _lean_source(report, fields):
    namespace = _lean_identifier(report.get("slug") or "ProductionClaim", "ProductionClaimFormalization")
    lines = [
        "/-",
        "paper_factory production claim Lean numeric law-signature draft.",
        "This file records law obligations as structure fields.",
        "It does not prove the laws or certify the production claim.",
        "-/",
        "",
        "universe u",
        "",
        f"namespace {namespace}",
        "",
        "structure RateScalar where",
        "  Carrier : Type u",
        "  zero : Carrier",
        "  one : Carrier",
        "  add : Carrier -> Carrier -> Carrier",
        "  mul : Carrier -> Carrier -> Carrier",
        "  inv : Carrier -> Carrier",
        "  sqrt : Carrier -> Carrier",
        "  le : Carrier -> Carrier -> Prop",
        "  lt : Carrier -> Carrier -> Prop",
        "",
        "def Eventually (P : Nat -> Prop) : Prop :=",
        "  Exists (fun N0 : Nat => forall N : Nat, N0 <= N -> P N)",
        "",
        "structure RateScalarLaws (S : RateScalar) where",
        "  le_refl : forall x : S.Carrier, S.le x x",
        "  le_trans : forall x y z : S.Carrier, S.le x y -> S.le y z -> S.le x z",
        "  lt_of_lt_of_le : forall x y z : S.Carrier, S.lt x y -> S.le y z -> S.lt x z",
        "  zero_lt_one : S.lt S.zero S.one",
        "  mul_le_mul_left : forall c x y : S.Carrier, S.le S.zero c -> S.le x y -> S.le (S.mul c x) (S.mul c y)",
        "  inv_sqrt_positive : forall x : S.Carrier, S.lt S.zero x -> S.lt S.zero (S.inv (S.sqrt x))",
        "  sqrt_mul_self_le : forall x : S.Carrier, S.le S.zero x -> S.le (S.mul (S.sqrt x) (S.sqrt x)) x",
        "  eventually_filter_bridge : forall P : Nat -> Prop, Eventually P -> Prop",
        "  wald_direct_euler_bridge : Prop",
        "",
        "structure NumericLawSignature where",
        "  scalar : RateScalar",
        "  laws : RateScalarLaws scalar",
    ]
    if fields:
        for item in fields:
            lines.extend(
                [
                    f"  /-- {item['work_item_id']}: {item['required_law']} -/",
                    f"  {item['lean_field_name']} : Prop",
                ]
            )
    else:
        lines.append("  noMissingLawObligations : True")
    lines.extend(
        [
            "",
            "/- Law obligation index.",
            "Each field above is a required law/proof obligation.",
            "The next stage must supply no-placeholder proofs or imports.",
        ]
    )
    for item in fields:
        lines.append(f"{item.get('work_item_id')}: {item.get('lean_field_name')} proof_ready=false")
    lines.extend(["-/", "", f"end {namespace}", ""])
    return "\n".join(lines)


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft(
    numeric_semantics_law_gate_report=None,
    output_root=None,
    lean_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    law_report = numeric_semantics_law_gate_report or {}
    validation_issues = _law_gate_issues(law_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(
        law_report.get("production_claim_machine_checked")
        and law_report.get("formal_verifier_production_claim_lean_numeric_semantics_law_gate_state") == LAW_GATE_CLOSED_STATE
    )
    fields = _signature_fields(law_report)
    lean_source_text = _lean_source(law_report, fields)
    source_info = _write_text(output_root / "production-claim-lean-numeric-semantics-law-signature-draft.lean", lean_source_text)
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if selected_lean:
        try:
            result = _run_lean(selected_lean, source_info["path"], timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    proof_ready_count = sum(1 for item in fields if item.get("law_proof_available"))
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    checks = [
        _check("numeric_semantics_law_gate_report_consumable", not _law_gate_issues(law_report), "production_claim_lean_numeric_semantics_law_gate_not_consumable"),
        _check("law_obligations_present_or_closed", machine_checked or bool(fields), "numeric_semantics_law_obligations_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("rate_scalar_laws_structure_present", "RateScalarLaws" in structures, "rate_scalar_laws_structure_missing"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("law_proofs_available", machine_checked or proof_ready_count == len(fields), "law_proofs_required", severity="readiness"),
        _check("no_source_mutation", not law_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not law_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif lean_exit_zero and "RateScalarLaws" in structures and fields and not placeholders and proof_ready_count < len(fields):
        status = "PASS"
        state = PROOFS_REQUIRED_STATE
        next_agent_stage = "numeric_semantics_law_proof_gate"
        next_agent_command = ""
    elif lean_exit_zero and "RateScalarLaws" in structures and fields and not placeholders:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    proofs_required = bool(status == "PASS" and state == PROOFS_REQUIRED_STATE)
    theorem_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_law_signature_draft_ready": bool(status == "PASS" and state in {PROOFS_REQUIRED_STATE, READY_STATE}),
        "lean_law_proofs_required": proofs_required,
        "lean_theorem_draft_ready": theorem_ready,
        "production_claim_machine_checked": machine_checked,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": law_report.get("claim_packet_id") or "",
        "slug": law_report.get("slug") or "",
        "numeric_semantics_law_gate_report_path": law_report.get("report_path") or "",
        "numeric_semantics_law_gate_report_sha256": law_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "law_obligation_count": len(law_report.get("numeric_semantics_law_obligations") or []),
            "law_signature_field_count": len(fields),
            "lean_structure_count": len(structures),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "lean_law_proofs_required_count": 1 if proofs_required else 0,
            "lean_theorem_draft_ready_count": 1 if theorem_ready else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "placeholder_token_count": len(placeholders),
        },
        "numeric_semantics_law_signature_fields": fields,
        "numeric_semantics_law_gate_report": law_report,
        "boundary": [
            "This command drafts law signatures only; structure fields are not proved laws.",
            "The next stage must supply no-placeholder proofs or imports for each law obligation before theorem drafting.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Law Signature Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_law_signature_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Law proofs required: {report.get('lean_law_proofs_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Law Signature Fields", ""])
    for item in report.get("numeric_semantics_law_signature_fields") or []:
        lines.append(
            f"- {item.get('work_item_id')}: {item.get('lean_field_name')} "
            f"proof={item.get('law_proof_available')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
