"""Plan local nondegenerate Lean numeric backend production."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-local-backend-production-plan"
FEASIBILITY_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-local-proof-source-feasibility-gate"

FEASIBILITY_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_LOCAL_BACKEND_REQUIRED"
FEASIBILITY_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_READY"
FEASIBILITY_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_MACHINE_CHECKED_CLOSED"

PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_BACKEND_PRODUCTION_PLAN_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_BACKEND_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_BACKEND_PRODUCTION_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_BACKEND_PRODUCTION_PLAN_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_local_backend_production_plan_ready",
    "lean_local_numeric_backend_required",
    "lean_trusted_import_setup_required",
    "lean_theorem_draft_ready",
    "degenerate_model_allowed",
    "signature_only_allowed",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "local_proof_source_feasibility_gate_report_path",
    "local_proof_source_feasibility_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "local_backend_production_items",
    "route_options",
    "acceptance_criteria",
    "critical_blockers",
    "local_proof_source_feasibility_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "local_backend_gap_count",
    "local_backend_production_item_count",
    "route_option_count",
    "critical_blocker_count",
    "acceptance_criterion_count",
    "trusted_import_route_count",
    "local_backend_route_count",
    "source_mutation_planned_count",
    "network_action_planned_count",
    "lean_local_numeric_backend_required_count",
    "lean_trusted_import_setup_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes local proof-source feasibility gaps and plans the two non-vacuous routes: trusted import setup or local numeric backend production.",
    "The plan preserves hard boundaries: no Unit/True model, no signature-only proof, no placeholder, and no assumption-echo theorem.",
    "This command is report-only and does not execute Lean, mutate dependencies/source, fetch Mathlib, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _feasibility_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_report_missing")
        return issues
    if report.get("command") != FEASIBILITY_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_local_proof_source_feasibility_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_state") or ""
    if state not in {FEASIBILITY_REQUIRED_STATE, FEASIBILITY_READY_STATE, FEASIBILITY_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_local_proof_source_feasibility_gate_boundary:{key}")
    return issues


def _production_items(report):
    items = []
    for item in report.get("local_backend_classifications") or []:
        if item.get("local_backend_ready"):
            continue
        items.append(
            {
                "work_item_id": item.get("work_item_id") or "",
                "dispatch_id": item.get("dispatch_id") or "",
                "lean_field_name": item.get("lean_field_name") or "",
                "required_law": item.get("required_law") or "",
                "source_candidate_count": item.get("source_candidate_count", 0),
                "required_source_kind": "nondegenerate_local_numeric_backend_or_trusted_import",
                "degenerate_model_allowed": False,
                "signature_only_allowed": False,
                "placeholder_allowed": False,
                "assumption_echo_allowed": False,
                "trusted_import_allowed": bool(item.get("trusted_import_allowed")),
                "source_mutation_planned": False,
                "network_action_planned": False,
                "next_required_action": "choose_trusted_import_setup_or_author_local_numeric_backend",
            }
        )
    return items


def formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan(
    local_proof_source_feasibility_gate_report=None,
    label="",
):
    feasibility_report = local_proof_source_feasibility_gate_report or {}
    validation_issues = _feasibility_issues(feasibility_report)
    machine_checked = bool(
        feasibility_report.get("production_claim_machine_checked")
        and feasibility_report.get("formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_state") == FEASIBILITY_CLOSED_STATE
    )
    items = [] if machine_checked else _production_items(feasibility_report)
    if feasibility_report.get("lean_local_numeric_backend_required") and not items and not machine_checked:
        _issue(validation_issues, "local_numeric_backend_required_but_no_production_items")

    route_options = [
        {
            "route": "trusted_import_setup_then_law_import",
            "ready": False,
            "preferred_when": "Mathlib or a trusted local ordered/topological numeric library can be set up with hash/provenance.",
            "required_artifacts": ["lean-toolchain", "lakefile", "lake-manifest.json", "successful Mathlib/import probe", "law import provenance"],
            "source_mutation_planned": False,
            "network_action_planned": False,
        },
        {
            "route": "local_non_degenerate_numeric_backend",
            "ready": False,
            "preferred_when": "External trusted imports are unavailable and the project must define/order/prove the scalar laws locally.",
            "required_artifacts": ["nondegenerate carrier", "order/inverse/sqrt/filter laws", "Wald/direct-Euler theorem bridge", "no-placeholder theorem evidence"],
            "source_mutation_planned": False,
            "network_action_planned": False,
        },
    ]
    acceptance = [
        "Every law item has theorem or lemma evidence with no sorry/admit/axiom/opaque placeholders.",
        "The carrier and order are nondegenerate; Unit, True, Subsingleton, and always-true shortcuts are forbidden.",
        "Signature fields are treated only as obligations until backed by proof/import provenance.",
        "Trusted imports require local dependency provenance and a successful import probe before satisfying any law.",
        "Theorem draft readiness remains false until all law sources are produced and checked.",
    ]
    critical_blockers = [
        {"blocker": "local_theorem_sources_missing", "detail": "The feasibility gate found no theorem/lemma evidence for 5 law items."},
        {"blocker": "mathlib_import_unavailable", "detail": "The trusted-import capability gate could not import Mathlib in the current project."},
        {"blocker": "signature_only_candidate", "detail": "The only matched local candidate is the law-signature draft, not proof source."},
    ]
    checks = [
        _check("local_proof_source_feasibility_gate_report_consumable", not _feasibility_issues(feasibility_report), "production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_not_consumable"),
        _check("local_backend_production_items_present_or_closed", machine_checked or bool(items), "local_backend_production_items_missing"),
        _check("degenerate_model_forbidden", all(not item.get("degenerate_model_allowed") for item in items), "degenerate_model_allowed"),
        _check("signature_only_forbidden", all(not item.get("signature_only_allowed") for item in items), "signature_only_allowed"),
        _check("placeholder_forbidden", all(not item.get("placeholder_allowed") for item in items), "placeholder_allowed"),
        _check("plan_is_report_only", all(not item.get("source_mutation_planned") for item in items), "source_mutation_planned"),
        _check("network_not_planned", all(not item.get("network_action_planned") for item in items), "network_action_planned"),
        _check("no_source_mutation", not feasibility_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not feasibility_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = PLAN_READY_STATE
        next_agent_stage = "trusted_import_setup_execution_or_local_numeric_backend_draft"
        next_agent_command = ""

    local_required = bool(status == "PASS" and items)
    trusted_setup_required = bool(feasibility_report.get("lean_local_numeric_backend_required") and not feasibility_report.get("lean_mathlib_import_ready"))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_local_backend_production_plan_ready": status == "PASS",
        "lean_local_numeric_backend_required": local_required,
        "lean_trusted_import_setup_required": trusted_setup_required,
        "lean_theorem_draft_ready": False,
        "degenerate_model_allowed": False,
        "signature_only_allowed": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": feasibility_report.get("claim_packet_id") or "",
        "slug": feasibility_report.get("slug") or "",
        "local_proof_source_feasibility_gate_report_path": feasibility_report.get("report_path") or "",
        "local_proof_source_feasibility_gate_report_sha256": feasibility_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "local_backend_gap_count": (feasibility_report.get("summary") or {}).get("local_backend_gap_count", 0),
            "local_backend_production_item_count": len(items),
            "route_option_count": len(route_options),
            "critical_blocker_count": len(critical_blockers),
            "acceptance_criterion_count": len(acceptance),
            "trusted_import_route_count": 1,
            "local_backend_route_count": 1,
            "source_mutation_planned_count": sum(1 for item in items if item.get("source_mutation_planned")),
            "network_action_planned_count": sum(1 for item in items if item.get("network_action_planned")),
            "lean_local_numeric_backend_required_count": 1 if local_required else 0,
            "lean_trusted_import_setup_required_count": 1 if trusted_setup_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "local_backend_production_items": items,
        "route_options": route_options,
        "acceptance_criteria": acceptance,
        "critical_blockers": critical_blockers,
        "local_proof_source_feasibility_gate_report": feasibility_report,
        "boundary": [
            "This command plans local backend production only; it does not author or verify proofs.",
            "It records two valid routes: trusted imports with provenance, or a local nondegenerate numeric backend with law proofs.",
            "Degenerate models, signature-only evidence, placeholders, and assumption-echo proofs remain forbidden.",
            "It does not execute Lean, mutate dependency/source/manuscript/package/archive state, fetch Mathlib, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Local Backend Production Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_local_backend_production_plan_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Local backend required: {report.get('lean_local_numeric_backend_required')}",
        f"- Trusted import setup required: {report.get('lean_trusted_import_setup_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Route Options", ""])
    for item in report.get("route_options") or []:
        lines.append(
            f"- {item.get('route')}: ready={item.get('ready')} "
            f"mutation={item.get('source_mutation_planned')} network={item.get('network_action_planned')}"
        )
    lines.extend(["", "## Local Backend Production Items", ""])
    for item in report.get("local_backend_production_items") or []:
        lines.append(
            f"- {item.get('work_item_id')}: degenerate_allowed={item.get('degenerate_model_allowed')} "
            f"signature_only_allowed={item.get('signature_only_allowed')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
