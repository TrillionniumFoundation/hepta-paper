"""Gate local nondegenerate Lean proof-source feasibility for numeric laws."""

import hashlib
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-local-proof-source-feasibility-gate"
SETUP_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-setup-plan"

SETUP_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_PLAN_READY"
SETUP_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_PLAN_MACHINE_CHECKED_CLOSED"

LOCAL_BACKEND_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_LOCAL_BACKEND_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LOCAL_PROOF_SOURCE_FEASIBILITY_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_local_proof_source_feasibility_gate_ready",
    "lean_local_numeric_backend_ready",
    "lean_local_numeric_backend_required",
    "lean_mathlib_import_ready",
    "lean_theorem_draft_ready",
    "degenerate_model_allowed",
    "signature_only_allowed",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "trusted_import_setup_plan_report_path",
    "trusted_import_setup_plan_report_sha256",
    "source_root",
    "candidate_limit",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "local_backend_classifications",
    "local_backend_candidate_files",
    "proof_source_production_items",
    "trusted_import_setup_plan_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_production_item_count",
    "local_lean_file_count",
    "local_backend_candidate_file_count",
    "local_backend_ready_count",
    "local_backend_gap_count",
    "trusted_import_setup_item_count",
    "lean_local_numeric_backend_required_count",
    "lean_mathlib_import_ready_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the trusted-import setup plan and checks whether local nondegenerate Lean proof sources can replace missing imports.",
    "The scan is conservative: signatures, placeholders, assumption echoes, and Unit/True-style degenerate models do not satisfy law items.",
    "This command only reads local Lean sources and writes reports; it does not execute Lean, mutate source, fetch dependencies, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
THEOREM_RE = re.compile(r"^\s*(theorem|lemma)\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)
NEXT_DECL_RE = re.compile(r"^\s*(theorem|lemma|def|structure|class|abbrev|inductive|namespace|section|end)\b")
SIGNATURE_RE = re.compile(r"^\s*(structure|class|abbrev)\s+(RateScalarLaws|NumericLawSignature)\b", re.M)
DEGENERATE_RE = re.compile(r"\b(Unit|PUnit|True|False|Subsingleton|trivial)\b")
NUMERIC_BACKEND_RE = re.compile(
    r"\b(RateScalar|NumericRateInputs|RateScalarLaws|Real|Float|Rat|LinearOrdered|Preorder|PartialOrder|"
    r"Topological|Filter|Asymptotics|IsLittleO|sqrt|inv|inverse)\b"
)
EXCLUDED_DIR_NAMES = {
    ".git",
    ".lake",
    "__pycache__",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "logs",
    "node_modules",
}


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _strip_lean_comments(source_text):
    text = str(source_text or "")
    result = []
    index = 0
    block_depth = 0
    in_string = False
    string_escape = False
    while index < len(text):
        pair = text[index:index + 2]
        if in_string:
            char = text[index]
            if string_escape:
                result.append(" ")
                string_escape = False
                index += 1
                continue
            if char == "\\":
                result.append(" ")
                string_escape = True
                index += 1
                continue
            if char == "\"":
                result.append("\"")
                in_string = False
                index += 1
                continue
            result.append("\n" if char == "\n" else " ")
            index += 1
            continue
        if block_depth:
            if pair == "/-":
                block_depth += 1
                index += 2
                continue
            if pair == "-/":
                block_depth -= 1
                index += 2
                continue
            result.append("\n" if text[index] == "\n" else " ")
            index += 1
            continue
        if pair == "/-":
            block_depth = 1
            index += 2
            continue
        if pair == "--":
            while index < len(text) and text[index] != "\n":
                index += 1
            continue
        if text[index] == "\"":
            result.append("\"")
            in_string = True
            index += 1
            continue
        result.append(text[index])
        index += 1
    return "".join(result)


def _setup_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_plan_report_missing")
        return issues
    if report.get("command") != SETUP_PLAN_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_plan_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_plan_not_pass", report.get("status") or "")
    if not report.get("lean_trusted_import_setup_plan_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_plan_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan_state") or ""
    if state not in {SETUP_PLAN_READY_STATE, SETUP_PLAN_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_plan_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_trusted_import_setup_plan_boundary:{key}")
    return issues


def _proof_source_production_items(setup_report):
    capability_report = setup_report.get("trusted_import_capability_gate_report") or {}
    production_plan = capability_report.get("numeric_semantics_law_proof_source_production_plan_report") or {}
    return list(production_plan.get("proof_source_production_items") or [])


def _lean_identifier(value):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    return "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)


def _candidate_terms(item):
    terms = []
    for key in ["work_item_id", "dispatch_id", "lean_field_name", "required_law"]:
        value = str(item.get(key) or "").strip()
        if value:
            terms.append(value)
    ident = _lean_identifier(item.get("work_item_id") or "")
    if ident:
        terms.append(ident)
    return [term for index, term in enumerate(terms) if term and term not in terms[:index]]


def _lean_files(source_root, candidate_limit):
    root = pathlib.Path(source_root or ".").resolve()
    if not root.exists():
        return []
    files = []
    for path in root.rglob("*.lean"):
        if len(files) >= int(candidate_limit or 0):
            break
        try:
            relative_parts = path.resolve().relative_to(root).parts
        except ValueError:
            relative_parts = path.parts
        if any(part in EXCLUDED_DIR_NAMES for part in relative_parts):
            continue
        if path.is_file():
            files.append(path)
    return files


def _extract_theorem_blocks(text):
    lines = str(text or "").splitlines()
    blocks = []
    for index, line in enumerate(lines):
        match = THEOREM_RE.match(line)
        if not match:
            continue
        end = len(lines)
        for later in range(index + 1, len(lines)):
            if NEXT_DECL_RE.match(lines[later]):
                end = later
                break
        block_text = "\n".join(lines[index:end])
        blocks.append(
            {
                "kind": match.group(1),
                "name": match.group(2),
                "line_start": index + 1,
                "line_end": end,
                "text": block_text,
                "text_sha256": _sha256_text(block_text),
                "placeholder_token_count": len(PLACEHOLDER_RE.findall(block_text)),
                "degenerate_marker_count": len(DEGENERATE_RE.findall(block_text)),
                "numeric_backend_marker_count": len(NUMERIC_BACKEND_RE.findall(block_text)),
            }
        )
    return blocks


def _scan_sources(source_root, candidate_limit):
    candidates = []
    for path in _lean_files(source_root, candidate_limit):
        text = path.read_text(errors="replace")
        source_text = _strip_lean_comments(text)
        theorem_blocks = _extract_theorem_blocks(source_text)
        theorem_names = [item.get("name") for item in theorem_blocks]
        placeholder_count = len(PLACEHOLDER_RE.findall(source_text))
        degenerate_count = len(DEGENERATE_RE.findall(source_text))
        signature_count = len(SIGNATURE_RE.findall(source_text))
        numeric_backend_count = len(NUMERIC_BACKEND_RE.findall(source_text))
        candidates.append(
            {
                "path": str(path),
                "text_sha256": _sha256_text(text),
                "theorem_or_lemma_count": len(theorem_names),
                "theorem_or_lemma_names": theorem_names[:10],
                "placeholder_token_count": placeholder_count,
                "degenerate_marker_count": degenerate_count,
                "signature_only_marker_count": signature_count,
                "numeric_backend_marker_count": numeric_backend_count,
                "text": source_text,
                "_theorem_blocks": theorem_blocks,
            }
        )
    return candidates


def _source_file_summary(candidate):
    return {
        "path": candidate.get("path") or "",
        "text_sha256": candidate.get("text_sha256") or "",
        "theorem_or_lemma_count": candidate.get("theorem_or_lemma_count", 0),
        "placeholder_token_count": candidate.get("placeholder_token_count", 0),
        "degenerate_marker_count": candidate.get("degenerate_marker_count", 0),
        "signature_only_marker_count": candidate.get("signature_only_marker_count", 0),
        "numeric_backend_marker_count": candidate.get("numeric_backend_marker_count", 0),
    }


def _classify_item(item, source_candidates):
    terms = _candidate_terms(item)
    matches = []
    for candidate in source_candidates:
        for theorem_block in candidate.get("_theorem_blocks") or []:
            block_text = theorem_block.get("text") or ""
            matched_terms = [term for term in terms if term and term in block_text]
            if not matched_terms:
                continue
            no_placeholders = theorem_block.get("placeholder_token_count", 0) == 0
            nondegenerate = theorem_block.get("degenerate_marker_count", 0) == 0
            numeric_backend = theorem_block.get("numeric_backend_marker_count", 0) > 0
            ready = bool(no_placeholders and nondegenerate and numeric_backend)
            blockers = []
            if not no_placeholders:
                blockers.append("placeholder_token_present")
            if not nondegenerate:
                blockers.append("degenerate_marker_present")
            if not numeric_backend:
                blockers.append("numeric_backend_marker_missing")
            matches.append(
                {
                    "path": candidate.get("path") or "",
                    "text_sha256": candidate.get("text_sha256") or "",
                    "matched_terms": matched_terms[:5],
                    "matched_theorem_or_lemma_name": theorem_block.get("name") or "",
                    "matched_theorem_or_lemma_kind": theorem_block.get("kind") or "",
                    "line_start": theorem_block.get("line_start") or 0,
                    "line_end": theorem_block.get("line_end") or 0,
                    "theorem_block_text_sha256": theorem_block.get("text_sha256") or "",
                    "theorem_or_lemma_count": 1,
                    "placeholder_token_count": theorem_block.get("placeholder_token_count", 0),
                    "degenerate_marker_count": theorem_block.get("degenerate_marker_count", 0),
                    "numeric_backend_marker_count": theorem_block.get("numeric_backend_marker_count", 0),
                    "local_backend_ready": ready,
                    "blockers": blockers,
                }
            )
    ready = any(match.get("local_backend_ready") for match in matches)
    return {
        "work_item_id": item.get("work_item_id") or "",
        "dispatch_id": item.get("dispatch_id") or "",
        "lean_field_name": item.get("lean_field_name") or "",
        "required_law": item.get("required_law") or "",
        "degenerate_model_allowed": bool(item.get("degenerate_model_allowed")),
        "signature_only_allowed": bool(item.get("signature_only_allowed")),
        "trusted_import_allowed": bool(item.get("trusted_import_allowed")),
        "source_candidate_count": len(matches),
        "local_backend_ready": ready,
        "source_candidates": matches[:5],
        "next_required_action": "wire_local_no_placeholder_law_proof_source" if ready else "produce_non_degenerate_local_numeric_backend_or_complete_trusted_import_setup",
    }


def formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate(
    trusted_import_setup_plan_report=None,
    source_root="",
    candidate_limit=500,
    label="",
):
    setup_report = trusted_import_setup_plan_report or {}
    validation_issues = _setup_plan_issues(setup_report)
    machine_checked = bool(
        setup_report.get("production_claim_machine_checked")
        and setup_report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan_state") == SETUP_PLAN_CLOSED_STATE
    )
    source_candidates = _scan_sources(source_root or ".", candidate_limit)
    proof_items = [] if machine_checked else _proof_source_production_items(setup_report)
    classifications = [] if machine_checked else [_classify_item(item, source_candidates) for item in proof_items]
    ready_count = sum(1 for item in classifications if item.get("local_backend_ready"))
    local_backend_ready = bool(proof_items and ready_count == len(proof_items))
    if proof_items and ready_count < len(proof_items):
        _issue(validation_issues, "local_numeric_backend_required", f"{ready_count}/{len(proof_items)} ready")
    if setup_report.get("lean_mathlib_import_ready") and not setup_report.get("lean_trusted_import_setup_required"):
        _issue(validation_issues, "local_backend_gate_bypassed_by_trusted_import_ready")
    if any(item.get("degenerate_model_allowed") for item in proof_items):
        _issue(validation_issues, "degenerate_model_allowed_by_input_plan")
    if any(item.get("signature_only_allowed") for item in proof_items):
        _issue(validation_issues, "signature_only_allowed_by_input_plan")

    checks = [
        _check("trusted_import_setup_plan_consumable", not _setup_plan_issues(setup_report), "production_claim_lean_numeric_semantics_trusted_import_setup_plan_not_consumable"),
        _check("proof_source_production_items_present_or_closed", machine_checked or bool(proof_items), "proof_source_production_items_missing"),
        _check("local_lean_sources_scanned", machine_checked or bool(source_candidates), "local_lean_sources_missing", severity="readiness"),
        _check("degenerate_model_disallowed", all(not item.get("degenerate_model_allowed") for item in proof_items), "degenerate_model_allowed"),
        _check("signature_only_disallowed", all(not item.get("signature_only_allowed") for item in proof_items), "signature_only_allowed"),
        _check("all_local_backends_ready", machine_checked or local_backend_ready, "local_numeric_backend_required", severity="readiness"),
        _check("no_source_mutation", not setup_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not setup_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "production_claim_lean_numeric_semantics_trusted_import_setup_plan_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif local_backend_ready:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "numeric_semantics_local_law_proof_source_draft"
        next_agent_command = ""
    else:
        status = "PASS"
        state = LOCAL_BACKEND_REQUIRED_STATE
        next_agent_stage = "numeric_semantics_local_backend_or_trusted_import_setup"
        next_agent_command = ""

    local_backend_required = bool(status == "PASS" and state == LOCAL_BACKEND_REQUIRED_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_local_proof_source_feasibility_gate_ready": status == "PASS",
        "lean_local_numeric_backend_ready": bool(status == "PASS" and local_backend_ready),
        "lean_local_numeric_backend_required": local_backend_required,
        "lean_mathlib_import_ready": bool(setup_report.get("lean_mathlib_import_ready")),
        "lean_theorem_draft_ready": False,
        "degenerate_model_allowed": False,
        "signature_only_allowed": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": setup_report.get("claim_packet_id") or "",
        "slug": setup_report.get("slug") or "",
        "trusted_import_setup_plan_report_path": setup_report.get("report_path") or "",
        "trusted_import_setup_plan_report_sha256": setup_report.get("report_sha256") or "",
        "source_root": str(source_root or "."),
        "candidate_limit": int(candidate_limit or 0),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_production_item_count": len(proof_items),
            "local_lean_file_count": len(source_candidates),
            "local_backend_candidate_file_count": sum(item.get("source_candidate_count", 0) for item in classifications),
            "local_backend_ready_count": ready_count,
            "local_backend_gap_count": max(len(proof_items) - ready_count, 0),
            "trusted_import_setup_item_count": len(setup_report.get("trusted_import_setup_items") or []),
            "lean_local_numeric_backend_required_count": 1 if local_backend_required else 0,
            "lean_mathlib_import_ready_count": 1 if setup_report.get("lean_mathlib_import_ready") else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "local_backend_classifications": classifications,
        "local_backend_candidate_files": [_source_file_summary(candidate) for candidate in source_candidates[:20]],
        "proof_source_production_items": proof_items,
        "trusted_import_setup_plan_report": setup_report,
        "boundary": [
            "This command checks feasibility only; it does not author proofs or execute Lean.",
            "Local proof sources must contain theorem/lemma evidence, no placeholder tokens, nondegenerate numeric semantics, and no Unit/True-style shortcuts.",
            "Theorem draft readiness remains false until every law proof source is independently produced and checked.",
            "It does not mutate manuscript source/package/archive state, fetch dependencies, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Local Proof Source Feasibility Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_local_proof_source_feasibility_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Local backend ready: {report.get('lean_local_numeric_backend_ready')}",
        f"- Local backend required: {report.get('lean_local_numeric_backend_required')}",
        f"- Mathlib import ready: {report.get('lean_mathlib_import_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Local Backend Classifications", ""])
    for item in report.get("local_backend_classifications") or []:
        lines.append(
            f"- {item.get('work_item_id')}: ready={item.get('local_backend_ready')} "
            f"candidates={item.get('source_candidate_count')} next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
