"""Gate numeric asymptotic semantics needed after Lean semantic-definition drafts."""

import hashlib
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-refinement-gate"
SEMANTIC_DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-semantic-definition-draft"

SEMANTIC_DRAFT_NUMERIC_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_NUMERIC_SEMANTICS_REQUIRED"
SEMANTIC_DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_READY_FOR_THEOREM_DRAFT"
SEMANTIC_DRAFT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_MACHINE_CHECKED_CLOSED"

NUMERIC_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_NUMERIC_REFINEMENT_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_READY_FOR_THEOREM_DRAFT"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_REFINEMENT_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_refinement_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_refinement_gate_ready",
    "lean_numeric_semantics_refinement_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "semantic_definition_draft_report_path",
    "semantic_definition_draft_report_sha256",
    "lean_source_path",
    "lean_source_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_source_features",
    "numeric_semantics_work_items",
    "semantic_definition_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_backed_definition_draft_count",
    "lean_definition_count",
    "numeric_semantics_work_item_count",
    "nat_proxy_source_count",
    "real_semantics_source_count",
    "sqrt_semantics_source_count",
    "little_o_semantics_source_count",
    "filter_semantics_source_count",
    "high_frequency_split_source_count",
    "lean_numeric_semantics_refinement_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a Lean semantic-definition draft and refuses Nat proxy rate scaffolds as complete numeric semantics.",
    "Reports the missing numeric asymptotic work needed for little-o, square-root scales, and high-frequency rate splits.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _semantic_draft_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_semantic_definition_draft_report_missing")
        return issues
    if report.get("command") != SEMANTIC_DRAFT_COMMAND:
        _issue(issues, "production_claim_lean_semantic_definition_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_semantic_definition_draft_not_pass", report.get("status") or "")
    if not report.get("lean_semantic_definition_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_semantic_definition_draft_not_ready")
    state = report.get("formal_verifier_production_claim_lean_semantic_definition_draft_state") or ""
    if state not in {SEMANTIC_DRAFT_NUMERIC_REQUIRED_STATE, SEMANTIC_DRAFT_READY_STATE, SEMANTIC_DRAFT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_semantic_definition_draft_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_semantic_definition_draft_boundary:{key}")
    return issues


def _resolve_lean_source_path(report, source_root):
    path_text = report.get("lean_source_path") or (report.get("lean_execution") or {}).get("source_path") or ""
    if not path_text:
        return pathlib.Path()
    path = pathlib.Path(path_text)
    if path.is_absolute():
        return path
    return pathlib.Path(source_root or ".") / path


def _lean_source_features(text):
    text = str(text or "")
    real_re = re.compile(r"\b(Real|NNReal|Rat|Float)\b")
    sqrt_re = re.compile(r"\b(sqrt|Sqrt|Nat\.sqrt)\b")
    little_o_re = re.compile(r"\b(IsLittleO|Asymptotics|Tendsto)\b")
    filter_re = re.compile(r"\b(Filter|atTop)\b")
    high_frequency_re = re.compile(r"\b(highFrequency|HighFrequency|DeltaT|driftBlock|diffusionBlock)\b")
    return {
        "source_available": bool(text),
        "nat_proxy_present": "Nat -> Nat" in text,
        "real_semantics_present": bool(real_re.search(text)),
        "sqrt_semantics_present": bool(sqrt_re.search(text)),
        "little_o_semantics_present": bool(little_o_re.search(text)),
        "filter_semantics_present": bool(filter_re.search(text)),
        "high_frequency_split_present": bool(high_frequency_re.search(text)),
        "source_byte_count": len(text.encode()),
    }


def _work_items(features, semantic_report):
    items = []
    drafts = list(semantic_report.get("source_backed_semantic_definition_drafts") or [])
    if features.get("nat_proxy_present") and not features.get("real_semantics_present"):
        items.append(
            {
                "work_item_id": "numeric-semantics-real-rate-scale",
                "kind": "numeric_semantics",
                "required_definition": "replace Nat-valued proxy rate sequences with nonnegative real-valued rate/norm scales",
                "affected_primitives": ["bar_rho_N", "n_2", "Delta_t"],
                "source_backed_definition_draft_count": len(drafts),
            }
        )
    if not features.get("sqrt_semantics_present"):
        items.append(
            {
                "work_item_id": "numeric-semantics-sqrt-inverse-n2-scale",
                "kind": "numeric_semantics",
                "required_definition": "define the square-root comparison scale for n_2^{-1/2} and sqrt(Delta t / n_2)",
                "affected_primitives": ["n_2", "Delta_t", "little_o_rate"],
                "source_backed_definition_draft_count": len(drafts),
            }
        )
    if not features.get("little_o_semantics_present"):
        items.append(
            {
                "work_item_id": "numeric-semantics-little-o-limit",
                "kind": "numeric_semantics",
                "required_definition": "define little-o as a numeric limiting relation rather than a bounded Nat proxy",
                "affected_primitives": ["bar_rho_N", "little_o_rate"],
                "source_backed_definition_draft_count": len(drafts),
            }
        )
    if not features.get("filter_semantics_present"):
        items.append(
            {
                "work_item_id": "numeric-semantics-eventual-filter",
                "kind": "numeric_semantics",
                "required_definition": "bind asymptotic eventuality to a filter/atTop semantics suitable for limits",
                "affected_primitives": ["little_o_rate", "direct_Euler_limit"],
                "source_backed_definition_draft_count": len(drafts),
            }
        )
    if not features.get("high_frequency_split_present"):
        items.append(
            {
                "work_item_id": "numeric-semantics-high-frequency-block-split",
                "kind": "numeric_semantics",
                "required_definition": "define separate drift and diffusion high-frequency block rate targets",
                "affected_primitives": ["drift_block_rate", "diffusion_block_rate", "high_frequency_regime"],
                "source_backed_definition_draft_count": len(drafts),
            }
        )
    items.append(
        {
            "work_item_id": "numeric-semantics-wald-direct-euler-implication",
            "kind": "theorem_semantics",
            "required_definition": "turn manuscript gating language into an implication from numeric bounds to direct Euler/Wald validity",
            "affected_primitives": ["Wald_inference", "direct_Euler_limit"],
            "source_backed_definition_draft_count": len(drafts),
        }
    )
    return items


def formal_verifier_production_claim_lean_numeric_semantics_refinement_gate(
    semantic_definition_draft_report=None,
    source_root="",
    label="",
):
    semantic_report = semantic_definition_draft_report or {}
    validation_issues = _semantic_draft_issues(semantic_report)
    machine_checked = bool(
        semantic_report.get("production_claim_machine_checked")
        and semantic_report.get("formal_verifier_production_claim_lean_semantic_definition_draft_state") == SEMANTIC_DRAFT_CLOSED_STATE
    )
    lean_source_path = _resolve_lean_source_path(semantic_report, source_root)
    lean_source_text = ""
    lean_source_sha = ""
    if lean_source_path and lean_source_path.exists():
        lean_source_text = lean_source_path.read_text(errors="replace")
        lean_source_sha = _sha256_file(lean_source_path)
    elif not machine_checked:
        _issue(validation_issues, "lean_semantic_definition_draft_source_missing", str(lean_source_path or ""))

    features = _lean_source_features(lean_source_text)
    semantic_summary = semantic_report.get("summary") or {}
    syntax_checked = bool(semantic_report.get("lean_exit_code") == 0 or semantic_summary.get("lean_exit_zero_count"))
    work_items = [] if machine_checked else _work_items(features, semantic_report)
    if semantic_report.get("lean_numeric_semantics_required") and not work_items and not machine_checked:
        _issue(validation_issues, "numeric_semantics_required_but_no_work_items")

    checks = [
        _check("semantic_definition_draft_report_consumable", not _semantic_draft_issues(semantic_report), "production_claim_lean_semantic_definition_draft_not_consumable"),
        _check("semantic_definition_draft_lean_syntax_checked", syntax_checked or machine_checked, "lean_semantic_definition_draft_not_syntax_checked"),
        _check("lean_source_available", bool(lean_source_text) or machine_checked, "lean_semantic_definition_draft_source_missing", severity="readiness"),
        _check("numeric_semantics_complete", machine_checked or not work_items, "numeric_semantics_refinement_required", severity="readiness"),
        _check("no_source_mutation", not semantic_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not semantic_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif work_items:
        status = "PASS"
        state = NUMERIC_REQUIRED_STATE
        next_agent_stage = "numeric_asymptotic_semantics_draft"
        next_agent_command = ""
    else:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""

    numeric_required = bool(status == "PASS" and state == NUMERIC_REQUIRED_STATE)
    theorem_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_refinement_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_refinement_gate_ready": status == "PASS",
        "lean_numeric_semantics_refinement_required": numeric_required,
        "lean_theorem_draft_ready": theorem_ready,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": semantic_report.get("claim_packet_id") or "",
        "slug": semantic_report.get("slug") or "",
        "semantic_definition_draft_report_path": semantic_report.get("report_path") or "",
        "semantic_definition_draft_report_sha256": semantic_report.get("report_sha256") or "",
        "lean_source_path": str(lean_source_path or ""),
        "lean_source_sha256": lean_source_sha,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "source_backed_definition_draft_count": semantic_summary.get("source_backed_definition_draft_count", 0),
            "lean_definition_count": semantic_summary.get("lean_definition_count", 0),
            "numeric_semantics_work_item_count": len(work_items),
            "nat_proxy_source_count": 1 if features.get("nat_proxy_present") else 0,
            "real_semantics_source_count": 1 if features.get("real_semantics_present") else 0,
            "sqrt_semantics_source_count": 1 if features.get("sqrt_semantics_present") else 0,
            "little_o_semantics_source_count": 1 if features.get("little_o_semantics_present") else 0,
            "filter_semantics_source_count": 1 if features.get("filter_semantics_present") else 0,
            "high_frequency_split_source_count": 1 if features.get("high_frequency_split_present") else 0,
            "lean_numeric_semantics_refinement_required_count": 1 if numeric_required else 0,
            "lean_theorem_draft_ready_count": 1 if theorem_ready else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_source_features": features,
        "numeric_semantics_work_items": work_items,
        "semantic_definition_draft_report": semantic_report,
        "boundary": [
            "This command refuses Nat-valued proxy rate definitions as complete numeric asymptotic semantics.",
            "The next stage must provide source-backed Lean semantics for real rates, square-root scales, little-o limits, and high-frequency block splits.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_refinement_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Refinement Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_refinement_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Numeric refinement required: {report.get('lean_numeric_semantics_refinement_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Numeric Semantics Work Items", ""])
    for item in report.get("numeric_semantics_work_items") or []:
        lines.append(
            f"- {item.get('work_item_id')}: {item.get('required_definition')} "
            f"affected={','.join(item.get('affected_primitives') or [])}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
