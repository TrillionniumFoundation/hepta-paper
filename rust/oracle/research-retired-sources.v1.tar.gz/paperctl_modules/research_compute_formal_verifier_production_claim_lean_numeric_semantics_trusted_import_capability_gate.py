"""Check trusted-import capability for Lean numeric semantics law proofs."""

import hashlib
import pathlib
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-capability-gate"
SOURCE_PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-law-proof-source-production-plan"

SOURCE_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_PRODUCTION_PLAN_READY"
SOURCE_PLAN_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_LAW_PROOF_SOURCE_PRODUCTION_PLAN_MACHINE_CHECKED_CLOSED"

IMPORT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_IMPORT_SETUP_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_trusted_import_capability_gate_ready",
    "lean_trusted_import_setup_required",
    "lean_mathlib_import_ready",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lake_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "numeric_semantics_law_proof_source_production_plan_report_path",
    "numeric_semantics_law_proof_source_production_plan_report_sha256",
    "source_root",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "lean_project_files",
    "trusted_import_setup_gaps",
    "numeric_semantics_law_proof_source_production_plan_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_source_production_item_count",
    "lean_project_file_count",
    "lean_exit_zero_count",
    "mathlib_import_ready_count",
    "trusted_import_setup_gap_count",
    "lean_trusted_import_setup_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the proof-source production plan and probes local Lean/Mathlib trusted-import capability.",
    "A failed Mathlib import means law proofs need local setup or local source production before theorem drafting.",
    "This command writes a local probe artifact and executes Lean only for import capability; it does not mutate manuscript source, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _source_plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_production_plan_report_missing")
        return issues
    if report.get("command") != SOURCE_PLAN_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_production_plan_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_production_plan_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_law_proof_source_production_plan_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_production_plan_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan_state") or ""
    if state not in {SOURCE_PLAN_READY_STATE, SOURCE_PLAN_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_law_proof_source_production_plan_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_numeric_semantics_law_proof_source_production_plan_boundary:{key}")
    return issues


def _project_files(source_root):
    root = pathlib.Path(source_root or ".").resolve()
    names = ["lakefile.lean", "lakefile.toml", "lean-toolchain", "lake-manifest.json", "leanpkg.toml"]
    files = []
    for name in names:
        path = root / name
        if path.exists():
            files.append({"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size})
    return files


def _probe_source():
    return "\n".join(
        [
            "import Mathlib",
            "",
            "#check Filter.atTop",
            "#check Asymptotics.IsLittleO",
            "#check Real.sqrt",
            "",
        ]
    )


def _lean_command(lean_executable, lean_source_path, lake_executable="", project_root="", project_files=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    cwd = None
    if lake_executable and project_files:
        command = [lake_executable, "env", lean_executable, "--error=warning", str(lean_source_path)]
        cwd = str(pathlib.Path(project_root or ".").resolve())
    return command, cwd


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None, lake_executable="", project_root="", project_files=None):
    command, cwd = _lean_command(
        lean_executable,
        lean_source_path,
        lake_executable=lake_executable,
        project_root=project_root,
        project_files=project_files,
    )
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
        cwd=cwd,
    )


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate(
    numeric_semantics_law_proof_source_production_plan_report=None,
    output_root=None,
    source_root="",
    lean_executable="",
    lake_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    plan_report = numeric_semantics_law_proof_source_production_plan_report or {}
    validation_issues = _source_plan_issues(plan_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(
        plan_report.get("production_claim_machine_checked")
        and plan_report.get("formal_verifier_production_claim_lean_numeric_semantics_law_proof_source_production_plan_state") == SOURCE_PLAN_CLOSED_STATE
    )
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    selected_lake = str(lake_executable or shutil.which("lake") or "")
    source_info = _write_text(output_root / "production-claim-lean-mathlib-import-probe.lean", _probe_source())
    project_files = _project_files(source_root or ".")
    lean_command, _lean_cwd = _lean_command(
        selected_lean,
        source_info["path"],
        lake_executable=selected_lake,
        project_root=source_root or ".",
        project_files=project_files,
    ) if selected_lean else ([], None)
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if selected_lean:
        try:
            result = _run_lean(
                selected_lean,
                source_info["path"],
                timeout_seconds,
                runner=runner,
                lake_executable=selected_lake,
                project_root=source_root or ".",
                project_files=project_files,
            )
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    setup_gaps = []
    if not project_files:
        setup_gaps.append({"gap": "lean_project_files_missing", "required_action": "add or locate lakefile/lean-toolchain for trusted imports"})
    if not selected_lean:
        setup_gaps.append({"gap": "lean_executable_missing", "required_action": "install or locate Lean executable"})
    if not selected_lake:
        setup_gaps.append({"gap": "lake_executable_missing", "required_action": "install or locate Lake executable"})
    if selected_lean and not lean_exit_zero:
        setup_gaps.append({"gap": "mathlib_import_probe_failed", "required_action": "set up Mathlib or provide local trusted proof imports"})
    checks = [
        _check("proof_source_production_plan_consumable", not _source_plan_issues(plan_report), "production_claim_lean_numeric_semantics_law_proof_source_production_plan_not_consumable"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lake_executable_found", bool(selected_lake), "lake_executable_not_found", severity="readiness"),
        _check("lean_project_files_present", bool(project_files), "lean_project_files_missing", severity="readiness"),
        _check("mathlib_import_probe_exit_zero", lean_exit_zero, "mathlib_import_probe_failed", severity="readiness"),
        _check("no_source_mutation", not plan_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not plan_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif setup_gaps:
        status = "PASS"
        state = IMPORT_REQUIRED_STATE
        next_agent_stage = "trusted_import_setup_or_local_law_proof_source"
        next_agent_command = ""
    else:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "numeric_semantics_law_proof_source_draft"
        next_agent_command = ""

    setup_required = bool(status == "PASS" and state == IMPORT_REQUIRED_STATE)
    import_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_trusted_import_capability_gate_ready": status == "PASS",
        "lean_trusted_import_setup_required": setup_required,
        "lean_mathlib_import_ready": import_ready,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "lean_executable_path": selected_lean,
        "lake_executable_path": selected_lake,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": plan_report.get("claim_packet_id") or "",
        "slug": plan_report.get("slug") or "",
        "numeric_semantics_law_proof_source_production_plan_report_path": plan_report.get("report_path") or "",
        "numeric_semantics_law_proof_source_production_plan_report_sha256": plan_report.get("report_sha256") or "",
        "source_root": str(source_root or "."),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_source_production_item_count": len(plan_report.get("proof_source_production_items") or []),
            "lean_project_file_count": len(project_files),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "mathlib_import_ready_count": 1 if import_ready else 0,
            "trusted_import_setup_gap_count": len(setup_gaps),
            "lean_trusted_import_setup_required_count": 1 if setup_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "command": lean_command,
            "executable_path": selected_lean,
            "lake_executable_path": selected_lake,
            "lake_env_used": bool(selected_lake and project_files),
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
        },
        "lean_project_files": project_files,
        "trusted_import_setup_gaps": setup_gaps,
        "numeric_semantics_law_proof_source_production_plan_report": plan_report,
        "boundary": [
            "This command checks trusted-import capability only; it does not prove law obligations.",
            "A Mathlib import probe failure keeps theorem drafting blocked unless local no-placeholder proof sources are produced.",
            "It writes only local probe/report artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Trusted Import Capability Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Mathlib import ready: {report.get('lean_mathlib_import_ready')}",
        f"- Trusted import setup required: {report.get('lean_trusted_import_setup_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Trusted Import Setup Gaps", ""])
    for item in report.get("trusted_import_setup_gaps") or []:
        lines.append(f"- {item.get('gap')}: {item.get('required_action')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
