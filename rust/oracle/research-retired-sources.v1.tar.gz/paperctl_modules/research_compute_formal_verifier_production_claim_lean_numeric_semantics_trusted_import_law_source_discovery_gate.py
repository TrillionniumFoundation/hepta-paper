"""Discover trusted Mathlib import candidates for Lean numeric law items."""

import datetime as dt
import hashlib
import pathlib
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-law-source-discovery-gate"
CAPABILITY_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-capability-gate"

CAPABILITY_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_READY"
CAPABILITY_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_MACHINE_CHECKED_CLOSED"

DOMAIN_THEOREM_BRIDGE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_DOMAIN_THEOREM_BRIDGE_REQUIRED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_LAW_SOURCE_DISCOVERY_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_trusted_import_law_source_discovery_gate_ready",
    "trusted_import_candidates_ready",
    "domain_theorem_bridge_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "trusted_import_capability_gate_report_path",
    "trusted_import_capability_gate_report_sha256",
    "source_root",
    "lean_exit_code",
    "lean_source_path",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "trusted_import_law_source_classifications",
    "lean_execution",
    "trusted_import_capability_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "law_work_item_count",
    "trusted_import_candidate_ready_count",
    "domain_theorem_bridge_gap_count",
    "lean_exit_zero_count",
    "trusted_import_candidates_ready_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a Mathlib-ready trusted-import capability gate and checks candidate imported symbols for numeric law items.",
    "Imported order/inverse/sqrt/filter candidates are not treated as the manuscript theorem proof.",
    "Wald/direct-Euler still requires a source-backed domain theorem bridge unless a specific trusted theorem is discovered.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]

DEFAULT_CANDIDATES = {
    "numeric-laws-rate-scalar-law-structure": ["Preorder", "GroupWithZero", "Filter.atTop", "Asymptotics.IsLittleO", "Real.sqrt"],
    "numeric-laws-order-preorder": ["le_refl", "le_trans"],
    "numeric-laws-inverse-sqrt": ["inv_mul_cancel₀", "Real.sqrt_nonneg", "Real.sq_sqrt"],
    "numeric-laws-filter-at-top-bridge": ["Filter.atTop", "Asymptotics.IsLittleO"],
    "numeric-laws-wald-direct-euler-theorem-bridge": [],
}


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _capability_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_report_missing")
        return issues
    if report.get("command") != CAPABILITY_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_not_pass", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state") or ""
    if state not in {CAPABILITY_READY_STATE, CAPABILITY_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_state_not_ready", state)
    if not report.get("lean_mathlib_import_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "mathlib_import_not_ready")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_trusted_import_capability_gate_boundary:{key}")
    return issues


def _work_items(report):
    plan = report.get("numeric_semantics_law_proof_source_production_plan_report") or {}
    return list(plan.get("proof_source_production_items") or [])


def _probe_source(symbols):
    lines = ["import Mathlib", ""]
    for symbol in symbols:
        lines.append(f"#check {symbol}")
    lines.append("")
    return "\n".join(lines)


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _run_lean(source_root, source_path, timeout_seconds, runner=None):
    command = ["lake", "env", "lean", "--error=warning", str(source_path)]
    if runner:
        return runner(command, str(pathlib.Path(source_root or ".").resolve()), timeout_seconds)
    return subprocess.run(
        command,
        cwd=str(pathlib.Path(source_root or ".").resolve()),
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate(
    trusted_import_capability_gate_report=None,
    source_root="",
    output_root=None,
    timeout_seconds=180,
    label="",
    runner=None,
):
    capability_report = trusted_import_capability_gate_report or {}
    validation_issues = _capability_issues(capability_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(
        capability_report.get("production_claim_machine_checked")
        and capability_report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state") == CAPABILITY_CLOSED_STATE
    )
    work_items = [] if machine_checked else _work_items(capability_report)
    all_symbols = []
    for item in work_items:
        for symbol in DEFAULT_CANDIDATES.get(item.get("work_item_id") or "", []):
            if symbol not in all_symbols:
                all_symbols.append(symbol)
    source_info = _write_text(output_root / "production-claim-lean-trusted-import-law-source-discovery.lean", _probe_source(all_symbols))
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if not validation_issues and not machine_checked:
        try:
            result = _run_lean(source_root or ".", source_info["path"], timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")
    lean_ok = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    classifications = []
    for item in work_items:
        symbols = DEFAULT_CANDIDATES.get(item.get("work_item_id") or "", [])
        domain_gap = not symbols or item.get("work_item_id") == "numeric-laws-wald-direct-euler-theorem-bridge"
        classifications.append(
            {
                "work_item_id": item.get("work_item_id") or "",
                "dispatch_id": item.get("dispatch_id") or "",
                "lean_field_name": item.get("lean_field_name") or "",
                "required_law": item.get("required_law") or "",
                "trusted_import_candidate_symbols": symbols,
                "trusted_import_candidate_ready": bool(symbols and lean_ok and not domain_gap),
                "domain_theorem_bridge_required": domain_gap,
                "next_required_action": "draft_trusted_import_bridge" if symbols and lean_ok and not domain_gap else "produce_source_backed_domain_theorem_bridge",
            }
        )
    ready_count = sum(1 for item in classifications if item.get("trusted_import_candidate_ready"))
    domain_gap_count = sum(1 for item in classifications if item.get("domain_theorem_bridge_required"))
    if work_items and ready_count < len(work_items):
        _issue(validation_issues, "trusted_import_law_sources_incomplete", f"{ready_count}/{len(work_items)} import candidates ready")

    checks = [
        _check("trusted_import_capability_gate_consumable", not _capability_issues(capability_report), "production_claim_lean_numeric_semantics_trusted_import_capability_gate_not_consumable"),
        _check("law_work_items_present_or_closed", machine_checked or bool(work_items), "law_work_items_missing"),
        _check("lean_import_candidate_probe_exit_zero", lean_ok or machine_checked, "lean_import_candidate_probe_failed", severity="readiness"),
        _check("domain_theorem_bridge_not_satisfied_by_numeric_imports", bool(domain_gap_count) or machine_checked, "domain_theorem_bridge_gap_missing"),
        _check("no_source_mutation", not capability_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not capability_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "production_claim_lean_numeric_semantics_trusted_import_capability_gate_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif domain_gap_count:
        status = "PASS"
        state = DOMAIN_THEOREM_BRIDGE_REQUIRED_STATE
        next_agent_stage = "trusted_import_bridge_draft_plus_domain_theorem_bridge"
        next_agent_command = ""
    else:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "trusted_import_bridge_draft"
        next_agent_command = ""

    candidates_ready = bool(status == "PASS" and ready_count and lean_ok)
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_trusted_import_law_source_discovery_gate_ready": status == "PASS",
        "trusted_import_candidates_ready": candidates_ready,
        "domain_theorem_bridge_required": bool(domain_gap_count and status == "PASS"),
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": capability_report.get("claim_packet_id") or "",
        "slug": capability_report.get("slug") or "",
        "trusted_import_capability_gate_report_path": capability_report.get("report_path") or "",
        "trusted_import_capability_gate_report_sha256": capability_report.get("report_sha256") or "",
        "source_root": str(source_root or "."),
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "law_work_item_count": len(work_items),
            "trusted_import_candidate_ready_count": ready_count,
            "domain_theorem_bridge_gap_count": domain_gap_count,
            "lean_exit_zero_count": 1 if lean_ok else 0,
            "trusted_import_candidates_ready_count": 1 if candidates_ready else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "trusted_import_law_source_classifications": classifications,
        "lean_execution": {
            "command": ["lake", "env", "lean", "--error=warning", source_info["path"]],
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
        },
        "trusted_import_capability_gate_report": capability_report,
        "boundary": [
            "This command discovers trusted import candidates only; it does not prove manuscript-specific theorem bridges.",
            "Mathlib numeric/order/filter candidates can support law proofs, but Wald/direct-Euler validity still requires source-backed theorem evidence.",
            "It does not mutate source, fetch dependencies, edit manuscript/package/archive state, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Trusted Import Law Source Discovery Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_trusted_import_law_source_discovery_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Import candidates ready: {report.get('trusted_import_candidates_ready')}",
        f"- Domain theorem bridge required: {report.get('domain_theorem_bridge_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Classifications", ""])
    for item in report.get("trusted_import_law_source_classifications") or []:
        lines.append(
            f"- {item.get('work_item_id')}: ready={item.get('trusted_import_candidate_ready')} "
            f"domain_bridge_required={item.get('domain_theorem_bridge_required')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
