"""Execute trusted-import setup for Lean numeric semantics proofs."""

import hashlib
import pathlib
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-setup-execution"
PREFLIGHT_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-setup-execution-preflight"

PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_PREFLIGHT_READY"
PREFLIGHT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_PREFLIGHT_MACHINE_CHECKED_CLOSED"

MATHLIB_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_MATHLIB_READY"
DEPENDENCY_SETUP_BLOCKED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_DEPENDENCY_SETUP_BLOCKED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_trusted_import_setup_execution_ready",
    "lean_mathlib_import_ready",
    "lean_trusted_import_setup_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "trusted_import_setup_execution_preflight_report_path",
    "trusted_import_setup_execution_preflight_report_sha256",
    "source_root",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "file_mutations",
    "command_executions",
    "lean_project_files_after",
    "mathlib_probe",
    "trusted_import_setup_execution_preflight_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "file_mutation_count",
    "command_execution_count",
    "command_success_count",
    "lean_project_file_after_count",
    "lake_update_exit_zero_count",
    "mathlib_probe_exit_zero_count",
    "mathlib_import_ready_count",
    "trusted_import_setup_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes trusted-import setup execution preflight and performs the selected local Lean project setup.",
    "This command may mutate Lean dependency/project files and perform network dependency resolution, but never edits the manuscript or submits externally.",
    "Mathlib readiness is accepted only after a Lake-environment import probe exits zero.",
]

FORBIDDEN_KEYS = [
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PROJECT_FILE_NAMES = ["lean-toolchain", "lakefile.lean", "lakefile.toml", "lake-manifest.json", "leanpkg.toml"]


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _preflight_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_report_missing")
        return issues
    if report.get("command") != PREFLIGHT_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_trusted_import_setup_execution_preflight_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_state") or ""
    if state not in {PREFLIGHT_READY_STATE, PREFLIGHT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_state_not_consumable", state)
    if not report.get("trusted_import_setup_execution_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "trusted_import_setup_execution_not_ready")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_trusted_import_setup_execution_preflight_boundary:{key}")
    return issues


def _lakefile_content(package_name):
    return "\n".join(
        [
            "import Lake",
            "open Lake DSL",
            "",
            f"package {package_name} where",
            "",
            "require mathlib from git",
            '  "https://github.com/leanprover-community/mathlib4.git" @ "v4.30.0"',
            "",
            "@[default_target]",
            f"lean_lib {package_name} where",
            "",
        ]
    )


def _probe_source():
    return "\n".join(
        [
            "import Mathlib",
            "",
            "#check Filter.atTop",
            "#check Asymptotics.IsLittleO",
            "#check Real.sqrt",
            "#check Inv.inv",
            "",
        ]
    )


def _project_files(source_root):
    root = pathlib.Path(source_root or ".").resolve()
    files = []
    for name in PROJECT_FILE_NAMES:
        path = root / name
        if path.exists():
            files.append({"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size})
    return files


def _write_if_needed(path, content):
    path = pathlib.Path(path)
    before_exists = path.exists()
    before_sha = _sha256_file(path) if before_exists else ""
    before_bytes = path.stat().st_size if before_exists else 0
    if not before_exists:
        path.write_text(content)
        operation = "create"
    elif before_sha != _sha256_text(content):
        path.write_text(content)
        operation = "update"
    else:
        operation = "reuse_existing"
    after_sha = _sha256_file(path) if path.exists() else ""
    after_bytes = path.stat().st_size if path.exists() else 0
    return {
        "path": str(path),
        "operation": operation,
        "before_exists": before_exists,
        "before_sha256": before_sha,
        "before_bytes": before_bytes,
        "after_exists": path.exists(),
        "after_sha256": after_sha,
        "after_bytes": after_bytes,
        "planned_content_sha256": _sha256_text(content),
    }


def _run_command(command, cwd, timeout_seconds, runner=None):
    if runner:
        return runner(command, cwd, timeout_seconds)
    return subprocess.run(
        command,
        cwd=cwd,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def _command_execution(name, command, cwd, timeout_seconds, runner=None):
    try:
        result = _run_command(command, cwd, timeout_seconds, runner=runner)
        return {
            "name": name,
            "command": command,
            "cwd": str(cwd),
            "timeout_seconds": timeout_seconds,
            "exit_code": int(getattr(result, "returncode", 1)),
            "timed_out": False,
            "stdout": str(getattr(result, "stdout", "") or "")[-8000:],
            "stderr": str(getattr(result, "stderr", "") or "")[-8000:],
        }
    except subprocess.TimeoutExpired as exc:
        return {
            "name": name,
            "command": command,
            "cwd": str(cwd),
            "timeout_seconds": timeout_seconds,
            "exit_code": 124,
            "timed_out": True,
            "stdout": str(exc.stdout or "")[-8000:],
            "stderr": str(exc.stderr or "")[-8000:],
        }


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution(
    trusted_import_setup_execution_preflight_report=None,
    source_root="",
    output_root=None,
    package_name="PaperFactoryFormalVerifier",
    timeout_seconds=900,
    skip_cache=True,
    label="",
    runner=None,
):
    preflight_report = trusted_import_setup_execution_preflight_report or {}
    validation_issues = _preflight_issues(preflight_report)
    source_root_path = pathlib.Path(source_root or ".").resolve()
    output_root_path = pathlib.Path(output_root or ".").resolve()
    output_root_path.mkdir(parents=True, exist_ok=True)
    machine_checked = bool(
        preflight_report.get("production_claim_machine_checked")
        and preflight_report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_state") == PREFLIGHT_CLOSED_STATE
    )
    file_mutations = []
    command_executions = []
    probe_info = {}
    execution_performed = False
    source_mutation_performed = False
    network_performed = False
    prover_execution_performed = False

    if not validation_issues and not machine_checked:
        source_root_path.mkdir(parents=True, exist_ok=True)
        toolchain = "leanprover/lean4:v4.30.0"
        for item in preflight_report.get("planned_source_mutations") or []:
            if item.get("path") == "lean-toolchain":
                toolchain = "leanprover/lean4:v4.30.0"
        file_mutations.append(_write_if_needed(source_root_path / "lean-toolchain", f"{toolchain}\n"))
        file_mutations.append(_write_if_needed(source_root_path / "lakefile.lean", _lakefile_content(package_name)))
        source_mutation_performed = any(item.get("operation") in {"create", "update"} for item in file_mutations)

        lake_update = _command_execution("lake_update", ["lake", "update"], source_root_path, timeout_seconds, runner=runner)
        command_executions.append(lake_update)
        execution_performed = True
        network_performed = True
        source_mutation_performed = True

        if not skip_cache and lake_update.get("exit_code") == 0:
            cache_get = _command_execution("lake_exe_cache_get", ["lake", "exe", "cache", "get"], source_root_path, timeout_seconds, runner=runner)
            command_executions.append(cache_get)
            network_performed = True

        probe_path = output_root_path / "production-claim-lean-mathlib-import-probe.lean"
        probe_path.write_text(_probe_source())
        probe_info = {"path": str(probe_path), "sha256": _sha256_file(probe_path), "bytes": probe_path.stat().st_size}
        if lake_update.get("exit_code") == 0:
            probe = _command_execution(
                "lake_env_lean_mathlib_probe",
                ["lake", "env", "lean", "--error=warning", str(probe_path)],
                source_root_path,
                timeout_seconds,
                runner=runner,
            )
            command_executions.append(probe)
            prover_execution_performed = True
        manifest = source_root_path / "lake-manifest.json"
        if manifest.exists():
            file_mutations.append(
                {
                    "path": str(manifest),
                    "operation": "created_or_updated_by_lake_update",
                    "before_exists": False,
                    "before_sha256": "",
                    "before_bytes": 0,
                    "after_exists": True,
                    "after_sha256": _sha256_file(manifest),
                    "after_bytes": manifest.stat().st_size,
                    "planned_content_sha256": "",
                }
            )

    lake_update_zero = any(item.get("name") == "lake_update" and item.get("exit_code") == 0 for item in command_executions)
    probe_zero = any(item.get("name") == "lake_env_lean_mathlib_probe" and item.get("exit_code") == 0 for item in command_executions)
    mathlib_ready = bool(lake_update_zero and probe_zero)
    if command_executions and not mathlib_ready:
        _issue(validation_issues, "trusted_import_setup_execution_incomplete", "lake_update_or_mathlib_probe_failed")

    checks = [
        _check("trusted_import_setup_execution_preflight_consumable", not _preflight_issues(preflight_report), "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_not_consumable"),
        _check("lake_update_exit_zero", lake_update_zero or machine_checked, "lake_update_failed", severity="readiness"),
        _check("lake_env_mathlib_probe_exit_zero", probe_zero or machine_checked, "lake_env_mathlib_probe_failed", severity="readiness"),
        _check("no_external_action", not preflight_report.get("external_action_performed"), "external_action_performed"),
        _check("no_commit", not preflight_report.get("commit_performed"), "commit_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif any(item.get("issue") == "production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_report_missing" for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif mathlib_ready:
        status = "PASS"
        state = MATHLIB_READY_STATE
        next_agent_stage = "trusted_import_capability_reprobe"
        next_agent_command = ""
    else:
        status = "PASS"
        state = DEPENDENCY_SETUP_BLOCKED_STATE
        next_agent_stage = "trusted_import_setup_failure_triage"
        next_agent_command = ""

    setup_required = bool(status == "PASS" and not mathlib_ready and not machine_checked)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": bool(probe_info),
        "execution_performed": execution_performed,
        "prover_execution_performed": prover_execution_performed,
        "network_performed": network_performed,
        "secret_material_read_performed": False,
        "source_mutation_performed": source_mutation_performed,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_trusted_import_setup_execution_ready": status == "PASS",
        "lean_mathlib_import_ready": mathlib_ready,
        "lean_trusted_import_setup_required": setup_required,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": preflight_report.get("claim_packet_id") or "",
        "slug": preflight_report.get("slug") or "",
        "trusted_import_setup_execution_preflight_report_path": preflight_report.get("report_path") or "",
        "trusted_import_setup_execution_preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "source_root": str(source_root_path),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "file_mutation_count": len(file_mutations),
            "command_execution_count": len(command_executions),
            "command_success_count": sum(1 for item in command_executions if item.get("exit_code") == 0),
            "lean_project_file_after_count": len(_project_files(source_root_path)),
            "lake_update_exit_zero_count": 1 if lake_update_zero else 0,
            "mathlib_probe_exit_zero_count": 1 if probe_zero else 0,
            "mathlib_import_ready_count": 1 if mathlib_ready else 0,
            "trusted_import_setup_required_count": 1 if setup_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if prover_execution_performed else 0,
            "network_performed_count": 1 if network_performed else 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 1 if source_mutation_performed else 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "file_mutations": file_mutations,
        "command_executions": command_executions,
        "lean_project_files_after": _project_files(source_root_path),
        "mathlib_probe": probe_info,
        "trusted_import_setup_execution_preflight_report": preflight_report,
        "boundary": [
            "This command may create/update Lean project and dependency files, but it does not edit the manuscript or package archive.",
            "It may perform network dependency resolution through Lake/Git, but it does not upload, email, submit, send Telegram, or commit.",
            "Production theorem readiness remains false until law proofs/imports are separately drafted and checked.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Trusted Import Setup Execution",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Mathlib import ready: {report.get('lean_mathlib_import_ready')}",
        f"- Setup required: {report.get('lean_trusted_import_setup_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Command Executions", ""])
    for item in report.get("command_executions") or []:
        lines.append(f"- {item.get('name')}: exit={item.get('exit_code')} timeout={item.get('timed_out')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
