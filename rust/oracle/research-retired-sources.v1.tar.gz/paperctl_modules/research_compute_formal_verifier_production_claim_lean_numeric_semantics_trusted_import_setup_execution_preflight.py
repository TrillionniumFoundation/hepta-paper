"""Preflight trusted-import setup execution for Lean numeric semantics proofs."""

import hashlib
import pathlib


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-setup-execution-preflight"
ROUTE_SELECTION_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-backend-route-selection-gate"

TRUSTED_IMPORT_RECOMMENDED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_TRUSTED_IMPORT_SETUP_RECOMMENDED"
ROUTE_SELECTION_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_BACKEND_ROUTE_SELECTION_GATE_MACHINE_CHECKED_CLOSED"

PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_PREFLIGHT_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_PREFLIGHT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_PREFLIGHT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_EXECUTION_PREFLIGHT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_numeric_semantics_trusted_import_setup_execution_preflight_ready",
    "trusted_import_setup_execution_ready",
    "source_mutation_required",
    "network_action_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "backend_route_selection_gate_report_path",
    "backend_route_selection_gate_report_sha256",
    "source_root",
    "recommended_backend_route",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "existing_lean_project_files",
    "planned_source_mutations",
    "planned_network_actions",
    "planned_commands",
    "acceptance_probes",
    "rollback_plan",
    "backend_route_selection_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "existing_lean_project_file_count",
    "planned_source_mutation_count",
    "planned_network_action_count",
    "planned_command_count",
    "acceptance_probe_count",
    "rollback_step_count",
    "source_mutation_required_count",
    "network_action_required_count",
    "trusted_import_setup_execution_ready_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes backend route selection and preflights the selected trusted-import setup route.",
    "This preflight plans source/dependency mutations and network actions but performs none of them.",
    "Acceptance requires a Lake-environment Mathlib probe and local dependency provenance before any law item can be satisfied.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PROJECT_FILE_NAMES = ["lean-toolchain", "lakefile.lean", "lakefile.toml", "lake-manifest.json", "leanpkg.toml"]


def _sha256_text(text):
    return hashlib.sha256(str(text or "").encode()).hexdigest()


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _route_selection_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_backend_route_selection_gate_report_missing")
        return issues
    if report.get("command") != ROUTE_SELECTION_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_backend_route_selection_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_backend_route_selection_gate_not_pass", report.get("status") or "")
    if not report.get("lean_numeric_semantics_backend_route_selection_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_backend_route_selection_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate_state") or ""
    if state not in {TRUSTED_IMPORT_RECOMMENDED_STATE, ROUTE_SELECTION_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_backend_route_selection_gate_state_not_trusted_import_route", state)
    if report.get("recommended_backend_route") != "trusted_import_setup_then_law_import" and not report.get("production_claim_machine_checked"):
        _issue(issues, "trusted_import_route_not_selected", report.get("recommended_backend_route") or "")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_backend_route_selection_gate_boundary:{key}")
    return issues


def _project_files(source_root):
    root = pathlib.Path(source_root or ".").resolve()
    files = []
    for name in PROJECT_FILE_NAMES:
        path = root / name
        if path.exists():
            files.append({"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size})
    return files


def _lakefile_content(package_name):
    return "\n".join(
        [
            "import Lake",
            "open Lake DSL",
            "",
            f"package {package_name} where",
            "",
            "require mathlib from git",
            '  "https://github.com/leanprover-community/mathlib4.git" @ "v4.30.0"',
            "",
            '@[default_target]',
            f"lean_lib {package_name} where",
            "",
        ]
    )


def _planned_source_mutations(existing_files, package_name, lean_toolchain):
    existing_by_name = {pathlib.Path(item.get("path") or "").name: item for item in existing_files}
    mutations = []
    content = f"{lean_toolchain}\n"
    content_sha = _sha256_text(content)
    if "lean-toolchain" not in existing_by_name or existing_by_name["lean-toolchain"].get("sha256") != content_sha:
        mutations.append(
            {
                "path": "lean-toolchain",
                "operation": "create" if "lean-toolchain" not in existing_by_name else "update",
                "planned_content_sha256": content_sha,
                "required": True,
            }
        )
    content = _lakefile_content(package_name)
    content_sha = _sha256_text(content)
    if (
        "lakefile.lean" not in existing_by_name
        and "lakefile.toml" not in existing_by_name
    ) or (
        "lakefile.lean" in existing_by_name
        and existing_by_name["lakefile.lean"].get("sha256") != content_sha
    ):
        mutations.append(
            {
                "path": "lakefile.lean",
                "operation": "create" if "lakefile.lean" not in existing_by_name else "update",
                "planned_content_sha256": content_sha,
                "required": True,
            }
        )
    mutations.append(
        {
            "path": "lake-manifest.json",
            "operation": "create_or_update_via_lake_update",
            "planned_content_sha256": "",
            "required": True,
        }
    )
    return mutations


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight(
    backend_route_selection_gate_report=None,
    source_root="",
    package_name="PaperFactoryFormalVerifier",
    lean_toolchain="leanprover/lean4:v4.30.0",
    label="",
):
    route_report = backend_route_selection_gate_report or {}
    validation_issues = _route_selection_issues(route_report)
    source_root = str(source_root or ".")
    existing_files = _project_files(source_root)
    machine_checked = bool(
        route_report.get("production_claim_machine_checked")
        and route_report.get("formal_verifier_production_claim_lean_numeric_semantics_backend_route_selection_gate_state") == ROUTE_SELECTION_CLOSED_STATE
    )
    mutations = [] if machine_checked else _planned_source_mutations(existing_files, package_name, lean_toolchain)
    network_actions = [] if machine_checked else [
        {
            "action": "lake_update_mathlib",
            "command": "lake update",
            "network_required": True,
            "purpose": "resolve and pin Mathlib dependency into lake-manifest.json",
        },
        {
            "action": "optional_mathlib_cache_get",
            "command": "lake exe cache get",
            "network_required": True,
            "purpose": "download trusted build cache for Mathlib after manifest resolution",
        },
    ]
    planned_commands = [] if machine_checked else [
        {"command": "lake update", "cwd": source_root, "mutates": ["lake-manifest.json", ".lake/"], "network_required": True},
        {"command": "lake env lean --error=warning <probe.lean>", "cwd": source_root, "mutates": [], "network_required": False},
    ]
    acceptance = [
        "lean-toolchain and lakefile are present or explicitly reused with recorded hashes.",
        "lake update exits zero and records Mathlib dependency provenance in lake-manifest.json.",
        "Mathlib import probe is executed under Lake environment, not bare lean, and exits zero.",
        "Probe checks Filter.atTop, Asymptotics.IsLittleO, Real.sqrt, inverse/order symbols needed by the law items.",
        "No manuscript, package archive, external submission, upload, email, Telegram send, or commit is performed by setup execution.",
    ]
    rollback = [
        "Remove newly created lean-toolchain if it did not exist before preflight.",
        "Remove newly created lakefile.lean if it did not exist before preflight.",
        "Restore or remove lake-manifest.json according to its preflight existence/hash.",
        "Remove generated .lake/ dependency cache if setup execution fails or is rejected.",
    ]
    checks = [
        _check("backend_route_selection_gate_consumable", not _route_selection_issues(route_report), "production_claim_lean_numeric_semantics_backend_route_selection_gate_not_consumable"),
        _check("trusted_import_route_selected", machine_checked or route_report.get("recommended_backend_route") == "trusted_import_setup_then_law_import", "trusted_import_route_not_selected"),
        _check("planned_source_mutations_present_or_closed", machine_checked or bool(mutations), "planned_source_mutations_missing", severity="readiness"),
        _check("planned_network_actions_present_or_closed", machine_checked or bool(network_actions), "planned_network_actions_missing", severity="readiness"),
        _check("lake_env_probe_required", any("lake env lean" in item.get("command", "") for item in planned_commands) or machine_checked, "lake_env_probe_missing"),
        _check("no_source_mutation_performed", not route_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action_performed", not route_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = PREFLIGHT_READY_STATE
        next_agent_stage = "trusted_import_setup_execution"
        next_agent_command = ""

    source_mutation_required = bool(status == "PASS" and mutations)
    network_required = bool(status == "PASS" and network_actions)
    ready = bool(status == "PASS" and state == PREFLIGHT_READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_numeric_semantics_trusted_import_setup_execution_preflight_ready": status == "PASS",
        "trusted_import_setup_execution_ready": ready,
        "source_mutation_required": source_mutation_required,
        "network_action_required": network_required,
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": route_report.get("claim_packet_id") or "",
        "slug": route_report.get("slug") or "",
        "backend_route_selection_gate_report_path": route_report.get("report_path") or "",
        "backend_route_selection_gate_report_sha256": route_report.get("report_sha256") or "",
        "source_root": source_root,
        "recommended_backend_route": route_report.get("recommended_backend_route") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "existing_lean_project_file_count": len(existing_files),
            "planned_source_mutation_count": len(mutations),
            "planned_network_action_count": len(network_actions),
            "planned_command_count": len(planned_commands),
            "acceptance_probe_count": len(acceptance),
            "rollback_step_count": len(rollback),
            "source_mutation_required_count": 1 if source_mutation_required else 0,
            "network_action_required_count": 1 if network_required else 0,
            "trusted_import_setup_execution_ready_count": 1 if ready else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "existing_lean_project_files": existing_files,
        "planned_source_mutations": mutations,
        "planned_network_actions": network_actions,
        "planned_commands": planned_commands,
        "acceptance_probes": acceptance,
        "rollback_plan": rollback,
        "backend_route_selection_gate_report": route_report,
        "boundary": [
            "This command is preflight only; it does not write lean-toolchain, lakefile, lake-manifest, or dependency cache files.",
            "The next execution step will intentionally require source/dependency mutation and network access, but still no manuscript, package archive, submission, upload, email, Telegram send, or commit.",
            "Mathlib readiness must be re-probed under Lake environment before trusted imports can satisfy law obligations.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Trusted Import Setup Execution Preflight",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_execution_preflight_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Recommended route: {report.get('recommended_backend_route') or ''}",
        f"- Execution ready: {report.get('trusted_import_setup_execution_ready')}",
        f"- Source mutation required: {report.get('source_mutation_required')}",
        f"- Network action required: {report.get('network_action_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Planned Source Mutations", ""])
    for item in report.get("planned_source_mutations") or []:
        lines.append(f"- {item.get('operation')} {item.get('path')}: required={item.get('required')}")
    lines.extend(["", "## Planned Commands", ""])
    for item in report.get("planned_commands") or []:
        lines.append(f"- {item.get('command')} cwd={item.get('cwd')} network={item.get('network_required')}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
