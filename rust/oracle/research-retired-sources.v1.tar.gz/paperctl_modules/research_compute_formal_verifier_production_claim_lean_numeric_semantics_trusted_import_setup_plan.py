"""Plan trusted-import setup for Lean numeric semantics law proofs."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-setup-plan"
CAPABILITY_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-numeric-semantics-trusted-import-capability-gate"

CAPABILITY_IMPORT_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_IMPORT_SETUP_REQUIRED"
CAPABILITY_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_READY"
CAPABILITY_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_CAPABILITY_GATE_MACHINE_CHECKED_CLOSED"

SETUP_PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_PLAN_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_PLAN_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_NUMERIC_SEMANTICS_TRUSTED_IMPORT_SETUP_PLAN_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_trusted_import_setup_plan_ready",
    "lean_trusted_import_setup_required",
    "lean_mathlib_import_ready",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "trusted_import_capability_gate_report_path",
    "trusted_import_capability_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "trusted_import_setup_items",
    "trusted_import_acceptance_criteria",
    "trusted_import_capability_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "trusted_import_setup_gap_count",
    "trusted_import_setup_item_count",
    "manual_setup_item_count",
    "source_mutation_planned_count",
    "network_action_planned_count",
    "acceptance_criterion_count",
    "lean_trusted_import_setup_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes the trusted-import capability gate and plans Lean project/Mathlib setup work.",
    "The plan is report-only: it does not create lakefiles, fetch dependencies, mutate source, or commit.",
    "Theorem drafting remains blocked until setup is actually performed and re-probed.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _capability_gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_report_missing")
        return issues
    if report.get("command") != CAPABILITY_GATE_COMMAND:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_not_pass", report.get("status") or "")
    if not report.get("lean_trusted_import_capability_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state") or ""
    if state not in {CAPABILITY_IMPORT_REQUIRED_STATE, CAPABILITY_READY_STATE, CAPABILITY_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_numeric_semantics_trusted_import_capability_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_trusted_import_capability_gate_boundary:{key}")
    return issues


def _setup_items(report):
    items = []
    for index, gap in enumerate(report.get("trusted_import_setup_gaps") or [], start=1):
        gap_name = gap.get("gap") or f"trusted_import_setup_gap_{index}"
        if gap_name == "lean_project_files_missing":
            required_artifacts = ["lean-toolchain", "lakefile.lean or lakefile.toml", "lake-manifest.json after dependency resolution"]
        elif gap_name == "mathlib_import_probe_failed":
            required_artifacts = ["Mathlib dependency", "successful import Mathlib probe", "local hash/provenance for dependency state"]
        elif gap_name == "lean_executable_missing":
            required_artifacts = ["Lean executable path"]
        elif gap_name == "lake_executable_missing":
            required_artifacts = ["Lake executable path"]
        else:
            required_artifacts = ["documented setup artifact"]
        items.append(
            {
                "setup_item_id": f"trusted-import-setup-{index:04d}",
                "gap": gap_name,
                "required_action": gap.get("required_action") or "",
                "required_artifacts": required_artifacts,
                "manual_review_required": True,
                "source_mutation_planned": False,
                "network_action_planned": False,
                "external_action_planned": False,
                "completion_probe": "rerun trusted-import capability gate and require mathlib_ready=true",
            }
        )
    return items


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan(
    trusted_import_capability_gate_report=None,
    label="",
):
    capability_report = trusted_import_capability_gate_report or {}
    validation_issues = _capability_gate_issues(capability_report)
    machine_checked = bool(
        capability_report.get("production_claim_machine_checked")
        and capability_report.get("formal_verifier_production_claim_lean_numeric_semantics_trusted_import_capability_gate_state") == CAPABILITY_CLOSED_STATE
    )
    items = [] if machine_checked else _setup_items(capability_report)
    if capability_report.get("lean_trusted_import_setup_required") and not items and not machine_checked:
        _issue(validation_issues, "trusted_import_setup_required_but_no_setup_items")
    acceptance = [
        "Lean project files are present and local to the working tree or explicitly referenced.",
        "Mathlib import probe exits zero under the selected Lean toolchain.",
        "Dependency provenance is captured by local file hashes before any trusted import can satisfy a law item.",
        "No manuscript source, package archive, external submission, upload, email, or commit is performed by the plan itself.",
    ]
    checks = [
        _check("trusted_import_capability_gate_report_consumable", not _capability_gate_issues(capability_report), "trusted_import_capability_gate_not_consumable"),
        _check("trusted_import_setup_items_present_or_closed", machine_checked or bool(items), "trusted_import_setup_items_missing"),
        _check("setup_plan_is_report_only", all(not item.get("source_mutation_planned") for item in items), "source_mutation_planned"),
        _check("network_not_planned", all(not item.get("network_action_planned") for item in items), "network_action_planned"),
        _check("no_source_mutation", not capability_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not capability_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues and any(item.get("issue", "").endswith("_report_missing") for item in validation_issues):
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = SETUP_PLAN_READY_STATE
        next_agent_stage = "trusted_import_setup_execution_or_local_law_source_route"
        next_agent_command = ""

    setup_required = bool(status == "PASS" and items)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_trusted_import_setup_plan_ready": status == "PASS",
        "lean_trusted_import_setup_required": setup_required,
        "lean_mathlib_import_ready": bool(capability_report.get("lean_mathlib_import_ready") and not items),
        "lean_theorem_draft_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": capability_report.get("claim_packet_id") or "",
        "slug": capability_report.get("slug") or "",
        "trusted_import_capability_gate_report_path": capability_report.get("report_path") or "",
        "trusted_import_capability_gate_report_sha256": capability_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "trusted_import_setup_gap_count": len(capability_report.get("trusted_import_setup_gaps") or []),
            "trusted_import_setup_item_count": len(items),
            "manual_setup_item_count": sum(1 for item in items if item.get("manual_review_required")),
            "source_mutation_planned_count": sum(1 for item in items if item.get("source_mutation_planned")),
            "network_action_planned_count": sum(1 for item in items if item.get("network_action_planned")),
            "acceptance_criterion_count": len(acceptance),
            "lean_trusted_import_setup_required_count": 1 if setup_required else 0,
            "lean_theorem_draft_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "trusted_import_setup_items": items,
        "trusted_import_acceptance_criteria": acceptance,
        "trusted_import_capability_gate_report": capability_report,
        "boundary": [
            "This command plans trusted-import setup only; it does not create project files or fetch dependencies.",
            "Theorem drafting remains blocked until setup is performed and a capability gate proves Mathlib/import readiness.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Numeric Semantics Trusted Import Setup Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_numeric_semantics_trusted_import_setup_plan_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Setup required: {report.get('lean_trusted_import_setup_required')}",
        f"- Mathlib import ready: {report.get('lean_mathlib_import_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Trusted Import Setup Items", ""])
    for item in report.get("trusted_import_setup_items") or []:
        lines.append(
            f"- {item.get('setup_item_id')}: {item.get('gap')} "
            f"manual={item.get('manual_review_required')} mutation={item.get('source_mutation_planned')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
