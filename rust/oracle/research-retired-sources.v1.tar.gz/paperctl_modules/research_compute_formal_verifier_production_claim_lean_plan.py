"""Plan Lean formalization work for a real theorem/proof claim packet."""

import hashlib
import json
import pathlib

from paperctl_modules import research_compute_formal_verifier_certificate_intake


COMMAND = "research-compute-formal-verifier-production-claim-lean-plan"
EVIDENCE_EXECUTION_COMMAND = "research-compute-claim-evidence-execution"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PLAN_READY"
CERTIFICATE_ACCEPTED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PLAN_CERTIFICATE_ALREADY_ACCEPTED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PLAN_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PLAN_FAILED"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_plan_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_plan_ready",
    "lean_translation_required",
    "production_claim_machine_checked",
    "certificate_intake_accepted",
    "claim_packet_id",
    "slug",
    "source_locator",
    "claim_text_sha256",
    "evidence_execution_report_path",
    "workspace_root",
    "formalization_root",
    "formalization_plan_path",
    "lean_skeleton_path",
    "summary",
    "checks",
    "validation_issues",
    "selected_claim_packet",
    "certificate_intake_report",
    "formalization_plan",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "proof_obligation_count",
    "formalization_work_item_count",
    "artifact_count",
    "lean_translation_required_count",
    "production_claim_machine_checked_count",
    "certificate_intake_accepted_count",
    "local_proof_obligation_fallback_detected_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Reads one real theorem/proof claim evidence-execution report and emits a Lean formalization work plan.",
    "This command does not translate natural-language manuscript claims into a machine proof automatically, execute Lean, mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_merge_performed",
    "commit_performed",
]


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode()).hexdigest()


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _safe_token(value, fallback="claim"):
    text = "".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in str(value or ""))
    text = text.strip(".-_")
    return (text or fallback)[:120]


def _write_json(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2, ensure_ascii=True))
    return {
        "path": str(path),
        "sha256": _sha256_file(path),
        "bytes": path.stat().st_size,
    }


def _write_text(path, payload):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(payload)
    return {
        "path": str(path),
        "sha256": _sha256_file(path),
        "bytes": path.stat().st_size,
    }


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _forbidden_issues(report):
    issues = []
    for key in FORBIDDEN_KEYS:
        if (report or {}).get(key):
            issues.append({"issue": f"forbidden_evidence_execution_boundary:{key}"})
    return issues


def _obligation_name(item, index):
    if isinstance(item, dict):
        value = str(item.get("name") or item.get("id") or "").strip()
    else:
        value = str(item or "").strip()
    return value or f"obligation_{index}"


def _lean_identifier(value, fallback="ProductionClaim"):
    pieces = []
    for chunk in str(value or "").replace("-", "_").replace(".", "_").split("_"):
        clean = "".join(ch for ch in chunk if ch.isalnum())
        if clean:
            pieces.append(clean[:32])
    ident = "".join(part[:1].upper() + part[1:] for part in pieces) or fallback
    if not ident[:1].isalpha():
        ident = fallback + ident
    return ident[:160]


def _formalization_plan(packet, certificate_intake):
    packet = packet or {}
    obligations = list(packet.get("proof_obligations") or [])
    claim_packet_id = packet.get("claim_packet_id") or "production-claim"
    theorem_name = _lean_identifier(claim_packet_id, fallback="ProductionClaimFormalization")
    work_items = []
    for index, obligation in enumerate(obligations, start=1):
        name = _obligation_name(obligation, index)
        description = obligation.get("description") if isinstance(obligation, dict) else ""
        work_items.append(
            {
                "work_item_id": f"lean-obligation-{index:04d}",
                "obligation_name": name,
                "source_locator": (obligation or {}).get("source_locator") if isinstance(obligation, dict) else packet.get("source_locator") or "",
                "description": description or "",
                "lean_task": "translate the manuscript obligation into typed Lean assumptions and a theorem statement",
                "required_before_certificate": True,
                "machine_checked": False,
            }
        )
    return {
        "plan_kind": "production_claim_lean_formalization_plan",
        "claim_packet_id": claim_packet_id,
        "slug": packet.get("slug") or "",
        "source_locator": packet.get("source_locator") or "",
        "claim_text_sha256": _sha256_text(packet.get("claim_text") or ""),
        "proposed_namespace": _lean_identifier(packet.get("slug") or "PaperFactoryProductionClaim"),
        "proposed_theorem_name": theorem_name,
        "proof_obligation_count": len(obligations),
        "work_items": work_items,
        "certificate_intake_status": certificate_intake.get("status") or "",
        "certificate_intake_state": certificate_intake.get("formal_verifier_certificate_intake_state") or "",
        "formal_certificate_verified": bool(certificate_intake.get("formal_certificate_verified")),
        "local_proof_obligation_fallback_detected": bool(certificate_intake.get("local_proof_obligation_fallback_detected")),
        "next_required_agent_actions": [
            "formalize manuscript assumptions as Lean definitions or hypotheses",
            "formalize each proof obligation as a Lean lemma/theorem statement",
            "prove the Lean statements without sorry/admit/axiom placeholders",
            "execute Lean with warnings treated as errors",
            "feed the resulting certificate artifact through research-compute-formal-verifier-certificate-intake",
        ],
        "not_machine_checked_reason": ""
        if certificate_intake.get("formal_certificate_verified")
        else "production claim has local proof-obligation evidence but no verified Lean/Coq/Isabelle certificate artifact",
    }


def _lean_skeleton(packet, plan):
    namespace = plan.get("proposed_namespace") or "PaperFactoryProductionClaim"
    theorem = plan.get("proposed_theorem_name") or "ProductionClaimFormalization"
    lines = [
        "/-",
        "paper_factory production claim Lean formalization skeleton.",
        "",
        "This file is a work item, not a machine-checked certificate.",
        "Do not treat it as proof evidence until the natural-language claim and",
        "all listed obligations are translated into Lean statements and proved",
        "without sorry/admit/axiom placeholders.",
        "",
        f"Claim packet: {packet.get('claim_packet_id') or ''}",
        f"Source locator: {packet.get('source_locator') or ''}",
        f"Claim text sha256: {plan.get('claim_text_sha256') or ''}",
        "-/",
        "",
        f"namespace {namespace}",
        "",
        f"-- Target theorem name: {theorem}",
        "-- Required proof obligations:",
    ]
    for item in plan.get("work_items") or []:
        lines.append(f"-- * {item.get('obligation_name')}: {item.get('description') or ''}")
    lines.extend(
        [
            "",
            "-- Next step: replace this comment-only skeleton with real Lean",
            "-- definitions, hypotheses, theorem statements, and proofs.",
            "",
            f"end {namespace}",
            "",
        ]
    )
    return "\n".join(lines)


def formal_verifier_production_claim_lean_plan(
    evidence_execution_report=None,
    root=".",
    output_root=None,
    label="",
):
    report = evidence_execution_report or {}
    root = pathlib.Path(root)
    output_root = pathlib.Path(output_root or root)
    validation_issues = []
    if not report:
        validation_issues.append({"issue": "claim_evidence_execution_report_missing"})
    elif report.get("command") != EVIDENCE_EXECUTION_COMMAND:
        validation_issues.append({"issue": "claim_evidence_execution_command_mismatch", "detail": report.get("command") or ""})
    if report and report.get("status") != "PASS":
        validation_issues.append({"issue": "claim_evidence_execution_not_pass", "detail": report.get("status") or ""})
    if report and report.get("selected_claim_kind") != "theorem_or_proof":
        validation_issues.append({"issue": "production_claim_lean_plan_requires_theorem_or_proof", "detail": report.get("selected_claim_kind") or ""})
    validation_issues.extend(_forbidden_issues(report))

    packet = dict((report or {}).get("selected_claim_packet") or {})
    if report and not packet:
        validation_issues.append({"issue": "selected_claim_packet_missing"})
    obligations = list(packet.get("proof_obligations") or [])
    if packet and not obligations:
        validation_issues.append({"issue": "proof_obligations_missing"})

    certificate_intake = (
        research_compute_formal_verifier_certificate_intake.formal_verifier_certificate_intake(
            report,
            root=str(root),
            label=label or "",
        )
        if report
        else {}
    )
    certificate_accepted = bool(
        certificate_intake.get("status") == "PASS"
        and certificate_intake.get("formal_certificate_verified")
        and certificate_intake.get("machine_checked_formal_claim_allowed")
    )
    plan = _formalization_plan(packet, certificate_intake) if packet else {}
    slug = _safe_token(packet.get("slug") or "production-claim")
    claim_id = _safe_token(packet.get("claim_packet_id") or "claim")
    artifact_dir = output_root / f"{slug}-{claim_id}-lean-formalization"
    plan_info = {}
    skeleton_info = {}
    if packet and not any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues):
        plan_info = _write_json(artifact_dir / "production-claim-lean-formalization-plan.json", plan)
        skeleton_info = _write_text(artifact_dir / "production-claim-lean-formalization-skeleton.lean", _lean_skeleton(packet, plan))

    checks = [
        _check("evidence_execution_report_present", bool(report), "claim_evidence_execution_report_missing"),
        _check("evidence_execution_report_pass", report.get("status") == "PASS" if report else False, "claim_evidence_execution_not_pass"),
        _check("theorem_or_proof_claim_selected", report.get("selected_claim_kind") == "theorem_or_proof" if report else False, "production_claim_lean_plan_requires_theorem_or_proof"),
        _check("selected_claim_packet_present", bool(packet), "selected_claim_packet_missing"),
        _check("proof_obligations_present", bool(obligations), "proof_obligations_missing"),
        _check("formalization_plan_written", bool(plan_info), "formalization_plan_not_written"),
        _check("lean_skeleton_written", bool(skeleton_info), "lean_skeleton_not_written"),
        _check("no_external_action", not report.get("external_action_performed") if report else True, "external_action_performed"),
        _check("no_source_mutation", not report.get("source_mutation_performed") if report else True, "source_mutation_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    issue_checks = [item for item in checks if item.get("status") != "PASS"]
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
    elif validation_issues or issue_checks:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = CERTIFICATE_ACCEPTED_STATE if certificate_accepted else READY_STATE

    lean_translation_required = bool(not certificate_accepted)
    return {
        "command": COMMAND,
        "status": status,
        "formal_verifier_production_claim_lean_plan_state": state,
        "label": label or "",
        "plan_only": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": bool(plan_info or skeleton_info),
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_plan_ready": status == "PASS",
        "lean_translation_required": lean_translation_required,
        "production_claim_machine_checked": certificate_accepted,
        "certificate_intake_accepted": certificate_accepted,
        "claim_packet_id": packet.get("claim_packet_id") or "",
        "slug": packet.get("slug") or "",
        "source_locator": packet.get("source_locator") or "",
        "claim_text_sha256": _sha256_text(packet.get("claim_text") or "") if packet else "",
        "evidence_execution_report_path": report.get("report_path") or "",
        "workspace_root": str(root),
        "formalization_root": str(artifact_dir) if packet else "",
        "formalization_plan_path": plan_info.get("path") or "",
        "lean_skeleton_path": skeleton_info.get("path") or "",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "proof_obligation_count": len(obligations),
            "formalization_work_item_count": len(plan.get("work_items") or []),
            "artifact_count": int(bool(plan_info)) + int(bool(skeleton_info)),
            "lean_translation_required_count": 1 if lean_translation_required else 0,
            "production_claim_machine_checked_count": 1 if certificate_accepted else 0,
            "certificate_intake_accepted_count": 1 if certificate_accepted else 0,
            "local_proof_obligation_fallback_detected_count": 1 if certificate_intake.get("local_proof_obligation_fallback_detected") else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "selected_claim_packet": packet,
        "certificate_intake_report": certificate_intake,
        "formalization_plan": plan,
        "boundary": [
            "This command turns a real theorem/proof evidence report into a Lean formalization work plan.",
            "It does not claim the production manuscript theorem is machine checked unless certificate intake already accepts a verified certificate artifact.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
            "Natural-language proof obligations must still be translated and proved in Lean before source/submission automation may treat them as machine-checked formal evidence.",
        ],
    }


def formal_verifier_production_claim_lean_plan_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_plan_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Source locator: {report.get('source_locator') or ''}",
        f"- Lean translation required: {report.get('lean_translation_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for item in report.get("checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
