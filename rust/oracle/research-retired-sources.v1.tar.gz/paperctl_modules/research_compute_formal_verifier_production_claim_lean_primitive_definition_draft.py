"""Draft Lean primitive signatures needed before replacing proof placeholders."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-primitive-definition-draft"
GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-proof-replacement-gate"

GATE_PRIMITIVE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_PRIMITIVE_DEFINITION_REQUIRED"
GATE_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_MACHINE_CHECKED_CLOSED"

READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PRIMITIVE_DEFINITION_DRAFT_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PRIMITIVE_DEFINITION_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PRIMITIVE_DEFINITION_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PRIMITIVE_DEFINITION_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_primitive_definition_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_primitive_definition_draft_ready",
    "lean_semantic_definition_required",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "proof_replacement_gate_report_path",
    "proof_replacement_gate_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "primitive_signature_fields",
    "proof_replacement_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "primitive_gap_count",
    "primitive_signature_field_count",
    "lean_structure_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "lean_semantic_definition_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a proof-replacement gate report and drafts Lean primitive signatures for missing manuscript primitives.",
    "The draft intentionally creates signatures only; it does not prove the production theorem or certify manuscript semantics.",
    "This command writes local draft artifacts and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
STRUCTURE_RE = re.compile(r"^\s*structure\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_proof_replacement_gate_report_missing")
        return issues
    if report.get("command") != GATE_COMMAND:
        _issue(issues, "production_claim_lean_proof_replacement_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_proof_replacement_gate_not_pass", report.get("status") or "")
    if not report.get("lean_proof_replacement_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_proof_replacement_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_proof_replacement_gate_state") or ""
    if state not in {GATE_PRIMITIVE_REQUIRED_STATE, GATE_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_proof_replacement_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_proof_replacement_gate_boundary:{key}")
    return issues


def _lean_identifier(value, fallback="Primitive"):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    ident = "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)
    if not ident or not ident[0].isalpha():
        ident = fallback
    return ident[:120]


def _lean_field_name(value, fallback="primitive"):
    ident = _lean_identifier(value, fallback.capitalize())
    return ident[:1].lower() + ident[1:]


def _primitive_fields(report):
    fields = []
    seen = set()
    for item in report.get("primitive_definition_gaps") or []:
        primitive = str(item.get("primitive") or "").strip()
        if not primitive or primitive in seen:
            continue
        seen.add(primitive)
        required = item.get("required_definition") or "formal primitive definition"
        field_name = _lean_field_name(primitive)
        field_type = "Type" if primitive in {"bar_rho_N", "n_2", "Delta_t"} else "Prop"
        fields.append(
            {
                "primitive": primitive,
                "lean_field_name": field_name,
                "lean_field_type": field_type,
                "required_definition": required,
                "source_locator": item.get("source_locator") or "",
                "work_item_id": item.get("work_item_id") or "",
            }
        )
    return fields


def _lean_source(report, fields):
    namespace = _lean_identifier(report.get("slug") or "ProductionClaim", "ProductionClaimFormalization")
    lines = [
        "/-",
        "paper_factory production claim Lean primitive-definition draft.",
        "This file only declares a typed signature for manuscript primitives.",
        "It is not a proof of the production claim.",
        "-/",
        "",
        f"namespace {namespace}",
        "",
        "structure ProductionClaimPrimitiveSignature where",
    ]
    if fields:
        for item in fields:
            lines.extend(
                [
                    f"  /-- {item['primitive']}: {item['required_definition']} -/",
                    f"  {item['lean_field_name']} : {item['lean_field_type']}",
                ]
            )
    else:
        lines.append("  noMissingPrimitives : True")
    lines.extend(
        [
            "",
            "/-",
            "The next stage must replace these signature slots with semantic definitions",
            "and then prove the candidate statement without placeholder or",
            "assumption-echo shortcuts.",
            "-/",
            "",
            f"end {namespace}",
            "",
        ]
    )
    return "\n".join(lines)


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_production_claim_lean_primitive_definition_draft(
    proof_replacement_gate_report=None,
    output_root=None,
    lean_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    gate_report = proof_replacement_gate_report or {}
    validation_issues = _gate_issues(gate_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(
        gate_report.get("production_claim_machine_checked")
        and gate_report.get("formal_verifier_production_claim_lean_proof_replacement_gate_state") == GATE_CLOSED_STATE
    )
    fields = _primitive_fields(gate_report)
    lean_source_text = _lean_source(gate_report, fields)
    source_info = _write_text(output_root / "production-claim-lean-primitive-definition-draft.lean", lean_source_text)
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if selected_lean:
        try:
            result = _run_lean(selected_lean, source_info["path"], timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    structures = STRUCTURE_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    checks = [
        _check("proof_replacement_gate_report_consumable", not _gate_issues(gate_report), "production_claim_lean_proof_replacement_gate_not_consumable"),
        _check("primitive_gaps_present_or_closed", machine_checked or bool(fields), "primitive_definition_gaps_missing"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("lean_structure_present", bool(structures), "lean_structure_missing"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("no_source_mutation", not gate_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not gate_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif lean_exit_zero and structures and fields and not placeholders:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "semantic_primitive_definition_materialization"
        next_agent_command = ""
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    semantic_required = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_primitive_definition_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_primitive_definition_draft_ready": status == "PASS",
        "lean_semantic_definition_required": semantic_required,
        "production_claim_machine_checked": machine_checked,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": gate_report.get("claim_packet_id") or "",
        "slug": gate_report.get("slug") or "",
        "proof_replacement_gate_report_path": gate_report.get("report_path") or "",
        "proof_replacement_gate_report_sha256": gate_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "primitive_gap_count": len(gate_report.get("primitive_definition_gaps") or []),
            "primitive_signature_field_count": len(fields),
            "lean_structure_count": len(structures),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "lean_semantic_definition_required_count": 1 if semantic_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "structure_names": structures,
            "placeholder_token_count": len(placeholders),
        },
        "primitive_signature_fields": fields,
        "proof_replacement_gate_report": gate_report,
        "boundary": [
            "This command drafts a Lean primitive signature only; it does not prove the production claim.",
            "A syntax-valid primitive signature is not a semantic formalization of the manuscript statement.",
            "The next stage must supply semantic definitions and a no-placeholder proof before any machine-checked claim can be counted.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_primitive_definition_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Primitive Definition Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_primitive_definition_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Semantic definition required: {report.get('lean_semantic_definition_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Primitive Signature Fields", ""])
    for item in report.get("primitive_signature_fields") or []:
        lines.append(
            f"- {item.get('primitive')}: {item.get('lean_field_name')} : {item.get('lean_field_type')} "
            f"({item.get('required_definition') or ''})".rstrip()
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
