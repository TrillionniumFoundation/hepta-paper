"""Gate whether a Lean declaration draft can receive a real proof replacement."""

import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-proof-replacement-gate"
DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-declaration-draft"

DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_DECLARATION_DRAFT_PLACEHOLDER_REQUIRED"
DRAFT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_DECLARATION_DRAFT_MACHINE_CHECKED_CLOSED"

CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_MACHINE_CHECKED_CLOSED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_READY_FOR_NO_PLACEHOLDER_PROOF"
PRIMITIVE_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_PRIMITIVE_DEFINITION_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PROOF_REPLACEMENT_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_proof_replacement_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_proof_replacement_gate_ready",
    "lean_proof_replacement_ready",
    "lean_primitive_definition_required",
    "assumption_echo_proof_rejected",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "declaration_draft_report_path",
    "declaration_draft_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "primitive_definition_gaps",
    "candidate_statement_classifications",
    "declaration_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "candidate_statement_count",
    "lean_declaration_count",
    "placeholder_token_count",
    "primitive_reference_count",
    "missing_primitive_definition_count",
    "assumption_echo_risk_count",
    "lean_proof_replacement_ready_count",
    "lean_primitive_definition_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a Lean declaration draft and decides whether placeholder replacement can be a real proof attempt.",
    "A no-placeholder theorem that merely assumes the manuscript conclusion is rejected as an assumption-echo proof.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PRIMITIVE_PATTERNS = [
    ("bar_rho_N", re.compile(r"(?:bar[_-]?rho[_-]?N|\\bar\{?\\rho\}?_?\{?N\}?)", re.I), "calibration-error bound sequence"),
    ("n_2", re.compile(r"(?:n_2|n\{?2\}?|n\s*[_^])", re.I), "second-stage sample-size scale"),
    ("Delta_t", re.compile(r"(?:Delta\s*t|\\Delta\s*t|fixed\s+Delta)", re.I), "sampling mesh or fixed-time-step regime"),
    ("little_o_rate", re.compile(r"(?:o\s*\(|little[- ]?o)", re.I), "asymptotic rate relation"),
    ("drift_block_rate", re.compile(r"drift[^.;,]*block[^.;,]*rate|block[^.;,]*drift[^.;,]*rate", re.I), "high-frequency drift block rate"),
    ("diffusion_block_rate", re.compile(r"diffusion[^.;,]*block[^.;,]*rate|block[^.;,]*diffusion[^.;,]*rate", re.I), "high-frequency diffusion block rate"),
    ("high_frequency_regime", re.compile(r"high[- ]frequency", re.I), "high-frequency asymptotic regime"),
    ("Wald_inference", re.compile(r"Wald\s+inference", re.I), "Wald inference validity predicate"),
    ("direct_Euler_limit", re.compile(r"direct\s+Euler\s+limit", re.I), "direct Euler limit theorem target"),
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _draft_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_declaration_draft_report_missing")
        return issues
    if report.get("command") != DRAFT_COMMAND:
        _issue(issues, "production_claim_lean_declaration_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_declaration_draft_not_pass", report.get("status") or "")
    if not report.get("lean_declaration_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_declaration_draft_not_ready")
    state = report.get("formal_verifier_production_claim_lean_declaration_draft_state") or ""
    if state not in {DRAFT_READY_STATE, DRAFT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_declaration_draft_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_declaration_draft_boundary:{key}")
    return issues


def _primitive_definitions(candidate):
    definitions = {}
    for item in candidate.get("formal_primitive_definitions") or candidate.get("lean_primitive_definitions") or []:
        if not isinstance(item, dict):
            continue
        name = str(item.get("primitive") or item.get("name") or "").strip()
        if not name:
            continue
        definitions[name] = bool(
            item.get("definition_available")
            or item.get("lean_definition")
            or item.get("formal_definition")
        )
    return definitions


def _primitive_references(candidate):
    text = str(candidate.get("candidate_statement_text") or "")
    definitions = _primitive_definitions(candidate)
    refs = []
    for primitive, pattern, required_definition in PRIMITIVE_PATTERNS:
        if pattern.search(text):
            refs.append(
                {
                    "primitive": primitive,
                    "required_definition": required_definition,
                    "definition_available": bool(definitions.get(primitive)),
                    "source_locator": candidate.get("source_locator") or "",
                    "work_item_id": candidate.get("work_item_id") or "",
                }
            )
    return refs


def _assumption_echo_risk(candidate, placeholder_count):
    text = str(candidate.get("candidate_statement_text") or "").lower()
    modal_claim = any(marker in text for marker in ["only when", "may ", "wald inference", "direct euler limit"])
    no_structured_statement = not (
        candidate.get("lean_statement")
        or candidate.get("formal_statement")
        or candidate.get("formal_primitive_definitions")
        or candidate.get("lean_primitive_definitions")
    )
    return bool(placeholder_count or (modal_claim and no_structured_statement))


def _classify_candidate(candidate, placeholder_count):
    primitive_refs = _primitive_references(candidate or {})
    missing = [item for item in primitive_refs if not item["definition_available"]]
    assumption_echo_risk = _assumption_echo_risk(candidate or {}, placeholder_count)
    return {
        "work_item_id": (candidate or {}).get("work_item_id") or "",
        "source_locator": (candidate or {}).get("source_locator") or "",
        "candidate_statement_sha256": (candidate or {}).get("candidate_statement_sha256") or "",
        "primitive_reference_count": len(primitive_refs),
        "missing_primitive_definition_count": len(missing),
        "assumption_echo_risk": assumption_echo_risk,
        "proof_replacement_ready": bool(not missing and not assumption_echo_risk and placeholder_count == 0),
        "next_required_action": "formalize_primitives_before_proof_replacement"
        if missing or assumption_echo_risk or placeholder_count
        else "run_no_placeholder_proof_attempt",
        "primitive_references": primitive_refs,
    }


def formal_verifier_production_claim_lean_proof_replacement_gate(
    declaration_draft_report=None,
    label="",
):
    draft_report = declaration_draft_report or {}
    validation_issues = _draft_issues(draft_report)
    summary = draft_report.get("summary") or {}
    candidate_statements = list(draft_report.get("candidate_statements") or [])
    placeholder_count = int(summary.get("placeholder_token_count") or 0)
    declaration_count = int(summary.get("lean_declaration_count") or 0)
    machine_checked = bool(
        draft_report.get("production_claim_machine_checked")
        and draft_report.get("formal_verifier_production_claim_lean_declaration_draft_state") == DRAFT_CLOSED_STATE
    )
    classifications = [_classify_candidate(candidate, placeholder_count) for candidate in candidate_statements]
    primitive_gaps = []
    for item in classifications:
        primitive_gaps.extend([ref for ref in item.get("primitive_references") or [] if not ref.get("definition_available")])
    assumption_echo_risk = any(item.get("assumption_echo_risk") for item in classifications)
    replacement_ready = bool(
        not validation_issues
        and not machine_checked
        and declaration_count
        and candidate_statements
        and placeholder_count == 0
        and not primitive_gaps
        and not assumption_echo_risk
    )
    primitive_required = bool(
        not validation_issues
        and not machine_checked
        and (placeholder_count > 0 or primitive_gaps or assumption_echo_risk)
    )

    checks = [
        _check("declaration_draft_report_consumable", not _draft_issues(draft_report), "production_claim_lean_declaration_draft_not_consumable"),
        _check("lean_declarations_present", bool(declaration_count) or machine_checked, "lean_declarations_missing"),
        _check("placeholder_tokens_absent_for_replacement", placeholder_count == 0 or machine_checked, "placeholder_tokens_present", severity="readiness"),
        _check("primitive_definitions_available", not primitive_gaps or machine_checked, "lean_primitive_definitions_missing", severity="readiness"),
        _check("no_assumption_echo_proof", not assumption_echo_risk or machine_checked, "assumption_echo_proof_rejected", severity="readiness"),
        _check("no_source_mutation", not draft_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not draft_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif replacement_ready:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "no_placeholder_lean_proof_attempt"
        next_agent_command = "research-compute-formal-verifier-production-claim-lean-execution-attempt"
    else:
        status = "PASS"
        state = PRIMITIVE_REQUIRED_STATE
        next_agent_stage = "lean_primitive_definition_draft"
        next_agent_command = ""

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_proof_replacement_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_proof_replacement_gate_ready": status == "PASS",
        "lean_proof_replacement_ready": bool(status == "PASS" and state == READY_STATE),
        "lean_primitive_definition_required": bool(status == "PASS" and state == PRIMITIVE_REQUIRED_STATE),
        "assumption_echo_proof_rejected": bool(status == "PASS" and not machine_checked and assumption_echo_risk),
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": draft_report.get("claim_packet_id") or "",
        "slug": draft_report.get("slug") or "",
        "declaration_draft_report_path": draft_report.get("report_path") or "",
        "declaration_draft_report_sha256": draft_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "candidate_statement_count": len(candidate_statements),
            "lean_declaration_count": declaration_count,
            "placeholder_token_count": placeholder_count,
            "primitive_reference_count": sum(item.get("primitive_reference_count", 0) for item in classifications),
            "missing_primitive_definition_count": len(primitive_gaps),
            "assumption_echo_risk_count": 1 if assumption_echo_risk else 0,
            "lean_proof_replacement_ready_count": 1 if status == "PASS" and state == READY_STATE else 0,
            "lean_primitive_definition_required_count": 1 if status == "PASS" and state == PRIMITIVE_REQUIRED_STATE else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "primitive_definition_gaps": primitive_gaps,
        "candidate_statement_classifications": classifications,
        "declaration_draft_report": draft_report,
        "boundary": [
            "This command does not convert an axiom draft into a proof certificate.",
            "A proof replacement is blocked until every manuscript primitive in the candidate statement has an explicit formal Lean definition.",
            "A theorem proved only by assuming the candidate statement is rejected as an assumption-echo proof, even if Lean would accept it.",
            "It writes only a local report and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_proof_replacement_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Proof Replacement Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_proof_replacement_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Proof replacement ready: {report.get('lean_proof_replacement_ready')}",
        f"- Primitive definition required: {report.get('lean_primitive_definition_required')}",
        f"- Assumption-echo proof rejected: {report.get('assumption_echo_proof_rejected')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Candidate Statements", ""])
    for item in report.get("candidate_statement_classifications") or []:
        lines.append(
            f"- {item.get('work_item_id')}: primitives={item.get('primitive_reference_count')} "
            f"missing={item.get('missing_primitive_definition_count')} "
            f"assumption_echo={item.get('assumption_echo_risk')} next={item.get('next_required_action')}"
        )
    if report.get("primitive_definition_gaps"):
        lines.extend(["", "## Primitive Definition Gaps", ""])
        for item in report.get("primitive_definition_gaps") or []:
            lines.append(
                f"- {item.get('primitive')}: {item.get('required_definition')} "
                f"({item.get('source_locator') or item.get('work_item_id') or ''})".rstrip()
            )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
