"""Draft source-backed Lean semantic definitions for production-claim primitives."""

import hashlib
import pathlib
import re
import shutil
import subprocess


COMMAND = "research-compute-formal-verifier-production-claim-lean-semantic-definition-draft"
SOURCE_CONTEXT_COMMAND = "research-compute-formal-verifier-production-claim-lean-semantic-source-context-extraction"

SOURCE_CONTEXT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_SOURCE_CONTEXT_EXTRACTION_DEFINITION_DRAFT_REQUIRED"
SOURCE_CONTEXT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_SOURCE_CONTEXT_EXTRACTION_MACHINE_CHECKED_CLOSED"

READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_READY_FOR_THEOREM_DRAFT"
NUMERIC_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_NUMERIC_SEMANTICS_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_DRAFT_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_semantic_definition_draft_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_semantic_definition_draft_ready",
    "lean_semantic_definition_proxy_only",
    "lean_numeric_semantics_required",
    "lean_theorem_draft_ready",
    "production_claim_machine_checked",
    "lean_executable_path",
    "lean_exit_code",
    "lean_source_path",
    "claim_packet_id",
    "slug",
    "semantic_source_context_extraction_report_path",
    "semantic_source_context_extraction_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "lean_execution",
    "source_backed_semantic_definition_drafts",
    "semantic_source_context_extraction_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "semantic_definition_candidate_count",
    "source_backed_definition_draft_count",
    "numeric_semantics_complete_count",
    "lean_definition_count",
    "placeholder_token_count",
    "lean_exit_zero_count",
    "lean_numeric_semantics_required_count",
    "lean_theorem_draft_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes source-context extraction and drafts Lean definitions tied to manuscript primitive mentions.",
    "The generated definitions are source-backed proxy scaffolds; they do not complete numeric asymptotic semantics.",
    "This command writes local draft artifacts, syntax-checks Lean, and does not mutate manuscript source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PLACEHOLDER_RE = re.compile(r"\b(sorry|admit|axiom|opaque)\b", re.I)
DEFINITION_RE = re.compile(r"^\s*def\s+([A-Za-z_][A-Za-z0-9_']*)\b", re.M)

PRIMITIVE_DEFINITION_NAMES = {
    "bar_rho_N": "BarRhoNDefinition",
    "n_2": "N2Definition",
    "Delta_t": "DeltaTDefinition",
    "little_o_rate": "LittleORateDefinition",
    "drift_block_rate": "DriftBlockRateDefinition",
    "diffusion_block_rate": "DiffusionBlockRateDefinition",
    "high_frequency_regime": "HighFrequencyRegimeDefinition",
    "Wald_inference": "WaldInferenceDefinition",
    "direct_Euler_limit": "DirectEulerLimitDefinition",
}


def _sha256_file(path):
    h = hashlib.sha256()
    with pathlib.Path(path).open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _write_text(path, text):
    path = pathlib.Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return {"path": str(path), "sha256": _sha256_file(path), "bytes": path.stat().st_size}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _source_context_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_semantic_source_context_extraction_report_missing")
        return issues
    if report.get("command") != SOURCE_CONTEXT_COMMAND:
        _issue(issues, "production_claim_lean_semantic_source_context_extraction_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_semantic_source_context_extraction_not_pass", report.get("status") or "")
    if not report.get("lean_semantic_source_context_extraction_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_semantic_source_context_extraction_not_ready")
    state = report.get("formal_verifier_production_claim_lean_semantic_source_context_extraction_state") or ""
    if state not in {SOURCE_CONTEXT_READY_STATE, SOURCE_CONTEXT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_semantic_source_context_extraction_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_semantic_source_context_extraction_boundary:{key}")
    return issues


def _lean_identifier(value, fallback="ProductionClaimFormalization"):
    chunks = re.split(r"[^A-Za-z0-9]+", str(value or ""))
    ident = "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)
    if not ident or not ident[0].isalpha():
        ident = fallback
    return ident[:120]


def _definition_name(primitive):
    return PRIMITIVE_DEFINITION_NAMES.get(primitive) or (_lean_identifier(primitive, "Primitive") + "Definition")


def _definition_drafts(report):
    drafts = []
    seen = set()
    for item in report.get("semantic_gap_source_classifications") or []:
        primitive = str(item.get("primitive") or "").strip()
        if not primitive or primitive in seen:
            continue
        seen.add(primitive)
        candidate_available = bool(item.get("semantic_definition_candidate_available"))
        drafts.append(
            {
                "primitive": primitive,
                "lean_definition_name": _definition_name(primitive),
                "lean_field_name": item.get("lean_field_name") or "",
                "required_definition": item.get("required_definition") or "",
                "source_locator": item.get("source_locator") or "",
                "source_mention_count": int(item.get("source_mention_count") or 0),
                "source_context_available": bool(item.get("source_context_available")),
                "source_backed_definition_draft_available": candidate_available,
                "lean_numeric_semantics_complete": False,
                "lean_theorem_draft_ready": False,
                "next_required_action": "replace_proxy_rate_semantics_with_numeric_asymptotic_semantics"
                if candidate_available
                else "locate_source_context_before_definition_draft",
            }
        )
    return drafts


def _lean_source(report, drafts):
    namespace = _lean_identifier(report.get("slug") or "ProductionClaim", "ProductionClaimFormalization")
    lines = [
        "/-",
        "paper_factory production claim Lean semantic-definition draft.",
        "The definitions below are tied to manuscript source-context candidates.",
        "They are proxy rate semantics and do not certify the production claim.",
        "-/",
        "",
        f"namespace {namespace}",
        "",
        "structure ManuscriptRateInputs where",
        "  barRhoN : Nat -> Nat",
        "  n2 : Nat -> Nat",
        "  deltaT : Nat -> Nat",
        "  driftBlockError : Nat -> Nat",
        "  diffusionBlockError : Nat -> Nat",
        "",
        "def Eventually (P : Nat -> Prop) : Prop :=",
        "  Exists (fun N0 : Nat => forall N : Nat, N0 <= N -> P N)",
        "",
        "def StrictlyBelowScale (x scale : Nat -> Nat) : Prop :=",
        "  forall c : Nat, 0 < c -> Eventually (fun N => c * (x N) <= scale N)",
        "",
        "def FixedStep (deltaT : Nat -> Nat) : Prop :=",
        "  Exists (fun d : Nat => Eventually (fun N => deltaT N = d))",
        "",
        "def BarRhoNDefinition (input : ManuscriptRateInputs) : Nat -> Nat :=",
        "  input.barRhoN",
        "",
        "def N2Definition (input : ManuscriptRateInputs) : Nat -> Nat :=",
        "  input.n2",
        "",
        "def DeltaTDefinition (input : ManuscriptRateInputs) : Nat -> Nat :=",
        "  input.deltaT",
        "",
        "def LittleORateDefinition (x scale : Nat -> Nat) : Prop :=",
        "  StrictlyBelowScale x scale",
        "",
        "def DriftBlockRateDefinition (input : ManuscriptRateInputs) : Prop :=",
        "  StrictlyBelowScale input.driftBlockError input.n2",
        "",
        "def DiffusionBlockRateDefinition (input : ManuscriptRateInputs) : Prop :=",
        "  StrictlyBelowScale input.diffusionBlockError input.n2",
        "",
        "def HighFrequencyRegimeDefinition (input : ManuscriptRateInputs) : Prop :=",
        "  And (DriftBlockRateDefinition input) (DiffusionBlockRateDefinition input)",
        "",
        "def DirectEulerLimitDefinition (input : ManuscriptRateInputs) : Prop :=",
        "  Or",
        "    (And (FixedStep input.deltaT) (LittleORateDefinition input.barRhoN input.n2))",
        "    (HighFrequencyRegimeDefinition input)",
        "",
        "def WaldInferenceDefinition (input : ManuscriptRateInputs) : Prop :=",
        "  DirectEulerLimitDefinition input",
        "",
        "def ProductionClaimSemanticDraft (input : ManuscriptRateInputs) : Prop :=",
        "  WaldInferenceDefinition input",
        "",
    ]
    lines.extend(
        [
            "/- Source-backed primitive draft index.",
            "Each listed primitive had at least one local source-context candidate.",
            "The next stage must refine Nat-valued proxy rates into the numeric",
            "asymptotic semantics required by the manuscript.",
        ]
    )
    for item in drafts:
        marker = "candidate" if item.get("source_backed_definition_draft_available") else "missing"
        lines.append(
            f"{item.get('primitive')}: {item.get('lean_definition_name')} [{marker}] "
            f"mentions={item.get('source_mention_count')} source={item.get('source_locator')}"
        )
    lines.extend(["-/", "", f"end {namespace}", ""])
    return "\n".join(lines)


def _run_lean(lean_executable, lean_source_path, timeout_seconds, runner=None):
    command = [lean_executable, "--error=warning", str(lean_source_path)]
    if runner:
        return runner(command, timeout_seconds)
    return subprocess.run(
        command,
        check=False,
        text=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout_seconds,
    )


def formal_verifier_production_claim_lean_semantic_definition_draft(
    semantic_source_context_extraction_report=None,
    output_root=None,
    lean_executable="",
    timeout_seconds=180,
    label="",
    runner=None,
):
    source_report = semantic_source_context_extraction_report or {}
    validation_issues = _source_context_issues(source_report)
    output_root = pathlib.Path(output_root or ".").resolve()
    machine_checked = bool(
        source_report.get("production_claim_machine_checked")
        and source_report.get("formal_verifier_production_claim_lean_semantic_source_context_extraction_state") == SOURCE_CONTEXT_CLOSED_STATE
    )
    drafts = _definition_drafts(source_report)
    candidate_count = sum(1 for item in drafts if item.get("source_backed_definition_draft_available"))
    numeric_complete_count = sum(1 for item in drafts if item.get("lean_numeric_semantics_complete"))
    lean_source_text = _lean_source(source_report, drafts)
    source_info = _write_text(output_root / "production-claim-lean-semantic-definition-draft.lean", lean_source_text)
    selected_lean = str(lean_executable or shutil.which("lean") or "")
    execution_performed = False
    lean_exit_code = None
    lean_stdout = ""
    lean_stderr = ""
    lean_timed_out = False
    if selected_lean:
        try:
            result = _run_lean(selected_lean, source_info["path"], timeout_seconds, runner=runner)
            execution_performed = True
            lean_exit_code = int(getattr(result, "returncode", 1))
            lean_stdout = str(getattr(result, "stdout", "") or "")
            lean_stderr = str(getattr(result, "stderr", "") or "")
        except subprocess.TimeoutExpired as exc:
            execution_performed = True
            lean_exit_code = 124
            lean_timed_out = True
            lean_stdout = str(exc.stdout or "")
            lean_stderr = str(exc.stderr or "")

    definitions = DEFINITION_RE.findall(lean_source_text)
    placeholders = PLACEHOLDER_RE.findall(lean_source_text)
    lean_exit_zero = bool(execution_performed and lean_exit_code == 0 and not lean_timed_out)
    all_candidates_available = bool(drafts) and candidate_count == len(drafts)
    proxy_only = bool(drafts and numeric_complete_count < len(drafts))
    checks = [
        _check("semantic_source_context_extraction_report_consumable", not _source_context_issues(source_report), "production_claim_lean_semantic_source_context_extraction_not_consumable"),
        _check("semantic_definition_candidates_present_or_closed", machine_checked or all_candidates_available, "semantic_definition_source_candidates_missing", severity="readiness"),
        _check("lean_executable_found", bool(selected_lean), "lean_executable_not_found", severity="readiness"),
        _check("lean_execution_performed", execution_performed, "lean_execution_not_performed"),
        _check("lean_execution_exit_zero", lean_exit_zero, "lean_execution_failed"),
        _check("lean_definitions_present", bool(definitions), "lean_definitions_missing"),
        _check("placeholder_tokens_absent", not placeholders, "placeholder_tokens_present"),
        _check("numeric_semantics_complete", machine_checked or not proxy_only, "numeric_asymptotic_semantics_required", severity="readiness"),
        _check("no_source_mutation", not source_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not source_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif lean_exit_zero and definitions and all_candidates_available and not placeholders and proxy_only:
        status = "PASS"
        state = NUMERIC_REQUIRED_STATE
        next_agent_stage = "numeric_asymptotic_semantics_refinement"
        next_agent_command = ""
    elif lean_exit_zero and definitions and all_candidates_available and not placeholders:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""

    draft_ready = bool(status == "PASS" and state in {READY_STATE, NUMERIC_REQUIRED_STATE})
    numeric_required = bool(status == "PASS" and state == NUMERIC_REQUIRED_STATE)
    theorem_ready = bool(status == "PASS" and state == READY_STATE)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_semantic_definition_draft_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": True,
        "execution_performed": execution_performed,
        "prover_execution_performed": execution_performed,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_semantic_definition_draft_ready": draft_ready,
        "lean_semantic_definition_proxy_only": bool(draft_ready and proxy_only),
        "lean_numeric_semantics_required": numeric_required,
        "lean_theorem_draft_ready": theorem_ready,
        "production_claim_machine_checked": machine_checked,
        "lean_executable_path": selected_lean,
        "lean_exit_code": lean_exit_code,
        "lean_source_path": source_info["path"],
        "claim_packet_id": source_report.get("claim_packet_id") or "",
        "slug": source_report.get("slug") or "",
        "semantic_source_context_extraction_report_path": source_report.get("report_path") or "",
        "semantic_source_context_extraction_report_sha256": source_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "semantic_definition_candidate_count": candidate_count,
            "source_backed_definition_draft_count": len(drafts),
            "numeric_semantics_complete_count": numeric_complete_count,
            "lean_definition_count": len(definitions),
            "placeholder_token_count": len(placeholders),
            "lean_exit_zero_count": 1 if lean_exit_zero else 0,
            "lean_numeric_semantics_required_count": 1 if numeric_required else 0,
            "lean_theorem_draft_ready_count": 1 if theorem_ready else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 1 if execution_performed else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "lean_execution": {
            "executable_path": selected_lean,
            "source_path": source_info["path"],
            "source_sha256": source_info["sha256"],
            "exit_code": lean_exit_code,
            "timed_out": lean_timed_out,
            "stdout": lean_stdout,
            "stderr": lean_stderr,
            "definition_names": definitions,
            "placeholder_token_count": len(placeholders),
        },
        "source_backed_semantic_definition_drafts": drafts,
        "semantic_source_context_extraction_report": source_report,
        "boundary": [
            "This command drafts source-backed Lean proxy definitions; it does not complete numeric asymptotic semantics.",
            "The Nat-valued rate scaffold must be refined before a theorem draft can be proof-ready.",
            "A syntax-valid semantic-definition draft is not a machine-checked production claim.",
            "It writes only local draft artifacts and does not mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_semantic_definition_draft_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Semantic Definition Draft",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_semantic_definition_draft_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Lean exit code: {report.get('lean_exit_code')}",
        f"- Proxy only: {report.get('lean_semantic_definition_proxy_only')}",
        f"- Numeric semantics required: {report.get('lean_numeric_semantics_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Source-Backed Semantic Definition Drafts", ""])
    for item in report.get("source_backed_semantic_definition_drafts") or []:
        lines.append(
            f"- {item.get('primitive')}: {item.get('lean_definition_name')} "
            f"source_backed={item.get('source_backed_definition_draft_available')} "
            f"numeric_complete={item.get('lean_numeric_semantics_complete')} "
            f"next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
