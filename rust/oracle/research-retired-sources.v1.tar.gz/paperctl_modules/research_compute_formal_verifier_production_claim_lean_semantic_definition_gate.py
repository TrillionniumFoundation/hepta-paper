"""Gate whether primitive signatures have source-backed Lean semantic definitions."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-semantic-definition-gate"
PRIMITIVE_DRAFT_COMMAND = "research-compute-formal-verifier-production-claim-lean-primitive-definition-draft"

PRIMITIVE_DRAFT_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PRIMITIVE_DEFINITION_DRAFT_READY"
PRIMITIVE_DRAFT_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PRIMITIVE_DEFINITION_DRAFT_MACHINE_CHECKED_CLOSED"

CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_MACHINE_CHECKED_CLOSED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_READY_FOR_THEOREM_DRAFT"
SEMANTIC_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_SEMANTIC_DEFINITION_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_semantic_definition_gate_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_semantic_definition_gate_ready",
    "lean_semantic_definition_required",
    "lean_theorem_draft_ready",
    "signature_only_definition_rejected",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "primitive_definition_draft_report_path",
    "primitive_definition_draft_report_sha256",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "semantic_definition_gaps",
    "signature_field_classifications",
    "primitive_definition_draft_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "primitive_signature_field_count",
    "semantic_definition_available_count",
    "semantic_definition_gap_count",
    "signature_only_definition_count",
    "lean_theorem_draft_ready_count",
    "lean_semantic_definition_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a Lean primitive-definition draft and refuses to treat bare Type/Prop signature slots as semantic definitions.",
    "Only source-backed Lean semantic definitions can unlock a theorem draft/proof attempt.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
BARE_SIGNATURE_TYPES = {"Type", "Prop", "Sort", "Sort u"}


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _primitive_draft_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_primitive_definition_draft_report_missing")
        return issues
    if report.get("command") != PRIMITIVE_DRAFT_COMMAND:
        _issue(issues, "production_claim_lean_primitive_definition_draft_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_primitive_definition_draft_not_pass", report.get("status") or "")
    if not report.get("lean_primitive_definition_draft_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_primitive_definition_draft_not_ready")
    state = report.get("formal_verifier_production_claim_lean_primitive_definition_draft_state") or ""
    if state not in {PRIMITIVE_DRAFT_READY_STATE, PRIMITIVE_DRAFT_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_primitive_definition_draft_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_primitive_definition_draft_boundary:{key}")
    return issues


def _semantic_available(field):
    return bool(
        field.get("semantic_definition_available")
        or field.get("lean_semantic_definition")
        or field.get("lean_definition_body")
        or field.get("formal_definition")
        or field.get("source_backed_definition_sha256")
    )


def _classify_field(field):
    field = field or {}
    field_type = str(field.get("lean_field_type") or "").strip()
    semantic_available = _semantic_available(field)
    signature_only = bool(not semantic_available and (not field_type or field_type in BARE_SIGNATURE_TYPES))
    gap = bool(not semantic_available)
    return {
        "primitive": field.get("primitive") or "",
        "lean_field_name": field.get("lean_field_name") or "",
        "lean_field_type": field_type,
        "required_definition": field.get("required_definition") or "",
        "source_locator": field.get("source_locator") or "",
        "work_item_id": field.get("work_item_id") or "",
        "semantic_definition_available": semantic_available,
        "signature_only_slot": signature_only,
        "semantic_definition_gap": gap,
        "next_required_action": "supply_source_backed_lean_semantic_definition" if gap else "draft_theorem_against_semantic_definition",
    }


def formal_verifier_production_claim_lean_semantic_definition_gate(
    primitive_definition_draft_report=None,
    label="",
):
    primitive_report = primitive_definition_draft_report or {}
    validation_issues = _primitive_draft_issues(primitive_report)
    fields = list(primitive_report.get("primitive_signature_fields") or [])
    classifications = [_classify_field(field) for field in fields]
    semantic_gaps = [item for item in classifications if item["semantic_definition_gap"]]
    signature_only_slots = [item for item in classifications if item["signature_only_slot"]]
    machine_checked = bool(
        primitive_report.get("production_claim_machine_checked")
        and primitive_report.get("formal_verifier_production_claim_lean_primitive_definition_draft_state") == PRIMITIVE_DRAFT_CLOSED_STATE
    )
    theorem_ready = bool(not validation_issues and fields and not semantic_gaps and not machine_checked)

    checks = [
        _check("primitive_definition_draft_report_consumable", not _primitive_draft_issues(primitive_report), "production_claim_lean_primitive_definition_draft_not_consumable"),
        _check("primitive_signature_fields_present_or_closed", machine_checked or bool(fields), "primitive_signature_fields_missing"),
        _check("semantic_definitions_available", not semantic_gaps or machine_checked, "lean_semantic_definitions_missing", severity="readiness"),
        _check("signature_only_slots_rejected", not signature_only_slots or machine_checked, "signature_only_slots_present", severity="readiness"),
        _check("no_source_mutation", not primitive_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not primitive_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif theorem_ready:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_theorem_draft"
        next_agent_command = ""
    else:
        status = "PASS"
        state = SEMANTIC_REQUIRED_STATE
        next_agent_stage = "source_backed_lean_semantic_definition"
        next_agent_command = ""

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_semantic_definition_gate_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_semantic_definition_gate_ready": status == "PASS",
        "lean_semantic_definition_required": bool(status == "PASS" and state == SEMANTIC_REQUIRED_STATE),
        "lean_theorem_draft_ready": bool(status == "PASS" and state == READY_STATE),
        "signature_only_definition_rejected": bool(status == "PASS" and signature_only_slots and not machine_checked),
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": primitive_report.get("claim_packet_id") or "",
        "slug": primitive_report.get("slug") or "",
        "primitive_definition_draft_report_path": primitive_report.get("report_path") or "",
        "primitive_definition_draft_report_sha256": primitive_report.get("report_sha256") or "",
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "primitive_signature_field_count": len(fields),
            "semantic_definition_available_count": sum(1 for item in classifications if item["semantic_definition_available"]),
            "semantic_definition_gap_count": len(semantic_gaps),
            "signature_only_definition_count": len(signature_only_slots),
            "lean_theorem_draft_ready_count": 1 if status == "PASS" and state == READY_STATE else 0,
            "lean_semantic_definition_required_count": 1 if status == "PASS" and state == SEMANTIC_REQUIRED_STATE else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "semantic_definition_gaps": semantic_gaps,
        "signature_field_classifications": classifications,
        "primitive_definition_draft_report": primitive_report,
        "boundary": [
            "This command rejects bare Type/Prop primitive-signature slots as semantic definitions.",
            "A source-backed Lean semantic definition must bind each primitive before a theorem draft can be treated as proof-ready.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_semantic_definition_gate_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Semantic Definition Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_semantic_definition_gate_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Semantic definition required: {report.get('lean_semantic_definition_required')}",
        f"- Theorem draft ready: {report.get('lean_theorem_draft_ready')}",
        f"- Signature-only definition rejected: {report.get('signature_only_definition_rejected')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Signature Field Classifications", ""])
    for item in report.get("signature_field_classifications") or []:
        lines.append(
            f"- {item.get('primitive')}: semantic={item.get('semantic_definition_available')} "
            f"signature_only={item.get('signature_only_slot')} next={item.get('next_required_action')}"
        )
    if report.get("semantic_definition_gaps"):
        lines.extend(["", "## Semantic Definition Gaps", ""])
        for item in report.get("semantic_definition_gaps") or []:
            lines.append(
                f"- {item.get('primitive')}: {item.get('required_definition')} "
                f"({item.get('source_locator') or item.get('work_item_id') or ''})".rstrip()
            )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
