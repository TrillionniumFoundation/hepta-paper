"""Extract source context for Lean semantic-definition gaps."""

import hashlib
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-semantic-source-context-extraction"
SEMANTIC_GATE_COMMAND = "research-compute-formal-verifier-production-claim-lean-semantic-definition-gate"

SEMANTIC_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_SEMANTIC_DEFINITION_REQUIRED"
SEMANTIC_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_DEFINITION_GATE_MACHINE_CHECKED_CLOSED"

READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_SOURCE_CONTEXT_EXTRACTION_DEFINITION_DRAFT_REQUIRED"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_SOURCE_CONTEXT_EXTRACTION_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_SOURCE_CONTEXT_EXTRACTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_SEMANTIC_SOURCE_CONTEXT_EXTRACTION_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_semantic_source_context_extraction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "lean_semantic_source_context_extraction_ready",
    "lean_semantic_definition_draft_required",
    "lean_semantic_definition_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "semantic_definition_gate_report_path",
    "semantic_definition_gate_report_sha256",
    "source_root",
    "context_radius",
    "next_agent_stage",
    "next_agent_command",
    "summary",
    "checks",
    "validation_issues",
    "semantic_gap_source_classifications",
    "source_context_windows",
    "semantic_definition_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "semantic_definition_gap_count",
    "source_context_window_count",
    "source_context_available_count",
    "source_mention_count",
    "semantic_definition_candidate_count",
    "lean_semantic_definition_ready_count",
    "lean_semantic_definition_draft_required_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a Lean semantic-definition gate report and extracts real manuscript source context for missing primitives.",
    "Source context mentions are candidates only; they are not Lean semantic definitions or theorem proofs.",
    "This command reads local source context and writes only local reports; it does not mutate source, execute Lean, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
PRIMITIVE_PATTERNS = {
    "bar_rho_N": re.compile(r"(?:bar[_-]?rho[_-]?N|\\bar\s*\\rho|\\bar\{?\\rho\}?_?\{?N\}?|rho_N|\\rho_N)", re.I),
    "n_2": re.compile(r"(?:n_2|n_2|n\{?2\}?|n_2|\{n_2\}|n_2\^|n_2\\|n_2)", re.I),
    "Delta_t": re.compile(r"(?:Delta\s*t|\\Delta\s*t|fixed-\$?\\Delta t|fixed\s+\\?\$?Delta)", re.I),
    "little_o_rate": re.compile(r"(?:o\s*\(|little[- ]?o|negligible|first-order)", re.I),
    "drift_block_rate": re.compile(r"drift[^.;,\n]*block[^.;,\n]*rate|block[^.;,\n]*drift[^.;,\n]*rate|rho_\{?N,\\alpha\}?", re.I),
    "diffusion_block_rate": re.compile(r"diffusion[^.;,\n]*block[^.;,\n]*rate|block[^.;,\n]*diffusion[^.;,\n]*rate|rho_\{?N,\\beta\}?", re.I),
    "high_frequency_regime": re.compile(r"high[- ]frequency|triangular[- ]array", re.I),
    "Wald_inference": re.compile(r"Wald\s+inference|Wald[- ]coverage", re.I),
    "direct_Euler_limit": re.compile(r"direct\s+Euler\s+limit|direct\s+Euler\s+score|direct-score\s+limit", re.I),
}


def _sha256_text(text):
    return hashlib.sha256(text.encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _semantic_gate_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_semantic_definition_gate_report_missing")
        return issues
    if report.get("command") != SEMANTIC_GATE_COMMAND:
        _issue(issues, "production_claim_lean_semantic_definition_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_semantic_definition_gate_not_pass", report.get("status") or "")
    if not report.get("lean_semantic_definition_gate_ready") and not report.get("production_claim_machine_checked"):
        _issue(issues, "production_claim_lean_semantic_definition_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_semantic_definition_gate_state") or ""
    if state not in {SEMANTIC_REQUIRED_STATE, SEMANTIC_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_semantic_definition_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_semantic_definition_gate_boundary:{key}")
    return issues


def _parse_source_locator(locator):
    match = re.match(r"(.+?):(\d+)(?::\d+)?$", str(locator or ""))
    if not match:
        return "", 0
    return match.group(1), int(match.group(2))


def _read_context(source_root, source_locator, context_radius):
    rel_path, line_no = _parse_source_locator(source_locator)
    if not rel_path or line_no <= 0:
        return {
            "source_locator": source_locator or "",
            "available": False,
            "issue": "source_locator_unparseable",
        }
    path = pathlib.Path(rel_path)
    if not path.is_absolute():
        path = pathlib.Path(source_root or ".") / path
    if not path.exists():
        return {
            "source_locator": source_locator or "",
            "path": str(path),
            "available": False,
            "issue": "source_file_missing",
        }
    lines = path.read_text(errors="replace").splitlines()
    start = max(1, line_no - int(context_radius or 0))
    end = min(len(lines), line_no + int(context_radius or 0))
    window_lines = lines[start - 1 : end]
    text = "\n".join(window_lines)
    return {
        "source_locator": source_locator or "",
        "path": str(path),
        "relative_path": rel_path,
        "available": True,
        "line": line_no,
        "start_line": start,
        "end_line": end,
        "text_sha256": _sha256_text(text),
        "text": text,
    }


def _candidate_lines(primitive, context_text):
    pattern = PRIMITIVE_PATTERNS.get(primitive) or re.compile(re.escape(primitive), re.I)
    lines = []
    for offset, line in enumerate(str(context_text or "").splitlines(), start=1):
        if pattern.search(line):
            lines.append({"window_line": offset, "text": line.strip()})
    return lines


def _classify_gap(gap, context):
    primitive = gap.get("primitive") or ""
    available = bool(context.get("available"))
    candidates = _candidate_lines(primitive, context.get("text") or "") if available else []
    return {
        "primitive": primitive,
        "lean_field_name": gap.get("lean_field_name") or "",
        "required_definition": gap.get("required_definition") or "",
        "source_locator": gap.get("source_locator") or "",
        "source_context_available": available,
        "source_mention_count": len(candidates),
        "semantic_definition_candidate_available": bool(candidates),
        "lean_semantic_definition_ready": False,
        "definition_candidate_lines": candidates[:5],
        "next_required_action": "turn_source_context_into_source_backed_lean_definition" if candidates else "locate_source_context_for_primitive",
    }


def formal_verifier_production_claim_lean_semantic_source_context_extraction(
    semantic_definition_gate_report=None,
    source_root="",
    context_radius=35,
    label="",
):
    semantic_report = semantic_definition_gate_report or {}
    validation_issues = _semantic_gate_issues(semantic_report)
    gaps = list(semantic_report.get("semantic_definition_gaps") or [])
    machine_checked = bool(
        semantic_report.get("production_claim_machine_checked")
        and semantic_report.get("formal_verifier_production_claim_lean_semantic_definition_gate_state") == SEMANTIC_CLOSED_STATE
    )
    contexts = {}
    for gap in gaps:
        locator = gap.get("source_locator") or ""
        if locator and locator not in contexts:
            contexts[locator] = _read_context(source_root, locator, context_radius)
    classifications = [_classify_gap(gap, contexts.get(gap.get("source_locator") or "", {})) for gap in gaps]
    source_context_available_count = sum(1 for item in contexts.values() if item.get("available"))
    source_mention_count = sum(item.get("source_mention_count", 0) for item in classifications)
    candidate_count = sum(1 for item in classifications if item.get("semantic_definition_candidate_available"))
    definition_ready_count = sum(1 for item in classifications if item.get("lean_semantic_definition_ready"))
    if gaps and not source_context_available_count:
        _issue(validation_issues, "semantic_definition_gap_source_context_missing")

    checks = [
        _check("semantic_definition_gate_report_consumable", not _semantic_gate_issues(semantic_report), "production_claim_lean_semantic_definition_gate_not_consumable"),
        _check("semantic_definition_gaps_present_or_closed", machine_checked or bool(gaps), "semantic_definition_gaps_missing"),
        _check("source_context_available", machine_checked or source_context_available_count > 0, "semantic_definition_gap_source_context_missing", severity="readiness"),
        _check("source_mentions_present", machine_checked or candidate_count > 0, "semantic_definition_source_mentions_missing", severity="readiness"),
        _check("no_source_mutation", not semantic_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not semantic_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        next_agent_stage = ""
        next_agent_command = ""
    else:
        status = "PASS"
        state = READY_STATE
        next_agent_stage = "source_backed_lean_semantic_definition_draft"
        next_agent_command = ""

    definition_draft_required = bool(status == "PASS" and state == READY_STATE and definition_ready_count < len(gaps))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_semantic_source_context_extraction_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "lean_semantic_source_context_extraction_ready": status == "PASS",
        "lean_semantic_definition_draft_required": definition_draft_required,
        "lean_semantic_definition_ready": bool(status == "PASS" and definition_ready_count == len(gaps) and bool(gaps)),
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": semantic_report.get("claim_packet_id") or "",
        "slug": semantic_report.get("slug") or "",
        "semantic_definition_gate_report_path": semantic_report.get("report_path") or "",
        "semantic_definition_gate_report_sha256": semantic_report.get("report_sha256") or "",
        "source_root": str(source_root or ""),
        "context_radius": int(context_radius or 0),
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "summary": {
            "validation_issue_count": len(validation_issues),
            "semantic_definition_gap_count": len(gaps),
            "source_context_window_count": len(contexts),
            "source_context_available_count": source_context_available_count,
            "source_mention_count": source_mention_count,
            "semantic_definition_candidate_count": candidate_count,
            "lean_semantic_definition_ready_count": definition_ready_count,
            "lean_semantic_definition_draft_required_count": 1 if definition_draft_required else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "semantic_gap_source_classifications": classifications,
        "source_context_windows": list(contexts.values()),
        "semantic_definition_gate_report": semantic_report,
        "boundary": [
            "This command extracts local manuscript source context only; source mentions are not Lean semantic definitions.",
            "The next stage must turn candidate context into explicit source-backed Lean definitions before theorem drafting.",
            "It does not execute Lean, prove the production claim, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_semantic_source_context_extraction_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Semantic Source Context Extraction",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_semantic_source_context_extraction_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Semantic definition draft required: {report.get('lean_semantic_definition_draft_required')}",
        f"- Semantic definition ready: {report.get('lean_semantic_definition_ready')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Semantic Gap Source Classifications", ""])
    for item in report.get("semantic_gap_source_classifications") or []:
        lines.append(
            f"- {item.get('primitive')}: context={item.get('source_context_available')} "
            f"mentions={item.get('source_mention_count')} ready={item.get('lean_semantic_definition_ready')} "
            f"next={item.get('next_required_action')}"
        )
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
