"""Extract candidate mathematical statements for production-claim Lean work."""

import hashlib
import json
import pathlib
import re


COMMAND = "research-compute-formal-verifier-production-claim-lean-statement-extraction"
FEASIBILITY_COMMAND = "research-compute-formal-verifier-production-claim-lean-feasibility-gate"

FEASIBILITY_STATEMENT_REQUIRED_STATE = (
    "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_MATHEMATICAL_STATEMENT_REQUIRED"
)
FEASIBILITY_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_READY_FOR_PROOF_ATTEMPT"
FEASIBILITY_CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_FEASIBILITY_GATE_MACHINE_CHECKED_CLOSED"

CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_STATEMENT_EXTRACTION_MACHINE_CHECKED_CLOSED"
READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_STATEMENT_EXTRACTION_READY"
DECLARATION_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_STATEMENT_EXTRACTION_DECLARATION_DRAFT_REQUIRED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_STATEMENT_EXTRACTION_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_STATEMENT_EXTRACTION_FAILED"

STATEMENT_PACKET_SCHEMA = "paper_factory.research_compute.formal_verifier_production_claim_lean_statement_extraction_packet.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_statement_extraction_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "statement_extraction_ready",
    "lean_declaration_draft_required",
    "lean_proof_attempt_ready",
    "production_claim_machine_checked",
    "claim_packet_id",
    "slug",
    "feasibility_gate_report_path",
    "feasibility_gate_report_sha256",
    "statement_extraction_packet_path",
    "statement_extraction_packet_sha256",
    "summary",
    "checks",
    "validation_issues",
    "candidate_statements",
    "source_contexts",
    "statement_extraction_packet",
    "feasibility_gate_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "work_item_count",
    "source_context_count",
    "candidate_statement_count",
    "lean_declaration_template_count",
    "lean_declaration_draft_required_count",
    "lean_proof_attempt_ready_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a Lean feasibility gate and extracts candidate mathematical statements from manuscript source context.",
    "Extracted statements are candidate formalization targets, not machine-checked Lean proofs.",
    "This command reads manuscript source for context, writes optional local reports/sidecars, and does not mutate source, execute Lean, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]
THEOREM_HINTS = [
    "theorem",
    "proposition",
    "lemma",
    "corollary",
    "if ",
    "only when",
    "under ",
    "satisfies",
    "implies",
    "then",
    "bound",
    "limit",
    "clt",
    "asymptotic",
    "wald inference",
    "direct euler",
]
EXCLUDE_HINTS = [
    "agent-drafted",
    "research compute claim boundary",
    "not an external submission",
    "venue decision",
    "local source rollback",
]


def _sha256_text(value):
    return hashlib.sha256(str(value or "").encode()).hexdigest()


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _feasibility_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_feasibility_gate_report_missing")
        return issues
    if report.get("command") != FEASIBILITY_COMMAND:
        _issue(issues, "production_claim_lean_feasibility_gate_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_feasibility_gate_not_pass", report.get("status") or "")
    if not report.get("lean_feasibility_gate_ready"):
        _issue(issues, "production_claim_lean_feasibility_gate_not_ready")
    state = report.get("formal_verifier_production_claim_lean_feasibility_gate_state") or ""
    if state not in {FEASIBILITY_STATEMENT_REQUIRED_STATE, FEASIBILITY_READY_STATE, FEASIBILITY_CLOSED_STATE}:
        _issue(issues, "production_claim_lean_feasibility_gate_state_not_consumable", state)
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_feasibility_boundary:{key}")
    return issues


def _parse_source_locator(locator, root):
    if not locator or ":" not in str(locator):
        return pathlib.Path(), 0
    path_text, line_text = str(locator).rsplit(":", 1)
    try:
        line = int(line_text)
    except ValueError:
        line = 0
    path = pathlib.Path(path_text)
    if not path.is_absolute():
        path = pathlib.Path(root) / path
    return path.resolve(), line


def _source_context(locator, root, radius):
    path, line = _parse_source_locator(locator, root)
    if not path or not path.exists() or line <= 0:
        return {
            "source_locator": locator or "",
            "source_path": str(path) if path else "",
            "line": line,
            "available": False,
            "context_text": "",
            "context_start_line": 0,
            "context_end_line": 0,
            "context_sha256": "",
        }
    lines = path.read_text(errors="ignore").splitlines()
    start = max(1, line - int(radius))
    end = min(len(lines), line + int(radius))
    context = "\n".join(lines[start - 1:end])
    return {
        "source_locator": locator or "",
        "source_path": str(path),
        "line": line,
        "available": True,
        "context_text": context,
        "context_start_line": start,
        "context_end_line": end,
        "context_sha256": _sha256_text(context),
    }


def _strip_tex(text):
    text = re.sub(r"%.*", "", text or "")
    replacements = {
        r"\\bar\\rho_N": "bar_rho_N",
        r"\\rho_N": "rho_N",
        r"\\hat\\rho_N": "hat_rho_N",
        r"\\Delta t": "Delta t",
        r"\\theta": "theta",
        r"\\Theta_N": "Theta_N",
    }
    for pattern, value in replacements.items():
        text = re.sub(pattern, value, text)
    text = re.sub(r"\\(Cref|cref|ref|eqref)\{([^}]*)\}", r"\2", text)
    text = re.sub(r"\\texttt\{([^}]*)\}", r"\1", text)
    text = re.sub(r"\\textbf\{([^}]*)\}", r"\1", text)
    text = re.sub(r"\\emph\{([^}]*)\}", r"\1", text)
    text = re.sub(r"\\paragraph\{([^}]*)\}", r"\n\1. ", text)
    text = re.sub(r"\\begin\{[^}]+\}|\\end\{[^}]+\}", " ", text)
    text = re.sub(r"\\[a-zA-Z]+", " ", text)
    text = re.sub(r"[{}]", "", text)
    text = re.sub(r"\s+", " ", text)
    return text.strip()


def _item_requests_statement(item):
    text = " ".join(
        [
            str((item or {}).get("work_item_id") or ""),
            str((item or {}).get("obligation_name") or ""),
            str((item or {}).get("description") or ""),
        ]
    ).lower()
    return any(marker in text for marker in ["candidate_theorem", "lemma_statement", "theorem statement", "formal statement"])


def _sentence_candidates(context_text):
    plain = _strip_tex(context_text)
    parts = re.split(r"(?<=[.!?])\s+", plain)
    candidates = []
    for part in parts:
        lower = part.lower()
        if len(part) < 40:
            continue
        if any(hint in lower for hint in EXCLUDE_HINTS):
            continue
        if any(hint in lower for hint in THEOREM_HINTS):
            candidates.append(part.strip())
    return candidates


def _select_candidate(candidates):
    if not candidates:
        return ""
    def score(text):
        lower = text.lower()
        value = 0
        for marker in ["only when", "if ", "under ", "satisfies", "bound", "limit", "wald inference", "direct euler"]:
            if marker in lower:
                value += 3
        value += min(len(text) // 80, 4)
        return value
    return sorted(candidates, key=score, reverse=True)[0]


def _lean_template_name(slug, work_item_id):
    raw = f"{slug or 'ProductionClaim'}_{work_item_id or 'Statement'}"
    chunks = re.split(r"[^A-Za-z0-9]+", raw)
    ident = "".join(chunk[:1].upper() + chunk[1:] for chunk in chunks if chunk)
    if not ident or not ident[0].isalpha():
        ident = "ProductionClaimStatement"
    return ident[:160]


def _build_candidate_statement(item, context, slug):
    if not _item_requests_statement(item):
        return {}
    candidates = _sentence_candidates(context.get("context_text") or "")
    selected = _select_candidate(candidates)
    if not selected:
        return {}
    theorem_name = _lean_template_name(slug, item.get("work_item_id") or "")
    return {
        "work_item_id": item.get("work_item_id") or "",
        "obligation_name": item.get("obligation_name") or "",
        "source_locator": item.get("source_locator") or context.get("source_locator") or "",
        "candidate_statement_kind": "manuscript_context_extracted_candidate",
        "candidate_statement_text": selected,
        "candidate_statement_sha256": _sha256_text(selected),
        "lean_namespace_hint": _lean_template_name(slug, "Formalization"),
        "lean_theorem_name_hint": theorem_name,
        "lean_declaration_template": f"theorem {theorem_name} : Prop := by\n  -- translate and prove the extracted statement here\n  sorry",
        "lean_declaration_template_contains_placeholder": True,
        "machine_checked": False,
        "proof_required": True,
        "source_context_sha256": context.get("context_sha256") or "",
    }


def _candidate_items(feasibility_report):
    dispatch = feasibility_report.get("dispatch_report") or {}
    items = list(dispatch.get("formalization_work_items") or [])
    if items:
        return items
    return []


def formal_verifier_production_claim_lean_statement_extraction(
    feasibility_gate_report=None,
    root=".",
    context_radius=30,
    label="",
):
    feasibility_report = feasibility_gate_report or {}
    validation_issues = _feasibility_issues(feasibility_report)
    state = feasibility_report.get("formal_verifier_production_claim_lean_feasibility_gate_state") or ""
    machine_checked = bool(state == FEASIBILITY_CLOSED_STATE and feasibility_report.get("production_claim_machine_checked"))
    work_items = _candidate_items(feasibility_report)
    slug = feasibility_report.get("slug") or ((feasibility_report.get("dispatch_report") or {}).get("slug") or "")
    contexts = []
    candidate_statements = []
    seen_contexts = {}
    for item in work_items:
        locator = item.get("source_locator") or ""
        if not locator:
            continue
        if locator not in seen_contexts:
            seen_contexts[locator] = _source_context(locator, root, context_radius)
        context = seen_contexts[locator]
        contexts.append({"work_item_id": item.get("work_item_id") or "", **context})
        statement = _build_candidate_statement(item, context, slug)
        if statement:
            candidate_statements.append(statement)
    if state == FEASIBILITY_STATEMENT_REQUIRED_STATE and not work_items:
        _issue(validation_issues, "production_claim_lean_statement_extraction_work_items_missing")
    if state == FEASIBILITY_STATEMENT_REQUIRED_STATE and work_items and not any(ctx.get("available") for ctx in contexts):
        _issue(validation_issues, "production_claim_lean_statement_extraction_source_context_missing")

    checks = [
        _check("feasibility_gate_report_consumable", not _feasibility_issues(feasibility_report), "production_claim_lean_feasibility_gate_not_consumable"),
        _check("work_items_present_or_closed", machine_checked or bool(work_items), "production_claim_lean_statement_extraction_work_items_missing"),
        _check("source_context_available_or_closed", machine_checked or any(ctx.get("available") for ctx in contexts), "production_claim_lean_statement_extraction_source_context_missing"),
        _check("no_source_mutation", not feasibility_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not feasibility_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        out_state = FAILED_STATE
    elif validation_issues:
        status = "ATTENTION"
        out_state = ATTENTION_STATE
    elif machine_checked:
        status = "PASS"
        out_state = CLOSED_STATE
    elif candidate_statements:
        status = "PASS"
        out_state = DECLARATION_REQUIRED_STATE
    else:
        status = "ATTENTION"
        out_state = ATTENTION_STATE
        _issue(validation_issues, "production_claim_lean_candidate_statement_not_found")

    packet = {
        "packet_type": "production_claim_lean_statement_extraction",
        "packet_schema": STATEMENT_PACKET_SCHEMA,
        "claim_packet_id": feasibility_report.get("claim_packet_id") or "",
        "slug": slug,
        "candidate_statement_count": len(candidate_statements),
        "lean_declaration_template_count": len(candidate_statements),
        "lean_declaration_draft_required": bool(candidate_statements and not machine_checked),
        "lean_proof_attempt_ready": False,
        "production_claim_machine_checked": machine_checked,
        "candidate_statements": candidate_statements,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
    }
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_statement_extraction_state": out_state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "statement_extraction_ready": status == "PASS",
        "lean_declaration_draft_required": bool(candidate_statements and not machine_checked),
        "lean_proof_attempt_ready": False,
        "production_claim_machine_checked": machine_checked,
        "claim_packet_id": feasibility_report.get("claim_packet_id") or "",
        "slug": slug,
        "feasibility_gate_report_path": feasibility_report.get("report_path") or "",
        "feasibility_gate_report_sha256": feasibility_report.get("report_sha256") or "",
        "statement_extraction_packet_path": "",
        "statement_extraction_packet_sha256": "",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "work_item_count": len(work_items),
            "source_context_count": len([ctx for ctx in contexts if ctx.get("available")]),
            "candidate_statement_count": len(candidate_statements),
            "lean_declaration_template_count": len(candidate_statements),
            "lean_declaration_draft_required_count": 1 if candidate_statements and not machine_checked else 0,
            "lean_proof_attempt_ready_count": 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "candidate_statements": candidate_statements,
        "source_contexts": contexts,
        "statement_extraction_packet": packet,
        "feasibility_gate_report": feasibility_report,
        "boundary": [
            "This command extracts candidate mathematical statements from manuscript context; it does not prove them.",
            "Lean declaration templates intentionally contain placeholders and must not be accepted as machine-checked certificates.",
            "It reads source context for evidence, writes optional local reports/sidecars, and does not mutate source/package/archive state, execute Lean, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_statement_extraction_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Statement Extraction",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_statement_extraction_state') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Candidate statements: {(report.get('summary') or {}).get('candidate_statement_count', 0)}",
        f"- Lean proof attempt ready: {report.get('lean_proof_attempt_ready')}",
        "",
        "## Candidate Statements",
        "",
    ]
    for item in report.get("candidate_statements") or []:
        lines.append(f"- {item.get('work_item_id')}: {item.get('candidate_statement_text') or ''}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
