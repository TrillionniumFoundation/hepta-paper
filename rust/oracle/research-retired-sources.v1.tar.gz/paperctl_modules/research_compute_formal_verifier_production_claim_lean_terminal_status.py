"""Summarize production-claim Lean proof terminal status."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-terminal-status"
PLAN_COMMAND = "research-compute-formal-verifier-production-claim-lean-plan"
ATTEMPT_COMMAND = "research-compute-formal-verifier-production-claim-lean-execution-attempt"

PLAN_READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PLAN_READY"
PLAN_CERTIFICATE_ACCEPTED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_PLAN_CERTIFICATE_ALREADY_ACCEPTED"
ATTEMPT_ACCEPTED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_EXECUTION_ATTEMPT_CERTIFICATE_ACCEPTED"
ATTEMPT_INCOMPLETE_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_EXECUTION_ATTEMPT_INCOMPLETE"
ATTEMPT_FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_EXECUTION_ATTEMPT_FAILED"

TERMINAL_MACHINE_CHECKED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_TERMINAL_MACHINE_CHECKED"
TERMINAL_WORK_REQUIRED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_TERMINAL_FORMALIZATION_WORK_REQUIRED"
TERMINAL_ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_TERMINAL_ATTENTION"
TERMINAL_FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_TERMINAL_FAILED"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_terminal_status_state",
    "terminal_status",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "terminal_status_created",
    "terminal_ready",
    "formalization_work_required",
    "lean_translation_required",
    "production_claim_machine_checked",
    "certificate_intake_accepted",
    "claim_packet_id",
    "slug",
    "plan_report_path",
    "execution_attempt_report_path",
    "summary",
    "checks",
    "validation_issues",
    "terminal_status_packet",
    "formalization_work_items",
    "plan_report",
    "execution_attempt_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "terminal_status_created_count",
    "terminal_ready_count",
    "formalization_work_required_count",
    "lean_translation_required_count",
    "formalization_work_item_count",
    "proof_obligation_count",
    "lean_declaration_count",
    "placeholder_token_count",
    "certificate_intake_accepted_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a production-claim Lean plan and execution attempt into a terminal status for downstream schedulers.",
    "A work-required terminal status is successful routing evidence, not a machine-checked production proof.",
    "This command is report-only and does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _forbidden_boundary_issues(report, prefix, issues):
    for key in FORBIDDEN_KEYS:
        if (report or {}).get(key):
            _issue(issues, f"forbidden_{prefix}_boundary:{key}")


def _plan_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_plan_report_missing")
        return issues
    if report.get("command") != PLAN_COMMAND:
        _issue(issues, "production_claim_lean_plan_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_plan_not_pass", report.get("status") or "")
    if not report.get("lean_plan_ready"):
        _issue(issues, "production_claim_lean_plan_not_ready")
    state = report.get("formal_verifier_production_claim_lean_plan_state") or ""
    if state not in {PLAN_READY_STATE, PLAN_CERTIFICATE_ACCEPTED_STATE}:
        _issue(issues, "production_claim_lean_plan_state_not_consumable", state)
    _forbidden_boundary_issues(report, "plan", issues)
    return issues


def _attempt_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_execution_attempt_report_missing")
        return issues
    if report.get("command") != ATTEMPT_COMMAND:
        _issue(issues, "production_claim_lean_execution_attempt_command_mismatch", report.get("command") or "")
    if report.get("status") not in {"PASS", "ATTENTION"}:
        _issue(issues, "production_claim_lean_execution_attempt_status_not_consumable", report.get("status") or "")
    state = report.get("formal_verifier_production_claim_lean_execution_attempt_state") or ""
    if state not in {ATTEMPT_ACCEPTED_STATE, ATTEMPT_INCOMPLETE_STATE}:
        _issue(issues, "production_claim_lean_execution_attempt_state_not_consumable", state)
    if state == ATTEMPT_FAILED_STATE or report.get("status") == "FAIL":
        _issue(issues, "production_claim_lean_execution_attempt_failed", report.get("status") or "")
    _forbidden_boundary_issues(report, "attempt", issues)
    return issues


def _claim_ids_match(plan_report, attempt_report):
    plan_id = (plan_report or {}).get("claim_packet_id") or ""
    attempt_id = (attempt_report or {}).get("claim_packet_id") or ""
    return bool(plan_id and attempt_id and plan_id == attempt_id)


def formal_verifier_production_claim_lean_terminal_status(
    plan_report=None,
    execution_attempt_report=None,
    label="",
):
    plan_report = plan_report or {}
    attempt_report = execution_attempt_report or {}
    validation_issues = _plan_issues(plan_report) + _attempt_issues(attempt_report)
    if plan_report and attempt_report and not _claim_ids_match(plan_report, attempt_report):
        _issue(validation_issues, "production_claim_lean_claim_packet_id_mismatch")

    plan_summary = plan_report.get("summary") or {}
    attempt_summary = attempt_report.get("summary") or {}
    plan = plan_report.get("formalization_plan") or {}
    work_items = list(plan.get("work_items") or [])
    machine_checked = bool(
        attempt_report.get("status") == "PASS"
        and attempt_report.get("production_claim_machine_checked")
        and attempt_report.get("certificate_intake_accepted")
    )
    plan_already_accepted = bool(
        plan_report.get("production_claim_machine_checked")
        and plan_report.get("certificate_intake_accepted")
    )
    attempt_incomplete = bool(
        attempt_report.get("formal_verifier_production_claim_lean_execution_attempt_state") == ATTEMPT_INCOMPLETE_STATE
    )
    formalization_work_required = bool(
        not machine_checked
        and not plan_already_accepted
        and plan_report.get("status") == "PASS"
        and attempt_incomplete
        and bool(work_items)
    )

    checks = [
        _check("production_claim_lean_plan_consumable", not _plan_issues(plan_report), "production_claim_lean_plan_not_consumable"),
        _check("production_claim_lean_execution_attempt_consumable", not _attempt_issues(attempt_report), "production_claim_lean_execution_attempt_not_consumable"),
        _check("claim_packet_id_match", _claim_ids_match(plan_report, attempt_report), "production_claim_lean_claim_packet_id_mismatch"),
        _check("terminal_status_classified", bool(machine_checked or plan_already_accepted or formalization_work_required), "production_claim_lean_terminal_status_unclassified"),
        _check("no_source_mutation", not plan_report.get("source_mutation_performed") and not attempt_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not plan_report.get("external_action_performed") and not attempt_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = TERMINAL_FAILED_STATE
        terminal_status = ""
    elif validation_issues:
        status = "ATTENTION"
        state = TERMINAL_ATTENTION_STATE
        terminal_status = ""
    elif machine_checked or plan_already_accepted:
        status = "PASS"
        state = TERMINAL_MACHINE_CHECKED_STATE
        terminal_status = "MACHINE_CHECKED_FORMAL_CERTIFICATE_ACCEPTED"
    elif formalization_work_required:
        status = "PASS"
        state = TERMINAL_WORK_REQUIRED_STATE
        terminal_status = "LEAN_TRANSLATION_OR_PROOF_REQUIRED"
    else:
        status = "ATTENTION"
        state = TERMINAL_ATTENTION_STATE
        terminal_status = ""

    terminal_packet = {
        "packet_type": "production_claim_lean_terminal_status",
        "packet_schema": "paper_factory.research_compute.formal_verifier_production_claim_lean_terminal_status_packet.v1",
        "terminal_status": terminal_status,
        "terminal_ready": status == "PASS",
        "claim_packet_id": plan_report.get("claim_packet_id") or attempt_report.get("claim_packet_id") or "",
        "slug": plan_report.get("slug") or attempt_report.get("slug") or "",
        "production_claim_machine_checked": bool(machine_checked or plan_already_accepted),
        "certificate_intake_accepted": bool(attempt_report.get("certificate_intake_accepted") or plan_report.get("certificate_intake_accepted")),
        "formalization_work_required": formalization_work_required,
        "lean_translation_required": bool(plan_report.get("lean_translation_required") or formalization_work_required),
        "formalization_work_item_count": len(work_items),
        "proof_obligation_count": int(plan_summary.get("proof_obligation_count") or attempt_summary.get("proof_obligation_count") or 0),
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "real_machine_checked_certificate_required_for_production_claim": not bool(machine_checked or plan_already_accepted),
    }
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_terminal_status_state": state,
        "terminal_status": terminal_status,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "terminal_status_created": status in {"PASS", "ATTENTION"},
        "terminal_ready": status == "PASS",
        "formalization_work_required": formalization_work_required,
        "lean_translation_required": bool(plan_report.get("lean_translation_required") or formalization_work_required),
        "production_claim_machine_checked": bool(machine_checked or plan_already_accepted),
        "certificate_intake_accepted": bool(attempt_report.get("certificate_intake_accepted") or plan_report.get("certificate_intake_accepted")),
        "claim_packet_id": plan_report.get("claim_packet_id") or attempt_report.get("claim_packet_id") or "",
        "slug": plan_report.get("slug") or attempt_report.get("slug") or "",
        "plan_report_path": plan_report.get("report_path") or "",
        "execution_attempt_report_path": attempt_report.get("report_path") or "",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "terminal_status_created_count": 1 if status in {"PASS", "ATTENTION"} else 0,
            "terminal_ready_count": 1 if status == "PASS" else 0,
            "formalization_work_required_count": 1 if formalization_work_required else 0,
            "lean_translation_required_count": 1 if (plan_report.get("lean_translation_required") or formalization_work_required) else 0,
            "formalization_work_item_count": len(work_items),
            "proof_obligation_count": int(plan_summary.get("proof_obligation_count") or attempt_summary.get("proof_obligation_count") or 0),
            "lean_declaration_count": int(attempt_summary.get("lean_declaration_count") or 0),
            "placeholder_token_count": int(attempt_summary.get("placeholder_token_count") or 0),
            "certificate_intake_accepted_count": 1 if (attempt_report.get("certificate_intake_accepted") or plan_report.get("certificate_intake_accepted")) else 0,
            "production_claim_machine_checked_count": 1 if (machine_checked or plan_already_accepted) else 0,
            "prover_execution_performed_count": 1 if attempt_report.get("prover_execution_performed") else 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "terminal_status_packet": terminal_packet,
        "formalization_work_items": work_items,
        "plan_report": plan_report,
        "execution_attempt_report": attempt_report,
        "boundary": [
            "This command converts plan plus Lean execution-attempt evidence into a scheduler-consumable terminal status.",
            "LEAN_TRANSLATION_OR_PROOF_REQUIRED means the next agent action is formalization/proof work, not source or submission finalization.",
            "Only MACHINE_CHECKED_FORMAL_CERTIFICATE_ACCEPTED may set production_claim_machine_checked=true.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_terminal_status_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Terminal Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_terminal_status_state') or ''}",
        f"- Terminal status: {report.get('terminal_status') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Formalization work required: {report.get('formalization_work_required')}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Checks", ""])
    for item in report.get("checks") or []:
        lines.append(f"- {item.get('name')}: {item.get('status')} {item.get('detail') or ''}".rstrip())
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
