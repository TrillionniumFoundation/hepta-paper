"""Dispatch production-claim Lean formalization work items."""


COMMAND = "research-compute-formal-verifier-production-claim-lean-work-item-dispatch"
TERMINAL_COMMAND = "research-compute-formal-verifier-production-claim-lean-terminal-status"

TERMINAL_WORK_REQUIRED = "LEAN_TRANSLATION_OR_PROOF_REQUIRED"
TERMINAL_MACHINE_CHECKED = "MACHINE_CHECKED_FORMAL_CERTIFICATE_ACCEPTED"

READY_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_WORK_ITEM_DISPATCH_READY"
CLOSED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_WORK_ITEM_DISPATCH_MACHINE_CHECKED_CLOSED"
ATTENTION_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_WORK_ITEM_DISPATCH_ATTENTION"
FAILED_STATE = "RESEARCH_COMPUTE_FORMAL_VERIFIER_PRODUCTION_CLAIM_LEAN_WORK_ITEM_DISPATCH_FAILED"

DISPATCH_PACKET_SCHEMA = "paper_factory.research_compute.formal_verifier_production_claim_lean_work_item_dispatch_packet.v1"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "formal_verifier_production_claim_lean_work_item_dispatch_state",
    "report_schema",
    "label",
    "report_write_performed",
    "db_mutation_performed",
    "artifact_write_performed",
    "execution_performed",
    "prover_execution_performed",
    "network_performed",
    "secret_material_read_performed",
    "source_mutation_performed",
    "external_action_performed",
    "commit_performed",
    "formalization_work_item_dispatch_created",
    "formalization_work_item_dispatch_ready",
    "dispatch_route",
    "claim_packet_id",
    "slug",
    "terminal_status",
    "production_claim_machine_checked",
    "formalization_work_required",
    "next_agent_stage",
    "next_agent_command",
    "terminal_status_report_path",
    "terminal_status_report_sha256",
    "formalization_work_item_dispatch_packet_path",
    "formalization_work_item_dispatch_packet_sha256",
    "summary",
    "checks",
    "validation_issues",
    "formalization_work_item_dispatch_packet",
    "formalization_work_items",
    "terminal_status_report",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "dispatch_ready_count",
    "formalization_work_item_count",
    "required_output_count",
    "acceptance_check_count",
    "machine_checked_closed_count",
    "production_claim_machine_checked_count",
    "prover_execution_performed_count",
    "network_performed_count",
    "external_action_performed_count",
    "source_mutation_performed_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Consumes a production-claim Lean terminal status and emits formalization/proof work-item dispatch packets.",
    "Dispatch packets are routing evidence only; they do not certify the production theorem.",
    "This command does not execute Lean, mutate source, read secrets, upload, email, submit, or commit.",
]

FORBIDDEN_KEYS = [
    "source_mutation_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "commit_performed",
]


def _issue(issues, issue, detail=""):
    item = {"issue": issue}
    if detail:
        item["detail"] = detail
    issues.append(item)


def _check(name, passed, detail="", severity="blocking"):
    return {
        "name": name,
        "status": "PASS" if passed else "ATTENTION",
        "passed": bool(passed),
        "severity": "" if passed else severity,
        "detail": "" if passed else detail,
    }


def _terminal_issues(report):
    issues = []
    if not report:
        _issue(issues, "production_claim_lean_terminal_status_report_missing")
        return issues
    if report.get("command") != TERMINAL_COMMAND:
        _issue(issues, "production_claim_lean_terminal_status_command_mismatch", report.get("command") or "")
    if report.get("status") != "PASS":
        _issue(issues, "production_claim_lean_terminal_status_not_pass", report.get("status") or "")
    if not report.get("terminal_ready"):
        _issue(issues, "production_claim_lean_terminal_status_not_ready")
    if report.get("terminal_status") not in {TERMINAL_WORK_REQUIRED, TERMINAL_MACHINE_CHECKED}:
        _issue(issues, "production_claim_lean_terminal_status_not_consumable", report.get("terminal_status") or "")
    for key in FORBIDDEN_KEYS:
        if report.get(key):
            _issue(issues, f"forbidden_terminal_boundary:{key}")
    return issues


def _next_agent_command(report):
    plan_path = report.get("plan_report_path") or "<production-claim-lean-plan-report>"
    return (
        "research-compute-formal-verifier-production-claim-lean-execution-attempt"
        f" --production-claim-lean-plan-report {plan_path}"
        " --write"
    )


def _dispatch_items(report):
    items = []
    claim_packet_id = report.get("claim_packet_id") or ""
    slug = report.get("slug") or ""
    for index, item in enumerate(report.get("formalization_work_items") or [], start=1):
        work_item_id = item.get("work_item_id") or f"lean-obligation-{index:04d}"
        items.append(
            {
                "dispatch_id": f"{claim_packet_id or 'claim'}:{work_item_id}",
                "claim_packet_id": claim_packet_id,
                "slug": slug,
                "work_item_id": work_item_id,
                "obligation_name": item.get("obligation_name") or item.get("name") or "",
                "source_locator": item.get("source_locator") or "",
                "description": item.get("description") or "",
                "lean_task": item.get("lean_task") or "translate and prove this obligation in Lean",
                "required_before_certificate": item.get("required_before_certificate", True),
                "machine_checked": False,
                "required_outputs": [
                    "typed Lean definitions or hypotheses for the relevant manuscript assumptions",
                    "one Lean theorem or lemma declaration tied to this obligation",
                    "a proof with no sorry/admit/axiom placeholders and no warning output",
                    "a successful production-claim Lean execution-attempt report",
                ],
                "acceptance_checks": [
                    "lean_exit_code == 0 with warnings treated as errors",
                    "lean_declaration_count > 0",
                    "placeholder_token_count == 0",
                    "certificate_intake_accepted == true",
                    "production_claim_machine_checked == true only after formal certificate intake accepts the artifact",
                ],
            }
        )
    return items


def _dispatch_packet(report, route, items, next_agent_stage, next_agent_command):
    return {
        "packet_type": "production_claim_lean_work_item_dispatch",
        "packet_schema": DISPATCH_PACKET_SCHEMA,
        "dispatch_route": route or "",
        "claim_packet_id": report.get("claim_packet_id") or "",
        "slug": report.get("slug") or "",
        "terminal_status": report.get("terminal_status") or "",
        "production_claim_machine_checked": bool(report.get("production_claim_machine_checked")),
        "formalization_work_required": bool(report.get("formalization_work_required")),
        "formalization_work_item_count": len(items),
        "plan_report_path": report.get("plan_report_path") or "",
        "execution_attempt_report_path": report.get("execution_attempt_report_path") or "",
        "next_agent_stage": next_agent_stage or "",
        "next_agent_command": next_agent_command or "",
        "work_items": items,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "real_machine_checked_certificate_required_for_production_claim": not bool(report.get("production_claim_machine_checked")),
    }


def formal_verifier_production_claim_lean_work_item_dispatch(
    terminal_status_report=None,
    label="",
):
    terminal_report = terminal_status_report or {}
    validation_issues = _terminal_issues(terminal_report)
    terminal_status = terminal_report.get("terminal_status") or ""
    work_items = _dispatch_items(terminal_report)
    machine_checked = bool(
        terminal_status == TERMINAL_MACHINE_CHECKED
        and terminal_report.get("production_claim_machine_checked")
        and terminal_report.get("certificate_intake_accepted")
    )
    work_required = bool(
        terminal_status == TERMINAL_WORK_REQUIRED
        and terminal_report.get("formalization_work_required")
        and work_items
    )
    if terminal_status == TERMINAL_WORK_REQUIRED and not work_items:
        _issue(validation_issues, "production_claim_lean_formalization_work_items_missing")

    checks = [
        _check("terminal_status_report_consumable", not _terminal_issues(terminal_report), "production_claim_lean_terminal_status_not_consumable"),
        _check("terminal_status_classified", bool(machine_checked or work_required), "production_claim_lean_work_item_dispatch_unclassified"),
        _check("formalization_work_items_present_when_required", terminal_status != TERMINAL_WORK_REQUIRED or bool(work_items), "production_claim_lean_formalization_work_items_missing"),
        _check("no_source_mutation", not terminal_report.get("source_mutation_performed"), "source_mutation_performed"),
        _check("no_external_action", not terminal_report.get("external_action_performed"), "external_action_performed"),
    ]
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in validation_issues)
    if forbidden:
        status = "FAIL"
        state = FAILED_STATE
        route = ""
        next_agent_stage = ""
        next_agent_command = ""
    elif validation_issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
        route = ""
        next_agent_stage = ""
        next_agent_command = ""
    elif machine_checked:
        status = "PASS"
        state = CLOSED_STATE
        route = "closed"
        next_agent_stage = ""
        next_agent_command = ""
    elif work_required:
        status = "PASS"
        state = READY_STATE
        route = "formalization"
        next_agent_stage = "lean_formalization_translation_and_proof"
        next_agent_command = _next_agent_command(terminal_report)
    else:
        status = "ATTENTION"
        state = ATTENTION_STATE
        route = ""
        next_agent_stage = ""
        next_agent_command = ""

    dispatch_packet = _dispatch_packet(terminal_report, route, work_items, next_agent_stage, next_agent_command)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "formal_verifier_production_claim_lean_work_item_dispatch_state": state,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "artifact_write_performed": False,
        "execution_performed": False,
        "prover_execution_performed": False,
        "network_performed": False,
        "secret_material_read_performed": False,
        "source_mutation_performed": False,
        "external_action_performed": False,
        "commit_performed": False,
        "formalization_work_item_dispatch_created": status in {"PASS", "ATTENTION"},
        "formalization_work_item_dispatch_ready": status == "PASS",
        "dispatch_route": route,
        "claim_packet_id": terminal_report.get("claim_packet_id") or "",
        "slug": terminal_report.get("slug") or "",
        "terminal_status": terminal_status,
        "production_claim_machine_checked": machine_checked,
        "formalization_work_required": work_required,
        "next_agent_stage": next_agent_stage,
        "next_agent_command": next_agent_command,
        "terminal_status_report_path": terminal_report.get("report_path") or "",
        "terminal_status_report_sha256": terminal_report.get("report_sha256") or "",
        "formalization_work_item_dispatch_packet_path": "",
        "formalization_work_item_dispatch_packet_sha256": "",
        "summary": {
            "validation_issue_count": len(validation_issues),
            "dispatch_ready_count": 1 if status == "PASS" else 0,
            "formalization_work_item_count": len(work_items),
            "required_output_count": sum(len(item.get("required_outputs") or []) for item in work_items),
            "acceptance_check_count": sum(len(item.get("acceptance_checks") or []) for item in work_items),
            "machine_checked_closed_count": 1 if machine_checked else 0,
            "production_claim_machine_checked_count": 1 if machine_checked else 0,
            "prover_execution_performed_count": 0,
            "network_performed_count": 0,
            "external_action_performed_count": 0,
            "source_mutation_performed_count": 0,
            "commit_performed_count": 0,
        },
        "checks": checks,
        "validation_issues": validation_issues,
        "formalization_work_item_dispatch_packet": dispatch_packet,
        "formalization_work_items": work_items,
        "terminal_status_report": terminal_report,
        "boundary": [
            "This command dispatches Lean formalization/proof work items only.",
            "It does not mark the production claim machine-checked unless the consumed terminal status is already MACHINE_CHECKED_FORMAL_CERTIFICATE_ACCEPTED.",
            "It does not execute Lean, mutate manuscript source/package/archive state, read secrets, call providers/models, upload, email, submit, send Telegram, or commit.",
        ],
    }


def formal_verifier_production_claim_lean_work_item_dispatch_markdown(report):
    lines = [
        "# paper_factory Production Claim Lean Work Item Dispatch",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('formal_verifier_production_claim_lean_work_item_dispatch_state') or ''}",
        f"- Route: {report.get('dispatch_route') or ''}",
        f"- Claim packet: {report.get('claim_packet_id') or ''}",
        f"- Next agent stage: {report.get('next_agent_stage') or ''}",
        f"- Production claim machine checked: {report.get('production_claim_machine_checked')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Work Items", ""])
    for item in report.get("formalization_work_items") or []:
        lines.append(f"- {item.get('work_item_id')}: {item.get('obligation_name') or ''}")
    if report.get("validation_issues"):
        lines.extend(["", "## Validation Issues", ""])
        for item in report.get("validation_issues") or []:
            lines.append(f"- {item.get('issue')}: {item.get('detail') or ''}".rstrip())
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
