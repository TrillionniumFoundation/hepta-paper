"""Map referee/review gaps into research-compute bridge jobs.

This module is still plan-only. It turns existing review/request rows into
bridge-plan gap specs and never executes compute, calls models, edits source, or
queues patches.
"""

from paperctl_modules import research_compute_bridge


COMMAND = "research-compute-gap-map"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "map_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "selected_requests",
    "gap_specs",
    "bridge_plan",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "input_request_count",
    "selected_request_count",
    "skipped_request_count",
    "gap_spec_count",
    "bridge_job_count",
    "proof_job_count",
    "experiment_job_count",
    "artifact_job_count",
    "reproducibility_job_count",
    "issue_count",
]
REPORT_SCHEMA_NOTES = [
    "Maps local referee/review request rows into research-compute bridge jobs.",
    "This is a spec-only mapper and does not execute compute or mutate manuscripts/packages/archives.",
]

COMPUTE_RELEVANT_STATUSES = {"requested", "assigned", "blocked"}

RISK_TO_GAP_KIND = {
    "artifact": "artifact",
    "artifact-boundary": "artifact",
    "direct-support": "artifact",
    "evidence-overclaim": "artifact",
    "evidence-resync": "artifact",
    "experiment": "experiment",
    "empirical": "experiment",
    "benchmark": "experiment",
    "reproducibility": "reproducibility",
    "process-boundary": "reproducibility",
    "process-trace": "reproducibility",
    "theory": "proof",
    "theory-boundary": "proof",
    "claim-downgrade": "proof",
    "proof": "proof",
}


def gap_kind_for_request(request):
    risk = str(request.get("risk_class") or "").strip().lower().replace("_", "-")
    if risk in RISK_TO_GAP_KIND:
        return RISK_TO_GAP_KIND[risk]
    text = " ".join([
        str(request.get("objection") or ""),
        str(request.get("proposed_fix") or ""),
        str(request.get("evidence_needed") or ""),
        str(request.get("verification") or ""),
    ]).lower()
    for needle, kind in [
        ("proof", "proof"),
        ("lemma", "proof"),
        ("theorem", "proof"),
        ("experiment", "experiment"),
        ("ablation", "experiment"),
        ("benchmark", "experiment"),
        ("reproduc", "reproducibility"),
        ("artifact", "artifact"),
        ("evidence", "artifact"),
    ]:
        if needle in text:
            return kind
    return "unknown"


def request_to_gap_spec(request):
    slug = research_compute_bridge.safe_slug(request.get("slug") or "UNSPECIFIED")
    kind = gap_kind_for_request(request)
    request_id = request.get("request_id") or ""
    risk = str(request.get("risk_class") or "").strip()
    detail_parts = [
        f"request_id={request_id}",
        f"risk_class={risk or 'unknown'}",
    ]
    for field in ["objection", "proposed_fix", "evidence_needed", "verification", "source_locator"]:
        value = " ".join(str(request.get(field) or "").split())
        if value:
            detail_parts.append(f"{field}={value[:240]}")
    return f"{slug}:{kind}:{' | '.join(detail_parts)}"


def select_compute_gap_requests(requests, statuses=None, include_closed=False, limit=0, request_ids=None, slugs=None):
    statuses = {str(item).strip() for item in (statuses or COMPUTE_RELEVANT_STATUSES) if str(item).strip()}
    request_ids = {int(item) for item in (request_ids or [])}
    slugs = {research_compute_bridge.safe_slug(item) for item in (slugs or []) if str(item or "").strip()}
    selected = []
    skipped = []
    for request in requests or []:
        request_id = int(request.get("request_id") or 0)
        slug = research_compute_bridge.safe_slug(request.get("slug") or "")
        status = str(request.get("status") or "").strip()
        if request_ids and request_id not in request_ids:
            skipped.append({"request_id": request_id, "slug": slug, "status": status, "reason": "request_id_filter"})
            continue
        if slugs and slug not in slugs:
            skipped.append({"request_id": request_id, "slug": slug, "status": status, "reason": "slug_filter"})
            continue
        if not include_closed and status not in statuses:
            skipped.append({"request_id": request_id, "slug": slug, "status": status, "reason": "status_not_compute_relevant"})
            continue
        selected.append(dict(request))
        if limit and len(selected) >= int(limit):
            break
    return selected, skipped


def research_compute_gap_map(requests=None, label="", statuses=None, include_closed=False, limit=0, request_ids=None, slugs=None):
    selected, skipped = select_compute_gap_requests(
        requests or [],
        statuses=statuses,
        include_closed=include_closed,
        limit=limit,
        request_ids=request_ids,
        slugs=slugs,
    )
    gap_specs = [request_to_gap_spec(request) for request in selected]
    bridge_plan = research_compute_bridge.research_compute_bridge_plan(
        slugs=slugs or sorted({request.get("slug") for request in selected if request.get("slug")}),
        gap_specs=gap_specs,
        label=label or "research-compute-gap-map",
    )
    issue_count = 0
    if bridge_plan.get("status") == "FAIL":
        issue_count += 1
    status = "PASS" if selected and bridge_plan.get("status") == "PASS" else "ATTENTION"
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "map_state": "BRIDGE_JOBS_MAPPED_NOT_EXECUTED" if selected else "NO_COMPUTE_RELEVANT_REVIEW_GAPS",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "summary": {
            "input_request_count": len(requests or []),
            "selected_request_count": len(selected),
            "skipped_request_count": len(skipped),
            "gap_spec_count": len(gap_specs),
            "bridge_job_count": (bridge_plan.get("summary") or {}).get("job_count", 0),
            "proof_job_count": (bridge_plan.get("summary") or {}).get("proof_job_count", 0),
            "experiment_job_count": (bridge_plan.get("summary") or {}).get("experiment_job_count", 0),
            "artifact_job_count": (bridge_plan.get("summary") or {}).get("artifact_job_count", 0),
            "reproducibility_job_count": (bridge_plan.get("summary") or {}).get("reproducibility_job_count", 0),
            "issue_count": issue_count,
        },
        "selected_requests": [
            {
                "request_id": request.get("request_id"),
                "slug": request.get("slug") or "",
                "status": request.get("status") or "",
                "risk_class": request.get("risk_class") or "",
                "gap_kind": gap_kind_for_request(request),
            }
            for request in selected
        ],
        "skipped_requests": skipped[:200],
        "gap_specs": gap_specs,
        "bridge_plan": bridge_plan,
        "boundary": [
            "This mapper reads local referee/review request records and creates bridge job specs only.",
            "It does not execute compute jobs, call providers/models, mutate source/package/archive state, or touch the patch queue.",
            "Mapped jobs still require research-compute-execute and later evidence ingestion/gating before any manuscript candidate exists.",
        ],
    }
    if bridge_plan.get("status") == "FAIL":
        report["status"] = "FAIL"
        report["map_state"] = "BRIDGE_JOB_MAPPING_INVALID"
    return report


def research_compute_gap_map_markdown(report):
    lines = [
        "# paper_factory Research Compute Gap Map",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Map state: {report.get('map_state') or ''}",
        f"- Execution performed: {report.get('execution_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Selected Requests", ""])
    for item in report.get("selected_requests") or []:
        lines.append(f"- `{item.get('request_id')}` `{item.get('slug')}` {item.get('risk_class')} -> {item.get('gap_kind')}")
    if not report.get("selected_requests"):
        lines.append("- No compute-relevant requests selected.")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
