"""Discover whether research-compute evidence can yield a manuscript patch draft.

This gate inspects existing research-compute evidence and queue artifacts. It
does not create a manuscript patch, mutate source/package/archive state, call
providers/models, merge queue rows, or commit.
"""

import json
import re


COMMAND = "research-compute-manuscript-patch-draft-discovery"
NO_INTENT_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_DRAFT_DISCOVERY_NO_SOURCE_CHANGE_INTENT"
READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_DRAFT_DISCOVERY_READY_FOR_MANUSCRIPT_PATCH_DRAFT_PREFLIGHT"
ATTENTION_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_DRAFT_DISCOVERY_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

MATERIAL_DISCOVERY_COMMAND = "research-compute-manuscript-source-material-discovery"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
REVIEW_QUEUE_SCOPES = {"candidate_note_review_queue_only", "candidate_note_patch_queue_only"}


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _safe_relative_path(path):
    text = str(path or "")
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _stringify(value):
    if value is None:
        return ""
    if isinstance(value, (dict, list)):
        return json.dumps(value, sort_keys=True, ensure_ascii=False)
    return str(value)


def _contains_unified_diff(text):
    value = text or ""
    return bool(
        "diff --git " in value
        or "```diff" in value.lower()
        or re.search(r"(?m)^---\s+\S+\n\+\+\+\s+\S+", value)
    )


def _contains_source_target_hint(text):
    value = text or ""
    return bool(
        re.search(r"(?i)(submission/|drafts/|source/|manuscript|\.tex\b|\.bib\b|\.sty\b|\.cls\b)", value)
    )


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "network_call_performed",
        "credential_lookup_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def validate_material_discovery_report(report):
    issues = []
    item = report or {}
    if item.get("command") != MATERIAL_DISCOVERY_COMMAND:
        issues.append({"issue": "material_discovery_command_mismatch", "detail": item.get("command") or ""})
    if item.get("status") != "PASS":
        issues.append({"issue": "material_discovery_not_pass", "detail": item.get("status") or ""})
    if item.get("source_mutation_apply_authorized"):
        issues.append({"issue": "material_discovery_apply_authorization_must_be_false"})
    for key in _boundary_keys():
        if item.get(key):
            issues.append({"issue": f"forbidden_material_discovery_boundary:{key}"})
    return issues


def validate_queue_artifact(queue_artifact):
    issues = []
    artifact = queue_artifact or {}
    if not artifact:
        issues.append({"issue": "queue_artifact_required"})
        return issues
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") and artifact.get("queue_scope") not in REVIEW_QUEUE_SCOPES:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    candidate_note = artifact.get("candidate_note_path") or ""
    if candidate_note and not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    candidate_sha = artifact.get("candidate_note_sha256") or ""
    if candidate_sha and not _valid_sha256(candidate_sha):
        issues.append({"issue": "invalid_candidate_note_sha256"})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_expected_review_only_not_applyable"})
    for key in _boundary_keys():
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary:{key}"})
    return issues


def validate_evidence_workspace(evidence_workspace):
    issues = []
    workspace = evidence_workspace or {}
    if not workspace.get("exists"):
        issues.append({"issue": "evidence_workspace_missing", "detail": workspace.get("path") or ""})
    expected = {
        "candidate-patch-plan.json",
        "command-material.json",
        "execution-manifest.json",
        "metrics.json",
        "output-hashes.json",
    }
    files = {item.get("name"): item for item in workspace.get("files") or []}
    for name in sorted(expected):
        if not (files.get(name) or {}).get("exists"):
            issues.append({"issue": "evidence_file_missing", "detail": name})
    plan = workspace.get("candidate_patch_plan") or {}
    if plan.get("source_mutation_performed") or plan.get("patch_queue_mutation_performed"):
        issues.append({"issue": "forbidden_candidate_patch_plan_mutation"})
    manifest = workspace.get("execution_manifest") or {}
    if manifest and manifest.get("returncode") not in (0, "0"):
        issues.append({"issue": "evidence_execution_nonzero", "detail": manifest.get("returncode")})
    return issues


def evidence_signals(evidence_workspace):
    workspace = evidence_workspace or {}
    texts = []
    for key in [
        "candidate_patch_plan",
        "command_material",
        "execution_manifest",
        "metrics",
        "output_hashes",
        "stdout",
        "stderr",
    ]:
        texts.append(_stringify(workspace.get(key)))
    for item in workspace.get("files") or []:
        texts.append(_stringify(item.get("text_preview") or ""))
    combined = "\n".join(texts)

    plan = workspace.get("candidate_patch_plan") or {}
    metrics = workspace.get("metrics") or {}
    candidate_patch_generated = plan.get("candidate_patch_generated") is True
    candidate_plan_negative = plan.get("candidate_patch_generated") is False
    executor_smoke_only = metrics.get("executor_smoke") is True and candidate_plan_negative
    contains_unified_diff = _contains_unified_diff(combined)
    contains_source_target_hint = _contains_source_target_hint(combined)
    source_change_intent = bool(candidate_patch_generated or contains_unified_diff or contains_source_target_hint)
    draft_ready = bool(candidate_patch_generated and contains_unified_diff and contains_source_target_hint)

    return {
        "evidence_workspace_exists": bool(workspace.get("exists")),
        "evidence_file_count": len([item for item in workspace.get("files") or [] if item.get("exists")]),
        "candidate_patch_generated": candidate_patch_generated,
        "candidate_patch_plan_negative": candidate_plan_negative,
        "executor_smoke_only": executor_smoke_only,
        "contains_unified_diff": contains_unified_diff,
        "contains_source_target_hint": contains_source_target_hint,
        "source_change_intent_present": source_change_intent,
        "manuscript_patch_draft_ready": draft_ready,
    }


def research_compute_manuscript_patch_draft_discovery(
    material_discovery_report,
    queue_artifact,
    evidence_workspace,
    source_target_snapshot=None,
    label="",
):
    material_discovery_report = material_discovery_report or {}
    queue_artifact = queue_artifact or {}
    evidence_workspace = evidence_workspace or {}
    source_target_snapshot = source_target_snapshot or {}

    issues = []
    issues.extend(validate_material_discovery_report(material_discovery_report))
    issues.extend(validate_queue_artifact(queue_artifact))
    issues.extend(validate_evidence_workspace(evidence_workspace))
    signals = evidence_signals(evidence_workspace)

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif signals["manuscript_patch_draft_ready"]:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = NO_INTENT_STATE

    draft_ready = state == READY_STATE
    if state == NO_INTENT_STATE:
        if signals["executor_smoke_only"]:
            blocked_reason = "evidence_contains_executor_smoke_only_no_source_change_intent"
        else:
            blocked_reason = "evidence_contains_no_applyable_manuscript_patch_draft_material"
    elif state == ATTENTION_STATE:
        blocked_reason = "evidence_material_requires_manual_disambiguation"
    elif state == FORBIDDEN_STATE:
        blocked_reason = "forbidden_boundary_crossed"
    else:
        blocked_reason = ""

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_patch_draft_discovery_state": state,
        "manuscript_patch_draft_discovery_created": status == "PASS",
        "material_discovery_report_status": material_discovery_report.get("status") or "",
        "material_discovery_report_state": material_discovery_report.get("manuscript_source_material_discovery_state") or "",
        "queue_artifact_reviewed": status == "PASS",
        "evidence_workspace_reviewed": status == "PASS",
        "source_target_path": source_target_snapshot.get("path") or "",
        "source_target_exists": bool(source_target_snapshot.get("exists")),
        "source_change_intent_present": bool(signals["source_change_intent_present"]),
        "manuscript_patch_draft_generated": False,
        "manuscript_patch_draft_generation_ready": draft_ready,
        "ready_for_manuscript_patch_draft_preflight": draft_ready,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "evidence_file_count": signals["evidence_file_count"],
            "source_change_intent_count": 1 if signals["source_change_intent_present"] else 0,
            "unified_diff_count": 1 if signals["contains_unified_diff"] else 0,
            "target_source_path_hint_count": 1 if signals["contains_source_target_hint"] else 0,
            "manuscript_patch_draft_generated_count": 0,
            "manuscript_patch_draft_ready_count": 1 if draft_ready else 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "evidence_signals": signals,
        "material_discovery_reference": {
            "report_path": material_discovery_report.get("report_path") or "",
            "status": material_discovery_report.get("status") or "",
            "state": material_discovery_report.get("manuscript_source_material_discovery_state") or "",
            "selected_patch_id": int(material_discovery_report.get("selected_patch_id") or 0),
        },
        "queue_artifact_reference": {
            "artifact_type": queue_artifact.get("artifact_type") or "",
            "queue_scope": queue_artifact.get("queue_scope") or "",
            "slug": queue_artifact.get("slug") or "",
            "candidate_note_path": queue_artifact.get("candidate_note_path") or "",
            "candidate_note_sha256": queue_artifact.get("candidate_note_sha256") or "",
            "queue_artifact_applyable_patch": queue_artifact.get("queue_artifact_applyable_patch"),
        },
        "evidence_workspace_snapshot": evidence_workspace,
        "source_target_snapshot": source_target_snapshot,
        "patch_draft_discovery_packet": {
            "slug": queue_artifact.get("slug") or material_discovery_report.get("slug") or "",
            "job_id": (evidence_workspace.get("execution_manifest") or {}).get("job_id") or "",
            "source_change_intent_present": bool(signals["source_change_intent_present"]),
            "manuscript_patch_draft_generated": False,
            "manuscript_patch_draft_generation_ready": draft_ready,
            "blocked_reason": blocked_reason,
            "required_next_gate": "research_compute_manuscript_patch_draft_preflight" if draft_ready else "provide_source_change_intent_or_patch_material",
            "source_mutation_apply_authorized": False,
        },
        "boundary": [
            "This command inspects research-compute evidence to decide whether an independent manuscript patch draft can be justified.",
            "It does not generate or apply a patch, mutate source/package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "Executor-smoke evidence without source-change intent must not be inflated into a manuscript patch.",
        ],
    }


def research_compute_manuscript_patch_draft_discovery_markdown(report):
    packet = report.get("patch_draft_discovery_packet") or {}
    lines = [
        "# paper_factory Research Compute Manuscript Patch Draft Discovery",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_patch_draft_discovery_state') or ''}",
        f"- Source change intent present: {report.get('source_change_intent_present')}",
        f"- Manuscript patch draft generated: {report.get('manuscript_patch_draft_generated')}",
        f"- Draft generation ready: {report.get('manuscript_patch_draft_generation_ready')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Discovery Packet", ""])
    lines.append(f"- Blocked reason: `{packet.get('blocked_reason') or ''}`")
    lines.append(f"- Required next gate: `{packet.get('required_next_gate') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
