"""Preflight a materialized manuscript patch draft before any source apply.

This gate checks that a local unified-diff draft is still applyable against the
current manuscript source and remains inside the selected target file. It does
not apply the patch, mutate source/package/archive state, call providers/models,
merge queue rows, or commit.
"""


COMMAND = "research-compute-manuscript-patch-draft-preflight"
READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_DRAFT_PREFLIGHT_READY_FOR_APPLY_GATE"
ATTENTION_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_DRAFT_PREFLIGHT_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

MATERIALIZATION_COMMAND = "research-compute-manuscript-patch-worker-materialization"
MATERIALIZATION_READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_WORKER_MATERIALIZATION_DRAFT_READY_NOT_APPLIED"
CLAIM_MATERIALIZATION_COMMAND = "research-compute-claim-manuscript-patch-materialization"
CLAIM_MATERIALIZATION_READY_STATE = "RESEARCH_COMPUTE_CLAIM_MANUSCRIPT_PATCH_MATERIALIZATION_DRAFT_READY_NOT_APPLIED"


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "network_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _safe_relative_path(path):
    text = str(path or "").strip()
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def parse_patch_changed_paths(patch_text):
    paths = []
    for line in (patch_text or "").splitlines():
        if not line.startswith("diff --git "):
            continue
        parts = line.split()
        if len(parts) < 4:
            continue
        left = parts[2][2:] if parts[2].startswith("a/") else parts[2]
        right = parts[3][2:] if parts[3].startswith("b/") else parts[3]
        if left == right and left not in paths:
            paths.append(left)
        elif left not in paths:
            paths.append(left)
        elif right not in paths:
            paths.append(right)
    return paths


def expected_boundary_text(report):
    risk_class = (report or {}).get("selected_risk_class")
    if str(risk_class or "").startswith("claim-"):
        return "Research compute claim boundary"
    if risk_class == "artifact-anchor":
        return "Artifact anchor"
    if risk_class == "reproducibility-protocol":
        return "Reproducibility protocol boundary"
    if risk_class == "anonymity-process":
        return "Anonymity/process boundary"
    if risk_class == "patch-scope":
        return "Patch-scope boundary"
    return "Assumption-risk boundary"


def _quality_gated_claim_boundary_replacement(report, patch_text, boundary_text):
    risk_class = (report or {}).get("selected_risk_class")
    if not str(risk_class or "").startswith("claim-"):
        return False
    if not (report or {}).get("claim_quality_gate_ready"):
        return False
    if boundary_text not in (patch_text or ""):
        return False
    return "\n-" in (patch_text or "") and "\n+" in (patch_text or "")


def validate_preflight_inputs(materialization_report, patch_snapshot, source_snapshot, git_apply_check, patch_text, source_text):
    issues = []
    report = materialization_report or {}
    patch_snapshot = patch_snapshot or {}
    source_snapshot = source_snapshot or {}
    git_apply_check = git_apply_check or {}

    command = report.get("command")
    if command not in {MATERIALIZATION_COMMAND, CLAIM_MATERIALIZATION_COMMAND}:
        issues.append({"issue": "materialization_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "materialization_not_pass", "detail": report.get("status") or ""})
    state = (
        report.get("claim_manuscript_patch_materialization_state")
        if command == CLAIM_MATERIALIZATION_COMMAND
        else report.get("manuscript_patch_worker_materialization_state")
    )
    expected_state = (
        CLAIM_MATERIALIZATION_READY_STATE
        if command == CLAIM_MATERIALIZATION_COMMAND
        else MATERIALIZATION_READY_STATE
    )
    if state != expected_state:
        issues.append({"issue": "materialization_not_ready", "detail": state or ""})
    if not report.get("patch_draft_generated"):
        issues.append({"issue": "patch_draft_not_generated"})
    if report.get("patch_draft_applied"):
        issues.append({"issue": "patch_draft_already_applied"})
    if not report.get("ready_for_manuscript_patch_draft_preflight"):
        issues.append({"issue": "materialization_not_ready_for_preflight"})
    for key in _boundary_keys():
        if report.get(key):
            issues.append({"issue": f"forbidden_materialization_boundary:{key}"})

    target_path = report.get("source_target_path") or ""
    if not _safe_relative_path(target_path):
        issues.append({"issue": "unsafe_source_target_path", "detail": target_path})
    if not source_snapshot.get("exists"):
        issues.append({"issue": "source_target_missing", "detail": target_path})
    source_sha = source_snapshot.get("sha256") or ""
    expected_source_sha = report.get("source_target_sha256") or report.get("source_target_expected_sha256") or ""
    if source_sha and expected_source_sha and source_sha != expected_source_sha:
        issues.append({"issue": "source_target_sha256_mismatch", "expected": expected_source_sha, "observed": source_sha})

    patch = report.get("patch_draft") or {}
    patch_file_path = patch_snapshot.get("path") or ""
    if patch_file_path and not _safe_relative_path(patch_file_path):
        issues.append({"issue": "unsafe_patch_file_path", "detail": patch_file_path})
    if not patch_snapshot.get("exists"):
        issues.append({"issue": "patch_file_missing", "detail": patch_file_path})
    if not patch_text:
        issues.append({"issue": "patch_text_missing"})
    expected_patch_sha = patch.get("patch_file_sha256") or ""
    actual_patch_sha = patch_snapshot.get("sha256") or ""
    if expected_patch_sha and actual_patch_sha and expected_patch_sha != actual_patch_sha:
        issues.append({"issue": "patch_file_sha256_mismatch", "expected": expected_patch_sha, "observed": actual_patch_sha})

    changed_paths = parse_patch_changed_paths(patch_text)
    if not changed_paths:
        issues.append({"issue": "patch_changed_paths_missing"})
    if target_path and changed_paths != [target_path]:
        issues.append({"issue": "patch_changed_paths_outside_target", "expected": target_path, "observed": changed_paths})
    if "--- /dev/null" in patch_text or "+++ /dev/null" in patch_text:
        issues.append({"issue": "patch_creates_or_deletes_file"})
    boundary_text = expected_boundary_text(report)
    if boundary_text not in patch_text:
        issues.append({"issue": "expected_boundary_text_missing_from_patch"})
    if boundary_text in (source_text or "") and not _quality_gated_claim_boundary_replacement(report, patch_text, boundary_text):
        issues.append({"issue": "patch_text_already_present_in_source"})

    if not git_apply_check.get("performed"):
        issues.append({"issue": "git_apply_check_not_performed"})
    elif not git_apply_check.get("passed"):
        issues.append(
            {
                "issue": "git_apply_check_failed",
                "returncode": git_apply_check.get("returncode"),
                "stderr": git_apply_check.get("stderr") or "",
            }
        )

    return issues


def research_compute_manuscript_patch_draft_preflight(
    materialization_report,
    patch_snapshot,
    source_snapshot,
    git_apply_check,
    patch_text,
    source_text,
    label="",
):
    materialization_report = materialization_report or {}
    patch_snapshot = patch_snapshot or {}
    source_snapshot = source_snapshot or {}
    git_apply_check = git_apply_check or {}
    patch_text = patch_text or ""
    issues = validate_preflight_inputs(
        materialization_report,
        patch_snapshot,
        source_snapshot,
        git_apply_check,
        patch_text,
        source_text or "",
    )
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    ready = state == READY_STATE
    changed_paths = parse_patch_changed_paths(patch_text)
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_patch_draft_preflight_state": state,
        "patch_draft_preflight_created": ready,
        "slug": materialization_report.get("slug") or "",
        "materialization_report_path": materialization_report.get("report_path") or "",
        "materialization_report_sha256": materialization_report.get("report_sha256") or "",
        "claim_quality_gate_ready": bool(materialization_report.get("claim_quality_gate_ready")),
        "selected_request_id": materialization_report.get("selected_request_id") or "",
        "selected_risk_class": materialization_report.get("selected_risk_class") or "",
        "source_target_path": materialization_report.get("source_target_path") or "",
        "source_target_exists": bool(source_snapshot.get("exists")),
        "source_target_sha256": source_snapshot.get("sha256") or "",
        "source_target_expected_sha256": materialization_report.get("source_target_sha256") or materialization_report.get("source_target_expected_sha256") or "",
        "patch_file_path": patch_snapshot.get("path") or "",
        "patch_file_exists": bool(patch_snapshot.get("exists")),
        "patch_file_sha256": patch_snapshot.get("sha256") or "",
        "patch_file_expected_sha256": (materialization_report.get("patch_draft") or {}).get("patch_file_sha256") or "",
        "patch_file_bytes": patch_snapshot.get("size_bytes") or 0,
        "patch_changed_paths": changed_paths,
        "patch_changed_path_count": len(changed_paths),
        "git_apply_check_performed": bool(git_apply_check.get("performed")),
        "git_apply_check_returncode": git_apply_check.get("returncode"),
        "git_apply_check_passed": bool(git_apply_check.get("passed")),
        "ready_for_manuscript_source_apply_gate": ready,
        "required_next_gate": "research_compute_manuscript_source_apply_gate" if ready else COMMAND.replace("-", "_"),
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "patch_changed_path_count": len(changed_paths),
            "git_apply_check_passed_count": 1 if git_apply_check.get("passed") else 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "git_apply_check": {
            "performed": bool(git_apply_check.get("performed")),
            "returncode": git_apply_check.get("returncode"),
            "passed": bool(git_apply_check.get("passed")),
            "stdout": git_apply_check.get("stdout") or "",
            "stderr": git_apply_check.get("stderr") or "",
        },
        "boundary": [
            "This command only checks a local manuscript patch draft and records a preflight report.",
            "It does not apply the patch, mutate source/package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "A separate source apply gate is required before any manuscript source file can be changed.",
        ],
    }


def research_compute_manuscript_patch_draft_preflight_markdown(report):
    lines = [
        "# paper_factory Research Compute Manuscript Patch Draft Preflight",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_patch_draft_preflight_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Request: `{report.get('selected_request_id') or ''}` `{report.get('selected_risk_class') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Patch file: `{report.get('patch_file_path') or ''}`",
        f"- git apply --check passed: {report.get('git_apply_check_passed')}",
        f"- Ready for source apply gate: {report.get('ready_for_manuscript_source_apply_gate')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
