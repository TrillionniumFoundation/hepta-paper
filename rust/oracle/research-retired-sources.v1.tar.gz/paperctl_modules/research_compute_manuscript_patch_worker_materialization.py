"""Materialize a manuscript patch draft from a prepared material packet.

This gate turns one selected source-change request into a local unified-diff
draft under logs. It does not apply the diff, enqueue/merge queue rows, mutate
source/package/archive state, call providers/models, or commit.
"""

import difflib


COMMAND = "research-compute-manuscript-patch-worker-materialization"
READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_WORKER_MATERIALIZATION_DRAFT_READY_NOT_APPLIED"
ATTENTION_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_WORKER_MATERIALIZATION_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

MATERIAL_PACKET_COMMAND = "research-compute-manuscript-source-change-material-packet"
MATERIAL_PACKET_READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_CHANGE_MATERIAL_PACKET_READY_FOR_PATCH_WORKER_MATERIALIZATION"


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "network_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _safe_relative_path(path):
    text = str(path or "").strip()
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _request_from_material_packet(packet):
    material = packet or {}
    selected = material.get("selected_next_request") or {}
    selected_id = str(selected.get("request_id") or "")
    if selected:
        return selected
    for item in material.get("source_change_requests") or []:
        if str(item.get("request_id") or "") == selected_id:
            return item
    return {}


def validate_material_packet(material_packet, source_snapshot):
    issues = []
    packet = material_packet or {}
    if packet.get("command") != MATERIAL_PACKET_COMMAND:
        issues.append({"issue": "material_packet_command_mismatch", "detail": packet.get("command") or ""})
    if packet.get("status") != "PASS":
        issues.append({"issue": "material_packet_not_pass", "detail": packet.get("status") or ""})
    if packet.get("manuscript_source_change_material_packet_state") != MATERIAL_PACKET_READY_STATE:
        issues.append({"issue": "material_packet_not_ready", "detail": packet.get("manuscript_source_change_material_packet_state") or ""})
    if not packet.get("ready_for_patch_worker_materialization"):
        issues.append({"issue": "patch_worker_materialization_not_ready"})
    for key in _boundary_keys():
        if packet.get(key):
            issues.append({"issue": f"forbidden_material_packet_boundary:{key}"})

    source_path = packet.get("source_target_path") or ""
    if source_path and not _safe_relative_path(source_path):
        issues.append({"issue": "unsafe_source_target_path", "detail": source_path})
    if not (source_snapshot or {}).get("exists"):
        issues.append({"issue": "source_target_missing", "detail": source_path})
    expected_sha = packet.get("source_target_sha256") or ""
    actual_sha = (source_snapshot or {}).get("sha256") or ""
    if expected_sha and actual_sha and expected_sha != actual_sha:
        issues.append({"issue": "source_target_sha256_mismatch", "expected": expected_sha, "observed": actual_sha})

    request = _request_from_material_packet(packet)
    if not request:
        issues.append({"issue": "selected_next_request_missing"})
    elif (request.get("request_id"), request.get("risk_class")) not in {
        ("01", "theory-boundary"),
        ("02", "artifact-anchor"),
        ("03", "reproducibility-protocol"),
        ("04", "anonymity-process"),
        ("05", "patch-scope"),
    }:
        issues.append({"issue": "unsupported_selected_request_for_materializer", "detail": request.get("risk_class") or ""})
    if request and request.get("evidence_status") == "candidate_found" and not request.get("evidence_paths"):
        issues.append({"issue": "selected_request_candidate_evidence_missing"})
    return issues


def _assumption_boundary_paragraph():
    return [
        "\\paragraph{Assumption-risk boundary.}\n",
        "The theorem-level claims below are limited to the local recovered-experiment rows audited in\n",
        "\\path{artifact/ndu_aos_assumption_risk_boundary_ledger.json}: the identified nonrecursive subclass,\n",
        "value-jet measurement and scale, shifter exclusion and support, generated-regressor rates,\n",
        "diffusion-source handling, scoped numerical diagnostics, and local package readiness. The ledger and\n",
        "its checker record retained non-claims and failure conditions; they do not certify the full recursive\n",
        "NDU envelope, behavior-only identification, external empirical validation, or theorem validity outside\n",
        "the stated projection, support, rate, diffusion, and calibration assumptions.\n",
        "\n",
    ]


def materialize_theory_boundary_patch(source_text):
    old_lines = (source_text or "").splitlines(keepends=True)
    if not old_lines:
        return "", False, "empty_source"
    marker = "\\paragraph{Statement scope.}"
    insert_at = None
    for index, line in enumerate(old_lines):
        if line.startswith(marker):
            insert_at = index
            break
    if insert_at is None:
        return "", False, "statement_scope_marker_missing"
    paragraph = _assumption_boundary_paragraph()
    paragraph_text = "".join(paragraph)
    if paragraph_text in "".join(old_lines):
        return "", False, "patch_text_already_present"
    new_lines = old_lines[:insert_at] + paragraph + old_lines[insert_at:]
    return new_lines, True, ""


def _selected_evidence_payloads(material_packet):
    return list((material_packet or {}).get("selected_evidence_payloads") or [])


def _payload_by_kind(material_packet, kind):
    for payload in _selected_evidence_payloads(material_packet):
        data = payload.get("json") or {}
        if data.get("kind") == kind:
            return payload
    return {}


def _payload_by_schema(material_packet, schema):
    for payload in _selected_evidence_payloads(material_packet):
        data = payload.get("json") or {}
        if data.get("schema") == schema:
            return payload
    return {}


def _artifact_anchor_summary(material_packet):
    calibration = (_payload_by_kind(material_packet, "ndu_aos_calibration_audit_check").get("json") or {})
    clean_zip = (_payload_by_kind(material_packet, "ndu_aos_clean_zip_manifest_audit").get("json") or {})
    calibration_summary = calibration.get("summary") or {}
    return {
        "calibration_audit_status": calibration_summary.get("status") or "",
        "calibration_audit_checks": calibration_summary.get("checks") or 0,
        "calibration_audit_failures": calibration_summary.get("failures") or 0,
        "calibration_design_rows": calibration_summary.get("design_rows") or 0,
        "calibration_csv_sha256": calibration_summary.get("csv_sha256") or "",
        "clean_zip_status": clean_zip.get("status") or "",
        "clean_zip_check_count": clean_zip.get("check_count") or 0,
        "clean_zip_failure_count": clean_zip.get("failure_count") or 0,
        "clean_zip_expected_entries": clean_zip.get("expected_entries") or 0,
        "clean_zip_sha256": clean_zip.get("zip_sha256") or "",
    }


def _anonymity_boundary_summary(material_packet):
    results = (_payload_by_kind(material_packet, "ndu_aos_anonymity_identity_redaction_boundary_check").get("json") or {})
    ledger = (_payload_by_schema(material_packet, "ndu_aos_anonymity_identity_redaction_boundary.v1").get("json") or {})
    portal = (_payload_by_schema(material_packet, "ndu_aos_portal_action_boundary.v1").get("json") or {})
    return {
        "anonymity_audit_status": results.get("status") or "",
        "anonymity_audit_checks": results.get("check_count") or 0,
        "anonymity_audit_failures": results.get("failure_count") or 0,
        "anonymity_row_count": results.get("row_count") or 0,
        "anonymity_ledger_sha256": results.get("ledger_sha256") or "",
        "anonymity_zip_sha256": results.get("zip_sha256") or "",
        "anonymity_nonclaim": results.get("nonclaim") or ledger.get("nonclaim") or "",
        "portal_schema": portal.get("schema") or "",
        "portal_nonclaim": portal.get("nonclaim") or "",
    }


def _reproducibility_boundary_summary(material_packet):
    replication = (_payload_by_kind(material_packet, "ndu_aos_external_independent_replication_boundary_check").get("json") or {})
    clean_zip = (_payload_by_kind(material_packet, "ndu_aos_clean_zip_manifest_audit").get("json") or {})
    final_handoff = (_payload_by_schema(material_packet, "ndu_aos_final_handoff_boundary.v1").get("json") or {})
    portal = (_payload_by_schema(material_packet, "ndu_aos_portal_action_boundary.v1").get("json") or {})
    return {
        "replication_boundary_status": replication.get("status") or "",
        "replication_boundary_checks": replication.get("check_count") or 0,
        "replication_boundary_failures": replication.get("failure_count") or 0,
        "replication_boundary_rows": replication.get("row_count") or 0,
        "replication_ledger_sha256": replication.get("ledger_sha256") or "",
        "replication_zip_sha256": replication.get("zip_sha256") or "",
        "clean_zip_status": clean_zip.get("status") or "",
        "clean_zip_check_count": clean_zip.get("check_count") or 0,
        "clean_zip_expected_entries": clean_zip.get("expected_entries") or 0,
        "clean_zip_sha256": clean_zip.get("zip_sha256") or "",
        "final_handoff_schema": final_handoff.get("schema") or "",
        "portal_schema": portal.get("schema") or "",
    }


def _patch_scope_summary(material_packet):
    prior_verified = []
    for reference in (material_packet or {}).get("prior_references") or []:
        if reference.get("command") != "research-compute-manuscript-source-post-apply-verify":
            continue
        if reference.get("status") != "PASS":
            continue
        if reference.get("manuscript_source_post_apply_verify_state") != "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_POST_APPLY_VERIFY_VERIFIED":
            continue
        prior_verified.append(
            {
                "request_id": reference.get("selected_request_id") or "",
                "risk_class": reference.get("selected_risk_class") or "",
                "report_path": reference.get("prior_report_path") or reference.get("report_path") or "",
                "source_after_sha256": reference.get("source_after_sha256") or "",
            }
        )
    applied_ids = [str(item) for item in (material_packet or {}).get("applied_request_ids") or []]
    return {
        "applied_request_ids": applied_ids,
        "prior_verified_post_apply_count": len(prior_verified),
        "prior_verified_requests": prior_verified,
        "prior_applied_request_count": material_packet.get("prior_applied_request_count") or len(applied_ids),
        "eligible_source_change_request_count": material_packet.get("eligible_source_change_request_count") or 0,
        "selected_evidence_status": ((_request_from_material_packet(material_packet) or {}).get("evidence_status") or ""),
        "selected_patch_scope": ((_request_from_material_packet(material_packet) or {}).get("patch_scope") or ""),
    }


def _evidence_anchor_summary(material_packet, request):
    risk_class = (request or {}).get("risk_class")
    if risk_class == "artifact-anchor":
        return _artifact_anchor_summary(material_packet)
    if risk_class == "reproducibility-protocol":
        return _reproducibility_boundary_summary(material_packet)
    if risk_class == "anonymity-process":
        return _anonymity_boundary_summary(material_packet)
    if risk_class == "patch-scope":
        return _patch_scope_summary(material_packet)
    return {}


def _artifact_anchor_paragraph(material_packet):
    summary = _artifact_anchor_summary(material_packet)
    required = [
        "calibration_audit_status",
        "calibration_audit_checks",
        "calibration_design_rows",
        "calibration_csv_sha256",
        "clean_zip_status",
        "clean_zip_check_count",
        "clean_zip_expected_entries",
        "clean_zip_sha256",
    ]
    missing = [key for key in required if not summary.get(key)]
    if missing:
        return [], "artifact_anchor_evidence_payload_missing:" + ",".join(missing)
    return [
        "\\paragraph{Artifact anchor.}\n",
        "The manuscript's local calibration-diagnostic language is anchored to\n",
        "\\path{artifact/ndu_aos_calibration_audit_check_results.json} and\n",
        "\\path{artifact/ndu_aos_calibration_audit_check_results.md}: status\n",
        f"{summary['calibration_audit_status']}, {summary['calibration_audit_checks']} checks,\n",
        f"{summary['calibration_design_rows']} design rows, calibration CSV SHA-256\n",
        f"\\path{{{summary['calibration_csv_sha256']}}}. The clean-source packaging statement is\n",
        "anchored to \\path{artifact/ndu_aos_clean_zip_manifest_audit_results.json} and\n",
        "\\path{artifact/ndu_aos_clean_zip_manifest_audit_results.md}: status\n",
        f"{summary['clean_zip_status']}, {summary['clean_zip_check_count']} checks,\n",
        f"{summary['clean_zip_expected_entries']} expected ZIP entries, ZIP SHA-256\n",
        f"\\path{{{summary['clean_zip_sha256']}}}. These local audit artifacts certify only the\n",
        "executable diagnostic table and clean-source manifest consistency; they are not\n",
        "external empirical validation, external review, submission, acceptance, or evidence\n",
        "for claims outside the model, assumptions, and limitations stated here.\n",
        "\n",
    ], ""


def _anonymity_boundary_paragraph(material_packet):
    summary = _anonymity_boundary_summary(material_packet)
    required = [
        "anonymity_audit_status",
        "anonymity_audit_checks",
        "anonymity_row_count",
        "anonymity_ledger_sha256",
        "anonymity_zip_sha256",
        "portal_schema",
    ]
    missing = [key for key in required if not summary.get(key)]
    if missing:
        return [], "anonymity_process_evidence_payload_missing:" + ",".join(missing)
    return [
        "\\paragraph{Anonymity/process boundary.}\n",
        "The manuscript-facing anonymity and process statements are limited to local package/readiness\n",
        "checks recorded in \\path{artifact/ndu_aos_anonymity_identity_redaction_boundary_results.json}\n",
        "and \\path{artifact/ndu_aos_anonymity_identity_redaction_boundary_ledger.json}: status\n",
        f"{summary['anonymity_audit_status']}, {summary['anonymity_audit_checks']} checks,\n",
        f"{summary['anonymity_row_count']} boundary rows, ledger SHA-256\n",
        f"\\path{{{summary['anonymity_ledger_sha256']}}}, clean ZIP SHA-256\n",
        f"\\path{{{summary['anonymity_zip_sha256']}}}. The portal-action boundary is local to\n",
        f"\\path{{artifact/ndu_aos_portal_action_boundary_ledger.json}} ({summary['portal_schema']}).\n",
        "These files are not anonymous-review compliance certification, double-blind compliance\n",
        "certification, venue anonymity clearance, metadata redaction certification, upload,\n",
        "submission, external receipt, external decision, acceptance, or Strong Accept evidence.\n",
        "\n",
    ], ""


def _reproducibility_boundary_paragraph(material_packet):
    summary = _reproducibility_boundary_summary(material_packet)
    required = [
        "replication_boundary_status",
        "replication_boundary_checks",
        "replication_boundary_rows",
        "replication_ledger_sha256",
        "replication_zip_sha256",
        "clean_zip_status",
        "clean_zip_check_count",
        "clean_zip_expected_entries",
        "clean_zip_sha256",
        "final_handoff_schema",
        "portal_schema",
    ]
    missing = [key for key in required if not summary.get(key)]
    if missing:
        return [], "reproducibility_protocol_evidence_payload_missing:" + ",".join(missing)
    return [
        "\\paragraph{Reproducibility protocol boundary.}\n",
        "The local regeneration and replay route for this manuscript is the workspace/package route\n",
        "described by \\path{README.local-compile.md}, \\path{MANIFEST.sha256}, and the local commands\n",
        "\\texttt{python3 artifact/ndu_aos_package_self_replay_check.py},\n",
        "\\texttt{python3 artifact/ndu_aos_clean_zip_manifest_audit.py}, and\n",
        "\\texttt{python3 artifact/ndu_aos_extracted_package_replay_check.py}. The external-independent\n",
        "replication boundary file \\path{artifact/ndu_aos_external_independent_replication_boundary_results.json}\n",
        f"records status {summary['replication_boundary_status']}, {summary['replication_boundary_checks']} checks,\n",
        f"{summary['replication_boundary_rows']} rows, ledger SHA-256\n",
        f"\\path{{{summary['replication_ledger_sha256']}}}, and ZIP SHA-256\n",
        f"\\path{{{summary['replication_zip_sha256']}}}. The clean ZIP manifest audit records status\n",
        f"{summary['clean_zip_status']}, {summary['clean_zip_check_count']} checks,\n",
        f"{summary['clean_zip_expected_entries']} expected entries, ZIP SHA-256\n",
        f"\\path{{{summary['clean_zip_sha256']}}}. These local replay, manifest, and boundary files\n",
        f"({summary['final_handoff_schema']}; {summary['portal_schema']}) are not independent\n",
        "replication, third-party reproduction, external raw-data rerun, external validation,\n",
        "external review, upload, submission, acceptance, or Strong Accept evidence.\n",
        "\n",
    ], ""


def _patch_scope_boundary_paragraph(material_packet):
    summary = _patch_scope_summary(material_packet)
    applied_ids = summary.get("applied_request_ids") or []
    verified_count = summary.get("prior_verified_post_apply_count") or 0
    if summary.get("selected_evidence_status") != "process_required":
        return [], "patch_scope_process_evidence_status_missing"
    if verified_count < len(applied_ids):
        return [], "patch_scope_verified_post_apply_reports_incomplete"
    if not applied_ids:
        return [], "patch_scope_applied_request_ids_missing"
    applied_text = ", ".join(applied_ids)
    return [
        "\\paragraph{Patch-scope boundary.}\n",
        "This revision records the referee-response work as bounded local patch gates, not as a\n",
        "broad rewrite or an unreviewed source sweep. Requests\n",
        f"{applied_text} have local post-apply verification reports, and each manuscript change above\n",
        "is tied to a single selected request, a local patch draft, a preflight check, an apply gate,\n",
        "and a post-apply verification gate. The remaining patch-scope checklist item is therefore a\n",
        "process boundary: any later queue merge, supersede, package/archive refresh, upload,\n",
        "submission, external review, acceptance, or Strong Accept claim requires a separate gate and\n",
        "is not implied by these manuscript edits.\n",
        "\n",
    ], ""


def materialize_artifact_anchor_patch(source_text, material_packet):
    old_lines = (source_text or "").splitlines(keepends=True)
    if not old_lines:
        return "", False, "empty_source"
    if "\\paragraph{Artifact anchor.}" in "".join(old_lines):
        return "", False, "patch_text_already_present"
    marker = "\\paragraph{Assumption scope.}"
    insert_at = None
    for index, line in enumerate(old_lines):
        if line.startswith(marker):
            insert_at = index
            break
    if insert_at is None:
        return "", False, "assumption_scope_marker_missing"
    paragraph, blocked_reason = _artifact_anchor_paragraph(material_packet)
    if blocked_reason:
        return "", False, blocked_reason
    new_lines = old_lines[:insert_at] + paragraph + old_lines[insert_at:]
    return new_lines, True, ""


def materialize_reproducibility_protocol_patch(source_text, material_packet):
    old_lines = (source_text or "").splitlines(keepends=True)
    if not old_lines:
        return "", False, "empty_source"
    if "\\paragraph{Reproducibility protocol boundary.}" in "".join(old_lines):
        return "", False, "patch_text_already_present"
    marker = "\\paragraph{Assumption scope.}"
    insert_at = None
    for index, line in enumerate(old_lines):
        if line.startswith(marker):
            insert_at = index
            break
    if insert_at is None:
        return "", False, "assumption_scope_marker_missing"
    paragraph, blocked_reason = _reproducibility_boundary_paragraph(material_packet)
    if blocked_reason:
        return "", False, blocked_reason
    new_lines = old_lines[:insert_at] + paragraph + old_lines[insert_at:]
    return new_lines, True, ""


def materialize_anonymity_process_patch(source_text, material_packet):
    old_lines = (source_text or "").splitlines(keepends=True)
    if not old_lines:
        return "", False, "empty_source"
    if "\\paragraph{Anonymity/process boundary.}" in "".join(old_lines):
        return "", False, "patch_text_already_present"
    marker = "\\paragraph{Assumption scope.}"
    insert_at = None
    for index, line in enumerate(old_lines):
        if line.startswith(marker):
            insert_at = index
            break
    if insert_at is None:
        return "", False, "assumption_scope_marker_missing"
    paragraph, blocked_reason = _anonymity_boundary_paragraph(material_packet)
    if blocked_reason:
        return "", False, blocked_reason
    new_lines = old_lines[:insert_at] + paragraph + old_lines[insert_at:]
    return new_lines, True, ""


def materialize_patch_scope_patch(source_text, material_packet):
    old_lines = (source_text or "").splitlines(keepends=True)
    if not old_lines:
        return "", False, "empty_source"
    if "\\paragraph{Patch-scope boundary.}" in "".join(old_lines):
        return "", False, "patch_text_already_present"
    marker = "\\paragraph{Assumption scope.}"
    insert_at = None
    for index, line in enumerate(old_lines):
        if line.startswith(marker):
            insert_at = index
            break
    if insert_at is None:
        return "", False, "assumption_scope_marker_missing"
    paragraph, blocked_reason = _patch_scope_boundary_paragraph(material_packet)
    if blocked_reason:
        return "", False, blocked_reason
    new_lines = old_lines[:insert_at] + paragraph + old_lines[insert_at:]
    return new_lines, True, ""


def unified_patch(source_path, old_text, new_lines):
    old_lines = (old_text or "").splitlines(keepends=True)
    path = str(source_path or "")
    diff = "".join(
        difflib.unified_diff(
            old_lines,
            list(new_lines or []),
            fromfile=f"a/{path}",
            tofile=f"b/{path}",
        )
    )
    if diff:
        return f"diff --git a/{path} b/{path}\n" + diff
    return ""


def research_compute_manuscript_patch_worker_materialization(
    material_packet,
    source_text,
    source_snapshot=None,
    label="",
):
    material_packet = material_packet or {}
    source_snapshot = source_snapshot or {}
    issues = validate_material_packet(material_packet, source_snapshot)
    request = _request_from_material_packet(material_packet)
    patch_text = ""
    target_path = material_packet.get("source_target_path") or ""
    materialized = False
    blocked_reason = ""

    if not issues:
        if request.get("risk_class") == "artifact-anchor":
            new_lines, materialized, blocked_reason = materialize_artifact_anchor_patch(source_text, material_packet)
        elif request.get("risk_class") == "reproducibility-protocol":
            new_lines, materialized, blocked_reason = materialize_reproducibility_protocol_patch(source_text, material_packet)
        elif request.get("risk_class") == "anonymity-process":
            new_lines, materialized, blocked_reason = materialize_anonymity_process_patch(source_text, material_packet)
        elif request.get("risk_class") == "patch-scope":
            new_lines, materialized, blocked_reason = materialize_patch_scope_patch(source_text, material_packet)
        else:
            new_lines, materialized, blocked_reason = materialize_theory_boundary_patch(source_text)
        if materialized:
            patch_text = unified_patch(target_path, source_text, new_lines)
        else:
            issues.append({"issue": "patch_materialization_blocked", "detail": blocked_reason})

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = READY_STATE

    draft_ready = state == READY_STATE
    if not blocked_reason:
        if state == ATTENTION_STATE:
            blocked_reason = "patch_materialization_requires_attention"
        elif state == FORBIDDEN_STATE:
            blocked_reason = "forbidden_boundary_crossed"

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_patch_worker_materialization_state": state,
        "patch_worker_materialization_created": status == "PASS",
        "slug": material_packet.get("slug") or "",
        "material_packet_report_path": material_packet.get("report_path") or "",
        "material_packet_sha256": material_packet.get("report_sha256") or "",
        "selected_request_id": request.get("request_id") or "",
        "selected_risk_class": request.get("risk_class") or "",
        "selected_source_locator": request.get("source_locator") or "",
        "source_target_path": target_path,
        "source_target_exists": bool(source_snapshot.get("exists")),
        "source_target_sha256": source_snapshot.get("sha256") or "",
        "source_target_expected_sha256": material_packet.get("source_target_sha256") or "",
        "candidate_evidence_paths": request.get("evidence_paths") or [],
        "candidate_evidence_path_count": len(request.get("evidence_paths") or []),
        "evidence_anchor_summary": _evidence_anchor_summary(material_packet, request),
        "patch_draft_generated": draft_ready,
        "patch_draft_applied": False,
        "ready_for_manuscript_patch_draft_preflight": draft_ready,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "patch_draft_generated_count": 1 if draft_ready else 0,
            "patch_draft_applied_count": 0,
            "candidate_evidence_path_count": len(request.get("evidence_paths") or []),
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "patch_draft": {
            "target_path": target_path,
            "patch_text": patch_text,
            "patch_scope": request.get("patch_scope") or "",
            "apply_allowed": False,
            "enqueue_allowed": False,
            "source_mutation_allowed": False,
            "source_preflight_required_before_apply": True,
            "blocked_reason": blocked_reason,
        },
        "materialized_request": request,
        "boundary": [
            "This command materializes a local unified-diff manuscript patch draft under logs only.",
            "It does not apply the patch, mutate source/package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "A later manuscript patch draft preflight and explicit apply gate are required before any manuscript source file can be changed.",
        ],
    }


def research_compute_manuscript_patch_worker_materialization_markdown(report):
    patch = report.get("patch_draft") or {}
    lines = [
        "# paper_factory Research Compute Manuscript Patch Worker Materialization",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_patch_worker_materialization_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Request: `{report.get('selected_request_id') or ''}` `{report.get('selected_risk_class') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source target SHA256: `{report.get('source_target_sha256') or ''}`",
        f"- Patch draft generated: {report.get('patch_draft_generated')}",
        f"- Patch draft applied: {report.get('patch_draft_applied')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Patch Draft", ""])
    lines.append(f"- Target: `{patch.get('target_path') or ''}`")
    lines.append(f"- Apply allowed: {patch.get('apply_allowed')}")
    lines.append(f"- Source preflight required before apply: {patch.get('source_preflight_required_before_apply')}")
    lines.append(f"- Blocked reason: `{patch.get('blocked_reason') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
