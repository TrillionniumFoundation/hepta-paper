"""Apply a preflighted manuscript patch draft through an explicit source gate.

The core module validates the preflight report, patch file snapshot, source
snapshot, and apply result. The CLI performs the filesystem mutation only when
--apply and --write are both present and all pre-apply checks pass.
"""

import datetime as dt


COMMAND = "research-compute-manuscript-source-apply-gate"
APPLIED_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_APPLIED"
READY_DRY_RUN_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_READY_DRY_RUN_NOT_APPLIED"
BLOCKED_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_BLOCKED"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

PREFLIGHT_COMMAND = "research-compute-manuscript-patch-draft-preflight"
PREFLIGHT_READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_PATCH_DRAFT_PREFLIGHT_READY_FOR_APPLY_GATE"
EXPECTED_NEXT_GATE = "research_compute_manuscript_source_apply_gate"
EXPECTED_BOUNDARY_TEXT = "Assumption-risk boundary"


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _boundary_keys():
    return [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "network_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def _safe_relative_path(path):
    text = str(path or "").strip()
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def expected_boundary_text(report):
    risk_class = (report or {}).get("selected_risk_class")
    if str(risk_class or "").startswith("claim-"):
        return "Research compute claim boundary"
    if risk_class == "artifact-anchor":
        return "Artifact anchor"
    if risk_class == "reproducibility-protocol":
        return "Reproducibility protocol boundary"
    if risk_class == "anonymity-process":
        return "Anonymity/process boundary"
    if risk_class == "patch-scope":
        return "Patch-scope boundary"
    return EXPECTED_BOUNDARY_TEXT


def validate_apply_inputs(preflight_report, patch_snapshot, source_before_snapshot, patch_text):
    issues = []
    preflight = preflight_report or {}
    patch_snapshot = patch_snapshot or {}
    source_before_snapshot = source_before_snapshot or {}

    if preflight.get("command") != PREFLIGHT_COMMAND:
        issues.append({"issue": "preflight_command_mismatch", "detail": preflight.get("command") or ""})
    if preflight.get("status") != "PASS":
        issues.append({"issue": "preflight_not_pass", "detail": preflight.get("status") or ""})
    if preflight.get("manuscript_patch_draft_preflight_state") != PREFLIGHT_READY_STATE:
        issues.append({"issue": "preflight_not_ready", "detail": preflight.get("manuscript_patch_draft_preflight_state") or ""})
    if not preflight.get("ready_for_manuscript_source_apply_gate"):
        issues.append({"issue": "preflight_not_ready_for_source_apply_gate"})
    if preflight.get("required_next_gate") != EXPECTED_NEXT_GATE:
        issues.append({"issue": "preflight_required_next_gate_mismatch", "detail": preflight.get("required_next_gate") or ""})
    if not preflight.get("git_apply_check_passed"):
        issues.append({"issue": "preflight_git_apply_check_not_passed"})
    for key in _boundary_keys():
        if preflight.get(key):
            issues.append({"issue": f"forbidden_preflight_boundary:{key}"})

    target_path = preflight.get("source_target_path") or ""
    if not _safe_relative_path(target_path):
        issues.append({"issue": "unsafe_source_target_path", "detail": target_path})
    if not source_before_snapshot.get("exists"):
        issues.append({"issue": "source_target_missing", "detail": target_path})
    source_before_sha = source_before_snapshot.get("sha256") or ""
    expected_source_sha = preflight.get("source_target_sha256") or preflight.get("source_target_expected_sha256") or ""
    if source_before_sha and expected_source_sha and source_before_sha != expected_source_sha:
        issues.append({"issue": "source_target_sha256_mismatch", "expected": expected_source_sha, "observed": source_before_sha})

    patch_path = patch_snapshot.get("path") or ""
    if patch_path and not _safe_relative_path(patch_path):
        issues.append({"issue": "unsafe_patch_file_path", "detail": patch_path})
    if not patch_snapshot.get("exists"):
        issues.append({"issue": "patch_file_missing", "detail": patch_path})
    expected_patch_sha = preflight.get("patch_file_sha256") or preflight.get("patch_file_expected_sha256") or ""
    patch_sha = patch_snapshot.get("sha256") or ""
    if expected_patch_sha and patch_sha and expected_patch_sha != patch_sha:
        issues.append({"issue": "patch_file_sha256_mismatch", "expected": expected_patch_sha, "observed": patch_sha})
    changed_paths = preflight.get("patch_changed_paths") or []
    if changed_paths != [target_path]:
        issues.append({"issue": "preflight_patch_changed_paths_outside_target", "expected": target_path, "observed": changed_paths})
    if expected_boundary_text(preflight) not in (patch_text or ""):
        issues.append({"issue": "expected_boundary_text_missing_from_patch"})

    return issues


def validate_apply_result(apply_result):
    issues = []
    result = apply_result or {}
    if not result.get("performed"):
        issues.append({"issue": "apply_result_not_performed"})
    if result.get("returncode") != 0:
        issues.append({"issue": "git_apply_failed", "returncode": result.get("returncode"), "stderr": result.get("stderr") or ""})
    before_sha = result.get("source_before_sha256") or ""
    after_sha = result.get("source_after_sha256") or ""
    if before_sha and after_sha and before_sha == after_sha:
        issues.append({"issue": "source_sha256_unchanged_after_apply"})
    if not after_sha:
        issues.append({"issue": "source_after_sha256_missing"})
    if not result.get("rollback_snapshot_created"):
        issues.append({"issue": "rollback_snapshot_missing"})
    if not result.get("source_after_contains_expected_boundary_text"):
        issues.append({"issue": "post_apply_expected_boundary_text_missing"})
    return issues


def research_compute_manuscript_source_apply_gate(
    preflight_report,
    patch_snapshot,
    source_before_snapshot,
    patch_text,
    apply_requested=False,
    write_requested=False,
    apply_result=None,
    label="",
):
    preflight_report = preflight_report or {}
    patch_snapshot = patch_snapshot or {}
    source_before_snapshot = source_before_snapshot or {}
    apply_result = apply_result or {}
    issues = validate_apply_inputs(preflight_report, patch_snapshot, source_before_snapshot, patch_text or "")

    if apply_requested and not write_requested:
        issues.append({"issue": "apply_requires_write_report"})

    source_mutation_apply_authorized = bool(apply_requested and not issues)
    if apply_requested:
        issues.extend(validate_apply_result(apply_result))

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    source_mutation_performed = bool(
        source_mutation_apply_authorized
        and apply_result.get("performed")
        and apply_result.get("returncode") == 0
        and not issues
    )

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = BLOCKED_STATE
    elif source_mutation_performed:
        status = "PASS"
        state = APPLIED_STATE
    else:
        status = "PASS"
        state = READY_DRY_RUN_STATE

    source_after_sha = apply_result.get("source_after_sha256") or ""
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_source_apply_gate_state": state,
        "apply_gate_created": status == "PASS",
        "slug": preflight_report.get("slug") or "",
        "preflight_report_path": preflight_report.get("report_path") or "",
        "preflight_report_sha256": preflight_report.get("report_sha256") or "",
        "claim_quality_gate_ready": bool(preflight_report.get("claim_quality_gate_ready")),
        "selected_request_id": preflight_report.get("selected_request_id") or "",
        "selected_risk_class": preflight_report.get("selected_risk_class") or "",
        "source_target_path": preflight_report.get("source_target_path") or "",
        "source_before_sha256": source_before_snapshot.get("sha256") or "",
        "source_expected_before_sha256": preflight_report.get("source_target_sha256") or preflight_report.get("source_target_expected_sha256") or "",
        "source_after_sha256": source_after_sha,
        "source_after_contains_expected_boundary_text": bool(apply_result.get("source_after_contains_expected_boundary_text")),
        "patch_file_path": patch_snapshot.get("path") or "",
        "patch_file_sha256": patch_snapshot.get("sha256") or "",
        "patch_file_expected_sha256": preflight_report.get("patch_file_sha256") or preflight_report.get("patch_file_expected_sha256") or "",
        "apply_requested": bool(apply_requested),
        "write_requested": bool(write_requested),
        "git_apply_performed": bool(apply_result.get("performed")),
        "git_apply_returncode": apply_result.get("returncode"),
        "rollback_snapshot_created": bool(apply_result.get("rollback_snapshot_created")),
        "rollback_snapshot_path": apply_result.get("rollback_snapshot_path") or "",
        "rollback_snapshot_sha256": apply_result.get("rollback_snapshot_sha256") or "",
        "ready_for_manuscript_source_post_apply_verify": source_mutation_performed,
        "required_next_gate": "research_compute_manuscript_source_post_apply_verify" if source_mutation_performed else COMMAND.replace("-", "_"),
        "source_mutation_apply_authorized": source_mutation_apply_authorized,
        "source_mutation_performed": source_mutation_performed,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "source_mutation_count": 1 if source_mutation_performed else 0,
            "rollback_snapshot_created_count": 1 if apply_result.get("rollback_snapshot_created") else 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "git_apply_result": {
            "performed": bool(apply_result.get("performed")),
            "returncode": apply_result.get("returncode"),
            "stdout": apply_result.get("stdout") or "",
            "stderr": apply_result.get("stderr") or "",
        },
        "boundary": [
            "This command may apply one preflighted manuscript patch draft to its single target source file.",
            "It does not mutate package/archive state, call providers/models, perform external actions, merge/dequeue/supersede queue rows, or commit.",
            "A post-apply verification gate is required after any source mutation.",
        ],
    }


def research_compute_manuscript_source_apply_gate_markdown(report):
    lines = [
        "# paper_factory Research Compute Manuscript Source Apply Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_source_apply_gate_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Request: `{report.get('selected_request_id') or ''}` `{report.get('selected_risk_class') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source before SHA256: `{report.get('source_before_sha256') or ''}`",
        f"- Source after SHA256: `{report.get('source_after_sha256') or ''}`",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
