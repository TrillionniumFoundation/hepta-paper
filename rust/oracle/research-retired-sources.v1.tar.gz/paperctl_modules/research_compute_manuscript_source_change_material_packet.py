"""Prepare manuscript source-change material for a later patch worker.

This gate consolidates referee patch requests, source locators, local evidence
paths, and target-file snapshots. It does not draft/apply a patch, mutate
source/package/archive state, call providers/models, merge queue rows, or
commit.
"""

import re


COMMAND = "research-compute-manuscript-source-change-material-packet"
READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_CHANGE_MATERIAL_PACKET_READY_FOR_PATCH_WORKER_MATERIALIZATION"
NO_REQUEST_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_CHANGE_MATERIAL_PACKET_NO_REQUESTED_SOURCE_CHANGE_MATERIAL"
ATTENTION_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_CHANGE_MATERIAL_PACKET_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

REQUEST_HEADING_RE = re.compile(r"^## Request\s+(\d+):\s*(.+?)\s*$", re.MULTILINE)
FIELD_RE = re.compile(r"^-\s+([A-Za-z0-9_-]+):\s*(.*?)\s*$")
SOURCE_LOCATOR_RE = re.compile(r"^(?P<path>[^:]+?)(?::(?P<line>\d+))?$")
SOURCE_TARGET_PREFIXES = ("submission/", "drafts/", "source/")
SOURCE_EXTENSIONS = (".tex", ".bib", ".sty", ".cls", ".md", ".csv")


def _safe_relative_path(path):
    text = str(path or "").strip()
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _looks_like_source_path(path):
    text = str(path or "").strip()
    return bool(text) and (text.startswith(SOURCE_TARGET_PREFIXES) or text.endswith(SOURCE_EXTENSIONS))


def _slug_from_path(path):
    parts = str(path or "").split("/")
    if len(parts) >= 3 and parts[0] == "submission":
        return parts[2]
    return ""


def _split_evidence_paths(value, evidence_status=""):
    if str(evidence_status or "").strip() != "candidate_found":
        return []
    paths = []
    for item in str(value or "").split(","):
        candidate = item.strip()
        if not candidate:
            continue
        if " + " in candidate:
            continue
        if _safe_relative_path(candidate):
            paths.append(candidate)
    return paths


def _parse_source_locator(value):
    text = str(value or "").strip()
    match = SOURCE_LOCATOR_RE.match(text)
    if not match:
        return {"source_locator": text, "source_path": "", "source_line": 0}
    return {
        "source_locator": text,
        "source_path": match.group("path") or "",
        "source_line": int(match.group("line") or 0),
    }


def _parse_metadata(lines):
    metadata = {}
    for line in lines:
        match = FIELD_RE.match(line)
        if not match:
            continue
        metadata[match.group(1)] = match.group(2)
    return metadata


def parse_patch_requests_markdown(text):
    body = text or ""
    matches = list(REQUEST_HEADING_RE.finditer(body))
    metadata_region = body[: matches[0].start()] if matches else body
    metadata = _parse_metadata(metadata_region.splitlines())
    requests = []

    for index, match in enumerate(matches):
        block_end = matches[index + 1].start() if index + 1 < len(matches) else len(body)
        block = body[match.end() : block_end]
        fields = _parse_metadata(block.splitlines())
        request_id = match.group(1)
        source = _parse_source_locator(fields.get("source_locator") or "")
        evidence_status = fields.get("evidence_status") or ""
        evidence_paths = _split_evidence_paths(fields.get("evidence_locator") or "", evidence_status)
        status = fields.get("status") or ""
        proposed_fix = fields.get("proposed_fix") or ""
        source_change_intent = bool(
            status == "REQUESTED_NOT_APPLIED"
            and source["source_path"]
            and _looks_like_source_path(source["source_path"])
            and proposed_fix
        )
        request = {
            "request_id": request_id,
            "request_number": int(request_id),
            "title": match.group(2),
            "matrix_rank": int(fields.get("matrix_rank") or 0),
            "status": status,
            "persona": fields.get("persona") or "",
            "severity": fields.get("severity") or "",
            "risk_class": fields.get("risk_class") or match.group(2),
            "fix_class": fields.get("fix_class") or "",
            "objection": fields.get("objection") or "",
            "source_locator": source["source_locator"],
            "source_path": source["source_path"],
            "source_line": source["source_line"],
            "evidence_locator": fields.get("evidence_locator") or "",
            "evidence_status": evidence_status,
            "evidence_paths": evidence_paths,
            "proposed_fix": proposed_fix,
            "evidence_needed": fields.get("evidence_needed") or "",
            "verification": fields.get("verification") or "",
            "patch_scope": fields.get("patch_scope") or "",
            "source_change_intent_present": source_change_intent,
            "patch_worker_material_candidate": bool(source_change_intent and (evidence_paths or evidence_status == "process_required")),
        }
        requests.append(request)

    return {
        "metadata": metadata,
        "requests": sorted(requests, key=lambda item: (item.get("matrix_rank") or 9999, item.get("request_number") or 9999)),
    }


def _forbidden_reference_boundary(reference):
    item = reference or {}
    if _is_verified_post_apply_reference(item):
        return []
    forbidden_keys = [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]
    return [key for key in forbidden_keys if item.get(key)]


def _is_verified_post_apply_reference(reference):
    item = reference or {}
    if item.get("command") != "research-compute-manuscript-source-post-apply-verify":
        return False
    if item.get("status") != "PASS":
        return False
    if item.get("manuscript_source_post_apply_verify_state") != "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_POST_APPLY_VERIFY_VERIFIED":
        return False
    if not item.get("selected_request_id"):
        return False
    forbidden_keys = [
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]
    return not any(item.get(key) for key in forbidden_keys)


def _applied_request_ids(prior_references):
    ids = []
    seen = set()
    for reference in prior_references or []:
        if not _is_verified_post_apply_reference(reference):
            continue
        request_id = str(reference.get("selected_request_id") or "").strip()
        if not request_id or request_id in seen:
            continue
        seen.add(request_id)
        ids.append(request_id)
    return ids


def _request_snapshot(request, material_snapshots):
    return (material_snapshots or {}).get(str(request.get("request_id") or "")) or {}


def _select_next_request(requests, material_snapshots, applied_request_ids=None):
    candidates = []
    applied = set(str(item) for item in (applied_request_ids or []))
    severity_rank = {"fatal": 0, "major": 1, "minor": 2}
    for request in requests:
        snap = _request_snapshot(request, material_snapshots)
        evidence_summary = snap.get("evidence_summary") or {}
        if str(request.get("request_id") or "") in applied:
            continue
        if not request.get("patch_worker_material_candidate"):
            continue
        if not snap.get("source_exists"):
            continue
        if request.get("evidence_status") == "candidate_found" and not evidence_summary.get("present_count"):
            continue
        candidates.append(
            (
                severity_rank.get(str(request.get("severity") or "").lower(), 9),
                int(request.get("matrix_rank") or 9999),
                int(request.get("request_number") or 9999),
                request,
            )
        )
    if not candidates:
        return {}
    return sorted(candidates, key=lambda item: item[:3])[0][3]


def validate_packet_material(parsed_requests, source_target_snapshot=None, material_snapshots=None, prior_references=None):
    issues = []
    parsed_requests = parsed_requests or {}
    requests = list(parsed_requests.get("requests") or [])
    source_target_snapshot = source_target_snapshot or {}
    material_snapshots = material_snapshots or {}

    if not requests:
        issues.append({"issue": "patch_request_material_missing"})
    if not source_target_snapshot.get("exists"):
        issues.append({"issue": "source_target_missing", "detail": source_target_snapshot.get("path") or ""})
    if source_target_snapshot.get("path") and not _safe_relative_path(source_target_snapshot.get("path")):
        issues.append({"issue": "unsafe_source_target_path", "detail": source_target_snapshot.get("path") or ""})

    for request in requests:
        source_path = request.get("source_path") or ""
        if source_path and not _safe_relative_path(source_path):
            issues.append({"issue": "unsafe_request_source_path", "request_id": request.get("request_id"), "detail": source_path})
        if source_path and source_target_snapshot.get("path") and source_path != source_target_snapshot.get("path"):
            issues.append({"issue": "request_source_target_mismatch", "request_id": request.get("request_id"), "detail": source_path})
        snap = _request_snapshot(request, material_snapshots)
        if request.get("source_change_intent_present") and not snap.get("source_exists"):
            issues.append({"issue": "request_source_missing", "request_id": request.get("request_id"), "detail": source_path})
        for evidence_path in request.get("evidence_paths") or []:
            if not _safe_relative_path(evidence_path):
                issues.append({"issue": "unsafe_evidence_path", "request_id": request.get("request_id"), "detail": evidence_path})
        evidence_summary = snap.get("evidence_summary") or {}
        if request.get("evidence_status") == "candidate_found" and evidence_summary.get("missing_count"):
            issues.append(
                {
                    "issue": "candidate_evidence_missing",
                    "request_id": request.get("request_id"),
                    "missing_count": evidence_summary.get("missing_count"),
                }
            )

    for reference in prior_references or []:
        for key in _forbidden_reference_boundary(reference):
            issues.append({"issue": f"forbidden_prior_reference_boundary:{key}"})

    return issues


def research_compute_manuscript_source_change_material_packet(
    parsed_requests,
    source_target_snapshot=None,
    material_snapshots=None,
    plan_status_snapshot=None,
    patch_status_snapshot=None,
    prior_references=None,
    label="",
):
    parsed_requests = parsed_requests or {"metadata": {}, "requests": []}
    source_target_snapshot = source_target_snapshot or {}
    material_snapshots = material_snapshots or {}
    plan_status_snapshot = plan_status_snapshot or {}
    patch_status_snapshot = patch_status_snapshot or {}
    requests = list(parsed_requests.get("requests") or [])
    issues = validate_packet_material(parsed_requests, source_target_snapshot, material_snapshots, prior_references)
    applied_ids = _applied_request_ids(prior_references)

    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    selected = _select_next_request(requests, material_snapshots, applied_ids)
    source_intent_count = len([item for item in requests if item.get("source_change_intent_present")])
    eligible_source_change_request_count = len(
        [
            item
            for item in requests
            if item.get("patch_worker_material_candidate") and str(item.get("request_id") or "") not in set(applied_ids)
        ]
    )
    candidate_found_count = len([item for item in requests if item.get("evidence_status") == "candidate_found"])
    process_required_count = len([item for item in requests if item.get("evidence_status") == "process_required"])
    requested_not_applied_count = len([item for item in requests if item.get("status") == "REQUESTED_NOT_APPLIED"])
    candidate_evidence_path_count = sum(len(item.get("evidence_paths") or []) for item in requests)
    evidence_present_count = sum((snap.get("evidence_summary") or {}).get("present_count", 0) for snap in material_snapshots.values())
    evidence_missing_count = sum((snap.get("evidence_summary") or {}).get("missing_count", 0) for snap in material_snapshots.values())

    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif selected:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = NO_REQUEST_STATE

    ready = state == READY_STATE
    blocked_reason = ""
    if state == NO_REQUEST_STATE:
        blocked_reason = "no_requested_source_change_material"
    elif state == ATTENTION_STATE:
        blocked_reason = "source_change_material_requires_attention"
    elif state == FORBIDDEN_STATE:
        blocked_reason = "forbidden_boundary_crossed"

    metadata = parsed_requests.get("metadata") or {}
    slug = metadata.get("slug") or _slug_from_path(source_target_snapshot.get("path") or "")

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_source_change_material_packet_state": state,
        "source_change_material_packet_created": status == "PASS",
        "slug": slug,
        "source_target_path": source_target_snapshot.get("path") or "",
        "source_target_exists": bool(source_target_snapshot.get("exists")),
        "source_target_sha256": source_target_snapshot.get("sha256") or "",
        "patch_requests_status": metadata.get("status") or "",
        "source_change_intent_present": bool(source_intent_count),
        "source_change_request_count": len(requests),
        "requested_not_applied_count": requested_not_applied_count,
        "applied_request_ids": applied_ids,
        "prior_applied_request_count": len(applied_ids),
        "eligible_source_change_request_count": eligible_source_change_request_count,
        "candidate_found_request_count": candidate_found_count,
        "process_required_request_count": process_required_count,
        "candidate_evidence_path_count": candidate_evidence_path_count,
        "candidate_evidence_present_count": evidence_present_count,
        "candidate_evidence_missing_count": evidence_missing_count,
        "applyable_manuscript_patch_material_present": False,
        "manuscript_patch_draft_generated": False,
        "ready_for_patch_worker_materialization": ready,
        "ready_for_manuscript_patch_draft_preflight": False,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "source_change_request_count": len(requests),
            "requested_not_applied_count": requested_not_applied_count,
            "prior_applied_request_count": len(applied_ids),
            "eligible_source_change_request_count": eligible_source_change_request_count,
            "source_change_intent_count": source_intent_count,
            "candidate_found_request_count": candidate_found_count,
            "process_required_request_count": process_required_count,
            "candidate_evidence_path_count": candidate_evidence_path_count,
            "candidate_evidence_present_count": evidence_present_count,
            "candidate_evidence_missing_count": evidence_missing_count,
            "selected_next_request_count": 1 if selected else 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "selected_next_request": selected,
        "source_target_snapshot": source_target_snapshot,
        "plan_status_snapshot": plan_status_snapshot,
        "patch_status_snapshot": patch_status_snapshot,
        "patch_requests_metadata": metadata,
        "source_change_requests": requests,
        "material_snapshots": material_snapshots,
        "prior_references": prior_references or [],
        "source_change_material_packet": {
            "slug": slug,
            "source_change_intent_present": bool(source_intent_count),
            "source_change_request_count": len(requests),
            "applied_request_ids": applied_ids,
            "prior_applied_request_count": len(applied_ids),
            "eligible_source_change_request_count": eligible_source_change_request_count,
            "selected_next_request_id": selected.get("request_id") if selected else "",
            "selected_next_risk_class": selected.get("risk_class") if selected else "",
            "ready_for_patch_worker_materialization": ready,
            "ready_for_manuscript_patch_draft_preflight": False,
            "blocked_reason": blocked_reason,
            "required_next_gate": "research_compute_manuscript_patch_worker_materialization" if ready else "resolve_source_change_material_attention",
            "source_mutation_apply_authorized": False,
        },
        "boundary": [
            "This command prepares source-change material for a later bounded patch worker.",
            "It does not draft or apply a patch, mutate source/package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "A material packet is not an apply authorization; any manuscript edit still needs a patch draft, preflight, verification, and merge discipline.",
        ],
    }


def research_compute_manuscript_source_change_material_packet_markdown(report):
    packet = report.get("source_change_material_packet") or {}
    selected = report.get("selected_next_request") or {}
    lines = [
        "# paper_factory Research Compute Manuscript Source Change Material Packet",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_source_change_material_packet_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source target SHA256: `{report.get('source_target_sha256') or ''}`",
        f"- Source change request count: {report.get('source_change_request_count')}",
        f"- Prior applied request count: {report.get('prior_applied_request_count')}",
        f"- Eligible source change request count: {report.get('eligible_source_change_request_count')}",
        f"- Candidate evidence present: {report.get('candidate_evidence_present_count')}",
        f"- Ready for patch worker materialization: {report.get('ready_for_patch_worker_materialization')}",
        f"- Manuscript patch draft generated: {report.get('manuscript_patch_draft_generated')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Selected Next Request", ""])
    if selected:
        lines.append(f"- Request: `{selected.get('request_id')}` `{selected.get('risk_class')}`")
        lines.append(f"- Severity: `{selected.get('severity')}`")
        lines.append(f"- Source locator: `{selected.get('source_locator')}`")
        lines.append(f"- Proposed fix: {selected.get('proposed_fix') or ''}")
    else:
        lines.append("- Request: none")
    lines.extend(["", "## Packet", ""])
    lines.append(f"- Required next gate: `{packet.get('required_next_gate') or ''}`")
    lines.append(f"- Blocked reason: `{packet.get('blocked_reason') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
