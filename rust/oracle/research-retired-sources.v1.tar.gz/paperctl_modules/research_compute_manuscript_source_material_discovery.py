"""Discover whether a queued research-compute item is a manuscript patch.

This gate records source-mutation authorization context and inspects patch_queue
material. It does not apply patches or mutate source/package/archive state.
"""


COMMAND = "research-compute-manuscript-source-material-discovery"
NO_MATERIAL_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_MATERIAL_DISCOVERY_NO_APPLYABLE_MANUSCRIPT_PATCH_MATERIAL"
READY_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_MATERIAL_DISCOVERY_READY_FOR_MANUSCRIPT_SOURCE_PREFLIGHT"
ATTENTION_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_MATERIAL_DISCOVERY_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

AUTHORIZATION_SCOPE = "manuscript_source_material_discovery_only"
REVIEW_ONLY_TARGET_PREFIX = "research_compute_candidate_notes/"
MANUSCRIPT_TARGET_PREFIXES = ("submission/", "drafts/", "source/")
MANUSCRIPT_EXTENSIONS = (".tex", ".bib", ".sty", ".cls", ".md", ".csv")


def _safe_relative_path(path):
    text = str(path or "")
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _target_paths(row):
    paths = row.get("target_paths")
    if isinstance(paths, list):
        return [str(item) for item in paths]
    return []


def _is_review_only_row(row):
    metadata = row.get("metadata") or {}
    targets = _target_paths(row)
    patch_path = str(row.get("patch_path") or "")
    if metadata.get("enqueue_scope") == "candidate_note_patch_queue_only":
        return True
    if metadata.get("source") == "research_compute_candidate_note_patch_queue_enqueue":
        return True
    if "candidate_note_queue_artifact" in patch_path or "candidate-note-queue-artifact" in patch_path:
        return True
    return any(path.startswith(REVIEW_ONLY_TARGET_PREFIX) for path in targets)


def _is_manuscript_target(path):
    text = str(path or "")
    if not text:
        return False
    if text == "source":
        return True
    if text.startswith(MANUSCRIPT_TARGET_PREFIXES):
        return True
    return text.endswith(MANUSCRIPT_EXTENSIONS) and not text.startswith(REVIEW_ONLY_TARGET_PREFIX)


def _patch_file_has_applyable_diff(row):
    patch_file = row.get("patch_file") or {}
    path = str(row.get("patch_path") or "")
    if not patch_file:
        return path.endswith(".patch")
    if not patch_file.get("exists") or not patch_file.get("is_file", True):
        return False
    if patch_file.get("sha256_match") is False:
        return False
    return bool(patch_file.get("contains_unified_diff") or path.endswith(".patch"))


def _candidate_note_already_exists(row):
    for snap in row.get("target_file_snapshots") or []:
        if str(snap.get("path") or "").startswith(REVIEW_ONLY_TARGET_PREFIX) and snap.get("exists"):
            return True
    return False


def classify_patch_queue_row(row):
    row = row or {}
    targets = _target_paths(row)
    status = str(row.get("status") or "")
    review_only = _is_review_only_row(row)
    manuscript_targets = [path for path in targets if _is_manuscript_target(path)]
    patch_material_present = _patch_file_has_applyable_diff(row)
    sha_match = (row.get("patch_file") or {}).get("sha256_match")
    if sha_match is None:
        sha_match = True

    classification = "nonqueued"
    if status == "queued":
        if review_only:
            classification = "queued_review_only"
        elif manuscript_targets and patch_material_present and sha_match:
            classification = "queued_applyable_manuscript_patch"
        else:
            classification = "queued_unknown_material"

    return {
        "patch_id": int(row.get("patch_id") or 0),
        "slug": row.get("slug") or "",
        "status": status,
        "patch_path": row.get("patch_path") or "",
        "patch_sha256": row.get("patch_sha256") or "",
        "target_paths": targets,
        "review_only_queue_artifact": review_only,
        "candidate_note_already_exists": _candidate_note_already_exists(row),
        "manuscript_target_paths": manuscript_targets,
        "patch_file_exists": bool((row.get("patch_file") or {}).get("exists")),
        "patch_file_sha256_match": bool(sha_match),
        "contains_unified_diff": bool((row.get("patch_file") or {}).get("contains_unified_diff")),
        "applyable_manuscript_patch_material": classification == "queued_applyable_manuscript_patch",
        "classification": classification,
    }


def validate_authorization_material(material):
    issues = []
    if not material:
        return issues, "NOT_PROVIDED_DISCOVERY_ONLY"
    if not isinstance(material, dict):
        return [{"issue": "authorization_material_must_be_object"}], "INVALID"
    scope = str(material.get("scope") or material.get("authorization_scope") or "")
    if scope and scope != AUTHORIZATION_SCOPE:
        issues.append({"issue": "authorization_scope_mismatch", "detail": scope})
    if not str(material.get("operator_id") or "").strip():
        issues.append({"issue": "operator_id_required"})
    for key in [
        "apply_now",
        "apply_allowed",
        "source_mutation_apply_authorized",
        "source_mutation_performed",
        "package_mutation_authorized",
        "archive_mutation_authorized",
        "provider_model_call_authorized",
        "external_action_authorized",
        "merge_allowed",
        "commit_allowed",
    ]:
        if material.get(key):
            issues.append({"issue": f"forbidden_authorization_flag:{key}"})
    return issues, "STRUCTURE_VALID_DISCOVERY_ONLY" if not issues else "INVALID"


def validate_patch_queue_rows(rows):
    issues = []
    for row in rows or []:
        if not row.get("db_checked"):
            issues.append({"issue": "patch_queue_row_unchecked", "patch_id": int(row.get("patch_id") or 0)})
        if not _safe_relative_path(row.get("patch_path") or ""):
            issues.append({"issue": "unsafe_patch_path", "patch_id": int(row.get("patch_id") or 0), "detail": row.get("patch_path") or ""})
        sha = row.get("patch_sha256") or ""
        if sha and not _valid_sha256(sha):
            issues.append({"issue": "invalid_patch_sha256", "patch_id": int(row.get("patch_id") or 0)})
        for key in [
            "source_mutation_performed",
            "package_mutation_performed",
            "archive_mutation_performed",
            "provider_model_call_performed",
            "external_action_performed",
            "commit_performed",
        ]:
            if (row.get("metadata") or {}).get(key):
                issues.append({"issue": f"forbidden_patch_queue_metadata_boundary:{key}", "patch_id": int(row.get("patch_id") or 0)})
    return issues


def research_compute_manuscript_source_material_discovery(
    patch_queue_rows,
    slug="",
    selected_patch_id=0,
    authorization_material=None,
    label="",
):
    rows = list(patch_queue_rows or [])
    classifications = [classify_patch_queue_row(row) for row in rows]
    queued = [item for item in classifications if item["status"] == "queued"]
    queued_review_only = [item for item in queued if item["classification"] == "queued_review_only"]
    queued_applyable = [item for item in queued if item["classification"] == "queued_applyable_manuscript_patch"]
    queued_unknown = [item for item in queued if item["classification"] == "queued_unknown_material"]
    applied_manuscript = [
        item
        for item in classifications
        if item["status"].startswith("applied") and item["manuscript_target_paths"]
    ]

    auth_issues, auth_state = validate_authorization_material(authorization_material or {})
    issues = validate_patch_queue_rows(rows)
    issues.extend(auth_issues)
    selected = [item for item in classifications if int(item.get("patch_id") or 0) == int(selected_patch_id or 0)]
    if selected_patch_id and not selected:
        issues.append({"issue": "selected_patch_id_not_found", "patch_id": int(selected_patch_id or 0)})
    material_scope = selected if selected_patch_id and selected else classifications
    scoped_queued = [item for item in material_scope if item["status"] == "queued"]
    scoped_queued_applyable = [
        item for item in scoped_queued if item["classification"] == "queued_applyable_manuscript_patch"
    ]
    scoped_queued_unknown = [
        item for item in scoped_queued if item["classification"] == "queued_unknown_material"
    ]

    forbidden = any(str(item.get("issue") or "").startswith(("forbidden_patch_queue_metadata_boundary", "forbidden_authorization_flag")) for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues or scoped_queued_unknown:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif scoped_queued_applyable:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = NO_MATERIAL_STATE

    ready = state == READY_STATE
    blocked_reason = ""
    if state == NO_MATERIAL_STATE:
        blocked_reason = "no_queued_applyable_manuscript_patch_material"
    elif state == ATTENTION_STATE:
        blocked_reason = "queued_material_requires_manual_disambiguation"

    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_source_material_discovery_state": state,
        "manuscript_source_material_discovery_created": status == "PASS",
        "slug": slug or (rows[0].get("slug") if rows else ""),
        "selected_patch_id": int(selected_patch_id or 0),
        "authorization_material_state": auth_state,
        "source_mutation_authorization_recorded": bool(authorization_material) and auth_state == "STRUCTURE_VALID_DISCOVERY_ONLY",
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "applyable_manuscript_patch_material_present": ready,
        "ready_for_manuscript_source_preflight": ready,
        "summary": {
            "validation_issue_count": len(issues),
            "patch_queue_row_count": len(rows),
            "queued_patch_count": len(queued),
            "queued_review_only_patch_count": len(queued_review_only),
            "queued_applyable_manuscript_patch_count": len(queued_applyable),
            "queued_unknown_material_count": len(queued_unknown),
            "applied_manuscript_patch_count": len(applied_manuscript),
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "queued_review_only_rows": queued_review_only,
        "queued_applyable_manuscript_rows": queued_applyable,
        "queued_unknown_material_rows": queued_unknown,
        "selected_patch_classification": selected[0] if selected else {},
        "authorization_material_reference": {
            "scope": (authorization_material or {}).get("scope") or "",
            "operator_id": (authorization_material or {}).get("operator_id") or "",
            "telegram_message_id": (authorization_material or {}).get("telegram_message_id") or "",
        },
        "material_discovery_packet": {
            "slug": slug or (rows[0].get("slug") if rows else ""),
            "selected_patch_id": int(selected_patch_id or 0),
            "applyable_manuscript_patch_material_present": ready,
            "queued_applyable_manuscript_patch_ids": [
                item["patch_id"] for item in (scoped_queued_applyable if selected_patch_id else queued_applyable)
            ],
            "queued_review_only_patch_ids": [
                item["patch_id"]
                for item in (
                    [item for item in scoped_queued if item["classification"] == "queued_review_only"]
                    if selected_patch_id
                    else queued_review_only
                )
            ],
            "blocked_reason": blocked_reason,
            "required_next_gate": "research_compute_manuscript_source_apply_preflight" if ready else "create_independent_applyable_manuscript_patch_draft",
            "existing_research_compute_source_gate_scope": REVIEW_ONLY_TARGET_PREFIX,
            "source_mutation_apply_authorized": False,
        },
        "boundary": [
            "This command records discovery-only source authorization context and audits patch_queue material.",
            "It does not apply a patch, mutate source/package/archive state, call providers/models, merge/dequeue/supersede, or commit.",
            "Existing research-compute source apply gates are scoped to research_compute_candidate_notes/ and must not be reused for manuscript source without a separate manuscript patch preflight.",
        ],
    }


def research_compute_manuscript_source_material_discovery_markdown(report):
    packet = report.get("material_discovery_packet") or {}
    lines = [
        "# paper_factory Research Compute Manuscript Source Material Discovery",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_source_material_discovery_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Selected patch ID: `{report.get('selected_patch_id') or 0}`",
        f"- Source mutation authorization recorded: {report.get('source_mutation_authorization_recorded')}",
        f"- Applyable manuscript patch present: {report.get('applyable_manuscript_patch_material_present')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Discovery Packet", ""])
    lines.append(f"- Blocked reason: `{packet.get('blocked_reason') or ''}`")
    lines.append(f"- Required next gate: `{packet.get('required_next_gate') or ''}`")
    lines.append(f"- Queued applyable manuscript patch IDs: `{packet.get('queued_applyable_manuscript_patch_ids') or []}`")
    lines.append(f"- Queued review-only patch IDs: `{packet.get('queued_review_only_patch_ids') or []}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
