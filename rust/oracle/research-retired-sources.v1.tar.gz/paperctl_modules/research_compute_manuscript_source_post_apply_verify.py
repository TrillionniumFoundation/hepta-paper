"""Verify a manuscript source apply gate after the source file was changed."""

import datetime as dt


COMMAND = "research-compute-manuscript-source-post-apply-verify"
VERIFIED_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_POST_APPLY_VERIFY_VERIFIED"
ATTENTION_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_POST_APPLY_VERIFY_ATTENTION"
FORBIDDEN_STATE = "FORBIDDEN_BOUNDARY_CROSSED"

APPLY_COMMAND = "research-compute-manuscript-source-apply-gate"
APPLY_APPLIED_STATE = "RESEARCH_COMPUTE_MANUSCRIPT_SOURCE_APPLY_GATE_APPLIED"
EXPECTED_BOUNDARY_TEXT = "Assumption-risk boundary"


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _safe_relative_path(path):
    text = str(path or "").strip()
    return bool(text) and not text.startswith("/") and ".." not in text.split("/")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def expected_boundary_text(report):
    risk_class = (report or {}).get("selected_risk_class")
    if str(risk_class or "").startswith("claim-"):
        return "Research compute claim boundary"
    if risk_class == "artifact-anchor":
        return "Artifact anchor"
    if risk_class == "reproducibility-protocol":
        return "Reproducibility protocol boundary"
    if risk_class == "anonymity-process":
        return "Anonymity/process boundary"
    if risk_class == "patch-scope":
        return "Patch-scope boundary"
    return EXPECTED_BOUNDARY_TEXT


def _quality_gated_claim_boundary_replacement(report):
    risk_class = (report or {}).get("selected_risk_class")
    return str(risk_class or "").startswith("claim-")


def _forbidden_apply_keys():
    return [
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "real_provider_model_call_performed",
        "network_call_performed",
        "external_action_performed",
        "patch_queue_merge_performed",
        "commit_performed",
    ]


def validate_post_apply(
    apply_report,
    source_snapshot,
    rollback_snapshot,
    patch_snapshot,
    source_text,
    rollback_text,
    diff_check,
):
    issues = []
    report = apply_report or {}
    source_snapshot = source_snapshot or {}
    rollback_snapshot = rollback_snapshot or {}
    patch_snapshot = patch_snapshot or {}
    diff_check = diff_check or {}

    if report.get("command") != APPLY_COMMAND:
        issues.append({"issue": "apply_report_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "apply_report_not_pass", "detail": report.get("status") or ""})
    if report.get("manuscript_source_apply_gate_state") != APPLY_APPLIED_STATE:
        issues.append({"issue": "apply_gate_state_not_applied", "detail": report.get("manuscript_source_apply_gate_state") or ""})
    if not _literal_bool_or_missing(report.get("source_mutation_performed")):
        issues.append({"issue": "invalid_apply_report_boolean:source_mutation_performed", "detail": repr(report.get("source_mutation_performed"))})
    if not _literal_true(report.get("source_mutation_performed")):
        issues.append({"issue": "source_mutation_not_recorded"})
    if not _literal_bool_or_missing(report.get("ready_for_manuscript_source_post_apply_verify")):
        issues.append({"issue": "invalid_apply_report_boolean:ready_for_manuscript_source_post_apply_verify", "detail": repr(report.get("ready_for_manuscript_source_post_apply_verify"))})
    if not _literal_true(report.get("ready_for_manuscript_source_post_apply_verify")):
        issues.append({"issue": "apply_report_not_ready_for_post_apply_verify"})
    if not _literal_bool_or_missing(report.get("claim_quality_gate_ready")):
        issues.append({"issue": "invalid_apply_report_boolean:claim_quality_gate_ready", "detail": repr(report.get("claim_quality_gate_ready"))})
    for key in _forbidden_apply_keys():
        if not _literal_bool_or_missing(report.get(key)):
            issues.append({"issue": f"invalid_apply_report_boolean:{key}", "detail": repr(report.get(key))})
        elif _literal_true(report.get(key)):
            issues.append({"issue": f"forbidden_apply_boundary:{key}"})

    target_path = report.get("source_target_path") or ""
    if not _safe_relative_path(target_path):
        issues.append({"issue": "unsafe_source_target_path", "detail": target_path})
    if not _literal_bool_or_missing(source_snapshot.get("exists")):
        issues.append({"issue": "invalid_source_snapshot_boolean:exists", "detail": repr(source_snapshot.get("exists"))})
    if not _literal_true(source_snapshot.get("exists")):
        issues.append({"issue": "source_target_missing", "detail": target_path})
    if not _literal_bool_or_missing(source_snapshot.get("is_file")):
        issues.append({"issue": "invalid_source_snapshot_boolean:is_file", "detail": repr(source_snapshot.get("is_file"))})
    elif source_snapshot.get("is_file") is False:
        issues.append({"issue": "source_target_not_file", "detail": target_path})
    if source_snapshot.get("sha256") != report.get("source_after_sha256"):
        issues.append(
            {
                "issue": "source_after_sha256_mismatch",
                "expected": report.get("source_after_sha256") or "",
                "observed": source_snapshot.get("sha256") or "",
            }
        )
    if source_snapshot.get("sha256") == report.get("source_before_sha256"):
        issues.append({"issue": "source_sha256_still_matches_before_apply"})

    rollback_path = report.get("rollback_snapshot_path") or ""
    if rollback_path and not _safe_relative_path(rollback_path):
        issues.append({"issue": "unsafe_rollback_snapshot_path", "detail": rollback_path})
    if not _literal_bool_or_missing(rollback_snapshot.get("exists")):
        issues.append({"issue": "invalid_rollback_snapshot_boolean:exists", "detail": repr(rollback_snapshot.get("exists"))})
    if not _literal_true(rollback_snapshot.get("exists")):
        issues.append({"issue": "rollback_snapshot_missing", "detail": rollback_path})
    if not _literal_bool_or_missing(rollback_snapshot.get("is_file")):
        issues.append({"issue": "invalid_rollback_snapshot_boolean:is_file", "detail": repr(rollback_snapshot.get("is_file"))})
    elif rollback_snapshot.get("is_file") is False:
        issues.append({"issue": "rollback_snapshot_not_file", "detail": rollback_path})
    if rollback_snapshot.get("sha256") != report.get("rollback_snapshot_sha256"):
        issues.append(
            {
                "issue": "rollback_snapshot_sha256_mismatch",
                "expected": report.get("rollback_snapshot_sha256") or "",
                "observed": rollback_snapshot.get("sha256") or "",
            }
        )
    if rollback_snapshot.get("sha256") != report.get("source_before_sha256"):
        issues.append({"issue": "rollback_snapshot_not_equal_source_before"})

    patch_path = report.get("patch_file_path") or ""
    if patch_path and not _safe_relative_path(patch_path):
        issues.append({"issue": "unsafe_patch_file_path", "detail": patch_path})
    if not _literal_bool_or_missing(patch_snapshot.get("exists")):
        issues.append({"issue": "invalid_patch_snapshot_boolean:exists", "detail": repr(patch_snapshot.get("exists"))})
    if not _literal_true(patch_snapshot.get("exists")):
        issues.append({"issue": "patch_file_missing", "detail": patch_path})
    if not _literal_bool_or_missing(patch_snapshot.get("is_file")):
        issues.append({"issue": "invalid_patch_snapshot_boolean:is_file", "detail": repr(patch_snapshot.get("is_file"))})
    elif patch_snapshot.get("is_file") is False:
        issues.append({"issue": "patch_file_not_file", "detail": patch_path})
    if patch_snapshot.get("sha256") != report.get("patch_file_sha256"):
        issues.append({"issue": "patch_file_sha256_mismatch"})

    boundary_text = expected_boundary_text(report)
    boundary_count = (source_text or "").count(boundary_text)
    rollback_boundary_count = (rollback_text or "").count(boundary_text)
    if _quality_gated_claim_boundary_replacement(report):
        if boundary_count < 1:
            issues.append({"issue": "post_apply_boundary_text_missing", "observed": boundary_count})
    elif boundary_count != 1:
        issues.append({"issue": "post_apply_boundary_text_count_mismatch", "observed": boundary_count})
    if rollback_boundary_count != 0 and not _quality_gated_claim_boundary_replacement(report):
        issues.append({"issue": "rollback_unexpectedly_contains_boundary_text", "observed": rollback_boundary_count})
    if source_text == rollback_text:
        issues.append({"issue": "source_text_unchanged_from_rollback"})

    if not _literal_bool_or_missing(diff_check.get("performed")):
        issues.append({"issue": "invalid_diff_check_boolean:performed", "detail": repr(diff_check.get("performed"))})
    if not _literal_bool_or_missing(diff_check.get("passed")):
        issues.append({"issue": "invalid_diff_check_boolean:passed", "detail": repr(diff_check.get("passed"))})
    if not _literal_true(diff_check.get("performed")):
        issues.append({"issue": "source_diff_check_not_performed"})
    elif not _literal_true(diff_check.get("passed")):
        issues.append({"issue": "source_diff_check_failed", "returncode": diff_check.get("returncode"), "stderr": diff_check.get("stderr") or ""})

    return issues


def research_compute_manuscript_source_post_apply_verify(
    apply_report,
    source_snapshot,
    rollback_snapshot,
    patch_snapshot,
    source_text,
    rollback_text,
    diff_check,
    label="",
):
    apply_report = apply_report or {}
    source_snapshot = source_snapshot or {}
    rollback_snapshot = rollback_snapshot or {}
    patch_snapshot = patch_snapshot or {}
    diff_check = diff_check or {}
    issues = validate_post_apply(
        apply_report,
        source_snapshot,
        rollback_snapshot,
        patch_snapshot,
        source_text or "",
        rollback_text or "",
        diff_check,
    )
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_") for item in issues)
    if forbidden:
        status = "FAIL"
        state = FORBIDDEN_STATE
    elif issues:
        status = "ATTENTION"
        state = ATTENTION_STATE
    else:
        status = "PASS"
        state = VERIFIED_STATE
    verified = state == VERIFIED_STATE

    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manuscript_source_post_apply_verify_state": state,
        "post_apply_verify_created": verified,
        "slug": apply_report.get("slug") or "",
        "apply_report_path": apply_report.get("report_path") or "",
        "apply_report_sha256": apply_report.get("report_sha256") or "",
        "selected_request_id": apply_report.get("selected_request_id") or "",
        "selected_risk_class": apply_report.get("selected_risk_class") or "",
        "claim_quality_gate_ready": _literal_true(apply_report.get("claim_quality_gate_ready")),
        "source_target_path": apply_report.get("source_target_path") or "",
        "source_before_sha256": apply_report.get("source_before_sha256") or "",
        "source_after_sha256": source_snapshot.get("sha256") or "",
        "source_after_expected_sha256": apply_report.get("source_after_sha256") or "",
        "source_after_boundary_text_count": (source_text or "").count(expected_boundary_text(apply_report)),
        "rollback_snapshot_path": rollback_snapshot.get("path") or "",
        "rollback_snapshot_sha256": rollback_snapshot.get("sha256") or "",
        "rollback_snapshot_expected_sha256": apply_report.get("rollback_snapshot_sha256") or "",
        "patch_file_path": patch_snapshot.get("path") or "",
        "patch_file_sha256": patch_snapshot.get("sha256") or "",
        "source_diff_check_performed": _literal_true(diff_check.get("performed")),
        "source_diff_check_returncode": diff_check.get("returncode"),
        "source_diff_check_passed": _literal_true(diff_check.get("passed")),
        "ready_for_next_material_packet_refresh": verified,
        "required_next_gate": "research_compute_manuscript_source_change_material_packet" if verified else COMMAND.replace("-", "_"),
        "source_mutation_performed": _literal_true(apply_report.get("source_mutation_performed")),
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "boundary_text_count": (source_text or "").count(expected_boundary_text(apply_report)),
            "source_mutation_count": 1 if _literal_true(apply_report.get("source_mutation_performed")) else 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "source_diff_check": {
            "performed": _literal_true(diff_check.get("performed")),
            "returncode": diff_check.get("returncode"),
            "passed": _literal_true(diff_check.get("passed")),
            "stdout": diff_check.get("stdout") or "",
            "stderr": diff_check.get("stderr") or "",
        },
        "boundary": [
            "This command verifies the already-applied manuscript source change and records local evidence.",
            "It does not mutate package/archive state, call providers/models, perform external actions, merge/dequeue/supersede, or commit.",
            "The next manuscript request should be materialized from a refreshed source-change material packet.",
        ],
    }


def research_compute_manuscript_source_post_apply_verify_markdown(report):
    lines = [
        "# paper_factory Research Compute Manuscript Source Post-Apply Verify",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manuscript_source_post_apply_verify_state') or ''}",
        f"- Slug: `{report.get('slug') or ''}`",
        f"- Request: `{report.get('selected_request_id') or ''}` `{report.get('selected_risk_class') or ''}`",
        f"- Source target: `{report.get('source_target_path') or ''}`",
        f"- Source after SHA256: `{report.get('source_after_sha256') or ''}`",
        f"- Boundary text count: {report.get('source_after_boundary_text_count')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
