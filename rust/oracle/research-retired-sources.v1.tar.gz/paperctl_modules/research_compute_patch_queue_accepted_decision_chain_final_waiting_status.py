"""Freeze the accepted-decision chain as finally waiting for real intake."""


COMMAND = "research-compute-patch-queue-accepted-decision-chain-final-waiting-status"
CLOSURE_NONPROMOTION_COMMAND = "research-compute-patch-queue-accepted-decision-closure-capstone-nonpromotion-gate"
CLOSURE_NONPROMOTION_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_CLOSURE_CAPSTONE_NONPROMOTION_GATE_PASS_NOT_PROMOTED"
TERMINAL_COMMAND = "research-compute-patch-queue-accepted-decision-real-intake-terminal-status"
TERMINAL_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_REAL_INTAKE_TERMINAL_STATUS_AWAITING_REAL_DECISION"
FINAL_WAITING_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_CHAIN_FINAL_WAITING_STATUS_AWAITING_REAL_DECISION"
TERMINAL_STATUS = "AWAITING_REAL_ACCEPTED_DECISION_INTAKE"
FINAL_WAITING_STATUS = "FINAL_WAITING_FOR_REAL_ACCEPTED_DECISION_INTAKE"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"
POSITIVE_DECISION = "approve_for_merge_preflight"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_chain_final_waiting_status_state",
    "report_schema",
    "accepted_decision_chain_final_waiting_status_created",
    "chain_final_waiting_status_ready",
    "closure_capstone_nonpromotion_gate_verified",
    "real_intake_terminal_status_verified",
    "terminal_status",
    "final_waiting_status",
    "real_accepted_decision_required",
    "real_accepted_decision_present",
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "closure_capstone_probe_count",
    "closure_capstone_probe_rejected_count",
    "real_intake_terminal_nonpromotion_probe_count",
    "real_intake_terminal_nonpromotion_probe_rejected_count",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "merge_preflight_eligible",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "closure_capstone_nonpromotion_gate_reference",
    "closure_capstone_nonpromotion_gate_report_path",
    "real_intake_terminal_status_reference",
    "real_intake_terminal_status_report_path",
    "patch_queue_row",
    "accepted_decision_chain_final_waiting_status_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "closure_capstone_probe_count",
    "closure_capstone_probe_rejected_count",
    "real_intake_terminal_nonpromotion_probe_count",
    "real_intake_terminal_nonpromotion_probe_rejected_count",
    "accepted_decision_intake_report_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "real_accepted_decision_present_count",
    "merge_preflight_allowed_count",
    "merge_preflight_eligible_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Freezes the accepted-decision chain as finally waiting for real decision intake.",
    "Closure capstone and nonpromotion evidence remain local status material only.",
    "This command records report/status only and does not create decisions, start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]

FORBIDDEN_REPORT_FLAGS = [
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "real_accepted_decision_present",
    "terminal_chain_closure_capstone_promoted",
    "closure_capstone_packet_promoted",
    "positive_shape_dry_run_promoted",
    "synthetic_decision_fixture_promoted",
    "merge_preflight_eligible",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
]

FORBIDDEN_PACKET_FLAGS = [
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "real_accepted_decision_present",
    "terminal_chain_closure_capstone_promoted",
    "closure_capstone_packet_promoted",
    "positive_shape_dry_run_promoted",
    "synthetic_decision_fixture_promoted",
    "ordinary_patch_consumer_allowed",
    "merge_preflight_allowed",
    "merge_preflight_eligible",
    "merge_authorized",
    "merge_performed",
    "commit_allowed",
    "commit_performed",
]


def _forbidden_issue(issue):
    text = str((issue or {}).get("issue") or "")
    return text.startswith("forbidden_")


def _packet(report, key):
    return (report or {}).get(key) or {}


def _add_true_issue(issues, data, key, prefix):
    if (data or {}).get(key):
        issues.append({"issue": f"{prefix}:{key}"})


def _validate_false_flags(issues, data, keys, prefix):
    for key in keys:
        _add_true_issue(issues, data, key, prefix)


def validate_closure_capstone_nonpromotion_gate_report(closure_capstone_nonpromotion_gate_report):
    issues = []
    report = closure_capstone_nonpromotion_gate_report or {}
    packet = _packet(report, "accepted_decision_closure_capstone_nonpromotion_gate_packet")
    if report.get("command") != CLOSURE_NONPROMOTION_COMMAND:
        issues.append({"issue": "closure_nonpromotion_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "closure_nonpromotion_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_closure_capstone_nonpromotion_gate_state") != CLOSURE_NONPROMOTION_STATE:
        issues.append({
            "issue": "closure_nonpromotion_state_mismatch",
            "detail": report.get("accepted_decision_closure_capstone_nonpromotion_gate_state") or "",
        })
    for key in [
        "accepted_decision_closure_capstone_nonpromotion_gate_created",
        "terminal_chain_closure_capstone_verified",
        "decision_template_verify_verified",
        "closure_capstone_probe_matrix_created",
        "closure_capstone_report_rejected_as_accepted_decision",
        "closure_capstone_packet_rejected_as_accepted_decision",
        "closure_capstone_report_rejected_as_merge_preflight_input",
    ]:
        if not report.get(key):
            issues.append({"issue": f"closure_nonpromotion_{key}_required"})

    probe_count = int(report.get("closure_capstone_probe_count") or 0)
    rejected_count = int(report.get("closure_capstone_probe_rejected_count") or 0)
    if probe_count < 3:
        issues.append({"issue": "closure_nonpromotion_probe_count_too_low", "detail": probe_count})
    if rejected_count != probe_count or rejected_count < 3:
        issues.append({"issue": "closure_nonpromotion_probes_not_all_rejected", "detail": f"{rejected_count}/{probe_count}"})

    _validate_false_flags(issues, report, FORBIDDEN_REPORT_FLAGS, "forbidden_closure_nonpromotion_report_boundary_crossed")
    if report.get("validation_issues"):
        issues.append({"issue": "closure_nonpromotion_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("closure_capstone_nonpromotion_gate_ready") is not True:
        issues.append({"issue": "closure_nonpromotion_packet_not_ready"})
    if int(packet.get("closure_capstone_probe_rejected_count") or 0) != int(packet.get("closure_capstone_probe_count") or 0):
        issues.append({"issue": "closure_nonpromotion_packet_probes_not_all_rejected"})
    _validate_false_flags(issues, packet, FORBIDDEN_PACKET_FLAGS, "forbidden_closure_nonpromotion_packet_boundary_crossed")
    if packet.get("decision") or packet.get("decision_scope"):
        issues.append({"issue": "closure_nonpromotion_packet_decision_must_be_empty"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "closure_nonpromotion_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for probe in report.get("closure_capstone_probe_matrix") or []:
        if not probe.get("rejected") or probe.get("promoted"):
            issues.append({"issue": "closure_nonpromotion_probe_promoted_or_unrejected", "detail": probe.get("probe_name") or ""})
    return issues


def validate_real_intake_terminal_status_report(real_intake_terminal_status_report):
    issues = []
    report = real_intake_terminal_status_report or {}
    packet = _packet(report, "accepted_decision_real_intake_terminal_status_packet")
    if report.get("command") != TERMINAL_COMMAND:
        issues.append({"issue": "real_intake_terminal_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "real_intake_terminal_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_real_intake_terminal_status_state") != TERMINAL_STATE:
        issues.append({
            "issue": "real_intake_terminal_state_mismatch",
            "detail": report.get("accepted_decision_real_intake_terminal_status_state") or "",
        })
    if not report.get("accepted_decision_real_intake_terminal_status_created"):
        issues.append({"issue": "real_intake_terminal_created_required"})
    if report.get("terminal_status") != TERMINAL_STATUS:
        issues.append({"issue": "real_intake_terminal_status_mismatch", "detail": report.get("terminal_status") or ""})
    if not report.get("real_accepted_decision_required") or report.get("real_accepted_decision_present"):
        issues.append({"issue": "real_intake_terminal_real_decision_requirement_mismatch"})
    if int(report.get("nonpromotion_probe_rejected_count") or 0) < 3:
        issues.append({"issue": "real_intake_terminal_nonpromotion_count_too_low"})
    _validate_false_flags(issues, report, FORBIDDEN_REPORT_FLAGS, "forbidden_real_intake_terminal_report_boundary_crossed")
    if report.get("validation_issues"):
        issues.append({"issue": "real_intake_terminal_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("terminal_status_ready") is not True:
        issues.append({"issue": "real_intake_terminal_packet_not_ready"})
    if packet.get("terminal_status") != TERMINAL_STATUS:
        issues.append({"issue": "real_intake_terminal_packet_status_mismatch", "detail": packet.get("terminal_status") or ""})
    if not packet.get("real_accepted_decision_required") or packet.get("real_accepted_decision_present"):
        issues.append({"issue": "real_intake_terminal_packet_real_decision_requirement_mismatch"})
    _validate_false_flags(issues, packet, FORBIDDEN_PACKET_FLAGS, "forbidden_real_intake_terminal_packet_boundary_crossed")
    if packet.get("decision") or packet.get("decision_scope"):
        issues.append({"issue": "real_intake_terminal_packet_decision_must_be_empty"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "real_intake_terminal_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    return issues


def validate_final_waiting_alignment(closure_capstone_nonpromotion_gate_report, real_intake_terminal_status_report, patch_queue_row):
    issues = []
    closure_packet = _packet(
        closure_capstone_nonpromotion_gate_report,
        "accepted_decision_closure_capstone_nonpromotion_gate_packet",
    )
    terminal_packet = _packet(real_intake_terminal_status_report, "accepted_decision_real_intake_terminal_status_packet")
    for field in [
        "patch_id",
        "slug",
        "candidate_note_path",
        "candidate_note_sha256",
        "queue_artifact_path",
        "queue_artifact_sha256",
        "decision_template_path",
        "decision_template_sha256",
    ]:
        if closure_packet.get(field) != terminal_packet.get(field):
            issues.append({"issue": f"final_waiting_{field}_mismatch"})

    row = patch_queue_row or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(closure_packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != closure_packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != closure_packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != closure_packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if closure_packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("candidate_note_path") != closure_packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != closure_packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != closure_packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def research_compute_patch_queue_accepted_decision_chain_final_waiting_status(
    closure_capstone_nonpromotion_gate_report,
    real_intake_terminal_status_report,
    patch_queue_row=None,
    label="",
):
    closure_capstone_nonpromotion_gate_report = closure_capstone_nonpromotion_gate_report or {}
    real_intake_terminal_status_report = real_intake_terminal_status_report or {}
    patch_queue_row = patch_queue_row or {}
    issues = validate_closure_capstone_nonpromotion_gate_report(closure_capstone_nonpromotion_gate_report)
    issues.extend(validate_real_intake_terminal_status_report(real_intake_terminal_status_report))
    issues.extend(validate_final_waiting_alignment(
        closure_capstone_nonpromotion_gate_report,
        real_intake_terminal_status_report,
        patch_queue_row,
    ))

    forbidden = any(_forbidden_issue(item) for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_CHAIN_FINAL_WAITING_STATUS_BLOCKED"
    else:
        status = "PASS"
        state = FINAL_WAITING_STATE

    closure_packet = _packet(
        closure_capstone_nonpromotion_gate_report,
        "accepted_decision_closure_capstone_nonpromotion_gate_packet",
    )
    terminal_packet = _packet(real_intake_terminal_status_report, "accepted_decision_real_intake_terminal_status_packet")
    closure_probe_count = int(closure_capstone_nonpromotion_gate_report.get("closure_capstone_probe_count") or 0)
    closure_rejected_count = int(closure_capstone_nonpromotion_gate_report.get("closure_capstone_probe_rejected_count") or 0)
    terminal_probe_count = int(real_intake_terminal_status_report.get("nonpromotion_probe_count") or 0)
    terminal_rejected_count = int(real_intake_terminal_status_report.get("nonpromotion_probe_rejected_count") or 0)
    final_packet = {
        "chain_final_waiting_status_ready": status == "PASS",
        "final_waiting_status": FINAL_WAITING_STATUS if status == "PASS" else "",
        "terminal_status": TERMINAL_STATUS if status == "PASS" else "",
        "real_accepted_decision_required": True,
        "real_accepted_decision_present": False,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "closure_capstone_probe_count": closure_probe_count,
        "closure_capstone_probe_rejected_count": closure_rejected_count,
        "real_intake_terminal_nonpromotion_probe_count": terminal_probe_count,
        "real_intake_terminal_nonpromotion_probe_rejected_count": terminal_rejected_count,
        "decision": "",
        "decision_scope": "",
        "allowed_real_decision": POSITIVE_DECISION,
        "allowed_real_decision_scope": DECISION_SCOPE,
        "patch_id": int(closure_packet.get("patch_id") or terminal_packet.get("patch_id") or 0),
        "slug": closure_packet.get("slug") or terminal_packet.get("slug") or "",
        "patch_queue_status": patch_queue_row.get("status") or "",
        "candidate_note_path": closure_packet.get("candidate_note_path") or terminal_packet.get("candidate_note_path") or "",
        "candidate_note_sha256": closure_packet.get("candidate_note_sha256") or terminal_packet.get("candidate_note_sha256") or "",
        "queue_artifact_path": closure_packet.get("queue_artifact_path") or terminal_packet.get("queue_artifact_path") or "",
        "queue_artifact_sha256": closure_packet.get("queue_artifact_sha256") or terminal_packet.get("queue_artifact_sha256") or "",
        "decision_template_path": closure_packet.get("decision_template_path") or terminal_packet.get("decision_template_path") or "",
        "decision_template_sha256": closure_packet.get("decision_template_sha256") or terminal_packet.get("decision_template_sha256") or "",
        "ordinary_patch_consumer_allowed": False,
        "merge_preflight_allowed": False,
        "merge_preflight_eligible": False,
        "merge_authorized": False,
        "merge_performed": False,
        "commit_allowed": False,
        "commit_performed": False,
        "required_next_gate": INTAKE_GATE,
    }
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_chain_final_waiting_status_state": state,
        "accepted_decision_chain_final_waiting_status_created": status == "PASS",
        "chain_final_waiting_status_ready": status == "PASS",
        "closure_capstone_nonpromotion_gate_verified": status == "PASS",
        "real_intake_terminal_status_verified": status == "PASS",
        "terminal_status": final_packet["terminal_status"],
        "final_waiting_status": final_packet["final_waiting_status"],
        "real_accepted_decision_required": True,
        "real_accepted_decision_present": False,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "closure_capstone_probe_count": closure_probe_count,
        "closure_capstone_probe_rejected_count": closure_rejected_count,
        "real_intake_terminal_nonpromotion_probe_count": terminal_probe_count,
        "real_intake_terminal_nonpromotion_probe_rejected_count": terminal_rejected_count,
        "patch_queue_review_only_guarded": True,
        "ordinary_patch_consumer_blocked": True,
        "merge_preflight_eligible": False,
        "patch_queue_merge_preflight_allowed": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "closure_capstone_probe_count": closure_probe_count,
            "closure_capstone_probe_rejected_count": closure_rejected_count,
            "real_intake_terminal_nonpromotion_probe_count": terminal_probe_count,
            "real_intake_terminal_nonpromotion_probe_rejected_count": terminal_rejected_count,
            "accepted_decision_intake_report_count": 0,
            "accepted_decision_intake_present_count": 0,
            "decision_accepted_count": 0,
            "real_accepted_decision_present_count": 0,
            "merge_preflight_allowed_count": 0,
            "merge_preflight_eligible_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "closure_capstone_nonpromotion_gate_reference": {
            "report_path": closure_capstone_nonpromotion_gate_report.get("report_path") or "",
            "status": closure_capstone_nonpromotion_gate_report.get("status") or "",
            "accepted_decision_closure_capstone_nonpromotion_gate_state": closure_capstone_nonpromotion_gate_report.get(
                "accepted_decision_closure_capstone_nonpromotion_gate_state"
            ) or "",
        },
        "real_intake_terminal_status_reference": {
            "report_path": real_intake_terminal_status_report.get("report_path") or "",
            "status": real_intake_terminal_status_report.get("status") or "",
            "accepted_decision_real_intake_terminal_status_state": real_intake_terminal_status_report.get(
                "accepted_decision_real_intake_terminal_status_state"
            ) or "",
        },
        "patch_queue_row": patch_queue_row,
        "accepted_decision_chain_final_waiting_status_packet": final_packet,
        "boundary": [
            "This command freezes the accepted-decision chain as finally waiting for real decision intake.",
            "The closure capstone and all nonpromotion evidence remain status material only.",
            "Only a standalone manual-review decision-intake report accepting the narrow approve_for_merge_preflight decision can move the row toward merge preflight.",
            "This command does not create a decision file, create an accepted-decision report, start preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_chain_final_waiting_status_markdown(report):
    packet = report.get("accepted_decision_chain_final_waiting_status_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Chain Final Waiting Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_chain_final_waiting_status_state') or ''}",
        f"- Final waiting status: {report.get('final_waiting_status') or ''}",
        f"- Terminal status: {report.get('terminal_status') or ''}",
        f"- Closure capstone probes: {report.get('closure_capstone_probe_rejected_count')}/{report.get('closure_capstone_probe_count')}",
        f"- Real-intake terminal probes: {report.get('real_intake_terminal_nonpromotion_probe_rejected_count')}/{report.get('real_intake_terminal_nonpromotion_probe_count')}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Final Waiting Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
