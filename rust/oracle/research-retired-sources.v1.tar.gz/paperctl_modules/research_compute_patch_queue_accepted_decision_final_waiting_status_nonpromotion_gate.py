"""Prove final-waiting-status material cannot be promoted to acceptance."""

from paperctl_modules import research_compute_patch_queue_manual_review_decision_reintake_status as reintake_status_core
from paperctl_modules import research_compute_patch_queue_merge_preflight_refusal as merge_preflight_refusal_core


COMMAND = "research-compute-patch-queue-accepted-decision-final-waiting-status-nonpromotion-gate"
FINAL_WAITING_COMMAND = "research-compute-patch-queue-accepted-decision-chain-final-waiting-status"
FINAL_WAITING_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_CHAIN_FINAL_WAITING_STATUS_AWAITING_REAL_DECISION"
TEMPLATE_VERIFY_COMMAND = "research-compute-patch-queue-manual-review-decision-template-verify"
TEMPLATE_VERIFY_STATE = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_TEMPLATE_VERIFIED_AWAITING_DECISION"
TERMINAL_STATUS = "AWAITING_REAL_ACCEPTED_DECISION_INTAKE"
FINAL_WAITING_STATUS = "FINAL_WAITING_FOR_REAL_ACCEPTED_DECISION_INTAKE"
POSITIVE_DECISION = "approve_for_merge_preflight"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_final_waiting_status_nonpromotion_gate_state",
    "report_schema",
    "accepted_decision_final_waiting_status_nonpromotion_gate_created",
    "chain_final_waiting_status_verified",
    "decision_template_verify_verified",
    "final_waiting_status_probe_matrix_created",
    "final_waiting_status_probe_count",
    "final_waiting_status_probe_rejected_count",
    "final_waiting_status_report_rejected_as_accepted_decision",
    "final_waiting_status_packet_rejected_as_accepted_decision",
    "final_waiting_status_report_rejected_as_merge_preflight_input",
    "terminal_status",
    "final_waiting_status",
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "chain_final_waiting_status_promoted",
    "final_waiting_status_packet_promoted",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_preflight_allowed",
    "merge_preflight_eligible",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "chain_final_waiting_status_reference",
    "final_waiting_status_report_path",
    "decision_template_verify_reference",
    "decision_template_verify_report_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "final_waiting_status_probe_matrix",
    "accepted_decision_final_waiting_status_nonpromotion_gate_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "final_waiting_status_probe_count",
    "final_waiting_status_probe_rejected_count",
    "accepted_decision_intake_report_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "merge_preflight_allowed_count",
    "merge_preflight_eligible_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Proves final-waiting-status material is non-promotable status material.",
    "Final-waiting reports and packets are rejected as accepted decision-intake inputs.",
    "This command records report/status only and does not create accepted decisions, start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _forbidden_issue(issue):
    text = str((issue or {}).get("issue") or "")
    return text.startswith("forbidden_")


def validate_final_waiting_status_report(final_waiting_status_report):
    issues = []
    report = final_waiting_status_report or {}
    packet = report.get("accepted_decision_chain_final_waiting_status_packet") or {}
    if report.get("command") != FINAL_WAITING_COMMAND:
        issues.append({"issue": "final_waiting_status_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "final_waiting_status_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_chain_final_waiting_status_state") != FINAL_WAITING_STATE:
        issues.append({
            "issue": "final_waiting_status_state_mismatch",
            "detail": report.get("accepted_decision_chain_final_waiting_status_state") or "",
        })
    if not report.get("accepted_decision_chain_final_waiting_status_created"):
        issues.append({"issue": "final_waiting_status_created_required"})
    if not report.get("chain_final_waiting_status_ready"):
        issues.append({"issue": "final_waiting_status_ready_required"})
    if report.get("terminal_status") != TERMINAL_STATUS:
        issues.append({"issue": "final_waiting_terminal_status_mismatch", "detail": report.get("terminal_status") or ""})
    if report.get("final_waiting_status") != FINAL_WAITING_STATUS:
        issues.append({"issue": "final_waiting_status_value_mismatch", "detail": report.get("final_waiting_status") or ""})
    if not report.get("real_accepted_decision_required") or report.get("real_accepted_decision_present"):
        issues.append({"issue": "final_waiting_real_decision_requirement_mismatch"})
    if int(report.get("closure_capstone_probe_rejected_count") or 0) != int(report.get("closure_capstone_probe_count") or 0):
        issues.append({"issue": "final_waiting_closure_probe_count_mismatch"})
    if int(report.get("closure_capstone_probe_rejected_count") or 0) < 3:
        issues.append({"issue": "final_waiting_closure_probe_count_too_low"})
    if int(report.get("real_intake_terminal_nonpromotion_probe_rejected_count") or 0) != int(report.get("real_intake_terminal_nonpromotion_probe_count") or 0):
        issues.append({"issue": "final_waiting_real_intake_terminal_probe_count_mismatch"})
    if int(report.get("real_intake_terminal_nonpromotion_probe_rejected_count") or 0) < 3:
        issues.append({"issue": "final_waiting_real_intake_terminal_probe_count_too_low"})
    for key in [
        "closure_capstone_nonpromotion_gate_verified",
        "real_intake_terminal_status_verified",
    ]:
        if not report.get(key):
            issues.append({"issue": f"final_waiting_{key}_required"})
    for key in [
        "accepted_decision_intake_report_created",
        "accepted_decision_intake_present",
        "manual_review_decision_present",
        "manual_review_decision_accepted",
        "real_accepted_decision_present",
        "merge_preflight_eligible",
        "patch_queue_merge_preflight_allowed",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_final_waiting_status_boundary_crossed:{key}"})
    if report.get("validation_issues"):
        issues.append({"issue": "final_waiting_status_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("chain_final_waiting_status_ready") is not True:
        issues.append({"issue": "final_waiting_status_packet_not_ready"})
    if packet.get("terminal_status") != TERMINAL_STATUS:
        issues.append({"issue": "final_waiting_status_packet_terminal_status_mismatch", "detail": packet.get("terminal_status") or ""})
    if packet.get("final_waiting_status") != FINAL_WAITING_STATUS:
        issues.append({"issue": "final_waiting_status_packet_value_mismatch", "detail": packet.get("final_waiting_status") or ""})
    if not packet.get("real_accepted_decision_required") or packet.get("real_accepted_decision_present"):
        issues.append({"issue": "final_waiting_status_packet_real_decision_requirement_mismatch"})
    if int(packet.get("closure_capstone_probe_rejected_count") or 0) != int(packet.get("closure_capstone_probe_count") or 0):
        issues.append({"issue": "final_waiting_status_packet_closure_probe_count_mismatch"})
    if int(packet.get("real_intake_terminal_nonpromotion_probe_rejected_count") or 0) != int(packet.get("real_intake_terminal_nonpromotion_probe_count") or 0):
        issues.append({"issue": "final_waiting_status_packet_real_intake_terminal_probe_count_mismatch"})
    for key in [
        "accepted_decision_intake_report_created",
        "accepted_decision_intake_present",
        "manual_review_decision_present",
        "manual_review_decision_accepted",
        "real_accepted_decision_present",
        "ordinary_patch_consumer_allowed",
        "merge_preflight_allowed",
        "merge_preflight_eligible",
        "merge_authorized",
        "merge_performed",
        "commit_allowed",
        "commit_performed",
    ]:
        if packet.get(key):
            issues.append({"issue": f"forbidden_final_waiting_status_packet_boundary_crossed:{key}"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "final_waiting_status_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    return issues


def validate_template_verify_alignment(final_waiting_status_report, template_verify_report):
    issues = []
    final_packet = (final_waiting_status_report or {}).get("accepted_decision_chain_final_waiting_status_packet") or {}
    verify_packet = (template_verify_report or {}).get("decision_template_verify_packet") or {}
    if (template_verify_report or {}).get("command") != TEMPLATE_VERIFY_COMMAND:
        issues.append({"issue": "template_verify_command_mismatch", "detail": (template_verify_report or {}).get("command") or ""})
    if (template_verify_report or {}).get("decision_template_verify_state") != TEMPLATE_VERIFY_STATE:
        issues.append({"issue": "template_verify_state_mismatch", "detail": (template_verify_report or {}).get("decision_template_verify_state") or ""})
    for field in [
        "patch_id",
        "slug",
        "candidate_note_path",
        "candidate_note_sha256",
        "queue_artifact_path",
        "queue_artifact_sha256",
        "decision_template_path",
        "decision_template_sha256",
    ]:
        if final_packet.get(field) != verify_packet.get(field):
            issues.append({"issue": f"final_waiting_status_template_verify_{field}_mismatch"})
    return issues


def _reintake_probe_summary(probe_report):
    packet = (probe_report or {}).get("decision_reintake_status_packet") or {}
    return {
        "status": (probe_report or {}).get("status") or "",
        "decision_reintake_status_state": (probe_report or {}).get("decision_reintake_status_state") or "",
        "accepted_decision_intake_present": bool((probe_report or {}).get("accepted_decision_intake_present")),
        "manual_review_decision_accepted": bool((probe_report or {}).get("manual_review_decision_accepted")),
        "patch_queue_merge_preflight_allowed": bool((probe_report or {}).get("patch_queue_merge_preflight_allowed")),
        "patch_queue_merge_performed": bool((probe_report or {}).get("patch_queue_merge_performed")),
        "commit_performed": bool((probe_report or {}).get("commit_performed")),
        "required_next_gate": packet.get("required_next_gate") or "",
        "validation_issue_count": len((probe_report or {}).get("validation_issues") or []),
        "validation_issue_names": [item.get("issue") or "" for item in (probe_report or {}).get("validation_issues") or []],
    }


def _merge_probe_summary(probe_report):
    packet = (probe_report or {}).get("merge_preflight_refusal_packet") or {}
    return {
        "status": (probe_report or {}).get("status") or "",
        "merge_preflight_refusal_state": (probe_report or {}).get("merge_preflight_refusal_state") or "",
        "accepted_decision_intake_present": bool((probe_report or {}).get("accepted_decision_intake_present")),
        "manual_review_decision_accepted": bool((probe_report or {}).get("manual_review_decision_accepted")),
        "merge_preflight_eligible": bool((probe_report or {}).get("merge_preflight_eligible")),
        "patch_queue_merge_preflight_allowed": bool((probe_report or {}).get("patch_queue_merge_preflight_allowed")),
        "patch_queue_merge_performed": bool((probe_report or {}).get("patch_queue_merge_performed")),
        "commit_performed": bool((probe_report or {}).get("commit_performed")),
        "required_next_gate": packet.get("required_next_gate") or "",
        "validation_issue_count": len((probe_report or {}).get("validation_issues") or []),
        "validation_issue_names": [item.get("issue") or "" for item in (probe_report or {}).get("validation_issues") or []],
    }


def build_final_waiting_status_probe_matrix(final_waiting_status_report, template_verify_report, patch_queue_row, queue_artifact_snapshot):
    final_packet = (final_waiting_status_report or {}).get("accepted_decision_chain_final_waiting_status_packet") or {}
    final_report_reintake_probe = reintake_status_core.research_compute_patch_queue_manual_review_decision_reintake_status(
        template_verify_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        accepted_decision_intake_report=final_waiting_status_report,
        label="final-waiting-status-nonpromotion-report-as-intake",
    )
    final_packet_reintake_probe = reintake_status_core.research_compute_patch_queue_manual_review_decision_reintake_status(
        template_verify_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        accepted_decision_intake_report=final_packet,
        label="final-waiting-status-nonpromotion-packet-as-intake",
    )
    final_report_merge_probe = merge_preflight_refusal_core.research_compute_patch_queue_merge_preflight_refusal(
        final_waiting_status_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        label="final-waiting-status-nonpromotion-report-as-merge-preflight-input",
    )
    probes = [
        {
            "probe_name": "final_waiting_status_report_as_accepted_decision_intake_report",
            "probe_type": "decision_reintake",
            "summary": _reintake_probe_summary(final_report_reintake_probe),
        },
        {
            "probe_name": "final_waiting_status_packet_as_accepted_decision_intake_report",
            "probe_type": "decision_reintake",
            "summary": _reintake_probe_summary(final_packet_reintake_probe),
        },
        {
            "probe_name": "final_waiting_status_report_as_merge_preflight_input",
            "probe_type": "merge_preflight_refusal",
            "summary": _merge_probe_summary(final_report_merge_probe),
        },
    ]
    for probe in probes:
        summary = probe["summary"]
        promoted = (
            summary.get("manual_review_decision_accepted")
            or summary.get("patch_queue_merge_preflight_allowed")
            or summary.get("merge_preflight_eligible")
            or summary.get("patch_queue_merge_performed")
            or summary.get("commit_performed")
        )
        probe["promoted"] = bool(promoted)
        probe["rejected"] = not promoted and int(summary.get("validation_issue_count") or 0) > 0
        probe["rejection_reason"] = "final_waiting_status_is_not_real_accepted_decision_intake" if probe["rejected"] else ""
    return probes


def research_compute_patch_queue_accepted_decision_final_waiting_status_nonpromotion_gate(
    final_waiting_status_report,
    template_verify_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    final_waiting_status_report = final_waiting_status_report or {}
    template_verify_report = template_verify_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_final_waiting_status_report(final_waiting_status_report)
    issues.extend(reintake_status_core.validate_template_verify_report(template_verify_report))
    issues.extend(reintake_status_core.validate_patch_queue_row(patch_queue_row, template_verify_report))
    issues.extend(reintake_status_core.validate_queue_artifact(queue_artifact_snapshot, template_verify_report))
    issues.extend(validate_template_verify_alignment(final_waiting_status_report, template_verify_report))
    probe_matrix = build_final_waiting_status_probe_matrix(
        final_waiting_status_report,
        template_verify_report,
        patch_queue_row,
        queue_artifact_snapshot,
    )
    for probe in probe_matrix:
        if not probe.get("rejected"):
            issues.append({"issue": "final_waiting_status_nonpromotion_probe_not_rejected", "detail": probe.get("probe_name") or ""})
        summary = probe.get("summary") or {}
        if summary.get("patch_queue_merge_performed") or summary.get("commit_performed"):
            issues.append({"issue": f"forbidden_final_waiting_status_probe_boundary:{probe.get('probe_name') or ''}"})

    forbidden = any(_forbidden_issue(item) for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_FINAL_WAITING_STATUS_NONPROMOTION_GATE_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_FINAL_WAITING_STATUS_NONPROMOTION_GATE_PASS_NOT_PROMOTED"

    final_packet = final_waiting_status_report.get("accepted_decision_chain_final_waiting_status_packet") or {}
    verify_packet = template_verify_report.get("decision_template_verify_packet") or {}
    rejected_count = sum(1 for probe in probe_matrix if probe.get("rejected"))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_final_waiting_status_nonpromotion_gate_state": state,
        "accepted_decision_final_waiting_status_nonpromotion_gate_created": status == "PASS",
        "chain_final_waiting_status_verified": status == "PASS",
        "decision_template_verify_verified": status == "PASS",
        "final_waiting_status_probe_matrix_created": status == "PASS",
        "final_waiting_status_probe_count": len(probe_matrix),
        "final_waiting_status_probe_rejected_count": rejected_count,
        "final_waiting_status_report_rejected_as_accepted_decision": any(
            item.get("probe_name") == "final_waiting_status_report_as_accepted_decision_intake_report" and item.get("rejected")
            for item in probe_matrix
        ),
        "final_waiting_status_packet_rejected_as_accepted_decision": any(
            item.get("probe_name") == "final_waiting_status_packet_as_accepted_decision_intake_report" and item.get("rejected")
            for item in probe_matrix
        ),
        "final_waiting_status_report_rejected_as_merge_preflight_input": any(
            item.get("probe_name") == "final_waiting_status_report_as_merge_preflight_input" and item.get("rejected")
            for item in probe_matrix
        ),
        "terminal_status": final_waiting_status_report.get("terminal_status") or "",
        "final_waiting_status": final_waiting_status_report.get("final_waiting_status") or "",
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "chain_final_waiting_status_promoted": False,
        "final_waiting_status_packet_promoted": False,
        "patch_queue_review_only_guarded": bool(template_verify_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(template_verify_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_preflight_allowed": False,
        "merge_preflight_eligible": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "final_waiting_status_probe_count": len(probe_matrix),
            "final_waiting_status_probe_rejected_count": rejected_count,
            "accepted_decision_intake_report_count": 0,
            "accepted_decision_intake_present_count": 0,
            "decision_accepted_count": 0,
            "merge_preflight_allowed_count": 0,
            "merge_preflight_eligible_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "chain_final_waiting_status_reference": {
            "report_path": final_waiting_status_report.get("report_path") or "",
            "status": final_waiting_status_report.get("status") or "",
            "accepted_decision_chain_final_waiting_status_state": final_waiting_status_report.get(
                "accepted_decision_chain_final_waiting_status_state"
            ) or "",
        },
        "decision_template_verify_reference": {
            "report_path": template_verify_report.get("report_path") or "",
            "status": template_verify_report.get("status") or "",
            "decision_template_verify_state": template_verify_report.get("decision_template_verify_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "final_waiting_status_probe_matrix": probe_matrix,
        "accepted_decision_final_waiting_status_nonpromotion_gate_packet": {
            "final_waiting_status_nonpromotion_gate_ready": status == "PASS",
            "final_waiting_status_probe_matrix_created": status == "PASS",
            "final_waiting_status_probe_count": len(probe_matrix),
            "final_waiting_status_probe_rejected_count": rejected_count,
            "accepted_decision_intake_report_created": False,
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "chain_final_waiting_status_promoted": False,
            "final_waiting_status_packet_promoted": False,
            "terminal_status": final_waiting_status_report.get("terminal_status") or "",
            "final_waiting_status": final_waiting_status_report.get("final_waiting_status") or "",
            "decision": "",
            "decision_scope": "",
            "allowed_real_decision": POSITIVE_DECISION,
            "allowed_real_decision_scope": DECISION_SCOPE,
            "patch_id": int(final_packet.get("patch_id") or verify_packet.get("patch_id") or 0),
            "slug": final_packet.get("slug") or verify_packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": final_packet.get("candidate_note_path") or verify_packet.get("candidate_note_path") or "",
            "candidate_note_sha256": final_packet.get("candidate_note_sha256") or verify_packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": final_packet.get("queue_artifact_path") or verify_packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": final_packet.get("queue_artifact_sha256") or verify_packet.get("queue_artifact_sha256") or "",
            "decision_template_path": final_packet.get("decision_template_path") or verify_packet.get("decision_template_path") or "",
            "decision_template_sha256": final_packet.get("decision_template_sha256") or verify_packet.get("decision_template_sha256") or "",
            "ordinary_patch_consumer_allowed": False,
            "merge_preflight_allowed": False,
            "merge_preflight_eligible": False,
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": INTAKE_GATE,
        },
        "boundary": [
            "This command treats the final-waiting status report as explicit non-promotable status material.",
            "It proves the final-waiting report and packet are rejected as accepted decision-intake inputs.",
            "It also proves the final-waiting report is rejected as a merge-preflight input.",
            "This command does not create a decision file, create an accepted decision report, start preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_final_waiting_status_nonpromotion_gate_markdown(report):
    packet = report.get("accepted_decision_final_waiting_status_nonpromotion_gate_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Final Waiting Status Nonpromotion Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_final_waiting_status_nonpromotion_gate_state') or ''}",
        f"- Final waiting status: {report.get('final_waiting_status') or ''}",
        f"- Final-waiting probes: {report.get('final_waiting_status_probe_rejected_count')}/{report.get('final_waiting_status_probe_count')}",
        f"- Final-waiting report rejected as accepted decision: {report.get('final_waiting_status_report_rejected_as_accepted_decision')}",
        f"- Final-waiting packet rejected as accepted decision: {report.get('final_waiting_status_packet_rejected_as_accepted_decision')}",
        f"- Final-waiting report rejected as merge-preflight input: {report.get('final_waiting_status_report_rejected_as_merge_preflight_input')}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Final Waiting Status Nonpromotion Gate Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
