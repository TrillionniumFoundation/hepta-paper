"""Prove fixtures and generic authorization cannot unlock merge preflight."""


COMMAND = "research-compute-patch-queue-accepted-decision-fixture-negative-gate"
PREVIOUS_COMMAND = "research-compute-patch-queue-merge-preflight-refusal"
PREVIOUS_STATE = "PATCH_QUEUE_MERGE_PREFLIGHT_REFUSED_AWAITING_ACCEPTED_DECISION"
DECISION_TEMPLATE_TYPE = "research_compute_patch_queue_manual_review_decision_template.v1"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"
ALLOWED_DECISION = "approve_for_merge_preflight"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_fixture_negative_gate_state",
    "report_schema",
    "accepted_decision_fixture_negative_gate_created",
    "merge_preflight_refusal_verified",
    "decision_template_verified_not_decision",
    "negative_fixture_matrix_created",
    "negative_fixture_count",
    "negative_fixture_rejected_count",
    "accepted_decision_intake_required",
    "accepted_decision_intake_present",
    "manual_review_decision_accepted",
    "generic_authorization_rejected",
    "blank_template_rejected",
    "forged_decision_without_intake_rejected",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "merge_preflight_refusal_reference",
    "merge_preflight_refusal_report_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "decision_template_snapshot",
    "negative_fixture_matrix",
    "accepted_decision_fixture_negative_gate_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "negative_fixture_count",
    "negative_fixture_rejected_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "merge_preflight_allowed_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Proves that blank templates, generic authorization text, and forged decision fields are not accepted decision-intake reports.",
    "Merge preflight remains blocked until a separate accepted decision-intake report exists.",
    "This command records status only and does not start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_merge_preflight_refusal_report(merge_preflight_refusal_report):
    issues = []
    report = merge_preflight_refusal_report or {}
    packet = report.get("merge_preflight_refusal_packet") or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "merge_preflight_refusal_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "merge_preflight_refusal_not_pass", "detail": report.get("status") or ""})
    if report.get("merge_preflight_refusal_state") != PREVIOUS_STATE:
        issues.append({"issue": "merge_preflight_refusal_state_mismatch", "detail": report.get("merge_preflight_refusal_state") or ""})
    if not report.get("merge_preflight_refusal_created"):
        issues.append({"issue": "merge_preflight_refusal_created_required"})
    if not report.get("decision_reintake_status_verified"):
        issues.append({"issue": "decision_reintake_status_verified_required"})
    if not report.get("accepted_decision_required"):
        issues.append({"issue": "accepted_decision_required_flag_required"})
    if report.get("accepted_decision_intake_present"):
        issues.append({"issue": "accepted_decision_intake_must_be_absent_for_negative_gate"})
    if report.get("manual_review_decision_present") or report.get("manual_review_decision_accepted"):
        issues.append({"issue": "accepted_manual_review_decision_must_be_absent"})
    if not report.get("ordinary_patch_consumer_blocked"):
        issues.append({"issue": "ordinary_patch_consumer_block_required"})
    if not report.get("merge_preflight_refused"):
        issues.append({"issue": "merge_preflight_refused_required"})
    if report.get("merge_preflight_eligible") or report.get("patch_queue_merge_preflight_allowed"):
        issues.append({"issue": "merge_preflight_must_not_be_allowed"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "merge_preflight_refusal_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "merge_preflight_refusal_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    candidate_note = str(packet.get("candidate_note_path") or "")
    if not packet.get("merge_preflight_refusal_ready"):
        issues.append({"issue": "merge_preflight_refusal_packet_not_ready"})
    if not packet.get("merge_preflight_refused"):
        issues.append({"issue": "merge_preflight_refusal_packet_refusal_required"})
    if packet.get("merge_preflight_eligible") or packet.get("merge_preflight_allowed"):
        issues.append({"issue": "merge_preflight_refusal_packet_must_not_allow_preflight"})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if not _safe_relative_path(packet.get("decision_template_path") or ""):
        issues.append({"issue": "unsafe_decision_template_path", "detail": packet.get("decision_template_path") or ""})
    if not _valid_sha256(packet.get("decision_template_sha256")):
        issues.append({"issue": "decision_template_sha256_required"})
    if packet.get("ordinary_patch_consumer_allowed"):
        issues.append({"issue": "ordinary_patch_consumer_must_not_be_allowed"})
    if packet.get("merge_preflight_started") or packet.get("merge_authorized") or packet.get("merge_performed"):
        issues.append({"issue": "merge_preflight_refusal_packet_must_not_start_authorize_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "merge_preflight_refusal_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "merge_preflight_refusal_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_merge_preflight_refusal_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, merge_preflight_refusal_report):
    issues = []
    row = patch_queue_row or {}
    packet = (merge_preflight_refusal_report or {}).get("merge_preflight_refusal_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, merge_preflight_refusal_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (merge_preflight_refusal_report or {}).get("merge_preflight_refusal_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    if snapshot.get("json_error"):
        issues.append({"issue": "queue_artifact_json_error", "detail": snapshot.get("json_error") or ""})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def validate_decision_template_snapshot(decision_template_snapshot, merge_preflight_refusal_report):
    issues = []
    snapshot = decision_template_snapshot or {}
    packet = (merge_preflight_refusal_report or {}).get("merge_preflight_refusal_packet") or {}
    if snapshot.get("path") != packet.get("decision_template_path"):
        issues.append({"issue": "decision_template_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "decision_template_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "decision_template_not_file"})
    if snapshot.get("sha256") != packet.get("decision_template_sha256"):
        issues.append({"issue": "decision_template_sha256_mismatch"})
    if snapshot.get("json_error"):
        issues.append({"issue": "decision_template_json_error", "detail": snapshot.get("json_error") or ""})
    template = snapshot.get("json") or {}
    if template.get("artifact_type") != DECISION_TEMPLATE_TYPE:
        issues.append({"issue": "decision_template_type_mismatch", "detail": template.get("artifact_type") or ""})
    if template.get("template_is_decision") is not False:
        issues.append({"issue": "decision_template_must_not_be_decision"})
    if template.get("decision"):
        issues.append({"issue": "decision_template_decision_must_be_blank", "detail": template.get("decision") or ""})
    if template.get("patch_id") != packet.get("patch_id"):
        issues.append({"issue": "decision_template_patch_id_mismatch"})
    if template.get("slug") != packet.get("slug"):
        issues.append({"issue": "decision_template_slug_mismatch"})
    if template.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "decision_template_candidate_note_path_mismatch"})
    if template.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "decision_template_candidate_note_sha256_mismatch"})
    if template.get("queue_artifact_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "decision_template_queue_artifact_path_mismatch"})
    if template.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "decision_template_queue_artifact_sha256_mismatch"})
    if ALLOWED_DECISION not in (template.get("allowed_decisions") or []):
        issues.append({"issue": "decision_template_allowed_decisions_missing_approve_for_preflight"})
    if template.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "decision_template_required_next_gate_mismatch", "detail": template.get("required_next_gate") or ""})
    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
        "merge_authorized",
        "merge_performed",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
    ]:
        if template.get(key):
            issues.append({"issue": f"forbidden_decision_template_boundary_crossed:{key}"})
    return issues


def build_negative_fixture_matrix(merge_preflight_refusal_report, decision_template_snapshot):
    packet = (merge_preflight_refusal_report or {}).get("merge_preflight_refusal_packet") or {}
    template = (decision_template_snapshot or {}).get("json") or {}
    return [
        {
            "fixture_name": "blank_decision_template_file",
            "fixture_type": "decision_template",
            "fixture_source_path": packet.get("decision_template_path") or "",
            "template_is_decision": bool(template.get("template_is_decision")),
            "decision": template.get("decision") or "",
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "merge_preflight_allowed": False,
            "rejected": not bool(template.get("template_is_decision")) and not bool(template.get("decision")),
            "rejection_reason": "template_is_not_decision_intake_report",
        },
        {
            "fixture_name": "generic_authorization_text",
            "fixture_type": "operator_text",
            "fixture_source_path": "",
            "template_is_decision": False,
            "decision": "",
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "merge_preflight_allowed": False,
            "rejected": True,
            "rejection_reason": "generic_authorization_is_not_narrow_decision_json",
        },
        {
            "fixture_name": "forged_decision_without_intake_report",
            "fixture_type": "forged_packet_field",
            "fixture_source_path": "",
            "template_is_decision": True,
            "decision": ALLOWED_DECISION,
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "merge_preflight_allowed": False,
            "rejected": True,
            "rejection_reason": "missing_accepted_decision_intake_report",
        },
    ]


def research_compute_patch_queue_accepted_decision_fixture_negative_gate(
    merge_preflight_refusal_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    decision_template_snapshot=None,
    label="",
):
    merge_preflight_refusal_report = merge_preflight_refusal_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    decision_template_snapshot = decision_template_snapshot or {}
    issues = validate_merge_preflight_refusal_report(merge_preflight_refusal_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, merge_preflight_refusal_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, merge_preflight_refusal_report))
    issues.extend(validate_decision_template_snapshot(decision_template_snapshot, merge_preflight_refusal_report))
    fixture_matrix = build_negative_fixture_matrix(merge_preflight_refusal_report, decision_template_snapshot)
    for fixture in fixture_matrix:
        if not fixture.get("rejected") or fixture.get("merge_preflight_allowed"):
            issues.append({"issue": "negative_fixture_not_rejected", "detail": fixture.get("fixture_name") or ""})
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_merge_preflight_refusal_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_decision_template_boundary_crossed")
        for item in issues
    )
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_FIXTURE_NEGATIVE_GATE_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_FIXTURE_NEGATIVE_GATE_PASS_PREFLIGHT_BLOCKED"
    packet = merge_preflight_refusal_report.get("merge_preflight_refusal_packet") or {}
    rejected_count = sum(1 for item in fixture_matrix if item.get("rejected") and not item.get("merge_preflight_allowed"))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_fixture_negative_gate_state": state,
        "accepted_decision_fixture_negative_gate_created": status == "PASS",
        "merge_preflight_refusal_verified": status == "PASS",
        "decision_template_verified_not_decision": status == "PASS",
        "negative_fixture_matrix_created": status == "PASS",
        "negative_fixture_count": len(fixture_matrix),
        "negative_fixture_rejected_count": rejected_count,
        "accepted_decision_intake_required": True,
        "accepted_decision_intake_present": False,
        "manual_review_decision_accepted": False,
        "generic_authorization_rejected": any(item.get("fixture_name") == "generic_authorization_text" and item.get("rejected") for item in fixture_matrix),
        "blank_template_rejected": any(item.get("fixture_name") == "blank_decision_template_file" and item.get("rejected") for item in fixture_matrix),
        "forged_decision_without_intake_rejected": any(item.get("fixture_name") == "forged_decision_without_intake_report" and item.get("rejected") for item in fixture_matrix),
        "patch_queue_review_only_guarded": bool(merge_preflight_refusal_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(merge_preflight_refusal_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_preflight_allowed": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "negative_fixture_count": len(fixture_matrix),
            "negative_fixture_rejected_count": rejected_count,
            "accepted_decision_intake_present_count": 0,
            "decision_accepted_count": 0,
            "merge_preflight_allowed_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "merge_preflight_refusal_reference": {
            "report_path": merge_preflight_refusal_report.get("report_path") or "",
            "status": merge_preflight_refusal_report.get("status") or "",
            "merge_preflight_refusal_state": merge_preflight_refusal_report.get("merge_preflight_refusal_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "decision_template_snapshot": decision_template_snapshot,
        "negative_fixture_matrix": fixture_matrix,
        "accepted_decision_fixture_negative_gate_packet": {
            "accepted_decision_fixture_negative_gate_ready": status == "PASS",
            "negative_fixture_matrix_created": status == "PASS",
            "negative_fixture_count": len(fixture_matrix),
            "negative_fixture_rejected_count": rejected_count,
            "accepted_decision_intake_required": True,
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "patch_id": int(packet.get("patch_id") or 0),
            "slug": packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": packet.get("candidate_note_path") or "",
            "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
            "decision_template_path": packet.get("decision_template_path") or "",
            "decision_template_sha256": packet.get("decision_template_sha256") or "",
            "ordinary_patch_consumer_allowed": False,
            "merge_preflight_allowed": False,
            "merge_preflight_started": False,
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": INTAKE_GATE,
        },
        "boundary": [
            "This command records negative fixture evidence proving that blank templates, generic authorization text, and forged decision fields are not accepted decision-intake reports.",
            "Only a separate accepted manual-review decision-intake report can make a later merge-preflight gate eligible.",
            "This command does not start preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_fixture_negative_gate_markdown(report):
    packet = report.get("accepted_decision_fixture_negative_gate_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Fixture Negative Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_fixture_negative_gate_state') or ''}",
        f"- Negative fixtures: {report.get('negative_fixture_rejected_count')}/{report.get('negative_fixture_count')}",
        f"- Generic authorization rejected: {report.get('generic_authorization_rejected')}",
        f"- Blank template rejected: {report.get('blank_template_rejected')}",
        f"- Forged decision without intake rejected: {report.get('forged_decision_without_intake_rejected')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Negative Gate Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
