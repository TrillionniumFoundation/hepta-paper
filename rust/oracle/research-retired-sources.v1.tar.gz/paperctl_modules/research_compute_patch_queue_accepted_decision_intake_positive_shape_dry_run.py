"""Dry-run a positive accepted-decision intake shape without accepting it."""

from paperctl_modules import research_compute_patch_queue_manual_review_decision_intake as decision_intake_core


COMMAND = "research-compute-patch-queue-accepted-decision-intake-positive-shape-dry-run"
NEGATIVE_GATE_COMMAND = "research-compute-patch-queue-accepted-decision-fixture-negative-gate"
NEGATIVE_GATE_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_FIXTURE_NEGATIVE_GATE_PASS_PREFLIGHT_BLOCKED"
MANUAL_REVIEW_PACKET_COMMAND = "research-compute-patch-queue-manual-review-packet"
POSITIVE_DECISION = "approve_for_merge_preflight"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
REQUIRED_NEXT_GATE = "research_compute_patch_queue_manual_review_decision_intake"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_intake_positive_shape_dry_run_state",
    "report_schema",
    "accepted_decision_intake_positive_shape_dry_run_created",
    "negative_gate_verified",
    "manual_review_packet_verified",
    "synthetic_decision_fixture_created",
    "synthetic_decision_fixture_written",
    "synthetic_decision_fixture_path",
    "synthetic_decision_fixture_sha256",
    "synthetic_decision_fixture_is_real_decision",
    "in_memory_intake_probe_created",
    "in_memory_intake_probe_accepts_shape",
    "intake_positive_shape_compatible",
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "negative_gate_reference",
    "negative_gate_report_path",
    "manual_review_packet_reference",
    "manual_review_packet_report_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "synthetic_decision_fixture",
    "in_memory_intake_probe_summary",
    "accepted_decision_intake_positive_shape_dry_run_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "synthetic_decision_fixture_count",
    "in_memory_probe_count",
    "in_memory_probe_accepted_shape_count",
    "accepted_decision_intake_report_count",
    "real_decision_accepted_count",
    "merge_preflight_allowed_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Creates a synthetic dry-run decision shape and probes the decision-intake validator in memory.",
    "The synthetic fixture is not a real manual-review decision and does not create an accepted decision-intake report.",
    "This command records report/status only and does not start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _forbidden_issue(issue):
    text = str((issue or {}).get("issue") or "")
    return (
        text.startswith("forbidden_")
        or text.startswith("decision_material_forbidden_boundary")
        or text.startswith("synthetic_decision_fixture_forbidden_boundary")
        or text.startswith("in_memory_intake_probe_forbidden_boundary")
    )


def validate_negative_gate_report(negative_gate_report):
    issues = []
    report = negative_gate_report or {}
    packet = report.get("accepted_decision_fixture_negative_gate_packet") or {}
    if report.get("command") != NEGATIVE_GATE_COMMAND:
        issues.append({"issue": "negative_gate_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "negative_gate_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_fixture_negative_gate_state") != NEGATIVE_GATE_STATE:
        issues.append({"issue": "negative_gate_state_mismatch", "detail": report.get("accepted_decision_fixture_negative_gate_state") or ""})
    if not report.get("accepted_decision_fixture_negative_gate_created"):
        issues.append({"issue": "negative_gate_created_required"})
    if not report.get("merge_preflight_refusal_verified"):
        issues.append({"issue": "merge_preflight_refusal_verified_required"})
    if not report.get("decision_template_verified_not_decision"):
        issues.append({"issue": "decision_template_verified_not_decision_required"})
    if int(report.get("negative_fixture_count") or 0) < 3:
        issues.append({"issue": "negative_fixture_count_too_low"})
    if report.get("negative_fixture_rejected_count") != report.get("negative_fixture_count"):
        issues.append({"issue": "negative_fixture_rejection_incomplete"})
    if not report.get("generic_authorization_rejected"):
        issues.append({"issue": "generic_authorization_negative_control_not_rejected"})
    if not report.get("blank_template_rejected"):
        issues.append({"issue": "blank_template_negative_control_not_rejected"})
    if not report.get("forged_decision_without_intake_rejected"):
        issues.append({"issue": "forged_decision_negative_control_not_rejected"})
    if not report.get("accepted_decision_intake_required"):
        issues.append({"issue": "accepted_decision_intake_required_flag_missing"})
    if report.get("accepted_decision_intake_present") or report.get("manual_review_decision_accepted"):
        issues.append({"issue": "negative_gate_must_not_have_accepted_decision"})
    if report.get("patch_queue_merge_preflight_allowed") or report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "negative_gate_must_not_allow_or_perform_merge"})
    if report.get("commit_performed"):
        issues.append({"issue": "negative_gate_must_not_commit"})
    if report.get("validation_issues"):
        issues.append({"issue": "negative_gate_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("required_next_gate") != REQUIRED_NEXT_GATE:
        issues.append({"issue": "negative_gate_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "negative_gate_patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "negative_gate_patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    if packet.get("merge_preflight_allowed") or packet.get("merge_authorized") or packet.get("merge_performed"):
        issues.append({"issue": "negative_gate_packet_must_not_allow_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "negative_gate_packet_must_not_allow_or_perform_commit"})

    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_negative_gate_boundary_crossed:{key}"})
    return issues


def validate_packet_alignment(negative_gate_report, manual_review_packet_report):
    issues = []
    negative_packet = (negative_gate_report or {}).get("accepted_decision_fixture_negative_gate_packet") or {}
    manual_packet = (manual_review_packet_report or {}).get("manual_review_packet") or {}
    for field in [
        "patch_id",
        "slug",
        "candidate_note_path",
        "candidate_note_sha256",
        "queue_artifact_path",
        "queue_artifact_sha256",
    ]:
        if negative_packet.get(field) != manual_packet.get(field):
            issues.append({"issue": f"manual_review_packet_negative_gate_{field}_mismatch"})
    if manual_packet.get("required_next_gate") != REQUIRED_NEXT_GATE:
        issues.append({"issue": "manual_review_packet_required_next_gate_mismatch", "detail": manual_packet.get("required_next_gate") or ""})
    return issues


def build_positive_shape_fixture(manual_review_packet_report):
    packet = (manual_review_packet_report or {}).get("manual_review_packet") or {}
    return {
        "fixture_type": "accepted_decision_intake_positive_shape_dry_run.v1",
        "fixture_only": True,
        "dry_run_only": True,
        "fixture_is_real_decision": False,
        "decision_scope": DECISION_SCOPE,
        "decision": POSITIVE_DECISION,
        "patch_id": int(packet.get("patch_id") or 0),
        "slug": packet.get("slug") or "",
        "candidate_note_path": packet.get("candidate_note_path") or "",
        "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
        "queue_artifact_path": packet.get("queue_artifact_path") or "",
        "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
        "reviewer_reference": "positive-shape-dry-run:synthetic-local-fixture",
        "rationale": "Synthetic shape probe for the narrow accepted decision-intake contract; not a real manual-review decision.",
        "merge_authorized": False,
        "merge_performed": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
    }


def validate_positive_shape_fixture(decision_fixture):
    issues = []
    fixture = decision_fixture or {}
    if fixture.get("fixture_type") != "accepted_decision_intake_positive_shape_dry_run.v1":
        issues.append({"issue": "synthetic_decision_fixture_type_mismatch", "detail": fixture.get("fixture_type") or ""})
    if fixture.get("fixture_only") is not True or fixture.get("dry_run_only") is not True:
        issues.append({"issue": "synthetic_decision_fixture_must_be_dry_run_only"})
    if fixture.get("fixture_is_real_decision") is not False:
        issues.append({"issue": "synthetic_decision_fixture_must_not_be_real_decision"})
    if fixture.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "synthetic_decision_fixture_scope_mismatch", "detail": fixture.get("decision_scope") or ""})
    if fixture.get("decision") != POSITIVE_DECISION:
        issues.append({"issue": "synthetic_decision_fixture_decision_mismatch", "detail": fixture.get("decision") or ""})
    if not fixture.get("reviewer_reference"):
        issues.append({"issue": "synthetic_decision_fixture_reviewer_reference_required"})
    if not fixture.get("rationale"):
        issues.append({"issue": "synthetic_decision_fixture_rationale_required"})
    for key in [
        "merge_authorized",
        "merge_performed",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if fixture.get(key):
            issues.append({"issue": f"synthetic_decision_fixture_forbidden_boundary:{key}"})
    return issues


def _probe_summary(probe_report):
    packet = (probe_report or {}).get("decision_intake_packet") or {}
    return {
        "status": (probe_report or {}).get("status") or "",
        "decision_intake_state": (probe_report or {}).get("decision_intake_state") or "",
        "decision_intake_created": bool((probe_report or {}).get("decision_intake_created")),
        "manual_review_decision_present": bool((probe_report or {}).get("manual_review_decision_present")),
        "manual_review_decision_accepted_by_probe": bool((probe_report or {}).get("manual_review_decision_accepted")),
        "decision": packet.get("decision") or "",
        "required_next_gate": packet.get("required_next_gate") or "",
        "patch_queue_merge_authorized": bool((probe_report or {}).get("patch_queue_merge_authorized")),
        "patch_queue_merge_performed": bool((probe_report or {}).get("patch_queue_merge_performed")),
        "commit_performed": bool((probe_report or {}).get("commit_performed")),
        "validation_issue_count": len((probe_report or {}).get("validation_issues") or []),
    }


def research_compute_patch_queue_accepted_decision_intake_positive_shape_dry_run(
    negative_gate_report,
    manual_review_packet_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    negative_gate_report = negative_gate_report or {}
    manual_review_packet_report = manual_review_packet_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_negative_gate_report(negative_gate_report)
    issues.extend(decision_intake_core.validate_manual_review_packet_report(manual_review_packet_report))
    issues.extend(decision_intake_core.validate_patch_queue_row(patch_queue_row, manual_review_packet_report))
    issues.extend(decision_intake_core.validate_queue_artifact(queue_artifact_snapshot, manual_review_packet_report))
    issues.extend(validate_packet_alignment(negative_gate_report, manual_review_packet_report))

    decision_fixture = build_positive_shape_fixture(manual_review_packet_report)
    issues.extend(validate_positive_shape_fixture(decision_fixture))
    probe_report = decision_intake_core.research_compute_patch_queue_manual_review_decision_intake(
        manual_review_packet_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        decision_material=decision_fixture,
        label="positive-shape-dry-run-probe",
    )
    probe_accepts_shape = (
        probe_report.get("status") == "PASS"
        and probe_report.get("decision_intake_state") == "PATCH_QUEUE_MANUAL_REVIEW_DECISION_ACCEPTED_NOT_MERGED"
        and probe_report.get("manual_review_decision_accepted") is True
        and probe_report.get("patch_queue_merge_authorized") is False
        and probe_report.get("patch_queue_merge_performed") is False
        and probe_report.get("commit_performed") is False
        and not probe_report.get("validation_issues")
    )
    if not probe_accepts_shape:
        issues.append({"issue": "in_memory_intake_probe_did_not_accept_positive_shape"})
    if probe_report.get("patch_queue_merge_authorized") or probe_report.get("patch_queue_merge_performed") or probe_report.get("commit_performed"):
        issues.append({"issue": "in_memory_intake_probe_forbidden_boundary:merge_or_commit"})

    forbidden = any(_forbidden_issue(item) for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_INTAKE_POSITIVE_SHAPE_DRY_RUN_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_INTAKE_POSITIVE_SHAPE_DRY_RUN_PASS_NOT_ACCEPTED"
    negative_packet = negative_gate_report.get("accepted_decision_fixture_negative_gate_packet") or {}
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_intake_positive_shape_dry_run_state": state,
        "accepted_decision_intake_positive_shape_dry_run_created": status == "PASS",
        "negative_gate_verified": status == "PASS",
        "manual_review_packet_verified": status == "PASS",
        "synthetic_decision_fixture_created": status == "PASS",
        "synthetic_decision_fixture_written": False,
        "synthetic_decision_fixture_path": "",
        "synthetic_decision_fixture_sha256": "",
        "synthetic_decision_fixture_is_real_decision": False,
        "in_memory_intake_probe_created": True,
        "in_memory_intake_probe_accepts_shape": probe_accepts_shape,
        "intake_positive_shape_compatible": status == "PASS" and probe_accepts_shape,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "patch_queue_review_only_guarded": bool(manual_review_packet_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(manual_review_packet_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_preflight_allowed": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "synthetic_decision_fixture_count": 1 if status == "PASS" else 0,
            "in_memory_probe_count": 1,
            "in_memory_probe_accepted_shape_count": 1 if probe_accepts_shape else 0,
            "accepted_decision_intake_report_count": 0,
            "real_decision_accepted_count": 0,
            "merge_preflight_allowed_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "negative_gate_reference": {
            "report_path": negative_gate_report.get("report_path") or "",
            "status": negative_gate_report.get("status") or "",
            "accepted_decision_fixture_negative_gate_state": negative_gate_report.get("accepted_decision_fixture_negative_gate_state") or "",
        },
        "manual_review_packet_reference": {
            "report_path": manual_review_packet_report.get("report_path") or "",
            "status": manual_review_packet_report.get("status") or "",
            "manual_review_packet_state": manual_review_packet_report.get("manual_review_packet_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "synthetic_decision_fixture": decision_fixture,
        "in_memory_intake_probe_summary": _probe_summary(probe_report),
        "accepted_decision_intake_positive_shape_dry_run_packet": {
            "positive_shape_dry_run_ready": status == "PASS",
            "synthetic_decision_fixture_created": status == "PASS",
            "synthetic_decision_fixture_is_real_decision": False,
            "in_memory_intake_probe_accepts_shape": probe_accepts_shape,
            "accepted_decision_intake_report_created": False,
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "decision": POSITIVE_DECISION,
            "decision_scope": DECISION_SCOPE,
            "patch_id": int(negative_packet.get("patch_id") or 0),
            "slug": negative_packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": negative_packet.get("candidate_note_path") or "",
            "candidate_note_sha256": negative_packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": negative_packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": negative_packet.get("queue_artifact_sha256") or "",
            "ordinary_patch_consumer_allowed": False,
            "merge_preflight_allowed": False,
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": REQUIRED_NEXT_GATE,
        },
        "boundary": [
            "This command creates a synthetic, fixture-only, dry-run decision shape and probes the decision-intake validator in memory.",
            "The synthetic fixture is not a real manual-review decision and is not an accepted decision-intake report.",
            "This command does not start merge preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_intake_positive_shape_dry_run_markdown(report):
    packet = report.get("accepted_decision_intake_positive_shape_dry_run_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Intake Positive Shape Dry Run",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_intake_positive_shape_dry_run_state') or ''}",
        f"- Synthetic fixture created: {report.get('synthetic_decision_fixture_created')}",
        f"- In-memory intake probe accepts shape: {report.get('in_memory_intake_probe_accepts_shape')}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Real decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Positive Shape Dry Run Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Decision: `{packet.get('decision') or ''}`",
        f"- Decision scope: `{packet.get('decision_scope') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
