"""Prove positive-shape dry-run material cannot be promoted to acceptance."""

from paperctl_modules import research_compute_patch_queue_manual_review_decision_reintake_status as reintake_status_core
from paperctl_modules import research_compute_patch_queue_merge_preflight_refusal as merge_preflight_refusal_core


COMMAND = "research-compute-patch-queue-accepted-decision-positive-shape-nonpromotion-gate"
POSITIVE_SHAPE_COMMAND = "research-compute-patch-queue-accepted-decision-intake-positive-shape-dry-run"
POSITIVE_SHAPE_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_INTAKE_POSITIVE_SHAPE_DRY_RUN_PASS_NOT_ACCEPTED"
TEMPLATE_VERIFY_COMMAND = "research-compute-patch-queue-manual-review-decision-template-verify"
TEMPLATE_VERIFY_STATE = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_TEMPLATE_VERIFIED_AWAITING_DECISION"
POSITIVE_DECISION = "approve_for_merge_preflight"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_positive_shape_nonpromotion_gate_state",
    "report_schema",
    "accepted_decision_positive_shape_nonpromotion_gate_created",
    "positive_shape_dry_run_verified",
    "decision_template_verify_verified",
    "nonpromotion_probe_matrix_created",
    "nonpromotion_probe_count",
    "nonpromotion_probe_rejected_count",
    "dry_run_report_rejected_as_accepted_decision",
    "synthetic_fixture_rejected_as_accepted_decision",
    "dry_run_report_rejected_as_merge_preflight_input",
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "synthetic_decision_fixture_promoted",
    "positive_shape_dry_run_promoted",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_preflight_allowed",
    "merge_preflight_eligible",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "positive_shape_dry_run_reference",
    "positive_shape_dry_run_report_path",
    "decision_template_verify_reference",
    "decision_template_verify_report_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "nonpromotion_probe_matrix",
    "accepted_decision_positive_shape_nonpromotion_gate_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "nonpromotion_probe_count",
    "nonpromotion_probe_rejected_count",
    "accepted_decision_intake_report_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "merge_preflight_allowed_count",
    "merge_preflight_eligible_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Proves positive-shape dry-run material is non-promotable test material.",
    "Dry-run reports and synthetic fixtures are rejected as accepted decision-intake inputs.",
    "This command records report/status only and does not create accepted decisions, start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _forbidden_issue(issue):
    text = str((issue or {}).get("issue") or "")
    return text.startswith("forbidden_") or text.startswith("dry_run_positive_shape_forbidden_boundary")


def validate_positive_shape_dry_run_report(positive_shape_dry_run_report):
    issues = []
    report = positive_shape_dry_run_report or {}
    packet = report.get("accepted_decision_intake_positive_shape_dry_run_packet") or {}
    fixture = report.get("synthetic_decision_fixture") or {}
    if report.get("command") != POSITIVE_SHAPE_COMMAND:
        issues.append({"issue": "positive_shape_dry_run_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "positive_shape_dry_run_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_intake_positive_shape_dry_run_state") != POSITIVE_SHAPE_STATE:
        issues.append({"issue": "positive_shape_dry_run_state_mismatch", "detail": report.get("accepted_decision_intake_positive_shape_dry_run_state") or ""})
    if not report.get("accepted_decision_intake_positive_shape_dry_run_created"):
        issues.append({"issue": "positive_shape_dry_run_created_required"})
    if not report.get("negative_gate_verified"):
        issues.append({"issue": "positive_shape_negative_gate_verified_required"})
    if not report.get("manual_review_packet_verified"):
        issues.append({"issue": "positive_shape_manual_review_packet_verified_required"})
    if not report.get("synthetic_decision_fixture_created"):
        issues.append({"issue": "synthetic_decision_fixture_created_required"})
    if report.get("synthetic_decision_fixture_written"):
        issues.append({"issue": "synthetic_decision_fixture_must_not_be_written"})
    if report.get("synthetic_decision_fixture_path") or report.get("synthetic_decision_fixture_sha256"):
        issues.append({"issue": "synthetic_decision_fixture_path_or_sha_must_be_empty"})
    if report.get("synthetic_decision_fixture_is_real_decision"):
        issues.append({"issue": "synthetic_decision_fixture_must_not_be_real_decision"})
    if not report.get("in_memory_intake_probe_created") or not report.get("in_memory_intake_probe_accepts_shape"):
        issues.append({"issue": "in_memory_positive_shape_probe_required"})
    if not report.get("intake_positive_shape_compatible"):
        issues.append({"issue": "positive_shape_compatible_flag_required"})
    if report.get("accepted_decision_intake_report_created") or report.get("accepted_decision_intake_present"):
        issues.append({"issue": "positive_shape_dry_run_must_not_create_or_present_accepted_intake"})
    if report.get("manual_review_decision_present") or report.get("manual_review_decision_accepted"):
        issues.append({"issue": "positive_shape_dry_run_must_not_accept_decision"})
    if report.get("patch_queue_merge_preflight_allowed") or report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "positive_shape_dry_run_must_not_allow_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "positive_shape_dry_run_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("positive_shape_dry_run_ready") is not True:
        issues.append({"issue": "positive_shape_dry_run_packet_not_ready"})
    if packet.get("synthetic_decision_fixture_is_real_decision"):
        issues.append({"issue": "positive_shape_packet_fixture_must_not_be_real_decision"})
    if packet.get("accepted_decision_intake_report_created") or packet.get("accepted_decision_intake_present"):
        issues.append({"issue": "positive_shape_packet_must_not_create_or_present_accepted_intake"})
    if packet.get("manual_review_decision_accepted"):
        issues.append({"issue": "positive_shape_packet_must_not_accept_decision"})
    if packet.get("decision") != POSITIVE_DECISION:
        issues.append({"issue": "positive_shape_packet_decision_mismatch", "detail": packet.get("decision") or ""})
    if packet.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "positive_shape_packet_scope_mismatch", "detail": packet.get("decision_scope") or ""})
    if packet.get("merge_preflight_allowed") or packet.get("merge_authorized") or packet.get("merge_performed"):
        issues.append({"issue": "positive_shape_packet_must_not_allow_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "positive_shape_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "positive_shape_packet_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    if fixture.get("fixture_only") is not True or fixture.get("dry_run_only") is not True:
        issues.append({"issue": "synthetic_fixture_must_be_fixture_only_dry_run_only"})
    if fixture.get("fixture_is_real_decision") is not False:
        issues.append({"issue": "synthetic_fixture_must_not_be_real_decision"})
    if fixture.get("decision") != POSITIVE_DECISION:
        issues.append({"issue": "synthetic_fixture_decision_mismatch", "detail": fixture.get("decision") or ""})
    if fixture.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "synthetic_fixture_scope_mismatch", "detail": fixture.get("decision_scope") or ""})

    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_positive_shape_dry_run_boundary_crossed:{key}"})
    return issues


def validate_template_verify_alignment(positive_shape_dry_run_report, template_verify_report):
    issues = []
    positive_packet = (positive_shape_dry_run_report or {}).get("accepted_decision_intake_positive_shape_dry_run_packet") or {}
    verify_packet = (template_verify_report or {}).get("decision_template_verify_packet") or {}
    if (template_verify_report or {}).get("command") != TEMPLATE_VERIFY_COMMAND:
        issues.append({"issue": "template_verify_command_mismatch", "detail": (template_verify_report or {}).get("command") or ""})
    if (template_verify_report or {}).get("decision_template_verify_state") != TEMPLATE_VERIFY_STATE:
        issues.append({"issue": "template_verify_state_mismatch", "detail": (template_verify_report or {}).get("decision_template_verify_state") or ""})
    for field in [
        "patch_id",
        "slug",
        "candidate_note_path",
        "candidate_note_sha256",
        "queue_artifact_path",
        "queue_artifact_sha256",
    ]:
        if positive_packet.get(field) != verify_packet.get(field):
            issues.append({"issue": f"positive_shape_template_verify_{field}_mismatch"})
    if not verify_packet.get("decision_template_path") or not verify_packet.get("decision_template_sha256"):
        issues.append({"issue": "template_verify_decision_template_reference_required"})
    return issues


def _reintake_probe_summary(probe_report):
    packet = (probe_report or {}).get("decision_reintake_status_packet") or {}
    return {
        "status": (probe_report or {}).get("status") or "",
        "decision_reintake_status_state": (probe_report or {}).get("decision_reintake_status_state") or "",
        "accepted_decision_intake_present": bool((probe_report or {}).get("accepted_decision_intake_present")),
        "manual_review_decision_accepted": bool((probe_report or {}).get("manual_review_decision_accepted")),
        "patch_queue_merge_preflight_allowed": bool((probe_report or {}).get("patch_queue_merge_preflight_allowed")),
        "patch_queue_merge_performed": bool((probe_report or {}).get("patch_queue_merge_performed")),
        "commit_performed": bool((probe_report or {}).get("commit_performed")),
        "required_next_gate": packet.get("required_next_gate") or "",
        "validation_issue_count": len((probe_report or {}).get("validation_issues") or []),
        "validation_issue_names": [item.get("issue") or "" for item in (probe_report or {}).get("validation_issues") or []],
    }


def _merge_probe_summary(probe_report):
    packet = (probe_report or {}).get("merge_preflight_refusal_packet") or {}
    return {
        "status": (probe_report or {}).get("status") or "",
        "merge_preflight_refusal_state": (probe_report or {}).get("merge_preflight_refusal_state") or "",
        "accepted_decision_intake_present": bool((probe_report or {}).get("accepted_decision_intake_present")),
        "manual_review_decision_accepted": bool((probe_report or {}).get("manual_review_decision_accepted")),
        "merge_preflight_eligible": bool((probe_report or {}).get("merge_preflight_eligible")),
        "patch_queue_merge_preflight_allowed": bool((probe_report or {}).get("patch_queue_merge_preflight_allowed")),
        "patch_queue_merge_performed": bool((probe_report or {}).get("patch_queue_merge_performed")),
        "commit_performed": bool((probe_report or {}).get("commit_performed")),
        "required_next_gate": packet.get("required_next_gate") or "",
        "validation_issue_count": len((probe_report or {}).get("validation_issues") or []),
        "validation_issue_names": [item.get("issue") or "" for item in (probe_report or {}).get("validation_issues") or []],
    }


def build_nonpromotion_probe_matrix(positive_shape_dry_run_report, template_verify_report, patch_queue_row, queue_artifact_snapshot):
    synthetic_fixture = (positive_shape_dry_run_report or {}).get("synthetic_decision_fixture") or {}
    dry_run_reintake_probe = reintake_status_core.research_compute_patch_queue_manual_review_decision_reintake_status(
        template_verify_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        accepted_decision_intake_report=positive_shape_dry_run_report,
        label="nonpromotion-dry-run-report-as-intake",
    )
    synthetic_fixture_reintake_probe = reintake_status_core.research_compute_patch_queue_manual_review_decision_reintake_status(
        template_verify_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        accepted_decision_intake_report=synthetic_fixture,
        label="nonpromotion-synthetic-fixture-as-intake",
    )
    dry_run_merge_probe = merge_preflight_refusal_core.research_compute_patch_queue_merge_preflight_refusal(
        positive_shape_dry_run_report,
        patch_queue_row=patch_queue_row,
        queue_artifact_snapshot=queue_artifact_snapshot,
        label="nonpromotion-dry-run-report-as-merge-preflight-input",
    )
    probes = [
        {
            "probe_name": "dry_run_report_as_accepted_decision_intake_report",
            "probe_type": "decision_reintake",
            "summary": _reintake_probe_summary(dry_run_reintake_probe),
        },
        {
            "probe_name": "synthetic_fixture_as_accepted_decision_intake_report",
            "probe_type": "decision_reintake",
            "summary": _reintake_probe_summary(synthetic_fixture_reintake_probe),
        },
        {
            "probe_name": "positive_shape_dry_run_report_as_merge_preflight_input",
            "probe_type": "merge_preflight_refusal",
            "summary": _merge_probe_summary(dry_run_merge_probe),
        },
    ]
    for probe in probes:
        summary = probe["summary"]
        promoted = (
            summary.get("manual_review_decision_accepted")
            or summary.get("patch_queue_merge_preflight_allowed")
            or summary.get("merge_preflight_eligible")
            or summary.get("patch_queue_merge_performed")
            or summary.get("commit_performed")
        )
        probe["promoted"] = bool(promoted)
        probe["rejected"] = not promoted and int(summary.get("validation_issue_count") or 0) > 0
        probe["rejection_reason"] = "not_a_real_accepted_decision_intake_report" if probe["rejected"] else ""
    return probes


def research_compute_patch_queue_accepted_decision_positive_shape_nonpromotion_gate(
    positive_shape_dry_run_report,
    template_verify_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    positive_shape_dry_run_report = positive_shape_dry_run_report or {}
    template_verify_report = template_verify_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_positive_shape_dry_run_report(positive_shape_dry_run_report)
    issues.extend(reintake_status_core.validate_template_verify_report(template_verify_report))
    issues.extend(reintake_status_core.validate_patch_queue_row(patch_queue_row, template_verify_report))
    issues.extend(reintake_status_core.validate_queue_artifact(queue_artifact_snapshot, template_verify_report))
    issues.extend(validate_template_verify_alignment(positive_shape_dry_run_report, template_verify_report))
    probe_matrix = build_nonpromotion_probe_matrix(
        positive_shape_dry_run_report,
        template_verify_report,
        patch_queue_row,
        queue_artifact_snapshot,
    )
    for probe in probe_matrix:
        if not probe.get("rejected"):
            issues.append({"issue": "nonpromotion_probe_not_rejected", "detail": probe.get("probe_name") or ""})
        summary = probe.get("summary") or {}
        if summary.get("patch_queue_merge_performed") or summary.get("commit_performed"):
            issues.append({"issue": f"forbidden_nonpromotion_probe_boundary:{probe.get('probe_name') or ''}"})

    forbidden = any(_forbidden_issue(item) for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_POSITIVE_SHAPE_NONPROMOTION_GATE_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_POSITIVE_SHAPE_NONPROMOTION_GATE_PASS_NOT_PROMOTED"

    positive_packet = positive_shape_dry_run_report.get("accepted_decision_intake_positive_shape_dry_run_packet") or {}
    verify_packet = template_verify_report.get("decision_template_verify_packet") or {}
    rejected_count = sum(1 for probe in probe_matrix if probe.get("rejected"))
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_positive_shape_nonpromotion_gate_state": state,
        "accepted_decision_positive_shape_nonpromotion_gate_created": status == "PASS",
        "positive_shape_dry_run_verified": status == "PASS",
        "decision_template_verify_verified": status == "PASS",
        "nonpromotion_probe_matrix_created": status == "PASS",
        "nonpromotion_probe_count": len(probe_matrix),
        "nonpromotion_probe_rejected_count": rejected_count,
        "dry_run_report_rejected_as_accepted_decision": any(
            item.get("probe_name") == "dry_run_report_as_accepted_decision_intake_report" and item.get("rejected")
            for item in probe_matrix
        ),
        "synthetic_fixture_rejected_as_accepted_decision": any(
            item.get("probe_name") == "synthetic_fixture_as_accepted_decision_intake_report" and item.get("rejected")
            for item in probe_matrix
        ),
        "dry_run_report_rejected_as_merge_preflight_input": any(
            item.get("probe_name") == "positive_shape_dry_run_report_as_merge_preflight_input" and item.get("rejected")
            for item in probe_matrix
        ),
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "synthetic_decision_fixture_promoted": False,
        "positive_shape_dry_run_promoted": False,
        "patch_queue_review_only_guarded": bool(template_verify_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(template_verify_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_preflight_allowed": False,
        "merge_preflight_eligible": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "nonpromotion_probe_count": len(probe_matrix),
            "nonpromotion_probe_rejected_count": rejected_count,
            "accepted_decision_intake_report_count": 0,
            "accepted_decision_intake_present_count": 0,
            "decision_accepted_count": 0,
            "merge_preflight_allowed_count": 0,
            "merge_preflight_eligible_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "positive_shape_dry_run_reference": {
            "report_path": positive_shape_dry_run_report.get("report_path") or "",
            "status": positive_shape_dry_run_report.get("status") or "",
            "accepted_decision_intake_positive_shape_dry_run_state": positive_shape_dry_run_report.get("accepted_decision_intake_positive_shape_dry_run_state") or "",
        },
        "decision_template_verify_reference": {
            "report_path": template_verify_report.get("report_path") or "",
            "status": template_verify_report.get("status") or "",
            "decision_template_verify_state": template_verify_report.get("decision_template_verify_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "nonpromotion_probe_matrix": probe_matrix,
        "accepted_decision_positive_shape_nonpromotion_gate_packet": {
            "nonpromotion_gate_ready": status == "PASS",
            "nonpromotion_probe_matrix_created": status == "PASS",
            "nonpromotion_probe_count": len(probe_matrix),
            "nonpromotion_probe_rejected_count": rejected_count,
            "accepted_decision_intake_report_created": False,
            "accepted_decision_intake_present": False,
            "manual_review_decision_accepted": False,
            "positive_shape_dry_run_promoted": False,
            "synthetic_decision_fixture_promoted": False,
            "decision": POSITIVE_DECISION,
            "decision_scope": DECISION_SCOPE,
            "patch_id": int(positive_packet.get("patch_id") or verify_packet.get("patch_id") or 0),
            "slug": positive_packet.get("slug") or verify_packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": positive_packet.get("candidate_note_path") or verify_packet.get("candidate_note_path") or "",
            "candidate_note_sha256": positive_packet.get("candidate_note_sha256") or verify_packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": positive_packet.get("queue_artifact_path") or verify_packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": positive_packet.get("queue_artifact_sha256") or verify_packet.get("queue_artifact_sha256") or "",
            "decision_template_path": verify_packet.get("decision_template_path") or "",
            "decision_template_sha256": verify_packet.get("decision_template_sha256") or "",
            "ordinary_patch_consumer_allowed": False,
            "merge_preflight_allowed": False,
            "merge_preflight_eligible": False,
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": INTAKE_GATE,
        },
        "boundary": [
            "This command treats positive-shape dry-run material as explicit non-promotable test material.",
            "It proves the dry-run report and synthetic fixture are rejected as accepted decision-intake inputs.",
            "It also proves the dry-run report is rejected as a merge-preflight input.",
            "This command does not write a synthetic decision file, create an accepted decision report, start preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_positive_shape_nonpromotion_gate_markdown(report):
    packet = report.get("accepted_decision_positive_shape_nonpromotion_gate_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Positive Shape Nonpromotion Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_positive_shape_nonpromotion_gate_state') or ''}",
        f"- Nonpromotion probes: {report.get('nonpromotion_probe_rejected_count')}/{report.get('nonpromotion_probe_count')}",
        f"- Dry-run report rejected as accepted decision: {report.get('dry_run_report_rejected_as_accepted_decision')}",
        f"- Synthetic fixture rejected as accepted decision: {report.get('synthetic_fixture_rejected_as_accepted_decision')}",
        f"- Dry-run report rejected as merge-preflight input: {report.get('dry_run_report_rejected_as_merge_preflight_input')}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Nonpromotion Gate Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Decision: `{packet.get('decision') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
