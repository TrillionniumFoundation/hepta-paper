"""Prepare the accepted-decision chain for real intake handoff."""

from paperctl_modules import research_compute_patch_queue_accepted_decision_final_waiting_chain_closure_nonpromotion_gate as final_closure_nonpromotion_core


COMMAND = "research-compute-patch-queue-accepted-decision-real-intake-handoff-status"
FINAL_CLOSURE_NONPROMOTION_COMMAND = "research-compute-patch-queue-accepted-decision-final-waiting-chain-closure-nonpromotion-gate"
FINAL_CLOSURE_NONPROMOTION_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_FINAL_WAITING_CHAIN_CLOSURE_NONPROMOTION_GATE_PASS_NOT_PROMOTED"
HANDOFF_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_REAL_INTAKE_HANDOFF_STATUS_READY_AWAITING_REAL_DECISION_INTAKE"
TERMINAL_STATUS = "AWAITING_REAL_ACCEPTED_DECISION_INTAKE"
FINAL_WAITING_STATUS = "FINAL_WAITING_FOR_REAL_ACCEPTED_DECISION_INTAKE"
HANDOFF_STATUS = "READY_FOR_REAL_ACCEPTED_DECISION_INTAKE_HANDOFF"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"
POSITIVE_DECISION = "approve_for_merge_preflight"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_real_intake_handoff_status_state",
    "report_schema",
    "accepted_decision_real_intake_handoff_status_created",
    "real_intake_handoff_status_ready",
    "handoff_status",
    "final_waiting_chain_closure_capstone_verified",
    "final_waiting_chain_closure_nonpromotion_gate_verified",
    "terminal_status",
    "final_waiting_status",
    "real_accepted_decision_required",
    "real_accepted_decision_present",
    "standalone_real_decision_json_required",
    "required_real_decision",
    "required_real_decision_scope",
    "required_decision_intake_gate",
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "local_evidence_report_count",
    "local_evidence_pass_report_count",
    "final_waiting_chain_report_count",
    "final_waiting_chain_pass_report_count",
    "negative_fixture_count",
    "negative_fixture_rejected_count",
    "direct_nonpromotion_probe_count",
    "direct_nonpromotion_probe_rejected_count",
    "final_waiting_chain_closure_probe_count",
    "final_waiting_chain_closure_probe_rejected_count",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "merge_preflight_eligible",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "final_waiting_chain_closure_capstone_reference",
    "final_waiting_chain_closure_capstone_report_path",
    "final_waiting_chain_closure_nonpromotion_gate_reference",
    "final_waiting_chain_closure_nonpromotion_gate_report_path",
    "patch_queue_row",
    "real_decision_intake_requirements",
    "accepted_decision_real_intake_handoff_status_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "local_evidence_report_count",
    "local_evidence_pass_report_count",
    "final_waiting_chain_report_count",
    "final_waiting_chain_pass_report_count",
    "negative_fixture_count",
    "negative_fixture_rejected_count",
    "direct_nonpromotion_probe_count",
    "direct_nonpromotion_probe_rejected_count",
    "final_waiting_chain_closure_probe_count",
    "final_waiting_chain_closure_probe_rejected_count",
    "accepted_decision_intake_report_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "real_accepted_decision_present_count",
    "merge_preflight_allowed_count",
    "merge_preflight_eligible_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Prepares the local accepted-decision evidence chain for real decision-intake handoff.",
    "The handoff packet is not a decision and cannot start merge preflight.",
    "This command records report/status only and does not create accepted decisions, start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]

FORBIDDEN_REPORT_FLAGS = [
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "real_accepted_decision_present",
    "final_waiting_chain_closure_capstone_promoted",
    "final_waiting_chain_closure_packet_promoted",
    "merge_preflight_eligible",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
]

FORBIDDEN_PACKET_FLAGS = [
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "real_accepted_decision_present",
    "final_waiting_chain_closure_capstone_promoted",
    "final_waiting_chain_closure_packet_promoted",
    "ordinary_patch_consumer_allowed",
    "merge_preflight_allowed",
    "merge_preflight_eligible",
    "merge_authorized",
    "merge_performed",
    "commit_allowed",
    "commit_performed",
]


def _forbidden_issue(issue):
    text = str((issue or {}).get("issue") or "")
    return text.startswith("forbidden_")


def _packet(report, key):
    return (report or {}).get(key) or {}


def _validate_false_flags(issues, data, keys, prefix):
    for key in keys:
        if (data or {}).get(key):
            issues.append({"issue": f"{prefix}:{key}"})


def validate_final_waiting_chain_closure_nonpromotion_gate_report(nonpromotion_report):
    issues = []
    report = nonpromotion_report or {}
    packet = _packet(report, "accepted_decision_final_waiting_chain_closure_nonpromotion_gate_packet")
    if report.get("command") != FINAL_CLOSURE_NONPROMOTION_COMMAND:
        issues.append({"issue": "final_closure_nonpromotion_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "final_closure_nonpromotion_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_final_waiting_chain_closure_nonpromotion_gate_state") != FINAL_CLOSURE_NONPROMOTION_STATE:
        issues.append({
            "issue": "final_closure_nonpromotion_state_mismatch",
            "detail": report.get("accepted_decision_final_waiting_chain_closure_nonpromotion_gate_state") or "",
        })
    for key in [
        "accepted_decision_final_waiting_chain_closure_nonpromotion_gate_created",
        "final_waiting_chain_closure_capstone_verified",
        "decision_template_verify_verified",
        "final_waiting_chain_closure_probe_matrix_created",
        "final_waiting_chain_closure_report_rejected_as_accepted_decision",
        "final_waiting_chain_closure_packet_rejected_as_accepted_decision",
        "final_waiting_chain_closure_report_rejected_as_merge_preflight_input",
    ]:
        if not report.get(key):
            issues.append({"issue": f"final_closure_nonpromotion_{key}_required"})
    probe_count = int(report.get("final_waiting_chain_closure_probe_count") or 0)
    rejected_count = int(report.get("final_waiting_chain_closure_probe_rejected_count") or 0)
    if probe_count < 3:
        issues.append({"issue": "final_closure_nonpromotion_probe_count_too_low", "detail": probe_count})
    if rejected_count != probe_count or rejected_count < 3:
        issues.append({"issue": "final_closure_nonpromotion_probes_not_all_rejected", "detail": f"{rejected_count}/{probe_count}"})
    if report.get("terminal_status") != TERMINAL_STATUS:
        issues.append({"issue": "final_closure_nonpromotion_terminal_status_mismatch", "detail": report.get("terminal_status") or ""})
    if report.get("final_waiting_status") != FINAL_WAITING_STATUS:
        issues.append({"issue": "final_closure_nonpromotion_final_waiting_status_mismatch", "detail": report.get("final_waiting_status") or ""})
    _validate_false_flags(issues, report, FORBIDDEN_REPORT_FLAGS, "forbidden_final_closure_nonpromotion_report_boundary_crossed")
    if report.get("validation_issues"):
        issues.append({"issue": "final_closure_nonpromotion_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("final_waiting_chain_closure_nonpromotion_gate_ready") is not True:
        issues.append({"issue": "final_closure_nonpromotion_packet_not_ready"})
    if int(packet.get("final_waiting_chain_closure_probe_rejected_count") or 0) != int(packet.get("final_waiting_chain_closure_probe_count") or 0):
        issues.append({"issue": "final_closure_nonpromotion_packet_probes_not_all_rejected"})
    if packet.get("terminal_status") != TERMINAL_STATUS:
        issues.append({"issue": "final_closure_nonpromotion_packet_terminal_status_mismatch", "detail": packet.get("terminal_status") or ""})
    if packet.get("final_waiting_status") != FINAL_WAITING_STATUS:
        issues.append({"issue": "final_closure_nonpromotion_packet_final_waiting_status_mismatch", "detail": packet.get("final_waiting_status") or ""})
    _validate_false_flags(issues, packet, FORBIDDEN_PACKET_FLAGS, "forbidden_final_closure_nonpromotion_packet_boundary_crossed")
    if packet.get("decision") or packet.get("decision_scope"):
        issues.append({"issue": "final_closure_nonpromotion_packet_decision_must_be_empty"})
    if packet.get("allowed_real_decision") != POSITIVE_DECISION:
        issues.append({"issue": "final_closure_nonpromotion_allowed_decision_mismatch", "detail": packet.get("allowed_real_decision") or ""})
    if packet.get("allowed_real_decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "final_closure_nonpromotion_allowed_scope_mismatch", "detail": packet.get("allowed_real_decision_scope") or ""})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "final_closure_nonpromotion_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    for probe in report.get("final_waiting_chain_closure_probe_matrix") or []:
        if not probe.get("rejected") or probe.get("promoted"):
            issues.append({"issue": "final_closure_nonpromotion_probe_promoted_or_unrejected", "detail": probe.get("probe_name") or ""})
    return issues


def validate_handoff_alignment(final_closure_report, nonpromotion_report, patch_queue_row):
    issues = []
    closure_packet = _packet(final_closure_report, "accepted_decision_final_waiting_chain_closure_capstone_packet")
    nonpromotion_packet = _packet(nonpromotion_report, "accepted_decision_final_waiting_chain_closure_nonpromotion_gate_packet")
    for field in [
        "patch_id",
        "slug",
        "candidate_note_path",
        "candidate_note_sha256",
        "queue_artifact_path",
        "queue_artifact_sha256",
        "decision_template_path",
        "decision_template_sha256",
        "terminal_status",
        "final_waiting_status",
    ]:
        if closure_packet.get(field) != nonpromotion_packet.get(field):
            issues.append({"issue": f"real_intake_handoff_{field}_mismatch"})
    if closure_packet.get("required_next_gate") != nonpromotion_packet.get("required_next_gate"):
        issues.append({"issue": "real_intake_handoff_required_next_gate_mismatch"})

    row = patch_queue_row or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(nonpromotion_packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != nonpromotion_packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != nonpromotion_packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != nonpromotion_packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if nonpromotion_packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("candidate_note_path") != nonpromotion_packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != nonpromotion_packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != nonpromotion_packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def research_compute_patch_queue_accepted_decision_real_intake_handoff_status(
    final_waiting_chain_closure_capstone_report,
    final_waiting_chain_closure_nonpromotion_gate_report,
    patch_queue_row=None,
    label="",
):
    final_waiting_chain_closure_capstone_report = final_waiting_chain_closure_capstone_report or {}
    final_waiting_chain_closure_nonpromotion_gate_report = final_waiting_chain_closure_nonpromotion_gate_report or {}
    patch_queue_row = patch_queue_row or {}
    issues = final_closure_nonpromotion_core.validate_final_waiting_chain_closure_capstone_report(
        final_waiting_chain_closure_capstone_report
    )
    issues.extend(validate_final_waiting_chain_closure_nonpromotion_gate_report(
        final_waiting_chain_closure_nonpromotion_gate_report
    ))
    issues.extend(validate_handoff_alignment(
        final_waiting_chain_closure_capstone_report,
        final_waiting_chain_closure_nonpromotion_gate_report,
        patch_queue_row,
    ))

    forbidden = any(_forbidden_issue(item) for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_REAL_INTAKE_HANDOFF_STATUS_BLOCKED"
    else:
        status = "PASS"
        state = HANDOFF_STATE

    closure_packet = _packet(
        final_waiting_chain_closure_capstone_report,
        "accepted_decision_final_waiting_chain_closure_capstone_packet",
    )
    nonpromotion_packet = _packet(
        final_waiting_chain_closure_nonpromotion_gate_report,
        "accepted_decision_final_waiting_chain_closure_nonpromotion_gate_packet",
    )
    final_closure_probe_count = int(final_waiting_chain_closure_nonpromotion_gate_report.get("final_waiting_chain_closure_probe_count") or 0)
    final_closure_rejected_count = int(final_waiting_chain_closure_nonpromotion_gate_report.get("final_waiting_chain_closure_probe_rejected_count") or 0)
    chain_report_count = int(final_waiting_chain_closure_capstone_report.get("chain_report_count") or 0)
    chain_pass_report_count = int(final_waiting_chain_closure_capstone_report.get("chain_pass_report_count") or 0)
    evidence_report_count = chain_report_count + 2
    evidence_pass_report_count = chain_pass_report_count + (1 if final_waiting_chain_closure_capstone_report.get("status") == "PASS" else 0) + (1 if final_waiting_chain_closure_nonpromotion_gate_report.get("status") == "PASS" else 0)
    handoff_packet = {
        "real_intake_handoff_status_ready": status == "PASS",
        "handoff_status": HANDOFF_STATUS if status == "PASS" else "",
        "terminal_status": TERMINAL_STATUS if status == "PASS" else "",
        "final_waiting_status": FINAL_WAITING_STATUS if status == "PASS" else "",
        "real_accepted_decision_required": True,
        "real_accepted_decision_present": False,
        "standalone_real_decision_json_required": True,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "local_evidence_report_count": evidence_report_count,
        "local_evidence_pass_report_count": evidence_pass_report_count,
        "final_waiting_chain_report_count": chain_report_count,
        "final_waiting_chain_pass_report_count": chain_pass_report_count,
        "negative_fixture_count": int(final_waiting_chain_closure_capstone_report.get("negative_fixture_count") or 0),
        "negative_fixture_rejected_count": int(final_waiting_chain_closure_capstone_report.get("negative_fixture_rejected_count") or 0),
        "direct_nonpromotion_probe_count": int(final_waiting_chain_closure_capstone_report.get("direct_nonpromotion_probe_count") or 0),
        "direct_nonpromotion_probe_rejected_count": int(final_waiting_chain_closure_capstone_report.get("direct_nonpromotion_probe_rejected_count") or 0),
        "final_waiting_chain_closure_probe_count": final_closure_probe_count,
        "final_waiting_chain_closure_probe_rejected_count": final_closure_rejected_count,
        "decision": "",
        "decision_scope": "",
        "allowed_real_decision": POSITIVE_DECISION,
        "allowed_real_decision_scope": DECISION_SCOPE,
        "patch_id": int(nonpromotion_packet.get("patch_id") or closure_packet.get("patch_id") or 0),
        "slug": nonpromotion_packet.get("slug") or closure_packet.get("slug") or "",
        "patch_queue_status": patch_queue_row.get("status") or "",
        "candidate_note_path": nonpromotion_packet.get("candidate_note_path") or closure_packet.get("candidate_note_path") or "",
        "candidate_note_sha256": nonpromotion_packet.get("candidate_note_sha256") or closure_packet.get("candidate_note_sha256") or "",
        "queue_artifact_path": nonpromotion_packet.get("queue_artifact_path") or closure_packet.get("queue_artifact_path") or "",
        "queue_artifact_sha256": nonpromotion_packet.get("queue_artifact_sha256") or closure_packet.get("queue_artifact_sha256") or "",
        "decision_template_path": nonpromotion_packet.get("decision_template_path") or closure_packet.get("decision_template_path") or "",
        "decision_template_sha256": nonpromotion_packet.get("decision_template_sha256") or closure_packet.get("decision_template_sha256") or "",
        "ordinary_patch_consumer_allowed": False,
        "merge_preflight_allowed": False,
        "merge_preflight_eligible": False,
        "merge_authorized": False,
        "merge_performed": False,
        "commit_allowed": False,
        "commit_performed": False,
        "required_next_gate": INTAKE_GATE,
    }
    real_decision_intake_requirements = {
        "standalone_json_required": True,
        "must_be_received_by_gate": INTAKE_GATE,
        "decision": POSITIVE_DECISION,
        "decision_scope": DECISION_SCOPE,
        "must_reference_patch_id": handoff_packet["patch_id"],
        "must_reference_queue_artifact_sha256": handoff_packet["queue_artifact_sha256"],
        "status_reports_are_not_decisions": True,
        "templates_are_not_decisions": True,
        "synthetic_fixtures_are_not_decisions": True,
    }
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_real_intake_handoff_status_state": state,
        "accepted_decision_real_intake_handoff_status_created": status == "PASS",
        "real_intake_handoff_status_ready": status == "PASS",
        "handoff_status": handoff_packet["handoff_status"],
        "final_waiting_chain_closure_capstone_verified": status == "PASS",
        "final_waiting_chain_closure_nonpromotion_gate_verified": status == "PASS",
        "terminal_status": handoff_packet["terminal_status"],
        "final_waiting_status": handoff_packet["final_waiting_status"],
        "real_accepted_decision_required": True,
        "real_accepted_decision_present": False,
        "standalone_real_decision_json_required": True,
        "required_real_decision": POSITIVE_DECISION,
        "required_real_decision_scope": DECISION_SCOPE,
        "required_decision_intake_gate": INTAKE_GATE,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "local_evidence_report_count": evidence_report_count,
        "local_evidence_pass_report_count": evidence_pass_report_count,
        "final_waiting_chain_report_count": chain_report_count,
        "final_waiting_chain_pass_report_count": chain_pass_report_count,
        "negative_fixture_count": handoff_packet["negative_fixture_count"],
        "negative_fixture_rejected_count": handoff_packet["negative_fixture_rejected_count"],
        "direct_nonpromotion_probe_count": handoff_packet["direct_nonpromotion_probe_count"],
        "direct_nonpromotion_probe_rejected_count": handoff_packet["direct_nonpromotion_probe_rejected_count"],
        "final_waiting_chain_closure_probe_count": final_closure_probe_count,
        "final_waiting_chain_closure_probe_rejected_count": final_closure_rejected_count,
        "patch_queue_review_only_guarded": True,
        "ordinary_patch_consumer_blocked": True,
        "merge_preflight_eligible": False,
        "patch_queue_merge_preflight_allowed": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "local_evidence_report_count": evidence_report_count,
            "local_evidence_pass_report_count": evidence_pass_report_count,
            "final_waiting_chain_report_count": chain_report_count,
            "final_waiting_chain_pass_report_count": chain_pass_report_count,
            "negative_fixture_count": handoff_packet["negative_fixture_count"],
            "negative_fixture_rejected_count": handoff_packet["negative_fixture_rejected_count"],
            "direct_nonpromotion_probe_count": handoff_packet["direct_nonpromotion_probe_count"],
            "direct_nonpromotion_probe_rejected_count": handoff_packet["direct_nonpromotion_probe_rejected_count"],
            "final_waiting_chain_closure_probe_count": final_closure_probe_count,
            "final_waiting_chain_closure_probe_rejected_count": final_closure_rejected_count,
            "accepted_decision_intake_report_count": 0,
            "accepted_decision_intake_present_count": 0,
            "decision_accepted_count": 0,
            "real_accepted_decision_present_count": 0,
            "merge_preflight_allowed_count": 0,
            "merge_preflight_eligible_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "final_waiting_chain_closure_capstone_reference": {
            "report_path": final_waiting_chain_closure_capstone_report.get("report_path") or "",
            "status": final_waiting_chain_closure_capstone_report.get("status") or "",
            "accepted_decision_final_waiting_chain_closure_capstone_state": final_waiting_chain_closure_capstone_report.get(
                "accepted_decision_final_waiting_chain_closure_capstone_state"
            ) or "",
        },
        "final_waiting_chain_closure_nonpromotion_gate_reference": {
            "report_path": final_waiting_chain_closure_nonpromotion_gate_report.get("report_path") or "",
            "status": final_waiting_chain_closure_nonpromotion_gate_report.get("status") or "",
            "accepted_decision_final_waiting_chain_closure_nonpromotion_gate_state": final_waiting_chain_closure_nonpromotion_gate_report.get(
                "accepted_decision_final_waiting_chain_closure_nonpromotion_gate_state"
            ) or "",
        },
        "patch_queue_row": patch_queue_row,
        "real_decision_intake_requirements": real_decision_intake_requirements,
        "accepted_decision_real_intake_handoff_status_packet": handoff_packet,
        "boundary": [
            "This command prepares a local handoff packet for real accepted-decision intake.",
            "The existing local evidence chain remains proof/status material only and is not a decision.",
            "Only a standalone narrow decision JSON received by manual-review-decision-intake can move the row toward merge preflight.",
            "This command does not create a decision file, create an accepted-decision report, start preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_real_intake_handoff_status_markdown(report):
    packet = report.get("accepted_decision_real_intake_handoff_status_packet") or {}
    requirements = report.get("real_decision_intake_requirements") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Real Intake Handoff Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_real_intake_handoff_status_state') or ''}",
        f"- Handoff status: {report.get('handoff_status') or ''}",
        f"- Final waiting status: {report.get('final_waiting_status') or ''}",
        f"- Evidence reports: {report.get('local_evidence_pass_report_count')}/{report.get('local_evidence_report_count')}",
        f"- Direct nonpromotion probes: {report.get('direct_nonpromotion_probe_rejected_count')}/{report.get('direct_nonpromotion_probe_count')}",
        f"- Final closure probes: {report.get('final_waiting_chain_closure_probe_rejected_count')}/{report.get('final_waiting_chain_closure_probe_count')}",
        f"- Required decision: `{requirements.get('decision') or ''}`",
        f"- Required decision scope: `{requirements.get('decision_scope') or ''}`",
        f"- Required next gate: `{requirements.get('must_be_received_by_gate') or ''}`",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Real Intake Handoff Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Queue artifact SHA256: `{packet.get('queue_artifact_sha256') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
