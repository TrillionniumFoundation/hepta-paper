"""Record the accepted-decision chain as awaiting real intake."""


COMMAND = "research-compute-patch-queue-accepted-decision-real-intake-terminal-status"
NONPROMOTION_COMMAND = "research-compute-patch-queue-accepted-decision-positive-shape-nonpromotion-gate"
NONPROMOTION_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_POSITIVE_SHAPE_NONPROMOTION_GATE_PASS_NOT_PROMOTED"
REINTAKE_COMMAND = "research-compute-patch-queue-manual-review-decision-reintake-status"
REINTAKE_AWAITING_STATE = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_REINTAKE_AWAITING_ACCEPTED_DECISION"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"
TERMINAL_STATUS = "AWAITING_REAL_ACCEPTED_DECISION_INTAKE"
TERMINAL_STATE = "PATCH_QUEUE_ACCEPTED_DECISION_REAL_INTAKE_TERMINAL_STATUS_AWAITING_REAL_DECISION"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
POSITIVE_DECISION = "approve_for_merge_preflight"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "accepted_decision_real_intake_terminal_status_state",
    "report_schema",
    "accepted_decision_real_intake_terminal_status_created",
    "nonpromotion_gate_verified",
    "decision_reintake_status_verified",
    "real_accepted_decision_required",
    "real_accepted_decision_present",
    "accepted_decision_intake_report_created",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "dry_run_inputs_rejected",
    "synthetic_fixture_inputs_rejected",
    "nonpromotion_probe_count",
    "nonpromotion_probe_rejected_count",
    "terminal_status",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "merge_preflight_eligible",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "nonpromotion_gate_reference",
    "nonpromotion_gate_report_path",
    "decision_reintake_status_reference",
    "decision_reintake_status_report_path",
    "patch_queue_row",
    "accepted_decision_real_intake_terminal_status_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "nonpromotion_probe_count",
    "nonpromotion_probe_rejected_count",
    "accepted_decision_intake_report_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "real_accepted_decision_present_count",
    "merge_preflight_allowed_count",
    "merge_preflight_eligible_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Records the accepted-decision chain as awaiting a real decision-intake report.",
    "Positive-shape dry-run reports, synthetic fixtures, templates, generic authorization, and forged decision fields remain non-promotable.",
    "This command records report/status only and does not create decisions, start preflight, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _forbidden_issue(issue):
    text = str((issue or {}).get("issue") or "")
    return text.startswith("forbidden_")


def _add_true_issue(issues, data, key, prefix):
    if (data or {}).get(key):
        issues.append({"issue": f"{prefix}:{key}"})


def _packet(report, key):
    return (report or {}).get(key) or {}


def validate_nonpromotion_gate_report(nonpromotion_gate_report):
    issues = []
    report = nonpromotion_gate_report or {}
    packet = _packet(report, "accepted_decision_positive_shape_nonpromotion_gate_packet")
    if report.get("command") != NONPROMOTION_COMMAND:
        issues.append({"issue": "nonpromotion_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "nonpromotion_not_pass", "detail": report.get("status") or ""})
    if report.get("accepted_decision_positive_shape_nonpromotion_gate_state") != NONPROMOTION_STATE:
        issues.append({
            "issue": "nonpromotion_state_mismatch",
            "detail": report.get("accepted_decision_positive_shape_nonpromotion_gate_state") or "",
        })
    for key in [
        "accepted_decision_positive_shape_nonpromotion_gate_created",
        "positive_shape_dry_run_verified",
        "decision_template_verify_verified",
        "nonpromotion_probe_matrix_created",
        "dry_run_report_rejected_as_accepted_decision",
        "synthetic_fixture_rejected_as_accepted_decision",
        "dry_run_report_rejected_as_merge_preflight_input",
    ]:
        if not report.get(key):
            issues.append({"issue": f"nonpromotion_{key}_required"})

    probe_count = int(report.get("nonpromotion_probe_count") or 0)
    rejected_count = int(report.get("nonpromotion_probe_rejected_count") or 0)
    if probe_count < 3:
        issues.append({"issue": "nonpromotion_probe_count_too_low", "detail": probe_count})
    if rejected_count != probe_count or rejected_count < 3:
        issues.append({"issue": "nonpromotion_probes_not_all_rejected", "detail": f"{rejected_count}/{probe_count}"})

    for key in [
        "accepted_decision_intake_report_created",
        "accepted_decision_intake_present",
        "manual_review_decision_present",
        "manual_review_decision_accepted",
        "synthetic_decision_fixture_promoted",
        "positive_shape_dry_run_promoted",
        "patch_queue_merge_preflight_allowed",
        "merge_preflight_eligible",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        _add_true_issue(issues, report, key, f"forbidden_nonpromotion_boundary_crossed")

    if report.get("validation_issues"):
        issues.append({"issue": "nonpromotion_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("nonpromotion_gate_ready") is not True:
        issues.append({"issue": "nonpromotion_packet_not_ready"})
    if int(packet.get("nonpromotion_probe_rejected_count") or 0) != int(packet.get("nonpromotion_probe_count") or 0):
        issues.append({"issue": "nonpromotion_packet_probes_not_all_rejected"})
    for key in [
        "accepted_decision_intake_report_created",
        "accepted_decision_intake_present",
        "manual_review_decision_accepted",
        "positive_shape_dry_run_promoted",
        "synthetic_decision_fixture_promoted",
        "ordinary_patch_consumer_allowed",
        "merge_preflight_allowed",
        "merge_preflight_eligible",
        "merge_authorized",
        "merge_performed",
        "commit_allowed",
        "commit_performed",
    ]:
        _add_true_issue(issues, packet, key, "forbidden_nonpromotion_packet_boundary_crossed")
    if packet.get("decision") != POSITIVE_DECISION:
        issues.append({"issue": "nonpromotion_packet_decision_mismatch", "detail": packet.get("decision") or ""})
    if packet.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "nonpromotion_packet_scope_mismatch", "detail": packet.get("decision_scope") or ""})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "nonpromotion_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for probe in report.get("nonpromotion_probe_matrix") or []:
        if not probe.get("rejected") or probe.get("promoted"):
            issues.append({"issue": "nonpromotion_probe_promoted_or_unrejected", "detail": probe.get("probe_name") or ""})
    return issues


def validate_decision_reintake_status_report(decision_reintake_status_report):
    issues = []
    report = decision_reintake_status_report or {}
    packet = _packet(report, "decision_reintake_status_packet")
    if report.get("command") != REINTAKE_COMMAND:
        issues.append({"issue": "decision_reintake_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "decision_reintake_not_pass", "detail": report.get("status") or ""})
    if report.get("decision_reintake_status_state") != REINTAKE_AWAITING_STATE:
        issues.append({"issue": "decision_reintake_state_mismatch", "detail": report.get("decision_reintake_status_state") or ""})
    if not report.get("decision_reintake_status_created"):
        issues.append({"issue": "decision_reintake_status_created_required"})
    if not report.get("decision_template_verified"):
        issues.append({"issue": "decision_template_verified_required"})
    for key in [
        "accepted_decision_intake_present",
        "manual_review_decision_present",
        "manual_review_decision_accepted",
        "patch_queue_merge_preflight_allowed",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        _add_true_issue(issues, report, key, "forbidden_decision_reintake_boundary_crossed")
    if report.get("validation_issues"):
        issues.append({"issue": "decision_reintake_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if packet.get("decision_reintake_status_ready") is not True:
        issues.append({"issue": "decision_reintake_packet_not_ready"})
    for key in [
        "accepted_decision_intake_present",
        "manual_review_decision_present",
        "manual_review_decision_accepted",
        "ordinary_patch_consumer_allowed",
        "merge_preflight_allowed",
        "merge_authorized",
        "merge_performed",
        "commit_allowed",
        "commit_performed",
    ]:
        _add_true_issue(issues, packet, key, "forbidden_decision_reintake_packet_boundary_crossed")
    if packet.get("decision") or packet.get("decision_scope"):
        issues.append({"issue": "decision_reintake_packet_decision_must_be_empty"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "decision_reintake_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    return issues


def validate_terminal_alignment(nonpromotion_gate_report, decision_reintake_status_report, patch_queue_row):
    issues = []
    non_packet = _packet(nonpromotion_gate_report, "accepted_decision_positive_shape_nonpromotion_gate_packet")
    reintake_packet = _packet(decision_reintake_status_report, "decision_reintake_status_packet")
    for field in [
        "patch_id",
        "slug",
        "candidate_note_path",
        "candidate_note_sha256",
        "queue_artifact_path",
        "queue_artifact_sha256",
        "decision_template_path",
        "decision_template_sha256",
    ]:
        if non_packet.get(field) != reintake_packet.get(field):
            issues.append({"issue": f"terminal_{field}_mismatch"})

    row = patch_queue_row or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(non_packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != non_packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != non_packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != non_packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if non_packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("candidate_note_path") != non_packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != non_packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != non_packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def research_compute_patch_queue_accepted_decision_real_intake_terminal_status(
    nonpromotion_gate_report,
    decision_reintake_status_report,
    patch_queue_row=None,
    label="",
):
    nonpromotion_gate_report = nonpromotion_gate_report or {}
    decision_reintake_status_report = decision_reintake_status_report or {}
    patch_queue_row = patch_queue_row or {}
    issues = validate_nonpromotion_gate_report(nonpromotion_gate_report)
    issues.extend(validate_decision_reintake_status_report(decision_reintake_status_report))
    issues.extend(validate_terminal_alignment(nonpromotion_gate_report, decision_reintake_status_report, patch_queue_row))
    forbidden = any(_forbidden_issue(item) for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_ACCEPTED_DECISION_REAL_INTAKE_TERMINAL_STATUS_BLOCKED"
    else:
        status = "PASS"
        state = TERMINAL_STATE

    non_packet = _packet(nonpromotion_gate_report, "accepted_decision_positive_shape_nonpromotion_gate_packet")
    reintake_packet = _packet(decision_reintake_status_report, "decision_reintake_status_packet")
    rejected_count = int(nonpromotion_gate_report.get("nonpromotion_probe_rejected_count") or 0)
    probe_count = int(nonpromotion_gate_report.get("nonpromotion_probe_count") or 0)
    terminal_packet = {
        "terminal_status_ready": status == "PASS",
        "terminal_status": TERMINAL_STATUS,
        "real_accepted_decision_required": True,
        "real_accepted_decision_present": False,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "nonpromotion_probe_count": probe_count,
        "nonpromotion_probe_rejected_count": rejected_count,
        "dry_run_inputs_rejected": bool(
            nonpromotion_gate_report.get("dry_run_report_rejected_as_accepted_decision")
            and nonpromotion_gate_report.get("dry_run_report_rejected_as_merge_preflight_input")
        ),
        "synthetic_fixture_inputs_rejected": bool(
            nonpromotion_gate_report.get("synthetic_fixture_rejected_as_accepted_decision")
        ),
        "decision": "",
        "decision_scope": "",
        "allowed_real_decision": POSITIVE_DECISION,
        "allowed_real_decision_scope": DECISION_SCOPE,
        "patch_id": int(non_packet.get("patch_id") or reintake_packet.get("patch_id") or 0),
        "slug": non_packet.get("slug") or reintake_packet.get("slug") or "",
        "patch_queue_status": patch_queue_row.get("status") or "",
        "candidate_note_path": non_packet.get("candidate_note_path") or reintake_packet.get("candidate_note_path") or "",
        "candidate_note_sha256": non_packet.get("candidate_note_sha256") or reintake_packet.get("candidate_note_sha256") or "",
        "queue_artifact_path": non_packet.get("queue_artifact_path") or reintake_packet.get("queue_artifact_path") or "",
        "queue_artifact_sha256": non_packet.get("queue_artifact_sha256") or reintake_packet.get("queue_artifact_sha256") or "",
        "decision_template_path": non_packet.get("decision_template_path") or reintake_packet.get("decision_template_path") or "",
        "decision_template_sha256": non_packet.get("decision_template_sha256") or reintake_packet.get("decision_template_sha256") or "",
        "ordinary_patch_consumer_allowed": False,
        "merge_preflight_allowed": False,
        "merge_preflight_eligible": False,
        "merge_authorized": False,
        "merge_performed": False,
        "commit_allowed": False,
        "commit_performed": False,
        "required_next_gate": INTAKE_GATE,
    }
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "accepted_decision_real_intake_terminal_status_state": state,
        "accepted_decision_real_intake_terminal_status_created": status == "PASS",
        "nonpromotion_gate_verified": status == "PASS",
        "decision_reintake_status_verified": status == "PASS",
        "real_accepted_decision_required": True,
        "real_accepted_decision_present": False,
        "accepted_decision_intake_report_created": False,
        "accepted_decision_intake_present": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "dry_run_inputs_rejected": terminal_packet["dry_run_inputs_rejected"],
        "synthetic_fixture_inputs_rejected": terminal_packet["synthetic_fixture_inputs_rejected"],
        "nonpromotion_probe_count": probe_count,
        "nonpromotion_probe_rejected_count": rejected_count,
        "terminal_status": TERMINAL_STATUS if status == "PASS" else "",
        "patch_queue_review_only_guarded": bool(nonpromotion_gate_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(nonpromotion_gate_report.get("ordinary_patch_consumer_blocked")),
        "merge_preflight_eligible": False,
        "patch_queue_merge_preflight_allowed": False,
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "nonpromotion_probe_count": probe_count,
            "nonpromotion_probe_rejected_count": rejected_count,
            "accepted_decision_intake_report_count": 0,
            "accepted_decision_intake_present_count": 0,
            "decision_accepted_count": 0,
            "real_accepted_decision_present_count": 0,
            "merge_preflight_allowed_count": 0,
            "merge_preflight_eligible_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "nonpromotion_gate_reference": {
            "report_path": nonpromotion_gate_report.get("report_path") or "",
            "status": nonpromotion_gate_report.get("status") or "",
            "accepted_decision_positive_shape_nonpromotion_gate_state": nonpromotion_gate_report.get(
                "accepted_decision_positive_shape_nonpromotion_gate_state"
            ) or "",
        },
        "decision_reintake_status_reference": {
            "report_path": decision_reintake_status_report.get("report_path") or "",
            "status": decision_reintake_status_report.get("status") or "",
            "decision_reintake_status_state": decision_reintake_status_report.get("decision_reintake_status_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "accepted_decision_real_intake_terminal_status_packet": terminal_packet,
        "boundary": [
            "This command records that the accepted-decision chain is awaiting a real decision-intake report.",
            "Dry-run reports, synthetic fixtures, templates, generic authorization, and forged decision fields remain non-promotable.",
            "Only a standalone accepted manual-review decision-intake report can move the row toward a later preflight packet.",
            "This command does not create a decision, start preflight, merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_accepted_decision_real_intake_terminal_status_markdown(report):
    packet = report.get("accepted_decision_real_intake_terminal_status_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Accepted Decision Real Intake Terminal Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('accepted_decision_real_intake_terminal_status_state') or ''}",
        f"- Terminal status: {report.get('terminal_status') or ''}",
        f"- Real accepted decision present: {report.get('real_accepted_decision_present')}",
        f"- Nonpromotion probes: {report.get('nonpromotion_probe_rejected_count')}/{report.get('nonpromotion_probe_count')}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Terminal Status Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
