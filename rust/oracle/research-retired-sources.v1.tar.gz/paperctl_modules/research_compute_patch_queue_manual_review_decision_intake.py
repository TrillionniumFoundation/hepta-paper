"""Intake a narrow manual-review decision without merging."""


COMMAND = "research-compute-patch-queue-manual-review-decision-intake"
PREVIOUS_COMMAND = "research-compute-patch-queue-manual-review-packet"
PREVIOUS_READY_STATE = "PATCH_QUEUE_MANUAL_REVIEW_PACKET_READY_NOT_MERGED"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"
ALLOWED_DECISIONS = {
    "hold_for_manual_review",
    "request_more_evidence",
    "reject_review_only_artifact",
    "approve_for_merge_preflight",
}

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "decision_intake_state",
    "report_schema",
    "decision_intake_created",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "manual_review_packet_reference",
    "manual_review_packet_report_path",
    "decision_json_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "decision_material",
    "decision_intake_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "decision_present_count",
    "decision_accepted_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Intakes a narrow manual-review decision for a review-only research-compute patch_queue row.",
    "Without decision material it only records awaiting-decision state.",
    "An accepted decision still does not approve, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_manual_review_packet_report(manual_review_packet_report):
    issues = []
    report = manual_review_packet_report or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "manual_review_packet_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "manual_review_packet_not_pass", "detail": report.get("status") or ""})
    if report.get("manual_review_packet_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "manual_review_packet_state_not_ready", "detail": report.get("manual_review_packet_state") or ""})
    if not report.get("manual_review_packet_created"):
        issues.append({"issue": "manual_review_packet_created_required"})
    if not report.get("ordinary_patch_consumer_blocked"):
        issues.append({"issue": "ordinary_patch_consumer_block_required"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "manual_review_packet_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "manual_review_packet_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    packet = report.get("manual_review_packet") or {}
    candidate_note = str(packet.get("candidate_note_path") or "")
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    if packet.get("review_scope") != QUEUE_SCOPE:
        issues.append({"issue": "review_scope_mismatch", "detail": packet.get("review_scope") or ""})
    if packet.get("queue_artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": packet.get("queue_artifact_type") or ""})
    if packet.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if packet.get("ordinary_patch_consumer_allowed"):
        issues.append({"issue": "ordinary_patch_consumer_must_not_be_allowed"})
    if packet.get("merge_allowed") or packet.get("merge_performed"):
        issues.append({"issue": "manual_review_packet_must_not_allow_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "manual_review_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != "research_compute_patch_queue_manual_review_decision_intake":
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_manual_review_packet_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, manual_review_packet_report):
    issues = []
    row = patch_queue_row or {}
    packet = (manual_review_packet_report or {}).get("manual_review_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, manual_review_packet_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (manual_review_packet_report or {}).get("manual_review_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def validate_decision_material(decision_material, manual_review_packet_report):
    issues = []
    decision = decision_material or {}
    if not decision:
        return issues
    packet = (manual_review_packet_report or {}).get("manual_review_packet") or {}
    if decision.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "decision_scope_mismatch", "detail": decision.get("decision_scope") or ""})
    if decision.get("decision") not in ALLOWED_DECISIONS:
        issues.append({"issue": "decision_value_not_allowed", "detail": decision.get("decision") or ""})
    if int(decision.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "decision_patch_id_mismatch"})
    if decision.get("slug") != packet.get("slug"):
        issues.append({"issue": "decision_slug_mismatch"})
    if decision.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "decision_candidate_note_path_mismatch"})
    if decision.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "decision_candidate_note_sha256_mismatch"})
    if decision.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "decision_queue_artifact_sha256_mismatch"})
    if not decision.get("reviewer_reference"):
        issues.append({"issue": "reviewer_reference_required"})
    if not decision.get("rationale"):
        issues.append({"issue": "decision_rationale_required"})
    for key in [
        "merge_authorized",
        "merge_performed",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if decision.get(key):
            issues.append({"issue": f"decision_material_forbidden_boundary:{key}"})
    return issues


def _next_gate_for_decision(decision):
    if decision == "approve_for_merge_preflight":
        return "research_compute_patch_queue_merge_preflight_packet"
    if decision == "request_more_evidence":
        return "research_compute_candidate_note_evidence_followup_plan"
    if decision == "reject_review_only_artifact":
        return "research_compute_patch_queue_review_only_rejection_status"
    return "research_compute_patch_queue_manual_review_status"


def research_compute_patch_queue_manual_review_decision_intake(
    manual_review_packet_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    decision_material=None,
    label="",
):
    manual_review_packet_report = manual_review_packet_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    decision_material = decision_material or {}
    issues = validate_manual_review_packet_report(manual_review_packet_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, manual_review_packet_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, manual_review_packet_report))
    issues.extend(validate_decision_material(decision_material, manual_review_packet_report))
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_manual_review_packet_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        or str(item.get("issue") or "").startswith("decision_material_forbidden_boundary")
        for item in issues
    )
    decision_present = bool(decision_material)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_INTAKE_BLOCKED"
    elif decision_present:
        status = "PASS"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_ACCEPTED_NOT_MERGED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_AWAITING_NOT_MERGED"
    accepted = status == "PASS" and decision_present
    packet = manual_review_packet_report.get("manual_review_packet") or {}
    decision_value = decision_material.get("decision") if accepted else ""
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "decision_intake_state": state,
        "decision_intake_created": status == "PASS",
        "manual_review_decision_present": decision_present,
        "manual_review_decision_accepted": accepted,
        "patch_queue_review_only_guarded": bool(manual_review_packet_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(manual_review_packet_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "decision_present_count": 1 if decision_present else 0,
            "decision_accepted_count": 1 if accepted else 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "manual_review_packet_reference": {
            "report_path": manual_review_packet_report.get("report_path") or "",
            "status": manual_review_packet_report.get("status") or "",
            "manual_review_packet_state": manual_review_packet_report.get("manual_review_packet_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "decision_material": decision_material,
        "decision_intake_packet": {
            "decision_intake_ready": status == "PASS",
            "manual_review_decision_present": decision_present,
            "manual_review_decision_accepted": accepted,
            "decision": decision_value,
            "decision_scope": decision_material.get("decision_scope") if accepted else "",
            "patch_id": int(packet.get("patch_id") or 0),
            "slug": packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": packet.get("candidate_note_path") or "",
            "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
            "ordinary_patch_consumer_allowed": False,
            "merge_allowed": False,
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": _next_gate_for_decision(decision_value) if accepted else "research_compute_patch_queue_manual_review_decision_intake",
        },
        "boundary": [
            "This command intakes a narrow manual-review decision for a review-only research-compute patch_queue row.",
            "Without decision material it only records that the row is awaiting a narrow manual-review decision.",
            "Accepted decision material still does not approve, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
            "A later gate must re-check any accepted decision before a merge preflight or rejection/status action can occur.",
        ],
    }


def research_compute_patch_queue_manual_review_decision_intake_markdown(report):
    packet = report.get("decision_intake_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Manual Review Decision Intake",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('decision_intake_state') or ''}",
        f"- Decision present: {report.get('manual_review_decision_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Decision Intake Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Decision: `{packet.get('decision') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Queue artifact: `{packet.get('queue_artifact_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
