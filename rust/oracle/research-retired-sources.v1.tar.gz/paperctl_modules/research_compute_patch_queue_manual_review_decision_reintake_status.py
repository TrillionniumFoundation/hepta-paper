"""Status-check manual-review decision re-intake without merge preflight."""


COMMAND = "research-compute-patch-queue-manual-review-decision-reintake-status"
PREVIOUS_COMMAND = "research-compute-patch-queue-manual-review-decision-template-verify"
PREVIOUS_READY_STATE = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_TEMPLATE_VERIFIED_AWAITING_DECISION"
ACCEPTED_INTAKE_COMMAND = "research-compute-patch-queue-manual-review-decision-intake"
ACCEPTED_INTAKE_STATE = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_ACCEPTED_NOT_MERGED"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"
INTAKE_GATE = "research_compute_patch_queue_manual_review_decision_intake"
ALLOWED_DECISIONS = {
    "hold_for_manual_review",
    "request_more_evidence",
    "reject_review_only_artifact",
    "approve_for_merge_preflight",
}

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "decision_reintake_status_state",
    "report_schema",
    "decision_reintake_status_created",
    "decision_template_verified",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "manual_review_decision",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_preflight_allowed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "template_verify_reference",
    "accepted_decision_intake_reference",
    "decision_template_verify_report_path",
    "accepted_decision_intake_report_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "decision_reintake_status_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "merge_preflight_allowed_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Checks whether a verified manual-review decision template has returned through decision intake as an accepted narrow decision.",
    "Without an accepted decision-intake report, merge preflight remains blocked.",
    "This command records status only and does not merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _next_gate_for_decision(decision):
    if decision == "approve_for_merge_preflight":
        return "research_compute_patch_queue_merge_preflight_packet"
    if decision == "request_more_evidence":
        return "research_compute_candidate_note_evidence_followup_plan"
    if decision == "reject_review_only_artifact":
        return "research_compute_patch_queue_review_only_rejection_status"
    if decision == "hold_for_manual_review":
        return "research_compute_patch_queue_manual_review_status"
    return INTAKE_GATE


def validate_template_verify_report(template_verify_report):
    issues = []
    report = template_verify_report or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "template_verify_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "template_verify_not_pass", "detail": report.get("status") or ""})
    if report.get("decision_template_verify_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "template_verify_state_not_awaiting", "detail": report.get("decision_template_verify_state") or ""})
    if not report.get("decision_template_verified"):
        issues.append({"issue": "decision_template_verified_required"})
    if report.get("template_is_decision"):
        issues.append({"issue": "verified_template_must_not_be_decision"})
    if report.get("manual_review_decision_present"):
        issues.append({"issue": "verified_template_report_must_not_contain_decision"})
    if report.get("manual_review_decision_accepted"):
        issues.append({"issue": "verified_template_report_must_not_accept_decision"})
    if not report.get("ordinary_patch_consumer_blocked"):
        issues.append({"issue": "ordinary_patch_consumer_block_required"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "template_verify_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "template_verify_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    packet = report.get("decision_template_verify_packet") or {}
    candidate_note = str(packet.get("candidate_note_path") or "")
    if not packet.get("decision_template_verified"):
        issues.append({"issue": "template_verify_packet_not_verified"})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if not _safe_relative_path(packet.get("decision_template_path") or ""):
        issues.append({"issue": "unsafe_decision_template_path", "detail": packet.get("decision_template_path") or ""})
    if not _valid_sha256(packet.get("decision_template_sha256")):
        issues.append({"issue": "decision_template_sha256_required"})
    if packet.get("template_is_decision"):
        issues.append({"issue": "template_verify_packet_must_not_be_decision"})
    if packet.get("manual_review_decision_present") or packet.get("manual_review_decision_accepted"):
        issues.append({"issue": "template_verify_packet_must_not_contain_or_accept_decision"})
    if packet.get("ordinary_patch_consumer_allowed"):
        issues.append({"issue": "ordinary_patch_consumer_must_not_be_allowed"})
    if packet.get("merge_allowed") or packet.get("merge_authorized") or packet.get("merge_performed"):
        issues.append({"issue": "template_verify_packet_must_not_allow_authorize_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "template_verify_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != INTAKE_GATE:
        issues.append({"issue": "template_verify_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_template_verify_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, template_verify_report):
    issues = []
    row = patch_queue_row or {}
    packet = (template_verify_report or {}).get("decision_template_verify_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, template_verify_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (template_verify_report or {}).get("decision_template_verify_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    if snapshot.get("json_error"):
        issues.append({"issue": "queue_artifact_json_error", "detail": snapshot.get("json_error") or ""})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def validate_accepted_decision_intake_report(accepted_decision_intake_report, template_verify_report):
    issues = []
    report = accepted_decision_intake_report or {}
    if not report:
        return issues
    packet = (template_verify_report or {}).get("decision_template_verify_packet") or {}
    intake_packet = report.get("decision_intake_packet") or {}
    decision = intake_packet.get("decision") or ""
    if report.get("command") != ACCEPTED_INTAKE_COMMAND:
        issues.append({"issue": "accepted_decision_intake_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "accepted_decision_intake_not_pass", "detail": report.get("status") or ""})
    if report.get("decision_intake_state") != ACCEPTED_INTAKE_STATE:
        issues.append({"issue": "accepted_decision_intake_state_mismatch", "detail": report.get("decision_intake_state") or ""})
    if not report.get("decision_intake_created"):
        issues.append({"issue": "accepted_decision_intake_created_required"})
    if not report.get("manual_review_decision_present"):
        issues.append({"issue": "accepted_decision_present_required"})
    if not report.get("manual_review_decision_accepted"):
        issues.append({"issue": "accepted_decision_required"})
    if not report.get("ordinary_patch_consumer_blocked"):
        issues.append({"issue": "ordinary_patch_consumer_block_required"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "accepted_decision_intake_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "accepted_decision_intake_validation_issues_present", "detail": len(report.get("validation_issues") or [])})
    if decision not in ALLOWED_DECISIONS:
        issues.append({"issue": "accepted_decision_value_not_allowed", "detail": decision})
    if intake_packet.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "accepted_decision_scope_mismatch", "detail": intake_packet.get("decision_scope") or ""})
    if int(intake_packet.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "accepted_decision_patch_id_mismatch"})
    if intake_packet.get("slug") != packet.get("slug"):
        issues.append({"issue": "accepted_decision_slug_mismatch"})
    if intake_packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "accepted_decision_patch_queue_status_not_queued", "detail": intake_packet.get("patch_queue_status") or ""})
    if intake_packet.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "accepted_decision_candidate_note_path_mismatch"})
    if intake_packet.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "accepted_decision_candidate_note_sha256_mismatch"})
    if intake_packet.get("queue_artifact_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "accepted_decision_queue_artifact_path_mismatch"})
    if intake_packet.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "accepted_decision_queue_artifact_sha256_mismatch"})
    if intake_packet.get("ordinary_patch_consumer_allowed"):
        issues.append({"issue": "accepted_decision_must_keep_ordinary_patch_consumer_blocked"})
    if intake_packet.get("merge_allowed") or intake_packet.get("merge_authorized") or intake_packet.get("merge_performed"):
        issues.append({"issue": "accepted_decision_intake_packet_must_not_allow_authorize_or_perform_merge"})
    if intake_packet.get("commit_allowed") or intake_packet.get("commit_performed"):
        issues.append({"issue": "accepted_decision_intake_packet_must_not_allow_or_perform_commit"})
    if intake_packet.get("required_next_gate") != _next_gate_for_decision(decision):
        issues.append({"issue": "accepted_decision_required_next_gate_mismatch", "detail": intake_packet.get("required_next_gate") or ""})
    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_accepted_decision_intake_boundary_crossed:{key}"})
    return issues


def research_compute_patch_queue_manual_review_decision_reintake_status(
    template_verify_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    accepted_decision_intake_report=None,
    label="",
):
    template_verify_report = template_verify_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    accepted_decision_intake_report = accepted_decision_intake_report or {}
    issues = validate_template_verify_report(template_verify_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, template_verify_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, template_verify_report))
    issues.extend(validate_accepted_decision_intake_report(accepted_decision_intake_report, template_verify_report))
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_template_verify_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_accepted_decision_intake_boundary_crossed")
        for item in issues
    )
    accepted_present = bool(accepted_decision_intake_report)
    intake_packet = accepted_decision_intake_report.get("decision_intake_packet") or {}
    accepted = accepted_present and not issues and bool(accepted_decision_intake_report.get("manual_review_decision_accepted"))
    decision = intake_packet.get("decision") if accepted else ""
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_REINTAKE_STATUS_BLOCKED"
    elif accepted:
        status = "PASS"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_REINTAKE_ACCEPTED_STATUS_READY_NOT_MERGED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_REINTAKE_AWAITING_ACCEPTED_DECISION"
    packet = template_verify_report.get("decision_template_verify_packet") or {}
    next_gate = _next_gate_for_decision(decision) if accepted else INTAKE_GATE
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "decision_reintake_status_state": state,
        "decision_reintake_status_created": status == "PASS",
        "decision_template_verified": bool(template_verify_report.get("decision_template_verified")),
        "accepted_decision_intake_present": accepted_present,
        "manual_review_decision_present": accepted,
        "manual_review_decision_accepted": accepted,
        "manual_review_decision": decision,
        "patch_queue_review_only_guarded": bool(template_verify_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(template_verify_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_preflight_allowed": accepted and decision == "approve_for_merge_preflight",
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "accepted_decision_intake_present_count": 1 if accepted_present else 0,
            "decision_accepted_count": 1 if accepted else 0,
            "merge_preflight_allowed_count": 1 if accepted and decision == "approve_for_merge_preflight" else 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "template_verify_reference": {
            "report_path": template_verify_report.get("report_path") or "",
            "status": template_verify_report.get("status") or "",
            "decision_template_verify_state": template_verify_report.get("decision_template_verify_state") or "",
        },
        "accepted_decision_intake_reference": {
            "report_path": accepted_decision_intake_report.get("report_path") or "",
            "status": accepted_decision_intake_report.get("status") or "",
            "decision_intake_state": accepted_decision_intake_report.get("decision_intake_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "decision_reintake_status_packet": {
            "decision_reintake_status_ready": status == "PASS",
            "accepted_decision_intake_present": accepted_present,
            "manual_review_decision_present": accepted,
            "manual_review_decision_accepted": accepted,
            "decision": decision,
            "decision_scope": DECISION_SCOPE if accepted else "",
            "patch_id": int(packet.get("patch_id") or 0),
            "slug": packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": packet.get("candidate_note_path") or "",
            "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
            "decision_template_path": packet.get("decision_template_path") or "",
            "decision_template_sha256": packet.get("decision_template_sha256") or "",
            "ordinary_patch_consumer_allowed": False,
            "merge_preflight_allowed": accepted and decision == "approve_for_merge_preflight",
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": next_gate,
        },
        "boundary": [
            "This command checks whether a verified manual-review decision template has returned through decision intake as an accepted narrow decision.",
            "Without an accepted decision-intake report it records an awaiting status and blocks merge preflight.",
            "Even with an accepted decision, this command does not merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_manual_review_decision_reintake_status_markdown(report):
    packet = report.get("decision_reintake_status_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Manual Review Decision Re-Intake Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('decision_reintake_status_state') or ''}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight allowed: {report.get('patch_queue_merge_preflight_allowed')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Re-Intake Status Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Decision: `{packet.get('decision') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
