"""Verify a manual-review decision template without accepting a decision."""


COMMAND = "research-compute-patch-queue-manual-review-decision-template-verify"
PREVIOUS_COMMAND = "research-compute-patch-queue-manual-review-decision-template"
PREVIOUS_READY_STATE = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_TEMPLATE_READY_NOT_DECIDED"
DECISION_TEMPLATE_TYPE = "research_compute_patch_queue_manual_review_decision_template.v1"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"
NEXT_GATE = "research_compute_patch_queue_manual_review_decision_intake"
ALLOWED_DECISIONS = [
    "hold_for_manual_review",
    "request_more_evidence",
    "reject_review_only_artifact",
    "approve_for_merge_preflight",
]

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "decision_template_verify_state",
    "report_schema",
    "decision_template_verified",
    "decision_template_created",
    "decision_template_written",
    "template_is_decision",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "decision_template_reference",
    "decision_template_report_path",
    "decision_template_snapshot",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "decision_template_verify_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "decision_template_verified_count",
    "manual_review_decision_present_count",
    "decision_accepted_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Verifies a written manual-review decision template for a review-only research-compute patch_queue row.",
    "The verified template is not a decision and does not approve, merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
    "A filled decision JSON must return through the manual-review decision intake gate.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_decision_template_report(decision_template_report):
    issues = []
    report = decision_template_report or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "decision_template_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "decision_template_report_not_pass", "detail": report.get("status") or ""})
    if report.get("decision_template_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "decision_template_state_not_ready", "detail": report.get("decision_template_state") or ""})
    if not report.get("decision_template_created"):
        issues.append({"issue": "decision_template_created_required"})
    if not report.get("decision_template_written"):
        issues.append({"issue": "decision_template_written_required"})
    if report.get("template_is_decision"):
        issues.append({"issue": "decision_template_report_must_not_be_decision"})
    if report.get("manual_review_decision_present"):
        issues.append({"issue": "decision_template_report_must_not_contain_decision"})
    if report.get("manual_review_decision_accepted"):
        issues.append({"issue": "decision_template_report_must_not_accept_decision"})
    if not report.get("ordinary_patch_consumer_blocked"):
        issues.append({"issue": "ordinary_patch_consumer_block_required"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "decision_template_report_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "decision_template_report_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    template_path = report.get("decision_template_path") or ""
    if not _safe_relative_path(template_path):
        issues.append({"issue": "unsafe_decision_template_path", "detail": template_path})
    if not _valid_sha256(report.get("decision_template_sha256")):
        issues.append({"issue": "decision_template_sha256_required"})

    packet = report.get("decision_template_packet") or {}
    candidate_note = str(packet.get("candidate_note_path") or "")
    if not packet.get("decision_template_ready"):
        issues.append({"issue": "decision_template_packet_not_ready"})
    if packet.get("decision_template_type") != DECISION_TEMPLATE_TYPE:
        issues.append({"issue": "decision_template_type_mismatch", "detail": packet.get("decision_template_type") or ""})
    if packet.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "decision_scope_mismatch", "detail": packet.get("decision_scope") or ""})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if packet.get("template_is_decision"):
        issues.append({"issue": "decision_template_packet_must_not_be_decision"})
    if packet.get("ordinary_patch_consumer_allowed"):
        issues.append({"issue": "ordinary_patch_consumer_must_not_be_allowed"})
    if packet.get("merge_allowed") or packet.get("merge_authorized") or packet.get("merge_performed"):
        issues.append({"issue": "decision_template_packet_must_not_allow_authorize_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "decision_template_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != NEXT_GATE:
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_decision_template_boundary_crossed:{key}"})
    return issues


def validate_decision_template_snapshot(decision_template_snapshot, decision_template_report):
    issues = []
    snapshot = decision_template_snapshot or {}
    report = decision_template_report or {}
    packet = report.get("decision_template_packet") or {}
    if snapshot.get("path") != report.get("decision_template_path"):
        issues.append({"issue": "decision_template_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "decision_template_file_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "decision_template_not_file"})
    if snapshot.get("sha256") != report.get("decision_template_sha256"):
        issues.append({"issue": "decision_template_sha256_mismatch"})
    if snapshot.get("json_error"):
        issues.append({"issue": "decision_template_json_error", "detail": snapshot.get("json_error") or ""})

    template = snapshot.get("json") or {}
    if template.get("artifact_type") != DECISION_TEMPLATE_TYPE:
        issues.append({"issue": "decision_template_artifact_type_mismatch", "detail": template.get("artifact_type") or ""})
    if template.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "decision_template_scope_mismatch", "detail": template.get("decision_scope") or ""})
    if template.get("allowed_decisions") != ALLOWED_DECISIONS:
        issues.append({"issue": "decision_template_allowed_decisions_mismatch"})
    if template.get("decision") not in ("", None):
        issues.append({"issue": "decision_template_must_not_contain_decision"})
    if template.get("template_is_decision") is not False:
        issues.append({"issue": "decision_template_file_must_not_be_decision"})
    if int(template.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "decision_template_patch_id_mismatch"})
    if template.get("slug") != packet.get("slug"):
        issues.append({"issue": "decision_template_slug_mismatch"})
    if template.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "decision_template_candidate_note_path_mismatch"})
    if template.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "decision_template_candidate_note_sha256_mismatch"})
    if template.get("queue_artifact_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "decision_template_queue_artifact_path_mismatch"})
    if template.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "decision_template_queue_artifact_sha256_mismatch"})
    if template.get("required_next_gate") != NEXT_GATE:
        issues.append({"issue": "decision_template_required_next_gate_mismatch", "detail": template.get("required_next_gate") or ""})
    for key in [
        "merge_authorized",
        "merge_performed",
        "patch_queue_merge_authorized",
        "patch_queue_merge_performed",
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if template.get(key):
            issues.append({"issue": f"forbidden_decision_template_file_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, decision_template_report):
    issues = []
    row = patch_queue_row or {}
    packet = (decision_template_report or {}).get("decision_template_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, decision_template_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (decision_template_report or {}).get("decision_template_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    if snapshot.get("json_error"):
        issues.append({"issue": "queue_artifact_json_error", "detail": snapshot.get("json_error") or ""})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def research_compute_patch_queue_manual_review_decision_template_verify(
    decision_template_report,
    decision_template_snapshot=None,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    decision_template_report = decision_template_report or {}
    decision_template_snapshot = decision_template_snapshot or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_decision_template_report(decision_template_report)
    issues.extend(validate_decision_template_snapshot(decision_template_snapshot, decision_template_report))
    issues.extend(validate_patch_queue_row(patch_queue_row, decision_template_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, decision_template_report))
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_decision_template_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_decision_template_file_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        for item in issues
    )
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_TEMPLATE_VERIFY_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_MANUAL_REVIEW_DECISION_TEMPLATE_VERIFIED_AWAITING_DECISION"
    verified = status == "PASS"
    packet = decision_template_report.get("decision_template_packet") or {}
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "decision_template_verify_state": state,
        "decision_template_verified": verified,
        "decision_template_created": bool(decision_template_report.get("decision_template_created")),
        "decision_template_written": bool(decision_template_report.get("decision_template_written")),
        "template_is_decision": False,
        "manual_review_decision_present": False,
        "manual_review_decision_accepted": False,
        "patch_queue_review_only_guarded": bool(decision_template_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(decision_template_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "decision_template_verified_count": 1 if verified else 0,
            "manual_review_decision_present_count": 0,
            "decision_accepted_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "decision_template_reference": {
            "report_path": decision_template_report.get("report_path") or "",
            "status": decision_template_report.get("status") or "",
            "decision_template_state": decision_template_report.get("decision_template_state") or "",
            "decision_template_path": decision_template_report.get("decision_template_path") or "",
            "decision_template_sha256": decision_template_report.get("decision_template_sha256") or "",
        },
        "decision_template_snapshot": decision_template_snapshot,
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "decision_template_verify_packet": {
            "decision_template_verified": verified,
            "decision_template_type": DECISION_TEMPLATE_TYPE if verified else "",
            "decision_scope": DECISION_SCOPE if verified else "",
            "patch_id": int(packet.get("patch_id") or 0),
            "slug": packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": packet.get("candidate_note_path") or "",
            "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
            "decision_template_path": decision_template_report.get("decision_template_path") or "",
            "decision_template_sha256": decision_template_report.get("decision_template_sha256") or "",
            "template_is_decision": False,
            "manual_review_decision_present": False,
            "manual_review_decision_accepted": False,
            "ordinary_patch_consumer_allowed": False,
            "merge_allowed": False,
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": NEXT_GATE,
        },
        "boundary": [
            "This command verifies a manual-review decision template for a review-only research-compute patch_queue row.",
            "The verified template is still not a decision and cannot authorize approve, merge, apply, dequeue, supersede, commit, or source/package/archive mutation.",
            "A filled decision JSON must return through the manual-review decision intake gate before any later workflow can proceed.",
        ],
    }


def research_compute_patch_queue_manual_review_decision_template_verify_markdown(report):
    packet = report.get("decision_template_verify_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Manual Review Decision Template Verify",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('decision_template_verify_state') or ''}",
        f"- Template verified: {report.get('decision_template_verified')}",
        f"- Template is decision: {report.get('template_is_decision')}",
        f"- Manual decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Verify Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Decision template: `{packet.get('decision_template_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
