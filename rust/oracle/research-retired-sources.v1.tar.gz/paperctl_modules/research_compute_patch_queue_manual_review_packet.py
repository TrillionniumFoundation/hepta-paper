"""Create a manual-review packet for a review-only research-compute queue row."""


COMMAND = "research-compute-patch-queue-manual-review-packet"
PREVIOUS_COMMAND = "research-compute-patch-queue-review-only-guard"
PREVIOUS_READY_STATE = "PATCH_QUEUE_REVIEW_ONLY_GUARDED_MERGE_BLOCKED"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "manual_review_packet_state",
    "report_schema",
    "manual_review_packet_created",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "manual_review_required",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "review_only_guard_reference",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "manual_review_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "manual_review_packet_count",
    "ordinary_patch_consumer_blocked_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Creates a manual-review packet for a review-only research-compute patch_queue row.",
    "No approve/merge/apply/dequeue/supersede action is performed.",
    "No source/package/archive mutation, commit, provider/model call, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_review_only_guard_report(review_only_guard_report):
    issues = []
    report = review_only_guard_report or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "review_only_guard_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "review_only_guard_not_pass", "detail": report.get("status") or ""})
    if report.get("review_only_guard_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "review_only_guard_state_not_ready", "detail": report.get("review_only_guard_state") or ""})
    if not report.get("patch_queue_review_only_guarded"):
        issues.append({"issue": "patch_queue_review_only_guarded_required"})
    if not report.get("ordinary_patch_consumer_blocked"):
        issues.append({"issue": "ordinary_patch_consumer_block_required"})
    if not report.get("manual_review_required"):
        issues.append({"issue": "manual_review_required_flag_missing"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "review_only_guard_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "review_only_guard_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    packet = report.get("review_only_guard_packet") or {}
    candidate_note = str(packet.get("candidate_note_path") or "")
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    if packet.get("queue_artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": packet.get("queue_artifact_type") or ""})
    if packet.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_scope_mismatch", "detail": packet.get("queue_scope") or ""})
    if packet.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if packet.get("ordinary_patch_consumer_allowed"):
        issues.append({"issue": "ordinary_patch_consumer_must_not_be_allowed"})
    if packet.get("merge_allowed") or packet.get("merge_performed"):
        issues.append({"issue": "review_only_packet_must_not_allow_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "review_only_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != "research_compute_patch_queue_manual_review_packet":
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_review_only_guard_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, review_only_guard_report):
    issues = []
    row = patch_queue_row or {}
    packet = (review_only_guard_report or {}).get("review_only_guard_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, review_only_guard_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (review_only_guard_report or {}).get("review_only_guard_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def research_compute_patch_queue_manual_review_packet(
    review_only_guard_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    review_only_guard_report = review_only_guard_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_review_only_guard_report(review_only_guard_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, review_only_guard_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, review_only_guard_report))
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_review_only_guard_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        for item in issues
    )
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_MANUAL_REVIEW_PACKET_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_MANUAL_REVIEW_PACKET_READY_NOT_MERGED"
    ready = status == "PASS"
    guard_packet = review_only_guard_report.get("review_only_guard_packet") or {}
    artifact = queue_artifact_snapshot.get("json") or {}
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "manual_review_packet_state": state,
        "manual_review_packet_created": ready,
        "patch_queue_review_only_guarded": bool(review_only_guard_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(review_only_guard_report.get("ordinary_patch_consumer_blocked")),
        "manual_review_required": bool(artifact.get("manual_review_required")),
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "manual_review_packet_count": 1 if ready else 0,
            "ordinary_patch_consumer_blocked_count": 1 if ready else 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "review_only_guard_reference": {
            "report_path": review_only_guard_report.get("report_path") or "",
            "status": review_only_guard_report.get("status") or "",
            "review_only_guard_state": review_only_guard_report.get("review_only_guard_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "manual_review_packet": {
            "manual_review_packet_ready": ready,
            "review_item_type": "research_compute_candidate_note_queue_artifact",
            "review_scope": QUEUE_SCOPE,
            "patch_id": int(guard_packet.get("patch_id") or 0),
            "slug": guard_packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": guard_packet.get("candidate_note_path") or "",
            "candidate_note_sha256": guard_packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": guard_packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": guard_packet.get("queue_artifact_sha256") or "",
            "queue_artifact_type": artifact.get("artifact_type") or "",
            "queue_artifact_applyable_patch": artifact.get("queue_artifact_applyable_patch"),
            "manual_review_required": bool(artifact.get("manual_review_required")),
            "recommended_review_action": "review_candidate_note_evidence_before_any_merge_decision",
            "ordinary_patch_consumer_allowed": False,
            "merge_allowed": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": "research_compute_patch_queue_manual_review_decision_intake",
        },
        "boundary": [
            "This command creates a manual-review packet for a review-only research-compute patch_queue row.",
            "It does not approve, merge, apply, dequeue, supersede, or consume the queued artifact.",
            "It does not mutate source/package/archive state, call providers/models, commit, upload, email, or perform external actions.",
            "A later manual review decision intake must explicitly decide what to do with the review-only candidate-note artifact.",
        ],
    }


def research_compute_patch_queue_manual_review_packet_markdown(report):
    packet = report.get("manual_review_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Manual Review Packet",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('manual_review_packet_state') or ''}",
        f"- Manual review packet created: {report.get('manual_review_packet_created')}",
        f"- Ordinary patch consumer blocked: {report.get('ordinary_patch_consumer_blocked')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Manual Review Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Review item type: `{packet.get('review_item_type') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Queue artifact: `{packet.get('queue_artifact_path') or ''}`",
        f"- Recommended action: `{packet.get('recommended_review_action') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
