"""Verify a research-compute patch_queue enqueue without merging it."""

import json


COMMAND = "research-compute-patch-queue-post-enqueue-verify"
PREVIOUS_COMMAND = "research-compute-candidate-note-patch-queue-enqueue"
PREVIOUS_READY_STATE = "CANDIDATE_NOTE_PATCH_QUEUE_ENQUEUED"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "post_enqueue_verify_state",
    "report_schema",
    "patch_queue_post_enqueue_verified",
    "patch_queue_enqueue_performed",
    "candidate_patch_queue_mutation_performed",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "enqueue_report_reference",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "post_enqueue_status",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "verified_patch_queue_row_count",
    "patch_queue_enqueue_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Verifies a research-compute patch_queue row after explicit enqueue.",
    "No merge/apply, source/package/archive mutation, commit, provider/model call, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_enqueue_report(enqueue_report):
    issues = []
    report = enqueue_report or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "enqueue_report_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "enqueue_report_not_pass", "detail": report.get("status") or ""})
    if report.get("enqueue_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "enqueue_state_not_enqueued", "detail": report.get("enqueue_state") or ""})
    if not report.get("patch_queue_enqueue_authorized"):
        issues.append({"issue": "patch_queue_enqueue_authorized_required"})
    if not report.get("patch_queue_enqueue_performed"):
        issues.append({"issue": "patch_queue_enqueue_performed_required"})
    if not report.get("candidate_patch_queue_mutation_performed"):
        issues.append({"issue": "candidate_patch_queue_mutation_required"})
    if report.get("validation_issues"):
        issues.append({"issue": "enqueue_report_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    packet = report.get("enqueue_gate_packet") or {}
    target = str(packet.get("candidate_note_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": target})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if int(packet.get("patch_queue_patch_id") or 0) <= 0:
        issues.append({"issue": "patch_queue_patch_id_required"})
    if not packet.get("patch_queue_enqueue_performed"):
        issues.append({"issue": "packet_enqueue_performed_required"})
    if packet.get("commit_performed"):
        issues.append({"issue": "packet_commit_must_not_be_performed"})
    if packet.get("required_next_gate") != "research_compute_patch_queue_post_enqueue_verify":
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_enqueue_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, enqueue_report):
    issues = []
    row = patch_queue_row or {}
    packet = (enqueue_report or {}).get("enqueue_gate_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_queue_patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    targets = row.get("target_paths") or []
    if packet.get("candidate_note_path") not in targets:
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact_snapshot(queue_artifact_snapshot, enqueue_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (enqueue_report or {}).get("enqueue_gate_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    if int(snapshot.get("bytes") or 0) <= 0:
        issues.append({"issue": "queue_artifact_empty"})
    return issues


def research_compute_patch_queue_post_enqueue_verify(enqueue_report, patch_queue_row=None, queue_artifact_snapshot=None, label=""):
    enqueue_report = enqueue_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_enqueue_report(enqueue_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, enqueue_report))
    issues.extend(validate_queue_artifact_snapshot(queue_artifact_snapshot, enqueue_report))
    forbidden = any(str(item.get("issue") or "").startswith("forbidden_enqueue_boundary_crossed") for item in issues)
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_POST_ENQUEUE_VERIFY_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_POST_ENQUEUE_VERIFIED_NOT_MERGED"
    verified = status == "PASS"
    packet = enqueue_report.get("enqueue_gate_packet") or {}
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "post_enqueue_verify_state": state,
        "patch_queue_post_enqueue_verified": verified,
        "patch_queue_enqueue_performed": bool(enqueue_report.get("patch_queue_enqueue_performed")),
        "candidate_patch_queue_mutation_performed": bool(enqueue_report.get("candidate_patch_queue_mutation_performed")),
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "verified_patch_queue_row_count": 1 if verified else 0,
            "patch_queue_enqueue_count": 1 if enqueue_report.get("patch_queue_enqueue_performed") else 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "enqueue_report_reference": {
            "report_path": enqueue_report.get("report_path") or "",
            "status": enqueue_report.get("status") or "",
            "enqueue_state": enqueue_report.get("enqueue_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "post_enqueue_status": {
            "patch_queue_row_verified": verified,
            "patch_id": int(packet.get("patch_queue_patch_id") or 0),
            "slug": packet.get("slug") or "",
            "candidate_note_path": packet.get("candidate_note_path") or "",
            "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "merge_allowed": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": "research_compute_patch_queue_manual_review_or_merge_gate",
        },
        "boundary": [
            "This command verifies a patch_queue row created by the explicit research-compute enqueue gate.",
            "It does not merge/apply the queued artifact, mutate source/package/archive state, call providers/models, commit, upload, email, or perform external actions.",
            "A later manual review or merge gate must re-check the queue row before any queued artifact is consumed.",
        ],
    }


def research_compute_patch_queue_post_enqueue_verify_markdown(report):
    status = report.get("post_enqueue_status") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Post-Enqueue Verify",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('post_enqueue_verify_state') or ''}",
        f"- Patch queue row verified: {report.get('patch_queue_post_enqueue_verified')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Post-Enqueue Status",
        "",
        f"- Patch ID: `{status.get('patch_id') or 0}`",
        f"- Slug: `{status.get('slug') or ''}`",
        f"- Candidate note: `{status.get('candidate_note_path') or ''}`",
        f"- Queue artifact: `{status.get('queue_artifact_path') or ''}`",
        f"- Required next gate: `{status.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
