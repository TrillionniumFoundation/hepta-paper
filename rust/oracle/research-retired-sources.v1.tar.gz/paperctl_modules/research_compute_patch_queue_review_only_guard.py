"""Guard a research-compute patch_queue row as review-only."""


COMMAND = "research-compute-patch-queue-review-only-guard"
PREVIOUS_COMMAND = "research-compute-patch-queue-post-enqueue-verify"
PREVIOUS_READY_STATE = "PATCH_QUEUE_POST_ENQUEUE_VERIFIED_NOT_MERGED"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "review_only_guard_state",
    "report_schema",
    "patch_queue_review_only_guarded",
    "patch_queue_post_enqueue_verified",
    "patch_queue_enqueue_performed",
    "candidate_patch_queue_mutation_performed",
    "queue_artifact_review_only",
    "ordinary_patch_consumer_blocked",
    "manual_review_required",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "post_enqueue_verify_reference",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "review_only_guard_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "review_only_queue_row_count",
    "ordinary_patch_consumer_blocked_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Guards a research-compute patch_queue row as review-only.",
    "The queued artifact is a candidate-note JSON packet, not an applyable manuscript patch.",
    "No merge/apply, source/package/archive mutation, commit, provider/model call, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_post_enqueue_verify_report(post_enqueue_verify_report):
    issues = []
    report = post_enqueue_verify_report or {}
    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "post_enqueue_verify_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "post_enqueue_verify_not_pass", "detail": report.get("status") or ""})
    if report.get("post_enqueue_verify_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "post_enqueue_verify_state_not_ready", "detail": report.get("post_enqueue_verify_state") or ""})
    if not report.get("patch_queue_post_enqueue_verified"):
        issues.append({"issue": "patch_queue_post_enqueue_verified_required"})
    if not report.get("patch_queue_enqueue_performed"):
        issues.append({"issue": "patch_queue_enqueue_performed_required"})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "post_enqueue_report_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "post_enqueue_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    status = report.get("post_enqueue_status") or {}
    candidate_note = str(status.get("candidate_note_path") or "")
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(status.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(status.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": status.get("queue_artifact_path") or ""})
    if not _valid_sha256(status.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if int(status.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if status.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": status.get("patch_queue_status") or ""})
    if status.get("merge_allowed") or status.get("merge_performed"):
        issues.append({"issue": "post_enqueue_status_must_not_allow_or_perform_merge"})
    if status.get("commit_allowed") or status.get("commit_performed"):
        issues.append({"issue": "post_enqueue_status_must_not_allow_or_perform_commit"})
    if status.get("required_next_gate") != "research_compute_patch_queue_manual_review_or_merge_gate":
        issues.append({"issue": "required_next_gate_mismatch", "detail": status.get("required_next_gate") or ""})

    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_post_enqueue_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, post_enqueue_verify_report):
    issues = []
    row = patch_queue_row or {}
    status = (post_enqueue_verify_report or {}).get("post_enqueue_status") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(status.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != status.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != status.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != status.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    targets = row.get("target_paths") or []
    if status.get("candidate_note_path") not in targets:
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != status.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != status.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != status.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, post_enqueue_verify_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    status = (post_enqueue_verify_report or {}).get("post_enqueue_status") or {}
    if snapshot.get("path") != status.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != status.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    if int(snapshot.get("bytes") or 0) <= 0:
        issues.append({"issue": "queue_artifact_empty"})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_not_be_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != status.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != status.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def research_compute_patch_queue_review_only_guard(
    post_enqueue_verify_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    post_enqueue_verify_report = post_enqueue_verify_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_post_enqueue_verify_report(post_enqueue_verify_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, post_enqueue_verify_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, post_enqueue_verify_report))
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_post_enqueue_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        for item in issues
    )
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_REVIEW_ONLY_GUARD_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_REVIEW_ONLY_GUARDED_MERGE_BLOCKED"
    guarded = status == "PASS"
    post_status = post_enqueue_verify_report.get("post_enqueue_status") or {}
    artifact = queue_artifact_snapshot.get("json") or {}
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "review_only_guard_state": state,
        "patch_queue_review_only_guarded": guarded,
        "patch_queue_post_enqueue_verified": bool(post_enqueue_verify_report.get("patch_queue_post_enqueue_verified")),
        "patch_queue_enqueue_performed": bool(post_enqueue_verify_report.get("patch_queue_enqueue_performed")),
        "candidate_patch_queue_mutation_performed": bool(post_enqueue_verify_report.get("candidate_patch_queue_mutation_performed")),
        "queue_artifact_review_only": guarded,
        "ordinary_patch_consumer_blocked": guarded,
        "manual_review_required": bool(artifact.get("manual_review_required")),
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "review_only_queue_row_count": 1 if guarded else 0,
            "ordinary_patch_consumer_blocked_count": 1 if guarded else 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "post_enqueue_verify_reference": {
            "report_path": post_enqueue_verify_report.get("report_path") or "",
            "status": post_enqueue_verify_report.get("status") or "",
            "post_enqueue_verify_state": post_enqueue_verify_report.get("post_enqueue_verify_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "review_only_guard_packet": {
            "patch_queue_review_only_guarded": guarded,
            "patch_id": int(post_status.get("patch_id") or 0),
            "slug": post_status.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": post_status.get("candidate_note_path") or "",
            "candidate_note_sha256": post_status.get("candidate_note_sha256") or "",
            "queue_artifact_path": post_status.get("queue_artifact_path") or "",
            "queue_artifact_sha256": post_status.get("queue_artifact_sha256") or "",
            "queue_artifact_type": artifact.get("artifact_type") or "",
            "queue_scope": artifact.get("queue_scope") or "",
            "queue_artifact_applyable_patch": artifact.get("queue_artifact_applyable_patch"),
            "ordinary_patch_consumer_allowed": False,
            "manual_review_required": bool(artifact.get("manual_review_required")),
            "merge_allowed": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "required_next_gate": "research_compute_patch_queue_manual_review_packet",
        },
        "boundary": [
            "This command marks the research-compute patch_queue row as review-only and blocks ordinary patch consumers.",
            "The queued artifact is a candidate-note JSON packet, not an applyable manuscript patch.",
            "It does not merge/apply the queued artifact, mutate source/package/archive state, call providers/models, commit, upload, email, or perform external actions.",
            "A later manual review packet must decide whether and how a review-only candidate-note artifact is consumed.",
        ],
    }


def research_compute_patch_queue_review_only_guard_markdown(report):
    packet = report.get("review_only_guard_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Review-Only Guard",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('review_only_guard_state') or ''}",
        f"- Review-only guarded: {report.get('patch_queue_review_only_guarded')}",
        f"- Ordinary patch consumer blocked: {report.get('ordinary_patch_consumer_blocked')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Guard Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Queue artifact type: `{packet.get('queue_artifact_type') or ''}`",
        f"- Queue scope: `{packet.get('queue_scope') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Required next gate: `{packet.get('required_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
