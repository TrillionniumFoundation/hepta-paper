"""Finalize a review-only patch-queue artifact after merge preflight execution."""


COMMAND = "research-compute-patch-queue-review-only-terminal-status"
PREVIOUS_COMMAND = "research-compute-patch-queue-merge-preflight-execution"
PREVIOUS_READY_STATE = "PATCH_QUEUE_MERGE_PREFLIGHT_EXECUTION_PASS_REVIEW_ONLY_NOT_MERGEABLE"
DECISION_SCOPE = "research_compute_candidate_note_review_only_decision"
POSITIVE_DECISION = "approve_for_merge_preflight"
QUEUE_ARTIFACT_TYPE = "research_compute_candidate_note_queue_artifact.v1"
QUEUE_SCOPE = "candidate_note_review_queue_only"
TARGET_PREFIX = "research_compute_candidate_notes/"
BLOCKED_REASON = "queue_artifact_is_review_only_not_applyable_patch"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "review_only_terminal_status_state",
    "report_schema",
    "review_only_terminal_status_created",
    "merge_preflight_execution_verified",
    "accepted_decision_intake_present",
    "manual_review_decision_present",
    "manual_review_decision_accepted",
    "manual_review_decision",
    "patch_queue_review_only_guarded",
    "ordinary_patch_consumer_blocked",
    "patch_queue_merge_preflight_allowed",
    "merge_preflight_completed",
    "merge_execution_ready",
    "merge_execution_blocked_reason",
    "patch_queue_merge_authorized",
    "patch_queue_merge_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "merge_preflight_execution_reference",
    "merge_preflight_execution_report_path",
    "patch_queue_row",
    "queue_artifact_snapshot",
    "review_only_terminal_status_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "accepted_decision_intake_present_count",
    "decision_accepted_count",
    "terminal_status_count",
    "merge_execution_ready_count",
    "patch_queue_merge_count",
    "source_mutation_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Finalizes the accepted-decision preflight path for a review-only candidate-note queue artifact.",
    "The terminal status records that no applyable manuscript patch exists for merge execution.",
    "This command records terminal status only and does not merge, apply, dequeue, supersede, commit, or mutate source/package/archive state.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_merge_preflight_execution_report(merge_preflight_execution_report):
    issues = []
    report = merge_preflight_execution_report or {}
    packet = report.get("merge_preflight_execution_packet") or {}

    if report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "merge_preflight_execution_command_mismatch", "detail": report.get("command") or ""})
    if report.get("status") != "PASS":
        issues.append({"issue": "merge_preflight_execution_not_pass", "detail": report.get("status") or ""})
    if report.get("merge_preflight_execution_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "merge_preflight_execution_state_mismatch", "detail": report.get("merge_preflight_execution_state") or ""})
    if not report.get("merge_preflight_execution_performed"):
        issues.append({"issue": "merge_preflight_execution_performed_required"})
    if not report.get("merge_preflight_packet_verified"):
        issues.append({"issue": "merge_preflight_packet_verified_required"})
    if not report.get("accepted_decision_intake_present"):
        issues.append({"issue": "accepted_decision_intake_present_required"})
    if not report.get("manual_review_decision_accepted"):
        issues.append({"issue": "manual_review_decision_accepted_required"})
    if report.get("manual_review_decision") != POSITIVE_DECISION:
        issues.append({"issue": "manual_review_decision_not_approve_for_merge_preflight", "detail": report.get("manual_review_decision") or ""})
    if not report.get("merge_preflight_started") or not report.get("merge_preflight_completed"):
        issues.append({"issue": "merge_preflight_must_be_completed"})
    if report.get("merge_execution_ready"):
        issues.append({"issue": "review_only_terminal_requires_merge_execution_not_ready"})
    if report.get("merge_execution_blocked_reason") != BLOCKED_REASON:
        issues.append({"issue": "merge_execution_blocked_reason_mismatch", "detail": report.get("merge_execution_blocked_reason") or ""})
    if report.get("patch_queue_merge_authorized") or report.get("patch_queue_merge_performed"):
        issues.append({"issue": "merge_preflight_execution_must_not_authorize_or_perform_merge"})
    if report.get("validation_issues"):
        issues.append({"issue": "merge_preflight_execution_validation_issues_present", "detail": len(report.get("validation_issues") or [])})

    if not packet.get("merge_preflight_execution_ready") or not packet.get("merge_preflight_executed"):
        issues.append({"issue": "execution_packet_not_ready"})
    if not packet.get("manual_review_decision_accepted"):
        issues.append({"issue": "execution_packet_decision_accepted_required"})
    if packet.get("decision") != POSITIVE_DECISION:
        issues.append({"issue": "execution_packet_decision_not_approve_for_merge_preflight", "detail": packet.get("decision") or ""})
    if packet.get("decision_scope") != DECISION_SCOPE:
        issues.append({"issue": "execution_packet_decision_scope_mismatch", "detail": packet.get("decision_scope") or ""})
    if int(packet.get("patch_id") or 0) <= 0:
        issues.append({"issue": "patch_id_required"})
    if packet.get("patch_queue_status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": packet.get("patch_queue_status") or ""})
    candidate_note = str(packet.get("candidate_note_path") or "")
    if not _safe_relative_path(candidate_note):
        issues.append({"issue": "unsafe_candidate_note_path", "detail": candidate_note})
    if candidate_note and not candidate_note.startswith(TARGET_PREFIX):
        issues.append({"issue": "candidate_note_path_outside_allowlist", "detail": candidate_note})
    if not _valid_sha256(packet.get("candidate_note_sha256")):
        issues.append({"issue": "candidate_note_sha256_required"})
    if not _safe_relative_path(packet.get("queue_artifact_path") or ""):
        issues.append({"issue": "unsafe_queue_artifact_path", "detail": packet.get("queue_artifact_path") or ""})
    if not _valid_sha256(packet.get("queue_artifact_sha256")):
        issues.append({"issue": "queue_artifact_sha256_required"})
    if packet.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "execution_packet_must_be_review_only_not_applyable"})
    if not packet.get("merge_preflight_completed"):
        issues.append({"issue": "execution_packet_preflight_completed_required"})
    if packet.get("merge_execution_ready"):
        issues.append({"issue": "execution_packet_merge_execution_must_not_be_ready"})
    if packet.get("merge_execution_blocked_reason") != BLOCKED_REASON:
        issues.append({"issue": "execution_packet_blocked_reason_mismatch", "detail": packet.get("merge_execution_blocked_reason") or ""})
    if packet.get("merge_authorized") or packet.get("merge_performed"):
        issues.append({"issue": "execution_packet_must_not_authorize_or_perform_merge"})
    if packet.get("commit_allowed") or packet.get("commit_performed"):
        issues.append({"issue": "execution_packet_must_not_allow_or_perform_commit"})
    if packet.get("required_next_gate") != "research_compute_patch_queue_review_only_terminal_status":
        issues.append({"issue": "required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})

    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_authorized",
        "provider_model_call_performed",
        "external_action_authorized",
        "external_action_performed",
        "commit_authorized",
        "commit_performed",
    ]:
        if report.get(key):
            issues.append({"issue": f"forbidden_merge_preflight_execution_boundary_crossed:{key}"})
    return issues


def validate_patch_queue_row(patch_queue_row, merge_preflight_execution_report):
    issues = []
    row = patch_queue_row or {}
    packet = (merge_preflight_execution_report or {}).get("merge_preflight_execution_packet") or {}
    if not row.get("db_checked"):
        issues.append({"issue": "patch_queue_row_unavailable"})
    if int(row.get("patch_id") or 0) != int(packet.get("patch_id") or 0):
        issues.append({"issue": "patch_queue_patch_id_mismatch"})
    if row.get("slug") != packet.get("slug"):
        issues.append({"issue": "patch_queue_slug_mismatch"})
    if row.get("status") != "queued":
        issues.append({"issue": "patch_queue_status_not_queued", "detail": row.get("status") or ""})
    if row.get("patch_path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "patch_queue_patch_path_mismatch"})
    if row.get("patch_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_patch_sha256_mismatch"})
    if packet.get("candidate_note_path") not in (row.get("target_paths") or []):
        issues.append({"issue": "patch_queue_target_missing_candidate_note"})
    metadata = row.get("metadata") or {}
    if metadata.get("enqueue_scope") != "candidate_note_patch_queue_only":
        issues.append({"issue": "patch_queue_metadata_enqueue_scope_mismatch", "detail": metadata.get("enqueue_scope") or ""})
    if metadata.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_path_mismatch"})
    if metadata.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "patch_queue_metadata_candidate_note_sha256_mismatch"})
    if metadata.get("queue_artifact_sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "patch_queue_metadata_queue_artifact_sha256_mismatch"})
    if metadata.get("commit_performed"):
        issues.append({"issue": "patch_queue_metadata_must_not_commit"})
    return issues


def validate_queue_artifact(queue_artifact_snapshot, merge_preflight_execution_report):
    issues = []
    snapshot = queue_artifact_snapshot or {}
    packet = (merge_preflight_execution_report or {}).get("merge_preflight_execution_packet") or {}
    if snapshot.get("path") != packet.get("queue_artifact_path"):
        issues.append({"issue": "queue_artifact_path_mismatch"})
    if not snapshot.get("exists"):
        issues.append({"issue": "queue_artifact_missing"})
    if not snapshot.get("is_file", True):
        issues.append({"issue": "queue_artifact_not_file"})
    if snapshot.get("sha256") != packet.get("queue_artifact_sha256"):
        issues.append({"issue": "queue_artifact_sha256_mismatch"})
    if snapshot.get("json_error"):
        issues.append({"issue": "queue_artifact_json_error", "detail": snapshot.get("json_error") or ""})
    artifact = snapshot.get("json") or {}
    if artifact.get("artifact_type") != QUEUE_ARTIFACT_TYPE:
        issues.append({"issue": "queue_artifact_type_mismatch", "detail": artifact.get("artifact_type") or ""})
    if artifact.get("queue_scope") != QUEUE_SCOPE:
        issues.append({"issue": "queue_artifact_scope_mismatch", "detail": artifact.get("queue_scope") or ""})
    if artifact.get("queue_artifact_applyable_patch") is not False:
        issues.append({"issue": "queue_artifact_must_remain_review_only_not_applyable_patch"})
    if artifact.get("manual_review_required") is not True:
        issues.append({"issue": "manual_review_required_flag_missing"})
    if artifact.get("candidate_note_path") != packet.get("candidate_note_path"):
        issues.append({"issue": "queue_artifact_candidate_note_path_mismatch"})
    if artifact.get("candidate_note_sha256") != packet.get("candidate_note_sha256"):
        issues.append({"issue": "queue_artifact_candidate_note_sha256_mismatch"})
    if artifact.get("commit_performed"):
        issues.append({"issue": "queue_artifact_must_not_commit"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if artifact.get(key):
            issues.append({"issue": f"forbidden_queue_artifact_boundary_crossed:{key}"})
    return issues


def research_compute_patch_queue_review_only_terminal_status(
    merge_preflight_execution_report,
    patch_queue_row=None,
    queue_artifact_snapshot=None,
    label="",
):
    merge_preflight_execution_report = merge_preflight_execution_report or {}
    patch_queue_row = patch_queue_row or {}
    queue_artifact_snapshot = queue_artifact_snapshot or {}
    issues = validate_merge_preflight_execution_report(merge_preflight_execution_report)
    issues.extend(validate_patch_queue_row(patch_queue_row, merge_preflight_execution_report))
    issues.extend(validate_queue_artifact(queue_artifact_snapshot, merge_preflight_execution_report))
    forbidden = any(
        str(item.get("issue") or "").startswith("forbidden_merge_preflight_execution_boundary_crossed")
        or str(item.get("issue") or "").startswith("forbidden_queue_artifact_boundary_crossed")
        for item in issues
    )
    if forbidden:
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "PATCH_QUEUE_REVIEW_ONLY_TERMINAL_STATUS_BLOCKED"
    else:
        status = "PASS"
        state = "PATCH_QUEUE_REVIEW_ONLY_TERMINAL_STATUS_NO_MERGEABLE_PATCH"
    packet = merge_preflight_execution_report.get("merge_preflight_execution_packet") or {}
    terminal = status == "PASS"
    return {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "review_only_terminal_status_state": state,
        "review_only_terminal_status_created": terminal,
        "merge_preflight_execution_verified": terminal,
        "accepted_decision_intake_present": bool(merge_preflight_execution_report.get("accepted_decision_intake_present")),
        "manual_review_decision_present": bool(merge_preflight_execution_report.get("manual_review_decision_present")) and terminal,
        "manual_review_decision_accepted": bool(merge_preflight_execution_report.get("manual_review_decision_accepted")) and terminal,
        "manual_review_decision": packet.get("decision") if terminal else "",
        "patch_queue_review_only_guarded": bool(merge_preflight_execution_report.get("patch_queue_review_only_guarded")),
        "ordinary_patch_consumer_blocked": bool(merge_preflight_execution_report.get("ordinary_patch_consumer_blocked")),
        "patch_queue_merge_preflight_allowed": bool(merge_preflight_execution_report.get("patch_queue_merge_preflight_allowed")) and terminal,
        "merge_preflight_completed": bool(merge_preflight_execution_report.get("merge_preflight_completed")) and terminal,
        "merge_execution_ready": False,
        "merge_execution_blocked_reason": BLOCKED_REASON if terminal else "",
        "patch_queue_merge_authorized": False,
        "patch_queue_merge_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_authorized": False,
        "provider_model_call_performed": False,
        "external_action_authorized": False,
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "accepted_decision_intake_present_count": 1 if merge_preflight_execution_report.get("accepted_decision_intake_present") else 0,
            "decision_accepted_count": 1 if terminal else 0,
            "terminal_status_count": 1 if terminal else 0,
            "merge_execution_ready_count": 0,
            "patch_queue_merge_count": 0,
            "source_mutation_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "merge_preflight_execution_reference": {
            "report_path": merge_preflight_execution_report.get("report_path") or "",
            "status": merge_preflight_execution_report.get("status") or "",
            "merge_preflight_execution_state": merge_preflight_execution_report.get("merge_preflight_execution_state") or "",
        },
        "patch_queue_row": patch_queue_row,
        "queue_artifact_snapshot": queue_artifact_snapshot,
        "review_only_terminal_status_packet": {
            "review_only_terminal_status_ready": terminal,
            "accepted_decision_intake_present": bool(merge_preflight_execution_report.get("accepted_decision_intake_present")) and terminal,
            "manual_review_decision_present": bool(merge_preflight_execution_report.get("manual_review_decision_present")) and terminal,
            "manual_review_decision_accepted": bool(merge_preflight_execution_report.get("manual_review_decision_accepted")) and terminal,
            "decision": packet.get("decision") if terminal else "",
            "decision_scope": packet.get("decision_scope") if terminal else "",
            "patch_id": int(packet.get("patch_id") or 0),
            "slug": packet.get("slug") or "",
            "patch_queue_status": patch_queue_row.get("status") or "",
            "candidate_note_path": packet.get("candidate_note_path") or "",
            "candidate_note_sha256": packet.get("candidate_note_sha256") or "",
            "queue_artifact_path": packet.get("queue_artifact_path") or "",
            "queue_artifact_sha256": packet.get("queue_artifact_sha256") or "",
            "queue_artifact_applyable_patch": False,
            "merge_preflight_completed": terminal,
            "merge_execution_ready": False,
            "merge_execution_blocked_reason": BLOCKED_REASON if terminal else "",
            "merge_authorized": False,
            "merge_performed": False,
            "commit_allowed": False,
            "commit_performed": False,
            "automatic_next_gate": "",
            "manual_next_options": [
                "provide a separate source-mutation authorization with an applyable patch",
                "leave row queued as review-only evidence",
            ] if terminal else [],
        },
        "boundary": [
            "This command finalizes the accepted-decision merge-preflight path for a review-only candidate-note queue artifact.",
            "The terminal status records that merge preflight completed but no applyable manuscript patch exists for merge execution.",
            "It does not merge, apply, dequeue, supersede, commit, mutate source/package/archive state, call providers/models, or perform external actions.",
        ],
    }


def research_compute_patch_queue_review_only_terminal_status_markdown(report):
    packet = report.get("review_only_terminal_status_packet") or {}
    lines = [
        "# paper_factory Research Compute Patch Queue Review-Only Terminal Status",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('review_only_terminal_status_state') or ''}",
        f"- Accepted decision intake present: {report.get('accepted_decision_intake_present')}",
        f"- Decision accepted: {report.get('manual_review_decision_accepted')}",
        f"- Merge preflight completed: {report.get('merge_preflight_completed')}",
        f"- Merge execution ready: {report.get('merge_execution_ready')}",
        f"- Merge performed: {report.get('patch_queue_merge_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Terminal Status Packet",
        "",
        f"- Patch ID: `{packet.get('patch_id') or 0}`",
        f"- Slug: `{packet.get('slug') or ''}`",
        f"- Candidate note: `{packet.get('candidate_note_path') or ''}`",
        f"- Merge execution blocked reason: `{packet.get('merge_execution_blocked_reason') or ''}`",
        f"- Automatic next gate: `{packet.get('automatic_next_gate') or ''}`",
        "",
        "## Boundary",
        "",
    ]
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
