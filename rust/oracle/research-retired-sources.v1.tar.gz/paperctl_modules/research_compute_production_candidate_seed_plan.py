"""Plan production-candidate re-entry seeds from landed claim boundaries."""

import pathlib
import re


COMMAND = "research-compute-production-candidate-seed-plan"
READY_STATE = "RESEARCH_COMPUTE_PRODUCTION_CANDIDATE_SEED_PLAN_READY"
IDLE_STATE = "RESEARCH_COMPUTE_PRODUCTION_CANDIDATE_SEED_PLAN_IDLE_NO_REENTRY_CANDIDATES"
ATTENTION_STATE = "RESEARCH_COMPUTE_PRODUCTION_CANDIDATE_SEED_PLAN_ATTENTION"
CLAIM_BOUNDARY_TEXT = "Research compute claim boundary"
STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "production_candidate_seed_plan_state",
    "report_schema",
    "label",
    "plan_only",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "provider_model_call_performed",
    "external_action_performed",
    "secret_material_read_performed",
    "patch_queue_merge_performed",
    "commit_performed",
    "seed_plan_ready",
    "production_candidate_reentry_available",
    "theorem_or_proof_seed_available",
    "experiment_seed_available",
    "recommended_next_command",
    "claim_gap_scout_report_paths",
    "summary",
    "seed_candidates",
    "checks",
    "boundary",
]
STABLE_SUMMARY_FIELDS = [
    "scout_report_count",
    "input_already_landed_request_count",
    "seed_candidate_count",
    "deduplicated_request_count",
    "theorem_or_proof_seed_count",
    "experiment_seed_count",
    "source_target_exists_count",
    "boundary_marker_found_count",
    "recommended_seed_count",
    "source_mutation_performed_count",
    "external_action_performed_count",
    "secret_material_read_count",
    "commit_performed_count",
]
REPORT_SCHEMA_NOTES = [
    "Builds a local re-entry seed plan from already-landed research-compute claim boundaries.",
    "This command only reads local scout reports and manuscript text; it does not mutate source, run compute, call models/providers, submit, email, upload, or commit.",
]


SOURCE_LOCATOR_RE = re.compile(r"^(?P<path>[^:]+?)(?::(?P<line>.*))?$")


def _check(name, status, detail="", severity="readiness"):
    return {
        "name": name,
        "status": status,
        "passed": status == "PASS",
        "severity": "" if status == "PASS" else severity,
        "detail": "" if status == "PASS" else detail,
    }


def _source_path(source_locator):
    text = str(source_locator or "").strip()
    match = SOURCE_LOCATOR_RE.match(text)
    return (match.group("path") if match else text).strip()


def _normalized_source_locator(source_locator):
    text = str(source_locator or "").strip()
    match = SOURCE_LOCATOR_RE.match(text)
    if not match:
        return text
    path = (match.group("path") or "").strip()
    line_text = (match.group("line") or "").strip()
    line_match = re.search(r"\d+", line_text)
    return f"{path}:{line_match.group(0)}" if path and line_match else path


def _resolve_source(root, source_locator):
    path_text = _source_path(source_locator)
    if not path_text:
        return pathlib.Path()
    path = pathlib.Path(path_text)
    if not path.is_absolute():
        path = pathlib.Path(root or ".") / path
    return path


def _read_text(path):
    if not path or not path.exists() or not path.is_file():
        return ""
    try:
        return path.read_text(errors="replace")
    except OSError:
        return ""


def _boundary_line(text):
    for index, line in enumerate(str(text or "").splitlines(), start=1):
        if CLAIM_BOUNDARY_TEXT in line:
            return index
    return 0


def _claim_kind(request):
    domain = request.get("_domain") or request.get("original_domain") or ""
    risk_class = str(request.get("risk_class") or request.get("original_risk_class") or "").lower()
    gap_kind = str(request.get("_gap_kind") or request.get("original_gap_kind") or "").lower()
    if domain == "theorem_proof" or "theorem" in risk_class or gap_kind == "proof":
        return "theorem_or_proof"
    if domain == "experiment_evidence" or "benchmark" in risk_class or gap_kind in {"experiment", "reproducibility"}:
        return "experiment"
    return "evidence_anchor"


def _candidate_key(request):
    return (
        request.get("slug") or "",
        _normalized_source_locator(request.get("source_locator") or ""),
        _claim_kind(request),
    )


def _priority(request, source_exists, boundary_found):
    score = 0
    if source_exists:
        score += 10
    if boundary_found:
        score += 10
    if _claim_kind(request) == "theorem_or_proof":
        score += 3
    if _claim_kind(request) == "experiment":
        score += 2
    try:
        score += min(int(request.get("request_id") or request.get("original_request_id") or 0), 1000) / 1000000.0
    except Exception:
        pass
    return score


def _seed_candidate(request, root, scout_report_path, index):
    source_locator = _normalized_source_locator(request.get("source_locator") or "")
    source_path = _resolve_source(root, source_locator)
    text = _read_text(source_path)
    boundary_line = _boundary_line(text)
    claim_kind = _claim_kind(request)
    seed_id = f"claim-boundary-reentry-{index:04d}"
    return {
        "seed_id": seed_id,
        "claim_kind": claim_kind,
        "slug": request.get("slug") or "",
        "request_id": request.get("request_id") or "",
        "request_key": request.get("request_key") or "",
        "source_locator": source_locator,
        "source_path": _source_path(source_locator),
        "source_target_exists": bool(source_path and source_path.exists() and source_path.is_file()),
        "claim_boundary_marker_found": bool(boundary_line),
        "claim_boundary_line": boundary_line,
        "original_request_id": request.get("original_request_id") or request.get("request_id") or "",
        "original_gap_kind": request.get("original_gap_kind") or request.get("_gap_kind") or "",
        "original_domain": request.get("original_domain") or request.get("_domain") or "",
        "original_risk_class": request.get("original_risk_class") or request.get("risk_class") or "",
        "scout_report_path": scout_report_path or "",
        "recommended_stage": "claim_boundary_reentry_evidence_dry_run",
        "recommended_next_command": (
            "research-compute-claim-boundary-reentry-draft "
            f"--seed-id {seed_id} --production-candidate-seed-plan-report <seed-plan-report>"
        ),
        "source_mutation_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "commit_performed": False,
    }


def _scout_path(report):
    return (report or {}).get("report_path") or (report or {}).get("path") or ""


def _coverage_limited(candidates, limit):
    if not limit or len(candidates) <= limit:
        return list(candidates)
    selected = []
    selected_ids = set()
    for kind in ("theorem_or_proof", "experiment"):
        for item in candidates:
            if item.get("claim_kind") == kind and id(item) not in selected_ids:
                selected.append(item)
                selected_ids.add(id(item))
                break
    for item in candidates:
        if id(item) in selected_ids:
            continue
        selected.append(item)
        selected_ids.add(id(item))
        if len(selected) >= limit:
            break
    return selected[:limit]


def production_candidate_seed_plan(claim_gap_scout_reports=None, root=None, label="", limit=20):
    reports = list(claim_gap_scout_reports or [])
    root = pathlib.Path(root or ".")
    limit = max(0, int(limit or 20))
    already_landed = []
    for report in reports:
        path = _scout_path(report)
        for request in report.get("already_landed_source_requests") or []:
            already_landed.append((request, path))

    deduped = {}
    duplicate_count = 0
    for request, path in already_landed:
        key = _candidate_key(request)
        candidate = _seed_candidate(request, root, path, len(deduped) + 1)
        score = _priority(request, candidate["source_target_exists"], candidate["claim_boundary_marker_found"])
        candidate["_priority_score"] = score
        current = deduped.get(key)
        if current and current.get("_priority_score", 0) >= score:
            duplicate_count += 1
            continue
        if current:
            duplicate_count += 1
        deduped[key] = candidate

    candidates = sorted(deduped.values(), key=lambda item: item.get("_priority_score", 0), reverse=True)
    candidates = _coverage_limited(candidates, limit)
    for index, candidate in enumerate(candidates, start=1):
        candidate["seed_id"] = f"claim-boundary-reentry-{index:04d}"
        candidate["recommended_next_command"] = (
            "research-compute-claim-boundary-reentry-draft "
            f"--seed-id {candidate['seed_id']} --production-candidate-seed-plan-report <seed-plan-report>"
        )
        candidate.pop("_priority_score", None)
    recommended = candidates[0] if candidates else {}
    theorem_count = sum(1 for item in candidates if item.get("claim_kind") == "theorem_or_proof")
    experiment_count = sum(1 for item in candidates if item.get("claim_kind") == "experiment")
    marker_count = sum(1 for item in candidates if item.get("claim_boundary_marker_found"))
    checks = [
        _check(
            "claim_gap_scout_report_present",
            "PASS" if reports else "ATTENTION",
            "missing claim gap scout report",
        ),
        _check(
            "landed_claim_boundary_candidates_present",
            "PASS" if candidates else "ATTENTION",
            "no already-landed claim boundary candidates available",
        ),
        _check(
            "claim_boundary_marker_found",
            "PASS" if marker_count else ("ATTENTION" if candidates else "PASS"),
            "selected source files did not expose a claim boundary marker",
        ),
        _check("no_source_external_secret_commit_actions", "PASS", ""),
    ]
    attention_count = sum(1 for check in checks if check["status"] == "ATTENTION")
    if not reports:
        status = "ATTENTION"
        state = ATTENTION_STATE
    elif candidates:
        status = "PASS"
        state = READY_STATE
    else:
        status = "PASS"
        state = IDLE_STATE
    return {
        "command": COMMAND,
        "status": status,
        "production_candidate_seed_plan_state": state,
        "label": label or "",
        "plan_only": True,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "provider_model_call_performed": False,
        "external_action_performed": False,
        "secret_material_read_performed": False,
        "patch_queue_merge_performed": False,
        "commit_performed": False,
        "seed_plan_ready": bool(candidates),
        "production_candidate_reentry_available": bool(candidates),
        "theorem_or_proof_seed_available": bool(theorem_count),
        "experiment_seed_available": bool(experiment_count),
        "recommended_next_command": recommended.get("recommended_next_command") or "",
        "claim_gap_scout_report_paths": [_scout_path(report) for report in reports],
        "summary": {
            "scout_report_count": len(reports),
            "input_already_landed_request_count": len(already_landed),
            "seed_candidate_count": len(candidates),
            "deduplicated_request_count": duplicate_count,
            "theorem_or_proof_seed_count": theorem_count,
            "experiment_seed_count": experiment_count,
            "source_target_exists_count": sum(1 for item in candidates if item.get("source_target_exists")),
            "boundary_marker_found_count": marker_count,
            "recommended_seed_count": 1 if recommended else 0,
            "source_mutation_performed_count": 0,
            "external_action_performed_count": 0,
            "secret_material_read_count": 0,
            "commit_performed_count": 0,
            "attention_check_count": attention_count,
        },
        "seed_candidates": candidates,
        "checks": checks,
        "boundary": [
            "This command creates a local plan for re-entering already-landed research-compute claim boundaries as production-candidate dry-runs.",
            "It does not create active referee requests, edit manuscripts, execute proof/experiment commands, call providers, enqueue or merge patches, submit externally, send Telegram, or commit.",
            "The recommended re-entry draft command is intentionally a next product surface; this plan proves the seed inventory and boundary classification first.",
        ],
    }


def production_candidate_seed_plan_markdown(report):
    lines = [
        "# paper_factory Production Candidate Seed Plan",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('production_candidate_seed_plan_state') or ''}",
        f"- Seed plan ready: {report.get('seed_plan_ready')}",
        f"- Recommended next command: `{report.get('recommended_next_command') or ''}`",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    lines.extend(["", "## Seeds", ""])
    for item in report.get("seed_candidates") or []:
        lines.append(
            f"- `{item.get('seed_id')}` {item.get('claim_kind')} `{item.get('slug')}` "
            f"{item.get('source_locator')} boundary_line={item.get('claim_boundary_line')}"
        )
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
