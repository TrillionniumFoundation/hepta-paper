"""Apply a research-compute candidate note through an explicit local gate.

This gate consumes a successful source-apply preflight report, validates a
single allowlisted new-file patch, and records rollback material. The core
module only validates and reports state; the CLI performs filesystem writes.
"""

import datetime as dt

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-source-apply"
PREVIOUS_COMMAND = "research-compute-source-apply-preflight"
PREVIOUS_READY_STATE = "SOURCE_APPLY_PREFLIGHT_READY_NOT_APPLIED"
EXPECTED_NEXT_GATE = "explicit_source_mutation_apply_gate_with_rollback"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "source_apply_state",
    "report_schema",
    "dry_run",
    "apply_requested",
    "write_requested",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "apply_allowed",
    "enqueue_allowed",
    "source_mutation_apply_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_enqueue_authorized",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_applied",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "rollback_snapshot_created",
    "target_lock_acquired",
    "target_lock_released",
    "post_apply_verified",
    "summary",
    "validation_issues",
    "candidate_patch_file",
    "target_snapshot",
    "parsed_patch",
    "apply_plan",
    "apply_result",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "candidate_patch_file_verified_count",
    "target_lock_acquired_count",
    "rollback_snapshot_created_count",
    "source_mutation_apply_authorized_count",
    "source_mutation_performed_count",
    "post_apply_verified_count",
    "agent_generated_evidence_material_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Explicit local apply gate for research-compute candidate notes.",
    "No package/archive mutation, patch queue enqueue, provider/model call, commit, merge, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def extract_single_new_file_patch(patch_text, target_path):
    lines = (patch_text or "").splitlines()
    target = str(target_path or "")
    issues = []
    if not _safe_relative_path(target) or not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "unsafe_apply_target", "detail": target})
    expected_diff = f"diff --git a/{target} b/{target}"
    expected_plus = f"+++ b/{target}"
    if expected_diff not in lines[:3]:
        issues.append({"issue": "patch_diff_target_mismatch"})
    if "new file mode 100644" not in lines[:5]:
        issues.append({"issue": "patch_new_file_mode_required"})
    if "--- /dev/null" not in lines:
        issues.append({"issue": "patch_must_create_new_file"})
    if expected_plus not in lines:
        issues.append({"issue": "patch_plus_target_mismatch"})
    if sum(1 for line in lines if line.startswith("diff --git ")) != 1:
        issues.append({"issue": "single_file_patch_required"})
    hunk_index = -1
    for index, line in enumerate(lines):
        if line.startswith("@@ "):
            hunk_index = index
            break
    if hunk_index < 0:
        issues.append({"issue": "patch_hunk_required"})
        return {"target_path": target, "content": "", "line_count": 0, "issues": issues}
    content_lines = []
    for line in lines[hunk_index + 1:]:
        if line.startswith("+"):
            content_lines.append(line[1:])
        elif line == r"\ No newline at end of file":
            continue
        else:
            issues.append({"issue": "only_added_lines_allowed_in_new_file_patch", "detail": line[:80]})
    content = "\n".join(content_lines)
    if content_lines:
        content += "\n"
    return {
        "target_path": target,
        "content": content,
        "line_count": len(content_lines),
        "issues": issues,
    }


def make_reverse_delete_patch(target_path, content):
    target = str(target_path or "")
    lines = [
        f"diff --git a/{target} b/{target}",
        "deleted file mode 100644",
        "index 0000000..0000000",
        f"--- a/{target}",
        "+++ /dev/null",
        f"@@ -1,{len((content or '').splitlines())} +0,0 @@",
    ]
    for line in (content or "").splitlines():
        lines.append(f"-{line}")
    return "\n".join(lines) + "\n"


def validate_apply_preflight_report(apply_preflight_report):
    issues = []
    apply_preflight_report = apply_preflight_report or {}
    if apply_preflight_report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "apply_preflight_report_command_mismatch", "detail": apply_preflight_report.get("command") or ""})
    if apply_preflight_report.get("status") != "PASS":
        issues.append({"issue": "apply_preflight_report_not_pass", "detail": apply_preflight_report.get("status") or ""})
    if apply_preflight_report.get("apply_preflight_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "apply_preflight_state_not_ready", "detail": apply_preflight_report.get("apply_preflight_state") or ""})
    if not _literal_bool_or_missing(apply_preflight_report.get("apply_ready_manifest_created")):
        issues.append({"issue": "invalid_apply_preflight_boolean:apply_ready_manifest_created", "detail": repr(apply_preflight_report.get("apply_ready_manifest_created"))})
    if not _literal_true(apply_preflight_report.get("apply_ready_manifest_created")):
        issues.append({"issue": "apply_ready_manifest_required"})
    manifest = apply_preflight_report.get("apply_preflight_manifest") or {}
    if not _literal_bool_or_missing(manifest.get("apply_ready_manifest_created")):
        issues.append({"issue": "invalid_apply_preflight_manifest_boolean:apply_ready_manifest_created", "detail": repr(manifest.get("apply_ready_manifest_created"))})
    if not _literal_true(manifest.get("apply_ready_manifest_created")):
        issues.append({"issue": "apply_ready_manifest_entry_required"})
    if manifest.get("required_next_gate") != EXPECTED_NEXT_GATE:
        issues.append({"issue": "apply_preflight_required_next_gate_mismatch", "detail": manifest.get("required_next_gate") or ""})
    target = str(manifest.get("target_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_apply_target", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "apply_target_outside_research_compute_notes", "detail": target})
    patch_path = str(manifest.get("candidate_patch_path") or "")
    if not _safe_relative_path(patch_path):
        issues.append({"issue": "unsafe_candidate_patch_path", "detail": patch_path})
    if not _valid_sha256(manifest.get("candidate_patch_sha256")):
        issues.append({"issue": "candidate_patch_sha256_required"})
    if manifest.get("candidate_patch_sha256") != manifest.get("candidate_patch_file_sha256"):
        issues.append({"issue": "manifest_candidate_patch_sha_mismatch"})
    rollback = manifest.get("rollback_plan") or {}
    if rollback.get("strategy") != "manual_reverse_patch_required":
        issues.append({"issue": "rollback_strategy_manual_reverse_required", "detail": rollback.get("strategy") or ""})
    if not _literal_bool_or_missing(rollback.get("rollback_required_before_apply")):
        issues.append({"issue": "invalid_rollback_plan_boolean:rollback_required_before_apply", "detail": repr(rollback.get("rollback_required_before_apply"))})
    if not _literal_true(rollback.get("rollback_required_before_apply")):
        issues.append({"issue": "rollback_required_before_apply"})
    tracking = manifest.get("tracking_strategy") or {}
    if not _literal_bool_or_missing(tracking.get("manual_git_tracking_required")):
        issues.append({"issue": "invalid_tracking_strategy_boolean:manual_git_tracking_required", "detail": repr(tracking.get("manual_git_tracking_required"))})
    if not _literal_true(tracking.get("manual_git_tracking_required")):
        issues.append({"issue": "manual_git_tracking_required"})
    if not _literal_bool_or_missing(tracking.get("commit_allowed")):
        issues.append({"issue": "invalid_tracking_strategy_boolean:commit_allowed", "detail": repr(tracking.get("commit_allowed"))})
    elif _literal_true(tracking.get("commit_allowed")):
        issues.append({"issue": "commit_not_allowed_in_apply_gate"})
    for key in [
        "apply_allowed",
        "source_mutation_apply_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_enqueue_authorized",
        "candidate_patch_queue_mutation_performed",
        "candidate_patch_applied",
        "provider_model_call_performed",
        "external_action_performed",
        "commit_performed",
    ]:
        if not _literal_bool_or_missing(apply_preflight_report.get(key)):
            issues.append({"issue": f"invalid_apply_preflight_boolean:{key}", "detail": repr(apply_preflight_report.get(key))})
        elif _literal_true(apply_preflight_report.get(key)):
            issues.append({"issue": f"forbidden_preflight_boundary_crossed:{key}"})
    return issues


def validate_candidate_patch_file(candidate_patch_file, manifest):
    issues = []
    candidate_patch_file = candidate_patch_file or {}
    manifest = manifest or {}
    if not _literal_bool_or_missing(candidate_patch_file.get("exists")):
        issues.append({"issue": "invalid_candidate_patch_file_boolean:exists", "detail": repr(candidate_patch_file.get("exists"))})
    if not _literal_true(candidate_patch_file.get("exists")):
        issues.append({"issue": "candidate_patch_file_missing", "detail": candidate_patch_file.get("path") or ""})
    if not _literal_bool_or_missing(candidate_patch_file.get("is_file")):
        issues.append({"issue": "invalid_candidate_patch_file_boolean:is_file", "detail": repr(candidate_patch_file.get("is_file"))})
    elif candidate_patch_file.get("is_file") is False:
        issues.append({"issue": "candidate_patch_path_not_file", "detail": candidate_patch_file.get("path") or ""})
    if str(candidate_patch_file.get("path") or "") != str(manifest.get("candidate_patch_path") or ""):
        issues.append({"issue": "candidate_patch_file_path_mismatch"})
    if not _valid_sha256(candidate_patch_file.get("sha256")):
        issues.append({"issue": "candidate_patch_file_sha256_required"})
    if candidate_patch_file.get("sha256") != manifest.get("candidate_patch_sha256"):
        issues.append({"issue": "candidate_patch_file_sha256_mismatch"})
    return issues


def validate_target_snapshot(target_snapshot, manifest):
    issues = []
    target_snapshot = target_snapshot or {}
    manifest = manifest or {}
    if str(target_snapshot.get("target_path") or "") != str(manifest.get("target_path") or ""):
        issues.append({"issue": "target_snapshot_path_mismatch"})
    if not _literal_bool_or_missing(target_snapshot.get("exists_before")):
        issues.append({"issue": "invalid_target_snapshot_boolean:exists_before", "detail": repr(target_snapshot.get("exists_before"))})
    elif _literal_true(target_snapshot.get("exists_before")):
        issues.append({"issue": "target_already_exists_new_file_only", "detail": target_snapshot.get("status_short") or ""})
    status_short = str(target_snapshot.get("status_short") or "").strip()
    if status_short and not status_short.startswith("?? "):
        issues.append({"issue": "target_status_not_clean_for_apply", "detail": status_short})
    return issues


def validate_apply_result(apply_result, parsed_patch):
    issues = []
    apply_result = apply_result or {}
    parsed_patch = parsed_patch or {}
    if not _literal_bool_or_missing(apply_result.get("performed")):
        issues.append({"issue": "invalid_apply_result_boolean:performed", "detail": repr(apply_result.get("performed"))})
    if not _literal_true(apply_result.get("performed")):
        issues.append({"issue": "apply_result_not_performed"})
    if str(apply_result.get("target_path") or "") != str(parsed_patch.get("target_path") or ""):
        issues.append({"issue": "apply_result_target_mismatch"})
    if not _valid_sha256(apply_result.get("target_sha256")):
        issues.append({"issue": "apply_result_target_sha256_required"})
    if apply_result.get("target_sha256") != apply_result.get("expected_target_sha256"):
        issues.append({"issue": "post_apply_sha256_mismatch"})
    if not _literal_bool_or_missing(apply_result.get("rollback_snapshot_created")):
        issues.append({"issue": "invalid_apply_result_boolean:rollback_snapshot_created", "detail": repr(apply_result.get("rollback_snapshot_created"))})
    if not _literal_true(apply_result.get("rollback_snapshot_created")):
        issues.append({"issue": "rollback_snapshot_required"})
    if not _literal_bool_or_missing(apply_result.get("target_lock_acquired")):
        issues.append({"issue": "invalid_apply_result_boolean:target_lock_acquired", "detail": repr(apply_result.get("target_lock_acquired"))})
    if not _literal_true(apply_result.get("target_lock_acquired")):
        issues.append({"issue": "target_lock_required"})
    if not _literal_bool_or_missing(apply_result.get("target_lock_released")):
        issues.append({"issue": "invalid_apply_result_boolean:target_lock_released", "detail": repr(apply_result.get("target_lock_released"))})
    if not _literal_true(apply_result.get("target_lock_released")):
        issues.append({"issue": "target_lock_release_required"})
    return issues


def research_compute_source_apply(apply_preflight_report, candidate_patch_file=None, parsed_patch=None, target_snapshot=None, apply_requested=False, write_requested=False, apply_result=None, label=""):
    apply_preflight_report = apply_preflight_report or {}
    manifest = apply_preflight_report.get("apply_preflight_manifest") or {}
    policy = agent_autonomy_policy.normalize_policy(
        manifest.get("autonomy_policy") or apply_preflight_report.get("autonomy_policy")
    )
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = (
        _literal_true(manifest.get("agent_generated_evidence_material"))
        or _literal_true(apply_preflight_report.get("agent_generated_evidence_material"))
    )
    candidate_patch_file = candidate_patch_file or {}
    parsed_patch = parsed_patch or {}
    target_snapshot = target_snapshot or {}
    apply_result = apply_result or {}
    issues = validate_apply_preflight_report(apply_preflight_report)
    issues.extend(validate_candidate_patch_file(candidate_patch_file, manifest))
    issues.extend(validate_target_snapshot(target_snapshot, manifest))
    issues.extend(parsed_patch.get("issues") or [])
    if str(parsed_patch.get("target_path") or "") != str(manifest.get("target_path") or ""):
        issues.append({"issue": "parsed_patch_target_mismatch"})
    if not parsed_patch.get("content"):
        issues.append({"issue": "parsed_patch_content_required"})
    if apply_requested and not write_requested:
        issues.append({"issue": "apply_requires_write_report"})
    source_mutation_apply_authorized = bool(apply_requested and not issues)
    if apply_requested and apply_result:
        issues.extend(validate_apply_result(apply_result, parsed_patch))
    source_mutation_performed = bool(apply_requested and _literal_true(apply_result.get("performed")) and not issues)
    if issues and any(str(item.get("issue") or "").startswith(("forbidden_preflight_boundary_crossed",)) for item in issues):
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "SOURCE_APPLY_GATE_BLOCKED"
    elif source_mutation_performed:
        status = "PASS"
        state = "SOURCE_APPLY_GATE_APPLIED"
    elif source_mutation_apply_authorized:
        status = "PASS"
        state = "SOURCE_APPLY_GATE_READY_TO_APPLY"
    else:
        status = "PASS"
        state = "SOURCE_APPLY_GATE_READY_DRY_RUN_NOT_APPLIED"
    apply_plan = {
        "target_path": manifest.get("target_path") or "",
        "candidate_patch_path": manifest.get("candidate_patch_path") or "",
        "candidate_patch_sha256": manifest.get("candidate_patch_sha256") or "",
        "expected_target_sha256": apply_result.get("expected_target_sha256") or "",
        "parsed_patch_line_count": parsed_patch.get("line_count") or 0,
        "rollback_strategy": "restore_snapshot" if _literal_true(target_snapshot.get("exists_before")) else "delete_created_target",
        "allowlist": [TARGET_PREFIX],
        "apply_requested": bool(apply_requested),
        "write_requested": bool(write_requested),
    }
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "source_apply_state": state,
        "dry_run": not bool(apply_requested),
        "apply_requested": bool(apply_requested),
        "write_requested": bool(write_requested),
        "execution_performed": source_mutation_performed,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "apply_allowed": source_mutation_apply_authorized,
        "enqueue_allowed": False,
        "source_mutation_apply_authorized": source_mutation_apply_authorized,
        "source_mutation_performed": source_mutation_performed,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_applied": source_mutation_performed,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "rollback_snapshot_created": _literal_true(apply_result.get("rollback_snapshot_created")) if apply_requested else False,
        "target_lock_acquired": _literal_true(apply_result.get("target_lock_acquired")) if apply_requested else False,
        "target_lock_released": _literal_true(apply_result.get("target_lock_released")) if apply_requested else False,
        "post_apply_verified": source_mutation_performed,
        "summary": {
            "validation_issue_count": len(issues),
            "candidate_patch_file_verified_count": 1 if not issues else 0,
            "target_lock_acquired_count": 1 if _literal_true(apply_result.get("target_lock_acquired")) else 0,
            "rollback_snapshot_created_count": 1 if _literal_true(apply_result.get("rollback_snapshot_created")) else 0,
            "source_mutation_apply_authorized_count": 1 if source_mutation_apply_authorized else 0,
            "source_mutation_performed_count": 1 if source_mutation_performed else 0,
            "post_apply_verified_count": 1 if source_mutation_performed else 0,
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "candidate_patch_file": candidate_patch_file,
        "target_snapshot": target_snapshot,
        "parsed_patch": {
            "target_path": parsed_patch.get("target_path") or "",
            "line_count": parsed_patch.get("line_count") or 0,
        },
        "apply_plan": apply_plan,
        "apply_result": apply_result,
        "boundary": [
            "This command is the explicit local source apply gate for research-compute candidate notes.",
            "With --apply it may create exactly one allowlisted research_compute_candidate_notes file after lock, rollback, and hash checks.",
            "It does not enqueue patch queues, mutate package/archive state, call providers/models, commit, merge, upload, email, or perform external actions.",
        ],
    }


def research_compute_source_apply_markdown(report):
    lines = [
        "# paper_factory Research Compute Source Apply Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Source apply state: {report.get('source_apply_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Apply requested: {report.get('apply_requested')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    plan = report.get("apply_plan") or {}
    lines.extend(["", "## Apply Plan", ""])
    lines.append(f"- Target: `{plan.get('target_path') or ''}`")
    lines.append(f"- Candidate patch: `{plan.get('candidate_patch_path') or ''}`")
    lines.append(f"- Candidate patch SHA256: `{plan.get('candidate_patch_sha256') or ''}`")
    result = report.get("apply_result") or {}
    if result:
        lines.extend(["", "## Apply Result", ""])
        lines.append(f"- Target SHA256: `{result.get('target_sha256') or ''}`")
        lines.append(f"- Rollback patch: `{result.get('rollback_patch_path') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
