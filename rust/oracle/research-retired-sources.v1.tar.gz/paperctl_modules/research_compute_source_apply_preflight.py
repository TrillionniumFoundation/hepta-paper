"""Prepare a source apply manifest without applying candidate patches.

This layer consumes a source authorization packet and verifies the referenced
candidate patch file, rollback/tracking strategy, and scoped worktree state. It
emits an apply-ready manifest for a later explicit apply gate, but it does not
apply, enqueue, commit, merge, or mutate manuscript/package/archive state.
"""

import datetime as dt

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-source-apply-preflight"
PREVIOUS_COMMAND = "research-compute-source-authorization-packet"
PREVIOUS_READY_STATE = "SOURCE_MUTATION_AUTHORIZATION_PACKET_READY_NOT_APPLIED"
EXPECTED_AUTHORIZATION_NEXT_GATE = "explicit_source_mutation_apply_gate"
NEXT_GATE = "explicit_source_mutation_apply_gate_with_rollback"
TARGET_PREFIX = "research_compute_candidate_notes/"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "apply_preflight_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "apply_ready_manifest_created",
    "apply_allowed",
    "enqueue_allowed",
    "source_mutation_apply_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_enqueue_authorized",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_applied",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "candidate_patch_file",
    "worktree_snapshot",
    "apply_preflight_manifest",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "source_authorization_packet_validated_count",
    "candidate_patch_file_verified_count",
    "worktree_status_checked_count",
    "apply_ready_manifest_created_count",
    "source_mutation_apply_authorized_count",
    "source_mutation_performed_count",
    "agent_generated_evidence_material_count",
]

REPORT_SCHEMA_NOTES = [
    "Validates source authorization and candidate patch file state, then emits an apply-ready manifest only.",
    "No patch application, source mutation, patch queue enqueue, commit, or merge is performed by this command.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def validate_source_authorization_report(source_authorization_report):
    issues = []
    source_authorization_report = source_authorization_report or {}
    if source_authorization_report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "source_authorization_report_command_mismatch", "detail": source_authorization_report.get("command") or ""})
    if source_authorization_report.get("status") != "PASS":
        issues.append({"issue": "source_authorization_report_not_pass", "detail": source_authorization_report.get("status") or ""})
    if source_authorization_report.get("authorization_packet_state") != PREVIOUS_READY_STATE:
        issues.append({"issue": "source_authorization_packet_state_not_ready", "detail": source_authorization_report.get("authorization_packet_state") or ""})
    if not _literal_bool_or_missing(source_authorization_report.get("source_mutation_authorization_packet_created")):
        issues.append({"issue": "invalid_source_authorization_boolean:source_mutation_authorization_packet_created", "detail": repr(source_authorization_report.get("source_mutation_authorization_packet_created"))})
    if not _literal_true(source_authorization_report.get("source_mutation_authorization_packet_created")):
        issues.append({"issue": "source_mutation_authorization_packet_required"})
    packet = source_authorization_report.get("authorization_packet") or {}
    if not _literal_bool_or_missing(packet.get("source_mutation_authorization_packet_ready")):
        issues.append({"issue": "invalid_authorization_packet_boolean:source_mutation_authorization_packet_ready", "detail": repr(packet.get("source_mutation_authorization_packet_ready"))})
    if not _literal_true(packet.get("source_mutation_authorization_packet_ready")):
        issues.append({"issue": "authorization_packet_not_ready"})
    target = str(packet.get("target_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_authorized_target", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "authorized_target_outside_research_compute_notes", "detail": target})
    patch_path = str(packet.get("candidate_patch_path") or "")
    if not _safe_relative_path(patch_path):
        issues.append({"issue": "unsafe_candidate_patch_path", "detail": patch_path})
    if not _valid_sha256(packet.get("candidate_patch_sha256")):
        issues.append({"issue": "candidate_patch_sha256_required"})
    if packet.get("required_next_gate") != EXPECTED_AUTHORIZATION_NEXT_GATE:
        issues.append({"issue": "authorization_required_next_gate_mismatch", "detail": packet.get("required_next_gate") or ""})
    rollback = packet.get("rollback_plan") or {}
    if not rollback:
        issues.append({"issue": "rollback_plan_required"})
    else:
        if rollback.get("strategy") not in {"manual_reverse_patch_required", "restore_from_snapshot_required"}:
            issues.append({"issue": "rollback_strategy_not_allowed", "detail": rollback.get("strategy") or ""})
        if not _literal_bool_or_missing(rollback.get("rollback_required_before_apply")):
            issues.append({"issue": "invalid_rollback_plan_boolean:rollback_required_before_apply", "detail": repr(rollback.get("rollback_required_before_apply"))})
        if not _literal_true(rollback.get("rollback_required_before_apply")):
            issues.append({"issue": "rollback_required_before_apply"})
    tracking = packet.get("tracking_strategy") or {}
    if not tracking:
        issues.append({"issue": "tracking_strategy_required"})
    else:
        if tracking.get("strategy") not in {"manual_git_tracking_required", "review_tracking_strategy_required"}:
            issues.append({"issue": "tracking_strategy_not_allowed", "detail": tracking.get("strategy") or ""})
        if not _literal_bool_or_missing(tracking.get("manual_git_tracking_required")):
            issues.append({"issue": "invalid_tracking_strategy_boolean:manual_git_tracking_required", "detail": repr(tracking.get("manual_git_tracking_required"))})
        if not _literal_true(tracking.get("manual_git_tracking_required")):
            issues.append({"issue": "manual_git_tracking_required"})
        if not _literal_bool_or_missing(tracking.get("commit_allowed")):
            issues.append({"issue": "invalid_tracking_strategy_boolean:commit_allowed", "detail": repr(tracking.get("commit_allowed"))})
        elif _literal_true(tracking.get("commit_allowed")):
            issues.append({"issue": "commit_not_allowed_in_apply_preflight"})
    for key in [
        "apply_allowed",
        "enqueue_allowed",
        "source_mutation_allowed",
        "source_mutation_apply_authorized",
    ]:
        if not _literal_bool_or_missing(packet.get(key)):
            issues.append({"issue": f"invalid_authorization_packet_boolean:{key}", "detail": repr(packet.get(key))})
        elif _literal_true(packet.get(key)):
            issues.append({"issue": f"forbidden_authorization_packet_permission:{key}"})
    for key in [
        "source_mutation_apply_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_enqueue_authorized",
        "candidate_patch_queue_mutation_performed",
        "candidate_patch_applied",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if not _literal_bool_or_missing(source_authorization_report.get(key)):
            issues.append({"issue": f"invalid_source_authorization_boolean:{key}", "detail": repr(source_authorization_report.get(key))})
        elif _literal_true(source_authorization_report.get(key)):
            issues.append({"issue": f"forbidden_boundary_crossed:{key}"})
    return issues


def validate_candidate_patch_file(candidate_patch_file, authorization_packet):
    issues = []
    candidate_patch_file = candidate_patch_file or {}
    authorization_packet = authorization_packet or {}
    if not _literal_bool_or_missing(candidate_patch_file.get("exists")):
        issues.append({"issue": "invalid_candidate_patch_file_boolean:exists", "detail": repr(candidate_patch_file.get("exists"))})
    if not _literal_true(candidate_patch_file.get("exists")):
        issues.append({"issue": "candidate_patch_file_missing", "detail": candidate_patch_file.get("path") or ""})
    if not _literal_bool_or_missing(candidate_patch_file.get("is_file")):
        issues.append({"issue": "invalid_candidate_patch_file_boolean:is_file", "detail": repr(candidate_patch_file.get("is_file"))})
    elif candidate_patch_file.get("is_file") is False:
        issues.append({"issue": "candidate_patch_path_not_file", "detail": candidate_patch_file.get("path") or ""})
    actual_sha = str(candidate_patch_file.get("sha256") or "")
    expected_sha = str(authorization_packet.get("candidate_patch_sha256") or "")
    if not _valid_sha256(actual_sha):
        issues.append({"issue": "candidate_patch_file_sha256_required"})
    if expected_sha and actual_sha and actual_sha != expected_sha:
        issues.append({"issue": "candidate_patch_file_sha256_mismatch"})
    packet_path = str(authorization_packet.get("candidate_patch_path") or "")
    file_path = str(candidate_patch_file.get("path") or "")
    if packet_path and file_path and file_path != packet_path:
        issues.append({"issue": "candidate_patch_file_path_mismatch", "detail": file_path})
    return issues


def validate_worktree_snapshot(worktree_snapshot, target_path):
    issues = []
    worktree_snapshot = worktree_snapshot or {}
    if not _literal_bool_or_missing(worktree_snapshot.get("worktree_status_checked")):
        issues.append({"issue": "invalid_worktree_snapshot_boolean:worktree_status_checked", "detail": repr(worktree_snapshot.get("worktree_status_checked"))})
    if not _literal_true(worktree_snapshot.get("worktree_status_checked")):
        issues.append({"issue": "worktree_status_check_required"})
    if str(worktree_snapshot.get("target_path") or "") != str(target_path or ""):
        issues.append({"issue": "worktree_target_mismatch", "detail": worktree_snapshot.get("target_path") or ""})
    target_status = str(worktree_snapshot.get("target_status_short") or "").strip()
    if target_status and not target_status.startswith("?? "):
        issues.append({"issue": "target_path_not_clean", "detail": target_status})
    if not _literal_bool_or_missing(worktree_snapshot.get("commit_allowed")):
        issues.append({"issue": "invalid_worktree_snapshot_boolean:commit_allowed", "detail": repr(worktree_snapshot.get("commit_allowed"))})
    elif _literal_true(worktree_snapshot.get("commit_allowed")):
        issues.append({"issue": "commit_not_allowed_in_worktree_snapshot"})
    if not _literal_bool_or_missing(worktree_snapshot.get("manual_git_tracking_required")):
        issues.append({"issue": "invalid_worktree_snapshot_boolean:manual_git_tracking_required", "detail": repr(worktree_snapshot.get("manual_git_tracking_required"))})
    if not _literal_true(worktree_snapshot.get("manual_git_tracking_required")):
        issues.append({"issue": "manual_git_tracking_required_in_worktree_snapshot"})
    return issues


def research_compute_source_apply_preflight(source_authorization_report, candidate_patch_file=None, worktree_snapshot=None, label=""):
    source_authorization_report = source_authorization_report or {}
    packet = source_authorization_report.get("authorization_packet") or {}
    policy = agent_autonomy_policy.normalize_policy(
        packet.get("autonomy_policy") or source_authorization_report.get("autonomy_policy")
    )
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = (
        _literal_true(packet.get("agent_generated_evidence_material"))
        or _literal_true(source_authorization_report.get("agent_generated_evidence_material"))
    )
    candidate_patch_file = candidate_patch_file or {}
    worktree_snapshot = worktree_snapshot or {}
    issues = validate_source_authorization_report(source_authorization_report)
    issues.extend(validate_candidate_patch_file(candidate_patch_file, packet))
    issues.extend(validate_worktree_snapshot(worktree_snapshot, packet.get("target_path") or ""))
    status = "PASS" if not issues else "ATTENTION"
    ready = not issues
    manifest = {
        "apply_ready_manifest_created": ready,
        "manifest_state": "READY_FOR_EXPLICIT_APPLY_GATE" if ready else "BLOCKED",
        "target_path": packet.get("target_path") or "",
        "candidate_patch_path": packet.get("candidate_patch_path") or "",
        "candidate_patch_sha256": packet.get("candidate_patch_sha256") or "",
        "candidate_patch_file_sha256": candidate_patch_file.get("sha256") or "",
        "source_authorization_report_path": source_authorization_report.get("report_path") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "rollback_plan": packet.get("rollback_plan") or {},
        "tracking_strategy": packet.get("tracking_strategy") or {},
        "worktree_snapshot": worktree_snapshot,
        "apply_allowed": False,
        "enqueue_allowed": False,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "required_next_gate": NEXT_GATE,
    }
    report = {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "apply_preflight_state": "SOURCE_APPLY_PREFLIGHT_READY_NOT_APPLIED" if ready else "SOURCE_APPLY_PREFLIGHT_BLOCKED",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "apply_ready_manifest_created": ready,
        "apply_allowed": False,
        "enqueue_allowed": False,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_applied": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "source_authorization_packet_validated_count": 1 if ready else 0,
            "candidate_patch_file_verified_count": 1 if ready else 0,
            "worktree_status_checked_count": 1 if _literal_true(worktree_snapshot.get("worktree_status_checked")) else 0,
            "apply_ready_manifest_created_count": 1 if ready else 0,
            "source_mutation_apply_authorized_count": 0,
            "source_mutation_performed_count": 0,
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
        },
        "validation_issues": issues,
        "candidate_patch_file": candidate_patch_file,
        "worktree_snapshot": worktree_snapshot,
        "apply_preflight_manifest": manifest,
        "boundary": [
            "This command validates an authorization packet and emits an apply-ready manifest only.",
            "It does not apply a patch, enqueue a patch, mutate source/package/archive state, call a provider/model, commit, merge, or perform external actions.",
            "A later explicit apply gate with rollback checks must consume this manifest before any candidate patch can touch manuscript source.",
        ],
    }
    if any(str(item.get("issue") or "").startswith(("forbidden_boundary_crossed", "forbidden_authorization_packet_permission")) for item in issues):
        report["status"] = "FAIL"
        report["apply_preflight_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
        report["apply_ready_manifest_created"] = False
        report["apply_preflight_manifest"]["apply_ready_manifest_created"] = False
        report["apply_preflight_manifest"]["manifest_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
    return report


def research_compute_source_apply_preflight_markdown(report):
    lines = [
        "# paper_factory Research Compute Source Apply Preflight",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Apply preflight state: {report.get('apply_preflight_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Apply-ready manifest created: {report.get('apply_ready_manifest_created')}",
        f"- Apply allowed: {report.get('apply_allowed')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    manifest = report.get("apply_preflight_manifest") or {}
    lines.extend(["", "## Apply Preflight Manifest", ""])
    lines.append(f"- Target: `{manifest.get('target_path') or ''}`")
    lines.append(f"- Candidate patch: `{manifest.get('candidate_patch_path') or ''}`")
    lines.append(f"- Candidate patch SHA256: `{manifest.get('candidate_patch_sha256') or ''}`")
    lines.append(f"- Candidate patch file SHA256: `{manifest.get('candidate_patch_file_sha256') or ''}`")
    lines.append(f"- Required next gate: `{manifest.get('required_next_gate') or ''}`")
    lines.append(f"- Source mutation apply authorized: {manifest.get('source_mutation_apply_authorized')}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
