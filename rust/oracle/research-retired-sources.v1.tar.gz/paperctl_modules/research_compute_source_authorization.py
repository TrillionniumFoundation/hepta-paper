"""Validate source-mutation authorization material without applying patches.

This layer consumes a source-gate preflight report and operator authorization
material, then emits a local authorization packet for a later apply gate. It
does not apply, enqueue, merge, or mutate manuscript/package/archive state.
"""

import datetime as dt

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-source-authorization-packet"
AUTHORIZATION_SCOPE = "source_mutation_authorization_packet_only"
NEXT_GATE = "explicit_source_mutation_apply_gate"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "authorization_packet_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorization_packet_created",
    "source_mutation_apply_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_enqueue_authorized",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_applied",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "validation_issues",
    "authorization_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "authorization_material_validated_count",
    "source_mutation_authorization_packet_created_count",
    "source_mutation_apply_authorized_count",
    "rollback_plan_valid_count",
    "tracking_strategy_valid_count",
    "agent_generated_evidence_material_count",
]

REPORT_SCHEMA_NOTES = [
    "Validates narrow source authorization material and emits a local packet only.",
    "No source mutation, patch queue enqueue, patch application, commit, or merge is performed by this command.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def default_authorization_material(operator_id="", target_path="", candidate_patch_sha256=""):
    return {
        "scope": AUTHORIZATION_SCOPE,
        "operator_id": operator_id or "local-operator",
        "target_path": target_path or "",
        "candidate_patch_sha256": candidate_patch_sha256 or "",
        "authorized_next_gate": NEXT_GATE,
        "rollback_plan": {
            "strategy": "manual_reverse_patch_required",
            "rollback_required_before_apply": True,
        },
        "tracking_strategy": {
            "strategy": "manual_git_tracking_required",
            "manual_git_tracking_required": True,
            "commit_allowed": False,
        },
    }


def validate_source_gate_report(source_gate_report):
    issues = []
    if source_gate_report.get("command") != "research-compute-source-gate":
        issues.append({"issue": "source_gate_report_command_mismatch", "detail": source_gate_report.get("command") or ""})
    if source_gate_report.get("status") != "PASS":
        issues.append({"issue": "source_gate_report_not_pass", "detail": source_gate_report.get("status") or ""})
    if source_gate_report.get("source_gate_state") != "SOURCE_PREFLIGHT_READY_APPLY_BLOCKED":
        issues.append({"issue": "source_gate_state_not_ready", "detail": source_gate_report.get("source_gate_state") or ""})
    packet = source_gate_report.get("source_gate_packet") or {}
    if not _literal_bool_or_missing(packet.get("source_preflight_passed")):
        issues.append({"issue": "invalid_source_gate_packet_boolean:source_preflight_passed", "detail": repr(packet.get("source_preflight_passed"))})
    if not _literal_true(packet.get("source_preflight_passed")):
        issues.append({"issue": "source_preflight_required"})
    target = str(packet.get("target_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_source_gate_target", "detail": target})
    if target and not target.startswith("research_compute_candidate_notes/"):
        issues.append({"issue": "source_gate_target_outside_research_compute_notes", "detail": target})
    if not _valid_sha256(packet.get("candidate_patch_sha256")):
        issues.append({"issue": "candidate_patch_sha256_required"})
    for key in [
        "apply_allowed",
        "enqueue_allowed",
        "source_mutation_allowed",
    ]:
        if not _literal_bool_or_missing(packet.get(key)):
            issues.append({"issue": f"invalid_source_gate_packet_boolean:{key}", "detail": repr(packet.get(key))})
        elif _literal_true(packet.get(key)):
            issues.append({"issue": f"forbidden_source_gate_permission:{key}"})
    for key in [
        "source_mutation_authorized",
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_enqueue_authorized",
        "candidate_patch_queue_mutation_performed",
        "candidate_patch_applied",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if not _literal_bool_or_missing(source_gate_report.get(key)):
            issues.append({"issue": f"invalid_source_gate_boolean:{key}", "detail": repr(source_gate_report.get(key))})
        elif _literal_true(source_gate_report.get(key)):
            issues.append({"issue": f"forbidden_boundary_crossed:{key}"})
    return issues


def validate_authorization_material(material, source_gate_packet):
    issues = []
    if not isinstance(material, dict) or not material:
        return [{"issue": "authorization_material_required"}]
    scope = str(material.get("scope") or material.get("authorization_scope") or "")
    if scope != AUTHORIZATION_SCOPE:
        issues.append({"issue": "authorization_scope_mismatch", "detail": scope})
    if not str(material.get("operator_id") or "").strip():
        issues.append({"issue": "operator_id_required"})
    expected_target = str(source_gate_packet.get("target_path") or "")
    if str(material.get("target_path") or "") != expected_target:
        issues.append({"issue": "authorization_target_mismatch", "detail": material.get("target_path") or ""})
    expected_sha = str(source_gate_packet.get("candidate_patch_sha256") or "")
    if str(material.get("candidate_patch_sha256") or "") != expected_sha:
        issues.append({"issue": "authorization_candidate_patch_sha_mismatch"})
    if str(material.get("authorized_next_gate") or "") != NEXT_GATE:
        issues.append({"issue": "authorized_next_gate_mismatch", "detail": material.get("authorized_next_gate") or ""})
    rollback = material.get("rollback_plan") or {}
    if not isinstance(rollback, dict) or not rollback:
        issues.append({"issue": "rollback_plan_required"})
    else:
        if rollback.get("strategy") not in {"manual_reverse_patch_required", "restore_from_snapshot_required"}:
            issues.append({"issue": "rollback_strategy_not_allowed", "detail": rollback.get("strategy") or ""})
        if not _literal_bool_or_missing(rollback.get("rollback_required_before_apply")):
            issues.append({"issue": "invalid_rollback_plan_boolean:rollback_required_before_apply", "detail": repr(rollback.get("rollback_required_before_apply"))})
        if not _literal_true(rollback.get("rollback_required_before_apply")):
            issues.append({"issue": "rollback_required_before_apply"})
    tracking = material.get("tracking_strategy") or {}
    if not isinstance(tracking, dict) or not tracking:
        issues.append({"issue": "tracking_strategy_required"})
    else:
        if tracking.get("strategy") not in {"manual_git_tracking_required", "review_tracking_strategy_required"}:
            issues.append({"issue": "tracking_strategy_not_allowed", "detail": tracking.get("strategy") or ""})
        if not _literal_bool_or_missing(tracking.get("manual_git_tracking_required")):
            issues.append({"issue": "invalid_tracking_strategy_boolean:manual_git_tracking_required", "detail": repr(tracking.get("manual_git_tracking_required"))})
        if not _literal_true(tracking.get("manual_git_tracking_required")):
            issues.append({"issue": "manual_git_tracking_required"})
        if not _literal_bool_or_missing(tracking.get("commit_allowed")):
            issues.append({"issue": "invalid_tracking_strategy_boolean:commit_allowed", "detail": repr(tracking.get("commit_allowed"))})
        elif _literal_true(tracking.get("commit_allowed")):
            issues.append({"issue": "commit_not_allowed_in_authorization_packet"})
    for key in [
        "apply_now",
        "apply_allowed",
        "enqueue_allowed",
        "source_mutation_performed",
        "package_mutation_authorized",
        "archive_mutation_authorized",
        "provider_model_call_authorized",
        "external_action_authorized",
        "commit_allowed",
        "merge_allowed",
    ]:
        if not _literal_bool_or_missing(material.get(key)):
            issues.append({"issue": f"invalid_authorization_material_boolean:{key}", "detail": repr(material.get(key))})
        elif _literal_true(material.get(key)):
            issues.append({"issue": f"forbidden_authorization_flag:{key}"})
    return issues


def research_compute_source_authorization_packet(source_gate_report, authorization_material=None, label=""):
    source_gate_report = source_gate_report or {}
    source_gate_packet = source_gate_report.get("source_gate_packet") or {}
    policy = agent_autonomy_policy.normalize_policy(
        source_gate_packet.get("autonomy_policy") or source_gate_report.get("autonomy_policy")
    )
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    authorization_material = authorization_material or {}
    if not authorization_material and full_autonomy:
        authorization_material = default_authorization_material(
            operator_id=policy.get("operator_id") or "full-agent-autonomy",
            target_path=source_gate_packet.get("target_path") or "",
            candidate_patch_sha256=source_gate_packet.get("candidate_patch_sha256") or "",
        )
        authorization_material["authorization_source"] = "full_agent_autonomy_policy"
    issues = validate_source_gate_report(source_gate_report)
    issues.extend(validate_authorization_material(authorization_material, source_gate_packet))
    status = "PASS" if not issues else "ATTENTION"
    packet_ready = not issues
    agent_generated = (
        _literal_true(source_gate_packet.get("agent_generated_evidence_material"))
        or _literal_true(source_gate_report.get("agent_generated_evidence_material"))
    )
    authorization_packet = {
        "source_mutation_authorization_packet_ready": packet_ready,
        "authorization_scope": AUTHORIZATION_SCOPE,
        "operator_id": authorization_material.get("operator_id") or "",
        "target_path": source_gate_packet.get("target_path") or "",
        "candidate_patch_path": source_gate_packet.get("candidate_patch_path") or "",
        "candidate_patch_sha256": source_gate_packet.get("candidate_patch_sha256") or "",
        "source_gate_report_path": source_gate_report.get("report_path") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "authorization_source": authorization_material.get("authorization_source") or "operator_material",
        "rollback_plan": authorization_material.get("rollback_plan") or {},
        "tracking_strategy": authorization_material.get("tracking_strategy") or {},
        "apply_allowed": False,
        "enqueue_allowed": False,
        "source_mutation_allowed": False,
        "source_mutation_apply_authorized": False,
        "required_next_gate": NEXT_GATE,
    }
    report = {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "authorization_packet_state": "SOURCE_MUTATION_AUTHORIZATION_PACKET_READY_NOT_APPLIED" if packet_ready else "SOURCE_MUTATION_AUTHORIZATION_PACKET_BLOCKED",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorization_packet_created": packet_ready,
        "source_mutation_apply_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_applied": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "authorization_material_validated_count": 1 if packet_ready else 0,
            "source_mutation_authorization_packet_created_count": 1 if packet_ready else 0,
            "source_mutation_apply_authorized_count": 0,
            "rollback_plan_valid_count": 1 if packet_ready else 0,
            "tracking_strategy_valid_count": 1 if packet_ready else 0,
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
        },
        "validation_issues": issues,
        "authorization_packet": authorization_packet,
        "boundary": [
            "This command validates source-mutation authorization material and emits a local packet only.",
            "It does not apply a patch, enqueue a patch, mutate source/package/archive state, call a provider/model, commit, merge, or perform external actions.",
            "A later explicit apply gate must consume this packet before any candidate patch can touch manuscript source.",
        ],
    }
    if any(str(item.get("issue") or "").startswith(("forbidden_boundary_crossed", "forbidden_source_gate_permission", "forbidden_authorization_flag")) for item in issues):
        report["status"] = "FAIL"
        report["authorization_packet_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
    return report


def research_compute_source_authorization_packet_markdown(report):
    lines = [
        "# paper_factory Research Compute Source Authorization Packet",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Authorization packet state: {report.get('authorization_packet_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Packet created: {report.get('source_mutation_authorization_packet_created')}",
        f"- Apply authorized: {report.get('source_mutation_apply_authorized')}",
        f"- Source mutation performed: {report.get('source_mutation_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("authorization_packet") or {}
    lines.extend(["", "## Authorization Packet", ""])
    lines.append(f"- Target: `{packet.get('target_path') or ''}`")
    lines.append(f"- Candidate patch: `{packet.get('candidate_patch_path') or ''}`")
    lines.append(f"- Candidate patch SHA256: `{packet.get('candidate_patch_sha256') or ''}`")
    lines.append(f"- Required next gate: `{packet.get('required_next_gate') or ''}`")
    lines.append(f"- Apply allowed: {packet.get('apply_allowed')}")
    lines.append(f"- Enqueue allowed: {packet.get('enqueue_allowed')}")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
