"""Preflight a research-compute candidate patch before any source mutation.

This layer reviews candidate patch text and creates a source-gate packet. It
does not apply, enqueue, merge, or mutate manuscript/package/archive state.
"""

from paperctl_modules import agent_autonomy_policy

COMMAND = "research-compute-source-gate"

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "source_gate_state",
    "report_schema",
    "plan_only",
    "execution_performed",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_authorized",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_enqueue_authorized",
    "candidate_patch_queue_mutation_performed",
    "candidate_patch_reviewed",
    "candidate_patch_applied",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "summary",
    "authorization_material_state",
    "validation_issues",
    "source_gate_packet",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "candidate_patch_reviewed_count",
    "source_preflight_passed_count",
    "source_mutation_authorized_count",
    "agent_generated_evidence_material_count",
    "patch_queue_enqueue_authorized_count",
]

REPORT_SCHEMA_NOTES = [
    "Reviews a candidate patch draft and emits a local source preflight packet only.",
    "No source mutation, patch queue enqueue, or patch application is performed by this command.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def validate_authorization_material(material):
    issues = []
    if not material:
        return issues, "NOT_PROVIDED_PREFLIGHT_ONLY"
    if not isinstance(material, dict):
        return [{"issue": "authorization_material_must_be_object"}], "INVALID"
    scope = str(material.get("scope") or material.get("authorization_scope") or "")
    if scope and scope not in {"source_gate_preflight_only", "candidate_patch_review_only", "review_only"}:
        issues.append({"issue": "authorization_scope_not_preflight_only", "detail": scope})
    for key in [
        "source_mutation_authorized",
        "patch_queue_enqueue_authorized",
        "package_mutation_authorized",
        "archive_mutation_authorized",
        "provider_model_call_authorized",
        "external_action_authorized",
    ]:
        if material.get(key):
            issues.append({"issue": f"forbidden_authorization_scope:{key}"})
    return issues, "STRUCTURE_VALID_PREFLIGHT_ONLY" if not issues else "INVALID"


def validate_draft_report(draft_report, authorization_material=None):
    issues = []
    if draft_report.get("command") != "research-compute-candidate-patch-draft":
        issues.append({"issue": "draft_report_command_mismatch", "detail": draft_report.get("command") or ""})
    if draft_report.get("status") != "PASS":
        issues.append({"issue": "draft_report_not_pass", "detail": draft_report.get("status") or ""})
    if draft_report.get("draft_state") != "CANDIDATE_PATCH_DRAFT_READY_NOT_APPLIED":
        issues.append({"issue": "draft_state_not_ready", "detail": draft_report.get("draft_state") or ""})
    if not draft_report.get("candidate_patch_generated"):
        issues.append({"issue": "candidate_patch_required"})
    patch = draft_report.get("candidate_patch") or {}
    target = str(patch.get("target_path") or "")
    patch_text = str(patch.get("patch_text") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_candidate_patch_target", "detail": target})
    if target and not target.startswith("research_compute_candidate_notes/"):
        issues.append({"issue": "candidate_patch_target_outside_research_compute_notes", "detail": target})
    if not patch_text:
        issues.append({"issue": "candidate_patch_text_required"})
    elif target:
        if not patch_text.startswith(f"diff --git a/{target} b/{target}"):
            issues.append({"issue": "candidate_patch_diff_header_mismatch", "detail": target})
        if f"+++ b/{target}" not in patch_text:
            issues.append({"issue": "candidate_patch_new_path_mismatch", "detail": target})
    if patch.get("patch_sha256") and not _valid_sha256(patch.get("patch_sha256")):
        issues.append({"issue": "invalid_candidate_patch_sha256"})
    for key in [
        "apply_allowed",
        "enqueue_allowed",
        "source_mutation_allowed",
    ]:
        if patch.get(key):
            issues.append({"issue": f"forbidden_candidate_patch_permission:{key}"})
    for key in [
        "source_mutation_performed",
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_mutation_performed",
        "candidate_patch_applied",
        "provider_model_call_performed",
        "external_action_performed",
    ]:
        if draft_report.get(key):
            issues.append({"issue": f"forbidden_boundary_crossed:{key}"})
    auth_issues, auth_state = validate_authorization_material(authorization_material)
    issues.extend(auth_issues)
    return issues, auth_state


def research_compute_source_gate(draft_report, authorization_material=None, label=""):
    authorization_material = authorization_material or {}
    issues, auth_state = validate_draft_report(draft_report or {}, authorization_material)
    patch = (draft_report or {}).get("candidate_patch") or {}
    policy = agent_autonomy_policy.normalize_policy(
        patch.get("autonomy_policy") or (draft_report or {}).get("autonomy_policy")
    )
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = bool(patch.get("agent_generated_evidence_material") or (draft_report or {}).get("agent_generated_evidence_material"))
    target = patch.get("target_path") or ""
    status = "PASS" if not issues else "ATTENTION"
    report = {
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "source_gate_state": "SOURCE_PREFLIGHT_READY_APPLY_BLOCKED" if not issues else "SOURCE_PREFLIGHT_BLOCKED",
        "plan_only": True,
        "execution_performed": False,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_authorized": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_mutation_performed": False,
        "candidate_patch_reviewed": not issues,
        "candidate_patch_applied": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "candidate_patch_reviewed_count": 1 if not issues else 0,
            "source_preflight_passed_count": 1 if not issues else 0,
            "source_mutation_authorized_count": 0,
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
            "patch_queue_enqueue_authorized_count": 0,
        },
        "authorization_material_state": auth_state,
        "validation_issues": issues,
        "source_gate_packet": {
            "source_preflight_passed": not issues,
            "target_path": target,
            "candidate_patch_path": patch.get("patch_path") or "",
            "candidate_patch_sha256": patch.get("patch_sha256") or "",
            "full_agent_autonomy_authorized": full_autonomy,
            "autonomy_policy": policy,
            "agent_generated_evidence_material": agent_generated,
            "apply_allowed": False,
            "enqueue_allowed": False,
            "source_mutation_allowed": False,
            "required_next_gate": "explicit_source_mutation_authorization_gate",
            "from_draft_report_path": (draft_report or {}).get("report_path") or "",
        },
        "boundary": [
            "This command reviews a candidate patch draft and creates a source preflight packet only.",
            "It does not apply a patch, enqueue a patch, mutate source/package/archive state, call a provider/model, or perform external actions.",
            "A later explicit source mutation authorization gate is required before any candidate patch can touch manuscript source.",
        ],
    }
    if any(str(item.get("issue") or "").startswith(("forbidden_boundary_crossed", "forbidden_candidate_patch_permission", "forbidden_authorization_scope")) for item in issues):
        report["status"] = "FAIL"
        report["source_gate_state"] = "FORBIDDEN_BOUNDARY_CROSSED"
    return report


def research_compute_source_gate_markdown(report):
    lines = [
        "# paper_factory Research Compute Source Gate",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- Source gate state: {report.get('source_gate_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Candidate patch reviewed: {report.get('candidate_patch_reviewed')}",
        f"- Source mutation authorized: {report.get('source_mutation_authorized')}",
        f"- Candidate patch applied: {report.get('candidate_patch_applied')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    packet = report.get("source_gate_packet") or {}
    lines.extend(["", "## Source Gate Packet", ""])
    lines.append(f"- Target: `{packet.get('target_path') or ''}`")
    lines.append(f"- Candidate patch: `{packet.get('candidate_patch_path') or ''}`")
    lines.append(f"- Apply allowed: {packet.get('apply_allowed')}")
    lines.append(f"- Enqueue allowed: {packet.get('enqueue_allowed')}")
    lines.append(f"- Required next gate: `{packet.get('required_next_gate') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
