"""Verify a research-compute source apply and report integration status."""

import datetime as dt
import re

from paperctl_modules import agent_autonomy_policy


COMMAND = "research-compute-source-post-apply-verify"
PREVIOUS_COMMAND = "research-compute-source-apply"
PREVIOUS_APPLIED_STATE = "SOURCE_APPLY_GATE_APPLIED"
TARGET_PREFIX = "research_compute_candidate_notes/"
HASH_RE = re.compile(r"^- `([^`]+)` `([0-9a-f]{64})`$")

STABLE_TOP_LEVEL_FIELDS = [
    "created_at",
    "command",
    "status",
    "post_apply_verify_state",
    "report_schema",
    "source_post_apply_verified",
    "candidate_note_integrated",
    "report_write_performed",
    "db_mutation_performed",
    "source_mutation_performed",
    "package_mutation_performed",
    "archive_mutation_performed",
    "candidate_patch_queue_enqueue_authorized",
    "candidate_patch_queue_mutation_performed",
    "full_agent_autonomy_authorized",
    "autonomy_policy",
    "agent_generated_evidence_material",
    "provider_model_call_authorized",
    "provider_model_call_performed",
    "external_action_authorized",
    "external_action_performed",
    "commit_authorized",
    "commit_performed",
    "summary",
    "validation_issues",
    "target_file",
    "parsed_note",
    "artifact_checks",
    "rollback_file",
    "integration_status",
    "boundary",
]

STABLE_SUMMARY_FIELDS = [
    "validation_issue_count",
    "target_verified_count",
    "artifact_verified_count",
    "rollback_verified_count",
    "candidate_note_integrated_count",
    "agent_generated_evidence_material_count",
    "patch_queue_enqueue_authorized_count",
    "commit_performed_count",
]

REPORT_SCHEMA_NOTES = [
    "Verifies a prior research-compute source apply and reports integration status only.",
    "No patch application, package/archive mutation, patch queue enqueue, commit, merge, upload, email, or external action is performed.",
]


def _safe_relative_path(path):
    text = str(path or "")
    if not text or text.startswith("/"):
        return False
    return ".." not in text.split("/")


def _valid_sha256(value):
    text = str(value or "")
    return len(text) == 64 and all(ch in "0123456789abcdef" for ch in text.lower())


def _created_at():
    return dt.datetime.now().replace(microsecond=0).isoformat(sep=" ")


def _literal_true(value):
    return value is True


def _literal_bool_or_missing(value):
    return isinstance(value, bool) or value is None


def parse_candidate_note(content):
    lines = (content or "").splitlines()
    parsed = {
        "title_present": bool(lines and lines[0].strip() == "# Research Compute Candidate Evidence"),
        "slug": "",
        "job_id": "",
        "workspace": "",
        "output_hashes": [],
    }
    for line in lines:
        if line.startswith("- Slug:"):
            parsed["slug"] = line.split(":", 1)[1].strip()
        elif line.startswith("- Job:"):
            parsed["job_id"] = line.split(":", 1)[1].strip()
        elif line.startswith("- Workspace:"):
            parsed["workspace"] = line.split("`", 2)[1] if "`" in line else ""
        else:
            match = HASH_RE.match(line.strip())
            if match:
                parsed["output_hashes"].append({"path": match.group(1), "sha256": match.group(2)})
    return parsed


def validate_source_apply_report(source_apply_report):
    issues = []
    source_apply_report = source_apply_report or {}
    if source_apply_report.get("command") != PREVIOUS_COMMAND:
        issues.append({"issue": "source_apply_report_command_mismatch", "detail": source_apply_report.get("command") or ""})
    if source_apply_report.get("status") != "PASS":
        issues.append({"issue": "source_apply_report_not_pass", "detail": source_apply_report.get("status") or ""})
    if source_apply_report.get("source_apply_state") != PREVIOUS_APPLIED_STATE:
        issues.append({"issue": "source_apply_state_not_applied", "detail": source_apply_report.get("source_apply_state") or ""})
    if not _literal_bool_or_missing(source_apply_report.get("source_mutation_performed")):
        issues.append({"issue": "invalid_source_apply_boolean:source_mutation_performed", "detail": repr(source_apply_report.get("source_mutation_performed"))})
    if not _literal_true(source_apply_report.get("source_mutation_performed")):
        issues.append({"issue": "source_mutation_required"})
    if not _literal_bool_or_missing(source_apply_report.get("candidate_patch_applied")):
        issues.append({"issue": "invalid_source_apply_boolean:candidate_patch_applied", "detail": repr(source_apply_report.get("candidate_patch_applied"))})
    if not _literal_true(source_apply_report.get("candidate_patch_applied")):
        issues.append({"issue": "candidate_patch_applied_required"})
    apply_result = source_apply_report.get("apply_result") or {}
    if not _literal_bool_or_missing(apply_result.get("performed")):
        issues.append({"issue": "invalid_apply_result_boolean:performed", "detail": repr(apply_result.get("performed"))})
    if not _literal_true(apply_result.get("performed")):
        issues.append({"issue": "apply_result_performed_required"})
    target = str(apply_result.get("target_path") or "")
    if not _safe_relative_path(target):
        issues.append({"issue": "unsafe_applied_target", "detail": target})
    if target and not target.startswith(TARGET_PREFIX):
        issues.append({"issue": "applied_target_outside_research_compute_notes", "detail": target})
    if not _valid_sha256(apply_result.get("target_sha256")):
        issues.append({"issue": "apply_result_target_sha256_required"})
    for key in [
        "package_mutation_performed",
        "archive_mutation_performed",
        "candidate_patch_queue_enqueue_authorized",
        "candidate_patch_queue_mutation_performed",
        "provider_model_call_performed",
        "external_action_performed",
        "commit_performed",
    ]:
        if not _literal_bool_or_missing(source_apply_report.get(key)):
            issues.append({"issue": f"invalid_source_apply_boolean:{key}", "detail": repr(source_apply_report.get(key))})
        elif _literal_true(source_apply_report.get(key)):
            issues.append({"issue": f"forbidden_apply_boundary_crossed:{key}"})
    return issues


def validate_target_file(target_file, source_apply_report):
    issues = []
    target_file = target_file or {}
    apply_result = (source_apply_report or {}).get("apply_result") or {}
    if not _literal_bool_or_missing(target_file.get("exists")):
        issues.append({"issue": "invalid_target_file_boolean:exists", "detail": repr(target_file.get("exists"))})
    if not _literal_true(target_file.get("exists")):
        issues.append({"issue": "applied_target_missing", "detail": target_file.get("path") or ""})
    if not _literal_bool_or_missing(target_file.get("is_file")):
        issues.append({"issue": "invalid_target_file_boolean:is_file", "detail": repr(target_file.get("is_file"))})
    elif target_file.get("is_file") is False:
        issues.append({"issue": "applied_target_not_file", "detail": target_file.get("path") or ""})
    if str(target_file.get("path") or "") != str(apply_result.get("target_path") or ""):
        issues.append({"issue": "applied_target_path_mismatch"})
    if not _valid_sha256(target_file.get("sha256")):
        issues.append({"issue": "applied_target_sha256_required"})
    if target_file.get("sha256") != apply_result.get("target_sha256"):
        issues.append({"issue": "applied_target_sha256_mismatch"})
    return issues


def validate_candidate_note(parsed_note):
    issues = []
    parsed_note = parsed_note or {}
    if not _literal_bool_or_missing(parsed_note.get("title_present")):
        issues.append({"issue": "invalid_candidate_note_boolean:title_present", "detail": repr(parsed_note.get("title_present"))})
    if not _literal_true(parsed_note.get("title_present")):
        issues.append({"issue": "candidate_note_title_missing"})
    if not parsed_note.get("slug"):
        issues.append({"issue": "candidate_note_slug_missing"})
    if not parsed_note.get("job_id"):
        issues.append({"issue": "candidate_note_job_missing"})
    workspace = str(parsed_note.get("workspace") or "")
    if not _safe_relative_path(workspace):
        issues.append({"issue": "candidate_note_workspace_missing_or_unsafe", "detail": workspace})
    if not parsed_note.get("output_hashes"):
        issues.append({"issue": "candidate_note_output_hashes_required"})
    for item in parsed_note.get("output_hashes") or []:
        if not _safe_relative_path(item.get("path") or ""):
            issues.append({"issue": "candidate_note_output_path_unsafe", "detail": item.get("path") or ""})
        if not _valid_sha256(item.get("sha256")):
            issues.append({"issue": "candidate_note_output_sha_required", "detail": item.get("path") or ""})
    return issues


def validate_artifact_checks(artifact_checks, parsed_note):
    issues = []
    artifact_checks = list(artifact_checks or [])
    expected = {(item.get("path"), item.get("sha256")) for item in (parsed_note or {}).get("output_hashes") or []}
    observed = {(item.get("path"), item.get("expected_sha256")) for item in artifact_checks}
    if expected and expected != observed:
        issues.append({"issue": "artifact_check_set_mismatch"})
    for item in artifact_checks:
        if not _literal_bool_or_missing(item.get("exists")):
            issues.append({"issue": "invalid_artifact_check_boolean:exists", "detail": item.get("path") or "", "value": repr(item.get("exists"))})
        if not _literal_true(item.get("exists")):
            issues.append({"issue": "artifact_missing", "detail": item.get("path") or ""})
        if not _literal_bool_or_missing(item.get("sha256_match")):
            issues.append({"issue": "invalid_artifact_check_boolean:sha256_match", "detail": item.get("path") or "", "value": repr(item.get("sha256_match"))})
        if not _literal_true(item.get("sha256_match")):
            issues.append({"issue": "artifact_sha256_mismatch", "detail": item.get("path") or ""})
    return issues


def validate_rollback(rollback_file, source_apply_report):
    issues = []
    rollback_file = rollback_file or {}
    apply_result = (source_apply_report or {}).get("apply_result") or {}
    if not _literal_bool_or_missing(rollback_file.get("exists")):
        issues.append({"issue": "invalid_rollback_file_boolean:exists", "detail": repr(rollback_file.get("exists"))})
    if not _literal_true(rollback_file.get("exists")):
        issues.append({"issue": "rollback_patch_missing", "detail": rollback_file.get("path") or ""})
    if not _literal_bool_or_missing(rollback_file.get("is_file")):
        issues.append({"issue": "invalid_rollback_file_boolean:is_file", "detail": repr(rollback_file.get("is_file"))})
    elif rollback_file.get("is_file") is False:
        issues.append({"issue": "rollback_patch_not_file", "detail": rollback_file.get("path") or ""})
    if not _valid_sha256(rollback_file.get("sha256")):
        issues.append({"issue": "rollback_patch_sha256_required"})
    if str(rollback_file.get("path") or "") != str(apply_result.get("rollback_patch_path") or ""):
        issues.append({"issue": "rollback_patch_path_mismatch"})
    if not _literal_bool_or_missing(rollback_file.get("mentions_target")):
        issues.append({"issue": "invalid_rollback_file_boolean:mentions_target", "detail": repr(rollback_file.get("mentions_target"))})
    if not _literal_true(rollback_file.get("mentions_target")):
        issues.append({"issue": "rollback_patch_target_missing"})
    return issues


def research_compute_source_post_apply_verify(source_apply_report, target_file=None, parsed_note=None, artifact_checks=None, rollback_file=None, label=""):
    source_apply_report = source_apply_report or {}
    policy = agent_autonomy_policy.normalize_policy(source_apply_report.get("autonomy_policy"))
    full_autonomy = agent_autonomy_policy.full_autonomy_enabled(policy)
    agent_generated = _literal_true(source_apply_report.get("agent_generated_evidence_material"))
    target_file = target_file or {}
    parsed_note = parsed_note or {}
    artifact_checks = list(artifact_checks or [])
    rollback_file = rollback_file or {}
    issues = validate_source_apply_report(source_apply_report)
    issues.extend(validate_target_file(target_file, source_apply_report))
    issues.extend(validate_candidate_note(parsed_note))
    issues.extend(validate_artifact_checks(artifact_checks, parsed_note))
    issues.extend(validate_rollback(rollback_file, source_apply_report))
    if issues and any(str(item.get("issue") or "").startswith("forbidden_apply_boundary_crossed") for item in issues):
        status = "FAIL"
        state = "FORBIDDEN_BOUNDARY_CROSSED"
    elif issues:
        status = "ATTENTION"
        state = "SOURCE_POST_APPLY_VERIFY_BLOCKED"
    else:
        status = "PASS"
        state = "SOURCE_POST_APPLY_VERIFIED_INTEGRATION_STATUS_READY"
    verified = status == "PASS"
    integration_status = {
        "candidate_note_integrated": verified,
        "target_path": target_file.get("path") or "",
        "target_sha256": target_file.get("sha256") or "",
        "slug": parsed_note.get("slug") or "",
        "job_id": parsed_note.get("job_id") or "",
        "workspace": parsed_note.get("workspace") or "",
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "artifact_count": len(artifact_checks),
        "artifact_hashes_verified": verified,
        "rollback_patch_verified": verified,
        "patch_queue_enqueue_allowed": False,
        "commit_allowed": False,
        "required_next_gate": "research_compute_candidate_note_integration_review",
    }
    return {
        "created_at": _created_at(),
        "command": COMMAND,
        "label": label or "",
        "status": status,
        "post_apply_verify_state": state,
        "source_post_apply_verified": verified,
        "candidate_note_integrated": verified,
        "report_write_performed": False,
        "db_mutation_performed": False,
        "source_mutation_performed": False,
        "package_mutation_performed": False,
        "archive_mutation_performed": False,
        "candidate_patch_queue_enqueue_authorized": False,
        "candidate_patch_queue_mutation_performed": False,
        "full_agent_autonomy_authorized": full_autonomy,
        "autonomy_policy": policy,
        "agent_generated_evidence_material": agent_generated,
        "provider_model_call_authorized": bool(policy.get("provider_model_call_authorized")),
        "provider_model_call_performed": False,
        "external_action_authorized": bool(policy.get("external_action_authorized")),
        "external_action_performed": False,
        "commit_authorized": False,
        "commit_performed": False,
        "summary": {
            "validation_issue_count": len(issues),
            "target_verified_count": 1 if verified else 0,
            "artifact_verified_count": len(artifact_checks) if verified else 0,
            "rollback_verified_count": 1 if verified else 0,
            "candidate_note_integrated_count": 1 if verified else 0,
            "agent_generated_evidence_material_count": 1 if agent_generated else 0,
            "patch_queue_enqueue_authorized_count": 0,
            "commit_performed_count": 0,
        },
        "validation_issues": issues,
        "target_file": target_file,
        "parsed_note": parsed_note,
        "artifact_checks": artifact_checks,
        "rollback_file": rollback_file,
        "integration_status": integration_status,
        "boundary": [
            "This command verifies a prior research-compute source apply and reports integration status only.",
            "It does not apply patches, enqueue patch queues, mutate package/archive state, call providers/models, commit, merge, upload, email, or perform external actions.",
            "A separate review/enqueue gate is required before candidate notes can affect manuscript patch queues.",
        ],
    }


def research_compute_source_post_apply_verify_markdown(report):
    lines = [
        "# paper_factory Research Compute Source Post-Apply Verify",
        "",
        f"- Label: {report.get('label') or ''}",
        f"- Status: {report.get('status') or ''}",
        f"- State: {report.get('post_apply_verify_state') or ''}",
        f"- Full agent autonomy: {report.get('full_agent_autonomy_authorized')}",
        f"- Candidate note integrated: {report.get('candidate_note_integrated')}",
        f"- Commit performed: {report.get('commit_performed')}",
        "",
        "## Summary",
        "",
    ]
    for key, value in (report.get("summary") or {}).items():
        lines.append(f"- {key}: {value}")
    status = report.get("integration_status") or {}
    lines.extend(["", "## Integration Status", ""])
    lines.append(f"- Target: `{status.get('target_path') or ''}`")
    lines.append(f"- Target SHA256: `{status.get('target_sha256') or ''}`")
    lines.append(f"- Slug: `{status.get('slug') or ''}`")
    lines.append(f"- Job: `{status.get('job_id') or ''}`")
    lines.append(f"- Required next gate: `{status.get('required_next_gate') or ''}`")
    lines.extend(["", "## Boundary", ""])
    for item in report.get("boundary") or []:
        lines.append(f"- {item}")
    lines.append("")
    return "\n".join(lines)
